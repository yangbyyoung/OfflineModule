function sponsor() {
echo "#################################
 - 按音量键(volume key)＋: 赞助作者(sponsor)
 - 按音量键(volume key)－: 下次一定(jump)
#################################"
	while :;do choose="$(getevent -qlc 1 | awk '{ print $3 }')";case "${choose}" in KEY_VOLUMEUP)echo "感谢支持"; am start -a android.intent.action.VIEW -d  https://afdian.net/a/HCha1 >/dev/null &;;KEY_VOLUMEDOWN);;*)continue;esac;break;done
}
function cpconf() {
[[ ! -f "$hsgarb/$1" ]] && cp "$MODPATH/Xxxxx/$1" "$hsgarb/$1"
}
#########main##########
rm -rf /data/media/0/Android/HChai/
hsgarb="/sdcard/Android/HChai/HC_hsgarb"
mkdir -p $hsgarb
if [[ ! -f "/data/adb/modules/zygisk_hsgarb/.sponsor" ]];then
    sponsor
fi
echo 'no' > "$MODPATH/.sponsor"

cpconf 应用.conf
cpconf 终端配置.sh
cpconf 阻止创建路径.conf
cp -f "$MODPATH/Xxxxx/简单介绍与使用.TXT" "$hsgarb/简单介绍与使用.TXT"
cp -f "$MODPATH/Xxxxx/更新日志.TXT" "$hsgarb/更新日志.TXT"
rm -rf $MODPATH/Xxxxx

set_perm_recursive $MODPATH 0 0 0755 0777