#! /vendor/bin/sh

MODDIR=${0%/*}

# setprop sys.lmk.minfree_levels 12800:0,16384:100,18432:200,24576:250,32768:900,49152:950

# stop lmkd
# 
# start lmkd

swap_config="/data/swap_config.conf"
function get_prop() {
  cat $swap_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

# 解析配置
use_ram=$(get_prop use_ram)

# 备份日志
if [[ -f '/cache/swap.log' ]]; then
mv /cache/swap.log /cache/swap.log.bak
fi

# 设置内存管理机制
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $MODDIR/system.prop
}
if [ "$use_ram" == "lmk" ]; then
echo "✔内存管理方式设置为lmk" >> /cache/swap.log
update_system_prop ro.lmk.use_psi false
update_system_prop ro.lmk.psi_partial_stall_ms 750
update_system_prop ro.lmk.psi_complete_stall_ms 1000
update_system_prop ro.lmk.thrashing_limit 30
update_system_prop ro.lmk.thrashing_limit_decay 50
elif [ "$use_ram" == "psi1" ]; then
echo "✔内存管理方式设置为psi1" >> /cache/swap.log
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 750
update_system_prop ro.lmk.psi_complete_stall_ms 1000
update_system_prop ro.lmk.thrashing_limit 30
update_system_prop ro.lmk.thrashing_limit_decay 50
elif [ "$use_ram" == "psi2" ]; then
echo "✔内存管理方式设置为psi2" >> /cache/swap.log
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 250
update_system_prop ro.lmk.psi_complete_stall_ms 700
update_system_prop ro.lmk.thrashing_limit 30
update_system_prop ro.lmk.thrashing_limit_decay 50
elif [ "$use_ram" == "psi3" ]; then
echo "✔内存管理方式设置为psi3" >> /cache/swap.log
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 40
update_system_prop ro.lmk.psi_complete_stall_ms 200
update_system_prop ro.lmk.thrashing_limit 100
update_system_prop ro.lmk.thrashing_limit_decay 10
else
echo "✘无法设置内存管理方式：$use_ram，请检查参数是否正确" >> /cache/swap.log
fi