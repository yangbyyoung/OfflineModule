#!/system/bin/bash
# 优化MIUI12.5;来自酷安@Amktiao;https://www.coolapk.com/feed/29060961?shareKey=OTYyYWRjNTE2OGFhNjExNGY4ZjY~&shareUid=3481348&shareFrom=com.coolapk.market_11.1.5.1

# 判断脚本适用版本号
[[ $(getprop ro.miui.ui.version.name) != "V125" ]] && exit 0
# 查询ROM储存规格；“sd”开头，为UFS；“mmcblk”开头，为eMMC
[[ -n "$(ls /proc/fs/* | grep "^sd*")" ]] && rom_mode="ufs" || { [[ -n "$(ls /proc/fs/* | grep "^mmcblk*")" ]] && rom_mode="emmc";}
# 查询UFS版本；wSpecVersion=0x1002为UFS1.0；0x2为UFS2.0；0x21为UFS2.1
#ufs_version_1=$(find / -type f -iname "dump_device_desc" -exec grep "wSpecVersion" {} \; 2>/dev/null | awk -F '=' '{print $2}')
#[[ "$ufs_version_1" == *"0x1"* ]] && ufs_version="1"
#[[ "$ufs_version_1" == *" 0x2"* ]] && ufs_version="2"
#[[ "$ufs_version_1" == *" 0x3"* ]] && ufs_version="3"

# 禁用小米内核调试收集服务；在/system/build.prop末尾添加一行sys.miui.ndcd=off即可禁用
test "$(cat /system/build.prop | grep "sys.miui.ndcd" | awk -F '=' '{print $2}')" != "off" && { sed -i '/^sys.miui.ndcd/d' /system/build.prop;echo "sys.miui.ndcd=off" >>/system/build.prop;}
# 停止高通的wlan_logs日志抓取
stop cnss_diag
# 停止tcpdump日志工具；用于网络抓包
stop tcpdump
# 停止安卓运行日志
stop logd

modify_value(){
test -f $2 && echo $1 > $2
}
# 禁用收集磁盘I/O读写统计；原值为 1、1、1、1、1、1
# UFS设备使用
[[ $rom_mode == "ufs" ]] && {
modify_value 0 /sys/block/sda/queue/iostats ;
modify_value 0 /sys/block/sdb/queue/iostats ;
modify_value 0 /sys/block/sdc/queue/iostats ;
modify_value 0 /sys/block/sdd/queue/iostats ;
modify_value 0 /sys/block/sde/queue/iostats ;
modify_value 0 /sys/block/sdf/queue/iostats ;}
# eMMC设备使用
[[ $rom_mode == "emmc" ]] && modify_value 0 /sys/block/mmcblk0/queue/iostats

# 更改磁盘I/O预读大小；原值为 512、128、512、128、x、x
# UFS设备使用
[[ $rom_mode == "ufs" ]] && {
modify_value 128 /sys/block/sda/queue/read_ahead_kb ;
modify_value 36 /sys/block/sda/queue/nr_requests ;
modify_value 128 /sys/block/sde/queue/read_ahead_kb ;
modify_value 36 /sys/block/sde/queue/nr_requests ;
modify_value 128 /sys/block/dm-5/queue/read_ahead_kb ;
modify_value 36 /sys/block/dm-5/queue/nr_requests ;}
# eMMC设备使用
[[ $rom_mode == "emmc" ]] && modify_value 128 /sys/block/mmcblk0/queue/read_ahead_kb

# 调整ZRAM分区 512、128
modify_value 128 /sys/block/zram0/queue/read_ahead_kb
modify_value 36 /sys/block/zram0/queue/nr_requests
# 禁用binder活页夹日志；原值为 7、0
modify_value 0 /sys/module/binder/parameters/debug_mask
modify_value 0 /sys/module/binder_alloc/parameters/debug_mask
# 禁用内核调试 1、Y
modify_value 0 /sys/module/msm_show_resume_irq/parameters/debug_mask
modify_value N /sys/kernel/debug/debug_enabled
# 调整page虚拟空间页面集群大小；原值为 3
modify_value 0 /proc/sys/vm/page-cluster
# 禁用不必要的转储 1
modify_value 0 /sys/module/subsystem_restart/parameters/enable_ramdumps
# 禁用用户空间向dmesg写入日志 on
modify_value off /proc/sys/kernel/printk_devkmsg
# 禁用sched_autogroup 1
modify_value 0 /proc/sys/kernel/sched_autogroup_enabled
# 调整脏页写回策略时间 200
modify_value 3000 /proc/sys/vm/dirty_expire_centisecs
# 禁用f2fs I/O数据收集统计
modify_value 0 /sys/fs/f2fs/dm-5/iostat_enable
# 禁用调度统计 1
modify_value 0 /proc/sys/kernel/sched_schedstats
# 调整虚拟内存更新/刷新间隔；改为10或者20；原值为 1
modify_value 10 /proc/sys/vm/stat_interval
# 开启F2FS加速回收；改为1；原值为 0
modify_value 1 /sys/fs/f2fs/$(getprop dev.mnt.blk.data)/gc_booster
# 对F2FS的优化；手机root后，安卓内核对F2FS调整失效导致手机变慢
modify_value 50 /sys/fs/f2fs/$(getprop dev.mnt.blk.data)/gc_urgent_sleep_time
modify_value 200 /sys/fs/f2fs/$(getprop dev.mnt.blk.data)/cp_interval
# 未知项优化
modify_value 134217728 /sys/block/sda/queue/discard_max_bytes

# 回写结果至zw_fileclear脚本清理模块
zw_fileclear_service="/data/adb/modules/zw_fileclear/service.sh"
[[ -f $zw_fileclear_service ]] && sed -i "s/^miui_optimization_result=.*/miui_optimization_result=0/g" $zw_fileclear_service

compilers_apps() {
# 以speed方式编译常用APP;speed-profile部分编译，speed全编译
compilers_app_list='
cn.crec.wxwork
cn.kuwo.player
cn.ticktick.task
com.android.camera
com.autonavi.minimap
com.babytree.apps.pregnancy
com.baidu.searchbox
com.coolapk.market
com.eg.android.AlipayGphone
com.jingdong.app.mall
com.ks.kaishustory
com.lemon.faceu
com.lemon.lv
com.mt.mtxx.mtxx
com.sina.weibo
com.ss.android.ugc.aweme
com.ss.android.ugc.aweme.lite
com.taobao.idlefish
com.taobao.taobao
com.tencent.mm
com.tencent.mobileqq
com.tencent.qqlite
com.tencent.wework
com.xingin.xhs
tv.hanju.lite
'
if [[ -x /system/bin/cmd && -x /system/bin/dumpsys ]]
then
  for compilers_app in $compilers_app_list;do
    compile_result_1=$(/system/bin/dumpsys package $compilers_app | grep "status=")
    if [[ -n "$compile_result_1" && "$compile_result_1" != *"speed]"* ]];then
      /system/bin/cmd package compile -m speed $compilers_app 2>/dev/null &
      sleep 0.5s
    fi
  done
fi
}

# compilers_apps