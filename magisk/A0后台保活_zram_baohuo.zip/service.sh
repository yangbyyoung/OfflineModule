#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# LMK
chmod 777 /sys/module/lowmemorykiller/parameters/minfree
chown 777 /sys/module/lowmemorykiller/parameters/minfree
echo '10240,16384,18432,20480,30720,33280' > /sys/module/lowmemorykiller/parameters/minfree
echo '56250' > /sys/module/lowmemorykiller/parameters/vmpressure_file_min
adjZeroMinFree=14746
echo '262144' > /proc/sys/vm/extra_free_kbytes
# 修改zram为8g
echo '1' > /sys/block/zram0/reset
echo 'O' > /sys/block/zramO/disksize
echo '8' > /sys/block/zram0/max_comp_streams
echo '3892314112' > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1
# Kill无用线程
killall -9 com.xiaomi.market
killall -9 com.miui.screenrecorder
killall -9 com.miui.bugreport
killall -9 com.miui.analytics