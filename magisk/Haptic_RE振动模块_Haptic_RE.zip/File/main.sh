
End() {
ui_print "*************************"
ui_print " 更改选项请重刷模块,个别新机型禁用手势可能无效."
ui_print " 模块安装/卸载目录:data/adb/modules/$MODID"
ui_print " ID参数/映射作业/效果修改: 　　↑↑/system.prop"
ui_print " 仅适配官方MIUI-0809马达机型.官改/移植包兼容性未知!"
ui_print " 模块并非万能,若有振动异常,请删除本模块."
}

Endlite() {
ui_print "　　　　　　 ［注意］"
ui_print " 精简安装只有system.prop生效! 效果一般."
ui_print " 且无法修改返回与清理；请用Miui Extra映射补全震动."
ui_print " 映射请参考安装目录system.prop"
sleep 2
}

Notice() {
ui_print "　　　 ［是否增强通知振动］"
if [ -f $C/$aw ]; then
   ui_print "　　　 音量↑:是　音量↓:否"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　 ✓✓"
     cp -rf $F/$aw $D
     ;;
     *)
     ui_print "　　　　　　　　　　 ✓✓"
   esac
else
   ui_print "-本机无$aw文件,此项无效!请忽略."
fi
}

getver() {
NAME="`grep_prop name $M/module.prop`"
AUT="`grep_prop author $M/module.prop`"
VER="`grep_prop version $M/module.prop`"
VC="`grep_prop versionCode $M/module.prop`"
ui_print "-模块:$MODID　作者：$AUT"
ui_print "-版本:$VER　版本代号:$VC"
}

ckdir() {
if [ "$KSU" ]; then
   if [ -f $C/28_*_P_RTP.bin ]; then
     ui_print "-驱动目录:$C/ (_P_RTP)"
   else
     ui_print "-驱动目录:$C/ (_RTP)"
   fi
elif [ "$(which magisk)" ]; then
   if [ -f $C/28_*_P_RTP.bin ]; then
     ui_print "-驱动目录:$C/ (_P_RTP)"
   else
     ui_print "-驱动目录:$C/ (_RTP)"
   fi
   if [ "$A" = "odm" ]; then
     ui_print "-此目录需Delta面具,否则振动异常"
   else
     ui_print "-此目录不限面具版本"
   fi
fi
}

Mapp() {
cp -rf $F/ID*/* $M
File="$C/70_*.bin"
cp -rf $F/70_*.bin $D/$(basename ${File})
File="$C/71_*.bin"
cp -rf $F/71_*.bin $D/$(basename ${File})
File="$C/72_*.bin"
cp -rf $F/72_*.bin $D/$(basename ${File})
File="$C/162_*.bin"
cp -rf $F/70_*.bin $D/$(basename ${File})
File="$C/163_*.bin"
cp -rf $F/70_*.bin $D/$(basename ${File})
File="$C/169_*.bin"
cp -rf $F/71_*.bin $D/$(basename ${File})
File="$C/92_*.bin"
cp -rf $F/s/70_*.bin $D/$(basename ${File})
File="$C/91_*.bin"
cp -rf $F/s/71_*.bin $D/$(basename ${File})
File="$C/84_*.bin"
cp -rf $F/s/72_*.bin $D/$(basename ${File})
File="$C/90_*.bin"
cp -rf $F/93_*.bin $D/$(basename ${File})
File="$C/43_*.bin"
cp -rf $F/43_*.bin $D/$(basename ${File})
File="$C/74_*.bin"
cp -rf $F/76_*.bin $D/$(basename ${File})
File="$C/76_*.bin"
cp -rf $F/76_*.bin $D/$(basename ${File})
File="$C/85_*.bin"
cp -rf $F/85_*.bin $D/$(basename ${File})
File="$C/86_*.bin"
cp -rf $F/86_*.bin $D/$(basename ${File})
File="$C/87_*.bin"
cp -rf $F/87_*.bin $D/$(basename ${File})
File="$C/93_*.bin"
cp -rf $F/93_*.bin $D/$(basename ${File})
File="$C/171_*.bin"
cp -rf $F/171_*.bin $D/$(basename ${File})
File="$C/209_*.bin"
cp -rf $D/169*.bin $D/$(basename ${File})
File="$C/210_*.bin"
cp -rf $D/162*.bin $D/$(basename ${File})
File="$C/212_*.bin"
cp -rf $D/93*.bin $D/$(basename ${File})
File="$C/213_*.bin"
cp -rf $D/93*.bin $D/$(basename ${File})
File="$C/216_*.bin"
cp -rf $D/87*.bin $D/$(basename ${File})
}

Patch() {
if [ ! -f $F/171_*.bin ] || [ ! -f $F/85_*.bin ]; then
   rm -rf $MODPATH/$SC/71_*.bin
   rm -rf $MODPATH/$SC/72_*.bin
   rm -rf $MODPATH/$SC/74_*.bin
   rm -rf $MODPATH/$SC/92_*.bin
   rm -rf $MODPATH/$SC/91_*.bin
   rm -rf $MODPATH/$SC/84_*.bin
fi
if [ -f $C/MiRemix_*.bin ]; then
   File="$C/MiRemix_*.bin"
   cp -rf $D/43_*.bin $D/$(basename ${File})
   File="$C/Spring_*.bin"
   cp -rf $D/70_*.bin $D/$(basename ${File})
   File="$C/Swoosh_*.bin"
   cp -rf $D/71_*.bin $D/$(basename ${File})
   File="$C/Gesture_UpSlide_*.bin"
   cp -rf $D/72_*.bin $D/$(basename ${File})
   File="$C/Charge_Wire_*.bin"
   cp -rf $D/74_*.bin $D/$(basename ${File})
   File="$C/Unlock_Failed_*.bin"
   cp -rf $D/76_*.bin $D/$(basename ${File})
   File="$C/uninstall_dialog_*.bin"
   cp -rf $D/84_*.bin $D/$(basename ${File})
   File="$C/screenshot_*.bin"
   cp -rf $D/85_*.bin $D/$(basename ${File})
   File="$C/lockscreen_camera_*.bin"
   cp -rf $D/86_*.bin $D/$(basename ${File})
   File="$C/launcher_edit_*.bin"
   cp -rf $D/87_*.bin $D/$(basename ${File})
   File="$C/task_cleanall_*.bin"
   cp -rf $D/90_*.bin $D/$(basename ${File})
   File="$C/new_iconfolder_*.bin"
   cp -rf $D/91_*.bin $D/$(basename ${File})
   File="$C/notification_remove_*.bin"
   cp -rf $D/92_*.bin $D/$(basename ${File})
   File="$C/notification_cleanall_*.bin"
   cp -rf $D/93_*.bin $D/$(basename ${File})
   File="$C/Gesture_Back_Pull_*.bin"
   cp -rf $D/162_*.bin $D/$(basename ${File})
   File="$C/Gesture_Back_Release_*.bin"
   cp -rf $D/163_*.bin $D/$(basename ${File})
   File="$C/lockdown_*.bin"
   cp -rf $D/169_*.bin $D/$(basename ${File})
   File="$C/todo_alldone_*.bin"
   cp -rf $D/171_*.bin $D/$(basename ${File})
fi
}

ckid() {
if [ -f $C/162_Gesture*.bin ] && [ -f $C/163_Gesture*.bin ]; then
   　=　
else
   ui_print "! ID文件(162_Gesture*.bin、163_Gesture*.bin)异常！"
   IDerror
fi
if [ -f $C/90_taskClean*.bin ]; then
   　=　
else
   ui_print "! ID文件(90_taskClean*.bin)异常！"
   IDerror
fi
if [ -f $C/93_notificationCleanall*.bin ]; then
   　=　
else
   ui_print "! ID文件(93_notificationCleanall*.bin)异常！"
   IDerror
fi
}

main() {
mkdir -p $D
getver
ckdir
ui_print "*********个性化选项********"
sleep 0.1
ui_print "　　　　　 ［版本选择］"
ui_print "　　 音量↑:独立　音量↓:映射"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   . $F/Single.sh
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
   Mapp
esac
Patch
Notice
End
}

if [ "$KSU" ]; then
   ui_print "*************************"
   ui_print "-KSU版本:$KSU_KERNEL_VER_CODE(kernel)+$KSU_VER_CODE(ksud)"
   ui_print "-完整安装用于测试新版KSU兼容性."
   ui_print "-KSU目前仅支持精简安装,否则无振动."
   sleep 0.5
   ui_print "　　 音量↑:精简　音量↓:完整"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　 ✓✓"
     cp - rf $F/lite/* $M
     getver
     ckdir
     Endlite
     ;;
     *)
     ui_print "　　　　　　　　　　 ✓✓"
     ckid
     main
   esac
elif [ "$(which magisk)" ]; then
   ckid
   ui_print "*************************"
   ui_print "-面具版本:$MAGISK_VER($MAGISK_VER_CODE)"
   main
else
   abort "-不支持 Recovery !"
fi