#根据下面的频率可自定义
# /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies
# 300000 403200 499200 595200 691200 806400 902400 998400 1094400 1209600 1305600 1401600 1497600 1612800 1708800 1804800

# /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies
# 710400 844800 960000 1075200 1209600 1324800 1440000 1555200 1670400 1766400 1881600 1996800 2112000 2227200 2342400 2419200

# /sys/devices/system/cpu/cpu7/cpufreq/scaling_available_frequencies
# 844800 960000 1075200 1190400 1305600 1420800 1555200 1670400 1785600 1900800 2035200 2150400 2265600 2380800 2496000 2592000 2688000 2764800 2841600

action=$1

if [[ "$action" = "powersave" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "2-6" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '806400' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1305600' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '300000' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1075200' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '5000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'conservative' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '1440000' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '710400' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '844800' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '1000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'conservative' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '844800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '844800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '379000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq |\
echo '260000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '7' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '9' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '9' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
# lpm_levels低延时
echo 'N' >/sys/module/lpm_levels/parameters/sleep_disabled
for idle in $(find /sys/module/lpm_levels -name idle_enabled);do
chmod 777 $idle
echo 'N' >$idle
chmod 444 $idle
done
# 处理器EAS配置
for level in $(find /dev/cpuset -name sched_relax_domain_level);do
chmod 777 $level
echo '-1' >$level
chmod 444 $level
done
for load in $(find /dev/cpuset -name sched_load_balance);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for load in $(find /sys/devices/system/cpu -name sched_load_boost);do
chmod 777 $load
echo '0' >$load
chmod 444 $load
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.max);do
chmod 777 $uclamp
echo 'min' >$uclamp
chmod 444 $uclamp
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.min);do
chmod 777 $uclamp
echo 'min' >$uclamp
chmod 444 $uclamp
done
for boost in $(find /dev/cpuctl -name cpu.uclamp.sched_boost_no_override);do
chmod 777 $boost
echo '0' >$boost
chmod 444 $boost
done
# I/O配置
echo 15258 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq
echo 2288 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq
echo 12191 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 762 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq

elif [[ "$action" = "balance" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-6" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '1401600' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1804800' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '499200' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1440000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '500' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '1881600' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '710400' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '960000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '500' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'conservative' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '1075200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '844800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '491000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq |\
echo '315000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '5' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '8' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '8' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
# lpm_levels低延时
echo 'Y' >/sys/module/lpm_levels/parameters/sleep_disabled
for idle in $(find /sys/module/lpm_levels -name idle_enabled);do
chmod 777 $idle
echo 'Y' >$idle
chmod 444 $idle
done
# 处理器EAS配置
for level in $(find /dev/cpuset -name sched_relax_domain_level);do
chmod 777 $level
echo '-1' >$level
chmod 444 $level
done
for load in $(find /dev/cpuset -name sched_load_balance);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for load in $(find /sys/devices/system/cpu -name sched_load_boost);do
chmod 777 $load
echo '0' >$load
chmod 444 $load
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.max);do
chmod 777 $uclamp
echo 'min' >$uclamp
chmod 444 $uclamp
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.min);do
chmod 777 $uclamp
echo 'min' >$uclamp
chmod 444 $uclamp
done
for boost in $(find /dev/cpuctl -name cpu.uclamp.sched_boost_no_override);do
chmod 777 $boost
echo '0' >$boost
chmod 444 $boost
done
# I/O配置
echo 15258 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq
echo 2288 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq
echo 12191 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 762 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq

elif [[ "$action" = "performance" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '1094400' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1305600' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '902400' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1555200' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '2112000' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '1209600' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '1555200' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'conservative' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '2035200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '1190400' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '608000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq |\
echo '315000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '3' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '8' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '8' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
# lpm_levels低延时
echo 'Y' >/sys/module/lpm_levels/parameters/sleep_disabled
for idle in $(find /sys/module/lpm_levels -name idle_enabled);do
chmod 777 $idle
echo 'Y' >$idle
chmod 444 $idle
done
# 处理器EAS配置
for level in $(find /dev/cpuset -name sched_relax_domain_level);do
chmod 777 $level
echo '1' >$level
chmod 444 $level
done
for load in $(find /dev/cpuset -name sched_load_balance);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for load in $(find /sys/devices/system/cpu -name sched_load_boost);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.max);do
chmod 777 $uclamp
echo 'max' >$uclamp
chmod 444 $uclamp
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.min);do
chmod 777 $uclamp
echo 'max' >$uclamp
chmod 444 $uclamp
done
for boost in $(find /dev/cpuctl -name cpu.uclamp.sched_boost_no_override);do
chmod 777 $boost
echo '1' >$boost
chmod 444 $boost
done
# I/O配置
echo 15258 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq
echo 2288 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq
echo 12191 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 762 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq

elif [[ "$action" = "fast" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-0" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '1497600' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1804800' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '902400' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1881600' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '2419200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '1440000' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '2035200' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '87' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '2841600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '1555200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '850000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq |\
echo '491000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo 'simple_ondemand' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '0' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '5' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '5' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
# lpm_levels低延时
echo 'Y' >/sys/module/lpm_levels/parameters/sleep_disabled
for idle in $(find /sys/module/lpm_levels -name idle_enabled);do
chmod 777 $idle
echo 'Y' >$idle
chmod 444 $idle
done
# 处理器EAS配置
for level in $(find /dev/cpuset -name sched_relax_domain_level);do
chmod 777 $level
echo '1' >$level
chmod 444 $level
done
for load in $(find /dev/cpuset -name sched_load_balance);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for load in $(find /sys/devices/system/cpu -name sched_load_boost);do
chmod 777 $load
echo '1' >$load
chmod 444 $load
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.max);do
chmod 777 $uclamp
echo 'max' >$uclamp
chmod 444 $uclamp
done
for uclamp in $(find /dev/cpuctl -name cpu.uclamp.min);do
chmod 777 $uclamp
echo 'max' >$uclamp
chmod 444 $uclamp
done
for boost in $(find /dev/cpuctl -name cpu.uclamp.sched_boost_no_override);do
chmod 777 $boost
echo '1' >$boost
chmod 444 $boost
done
# I/O配置
echo 15258 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq
echo 2288 >/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq
echo 12191 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 762 >/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq
fi