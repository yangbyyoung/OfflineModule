chmod 731 /data/system/theme
