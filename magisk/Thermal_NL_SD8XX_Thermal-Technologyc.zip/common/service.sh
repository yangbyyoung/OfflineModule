#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

sleep 20

# This script will be executed in late_start service mode
# Force Thermal Dynamic Evaluation
chmod 0777 /sys/class/thermal/thermal_message/sconfig
echo '10' > /sys/class/thermal/thermal_message/sconfig
chmod 0444 /sys/class/thermal/thermal_message/sconfig

sleep 20 

# Fast Charger
chmod 0777 /sys/kernel/fast_charge/force_fast_charge
echo 1 > /sys/kernel/fast_charge/force_fast_charge
chmod 0444 /sys/kernel/fast_charge/force_fast_charge

chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
echo 5000000 > /sys/class/power_supply/battery/constant_charge_current_max
chmod 0444 /sys/class/power_supply/battery/constant_charge_current_max
