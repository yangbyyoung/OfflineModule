
function correctpath(){
	case `echo "$1"` in
	/system_ext* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	/vendor* )
		echo "/system"$1""
	;;
	/product* )
		echo "/system"$1""
	;;
	esac
}


find /system/ /system_ext /vendor /product -iname 'WCNSS_qcom_cfg.ini' -type f 2> /dev/null | while read file ;do
file=$(correctpath $file)
mkdir -p $MODPATH$(dirname $file)
cp -rf $file $MODPATH$(dirname $file)
sed 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nEND/g' $MODPATH$file
sed -i 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
test -z $file && abort "－ 您的设备不支持！"
done

logdir=/data/vendor/wlan_logs
test -e $logdir && rm -rf "$logdir/*"


