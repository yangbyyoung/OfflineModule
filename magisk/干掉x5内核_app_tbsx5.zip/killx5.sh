rmthch(){
if [[ -e "$1" ]];then
rm -rf "$1"
touch "$1"
chmod 000 "$1"
fi
}
echo ""
echo "∞————————————————————————∞"
echo "感谢酷安@Silver橙子喵酱，添加"app_xwalk"文件夹的清理。"
echo ""
echo "∞————————————————————————∞"
echo ""
echo ""
echo "∞————————————————————————∞"
echo ""
echo -e "\n- 查找文件文件中……\n"
echo "－ 请耐心等待……"

X5=`find /data/data -name '*app_tbs*' -type d -o -name '*app_tbs_64*' -type d -o -iname '*app_x5webview*' -type d -o -iname '*app_xwalk*' -type d`
X5backup=`find /data/media -name '*.tbs.*'`
if [[ "$X5" != "" ]];then
for i in $X5;do
rmthch $i 2>/dev/null
echo -e "\n- 已生成x5内核占用文件: \n $i"
done
else
echo "－ 并未发现X5内核文件。"
fi
if [[ "$X5backup" != "" ]];then
for i in $X5backup;do
rm -rf $i 2>/dev/null
echo -e "- 已删除x5内核备份占用文件: \n $i"
done
else
echo "－ 并未发现X5内核备份文件。"
fi
echo ""
echo "∞————————————————————————∞"
