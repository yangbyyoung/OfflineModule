#! /vendor/bin/sh
# LKT V5.1
# Author: korom42
# Credits: Matt Yang

# powercfg wrapper for com.omarea.vtools
# MAKE SURE THAT THE MAGISK MODULE "Uperf" HAS BEEN INSTALLED

