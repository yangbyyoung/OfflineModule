rm -rf /data/.poes
