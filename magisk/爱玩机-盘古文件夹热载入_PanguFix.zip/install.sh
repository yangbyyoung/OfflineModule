SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=true
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 if [ ! -d "/system/product/pangu/system"  ] ; then
  abort "您的设备不支持，别乱刷哦，没有任何效果！"
 else
  ui_print "已经完成此版本号的应用挂载！"
fi
  ui_print "首次使用，清理缓存避免模块不生效！"
# rm -rf /data/dalvik-cache
# rm -rf /data/system/package_cache
  cache_path=/data/dalvik-cache/arm
  [ -d $cache_path"64" ] && cache_path=$cache_path"64"
	for fileName in $system_ext_cache; do
		rm -f $cache_path/system_ext@*@"$fileName"*
		rm -f /data/system/package_cache/*/"$fileName"*
	done
	
	for fileName in $system_cache; do
		rm -f $cache_path/system@*@"$fileName"*
		rm -f /data/system/package_cache/*/"$fileName"*
	done
  
}
set_permissions() {
 #set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
  ui_print "动态加载，跳过权限设定！"
#
}