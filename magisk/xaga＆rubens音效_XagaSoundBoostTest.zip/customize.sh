SKIPUNZIP=0
MODDIR=${0%/*}
alias sh='/system/bin/sh'

print_modname() {
    ui_print "*******************************"
    ui_print "shadow3，我 Mly 要亲亲亲亲死你"
    ui_print "二改自酷安 @huber，二改作者酷安 @Mly"
    ui_print "音频通路/调音：酷安 @是Ray酱呀"
    ui_print "*******************************"
    ui_print "模块安装后需要开关音质音效的杜比开关和进入均衡器，场景推荐音乐模式。"
}

set_permissions() {
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:vendor_file:s0
}

install_pangu_fix() {
    ui_print "即将为您安装盘古修复"
    ui_print "此模块可以修复MIUI14的NFC及Joyose无响应等问题"
    ui_print "若您不需要（magisk26.0+）或已安装其他修复模块，请取消安装，谨慎操作"
    ui_print "单击音量上键即可确认安装"
    ui_print "单击音量下键取消安装"
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo "您已确认安装，请稍候"
            echo "正在为您安装pangu_fix"
            magisk --install-module "$MODPATH/modules/pangu_fix.zip"
            echo "* 已为您安装pangu_fix"
        ;;
        *)
            echo "已为您取消安装pangu_fix"
    esac
    rm -rf "$MODPATH/modules/pangu_fix.zip"
}

print_modname
set_permissions
install_pangu_fix