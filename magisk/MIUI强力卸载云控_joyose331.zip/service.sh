
#开机等待
sleep 35s

#指定包名
com="
com.miui.analytics
com.xiaomi.joyose
"

#强力卸载
for i in $com
do
pm uninstall -k --user 0 $i
done