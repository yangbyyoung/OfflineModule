#!/system/bin/sh
#2023031010
#Petit-Abba
#Environment Variables

# The system's busybox is more comfortable.
PATH="/system/bin"
# Executable Binary File Location.
