echo "
————————————————————🍂🍃🍂🍃
"
echo "
●————————⑤不必要的模块————————●
"
echo "－请你自行考虑是否要移除或者禁用模块。"
echo "－因为实际测试结果得出，模块装多确实会增加耗电😂"
echo "－如无必要，尽量不要搞一些替换二进制进程的模块。"
echo "－具体原因我也不知，就很迷惑😵"
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
if [[ -e $module_id/system/bin/logd ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－如果你没有logd 耗电异常，请尽量不要装。"
echo "－已知某个微信版本会造成异常耗电(7.0.18)，换个版本即可。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
if [[ -e $module_id/system/bin/mdnsd ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－如果你没有mdnsd 耗电异常，请尽量不要装。"
echo "－这玩意貌似的耗电和打印服务有关，你可以通过关闭打印服务来缓解异常。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
echo "
————————————————————🍂🍃🍂🍃
"
echo ""
echo ""