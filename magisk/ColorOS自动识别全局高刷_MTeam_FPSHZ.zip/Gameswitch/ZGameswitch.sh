#!/bin/bash
MODDIR=${0%/*}

cd $MODDIR/
#Run script program
awk 'BEGIN {
    i=0;
    do {
		system("'$PWD/ZGameswitchs.sh' ")
    }
    while (i)
exit;
}'