mount -o rw,remount /data
MODDIR=${0%/*}

# dependency
rm -f /data/adb/modules/MiuiCore/remove
rm -f /data/adb/modules/MiuiCore/disable

# cleaning
FILE=$MODDIR/cleaner.sh
if [ -f $FILE ]; then
  sh $FILE
  rm -f $FILE
fi




