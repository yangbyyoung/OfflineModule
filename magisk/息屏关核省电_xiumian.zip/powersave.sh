screen=`dumpsys window policy | grep "mInputRestricted"|cut -d= -f2`

dumpsys deviceidle | grep -q Enabled=true
check=$?

if [[ $screen = true ]]; then
    if [[ $check = 1 ]]; then

dumpsys deviceidle enable
echo powersave > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo powersave > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
echo 0 > /sys/devices/system/cpu/cpu2/online
echo 0 > /sys/devices/system/cpu/cpu3/online
echo 0 > /sys/devices/system/cpu/cpu4/online
echo 0 > /sys/devices/system/cpu/cpu5/online
echo 0 > /sys/devices/system/cpu/cpu6/online
echo 0 > /sys/devices/system/cpu/cpu7/online

echo $(date '+%Y-%m-%d %H:%M:%S') 已关闭 > /data/powersavelog.txt

    fi
else
    if [[ $check = 0 ]]; then

dumpsys deviceidle disable
echo schedutil > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo schedutil > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
echo 1 > /sys/devices/system/cpu/cpu2/online
echo 1 > /sys/devices/system/cpu/cpu3/online
echo 1 > /sys/devices/system/cpu/cpu4/online
echo 1 > /sys/devices/system/cpu/cpu5/online
echo 1 > /sys/devices/system/cpu/cpu6/online
echo 1 > /sys/devices/system/cpu/cpu7/online

echo $(date '+%Y-%m-%d %H:%M:%S') 已开启 > /data/powersavelog.txt

    fi
fi