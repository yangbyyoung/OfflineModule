SKIPMOUNT=false
set_perm_recursive  $MODPATH  0  0  0755  0644
if [[ ! -n $miui_version ]];then
ui_print "- 非miui系统，终止安装……" && abort
fi
if [[ "$var_version" != "11" ]];then
ui_print "- 非安卓11，终止安装……" && abort
fi