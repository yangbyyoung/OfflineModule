#
Added stereo sound effect and improved sound quality. Based in initial work of Kommandoz from 4PDA updated 

## Changelog
### v3:
- Updated Magisk template
### v2:
- Based on 9.10.24 vendor 
### v1:
- Initial Release
- Added stereo sound effect
- Sound volume increased
- Built mod according to instructions from Dante63

