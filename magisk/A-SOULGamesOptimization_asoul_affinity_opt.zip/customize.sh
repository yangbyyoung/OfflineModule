CFG_PATH="/sdcard/Android/naki/asopt"

echo "
- 卸载CuToolbox，你不卸载我帮你
- 配置位于 $CFG_PATH
- 可在 asopt.conf 内切换放置方案
- 并且可在其中修改主线程容量修正值
- 主线程容量修正值会影响帧率和功耗

- Uninstall CuToolbox, otherwise I will help you
- The config is at $CFG_PATH
- You can switch affinity plans in asopt.conf
- And also modify the main thread boost value
- The value affects fps and power consumption
"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/AsoulOpt 0 0 0755

note="# fallback：放置方案
# 0：抢占优化，理论上表现更好
# 1：均衡负载，更接近官方调度
# 建议自行测试以选择更好的方案
# ***切换方案后重启生效***

# boost：主线程容量修正值
# 范围 0-100，0 即关闭此功能
# 提升此值后将会提升大核频率
# 并可能导致更高的帧率和功耗
# 建议自行测试以选择更好的值
# ***修改此值后即时生效***

# fallback: Affinity plans
# 0: Preemptive, performs better in theory
# 1: Load balancing, closer to the default
# Test by yourself to know which is better
# ***Reboot after switching to take effect***

# boost: The main thread boost value
# The range is 0-100, 0 to turn off this feature
# This value will boost the prime core frequency
# May result in higher fps and power consumption
# Test by yourself to know which value is better
# ***You don't need to reboot after modification***
"

fallback=$(grep fallback= $CFG_PATH/asopt.conf)
boost=$(grep boost= $CFG_PATH/asopt.conf)
[ -z $fallback ] && fallback="fallback=0"
[ -z $boost ] && boost="boost=0"

rm -rf /data/adb/asopt /data/asopt.conf /sdcard/Android/asopt /sdcard/Android/naki/asopt/asopt.log
mkdir -p $CFG_PATH
echo "$note
$fallback
$boost" > $CFG_PATH/asopt.conf

for i in `find /data/adb/modules -name CuDaemon | cut -f 5 -d /`; do
    touch /data/adb/modules/$i/remove
done
