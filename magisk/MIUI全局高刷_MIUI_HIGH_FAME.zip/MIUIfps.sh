#!/system/bin/sh

function hight_test(){
local IFS=$'\n'
local value="$(dumpsys display | grep 'DisplayModeRecord' | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g')"
for i in $value
do
	echo "$i"
done
}

function choose_hightest(){
	hight_test | sed 's|\..*||g' | sort -n | tail -n 1
}


echo "
#设置开机最高刷新率
persist.vendor.dfps.level=$(choose_hightest)
" >> "$MODPATH/system.prop"


for i in $MODPATH/prop/*.prop
do
echo "
#设置开机最高刷新率
persist.vendor.dfps.level=$(choose_hightest)
" >> "${i}"
done

