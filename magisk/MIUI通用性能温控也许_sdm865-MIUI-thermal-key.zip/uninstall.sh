#!/system/bin/sh

wait_until_login() {
	# in case of /data encryption is disabled
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done

	# we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
	local test_file="/sdcard/Android/.PERMISSION_TEST"
	true >"$test_file"
	while [ ! -f "$test_file" ]; do
		true >"$test_file"
		sleep 1
	done
	rm "$test_file"
}

function unlock_thermal(){
local target="${1}" 
/data/adb/magisk/busybox chattr -R -i "${target}" >/dev/null 2>&1
/data/adb/magisk/busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
busybox chattr -R -i "${target}" >/dev/null 2>&1
busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
chattr -R -i "${target}" >/dev/null 2>&1
chattr -R -i "${target%/*}" >/dev/null 2>&1
rm -rf "${target%/*}"
}

function uninstall_running() {
wait_until_login
#智能充电保护
resetprop -p persist.vendor.night.charge true
iptables -F
unlock_thermal "/data/thermal/config"
unlock_thermal "/data/vendor/thermal/config"
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver >/dev/null 2>&1
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService >/dev/null 2>&1
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity >/dev/null 2>&1
pm enable com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver >/dev/null 2>&1
chattr -R =A /data/data/com.xiaomi.joyose
pm clear com.miui.powerkeeper >/dev/null
pm clear com.xiaomi.joyose >/dev/null
am broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
}

( uninstall_running & )
