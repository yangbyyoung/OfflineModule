SKIPUNZIP=0

print_modname() {
	ui_print "*******************************"
	ui_print "- mly:shadow3亲亲亲亲亲亲！！！"
	ui_print "*******************************"
	ui_print "- shadow3:mly亲亲亲亲亲亲！！！"
	ui_print "*******************************"
	ui_print "- 这是两只🐷🐷造成的震动！！！"
	ui_print "*******************************"
}

set_permissions() {
	set_perm_recursive $MODPATH 0 0 0755 0644
}

print_modname
set_permissions