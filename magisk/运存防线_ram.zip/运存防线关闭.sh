#!/system/bin/sh
MODDIR=${0%/*}

script_name="ram.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
    echo "进程 $lastID 已经结束"
    kill -KILL $lastID
fi
echo " "
lastIDD=$(pgrep -f "$script_name")
if [ "$lastIDD" != "" ]; then
    echo -e "\e[32m正在运行……\n\e[0m"
        
else
    echo -e "\e[31m没有运行……\n\e[0m"
fi
  