#!/system/bin/sh

# https://cs.android.com/android/platform/superproject/+/master:system/memory/lmkd/lmkd.cpp
# https://source.android.com/devices/tech/perf/lmkd
setprop ro.lmk.kill_heaviest_task true
setprop ro.lmk.kill_timeout_ms 100
setprop ro.lmk.use_psi true
setprop ro.lmk.use_minfree_levels true
setprop ro.lmk.low 1001
setprop ro.lmk.medium 1001
setprop ro.lmk.critical 1001
setprop ro.lmk.upgrade_pressure 95
setprop ro.lmk.downgrade_pressure 90
setprop ro.lmk.swap_free_low_percentage 5
