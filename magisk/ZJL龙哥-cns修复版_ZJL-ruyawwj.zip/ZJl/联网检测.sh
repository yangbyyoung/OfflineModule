	#全局颜色
	echo "\E[1;36m"
	echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
	echo -n '正在测试DNS...'
	for i in `${0%/*}/*/MLBox -timeout=5 -dns="-qtype=A -domain=time1.cloud.tencent.com" | grep -v 'timeout' | grep -E '[1-9][0-9]{0,2}(\.[0-9]{1,3}){3}'`; do
		ntpip=$i
		break
	done
	if [ -n "$ntpip" ]; then
		echo -e "\r✓ DNS联网成功          "
		echo -n '正在测试HTTP...'
		httpIP=`${0%/*}/*/MLBox -timeout=7 -http="http://182.254.116.116/d?dn=qq.com&clientip=1" 2>&1 | grep -Ev 'timeout|httpGetResponse' | grep -E '[1-9][0-9]{0,2}(\.[0-9]{1,3}){3}'`
		if [ -n "$httpIP" ]; then
			httpIP="${httpIP#*\|}"
			echo -e "\r✓ HTTP联网成功          "
		else
			echo -e "\r× HTTP联网失败          "
		fi
		echo -n '正在测试HTTPS...'
		ipInfo=`${0%/*}/*/MLBox -timeout=7 -http="https://ip.tool.lu/" 2>&1 | grep -Ev 'timeout|httpGetResponse'`
		if echo "$ipInfo" | grep -qi 'IP'; then
			echo -e "\r✓ HTTPS联网成功          "
		else
			httpsResp=`${0%/*}/*/MLBox -timeout=7 -http="https://ip.cn/dns.html" 2>&1 | grep -Ev 'timeout|httpGetResponse' | grep -E '[1-9][0-9]{0,2}(\.[0-9]{1,3}){3}'`
			if [ -n "$httpsResp" ]; then
				echo -e "\r✓ HTTPS联网成功          "
			else
				echo -e "\r× HTTPS联网失败          "
			fi
		fi
		echo -n '正在测试UDP...'
		currentTime=`${0%/*}/*/MLBox -timeout=7 -ntp="$ntpip" | grep -v 'timeout'`
		echo "$currentTime" | grep -qi 'LI:' && \
			echo -e "\r✓ UDP联网成功          " || \
			echo -e "\r× UDP联网失败          "
		echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
    sleep 1;
		if [ -n "$ipInfo" ]; then
			echo "$ipInfo"
		elif [ -n "$httpIP" ]; then
			echo "当前ip:$httpIP"
		fi
	else
		echo -e "\r× DNS错误 请更改IP          "
	fi