function mount_file(){
set_perm_recursive $MODPATH  0  0  0755  0644
for i in $bootpath;do
mount --bind $MODPATH$i $i
done
for i in $bootpath_dark;do
mount --bind $MODPATH$i $i
done
}

function uount_file(){
for i in $bootpath;do
umount $i
done
for i in $bootpath_dark;do
umount $i
done
}

function boot_view(){
setprop service.bootanim.exit 0
setprop ctl.start bootanim
sleep 10
setprop ctl.stop bootanim
setprop service.bootanim.exit 1
}

ui_print  "
"
ui_print  "————————————————————————"
ui_print  "即將播放開機動畫"
ui_print  "請確保開機動畫能正常工作否則不要保持模塊為開啟狀態"
sleep 3
mount_file 2>/dev/null 
boot_view 2>/dev/null
uount_file 2>/dev/null
ui_print  ""
ui_print "————————————————————————"