# 该脚本将在卸载模块期间执行，您可以编写自定义卸载规则
MODDIR=${0%/*}
sd0="/data/media/0"
test "$(echo /data/media/[0-9]*)" != "/data/media/0" && sd="/data/media/[0-9]*" || sd="/data/media/0"
# 自定义find、xargs等命令
command_list='
find
gawk
xargs
'
for command_temp_1 in $command_list;do
  command_temp_2=$(find $MODDIR -type f -iname "$command_temp_1" 2>/dev/null)
  if [[ -f $command_temp_2 ]];then
    chmod 775 $command_temp_2 2>/dev/null
    alias $command_temp_1="$command_temp_2"
  fi
done


# 卸载Crontabs服务
magisk_path=$(magisk --path)/.magisk
mount|grep "ro,"|grep -v "$magisk_path/"|awk -F'[ ,]' '{print $1,$3}'|while read a b
do
mount -o rw,remount $a $b &>/dev/null
done
crondID=`pgrep crond`
kill -9 $crondID 2>/dev/null
rm -rf /var

# 删除模块生成的0kb屏蔽文件
find /data/data /data/media /data/user_de -type f -size 0 -perm 000 2>/dev/null|xargs -I temp_file sh -c "chattr -i \"temp_file\" 2>/dev/null;rm -f \"temp_file\" 2>/dev/null"

# 删除MIUI 12.5优化在/system/build.prop中的痕迹
test -n "$(cat /system/build.prop | grep "sys.miui.ndcd")" && sed -i '/^sys.miui.ndcd/d' /system/build.prop

wait
rm -rf $sd/FileClear_zw_* $sd/adzw*.txt