SKIPMOUNT=false
miui_version="`grep_prop ro.miui.ui.version.name`"
var_soc="`getprop ro.board.platform`"
model="`grep_prop ro.product.system.model`"
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.device`"
var_version="`grep_prop ro.build.version.release`"
author="`grep_prop author $TMPDIR/module.prop`"
name="`grep_prop name $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
ui_print "- *******************************"
ui_print "- 您的设备名称: $model"
ui_print "- 您的设备: $var_device"
ui_print "- 系统版本: $var_version"
ui_print "- miui版本: $miui_version"
ui_print "- $name    "
ui_print "- 作者：$author"
ui_print "- $description   "
ui_print "- *******************************"
ui_print "
- 如果卡开机请在
- rec→高级→文件管理
- →data→adb→modules
- 删除$id这个文件夹
" 
[[ ! -n $miui_version ]] && abort "－非MIUI系统，停止安装。"
on_install() {
unzip -oq "$ZIPFILE" 'system/*' -d "$MODPATH/" >&2
source $TMPDIR/themepath.sh
source $TMPDIR/zip.sh
}

set_perm_recursive  $MODPATH  0  0  0755  0644