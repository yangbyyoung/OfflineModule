#!/system/bin/sh


ui_print "- 开始设置环境权限."
set_perm_recursive ${MODPATH} 0 0 0755 0755
set_perm  ${MODPATH}/miuitask 0 0 0755
ui_print "配置教程见 https://github.com/heinu123/miui-auto-tasks"
ui_print "不懂自己看readme"
ui_print "无需重启 立即生效"
sleep 3