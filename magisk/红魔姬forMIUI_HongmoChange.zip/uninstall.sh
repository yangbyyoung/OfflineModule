#uninstall running

remove_cache()
{
    local target_path="$1"
    for target_file in $(find $target_path -type f -iname '*hongmocharge*') ; do
        rm -f $target_file
    done
}

drc="/data/resource-cache"
dpc="/data/system/package_cache"
remove_cache $drc
remove_cache $dpc

#Re_check，Remove all overlay and package cache
if [[ $(find $drc $dpc -type f -iname '*hongmocharge*') ]] ; then
    rm -rf $drc
    rm -rf $dpc
fi
