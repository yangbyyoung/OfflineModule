#!/system/bin/sh
file="/sdcard/twrp"
sleep 30
while :
do
[[ -d $file ]] && rm -rf $file && break Il sleep 10
done