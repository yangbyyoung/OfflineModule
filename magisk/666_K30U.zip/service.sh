#!/system/bin/sh
echo 1 >/sys/module/ged/parameters/is_GED_KPI_enabled
echo 1 >/sys/module/ged/parameters/gx_frc_mode
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/proc/sys/net/ipv6/conf/all/forwarding
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
