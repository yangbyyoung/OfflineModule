

#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

value="$(show_value '应用内存限制大小' )"

function topapp() {
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
	echo "$app"
}

function recentapp(){
	local value="${1}"
	am stack list | sed '/taskId/!d;s|[[:space:]]taskId=.*[0-9]:[[:space:]]||g;s|\/.*||g;s|[[:space:]]||g;/^com.miui.home$/d' | grep -w "${value}" | head -n 1
}

function notification_simulation(){
local title="${2}"
local text="${1}"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
	test -z "${title}" && title='10007'
	test -z "${text}" && text='您未给出任何信息'
su -lp 2000 -c "cmd notification post -S messaging --conversation '${title}' --message '${title}':'${text}' 'Tag' '$(echo $RANDOM)' " >/dev/null 2>&1
}


function compile_mem() {
	local mem=$(dumpsys meminfo "$1" | awk '/TOTAL:/' | awk '{print $2}' 2>/dev/null)
	test "$(topapp)" = "${1}" && return
	test "$(recentapp "${1}" )" = "${1}" && return
	if test -n "$mem" ;then
		mem=$(($mem / 1024))
		if test "$mem" -gt "$value"; then
			if test "$(topapp)" = "${1}" -o "$(recentapp "${1}" )" = "${1}" ;then
				echo "跳过清理 [ ${1} ]"
					return
				else
					killall -15 "$1" || killall -9 "$1"
			fi
			sed -i "/^description=/c description="$(date +%H:%M)" ，"$1" 给爷死啊！占那么大的内存！内存回收 "$mem" MB。配置文件在$MODPATH目录下，$MODPATH/Conf是限制应用的名单。" "$MODPATH/module.prop"
			notification_simulation "$(date +%H:%M) ，"$1" 给爷死啊！占那么大的内存！内存回收 "$mem" MB。" "内存管理优化模块"
		fi
	fi
}

conf_file="$MODPATH/Conf/内存限制应用.prop"
cat "${conf_file}" | sed '/^#/d;/^[[:space:]]*$/d' | while read package; do
	compile_mem "$package"
done


