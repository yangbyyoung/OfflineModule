#!/system/bin/sh
    chmod 755 $MODPATH/bin/*
    $MODPATH/bin/install
    rm $MODPATH/bin/install
    sh $MODPATH/service.sh