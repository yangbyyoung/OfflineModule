SKIPUNZIP=0
DEBUG=false
M="$MODPATH"
F="$M/File/wave"
pro="$M/File/prop"
obui="/odm/etc/build.prop"
vbui="/vendor/build.prop"
aw="aw8697_haptic.bin"
P="`grep_prop ro.product.odm.device $obui`"
V="`grep_prop ro.odm.build.version.incremental $obui`"

###↓获取马达驱动目录↓###
#米系(8g2、8g3)机型
if grep -iq sys.haptic.down= $obui || [ -f /odm/firmware/0_*.bin ] || [ -f /odm/firmware/88_*.bin ]; then
#设定马达驱动目录
C="/odm/firmware"
#系统默认prop参数
defprop="/odm/etc/build.prop"

#米系(8+及以下、MTK)机型
elif grep -iq sys.haptic.down= $vbui || [ -f /vendor/firmware/alert*.bin ] || [ -f /vendor/firmware/0_*.bin ] || [ -f /vendor/firmware/88_*.bin ]; then
#设定马达驱动目录
C="/vendor/firmware"
#系统默认prop参数
defprop="/vendor/build.prop"
else
ui_print ""
ui_print "-设备:$P-$V(SDK:$API)"
ui_print "-未检测到马达驱动目录."
abort ""
fi
###↑获取马达驱动目录↑###

if [ "$API" -lt 30 ]; then
ui_print ""
ui_print "-设备:$P-$V(SDK:$API)"
ui_print "-安卓版本低于11.0"
abort ""
fi
buttos() {
butto=""
while [ "$butto" = "" ]; do
butto="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
sleep 0.2
done
}
SC="system$C"
D="$M/$SC"
sp="system.prop"
msp="$M/$sp"
mde="$M/module.prop"
dam="data/adb/modules"
instdir="$dam/$MODID"
vibmod="/$dam/*/$SC"
ime="`grep_prop sys.haptic.keyboard $defprop`"
NAME="`grep_prop name $mde`"
AUT="`grep_prop author $mde`"
VER="`grep_prop version $mde`"
VC="`grep_prop versionCode $mde`"
ui_print "　　　　　　　　　!风险提示!"
ui_print "-个别机型可能有(功耗/振动异常/无振动等)玄学问题."
ui_print "-建议搜索专版模块,或单独用Miui Extra映射震动."
if [[ $V == *816*.*.* ]]; then
ui_print ""
ui_print "-HyperOS改动较大! 部分场景可能不生效,自行测试."
ui_print ""
sleep 0.5
fi
ui_print "-模块非万能，玄学问题概不负责，是否继续?"
sleep 0.2
ui_print "　　　　　　音量↑:安装│音量↓:取消"
buttos
case "$butto" in
"KEY_VOLUMEUP")
ui_print "　　　　　　 ✓✓"
. $F/*　
;;
*)
abort "　　　　　　　　　　　　　　✓✓"
esac
