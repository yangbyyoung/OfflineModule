# GLTools

This is a GLTools module for installation via Magisk.
If it bootloops for some unknown reason, uninstallation should be done manually, via your custom recovery.
