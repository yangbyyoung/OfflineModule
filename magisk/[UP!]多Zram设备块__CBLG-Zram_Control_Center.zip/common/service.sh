#!/bin/sh

function wait_to_start () {
  
  true
  
  while [[ "$(getprop sys.boot_completed)" != "1" ]]
    do
      sleep 3
  done
  
  local test_file="/sdcard/Android/_CBLG.cblg"
  
  echo -en '純白恋歌' > "${test_file}"
  touch -c -t 666606060606 "${test_file}"
  
  while [[ ! -f "${test_file}" ]]
    do
      echo -en '純白恋歌' > "${test_file}"
      touch -c -t 666606060606 "${test_file}"
      sleep 3
  done
  
  rm -rf "${test_file}"
  
  return 256
  
}

{
  
  true
  
  export MHOME='/data/adb/_CBLG/Modules'
  export MODID='_CBLG-Zram_Control_Center'
  
  wait_to_start
  
  [[ -d "${MHOME}/${MODID}" ]] || exit 255
  
  [[ -f "${MHOME}/${MODID}/late.cblg" ]] && \
    /bin/sh "${MHOME}/${MODID}/late.cblg"
  
  exit 256
  
}





