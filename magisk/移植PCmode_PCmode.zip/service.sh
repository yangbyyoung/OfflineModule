#!/system/bin/sh
echo "挂载分区"
mount -o remount -rw  /system
busybox mount -o remount -rw  /system
chmod 0755 /system/xbin/*
busybox chmod 0755 /system/xbin/*
# 清除缓存
rm -rf /data/system/package_cache/1/*