# SystemUI-Patcher
Based on  systemUI patcher mod used for injecting Xmls to SystemUI on Aosp A11+, Systemlessly. 

Module Template by @Jai_08

By @cool_modules on telegram 

Feel free to use, modify, distribute as long as a part of credit is present.

Aosp / Oneui roms can use this

For A11+ only

This mod will patch your SystemUI with xmls which you place under the folder substratumXML

Just flash in magisk and reboot.

Features-
Quick Installation
Small size
Supports custom Functions
Multiple Modules work together without issues

How to use multiple mods together?

-Flash any 1 module 
-Reboot
-Flash another
Both will merge automatically and work together

Alternatively you can merge manually by adding all xml into substratumXML folder

Edit module prop and enter you module id name and description accordingly. 

If any issue reach out to me on @cool_modules69 telegram


This is modified version 
Download and uae the orignal template from here -

https://github.com/jairaj08/SystemUI-Patcher