MODDIR="$1"

# 微信清理无用垃圾（不包含聊天记录），我自己改的，你用我这一套还得先问问我呢！
echo "-----------------------"
echo "微信清理脚本 20210628"
echo "适用于7.0.15以前的版本，没有修改缓存路径的版本就是15以前的版本，从15以后就换路径了，本人用的7.0.3"
echo "-----------------------"
echo ""
echo "-开始处理根目录文件-"
echo "日志文件"
sleep 1
rm -rf /data/data/com.tencent.mm/files/xlog/
rm -rf /data/data/com.tencent.mm/files/live_log/
rm -rf /data/data/com.tencent.mm/files/com.tencent.mm:tools/logging_cache/
rm -rf /data/data/com.tencent.mm/files/webnet/cacheinfo/
rm -rf /data/data/com.tencent.mm/app_appcache/
rm -rf /data/data/com.tencent.mm/cache/
echo "主缓存"
rm -rf /data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
rm -rf /data/data/com.tencent.mm/cache/
sleep 1
echo "插件"
rm -rf /data/data/com.tencent.mm/app_xwalk_[0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z]/
rm -rf /data/data/com.tencent.mm/app_xwalkplugin/
##rm -rf /data/data/com.tencent.mm/files/host/
echo "视频缓存"
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/cache
echo "谷歌不带x5内核，但是也有view缓存"
rm -rf /data/data/com.tencent.mm/app_webview/GPUCache/
echo "TBS插件"
rm -rf /data/data/com.tencent.mm/app_tbs/
echo "直播"
sleep 1
rm -rf /data/data/com.tencent.mm/files/public/live/
rm -rf /data/data/com.tencent.mm/files/public/fts/
rm -rf /data/data/com.tencent.mm/files/public/OCR
rm -rf /data/data/com.tencent.mm/files/public/cityService/
rm -rf /data/data/com.tencent.mm/files/public/tagsearch/
rm -rf /data/data/com.tencent.mm/files/public/box/
rm -rf /data/data/com.tencent.mm/files/public/CheckResUpdate/
rm -rf /data/data/com.tencent.mm/files/public/websearch/

echo "开始处理内部存储目录文件"
rm -rf /storage/emulated/0/tencent/micromsg/xlog/
echo "------------------"
echo "大美制作 酷安@孤Lrkc   21.04.04"
echo "转发修改请保留原作者信息 谢啦๑ᵔ⌔ᵔ๑"
echo "改成了老版本的目录，精准妲己！！"
echo "酷安@嫖丶总"
# 微信清理无用垃圾（不包含聊天记录）