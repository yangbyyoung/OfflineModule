SKIPMOUNT=false
info_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
info_source $MODPATH/info.sh
set_perm_recursive  $MODPATH  0  0  0755  0644
set_perm_recursive  $MODPATH/bin  0  0  0755  0777
