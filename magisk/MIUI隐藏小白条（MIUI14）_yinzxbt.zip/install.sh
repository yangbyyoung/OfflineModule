SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
  ui_print "*******************************"
  ui_print "   Magisk Module:          "
  ui_print "   MiUI14小白条沉浸         "
  ui_print "   米皇太子                 "
  ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'system/product/overlay/SystemUi.apk' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}
moduleInfo() {
    AUTHOR=$(grep_prop author $TMPDIR/module.prop)
    ui_print "*********************************************"
    ui_print "                                             "
    ui_print "   ${AUTHOR} "
    ui_print "   酷安：米皇太子   "
    ui_print "                                             "
    ui_print "*********************************************"
}

moduleInfo

CommonPath=$MODPATH/common
if [ ! -d "${CommonPath}" ]; then
    ui_print "模块高级设置不需要修复!"
elif [ -z "$(ls -A "${CommonPath}")" ]; then
    ui_print "模块高级设置为空!"
    rm -rf "${CommonPath}"
else
    ui_print "- 正在进行模块高级设置"
    mv "${CommonPath}/"* "$MODPATH"
    rm -rf "${CommonPath}"
fi

sleep 5

ui_print "*********************************************"
ui_print "                                             "
ui_print "恭喜！安装已圆满完成，请重启您的设备以生效！ "
ui_print "                                             "
ui_print "*********************************************"
