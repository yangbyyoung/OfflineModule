#!/system/bin/sh
MODDIR=${0%/*}
mount --bind $MODDIR/my_product/media/bootanimation/bootanimation.zip /my_product/media/bootanimation/bootanimation.zip
mount --bind $MODDIR/my_product/media/bootanimation/rbootanimation.zip /my_product/media/bootanimation/rbootanimation.zip
