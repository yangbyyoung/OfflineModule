app='
com.tencent.mobileqq
com.tencent.mm
'

for i in $app;do
magiskhide rm $i 2>/dev/null
done