##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "警告：请在完整包更新重启前刷本模块，模块已集成指纹修复"
  ui_print "*******************************"
  ui_print " ******机型：RMX2202******"
  ui_print " 功能：安装新系统后保留ROOT"
  ui_print "*******************************"
  ui_print " **********作者：秋水*********"
  ui_print " ******QQ：1239120048******"
  ui_print "*******************************"
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
# rm -rf /data/adb/modules_update
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "脚本执行中，请耐心等待！!!"
  cd  $MODPATH
  mkdir tmp
  mkdir backup
  set_perm_recursive   $MODPATH/tmp  0  0  0777  0777
  set_perm_recursive   $MODPATH/backup  0  0  0777  0777
  
SLOT=`cat /proc/cmdline | tr '[:space:]' '\n' | sed -rn 's/androidboot.slot.{0,7}=//p'`
  
  if [ $SLOT == '_a' ] ;then
      SLOT0="_b"
     else
      SLOT0="_a"
  fi
  
ui_print "- 当前使用的槽位：$SLOT 目标槽位：$SLOT0"  

BIMG="/dev/block/by-name/boot$SLOT0" 
VBIMG="/dev/block/by-name/vendor_boot$SLOT0" 
VBMETA="/dev/block/by-name/vbmeta$SLOT" 
VBMETA0="/dev/block/by-name/vbmeta$SLOT0"  

    ui_print "- 目标分区$BIMG"
    
    ui_print "- 目标分区$VBIMG"
    ui_print "- 目标分区$VBMETA0"
    
    
    ui_print "- 正在备份boot,vendor_boot,vbmeta分区"
    cd $MODPATH/backup
    dd if="$BIMG" of=boot.img
    dd if="$VBIMG" of=vendor_boot.img
    dd if="$VBMETA0" of=vbmeta.img
    
    ui_print "******关闭vbmeta验证成功******"
    dd if="$VBMETA" of="$VBMETA0"
    
/data/adb/magisk/boot_patch.sh $BIMG
    dd if=/data/adb/magisk/new-boot.img of="$BIMG"
    ui_print "******补丁boot成功******"
    rm /data/adb/magisk/new-boot.img
    rm /data/adb/magisk/kernel
    rm /data/adb/magisk/ramdisk.cpio
    
    cd $MODPATH/tmp
    /data/adb/magisk/magiskboot unpack $VBIMG
    /data/adb/magisk/magiskboot cpio ramdisk.cpio extract
    sed -i "s/,avb_keys=\/vendor\/etc\/oplus_avb.pubkey//g" first_stage_ramdisk/oplus.fstab
    /data/adb/magisk/magiskboot cpio ramdisk.cpio "add 0644 first_stage_ramdisk/oplus.fstab  first_stage_ramdisk/oplus.fstab"
    /data/adb/magisk/magiskboot repack $VBIMG vb.img
    dd if=vb.img of="$VBIMG"
   ui_print "******补丁vendor_boot成功******"
   
  rm -rf  $MODPATH/tmp
   ui_print "！！！ROOT刷入成功！你现在可以重启了！！！"
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH/system 0 0 0755 0644
  chmod -R 755 $MODPATH

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code
