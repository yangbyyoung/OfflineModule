SKIPUNZIP=0
check_magisk_version()
{
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "*********************************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "*********************************************************"
	fi
}
check_magisk_version
ui_print "*********************************************************"
ui_print "关闭ZRAM模块建议在物理内存12GB及以上设备使用"
ui_print "本机$(cat /proc/meminfo | grep MemTotal)"
ui_print "*********************************************************"
set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod a+x $MODPATH/*.sh