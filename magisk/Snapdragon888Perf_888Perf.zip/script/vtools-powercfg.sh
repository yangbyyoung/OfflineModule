#! /vendor/bin/sh
# Uperf https://github.com/yc9559/uperf/
# Author: Matt Yang

# powercfg wrapper for com.omarea.vtools
# MAKE SURE THAT THE MAGISK MODULE "Uperf" HAS BEEN INSTALLED
