#!/system/bin/sh
action=$1
#CuprumTurbo Adjustment powercfg for scene.
if [ "$action" = "powersave" ] ; then
 echo "powersave" > /data/Cuprum_Custom/mode
elif [ "$action" = "balance" ] ; then
 echo "balance" > /data/Cuprum_Custom/mode
elif [ "$action" = "performance" ] ; then
 echo "performance" > /data/Cuprum_Custom/mode
elif [ "$action" = "fast" ] ; then
 #Performance take the place of Fast.
 #I won't add Fast mode to the Adjustment,Performance is enough.
 echo "performance" > /data/Cuprum_Custom/mode
fi
exit 0