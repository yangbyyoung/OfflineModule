#!/system/bin/sh

{
	until [[ "$(getprop sys.boot_completed)" == "1" ]]; 
	do
		sleep 1
	done
	settings put global hide_gesture_line 1
}&