DUBUG_FLAG=false

PROPFILE=false

POSTFSDATA=false

LATESTARTSERVICE=false

var_device="`getprop ro.product.board`"
var_version="`grep_prop ro.*build.version.incremental`"

print_modname() {
  ui_print "******************************"
  ui_print " $MODNAME "
  ui_print "******************************"
  ui_print " 作者：$MODauthor "
  ui_print " 介绍：$MODdescription "
  ui_print "******************************"
}

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}
