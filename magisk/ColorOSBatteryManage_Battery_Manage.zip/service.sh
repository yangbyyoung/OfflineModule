#!/system/bin/sh
#官宣粉丝交流群：938499734
#ColorOS玩机交流群：872254795
#禁止商用*转载请获取作者许可
MODDIR=${0%/*}
vooc1=$(sed '/^线路1=/!d;s/.*=//' $MODDIR/线程.php)
vooc2=$(sed '/^线路2=/!d;s/.*=//' $MODDIR/线程.php)
vooc3=$(sed '/^线路3=/!d;s/.*=//' $MODDIR/线程.php)
vooc4=$(sed '/^线路4=/!d;s/.*=//' $MODDIR/线程.php)
if [[ $vooc1 == "Y" ]];then
chmod 777 -R $MODDIR/vooc
$MODDIR/vooc
elif [[ $vooc2 == "Y" ]];then
chmod 777 -R $MODDIR/vooc2
$MODDIR/vooc2
fi
if [[ $vooc3 == "Y" ]];then
chmod 777 -R $MODDIR/vooc3
$MODDIR/vooc3
elif [[ $vooc4 == "Y" ]];then
chmod 777 -R $MODDIR/c11
$MODDIR/c11
fi
