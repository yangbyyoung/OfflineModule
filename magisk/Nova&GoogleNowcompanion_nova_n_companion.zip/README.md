<p align="center">
<b> Nova & GoogleNow </b><br>
</p>

## Module Explanation:

A very simple module just to make NovaLauncher with GoogleNow work as a rom-integrated app systemlessly. It'll simply inject two folders with the apks into the path: /system/priv-app.
I made it because i faced some issues with getting notifications from google app (like weather). Moving launcher & companion to the system directory solved that issue for me.
* Note: You won't get any premium(prime) functions! If you want the app to fully work, buy the "Nova Prime" extension on Play Market!

## Requirements: 
- Android 5.0+ (Magisk requirement).
- Magisk v15/16+ .

# Credits:
* Nova Developer (© All rights reserved) - I'm not the dev of the app.
* Magisk Developer - [Topjohnwu](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445 "Magisk official XDA thread").

## Third party code used:
* [Module Template](https://github.com/topjohnwu/magisk-module-template "Template's repository").

## Usefull links & Addons
* NovaLauncher - [Play Market](https://play.google.com/store/apps/details?id=com.teslacoilsw.launcher)
* NovaLauncher FAQ: [Official website](https://help.teslacoilapps.com/faq)
* NovaPrime extenstion - [Play Market](https://play.google.com/store/apps/details?id=com.teslacoilsw.launcher.prime)
* Tesla Unread - Notifications addon for Nova - [Play Market](https://play.google.com/store/apps/details?id=com.teslacoilsw.notifier)
* Sesame shortcuts - [Play Market](https://play.google.com/store/apps/details?id=ninja.sesame.app.edge)
