rm -rf /data/system/package_cache/*
rm -rf /data/adb/modules_update/CameraLib
rm -rf /data/adb/modules/CameraLib