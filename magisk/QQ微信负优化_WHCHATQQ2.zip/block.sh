#!/system/bin/sh
disable_modules_name="
clear_QQ_MM_trash_key
WHCHATQQ
"

for i in $disable_modules_name
do
ls -d /data/adb/modules/${i} /data/adb/lite_modules/${i} 2>/dev/null | while read modules ;do
touch "${modules}/disable"
sh "${modules}/uninstall.sh" & 2>/dev/null
done
done
