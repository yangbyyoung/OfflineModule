MODDIR="$1"

#---以下代码不属于任何人，太简单了，写也是贴金，欢迎作者前来认领，看看谁不要脸---
# 清理MIUI系统日志
rm -rf /data/vendor/charge_logger/
#清理MIUI桌面日志
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 
#清理Wifi_logs日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
#清理mi-rcs日志
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService