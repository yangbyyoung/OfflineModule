	#init
	function check_fs(){
		data=`find -L /dev/block/mapper/ -iname 'userdata' | head -1`
		temp=`ls -al $data`
		userdata="${temp##*/}"
		if [ -d /sys/fs/f2fs/$userdata ] ; then
			echo " >>> DATA分区号：$userdata (已加密) "
			echo " >>> F2FS接口：/sys/fs/f2fs/$userdata "
		else
			data=`find -L /dev/block/ -iname 'userdata' | head -1`
			temp=`ls -al $data`
			userdata="${temp##*/}"
			if  [ -d /sys/fs/f2fs/$userdata ] ; then
				echo " >>> DATA分区号：$userdata (未加密) "
				echo " >>> F2FS接口：/sys/fs/f2fs/$userdata "
			else
				data_numsda=`echo "$userdata" | tr -cd "dm-"`
				data_numdm=`echo "$userdata" | tr -cd "sd"`
				if [ "$data_numsda" != "dm-" ] ; then
					if [ "$data_numdm" != "sd" ] ; then
					echo " >>> ERROR！无法获取到DATA的分区号！"
					sleep 0.2
					echo " ------ 取消安装 "
					exit 1
					fi
				fi
				echo " >>> ERROR！未找到DATA的F2FS接口！"
				sleep 0.2
				echo " ------ 取消安装 "
				exit 1
			fi
		fi
		echo "$userdata" > $MODPATH/datafile/userdata_num
	}

	function testapi(){
		sleep 0.2
		if [ $2 ] ; then
			echo " >>> 接口: $1 --------- OK"
		else
			echo " >>> 接口: $1 --------- ERROR！"
			echo " >>> 请检查$3 "
			apiloss=$(($apiloss + 1))
		fi
	}

	function get_value(){
		cp_interval=`cat "/sys/fs/f2fs/$userdata/cp_interval"`
		dirty_nats_ratio=`cat "/sys/fs/f2fs/$userdata/dirty_nats_ratio"`
		discard_idle_interval=`cat "/sys/fs/f2fs/$userdata/discard_idle_interval"`
		gc_booster=`cat "/sys/fs/f2fs/$userdata/gc_booster"`
		gc_idle=`cat "/sys/fs/f2fs/$userdata/gc_idle"`
		gc_idle_interval=`cat "/sys/fs/f2fs/$userdata/gc_idle_interval"`
		gc_max_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_max_sleep_time"`
		gc_min_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_min_sleep_time"`
		gc_no_gc_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_no_gc_sleep_time"`
		gc_urgent=`cat "/sys/fs/f2fs/$userdata/gc_urgent"`
		gc_urgent_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_urgent_sleep_time"`
		gc_urgent_high_remaining=`cat "/sys/fs/f2fs/$userdata/gc_urgent_high_remaining"`
		unusable=`cat "/sys/fs/f2fs/$userdata/unusable"`
		idle_interval=`cat "/sys/fs/f2fs/$userdata/idle_interval"`
		ram_thresh=`cat "/sys/fs/f2fs/$userdata/ram_thresh"`
		free_segments=`cat "/sys/fs/f2fs/$userdata/free_segments"`
	}

	function check_f2fs(){
		get_value
		[[ "$cp_interval" == "" ]] && warning cp_interval
		[[ "$dirty_nats_ratio" == "" ]] && warning dirty_nats_ratio
		[[ "$discard_idle_interval" == "" ]] && warning discard_idle_interval
		[[ "$gc_booster" == "" ]] && warning gc_booster
		[[ "$gc_idle" == "" ]] && warning gc_idle
		[[ "$gc_idle_interval" == "" ]] && warning gc_idle_interval
		[[ "$gc_min_sleep_time" == "" ]] && warning gc_min_sleep_time
		[[ "$gc_max_sleep_time" == "" ]] && warning gc_max_sleep_time
		[[ "$gc_no_gc_sleep_time" == "" ]] && warning gc_no_gc_sleep_time
		[[ "$gc_urgent" == "" ]] && err gc_urgent
		[[ "$gc_urgent_sleep_time" == "" ]] && err gc_urgent_sleep_time
		[[ "$gc_urgent_high_remaining" == "" ]] && warning gc_urgent_high_remaining
		[[ "$unusable" == "" ]] && err unusable
		[[ "$idle_interval" == "" ]] && warning idle_interval
		[[ "$ram_thresh" == "" ]] && warning ram_thresh
		[[ "$free_segments" == "" ]] && warning free_segments
		if [ "$warn_flag" == "1" ] ; then
			echo " >>> 可能会对GC回收及日志输出产生影响"
			echo " >>> 模块仍会安装，如果无效果请卸载模块 "
		fi
	}

	function err(){
		echo " >>> ERROR！F2FS态<$1>未找到！"
		sleep 0.2
		main_bak
	}
	
	function warning(){
		echo " >>> WARNING！F2FS态<$1>未找到！"
		warn_flag=1
		sleep 0.2
	}
	
	function cpud(){
		out=$(echo "scale=2; $1/$2" | bc)
		echo $out
		return $?
	}

	function chk_df(){
		diskfree=$(/bin/df /data | grep -w block | awk '{print $2,$3,$4}')
		diskfree=$(echo $diskfree | awk '{print $3}')
		if [ "$diskfree" == "" ] ; then
			echo " >>> ERROR！<df>命令不可用！"
			sleep 0.2
			main_bak
		fi
		if [ "$diskfree" -ge "1000" ] ; then
			out=$(echo "scale=2; $diskfree/1000" | bc)
			if [ "$diskfree" -ge "1000000" ] ; then
				out=$(echo "scale=2; $diskfree/1000000" | bc)
				echo " >>> DATA剩余空间: $out GB "
			else
				echo " >>> DATA剩余空间: $out MB "
			fi
		else
			echo " >>> DATA剩余空间: $out KB "
		fi
	}
	
	function check_gclog(){
		unusable=`cat "/sys/fs/f2fs/$userdata/unusable"`
		free_segments=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		if [ "$unusable" == "" -o "$free_segments" == "" ] ; then
			echo " >>> GC日志级别: 精简 "
			echo "S" > $MODPATH/datafile/gc_log
		else
			echo " >>> GC日志级别: 完整 "
			echo "C" > $MODPATH/datafile/gc_log
		fi
	}

	function d_rate(){
		if [ -e /d/f2fs/status ] ; then
			drate=$(cat /d/f2fs/status | grep -A130 "$userdata" | grep -w BDF | awk '{print $2}')
		else
			drate=$(cat /proc/fs/f2fs/status | grep -A130 "$userdata" | grep -w BDF | awk '{print $2}')
		fi
		drate=`echo $drate | tr -cd "[0-9]"`
		drate=$((100 - $drate))
		if [ "$drate" -le "0" ] ; then
			echo " >>> ERROR！DATA碎片信息异常！"
			sleep 0.2
			echo " ------ 取消安装 "
			$restore_se
			exit 1
		fi
		echo " >>> DATA碎片率: $drate % "
		sed -i "s/\[.*\]/\[ 已TRIM 0 次，已GC 0 次，碎片率: $drate % \]/g" "$MODPATH/datafile/module.prop"
	}

	function main_bak(){
	    ui_print " > "
	    sleep 1
		ui_print " ------ 主逻辑运行环境缺失，尝试备用逻辑 "
		sleep 0.3
		ui_print " > "
		sleep 0.3
		apiloss=0
		testapi "info_f2fs" "-e /d/f2fs/status -o -e /proc/fs/f2fs/status" "/d/f2fs/status或/proc/fs/f2fs/status是否存在"
		if [ "$apiloss" -ge "1" ] ; then
			echo " ------ 信息节点缺失，模块不支持当前内核！"
			sleep 0.2
			echo " ------ 取消安装 "
			exit 1
		fi
		sleep 0.5
		d_rate
		sleep 0.5
		check_gclog
		sleep 1
		rm -rf /sdcard/Android/fsopt
		mkdir /sdcard/Android/fsopt
		chmod 0755 $MODPATH/main.sh
		chmod 0755 $MODPATH/bin/busybox
		chmod 0755 $MODPATH/bin/f2fs-fggc
		mv $MODPATH/datafile/module.prop $MODPATH/
		mv $MODPATH/datafile/service.sh $MODPATH/
		chmod 0644 $MODPATH/module.prop
		chmod 0644 $MODPATH/service.sh
		sleep 0.2
		ui_print " > "
		sleep 0.5
		ui_print " ------ 安装已完成，请重启！"
		exit 0
	}

#install
ui_print " ------ FSOPT for Magisk/KSU"
sleep 0.5
ui_print " ------ 检测基础环境 "
sleep 0.3
check_fs
apiloss=0
testapi "set_wake_lock" "-e /sys/power/wake_lock -a -e /sys/power/wake_unlock" "/sys/power/wake_lock和wake_unlock是否存在"
testapi "info_cpuload" "-e /proc/stat" "/proc/stat是否存在"
testapi "info_screen" "`dumpsys deviceidle | grep mScreenOn` == mScreenOn=true" " dumpsys deviceidle | grep mScreenOn 命令是否可用"
testapi "info_battery" "-e /sys/class/power_supply/battery/capacity -a -e /sys/class/power_supply/battery/status" "/sys/class/power_supply/battery/capacity和status是否存在"
if [ "$apiloss" -ge "1" ] ; then
	echo " ------ $apiloss 个接口不可用！"
	sleep 0.2
	echo " ------ 取消安装 "
	exit 1
fi
sleep 0.5
chk_df
sleep 0.5
echo " ------ 检查F2FS_GC功能 "
sleep 1
check_f2fs
rm -rf /sdcard/Android/fsopt
mkdir /sdcard/Android/fsopt
chmod 0755 $MODPATH/main.sh
chmod 0755 $MODPATH/bin/busybox
sleep 0.2
ui_print " > "
sleep 0.5
ui_print " ------ 安装已完成，请重启！"
exit 0
