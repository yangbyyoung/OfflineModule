#!/system/bin/sh
until [[ $supercharge == true ]]; do
chmod 777 /sys/class/power_supply/battery/fast_charge_current
chmod 777 /sys/class/power_supply/battery/thermal_input_current
chmod 777 /sys/class/power_supply/battery/input_suspend
chmod 777 /sys/class/power_supply/battery/battery_charging_enabled
echo 0 > /sys/class/power_supply/battery/input_suspend
echo 1 > /sys/class/power_supply/battery/battery_charging_enabled
echo 6000000 > /sys/class/power_supply/battery/fast_charge_current
echo 6000000 > /sys/class/power_supply/battery/thermal_input_current
sleep 3s
done