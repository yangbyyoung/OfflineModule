export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

MODDIR=${0%/*}

#清除日志
function limitlog(){  
local logfile=$1  
local maxsize=$((1024*100)) 
filesize=`ls -l $logfile | awk '{ print $5 }'`
if [ $filesize -gt $maxsize ];then
echo " " > $logfile
fi
}

cd $MODDIR/log
for i in $(ls);do
limitlog "$i"
done
