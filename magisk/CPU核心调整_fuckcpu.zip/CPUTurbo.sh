config_file="/data/adb/modules/fuckcpu/config.txt"
if [ -f "$config_file" ]; then
    config=$(cat "$config_file")
fi

cpu_turbo() {
    if [ "$config" = "省电" ]; then
        # 关闭全部小核
        echo 0 > /sys/devices/system/cpu/cpu1/online
        echo 0 > /sys/devices/system/cpu/cpu2/online
        echo 0 > /sys/devices/system/cpu/cpu3/online
    elif [ "$config" = "性能" ]; then
        # 启用所有CPU核心
        echo 1 > /sys/devices/system/cpu/cpu0/online
        echo 1 > /sys/devices/system/cpu/cpu1/online
        echo 1 > /sys/devices/system/cpu/cpu2/online
        echo 1 > /sys/devices/system/cpu/cpu3/online
        echo 1 > /sys/devices/system/cpu/cpu4/online
        echo 1 > /sys/devices/system/cpu/cpu5/online
        echo 1 > /sys/devices/system/cpu/cpu6/online
        echo 1 > /sys/devices/system/cpu/cpu7/online
    fi
}
cpu_turbo # 调用 cpu_turbo 函数