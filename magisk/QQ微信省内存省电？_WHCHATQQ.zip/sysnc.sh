MODSYSNCDIR="/data/adb/modules/WHCHATQQ"
MODSYSNCDIR2="/data/adb/lite_modules/WHCHATQQ"
test -e $MODSYSNCDIR2 -a "$Magisk_mod" = "lite_modules" && MODSYSNCDIR=$MODSYSNCDIR2

symbol=" AK BK CK DK"

for i in $symbol;do
	if test -e $MODSYSNCDIR/keymod/$i ;then
		touch $MODPATH/keymod/$i
	fi
done

cp -rf $MODPATH/* $MODSYSNCDIR


