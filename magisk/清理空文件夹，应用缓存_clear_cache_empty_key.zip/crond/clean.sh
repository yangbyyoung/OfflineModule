#!/system/bin/sh

mkdir -p ${MODPATH}/log

test "$MODPATH" = "" && exit


local IFS=$'\n'

clean_config_file="${MODPATH}/clear.prop"
log_file="${MODPATH}/log/clean.log"



function clearad(){
case "${1}" in
"/data/user/"|"/data/user"|"/data/media/0/Android/data/"|"/data/media/0/Android/data"|"/data/data/"|"/data/data"|"/data"|"/data/"|"/data/media/0"|"/data/media/0/"|"/data/media/0/Downloa"|"/data/media/0/Download/"|"/data/media/0/Android"|"/data/media/0/Android/"|"/sdcard"|"/sdcard/"|"/sdcard/Download"|"/sdcard/Download/"|"/sdcard/Android"|"/sdcard/Android/"|"/storage"|"/storage/"|"/storage/emulated/0"|"/storage/emulated/0/"|"/storage/emulated/0/Download"|"/storage/emulated/0/Download/"|"/storage/emulated/0/Android"|"/storage/emulated/0/Android/"|"/"|"/*")
echo "你他娘的真是个人才！想把系统给格了？™"
echo "\n[E]`date '+%F %T'` 你他娘的真是个人才！想把系统给格了？™\n[E]`date '+%F %T'`错误的路径: ${1} \n" > "${log_file}"
update_module_information "[E]`date '+%F %T'` 你他娘的真是个人才！想把系统给格了？请检查配置文件: ${clean_config_file} ！"
notification_simulation "[E]`date '+%F %T'` 你他娘的真是个人才！想把系统给格了？请检查配置文件: ${clean_config_file} ！"
exit 1
;;
*)
	if test -e "${1}" ;then
		rm -rf "${1}"
		echo "[I]`date '+%F %T'` 删除 ${1}" >> "${log_file}"
	fi
;;
esac
}

function clearad2(){
for i in `cat "${clean_config_file}" | sed '/^#/d;/^[[:space:]]*$/d' `
do 
	clearad "${i}" 2> /dev/null 
done
}

function update_module_information(){
local target_file="$MODPATH/module.prop"
local backup_file="$MODPATH/backup.prop"
if test -f "${backup_file}" ;then
	cp -rf "${backup_file}" "${target_file}"
	sed -i "/^description=/c description=`date +'%F %T'` ${1} 。配置文件全在模块目录(notclear.conf和clear.prop)，模块目录:${MODPATH}。" "${target_file}"
fi
}

function sort_uniq_log(){
local new=`cat "${log_file}" | sort | uniq `
echo "${new}" > "${log_file}"
}

function limitlog() {
	local logfile=${1}
	local maxsize=$((1024 * 1000))
	filesize=$(ls -l ${logfile} | awk '{ print $5 }')
	if test ${filesize} -gt ${maxsize}; then
		echo "[I]`date '+%F %T'` 日志达到上限，已经清空！" > ${logfile}
	fi
}

function notification_simulation(){
local title="${2}"
local text="${1}"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
	test -z "${title}" && title='10007'
	test -z "${text}" && text='您未给出任何信息'
su -lp 2000 -c "cmd notification post -S messaging --conversation '${title}' --message '${title}':'${text}' 'Tag' '$(echo $RANDOM)' " >/dev/null 2>&1
}


if test "$(dumpsys deviceidle get screen)" = "true" ;then
	clearad2
	limitlog "${log_file}"
fi

a=$(cat $MODPATH/log/emptydir.log 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)
b=$(cat ${log_file} 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)
c=$(cat $MODPATH/log/cachedir.log 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)

update_module_information "共清理空文件夹"${a}"个，"${c}"个应用缓存文件夹，"${b}"个垃圾文件"
