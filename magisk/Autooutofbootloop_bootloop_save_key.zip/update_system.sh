#!/system/bin/sh

source "${0%/*}/util_functions.sh"

function update_system(){
file="$MODPATH/version"
test ! -e "$file" && change_description "你他娘的怎么给我搞不见了？" "Oops, the file is missing!" && {
echo "false"
return 0
}
old="$(cat $file)"
now="$(getprop ro.system.build.version.incremental)"
if test "$old" = "$now" ;then 
	result="false"
else
	result="true"
	echo "$now" > "$file"
fi
echo "$result"
}


if $(update_system) ;then

#写入日志
change_description "[I]升级系统中！" "Upgrading the system!" "false" "true"

#等待启动时间
sleep 15m

#音量键救砖
if test "$(show_value "音量键救砖")" != "禁用" ;then 
	source "${0%/*}/volume_save.sh" &
fi

#查找zygote
source "${0%/*}/find_zygote.sh" &

#自动救砖
	if test "$(show_value "自动禁用时间")" != "禁用" ;then 
		source "${0%/*}/boot_toolate.sh" &
	fi
else
#音量键救砖
if test "$(show_value "音量键救砖")" != "禁用" ;then 
	source "${0%/*}/volume_save.sh" &
fi

#查找zygote
source "${0%/*}/find_zygote.sh" &

#自动救砖
	if test "$(show_value "自动禁用时间")" != "禁用" ;then 
		source "${0%/*}/boot_toolate.sh" &
	fi
fi


