#!/system/bin/sh


MODDIR=${0%/*}


chmod -R 0777 $MODDIR/*

echo "依
Yi" > $MODDIR/Ling_Yi

dd if=$MODDIR/Ling_Yi of=$MODDIR/thermald
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.thermald.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_core
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_intf
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.thermal_core.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/disable_thermal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/disable_thermal_temp.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/disable_skin_control.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/disable_throttling.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_mtbf.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_00.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_01.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_02.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_03.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_08.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_policy_09.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_hal.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_trace.ko
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_interface.ko
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-generic-adc.ko
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_hal.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/libthermalalgo.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mt6893.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.thermal.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.thermal_manager.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.thermalloadalgod.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mt6893.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/libthermalalgo.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-chg-only.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal_manager
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermalloadalgod
dd if=$MODDIR/Ling_Yi of=$MODDIR/libthermalclient.qti.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/libthermalclient.qti.so
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-4k.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-arvr.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-camera.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-chg-only.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-class0.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-class0.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-camera.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-mgame.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-navigation.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-per-class0.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-per-normal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-per-video.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-video.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-map.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-map-india.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-nolimits.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-per-camera.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-normal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-per-navigation.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-per-normal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.current.ini
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.level1.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.level2.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.level4.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.low.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.low.level1.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.low.level2.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mid.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mid.level1.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.sgame.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermald-devices.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-engine.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-nolimits.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-normal.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-phone.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-india-tgame.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-mgame.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-navigation.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-per-class0.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-per-video.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-phone.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-region-map.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-tgame.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-video.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.benchmark.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.level3.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.high.level5.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mid.level2.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mid.level3.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.mid.level4.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal.super.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/mi_thermald
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-engine
dd if=$MODDIR/Ling_Yi of=$MODDIR/init.mi_thermald.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/init_thermal-engine.rc
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermalboost.conf
dd if=$MODDIR/Ling_Yi of=$MODDIR/thermal-engine.conf

mount --bind $MODDIR/thermal-engine.conf /system/vendor/etc/thermal-engine.conf
mount --bind $MODDIR/thermalboost.conf /system/vendor/etc/perf/thermalboost.conf
mount --bind $MODDIR/init_thermal-engine.rc /system/vendor/etc/init/init_thermal-engine.rc
mount --bind $MODDIR/init.mi_thermald.rc /system/vendor/etc/init/init.mi_thermald.rc
mount --bind $MODDIR/thermal-engine /system/vendor/bin/thermal-engine
mount --bind $MODDIR/mi_thermald /system/vendor/bin/mi_thermald
mount --bind $MODDIR/thermal-tgame.conf /system/vendor/etc/thermal-tgame.conf
mount --bind $MODDIR/thermal.super.conf /system/vendor/etc/thermal.super.conf
mount --bind $MODDIR/thermal.mid.level4.conf /system/vendor/etc/thermal.mid.level4.conf
mount --bind $MODDIR/thermal.mid.level3.conf /system/vendor/etc/thermal.mid.level3.conf
mount --bind $MODDIR/thermal.mid.level2.conf /system/vendor/etc/thermal.mid.level2.conf
mount --bind $MODDIR/thermal.high.level5.conf /system/vendor/etc/thermal.high.level5.conf
mount --bind $MODDIR/thermal.high.level3.conf /system/vendor/etc/thermal.high.level3.conf
mount --bind $MODDIR/thermal.high.conf /system/vendor/etc/thermal.high.conf
mount --bind $MODDIR/thermal.benchmark.conf /system/vendor/etc/thermal.benchmark.conf
mount --bind $MODDIR/thermal-video.conf /system/vendor/etc/thermal-video.conf
mount --bind $MODDIR/thermal-region-map.conf /system/vendor/etc/thermal-region-map.conf
mount --bind $MODDIR/thermal-phone.conf /system/vendor/etc/thermal-phone.conf
mount --bind $MODDIR/thermal-per-video.conf /system/vendor/etc/thermal-per-video.conf
mount --bind $MODDIR/thermal-per-class0.conf /system/vendor/etc/thermal-per-class0.conf
mount --bind $MODDIR/thermal-navigation.conf /system/vendor/etc/thermal-navigation.conf
mount --bind $MODDIR/thermal-mgame.conf /system/vendor/etc/thermal-mgame.conf
mount --bind $MODDIR/thermal-india-tgame.conf /system/vendor/etc/thermal-india-tgame.conf
mount --bind $MODDIR/thermal-india-phone.conf /system/vendor/etc/thermal-india-phone.conf
mount --bind $MODDIR/thermal-india-normal.conf /system/vendor/etc/thermal-india-normal.conf
mount --bind $MODDIR/thermal-india-nolimits.conf /system/vendor/etc/thermal-india-nolimits.conf
mount --bind $MODDIR/thermal-engine.conf /system/vendor/etc/thermal-engine.conf
mount --bind $MODDIR/thermald-devices.conf /system/vendor/etc/thermald-devices.conf
mount --bind $MODDIR/thermal.sgame.conf /system/vendor/etc/thermal.sgame.conf
mount --bind $MODDIR/thermal.mid.level1.conf /system/vendor/etc/thermal.mid.level1.conf
mount --bind $MODDIR/thermal.mid.conf /system/vendor/etc/thermal.mid.conf
mount --bind $MODDIR/thermal.low.level2.conf /system/vendor/etc/thermal.low.level2.conf
mount --bind $MODDIR/thermal.low.level1.conf /system/vendor/etc/thermal.low.level1.conf
mount --bind $MODDIR/thermal.low.conf /system/vendor/etc/thermal.low.conf
mount --bind $MODDIR/thermal.high.level4.conf /system/vendor/etc/thermal.high.level4.conf
mount --bind $MODDIR/thermal.high.level2.conf /system/vendor/etc/thermal.high.level2.conf
mount --bind $MODDIR/thermal.high.level1.conf /system/vendor/etc/thermal.high.level1.conf
mount --bind $MODDIR/thermal.current.ini /system/vendor/etc/thermal.current.ini
mount --bind $MODDIR/thermal-per-normal.conf /system/vendor/etc/thermal-per-normal.conf
mount --bind $MODDIR/thermal-per-navigation.conf /system/vendor/etc/thermal-per-navigation.conf
mount --bind $MODDIR/thermal-normal.conf /system/vendor/etc/thermal-normal.conf
mount --bind $MODDIR/thermal-per-camera.conf /system/vendor/etc/thermal-per-camera.conf
mount --bind $MODDIR/thermal-nolimits.conf /system/vendor/etc/thermal-nolimits.conf
mount --bind $MODDIR/thermal-map-india.conf /system/vendor/etc/thermal-map-india.conf
mount --bind $MODDIR/thermal-map.conf /system/vendor/etc/thermal-map.conf
mount --bind $MODDIR/thermal-india-video.conf /system/vendor/etc/thermal-india-video.conf
mount --bind $MODDIR/thermal-india-per-video.conf /system/vendor/etc/thermal-india-per-video.conf
mount --bind $MODDIR/thermal-india-per-normal.conf /system/vendor/etc/thermal-india-per-normal.conf
mount --bind $MODDIR/thermal-india-per-class0.conf /system/vendor/etc/thermal-india-per-class0.conf
mount --bind $MODDIR/thermal-india-navigation.conf /system/vendor/etc/thermal-india-navigation.conf
mount --bind $MODDIR/thermal-india-mgame.conf /system/vendor/etc/thermal-india-mgame.conf
mount --bind $MODDIR/thermal-india-camera.conf /system/vendor/etc/thermal-india-camera.conf
mount --bind $MODDIR/thermal-india-class0.conf /system/vendor/etc/thermal-india-class0.conf
mount --bind $MODDIR/thermal-class0.conf /system/vendor/etc/thermal-class0.conf
mount --bind $MODDIR/thermal-chg-only.conf /system/vendor/etc/thermal-chg-only.conf
mount --bind $MODDIR/thermal-camera.conf /system/vendor/etc/thermal-camera.conf
mount --bind $MODDIR/thermal-arvr.conf /system/vendor/etc/thermal-arvr.conf
mount --bind $MODDIR/thermal-4k.conf /system/vendor/etc/thermal-4k.conf
mount --bind $MODDIR/libthermalclient.qti.so /system/system_ext/lib/libthermalclient.qti.so
mount --bind $MODDIR/libthermalclient.qti.so /system/system_ext/lib64/libthermalclient.qti.so
mount --bind $MODDIR/thermald /system/bin/thermald
mount --bind $MODDIR/init.thermald.rc /system/etc/init/init.thermald.rc
mount --bind $MODDIR/thermal_core /vendor/bin/thermal_core
mount --bind $MODDIR/thermal_intf /vendor/bin/thermal_intf
mount --bind $MODDIR/init.thermal_core.rc /vendor/etc/init/init.thermal_core.rc
mount --bind $MODDIR/disable_thermal.conf /vendor/etc/thermal/disable_thermal.conf
mount --bind $MODDIR/disable_thermal_temp.conf /vendor/etc/thermal/disable_thermal_temp.conf
mount --bind $MODDIR/disable_skin_control.conf /vendor/etc/thermal/disable_skin_control.conf
mount --bind $MODDIR/disable_throttling.conf /vendor/etc/thermal/disable_throttling.conf
mount --bind $MODDIR/thermal_mtbf.conf /vendor/etc/thermal/thermal_mtbf.conf
mount --bind $MODDIR/thermal.conf /vendor/etc/thermal/thermal.conf
mount --bind $MODDIR/thermal_policy_00.conf /vendor/etc/thermal/thermal_policy_00.conf
mount --bind $MODDIR/thermal_policy_01.conf /vendor/etc/thermal/thermal_policy_01.conf
mount --bind $MODDIR/thermal_policy_02.conf /vendor/etc/thermal/thermal_policy_02.conf
mount --bind $MODDIR/thermal_policy_03.conf /vendor/etc/thermal/thermal_policy_03.conf
mount --bind $MODDIR/thermal_policy_08.conf /vendor/etc/thermal/thermal_policy_08.conf
mount --bind $MODDIR/thermal_policy_09.conf /vendor/etc/thermal/thermal_policy_09.conf
mount --bind $MODDIR/thermal_hal.so /vendor/lib/hw/thermal_hal.so
mount --bind $MODDIR/thermal_trace.ko /vendor/lib/modules/thermal_trace.ko
mount --bind $MODDIR/thermal_interface.ko /vendor/lib/modules/thermal_interface.ko
mount --bind $MODDIR/thermal-generic-adc.ko /vendor/lib/modules/thermal-generic-adc.ko
mount --bind $MODDIR/thermal_hal.so /vendor/lib64/hw/thermal_hal.so
mount --bind $MODDIR/sys_thermal_config.xml /vendor/odm/etc/ThermalServiceConfig/sys_thermal_config.xml
mount --bind $MODDIR/sys_thermal_config.xml /system/system_ext/etc/sys_thermal_config.xml
mount --bind $MODDIR/libthermalalgo.so /vendor/lib/libthermalalgo.so
mount --bind $MODDIR/thermal-chg-only.conf /vendor/etc/thermal-chg-only.conf
mount --bind $MODDIR/thermal /vendor/bin/thermal
mount --bind $MODDIR/thermal_manager /vendor/bin/thermal_manager
mount --bind $MODDIR/thermalloadalgod /vendor/bin/thermalloadalgod
mount --bind $MODDIR/thermal.mt6893.so /vendor/lib/hw/thermal.mt6893.so
mount --bind $MODDIR/init.thermal.rc /vendor/etc/init/init.thermal.rc
mount --bind $MODDIR/init.thermal_manager.rc /vendor/etc/init/init.thermal_manager.rc
mount --bind $MODDIR/init.thermalloadalgod.rc /vendor/etc/init/init.thermalloadalgod.rc
mount --bind $MODDIR/thermal.mt6893.so /vendor/lib64/hw/thermal.mt6893.so


chmod 755 -R /sys/devices/virtual/thermal
chmod 000 -R /sys/devices/virtual/thermal/cooling_device0
chmod 000 -R /sys/devices/virtual/thermal/cooling_device1
chmod 000 -R /sys/devices/virtual/thermal/cooling_device2
chmod 000 -R /sys/devices/virtual/thermal/cooling_device3
chmod 000 -R /sys/devices/virtual/thermal/cooling_device4
chmod 000 -R /sys/devices/virtual/thermal/cooling_device5
chmod 000 -R /sys/devices/virtual/thermal/cooling_device6
chmod 000 -R /sys/devices/virtual/thermal/cooling_device7
chmod 000 -R /sys/devices/virtual/thermal/cooling_device8
chmod 000 -R /sys/devices/virtual/thermal/cooling_device9
chmod 000 -R /sys/devices/virtual/thermal/cooling_device10
chmod 000 -R /sys/devices/virtual/thermal/cooling_device11
chmod 000 -R /sys/devices/virtual/thermal/cooling_device12
chmod 000 -R /sys/devices/virtual/thermal/cooling_device13
chmod 000 -R /sys/devices/virtual/thermal/cooling_device14
chmod 000 -R /sys/devices/virtual/thermal/cooling_device15
chmod 000 -R /sys/devices/virtual/thermal/cooling_device16
chmod 000 -R /sys/devices/virtual/thermal/cooling_device17
chmod 000 -R /sys/devices/virtual/thermal/cooling_device18
chmod 000 -R /sys/devices/virtual/thermal/cooling_device19
chmod 000 -R /sys/devices/virtual/thermal/cooling_device20
chmod 000 -R /sys/devices/virtual/thermal/cooling_device21
chmod 000 -R /sys/devices/virtual/thermal/cooling_device22
chmod 000 -R /sys/devices/virtual/thermal/cooling_device23
chmod 000 -R /sys/devices/virtual/thermal/cooling_device24
chmod 000 -R /sys/devices/virtual/thermal/cooling_device25
chmod 000 -R /sys/devices/virtual/thermal/cooling_device26
chmod 000 -R /sys/devices/virtual/thermal/cooling_device27
chmod 000 -R /sys/devices/virtual/thermal/cooling_device28
chmod 000 -R /sys/devices/virtual/thermal/cooling_device29
chmod 000 -R /sys/devices/virtual/thermal/cooling_device30
chmod 000 -R /sys/devices/virtual/thermal/cooling_device31
chmod 000 -R /sys/devices/virtual/thermal/cooling_device32
chmod 000 -R /sys/devices/virtual/thermal/cooling_device33
chmod 000 -R /sys/devices/virtual/thermal/cooling_device34
chmod 000 -R /sys/devices/virtual/thermal/cooling_device35
chmod 000 -R /sys/devices/virtual/thermal/cooling_device36
chmod 000 -R /sys/devices/virtual/thermal/cooling_device37
chmod 000 -R /sys/devices/virtual/thermal/cooling_device38
chmod 000 -R /sys/devices/virtual/thermal/cooling_device39
chmod 000 -R /sys/devices/virtual/thermal/cooling_device40
chmod 000 -R /sys/devices/virtual/thermal/cooling_device41
chmod 000 -R /sys/devices/virtual/thermal/cooling_device42
chmod 000 -R /sys/devices/virtual/thermal/cooling_device43
chmod 000 -R /sys/devices/virtual/thermal/cooling_device44
chmod 000 -R /sys/devices/virtual/thermal/cooling_device45
chmod 000 -R /sys/devices/virtual/thermal/cooling_device46
chmod 000 -R /sys/devices/virtual/thermal/cooling_device47
chmod 000 -R /sys/devices/virtual/thermal/cooling_device48
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone0
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone1
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone2
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone3
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone4
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone5
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone6
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone7
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone8
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone9
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone10
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone11
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone12
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone13
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone14
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone15
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone16
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone17
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone18
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone19
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone20
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone21
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone22
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone23
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone24
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone25
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone26
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone27
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone28
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone29
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone30
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone31
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone32
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone33
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone34
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone35
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone36
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone37
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone38
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone39
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone40
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone41
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone42
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone43
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone44
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone45
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone46
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone47
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone48
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone49
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone50
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone51
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone52
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone53
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone54
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone55
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone56
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone57
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone58
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone59
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone60
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone61
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone62
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone63
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone64
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone65
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone66
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone67
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone68
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone69
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone70
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone71
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone72
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone73
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone74
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone75
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone76
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone77
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone78
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone79
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone80
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone81
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone82
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone83
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone84
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone85
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone86
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone87
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone88
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone89
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone90
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone91
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone92
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone93
chmod 755 -R /sys/devices/virtual/thermal/thermal_zone94
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone95
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone96
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone97
chmod 000 -R /sys/devices/virtual/thermal/thermal_zone98


rm -rf $MODDIR/*thermal*.conf
rm -rf $MODDIR/*thermal*.so
rm -rf $MODDIR/*thermal*.ko
rm -rf $MODDIR/*thermal*.rc
rm -rf $MODDIR/*disable*.conf
rm -rf $MODDIR/thermal*
rm -rf $MODDIR/mi_thermald
rm -rf $MODDIR/Ling_Yi


mount --bind $MODDIR/sys_high_temp_protect_21641.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect_21641.xml
mount --bind $MODDIR/sys_high_temp_protect_21641.xml /odm/etc/temperature_profile/sys_high_temp_protect_21641.xml
mount --bind $MODDIR/sys_high_temp_protect_21642.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect_21642.xml
mount --bind $MODDIR/sys_high_temp_protect_21642.xml /odm/etc/temperature_profile/sys_high_temp_protect_21642.xml
mount --bind $MODDIR/sys_high_temp_protect_realme_20627.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect_realme_20627.xml
mount --bind $MODDIR/sys_high_temp_protect_realme_20627.xml /odm/etc/temperature_profile/sys_high_temp_protect_realme_20627.xml
mount --bind $MODDIR/sys_high_temp_protect_realme_21631.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect_realme_21631.xml
mount --bind $MODDIR/sys_high_temp_protect_realme_21631.xml /odm/etc/temperature_profile/sys_high_temp_protect_realme_21631.xml
mount --bind $MODDIR/sys_thermal_control_config.xml /vendor/odm/etc/temperature_profile/sys_thermal_control_config.xml
mount --bind $MODDIR/sys_thermal_control_config.xml /odm/etc/temperature_profile/sys_thermal_control_config.xml
mount --bind $MODDIR/sys_thermal_control_config_gt.xml /vendor/odm/etc/temperature_profile/sys_thermal_control_config_gt.xml
mount --bind $MODDIR/sys_thermal_control_config_gt.xml /odm/etc/temperature_profile/sys_thermal_control_config_gt.xml
mount --bind $MODDIR/sys_high_temp_protect.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect.xml
mount --bind $MODDIR/sys_high_temp_protect.xml /odm/etc/temperature_profile/sys_high_temp_protect.xml
mount --bind $MODDIR/sys_high_temp_protect_OPPO.xml /vendor/odm/etc/temperature_profile/sys_high_temp_protect_OPPO.xml
mount --bind $MODDIR/sys_high_temp_protect_OPPO.xml /odm/etc/temperature_profile/sys_high_temp_protect_OPPO.xml
mount --bind $MODDIR/sys_thermal_control_config_gt.xml /vendor/odm/etc/temperature_profile/sys_thermal_control_config_gt.xml
mount --bind $MODDIR/sys_thermal_control_config_gt.xml /odm/etc/temperature_profile/sys_thermal_control_config_gt.xml

