set_perm_recursive $MODPATH 0 0 0755 0644

conf=/data/eem_offset.conf

echo '# Little Cores(0-3)
little=-2
# Middle Cores(4-6)
middle=-5
# Big Cores(7)
big=-5
# CCI
cci=-2' > $conf

echo '配置位于 /data/eem_offset.conf'
echo '模块开机120秒后才会开始生效'
echo '无需担心电压设置过低导致无法开机'

echo '降压可能导致稳定性下降频繁死机！'
echo '请酌情调整电压'
