#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
cat <<EOF | nohup sh &
if_Charging() {
    [[ -n \`dumpsys battery | grep 'status: 2'\` ]] && echo 1
}
# This script will be executed in late_start service mode
sleep 10
chmod 755 /sys/class/power_supply/*/*
chmod 755 /sys/module/qpnp_smbcharger/*/*
chmod 755 /sys/module/dwc3_msm/*/*
chmod 755 /sys/module/phy_msm_usb/*/*
while true; do
  until [[ \`if_Charging\` != 1 ]] ; do
    echo '1' > /sys/kernel/fast_charge/force_fast_charge
    echo '1' > /sys/kernel/fast_charge/failsafe
    echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
    echo '0' > /sys/class/power_supply/battery/restricted_charging
    echo '0' > /sys/class/power_supply/battery/system_temp_level
    echo '0' > /sys/class/power_supply/battery/input_current_limited
    echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
    echo '1' > /sys/class/power_supply/usb/pd_allowed
    echo '1' > /sys/class/power_supply/battery/input_current_settled
    echo '1' > /sys/class/power_supply/usb/boost_current
    echo '0' > /sys/module/smb_lib/parameters/skip_thermal
    echo '0' > /sys/class/qcom-battery/restricted_charging
    echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
    echo '1' > /sys/class/power_supply/wireless/input_current_settled
    echo '100' > /sys/class/power_supply/bms/temp_cool
    echo '600' > /sys/class/power_supply/bms/temp_warm
    echo '5000000' > /sys/class/power_supply/usb/current_max
    echo '5100000' > /sys/class/power_supply/usb/hw_current_max
    echo '5100000' > /sys/class/power_supply/usb/pd_current_max
    echo '5100000' > /sys/class/power_supply/usb/ctm_current_max
    echo '5000000' > /sys/class/power_supply/usb/sdp_current_max
    echo '5100000' > /sys/class/power_supply/usb/constant_charge_current
    echo '5100000' > /sys/class/power_supply/usb/constant_charge_current_max
    echo '5000000' > /sys/class/power_supply/main/current_max
    echo '5100000' > /sys/class/power_supply/main/constant_charge_current
    echo '5100000' > /sys/class/power_supply/main/constant_charge_current_max
    echo '5000000' > /sys/class/power_supply/dc/current_max
    echo '5100000' > /sys/class/power_supply/dc/constant_charge_current_max
    echo '5000000' > /sys/class/power_supply/parallel/current_max
    echo '5100000' > /sys/class/power_supply/parallel/constant_charge_current_max
    echo '5000000' > /sys/class/power_supply/battery/current_max
    echo '5100000' > /sys/class/power_supply/battery/input_current_max
    echo '5100000' > /sys/class/power_supply/battery/constant_charge_current
    echo '5100000' > /sys/class/power_supply/battery/constant_charge_current_max
    echo '5100000' > /sys/class/power_supply/bms/constant_charge_current_max
    echo '5000000' > /sys/class/power_supply/pc_port/current_max
    echo '5000000' > /sys/class/power_supply/qpnp-dc/current_max
    echo '4500000' > /sys/class/power_supply/wireless/constant_charge_current_max
    echo '5500000' > /sys/class/qcom-battery/restricted_current
    echo '3500' > /sys/kernel/fast_charge/wireless_charge_level
    echo '5000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma
    echo '5000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma
    echo '5000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma
    echo '5000' > /sys/module/dwc3_msm/parameters/dcp_max_current
    echo '5000' > /sys/module/dwc3_msm/parameters/hvdcp_max_current
    echo '5000' > /sys/module/phy_msm_usb/parameters/dcp_max_current
    echo '5000' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current
    echo '5000' > /sys/module/phy_msm_usb/parameters/lpm_disconnect_thresh
    sleep 1
  done
  sleep 5
done
EOF
exit