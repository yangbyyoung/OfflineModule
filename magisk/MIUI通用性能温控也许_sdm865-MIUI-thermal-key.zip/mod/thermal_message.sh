#!/system/bin/sh

function install_magisk_busybox() {
mkdir -p /data/adb/busybox
/data/adb/magisk/busybox --install -s /data/adb/busybox
chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

#添加busybox，避免参数无用。
install_magisk_busybox

dir="${0%/*}"
MODPATH="${dir%/*}"
TARGET_FOLDER="${MODPATH}/温控自检信息"
mkdir -p "${TARGET_FOLDER}"
cp -rf "${MODPATH}/配置.prop" "${TARGET_FOLDER}"

function echo_thermal_message(){
for folder in `ls -d /sys/class/thermal/thermal_message`
do
cat << key
综合温度传感器=`cat "${folder}/ambient_sensor" 2>/dev/null`
综合温度=`cat "${folder}/ambient_sensor_temp" 2>/dev/null`
当前使用的温度传感器=`cat "${folder}/board_sensor" 2>/dev/null`
温度=`cat "${folder}/board_sensor_temp" 2>/dev/null`
严格温控限制是否开启=`cat "${folder}/temp_state" 2>/dev/null`
当前温控配置=`cat "${folder}/sconfig" 2>/dev/null`
key
done
}


function echo_cooling_message(){
for i in $(ls -d /sys/class/thermal/cooling*/*cur_state)
do
name=`cat "${i%/*}/type" 2>/dev/null`
value=`cat "${i}" 2>/dev/null`
cat << key 
降温策略名称=${name}
当前策略=${value}
路径=${i}

key
done
}


function echo_GPU_temp_message(){
for i in $(ls -d /sys/class/thermal/thermal_zone*/*point*temp)
do
name=`cat "${i%/*}/type" 2>/dev/null | grep -Ei 'gpu|gpuss'`
value=`cat "${i}" 2>/dev/null `
if test "${name}" != "" ;then
cat << key
名称=${name}
阈值=${value}
路径=${i}

key
fi
done
}

function echo_CPU_temp_message(){
for i in $(ls -d /sys/class/thermal/thermal_zone*/*point*temp)
do
name=`cat "${i%/*}/type" 2>/dev/null | grep -Ei 'cpu|cpuss'`
value=`cat "${i}" 2>/dev/null `
if test "${name}" != "" ;then
cat << key
名称=${name}
阈值=${value}
路径=${i}

key
fi
done
}

function echo_all_temp_sensor(){
for i in $(ls -d /sys/class/thermal/thermal*/type)
do
name=`cat "${i}" 2>/dev/null`
value=`cat "${i%/*}/temp" 2>/dev/null `
if test "${name}" != "" ;then
cat << key
名称=${name}
值=${value}
路径=${i%/*}

key
fi
done
}

function echo_head_info(){
echo "品牌=`getprop ro.product.brand`"
echo "代号=`getprop ro.product.device`"
echo "模型=`getprop ro.product.model`"
echo "安卓版本=`getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && echo "MIUI版本=MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
echo "内核版本=`uname -a `"
echo "处理器=$(getprop ro.board.platform)"
echo "上次云控更新日期:$(content query --uri 'content://com.miui.powerkeeper.configure/SimpleSettings/misc' --where "name='last_sync_cloud_info'" | sed 's|.*value=||g;s|,.*||g')"
}

cat << key >"$TARGET_FOLDER/MIUI温控信息.prop"

$(echo_head_info)

#############

$(echo_thermal_message)

#############
key

cat << key >"$TARGET_FOLDER/降温策略信息.prop"

$(echo_head_info)

#############

$(echo_cooling_message)

#############
key

cat << key >"$TARGET_FOLDER/GPU温度墙信息.prop"

$(echo_head_info)

#############

$(echo_GPU_temp_message)

#############
key


cat << key >"$TARGET_FOLDER/CPU温度墙信息.prop"

$(echo_head_info)

#############

$(echo_CPU_temp_message)

#############
key

cat << key >"$TARGET_FOLDER/所有温度传感器信息.prop"

$(echo_head_info)

#############

$(echo_all_temp_sensor)

#############
key

cat << key >"$TARGET_FOLDER/云控信息.json"

$(echo_head_info)

#############

$(content query --uri "content://com.miui.powerkeeper.configure/SimpleSettings/misc")

#############
key
