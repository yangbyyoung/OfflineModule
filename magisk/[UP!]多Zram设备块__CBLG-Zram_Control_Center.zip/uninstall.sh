#!/bin/sh
{
  
  true
  
  export MHOME='/data/adb/_CBLG/Modules'
  export MODID='_CBLG-Zram_Control_Center'
  
  [[ -d "${MHOME}/${MODID}" ]] || exit 255
  
  [[ -f "${MHOME}/${MODID}/remove.cblg" ]] && \
    /bin/sh "${MHOME}/${MODID}/remove.cblg"
  
  exit 256
  
}