#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。

source "${0%/*}/util_functions.sh"

#其他vm参数的设定
function other_vm() {
	set_value '0' /proc/sys/vm/swap_ratio_enable
	set_value '120' /proc/sys/vm/vfs_cache_pressure
	set_value '0' /sys/module/vmpressure/parameters/allocstall_threshold
	set_value '0' /proc/sys/vm/oom_kill_allocating_task
	set_value '0' /proc/sys/vm/oom_dump_task
	set_value '0' /proc/sys/vm/compact_unevictable_allowed
	set_value '20' /proc/sys/vm/stat_interval
	set_value '30' /proc/sys/vm/overcommit_ratio
	set_value '0' /proc/sys/vm/overcommit_memory
	set_value '0' /proc/sys/vm/panic_on_oom
	set_value '30' /proc/sys/vm/watermark_scale_factor
	set_value '10' /proc/sys/vm/page-cluster
	sync
	echo "3" > /proc/sys/vm/drop_caches
	echo "1" > /proc/sys/vm/compact_memory
	sync
}


if test $(show_value "其他VM参数") == 修改 ;then
	other_vm
fi




