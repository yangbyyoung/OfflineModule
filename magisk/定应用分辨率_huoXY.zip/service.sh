#!/system/bin/sh
MODDIR=${0%/*}
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c /data/adb/modules/huoXY/cron.d