
SKIPUNZIP=0

ASH_STANDALONE=0

REPLACE="
/system/priv-app/MIUIMusic
"

ui_print '================================================='
ui_print " 兼容性检测ing "
sleep 2
test "$(getprop ro.miui.ui.version.name)" = "" && abort "－ 非MIUI系统 ！"

ui_print '================================================='
ui_print "     	Magisk Module        "
ui_print "   模块名称: MIUI MUSIC Global "
ui_print "   版本: 6.6.5.4i "
ui_print "   作者: lllyyyz"
ui_print "   本模块仅简单替换国内版小米音乐为国际版，不包含MIUI Core"
ui_print "   非MIUI系统安装后，可能会出现闪退、无法播放等各种情况"
ui_print "   重启后如界面无变化，请在系统设置中卸载更新"
ui_print "   如需卸载，重启后，请在/system/priv-app/MIUIMusic/下手动安装一遍或在应用商店更新最新版本"
ui_print '================================================='

# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644
