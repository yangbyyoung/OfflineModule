#!/system/bin/sh
MODDIR=${0%/*}
mount --bind $MODDIR/my_product/etc/extension/feature_com.android.battery.xml /my_product/etc/extension/feature_com.android.battery.xml
mount --bind $MODDIR/my_product/fdt /sys/firmware/fdt
