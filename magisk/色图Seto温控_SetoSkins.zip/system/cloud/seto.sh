while true; do
	sleep 3
	cp /data/media/0/Android/备份温控（请勿删除）/* /data/vendor/thermal/config/
done
