#!/system/bin/sh

#定义相关路径和文件
MODDIR=${0%/*}
DEX2OAT_CONFIG="/data/adb/Dex2oatBOOT/dex2oat基础配置.prop"
DEX2OAT_LOG="/data/adb/Dex2oatBOOT/dex2oat日志.log"
OPTIONALAPP_CONFIG="/data/adb/Dex2oatBOOT/dex2oat自选应用配置.prop"

#读取配置
dex2oat_mode=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^模式=" | cut -f2 -d '=')
dex2oat_select=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^应用=" | cut -f2 -d '=')
optional_app=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^自选应用=" | cut -f2 -d '=')

#创建日志文件
if [ ! -d $DEX2OAT_LOG ]; then
	touch $DEX2OAT_LOG
fi

#输出相关信息到日志文件
echo -e " ҉开始运行dex2oat，当前配置为：$dex2oat_mode；选择应用为：$dex2oat_select；自选应用：$optional_app" >> $DEX2OAT_LOG

#判断并运行dex2oat
if [ $dex2oat_mode = "speed-profile" ]; then
	. $MODDIR/mode/speed-profile.sh
elif [ $dex2oat_mode = "speed" ]; then
	. $MODDIR/mode/speed.sh
elif [ $dex2oat_mode = "everything" ]; then
	. $MODDIR/mode/everything.sh
else
	echo "✘未知的dex2oat模式" >> $DEX2OAT_LOG
fi
echo "✔运行完毕" >> $DEX2OAT_LOG
