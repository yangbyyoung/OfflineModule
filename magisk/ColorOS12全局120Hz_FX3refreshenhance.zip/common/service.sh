#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

sys_path=/data/system
if [ -f $sys_path/refresh_rate_config.bak ];then
  ratemagic=`cat $sys_path/refresh_rate_config.bak|grep 'ratemagic'|awk -F "\"" '{print $4}'`
  datenow=$(date "+%Y%m%d")

  Line=`grep -rn "<refresh_rate_config" $sys_path"/refresh_rate_config.xml" |awk -F ':' '{print $1}'`
  sed -i $Line"d"  $sys_path/refresh_rate_config.xml

  if [ -n "$ratemagic" ]; then
  sed -i $Line"i<refresh_rate_config\ version=\"$datenow\" ratemagic=\"$ratemagic\">"  $sys_path/refresh_rate_config.xml
  else
  sed -i $Line"i<refresh_rate_config\ version=\"$datenow\">"  $sys_path/refresh_rate_config.xml
  fi
fi
exit 0
