#!/system/bin/sh
rm -rf /data/adb/modules/miui_fastcharge/
exit 0