SKIPUNZIP=0
var_device="`getprop ro.product.board`"
echo "当前手机型号是: $var_device "
case "${var_device}" in
"cas")
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
  ui_print "done..."
;;
"cmi")
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
  ui_print "done..."
;;
"venus")
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
  ui_print "done..."
;;
*)
  rm -rf $MODPATH/*
  abort "- ${var_device} 其它机型别乱刷哦，没有任何效果！"
;;
esac
exit
