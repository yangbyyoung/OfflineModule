#!/system/bin/sh
function white_list()
{
  pgrep -o $1 | while read pid; do
  echo $pid > /dev/cpuset/audio-app/cgroup.procs
  echo $pid > /dev/cpuset/audio-app/cgroup.procs
   chrt -f -p $pid 1
   renice -n -1 -p $pid
  done
}
white_list com.android.systemui
white_list net.oneplus.launcher
white_list com.meizu.flyme.launcher
white_list android:ui
white_list com.android.wallpaper.livepicker
white_list com.android.touch.gestures

function white()
{
  pgrep -f $1 | while read pid; do
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
   chrt -f -p $pid 0
   renice -n -0 -p $pid
  done
}
white surfaceflinger
white system_server
white android.hardware.graphics.composer@2.1-service
white android
white com.android.networkstack
white zygote