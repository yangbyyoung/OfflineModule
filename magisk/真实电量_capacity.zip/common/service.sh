if [ -f /sys/class/qcom-battery/fg1_rsoc ]; then
  setenforce 0
mount --bind /sys/class/qcom-battery/fg1_rsoc /sys/class/power_supply/battery/capacity
chcon u:object_r:vendor_sysfs_battery_supply:s0 /sys/class/power_supply/battery/capacity
setenforce 1 
fi