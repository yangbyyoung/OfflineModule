#设置权限
set_perm_recursive $MODPATH 0 0 0755 0644
echo 正在释放资源。。。
#需要将配置文件复制到指定目录
info_path="/sdcard/Android/EasyClean"
#清理目录，准备释放规则文件
rm -rf $info_path
mkdir -p $info_path

#释放文件
cp -r ${MODPATH}/files $info_path/files
cp -r ${MODPATH}/Rules $info_path/Rules
cp -r ${MODPATH}/源码备份 $info_path/源码备份
#清理剩下的文件
rm -rf ${MODPATH}/files
rm -rf ${MODPATH}/Rules
rm -rf ${MODPATH}/源码备份
sleep 1
sleep 0.1
MyPrint() {
	echo "$@"
	sleep 0.1
}
MyPrint "╔════════════════════════════════════"
MyPrint "║   - [&]    采用C语言和shell命令编写，超低功耗，遥遥领先！    "
MyPrint "╠════════════════════════════════════"
MyPrint "║ 温馨提示：尽量不要同时使用多个文件清理模块"
MyPrint "║   - 1.如果你不是从作者发布链接获取此模块，将承担未知风险"
MyPrint "║   - 2.内置规则可满足一定清理需求，请根据需求修改规则"
MyPrint "║   - 3.模块配置路径: /sdcard/Android/EasyClean"
MyPrint "║   - 4.打包了源码，可根据需求修改编译"
MyPrint "║   - 5.请设置酷安下载目录到Download，避免安装包被清理"
MyPrint "║ "
MyPrint "║   - ps: 看不懂源码可以问问AI，它可以帮到你"
MyPrint "║                 群号：790355353"
MyPrint "╚════════════════════════════════════"
echo " "
echo 
echo 


