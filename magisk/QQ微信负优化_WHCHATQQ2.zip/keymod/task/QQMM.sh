#!/system/bin/sh

wait_until_login() {
	# in case of /data encryption is disabled
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done

	# we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
	local test_file="/sdcard/Android/.PERMISSION_TEST"
	true >"$test_file"
	while [ ! -f "$test_file" ]; do
		true >"$test_file"
		sleep 1
	done
	rm "$test_file"
}

wait_until_login

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

confdir="/data/media/0/Android/QQ微信负优化"

mkdir -p "${confdir}" 
mkdir -p "${confdir}/日志"

test ! -e "${confdir}"/QQ微信清理.conf && {
	sed -i '/description/d;/^[[:space:]]*$/d' ${MODPATH}/module.prop
	echo "description=配置文件：[ "${confdir}"/QQ微信清理.conf ] 丢失！配置文件文件在"${confdir}"/QQ微信清理.conf，日志在"${confdir}"/日志/清理日志.log。" >>${MODPATH}/module.prop
	exit 1
}

oldsize=$(du -sm /data | tr -cd '[0-9]')

function X_FILE_RE() {
	if test -e "$1"; then
		chattr -i "$1" 2>/dev/null
		rm -rf "$1"
	fi
}

function X_FILE_DIR() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
	fi
}

function show_value() {
	local value=$1
	local file="${confdir}"/QQ微信清理.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}


function limitlog() {
	local logfile="${confdir}"/日志/清理日志.log
	local maxsize=$((1024 * 1000))
	filesize=$(ls -l $logfile | awk '{print $5}')
	if test $filesize -gt $maxsize; then
		echo " " >${logfile}
	fi
}

function tencentlog() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/user/*/com.tencent.mm /data/media/*/Android/data/com.tencent.mobileqq /data/data/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent -iname "*crash*" -type d -o -iname "*log*" -type d | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_img_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "diskcache" -type d -o -iname "Scribble" -type d -o -iname "chatpic" -type d -o -iname "hotpic" -type d -o -iname "QQEditPic" -type d -o -iname "thumb" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_video_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "shortvideo" -type d -o -iname "video_story" -type d -o -iname "VideoCache" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_ad_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "qbosssplahAD" -type d -o -iname "pddata" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_card_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "vas" -type d -o -iname "lottie" -type d -o -iname ".apollo" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_qzone_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "qzone" -type d -o -iname "qzlive" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_qqmusic_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "qqmusic" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function MM_webcache_clear() {
	find /data/data/com.tencent.mm /data/user/*/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent/ -iname "webview_tmpl" -type d -o -iname "CheckResUpdate" -type d -o -iname "webcached" -type d -o -iname "CronetCache" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function MM_img_clear() {
	find /data/data/com.tencent.mm /data/user/*/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent/ -iname "bizimg" -type d -o -iname "sns" -type d -o -iname "sns_ad_landingpages" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_miniapp_clear() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/media/*/Tencent/ -iname "mini" -type d -o -iname "minigame" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function MM_liteapp_clear() {
	find /data/data/com.tencent.mm /data/user/*/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent/ -iname "liteapp" -type d -o -iname "pkg" -type d 2>/dev/null | while read value; do
		rm -rf "${value}"
		echo "${value}" >>"${confdir}"/日志/清理日志.log
	done
}

function QQ_tbs_forbid() {
	find /data/data/com.tencent.mobileqq /data/user/*/com.tencent.mobileqq -iname "*app_tbs*" -type d -o -iname "*x5*webview*" -type d 2>/dev/null | while read tbs; do
		X_FILE_DIR "${tbs}"
	done
}

function MM_tbs_forbid() {
	find /data/data/com.tencent.mm /data/user/*/com.tencent.mm -iname "*app_tbs*" -type d -o -iname "*x5*webview*" -type d 2>/dev/null | while read tbs; do
		X_FILE_DIR "${tbs}"
	done
}

function app_walk_clear_method() {
	last_plug=$(find "${1}" -iname "app_xwalk_*[[:digit:]]*" -type d 2>/dev/null | sed '/^[[:space:]]*$/d;s/.*app_xwalk_//g' | sort -nr | uniq | sed -n '1p')
	find "${1}" -iname "app_xwalk_*[[:digit:]]*" -type d 2>/dev/null | sed "/$last_plug/d" | while read folder; do
		rm -rf "${folder}"
	done
}

function MM_app_walk_clear (){
ls -d /data/data/com.tencent.mm /data/user/*/com.tencent.mm 2>/dev/null | while read dir; do
	app_walk_clear_method "${dir}"
	echo "${dir}" >>"${confdir}"/日志/清理日志.log
done
}


#通用缓存日志清理
#包含xlog,livelog 等SB玩意
if test $(show_value "通用缓存") == 清理; then
	tencentlog
fi

#QQ
#QQ日常图片清理，不包含聊天记录
if test $(show_value "QQ图片") == 清理; then
	QQ_img_clear
fi
#个性名片
if test $(show_value "QQ个性名片") == 清理; then
	QQ_card_clear
fi
#QQ空间
if test $(show_value "QQ空间") == 清理; then
	QQ_qzone_clear
fi
#QQ中的QQ音乐？傻逼玩意
if test $(show_value "QQ音乐") == 清理; then
	QQ_qqmusic_clear
fi
#QQ广告
if test $(show_value "QQ广告") == 清理; then
	QQ_ad_clear
fi
#QQ短视频
#清理后无法查看(保存到相册的不影响)
if test $(show_value "QQ短视频") == 清理; then
	QQ_video_clear
fi
#QQ小程序清理
if test $(show_value "QQ小程序") == 清理; then
	QQ_miniapp_clear
fi
#QQx5内核禁用
if test $(show_value "QQX5内核") == 清理; then
	QQ_tbs_forbid
fi

#微信
#微信日常网页缓存清理
#包含检查更新和webview_tmpl(貌似是小程序框架？)
#清理后解除大量内存，但小程序会打开缓慢
if test $(show_value "微信网页缓存") == 清理; then
	MM_webcache_clear
fi
#微信公众号图片和朋友圈视频和图片清理
if test $(show_value "微信图片") == 清理; then
	MM_img_clear
fi

#微信小程序清理
if test $(show_value "微信小程序") == 清理; then
	MM_liteapp_clear
fi

#微信X5内核
if test $(show_value "微信X5内核") == 清理; then
	MM_tbs_forbid
fi

if test $(show_value "微信X5内核旧插件") == 清理; then
	MM_app_walk_clear
fi

newsize=$(du -sm /data | tr -cd '[0-9]')
data_size=$(($oldsize - $newsize))
check_data_size=$(echo "$data_size" | grep -q '-' && echo "true")

if test "$check_data_size" = "true"; then
	sed -i '/description/d;/^[[:space:]]*$/d' ${MODPATH}/module.prop
	echo "description=[ $(date '+%y年%m月%d日%T') ]，本次运行储存空间减少了"$data_size"MB。配置文件文件在"${confdir}"/QQ微信清理.conf，日志在"${confdir}"/日志/清理日志.log。" >>${MODPATH}/module.prop
else
	sed -i '/description/d;/^[[:space:]]*$/d' ${MODPATH}/module.prop
	echo "description=[ $(date '+%y年%m月%d日%T') ]，本次运行储存空间释放了"$data_size"MB。配置文件文件在"${confdir}"/QQ微信清理.conf，日志在"${confdir}"/日志/清理日志.log。" >>${MODPATH}/module.prop
fi

echo "\n"$(date '+%y年%m月%d日%T')"，清理完成！\n########\n" >>"${confdir}"/日志/清理日志.log
limitlog
