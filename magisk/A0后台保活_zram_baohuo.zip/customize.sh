DUBUG_FLAG=false
SKIPMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
module_version="`grep_prop version $TMPDIR/module.prop`"
module_name="`grep_prop name $TMPDIR/module.prop`"
module_id="`grep_prop id $TMPDIR/module.prop`"
  ui_print "-------------------------------------"
  ui_print "- $module_name "
  ui_print "- 作者: 魔威"
  ui_print "- 版本: $module_version"
  ui_print "-------------------------------------"
  ui_print "- 机型: $var_device"
  ui_print "- 安卓版本: $var_version"
  ui_print "安装脚本马上开始"
  sleep 3
  ui_print "*******************************"
  ui_print "模块刷入中"
  ui_print "A0后台保活模块1.3已刷入"
  ui_print "*******************************"
  ui_print "               By:魔威"
  ui_print "模块刷入完毕"
  ui_print "即将打开酷安关注作者"
  sleep 1
  ui_print "3"
  sleep 1
  ui_print "2"
  sleep 1
  ui_print "1"
  sleep 1
  ui_print "正在打开酷安"
# ----------魔威andlua函数------------祝老天爷保佑----------永无bug
CommonPath=$MODPATH/common
if [ ! -d ${CommonPath} ];then
  ui_print "模块修复"
  
elif [ "`ls -A ${CommonPath}`" = "" ];then
    ui_print "模块为空，请重新安装"
    rm  -rf  ${CommonPath}
else

  ui_print "- 正在进行模块修复，请耐心等待"
  mv  ${CommonPath}/*  $MODPATH
  rm  -rf ${CommonPath}

  fi
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolmarket://u/24268987' >/dev/null 2>&1
  fi
#----------魔威andlua函数------------祝老天爷保佑----------永无bug