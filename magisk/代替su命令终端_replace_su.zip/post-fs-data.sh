#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
grep_cmdline() {
  local REGEX="s/^$1=//p"
  { echo $(cat /proc/cmdline)$(sed -e 's/[^"]//g' -e 's/""//g' /proc/cmdline) | xargs -n 1; \
    sed -e 's/ = /=/g' -e 's/, /,/g' -e 's/"//g' /proc/bootconfig; \
  } 2>/dev/null | sed -n "$REGEX"
}
MODDIR=${0%/*}
ANB=$(grep_cmdline androidboot.slot_suffix)&&$(grep_cmdline androidboot.slot)
MIRRORPROP=$MODDIR/module.prop
BFPROP=$MODDIR/配置/备用module

# 此脚本将在post-fs-data模式下执行

if [ $(cat "$MIRRORPROP" = ) ]; then
cp -r $BFPROP $MIRRORPROP
else
echo "prop无空白"
fi

if [ "$ANB" = "_b" ]; then
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ 活动B分区 ] /g' "$MIRRORPROP"
else
if [ "$ANB" = "_a" ]; then
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ 活动A分区 ] /g' "$MIRRORPROP"
else
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ 不是V-AB机型 ] /g' "$MIRRORPROP"
fi
fi
done
