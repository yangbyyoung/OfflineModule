# ProxyPin Certificate
这是一个Magisk 模块 用于安装ProxyPin系统证书, 安装完后需要重启手机.

抓包下载地址
https://github.com/wanghongenpin/network_proxy_flutter