test "$(getprop ro.miui.ui.version.name)" = "" && abort "●———— 非MIUI ————●"
