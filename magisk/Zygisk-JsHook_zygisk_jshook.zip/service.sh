MODDIR=${0%/*}
cd "$MODDIR"
# post-fs-data.sh may be blocked by other modules. retry to start this
unshare -m sh -c "$MODDIR/daemon --from-service $@&"
