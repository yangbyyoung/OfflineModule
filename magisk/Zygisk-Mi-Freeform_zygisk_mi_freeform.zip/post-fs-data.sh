magiskpolicy --live "allow untrusted_app default_android_service service_manager find"
magiskpolicy --live "allow system_server default_android_service service_manager add"