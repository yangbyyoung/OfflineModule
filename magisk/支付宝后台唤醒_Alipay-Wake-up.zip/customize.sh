SKIPUNZIP=0

MyPrint() {
	echo "$@"
	sleep 0.05
}

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}

PATH="$PATH:/system/sbin:/sbin/.magisk/busybox:$(magisk --path)/.magisk/busybox"

if [[ ! -z $(which curl) ]]; then
	echo "- Binary_System=$(which curl)"
	echo "Binary_System=\"$(which curl)\"" >> $MODPATH/files/Variable.sh
elif [[ ! -z $(which wget) ]]; then
	echo "- Binary_System=$(which wget)"
	echo "Binary_System=\"$(which wget)\"" >> $MODPATH/files/Variable.sh
else
	abort "- [!] 命令缺失: busybox curl/wget 二进制"
fi

paths="/data/media/0/Android/支付宝后台唤醒/"

[[ -d $paths ]] && rm -rf $paths

if [[ ! -d $paths/作者信息/ ]]; then
	mkdir -p $paths/作者信息/
	cp $MODPATH/files/Author_Information/作者主页[root执行前往].sh $paths/作者信息
	cp $MODPATH/files/Author_Information/作者QQ群[root执行前往].sh $paths/作者信息
	cp $MODPATH/files/Author_Information/开源地址[root执行前往].sh $paths/作者信息
fi

MyPrint " "
MyPrint "- 支付宝后台唤醒 [云端版]"
MyPrint "- 开源仓库: https://gitee.com/Petit-Abba/wake-up/"
MyPrint " "
MyPrint "- 是否前往开源地址查看详情?"
MyPrint "- 按音量键＋前往"
MyPrint "- 按音量键－是笨比"
if [[ $(get_choose) == 0 ]]; then
	MyPrint "- 前往"
	am start -a android.intent.action.VIEW -d https://gitee.com/Petit-Abba/wake-up >/dev/null 2>&1
else
	MyPrint "- 你是笨比"
fi
MyPrint " "
MyPrint "- 未经许可禁止转载和二改参数！"
MyPrint "- 禁止商用！"
MyPrint " "
MyPrint "- 重启后等待云端同步"
MyPrint "- 同步完成后可前往 /sdcard/Android/支付宝后台唤醒/ 进行查看"
MyPrint " "
MyPrint "- 重启生效"
MyPrint " "
