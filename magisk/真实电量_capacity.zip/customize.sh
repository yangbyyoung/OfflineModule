if [[ ! -f /sys/class/qcom-battery/fg1_rsoc ]] && [[ ! -f /sys/class/power_supply/bms/capacity_raw ]]; then
  echo '此模块不适用于您的设备'
  exit 1
fi