chattr -i /data/vendor/thermal
chattr -i /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
chattr +i /data/vendor/thermal/config
