AUTOMOUNT=true

MOD_Version="`grep_prop version $TMPDIR/module.prop`"
MOD_Author="`grep_prop author $TMPDIR/module.prop`"
MOD_Description="`grep_prop description $TMPDIR/module.prop`"
MarketName="`getprop ro.product.marketname`"
Device="`getprop ro.product.device`"
Model="`getprop ro.product.model`"
MIUI="`getprop ro.miui.ui.version.name`"
Version="`getprop ro.build.version.incremental`"
Android="`getprop ro.build.version.release`"
za=$MODPATH/YuK/7za #$za a -tzip -mx=7 -mmt
REPLACE=""

  ui_print "- $MOD_Description"
  ui_print "- "
  ui_print "- 模块版本："
  ui_print "- $MOD_Version"
  ui_print "- "
  ui_print "- 模块制作：$MOD_Author"
  ui_print "- Coolapk @余空_YuK"
  ui_print "- "
  ui_print "- 相关信息："
  ui_print "- 机型：$MarketName"
  ui_print "- 设备代号：$Device"
  ui_print "- 认证型号：$Model"
  ui_print "- 安卓版本：Android $Android"
  ui_print "- MIUI版本：$Version"
  
Time=$(date "+%Y年%m月%d日 %H:%M:%S")
echo "- "
echo "- 刷入时间：$Time"
description=$MODPATH/module.prop
echo "刷入时间：$Time." >> $description
echo "- "
echo "- 完成..."