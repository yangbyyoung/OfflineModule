# v9.0.0 - March 31, 2023

## Highlights

- Support for Notes (early beta)
- Support for Updater
- Support for Incall UI
- Support for Download UI
- Support for Global App vault

## Other changes

- Design improvements, updates & fixes

---

Made with ❤️