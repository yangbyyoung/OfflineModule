ui_print "- Verify module resources"

function do_verify() {
    [ -f "$MODPATH/$1" ] || abort "! Module resource '$1' not found"

    (echo "$2  $MODPATH/$1" | sha256sum -c -s -) || abort "! Module resource '$1' verify failed"

    ui_print "  '$1' verified"
}

do_verify classes.dex 774a8b9e61e2168c3edc028858ae3d46813dd52f621522865a7c7959c84a771f
do_verify customize.d/10-enforce-api-version.sh 2718f3493bcb01c30c770169ac88eeacfffa4bb0414813d76beb62d6854b7b6e
do_verify customize.d/11-enforce-arch.sh cb4066ff670fce4b0d4c9df752808d25c9b93e99f6d3809a16e7637308b6cb90
do_verify customize.d/20-enforce-magisk-version.sh 39c4cf061fd705ddfa9c3c473d4d506295dd2b409c933a2cd5fa46057a8bf7ef
do_verify customize.d/25-check-incompatible-module.sh 8574e539dfb713a83bedd94bb8e2187fe9fcc1e4a2c06632055925760b6f0fd2
do_verify customize.d/30-place-libraries.sh 6eb1ac5b571614f9c0a782c5daf82ff72ac8ee5b61b63855c55d3c1152071f66
do_verify customize.d/40-initialize-data-directory.sh 033a15bea05c7583250931c31508597a64a387e9e24535e86c0759e29dc4a49d
do_verify customize.d/90-restore-module-permission.sh 0f36308f5bd915778712ef2abd003628ea6178614a56455a8ac171f6b2a6b8cd
do_verify daemon 3ab846f2190a4528e5e7b1a42d752d712fd8873a56c8200fbc5eb41924973cd2
do_verify daemon.apk 9ef7522e4bf2ec1fffd2915c40bd737e7f69acde36204baa86eb2bb99092af1b
do_verify module.prop 02a5925fa9f63b8bbf280f49609904fa1c11222a62ef319d514ad4a4e2913ee2
do_verify post-fs-data.sh 324b919278869b862215c2488db55a7b4d9451d539d30ddcf42ba8f5400dbe49
do_verify sepolicy.rule 7e5d4daec1483f8a29fafecefefae9c074471cfbf4829fe7825a88c147d9bace
do_verify service.sh 38c8926dedfec18a6ff2dbf31bfaba3c7b316b3de0720306c1e998eff9739252
do_verify uninstall.sh f7bfcf59f645b48c830b35d61dd357fccb1fb67e2fc49c11a83b2963548b73a0
do_verify zygisk/arm64-v8a.so 96d402b23fa08c60a05ae8a5cff3b9f77ab9e513fbe1665c9314f6d1340605d0
do_verify zygisk/armeabi-v7a.so d1c755f8337f5e42a2fa01a3d59c9fd574f8e5ec320c2abc3c4905ec273d98c9
do_verify zygisk/x86.so cd997497a5fddea00613225795c5770dd38aa5e18d6c3038d19759f50974c63d
do_verify zygisk/x86_64.so dc5b251bbdfecd9891469605eb39ab269ba3dc23d50aa226724a94c9b0396e2f


unset -f do_verify