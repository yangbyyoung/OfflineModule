#!/system/bin/sh
MODDIR=${0%/*}
sleep 5

am kill tcpdump
killall -9 tcpdump

am kill cnss_diag
killall -9 cnss_diag

stop cnss_diag 2> /dev/null
killall -9 cnss_diag 2> /dev/null

stop tcpdump 2> /dev/null
killall -9 tcpdump 2> /dev/null

#清理wifi 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs