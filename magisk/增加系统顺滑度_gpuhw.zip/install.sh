
SKIPMOUNT=true
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

 RIRU_PATH="/data/misc/riru"

 print_modname() {
  ui_print "*******************************"
  ui_print "增加系统顺滑度"
  ui_print "使用GPU进行屏幕合成"
  ui_print "by肖施主"
  ui_print "*********重启后生效**********"
}

 set_permissions() {

  set_perm_recursive $MODPATH 0 0 0755 0644

}
