#!/system/bin/sh
TMP=/sdcard/data/tmp/$$
SKIP=28
SCRIPT="系统优化_未加密.sh"
PROG="${TMP}/`basename $0`"
mkdir -m=rwx -p $TMP
touch $PROG
tail -n +$SKIP "$0" | base64 -d > ${PROG}.tar.gz
cd $TMP
tar -xzvf `basename $0`.tar.gz > /dev/null
cd $OLDPWD
if [ $? -eq 0 ]; then
  sh=`sed -n '1p' ${TMP}/${SCRIPT}`
  if echo "$sh" | grep '\#\!/.*' > /dev/null; then
    sh=${sh#*\#\!}
  else
    sh=$SHELL
  fi
  $sh ${TMP}/${SCRIPT} $@
  res=$?
  rm -rf $TMP
  exit $res
else
  echo "解包失败!" 1>&2
  rm -rf $TMP
  exit 1
fi
H4sIAAAAAAAAA+1WS1PbSBDm7F+hIucY8cx5N4etrdqqzSW1R5VsD7YqsqXoAUVONgnYJn4R7MUB
LwYCGJLCJkCI8SP8mPWMpBN/YXs0xnjBcMpmL/TBsqSe/r7p/ro11knTapY7rSJO/SmQ0ke8tIlr
i149NPT9jAebmuLhOjY+MUav/OiTJ0/c52CT/Pjk0OjE+PjkxNTY+OTkED/GT/GjQxz/HTncaaZu
iBrHDZm8IN4HGEYBSRS02R/B6QeajgxDigR1TjUNTp/TDRTmREkwTM2nCCgi+mQU4HgP8ocUDn89
xgsnzurhT7+CTJxoGbcKZCVz2Uox/ZC/ojiXwdmjv6MxO7pq5b94HnF3rMDZWqe5azUL9kUctxo4
cebE0zhX83gGMZqRZhQhKIaREUJaWJQFfVYy/KEeMReD1Oskkb2BQ/LfcLVN6gckU6G3pSQ+WiaF
o06jgbNpZy+Bay07fsrWOod5a/0d3vlMCgmgTlY3cStKg0eTztY5o+xE14AyScU7zR2GS3dTr1iZ
OCl+s5dXSTaH0/G/o/PkZJ+8yeJc2qocXbbW6B4YDLDBjb3LVuKKVpLBwJrB2w8gnxn0+pWwquiS
ISkRrzGnIi4wF+nuH5bnakHVZJsH6hCcPswu29EFxh5QSHIFHjprOXs123PmWFY69ahVSVvJhF07
JcWavRcjS0sAQPLnJJEDb7rLhTNc3cClfbgl9WNSXsHv98WAhiLK5CgPuenUl9yU0yWwFhJsR1Pk
S8wqLED8TmP9xvaCsuIT5avtqSZECnhn9LmIn5sWZR0N9A7NmpI3IOlUmgJzNjQT9SsBb8xb66c4
lyKHu5SQWxFWI+d9DrTW02W/533k9GkvawYhKAs+0f9C1ZCuA2FutNcbVpOKD198YrmhKmzsUaTb
DwciDftFfwgFBFFVdWFaQ+gV0oa54W4TDl/3oFttnClb+TLeXrG2lx+TtXkcK5Fkxd5KUSatFXxY
tNbe4Ebeyu9TDrfW3FQa8tPdDIsBUTWkGSToMkIqwM+IstQDd6PY8Y9OdB5CB5RXqNf81w1/2+kO
LFmJBAU3kYIhhZFiGoA3xvPDEMVqHVjlQ6dwQVJJ3DyzL8qA5DSLdnUHR1sTPE/rWjiC//bZUqed
gV8r9oUUshwpReF+lOdxs2FXq6Nj/GOI2Tl/66yeDuYRNmVDuk1kso8IzqZwvNkjMhC5n+A4fz0z
u/mp7HVH0Pop87e/lkny7X2qc6VOmwJpSOP0F5I4Y8ovxMh16IsqdBte/4bb292OvBp8zvs0kMNL
ZShMr0isB9j4tV+32eyzK4vO9jJObzlbF5etMnQtOfxAEsvkeMuJxXHiCLLQBXL18/uzX37rh4QX
nXqDsuMYvctWjCUCBgl1vlqdy9C9l2KgE647MaH3dtt3tAP0gRBGYUWbE+joo+WB0QeVcevS7V9X
4DjzFspEc+tOOFjI+qzTWiPFDIxl1oLAi4NHOL0Ja2DcwExyXu/jxCKJViAbdGRvxPARFDI2kJHo
9yMZaaIBTdrtSmFa0QRRlmEMPOIAlzbZ0n53DP9bAF2qrgOjR+vgcmGwT589Z5XBF22oicejwuRn
c46DBHhfmqIMV/hjSN6XfkVWNOpiRqQInGGAw11OVzzsyge8eEKF0agCvLNadbaLVOJ7Mcrs/Ayn
63a77Xwq0o9c8hi3D6zqlpVbBFo31t6n2qAGZBT/1cCc9gmmb9bfNyi70vycxeeFnkBx4gBIPP/5
j6fX4yqXoryqbVzfYyWmryFBtwMM5qMiTZd0wwufUS98XYLIJSTq4Kv38QEoirO4AEMTr2+Q/Bmr
GCVyxyuX8DtKM71lJePuB/Qjc3PiS/TQ4TrDOYJslFxyqqaoPUL0LOD1iYaBQNwhJMpGSNBNVVU0
o5+XmwUJaoCrZxAc+oZ83sSxXdz4CqK2dhq0z5mCSw288ZZ1daeeJvkaScU8biQWrtPehO9BfwQ4
knj8osGNQHZG/DJkZWTaRLJuhsOiNjeiKyHP/304fbAHe7AHe7D/zP4BpsrRFgASAAA=
