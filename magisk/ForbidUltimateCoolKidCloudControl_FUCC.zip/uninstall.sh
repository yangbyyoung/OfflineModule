#!/system/bin/sh
#设置-广播接收器
pm enable com.android.settings/com.android.settings.cloud.UpdateReleaseDataReceive
pm enable com.android.settings/com.android.settings.search.provider.UpdateReceiver
pm enable com.android.settings/com.android.settings.cloud.push.CloudService
#录音机
pm enable com.android.soundrecorder/com.market.sdk.DownloadCompleteReceiver
#小米画报
pm enable com.mfashiongallery.emag/com.market.sdk.DownloadCompleteReceiver
#计算器
pm enable com.miui.calculator/com.market.sdk.DownloadCompleteReceiver
#电量和性能
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.analysis.SettingUploadJobService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
#手机管家
pm enable com.miui.securitycenter/com.miui.permcenter.root.RootUpdateReceiver
pm enable com.miui.securitycenter/com.miui.antivirus.receiver.UpdaterReceiver
#joyose
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
pm enable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
pm enable com.xiaomi.joyose/predownload.PreDownloadJobScheduler
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
#耗电检测
pm enable com.xiaomi.powerchecker/com.xiaomi.powerchecker.cloudcontrol.CloudUpdateJobService
#应用商店
pm enable com.xiaomi.market/com.xiaomi.market.ui.AboutPreferenceFragmentActivity
pm enable com.xiaomi.market/com.xiaomi.market.ui.AboutPreferenceActivity
pm enable com.xiaomi.market/com.miui.share.weibo.WeiboShareActivity
pm enable com.xiaomi.market/com.sina.weibo.sdk.component.WeiboSdkBrowser
pm enable com.xiaomi.market/com.sina.weibo.sdk.web.WebActivity
pm enable com.xiaomi.market/com.xiaomi.market.business_ui.widget.NewGameWidgetProvider
pm enable com.xiaomi.market/com.xiaomi.market.business_core.push.mi_push.PushGameFloatingNotificationReceiver
pm enable com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
#MIUI质量服务
pm enable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm enable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService

pm clear com.xiaomi.joyose
#清除数据joyose
pm clear com.xiaomi.powerchecker
#清除数据耗电检测

rm /data/vendor/thermal/config/*
