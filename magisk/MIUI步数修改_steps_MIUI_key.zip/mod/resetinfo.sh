#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

install_magisk_busybox 2>/dev/null

id="$(echo "${0%/*}" | cut -d'/' -f5)"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"


#今日步数
function show_steps(){
today="$(date -d "$(date +%Y-%m-%d)" +%s)000"
local number=0
local count="$(content query --uri content://com.miui.providers.steps/item --projection _steps --where "_end_time>"$today"" 2>/dev/null | cut -d'=' -f2 )"
test "$(echo "$count" | sed '/^#/d;/^[[:space:]]*$/d' | grep -w '^[[:digit:]]*$')" = "" && count="0"
for i in $count
do
	((number+=i))
done
echo "$number"
}

#修复描述消失
function check_description() {
local description_file="${MODPATH}/module.prop"
local count="$(cat $description_file | grep "^description=" | wc -l)"
local count_all="$(cat $description_file | wc -l)"
if test $count -lt 1 ;then 
	sed -i "/^description=/d" "$description_file"
	sed -i ""$count_all"i description=[已修复]因意外关闭导致的模块描述消失😂！" "$description_file"
	sed -i '/^[[:space:]]*$/d' "$description_file"
fi
}


#修改模块信息
function write_module_info(){
local target_file="$MODPATH/module.prop"
check_description
sed -i "/^description=/c description=今日步数 [ $(show_steps) ]" "${target_file}"
}

write_module_info

