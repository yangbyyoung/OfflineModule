# FCMHostsForChina

## Introduction
Modify Hosts file.

## Changelog
### v0.1
- First Release.

# Links
[Author's Blog](https://blog.minamigo.moe)