#!/system/bin/sh
su -c chmod 000 /mnt/vendor/persist/data