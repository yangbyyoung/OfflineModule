#!/system/bin/sh
rm /data/media/0/Android/ASGuard.txt
rm /data/media/0/Android/ASGuard.txt.bak
rm /data/media/0/Android/EAS.txt
rm /data/media/0/Android/log_ASG.txt
exit 0