
function set_value() {
	if test -f "$2" ;then
		chmod 0777 "$2" > /dev/null 2>&1
		echo "$1" > "$2"
		chmod 0755 "$2" > /dev/null 2>&1
	fi
}



#swap参数调整
set_value '100' /proc/sys/vm/swappiness
set_value '100' /proc/sys/vm/vfs_cache_pressure
#禁用自适应lmk
set_value '0' /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
#禁用lmk调试(解放性能)
set_value '0' /sys/module/lowmemorykiller/parameters/debug_level

#vm参数调整
set_value "1" /proc/sys/vm/panic_on_oom
set_value "0" /proc/sys/vm/oom_kill_allocating_task
set_value "0" /proc/sys/vm/oom_dump_tasks

#lmk调整
#echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree

until $(dumpsys deviceidle get screen) ;do
	sleep 5
done

settings put global activity_manager_constants max_cached_processes=128



