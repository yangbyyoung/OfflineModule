#清理白名单

id="app_Accessibility_crond"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
file=$MODPATH/Conf/电池优化白名单.conf

export PATH=/system/bin:$MODPATH/busybox:$PATH

if test -e $MODPATH/disable -o -e $MODPATH/remove; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

function weip_white_app (){
cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function set_white_app (){
cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' | while read package ;do
dumpsys deviceidle whitelist +$package
done
}


dumpsys deviceidle whitelist | cut -d ',' -f2 | grep -Ev "$(weip_white_app)" | while read package ;do
	dumpsys deviceidle whitelist -$package
done

set_white_app

sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，优化一次电池白名单。配置文件在[ $file ]，可以自行更改。" $MODPATH/module.prop


