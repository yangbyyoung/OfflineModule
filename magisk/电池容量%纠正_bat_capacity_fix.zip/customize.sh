if [[ ! -f /sys/class/power_supply/bms/capacity_raw ]]; then
  echo '此模块不适用于您的设备'
  exit 1
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/bat_capacity_fix 0 0 0755 0755