
set_perm_recursive "$MODPATH" 0 0 0777 0777

ui_print "______________________________"
ui_print " "
ui_print " "
ui_print "SUCCESSFULLY INSTALLED."
ui_print " "
ui_print "______________________________"

