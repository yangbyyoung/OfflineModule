. ./config.ini
./核心文件勿动/"$exec".bin stop