#更新hosts
fuckad
dd if=/data/adb/modules/AD_lite/ADhosts of=/data/adb/modules/AD_lite/system/etc/hosts
setprop net.dns1 223.5.5.5
setprop net.dns2 223.6.6.6