MODDIR=${0%/*}
test ! -e $MODDIR/log && mkdir -p $MODDIR/log
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH

# 移除云温控
dir1="/data/vendor/thermal/config"
dir2="/data/thermal/config"

busybox="/data/adb/magisk/busybox"
alias chattr="/data/adb/magisk/busybox chattr"

function thermalkill(){
if test -e ${1%/*};then
chattr -i -a -A ${1%/*}
rm -rf ${1%/*}
touch ${1%/*}
chmod 000 ${1%/*}
chattr +i ${1%/*} && echo "$(date +%y年%m月%d日%H点%M分): 移除云温控成功！" >>$MODDIR/log/thermal.log || echo "$(date +%y年%m月%d日%H点%M分): 移除云温控失败！" >>$MODDIR/log/thermal.log
fi
}

thermalkill $dir1 2>/dev/null
thermalkill $dir2 2>/dev/null

set_value() {
	[ ! -f "$2" ] && return 1
    chmod +w "$2" 2> /dev/null
	if ! echo "$1" > "$2" 2> /dev/null
	then
		echo "$(date +%y年%m月%d日%H点%M分): - 写入失败: $2 → $1" >> $MODDIR/log/thermal.log
		return 1
	fi
		echo "$(date +%y年%m月%d日%H点%M分): - 写入成功: $2 → $1" >> $MODDIR/log/thermal.log
}

set_value "250" /sys/class/power_supply/bms/temp
set_value "250" /sys/class/power_supply/battery/temp
