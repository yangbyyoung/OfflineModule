
MODDIR=${0%/*}

