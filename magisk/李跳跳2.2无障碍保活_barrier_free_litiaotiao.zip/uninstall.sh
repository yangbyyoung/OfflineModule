#!/system/bin/sh
rm -rf /data/adb/modules/barrier_free_litiaotiao
rm -rf /date/dalvik-cache/* | rm -rf /date/system/package_cache/*