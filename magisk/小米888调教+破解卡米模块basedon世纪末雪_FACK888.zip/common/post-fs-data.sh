#! /vendor/bin/sh
MODDIR=${0%/*}

# 设置lmk
# setprop sys.lmk.minfree_levels 12800:0,16384:100,18432:200,24576:250,32768:900,49152:950
# stop lmkd
# start lmkd

# 开机日志系统
rm -rf  /cache/*
{
dmesg
} >>/cache/kernel.log
{
logcat -d
} >>/cache/system.log
{
logcat -d | grep error
} >>/cache/error.log
{
dmesg | grep error
} >>/cache/error.log
{
su -c "dmesg | grep volt="
} >>/cache/CPU.log
{
dmesg | grep gfx3d_clk_src
} >>/cache/GPU.log
{
lsmod
} >>/cache/modules.log