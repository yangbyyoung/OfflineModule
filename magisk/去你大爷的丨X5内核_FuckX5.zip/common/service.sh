#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
  while :;do
function kx5()
{
rm -rf $1
touch $1
chmod 000 $1
}

A=`find /data/data -iname '*app_tbs*' -type d -print`
B=`find /data/data -iname '*app_tbs_64*' -type d -print`
C=`find /data/media -name '*.tbs.*' -print -type f`
D=`find /data/data -iname '*app_xwalk*' -print -type d`
E=`find /data/data -iname '*app_x5webview*' -print -type d`

for i in $A;do
kx5 $i 2>/dev/null
done

for i in $B;do
kx5 $i 2>/dev/null
done

for i in $C;do
kx5 $i 2>/dev/null
done

for i in $D;do
kx5 $i 2>/dev/null
done

for i in $E;do
kx5 $i 2>/dev/null
done

sleep 24h

done 
echo "X5内核清除服务进程运行完毕,当前时间: $date "