#!/system/bin/sh
MODDIR=${0%/*}
MODPATH=$MODDIR
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

sleep 5
chmod -R 777 $MODDIR/keymod
source $MODDIR/keymod/path.sh
cp -rf $MODPATH/脚本/* $(dirname $(dirname $Backup_path))
targetdir=/data/media/0/Android/Magisk备份
test ! -e $targetdir && mkdir -p $targetdir
cp -rf $MODPATH/keymod/magiskbackup.sh $targetdir
for i in `find $targetdir -iname "path.sh" `;do
	cp -rf $MODPATH/keymod/path.sh "$i"
done
chmod -R 777 $(dirname $(dirname $Backup_path))


crond -c $MODDIR/timetable

writemodulesinfo(){
	local file=$MODPATH/module.prop
	timesleep=`cat $timetablefile |tr -cd "[0-9]"`
	test $timesleep == 10  && timesleep='10分钟'
	test $timesleep == 30  && timesleep='30分钟'
	test $timesleep == 01  && timesleep='1个小时'
	test $timesleep == 001  && timesleep='1天'
	test $timesleep == 03  && timesleep='3个小时'
	test $timesleep == 06  && timesleep='6个小时'
	sed -i "/^description=/c description=备份文件在 "$(dirname $(dirname $Backup_path))"。模拟终端输入magiskbackup，可以选择恢复或者备份模块，您也可以在备份目录恢复或者备份模块。备份时间间隔为: "$timesleep" " $file
}
writemodulesinfo
