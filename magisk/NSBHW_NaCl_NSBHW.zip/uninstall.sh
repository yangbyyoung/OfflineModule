dd if=/data/adb/modules/NaCl_NSBHW/bak/dtbo_a of=/dev/block/by-name/dtbo_a
dd if=/data/adb/modules/NaCl_NSBHW/bak/dtbo_b of=/dev/block/by-name/dtbo_b
rm -rf /data/system/package_cache/*
rm -rf /data/adb/service.d/Run.sh
rm -rf /data/adb/service.d/ME.sh
rm -rf /data/adb/service.d/Optimize.sh
rm -rf /data/adb/service.d/DC.sh