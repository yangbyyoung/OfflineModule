rmx="resetprop --delete dalvik.vm.dex2oat-flags"
su -c $rmx 