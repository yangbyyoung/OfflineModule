#!/system/bin/sh
/data/adb/modules/S-T-E-P-S/Script/Author_Information/Coolapk