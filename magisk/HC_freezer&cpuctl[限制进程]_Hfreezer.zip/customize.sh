SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************
 "

confpz="/sdcard/Android/Hgroups"
mkdir /sdcard/Android/Hgroups
echo "/data/adb/modules/Hfreezer/Q.sh" >/sdcard/Android/Hgroups/加入Q反馈群.sh
echo "#需要暂停的进程名字，是暂停限制cpu使用率不是kill" >${confpz}/freezer.conf.bei
sed "1,/^#需要暂停的进程名字，是暂停限制cpu使用率不是kill/d" "${confpz}/freezer.conf" >>${confpz}/freezer.conf.bei
confif=$(cat ${confpz}/freezer.conf.bei | grep "切勿删除此行")
if [[ $confif == "#切勿删除此行#" ]]; then
	cat $MODPATH/freezer.conf >${confpz}/freezer.conf
	sed -i '/#需要暂停的进程名字，是暂停限制cpu使用率不是kill/,$d' ${confpz}/freezer.conf
	cat ${confpz}/freezer.conf.bei >>${confpz}/freezer.conf
	rm -rf ${confpz}/freezer.conf.bei
else
	rm -rf ${confpz}/freezer.conf.bei
	cat $MODPATH/freezer.conf >${confpz}/freezer.conf
fi
rm -rf $MODPATH/freezer.conf

set_perm_recursive $MODPATH 0 0 0755 0777