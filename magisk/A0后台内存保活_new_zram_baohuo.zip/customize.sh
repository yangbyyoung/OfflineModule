DUBUG_FLAG=false
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""
sponsor() {
    echo "#################################
 - 按音量键＋: 赞助作者
 - 按音量键－: 爷没钱
#################################"
    while true; do
        choose="$(getevent -qlc 1 | awk '{ print $3 }')"
        case "${choose}" in
            KEY_VOLUMEUP)
                echo "感谢支持"
                am start -a android.intent.action.VIEW -d https://afdian.net/a/MoWei_2077 >/dev/null &
                break
                ;;
            KEY_VOLUMEDOWN)
                break
                ;;
            *)
                continue
                ;;
        esac
    done
}
# 赞助支持
if [[ ! -f $freezer_path/.sponsor ]]; then
    sponsor
    echo 'yes' > $freezer_path/.sponsor
fi
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
module_version="`grep_prop version $TMPDIR/module.prop`"
module_name="`grep_prop name $TMPDIR/module.prop`"
module_id="`grep_prop id $TMPDIR/module.prop`"
  ui_print "-------------------------------------"
  ui_print "- $module_name "
  ui_print "- 作者: 魔威"
  ui_print "- 版本: $module_version"
  ui_print "-------------------------------------"
  ui_print "- 机型: $var_device"
  ui_print "- 安卓版本: $var_version"
  ui_print "安装脚本马上开始"
  sleep 3
  ui_print "使用freezer V1的请慎用 因为freezerV1的内存泄漏 导致乖巧模式结束不了进程 冻它暂时没有任何结束不了线程的问题"
  ui_print "此模块支持墓碑 A1 V4 scene附加模块 潘多拉内核 捕食者内核"
  ui_print "请稍等正在写入代码中"
mkdir /sdcard/Android/MW_A0
echo "#别问为什么我写了进程锁还要写强力保活 因为有些系统不支持进程锁
# 进程锁 强力保活 微信已添加
com.tencent.mm
# 乖巧模式 名单来自酷安:hchai
#酷安
kill com.coolapk.market:xg_vip_service
#腾讯视频
kill com.tencent.qqlive:cache
kill com.tencent.qqlive:wxa_container0
kill com.tencent.qqlive:services
kill com.tencent.ilink.ServiceProcess
kill com.tencent.qqlive:pmservice
kill com.tencent.qqlive:mini1
#kill com.tencent.qqlive:xg_vip_service
#虎牙
kill com.duowan.kiwi:remoteweb
kill com.duowan.kiwi:logcat
kill com.duowan.kiwi:lelinkps
kill com.duowan.kiwi:cloudpatch
kill com.duowan.kiwi:Unity
kill com.duowan.kiwi:download
kill com.duowan.kiwi:pushservice
#QQ
kill com.tencent.mobileqq:mini3
kill com.tencent.mobileqq:mini
kill com.tencent.mobileqq:tool
kill com.tencent.mobileqq:picture
kill com.tencent.mobileqq:video
kill com.tencent.mobileqq:peak
kill com.tencent.mobileqq:qzone
kill com.tencent.mobileqq:TMAssistantDownloadSDKService
kill com.tencent.mobileqq:qlink
kill com.tencent.mobileqq:mini2
kill com.tencent.mobileqq:wxa_container0
kill com.tencent.mobileqq:mini1
#微信
kill com.tencent.mm:appbrand0
kill com.tencent.mm:appbrand1
kill com.tencent.mm:appbrand2
kill com.tencent.mm:appbrand3
kill com.tencent.mm:appbrand4
kill com.tencent.mm:hotpot..
kill com.tencent.mm:support
kill com.tencent.mm:toolsmp
kill com.tencent.mm:tools
#腾讯云
kill com.qq.qcloud:wns
#腾讯视频
kill com.tencent.qqlive:cache
kill com.tencent.qqlive:services
#百度网盘
kill com.baidu.netdisk:operator_thumbnail
kill com.baidu.netdisk:p2p
#百度贴吧
kill com.baidu.tieba:media
kill com.baidu.tieba:swan0
kill com.baidu.tieba:remote
kill com.baidu.tieba:bdservice_v1
#美团
kill com.sankuai.meituan:miniApp0
kill com.sankuai.meituan:MgcProcess
kill com.sankuai.meituan.takeoutnew:download
kill com.sankuai.youxuan:download
kill com.sankuai.meituan.takeoutnew:dppushservice
#小红书
kill com.xingin.xhs:longlink
kill com.xingin.xhs:pushservice
#淘宝
kill com.taobao.taobao:channel
kill com.taobao.taobao:sandboxed_privilege_process0
kill com.taobao.taobao:gpu_process
#支付宝
kill com.eg.android.AlipayGphone:tools
kill com.eg.android.AlipayGphone:push
kill com.eg.android.AlipayGphone:lite1
kill com.eg.android.AlipayGphone:gpu_process
kill com.eg.android.AlipayGphone:sandboxed_privilege_process0
kill com.eg.android.AlipayGphone:widgetProvider
#京东
kill com.jingdong.app.mall:jdpush
kill com.jingdong.app.mall:manto0
kill com.jingdong.app.mall:WatchDogService
#拼多多
kill com.xunmeng.pinduoduo:titan
kill com.xunmeng.pinduoduo:support
kill com.xunmeng.pinduoduo:isr:com.xunmeng.pinduoduo.secure.IService
kill com.xunmeng.pinduoduo:sandboxed_process0
kill com.xunmeng.pinduoduo:lifecycle
#哔哩哔哩
kill tv.danmaku.bili:pushservice
kill tv.danmaku.bili:download
kill tv.danmaku.bili:web
#优酷
kill com.youku.phone:gpu_process
kill com.youku.phone:sandboxed_privilege_process0
kill com.youku.phone:channel
#爱奇艺
kill com.qiyi.video:downloader
#微博
kill com.sina.weibo:remote
#WPS Office Lite
kill cn.wps.moffice_i18n:overseabackground
kill cn.wps.moffice_i18n:scan
kill cn.wps.moffice_i18n:writer1
kill cn.wps.moffice_i18n:gcmpush
kill cn.wps.moffice_i18n:vas
#快手
kill com.smile.gifmaker:messagesdk
kill com.smile.gifmaker:mini0
kill com.smile.gifmaker:mm
kill com.smile.gifmaker:lelinkps
kill com.smile.gifmaker:commonMiniService
#中国移动
kill com.greenpoint.android.mc10086.activity:AgentService
#抖音
kill com.ss.android.ugc.aweme:pushservice
kill com.ss.android.ugc.aweme:push
kill com.ss.android.ugc.aweme:sandboxed_process1
kill com.ss.android.ugc.aweme:miniappX
kill com.ss.android.ugc.aweme:downloader
#QQ飞车
kill com.tencent.tmgp.speedmobile:tgaPlugin
kill com.tencent.tmgp.speedmobile:xg_vip_service
#DevCheck Pro
flar2.devcheck:Monitors
#夸克
kill com.quark.browser:gpu_process
kill com.quark.browser:sandboxed_privilege_process0
kill com.quark.browser:push
kill com.quark.browser:channel
#小米运动健康
kill com.mi.health:device
#百度
kill com.baidu.searchbox:swan0
kill com.baidu.searchbox:widgetProvider
kill com.baidu.searchbox:titanSandbox
kill com.baidu.searchbox:bdservice_v1
#酷安
kill com.coolapk.market:xg_vip_service
#网易云音乐
kill com.netease.cloudmusic:cmMP1
kill com.netease.cloudmusic:browser
kill com.netease.cloudmusic:viewer
kill com.netease.cloudmusic:videoplay
#百度地图
kill com.baidu.BaiduMap:SandBoxProcess
kill com.baidu.BaiduMap:bdservice_v1
kill com.baidu.BaiduMap:na
#12306
kill com.MobileTicket:push
kill com.MobileTicket:tools
#电信营业厅
kill com.ct.client:pushcore
kill com.ct.client:remote
#银联
kill com.unionpay:pushservice
kill com.unionpay:pushservice
#智联招聘
kill com.zhaopin.social:core
#抖音极速版
kill com.ss.android.ugc.aweme:sandboxed_process1
kill com.ss.android.ugc.aweme:pushservice
#番茄小说
kill com.dragon.read:push
kill com.dragon.read:pushservice
kill com.dragon.read:sandboxed_process1
kill com.dragon.read:sandboxed_process2
kill com.dragon.read:sandboxed_process3
#虎扑
kill com.hupu.games:pushcore
kill com.hupu.games.sdk.PushService
kill com.hupu.games/org.chromium
#WPS Office Lite
kill cn.wps.moffice_i18n:overseabackground
kill cn.wps.moffice_i18n:scan
kill cn.wps.moffice_i18n:writer1
kill cn.wps.moffice_i18n:gcmpush
kill cn.wps.moffice_i18n:vas
#光速体育直播
kill com.sports.gsty:core
kill com.sports.gsty:ipc
#ACfun
kill tv.acfundanmaku.video:push_helper
kill tv.acfundanmaku.video:compatibility
kill tv.acfundanmaku.video:messagesdk
kill tv.acfundanmaku.video:lelinkps
#QQ邮箱
kill com.tencent.androidqqmail
kill com.tencent.androidqqmail:Push
#QQ阅读
kill com.qq.reader:pushcore
#Tim
kill com.tencent.tim:mail
kill com.tencent.tim:web
kill com.tencent.tim:peak
kill com.tencent.tim:troop
#WPS Office
kill cn.wps.moffice_eng:onlineParams
kill cn.wps.moffice_eng:socket
kill cn.wps.moffice_eng:scan
kill cn.wps.moffice_eng:widgetProvider
kill cn.wps.moffice_eng:pushservice
kill cn.wps.moffice_eng:gcmpush
kill cn.wps.moffice_eng:writer1 
#小米应用商店
kill com.xiaomi.market
kill com.miui.screenrecorder
#小米bug反馈
kill com.miui.bugreport
#MIUI分析工具
kill com.miui.analytics
#云控
kill com.xiaomi.joyose
kill com.xiaomi.mi_connect_service" > /storage/emulated/0/Android/MW_A0/config.txt
ui_print "乖巧模式写入完成 将开始写入面板"
sleep 2
echo "/data/adb/modules/new_zram_baohuo/终端配置.sh" > /sdacard/Android/MW_A0/启动面板.sh
ui_print "面板写入完成 正在写入system.prop"
echo " # 这个文件将被 resetprop 读取
# 示例: 改变 dpi
# 开启zram
ro.config.zram=true
# 关闭swap
ro.config.swap=false
# 关闭LMK日志
ro.lmk.debug=false
# 内存回收优化
persist.sys.purgeable_assets=1
# 禁止安卓LMK杀掉占用很大内存的缓存进程
ro.sys.fw.bg_apps_limit=64
ro.sys.fw.empty_app_percent=50
ro.sys.fw.trim_empty_percent=100
# 指定设备为高性能模式
ro.config.low_ram=false
# 保持应用程序在后台运行
ro.sys.fw.bg_apps_limit=1000
# 取消procfs接口修改adj保活应用
ro.sys.fw.use_procfs_adj=0
# 禁用lmkd结束进程
persist.sys.lmk.disable_process_reclaim=1
# 以下代码均来自酷安大佬:开心小阳光123
# 参数优化
ro.lmk.thrashing_limit=100
ro.lmk.thrashing_limit_decay=10
ro.lmk.use_new_strategy=true
ro.lmk.psi_partial_stall_ms=750
ro.lmk.psi_complete_stall_ms=1000
ro.lmk.use_minfree_levels=true
# 其他优化
lmkd.reinit=0
persist.sys.lmk.camera_minfree_6g_levels=18432:1001,23040:1001,27648:1001,64512:1001,276480:1001,362880:1001
persist.sys.lmk.camera_minfree_levels=18432:1001,23040:1001,27648:1001,64512:1001,276480:1001,362880:1001
persist.sys.lmk.reportkills=false
sys.lmk.minfree_levels=4096:1001,5120:1001,8192:1001,32768:1001,96000:1001,131072:1001
sys.lmk.reportkills=0
persist.sys.mms.write_lmkd=false
persist.sys.oom_crash_on_watchdog=false
# SWAP不足比例
ro.lmk.swap_free_low_percentage=10
# 低内存压力
ro.lmk.low=1001
# 中等内存压力
ro.lmk.medium=1001
# 内存占用达到临界值时可杀死的进程
ro.lmk.critical=1001
# 是否允许将medium级压力上升为critical级压力
ro.lmk.critical_upgrade=false
# SWAP/ZRAM用量比例
ro.lmk.upgrade_pressure=100
# pressure大于该值允许将critical降为medium级别压力
ro.lmk.downgrade_pressure=100
# 在内存不足时杀死最"胖"的进程
ro.lmk.kill_heaviest_task=false
# 杀完一个进程后多久再检杀下一个
ro.lmk.kill_timeout_ms=1001
# 增强批量的kill
ro.lmk.enhance_batch_kill=false
# 自适应lmk，内存波动大杀的更积极
ro.lmk.enable_adaptive_lmk=false
persist.sys.usap_pool_enabled=true
ro.iorapd.enable=true
vm.dirty_ratio=75
vm.dirty_background_ratio=15" > /data/system.prop
echo "# 获取 Android 版本号
android_version="$(getprop ro.build.version.release)"

# 检查 Android 版本号
if [[ "$android_version" == "1"* ]] || [[ "$android_version" == "2"* ]] || [[ "$android_version" == "3"* ]] || [[ "$android_version" == "4"* ]] || [[ "$android_version" == "5"* ]] || [[ "$android_version" == "6"* ]] || [[ "$android_version" == "7"* ]] || [[ "$android_version" == "8"* ]] || [[ "$android_version" == "9"* ]]; then
    echo "您的 Android 版本为 $android_version"
    su -c /data/adb/modules/new_zram_baohuo/lock.sh
    chmod A+RAW /data/adb/modules/new_zram_baohuo/lock.sh
    echo "进程锁已开启"
else
    echo "您的 Android 版本为 $android_version"
    echo "进程锁不支持此安卓 只支持安卓10-11 已自动为您开启强力保活"
rm -rf /data/adb/modules/new_zram_baohuo/lock.sh
rm -rf /sdcard/Android/MW_A0/检测是否支持进程锁.sh
fi" > /sdcard/Android/MW_A0/检测是否支持进程锁.sh
ui_print "代码写入完成"
sleep
ui_print "模块安装完毕 请重启"
exit 0