#!/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/HMS_CORE_KEY"
CROND_FILE=$MODPATH/crond/root
busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
test -e "$magiskbusybox" && {
	chmod 0755 "$magiskbusybox"
	mkdir -p "$busyboxdir"
	echo "－ 安装Magisk的busybox 中……"
	$magiskbusybox --install -s $busyboxdir && echo "－ 完成！" || echo "－ 错误！"
} || echo "－ 您的magisk busybox 怎么不见了？"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

function show_value() {
	local value=$1
	local file=$MODPATH/模块配置.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g;s/，/,/g;s/——/-/g;s/：/:/g;s/[[:space:]]//g'
}

if test $(show_value "华为机型") == HUAWEINova8Pro; then
	echo '
#HUAWEI Nova 8 Pro
ro.product.manufacturer=HUAWEI
ro.product.brand=HUAWEI
ro.product.model=BRQ-AN00
#END
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMate40; then
	echo '
#HUAWEI Mate 40 
ro.product.manufacturer=HUAWEI
ro.product.brand=HUAWEI
ro.product.model=NOP-AN00-PD
#END 
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMateX5G; then
	echo '
#HUAWEI Mate X 5G
ro.product.brand=HUAWEI
ro.product.manufacturer=HUAWEI
ro.product.model=TAH-AN00
#END
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMate40Pro; then
	echo '
#HUAWEI Mate40 Pro
ro.product.brand=HUAWEI
ro.product.manufacturer=HUAWEI
ro.product.model=NOP-AN00
#END
' >$MODPATH/system.prop
fi

if test $(show_value "修改为华为机型") == 否; then
	rm -rf $MODPATH/system.prop
fi

function set_crond_hms() {
	mkdir -p ${CROND_FILE%/*}
	script_file1=${CROND_FILE%/*}/keepalivetask.sh
	cat <<"key" >$script_file1

pross=$(pgrep -f 'com.huawei.hwid' | wc -l )

if test "$pross" -lt 1 ;then
am start -n com.huawei.hwid/com.huawei.hms.core.activity.JumpActivity 2>/dev/null
sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，为您保活HMS 服务一次，杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
fi
key
	sed -i "s/.*keepalivetask.sh//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	echo "*/"$(show_value "HMS保活定时任务时间")" * * * * $MODPATH/crond/keepalivetask.sh" >>$CROND_FILE
	sed -i "2i MODPATH=$MODPATH" $script_file1
	sed -i "2i export PATH=$MODPATH/busybox:/system/bin:\$PATH" $script_file1
	chmod -R 777 $MODPATH/crond
	pgrep -f "crond -c ${CROND_FILE%/*}" | while read pid; do kill -9 $pid; done
	crond -c ${CROND_FILE%/*}
}

function set_crond_QQ() {
	mkdir -p ${CROND_FILE%/*}
	script_file2=${CROND_FILE%/*}/killhms.sh
	cat <<"key" >$script_file2
#!/system/bin/sh
function topapp() {
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
	echo "$app"
}

function whitelist() {
	local file=$MODPATH/crond/游戏白名单.conf
	cat $file | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function qq_av() {
	possess="$(pgrep -f "com.tencent.mobileqq:video" | wc -l)"
	if test $possess -ge 1; then
		sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，QQ通话中，暂停所有活动。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
		exit 0
	fi
}

qq_av

function killall_hms_wakeup_pross() {
	test "$(topapp)" = "$1" && exit 0
	pgrep -f "$1" | while read pid; do
		test "$(cat /proc/$pid/cpuset)" = "/background" && {
			sleep $cleartime
			qq_av
			if test "$(echo "$(topapp)" | grep -E "$(whitelist)")" != "" -o "$(topapp)" = "$1"; then
				sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，进入白名单应用，暂停杀死应用"$1"。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
				exit 0
			fi
			kill -9 $pid && cleartime='1s'
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，杀死"$1"后台。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
		} || continue
	done
}

if test -e $MODPATH/disable -o -e $MODPATH/remove; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

cat $MODPATH/crond/华为推送应用.conf | sed '/^#/d;/^[[:space:]]*$/d' | while read package; do
	killall_hms_wakeup_pross "$package"
done


key
	sed -i "s/.*killhms.sh//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	echo "*/"$(show_value "定时杀死唤醒后台时间")" * * * * $MODPATH/crond/killhms.sh" >>$CROND_FILE
	sed -i "2i MODPATH=$MODPATH" $script_file2
	sed -i "2i export PATH=$MODPATH/busybox:/system/bin:\$PATH" $script_file2
	sed -i "2i cleartime="$(show_value "杀死唤醒后台延时")"" $script_file2
	chmod -R 777 $MODPATH/crond
	pgrep -f "crond -c ${CROND_FILE%/*}" | while read pid; do kill -9 $pid; done
	crond -c ${CROND_FILE%/*}
}

if test $(show_value "HMS保活定时任务") == 开启; then
	set_crond_hms
elif test $(show_value "HMS保活定时任务") == 关闭; then
	rm -rf $MODPATH/crond/keepalivetask.sh
fi

if test $(show_value "定时杀死唤醒后台") == 开启; then
	set_crond_QQ
elif test $(show_value "定时杀死唤醒后台") == 关闭; then
	rm -rf $MODPATH/crond/killQQ.sh
fi

if test $(show_value "定时杀死唤醒后台") == 关闭 -a $(show_value "HMS保活定时任务") == 关闭; then
	rm -rf $MODPATH/crond
fi
