MODDIR="$1"
# 编写: 酷安@董小豪

#------White白话君------
# 禁用阶梯式充电限制
echo '0' > /sys/class/power_supply/battery/step_charging_enabled
