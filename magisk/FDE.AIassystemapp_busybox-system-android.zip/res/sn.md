### Info AI

FDE memiliki implementasi AI, yang berfungsi pada perangkat apa pun seperti halnya FDE itu sendiri.
Tujuannya adalah untuk memeriksa skenario penggunaan saat ini dan menyesuaikan beberapa parameter
sistem dengan cepat untuk memberikan pengalaman terbaik setiap skenario penggunaan. Semua
boost/turbo secara otomatis MATI saat layar MATI. Semua tindakan AI akan dicatat. Bagian terbaik
dari semua ini adalah TIDAK akan menghabiskan baterai.

---

#### Apa yang diaktifkan secara otomatis bila memungkinkan:

**GPU Turbo**:\
AI akan mendeteksi jika GPU Anda dapat menjalankan implementasi FDE GPU Turbo & akan memberi tahu
Anda di log. GPU Turbo akan mengukur beban GPU, dan jika tetap tinggi (di bawah beban berat) AI akan
mendorong frekuensi maksimum GPU selama ~30 detik hingga pemeriksaan beban berikutnya terjadi.
Setelah beban GPU menurun, frekuensi awal akan dipulihkan. Ini tidak akan membuat game Anda berjalan
lebih cepat, tetapi harus membuatnya lebih cepat stabil, karena governor tidak akan melompat dari
satu frekuensi ke frekuensi lain di bawah beban berat. Ini bukan tergantung nama-paket - secara
langsung memonitor beban GPU untuk alasan apa pun (permainan, benchmark, dll.), membuat hal ini
universal. Ini juga bergantung pada termal - nilai ambang batas bersifat dinamis, itu tidak
akan meningkatkan sesuatu jika perangkat terlalu panas. Berfungsi hanya saat layar AKTIF. Didukung
di sebagian besar Adreno dan GPU Mali. Tidak akan bertentangan dengan implementasi Turbo GPU Huawei.

**Turbo GPU lama**:\
Mode Turbo ini akan dipilih jika driver kernel GPU Anda tidak memberikan info pemuatan real-time.
Perbedaan dari GPU Turbo biasa adalah yang Lama hanya akan meningkat pada proses / game apa pun
dari daftar aplikasi berat yang berjalan tanpa mengandalkan beban GPU real-time. Anda juga dapat
mengaktifkan Turbo GPU lawas konstan dengan mengalihkan mode AI ke performa secara manual.
Aktifkan opsi penambah game berat di pengaturan untuk membuat mode ini bekerja secara otomatis.
Aktif hanya saat layar AKTIF. Didukung pada beberapa GPU Mali & Vivante.

**Peningkatan framebuffer**:\
AI akan mendeteksi jika SoC Anda dapat menjalankan implementasi FDE Framebuffer boost & akan memberi
tahu Anda di catatan. AI secara otomatis meningkatkan frekuensi framebuffer, saat layar AKTIF
dan beban GPU lebih besar dari 30%. Ini akan menghasilkan framerate yang lebih stabil saat merender
layar. Aktif hanya saat layar HIDUP. Didukung pada beberapa SoC Qualcomm.

**CPU Turbo**:\
AI akan mendeteksi jika CPU Anda dapat menjalankan implementasi FDE CPU Turbo & akan memberi tahu
Anda di log. CPU Turbo akan mengukur beban CPU, dan jika tetap tinggi (di bawah beban berat) AI akan
membuat CPU governor lebih responsif dan akan membuatnya menjaga frekuensi CPU di atas
'freq kecepatan tinggi.' (~setengah dari maks frekuensi yang tersedia) selama ~30 detik hingga
pemeriksaan beban berikutnya terjadi. Ini bukan berdasarkan nama paket - tapi secara langsung
memantau beban CPU untuk alasan apa pun (permainan, benchmark, dll.), membuatnya universal.
Ini bergantung pada termal - nilai ambang bersifat dinamis, dan tidak akan meningkatkan hal-hal jika
perangkat terlalu panas. Aktif hanya saat layar AKTIF. Cocok dengan interactive, ondemand, schedutil
dan governor lainnya berdasarkan hal ini.

**Pembelajaran mesin**:\
Machine learning (ML) digunakan jika perangkat Anda mendukung CPU dan/atau GPU Turbo. ML akan
mempelajari cara Anda menggunakan perangkat Anda dan menyesuaikan beberapa parameter sistem dengan
cepat. Jika Anda sering bermain game, AI akan memberikan lebih banyak performa untuk Anda.
Jika Anda hanya mengobrol dan menonton video, AI akan menghemat daya. Jika Anda bermain dan
mengobrol, AI akan memutuskan apa yang harus dilakukan sendiri - itulah mesin ada untuk belajar.
Dalam perilaku aplikasi FDE.AI dari pilihan yang dilakukan oleh ML dapat dikonfigurasi untuk
selalu lebih memilih penghematan daya atau pengoptimalan performa.

**Tuner VM dinamis**:\
Memeriksa penggunaan RAM setiap ~30 detik dan menyetel beberapa parameter VM berdasarkan pemeriksaan
ini. Ini akan menghasilkan manajemen cache RAM yang lebih baik. Ini juga akan menginformasikan jika
sistem sangat rendah pada RAM bebas. Berfungsi hanya saat layar AKTIF.

**Pengontrol termal**:\
AI memeriksa suhu perangkat dan melaporkannya di log jika perangkat terlalu panas. Ambang batas
Turbo CPU/GPU dihitung berdasarkan nilai yang dibaca dari pengontrol termal, sehingga jika perangkat
Anda memanas CPU/GPU Turbo akan berhenti meningkatkan perangkat Anda dan/atau melakukannya
lebih jarang. Jika suhu perangkat terlalu tinggi, ini akan mengesampingkan pengaturan
proses & mengaktifkannya hingga suhu turun sedikit, setelah itu mengembalikan parameter
proses sebelumnya.

**Detektor status pengisian daya**:\
AI memeriksa apakah perangkat sedang diisi atau tidak. Jika sedang mengisi daya, AI mengonfigurasi
VM untuk kinerja optimal. Setelah Anda mencabut perangkat Anda, profil VM sebelumnya akan
dikembalikan apa yang dipelajari profil AI. Mode Force Doze (jika diaktifkan) juga bergantung
pada ini, mencegah dirinya berjalan saat perangkat sedang diisi. Fitur ini tidak meningkatkan
frekuensi apa pun dan hanya menyetel pengaturan VM, jadi ini tidak berbahaya dan tidak akan
membuat perangkat kepanasan. Jika pemrosesan dinonaktifkan oleh pengguna atau oleh AI
(untuk aplikasi/game berat) - ini akan diaktifkan kembali saat perangkat sedang diisi. Juga saat
AI masuk mode lanjutan, status hemat daya OS Android akan dipantau - jika diaktifkan, AI akan
secara otomatis disetel ke mode hemat daya dan tidak akan mengaktifkan mode performa.
