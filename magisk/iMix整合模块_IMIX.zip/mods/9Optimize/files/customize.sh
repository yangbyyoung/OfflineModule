SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/WCNSS_qcom_cfg.sh
#key_source $MODPATH/cp.sh
key_source $MODPATH/miui_thermal_set.sh
settings put global hide_error_dialogs 1
pm enable com.coolapk.market/com.coolapk.market.view.splash.SplashActivity
set_perm_recursive  $MODPATH  0  0  0755  0644

