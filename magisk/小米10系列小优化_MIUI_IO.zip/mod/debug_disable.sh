#禁用调试驱动
echo 0 > /sys/module/binder/parameters/debug_mask
echo 0 > /sys/module/binder_alloc/parameters/debug_mask
echo 0 > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo 0 > /sys/module/millet_core/parameters/millet_debug
echo 0 > /proc/sys/migt/migt_sched_debug
echo N > /sys/kernel/debug/debug_enabled
# 禁用binder调试(来自水龙的小技巧)
echo 0 > /sys/module/binder/parameters/debug_mask
echo 0 > /sys/module/binder_alloc/parameters/debug_mask