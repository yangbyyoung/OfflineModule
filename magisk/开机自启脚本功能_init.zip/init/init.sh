
sleep 60

for i in /data/adb/modules/init/sh/*.sh ;do
  chmod 777 $i
  /system/bin/sh $i
done