#!/system/bin/sh
MODDIR=${0%/*}
$MODDIR/B.sh 2>&1 1>/dev/null &