[ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ] && abort "! Unsupported platform: $ARCH"

ui_print "- Device arch: $ARCH"
