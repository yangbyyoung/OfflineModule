#!/system/bin/sh

while [ -z "$(/system/bin/chronyc tracking | grep Normal)" ]; do
  pkill chronyd
  /system/bin/chronyd -f /system/etc/chrony.conf
  sleep 10
done
