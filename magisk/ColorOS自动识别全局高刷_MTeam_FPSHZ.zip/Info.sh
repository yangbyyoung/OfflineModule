#!/system/bin/sh
MODDIR=${0%/*}
#通用路径
MODXinXi="/data/adb/modules/MTeam_FPSHZ/module.prop"

if [ ! -f "/data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/MTeams" ];then
sed -i "/^description=/c description=ColorOS全局高刷：自动识别档位、实现全局高刷，支持90Hz和120Hz的1080P与2K的全局高刷，熄屏自动关闭全局高刷、亮屏恢复全局高刷，配置文件在[ /sdcard/Android/ColorOS全局高刷 ]浏览：✲未运行" "$MODXinXi"
fi