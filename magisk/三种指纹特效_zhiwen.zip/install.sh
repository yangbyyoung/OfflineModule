SKIPMOUNT=false

PROPFILE=false

POSTFSDATA=false

LATESTARTSERVICE=false

REPLACE=""

print_modname() {
  ui_print ""
  ui_print "指纹特效(适配MIUI官方及官改)"
  ui_print ""
}

on_install() {
if [ -d "/data/adb/zhiwen/nd/coloros" ];then
  rm -rf /data/adb/zhiwen/
fi
  source $TMPDIR/tianjia.sh
#别删除这个命令，这个命令是为后续的安装做准备的。没有这个命令后续的安装将出现其它未知错误。
  rm -rf /data/adb/zhiwen/nd/*
  mkdir -p /data/adb/zhiwen/nd/coloros
#别删除这个命令，这个命令是为后续的安装做准备的。没有这个命令后续的安装将出现其它未知错误。

  ui_print "  检测冲突模块："
  source $TMPDIR/module_detect.sh
  ui_print "******************************"

  ui_print "- 正在释放文件"

  zip=$TMPDIR/zip
  chmod 755 $zip
  unzip -o "$ZIPFILE" 'mods/*' -d "$TMPDIR/" >&2
  MOD_FILES_DIR="$TMPDIR/mods/files"
  ui_print "- 检测系统指纹目录ing"
  a=$(unzip -l /system/priv-app/MiuiSystemUI/MiuiSystemUI.apk | egrep finger_image_light)
  a=${a#*/}
  a=${a%%/*}
  ui_print "- 检测到指纹目录为$a"
  ui_print "- 创建模块目录"
  mkdir -p $MODPATH/system/media/theme/default/
  ui_print "- 创建临时指纹目录"
  mkdir -p $MODPATH/zhiwen/res/drawable-xxhdpi
  mkdir -p $MODPATH/zhiwen/nightmode/res/drawable-xxhdpi        
  mkdir -p $MODPATH/zhiwen/res/$a
  mkdir -p $MODPATH/zhiwen/nightmode/res/$a
  ui_print "- 移动指纹文件到临时指纹目录"
  cp -rf $MOD_FILES_DIR/zhiwen/* $MODPATH/zhiwen/res/$a
  cp -rf $MOD_FILES_DIR/zhiwen/* $MODPATH/zhiwen/nightmode/res/$a
  cp -rf $MOD_FILES_DIR/zhiwen/* $MODPATH/zhiwen/res/drawable-xxhdpi
  cp -rf $MOD_FILES_DIR/zhiwen/* $MODPATH/zhiwen/nightmode/res/drawable-xxhdpi
  ui_print "- 压缩指纹目录文件，并移动至模块目录"
  cd $MODPATH/zhiwen
  $zip -r ${MODPATH}/system/media/theme/default/com.android.systemui ./* >/dev/null
  sleep 1
  ui_print "- 清空临时文件"
  rm -rf $MODPATH/zhiwen

if [ -e "/data/adb/yulan/" ];then
  mkdir -p $MODPATH/Settings
  unzip -o /system/product/priv-app/Settings/Settings.apk -d $MODPATH/Settings >&2

  source $TMPDIR/yulan.sh
    
  cp -rf $TMPDIR/7za /sbin/.magisk/busybox/
  chmod 777 /sbin/.magisk/busybox/*
#取自酷安@巴啦啦魔仙女王 
  cd $MODPATH/Settings
  7za a -tzip Settings.apk ./* -mx0 >&2
  if [ $? -eq 0 ]; then
      ui_print "****************************************"
      ui_print "- 预览图压缩成功"
      mkdir -p $MODPATH/system/product/priv-app/Settings/
      cp -rf $MODPATH/Settings/*.apk $MODPATH/system/product/priv-app/Settings/
      ui_print "- 删除系统应用缓存"
      rm -rf /data/system/package_cache/*
  fi    
  rm -rf $MODPATH/Settings
fi
  ui_print "- 卸载遗留文件"
  source $TMPDIR/xiezaiyiliu.sh

}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644

}
