CFG_PATH="/sdcard/Android/naki/asopt"

echo "
- 卸载CuToolbox，你不卸载我帮你
- 配置位于 $CFG_PATH

- Uninstall CuToolbox, otherwise I will help you
- The config is at $CFG_PATH
"

note="# fallback：放置方案
# 0：抢占优化，理论上表现更好
# 1：均衡负载，更接近官方调度

# pertask：实现
# 0：亲和，仅遇到问题时使用
# 1：迁移，可使帧率更加平滑
# 仅适用于内核不低于以下版本的平台：
# 高通：5.10 联发科：5.15

# fallback: Affinity plans
# 0: Preemptive, performs better in theory
# 1: Load balancing, closer to the default

# pertask: Implementation
# 0: Affinity, only choose if met problems
# 1: Capacity, make the frametime smoother
# Only available on platforms with kernel no older than:
# Qualcomm: 5.10 Mediatek: 5.15

# ***修改此文件后重启生效***
# ***Reboot after modification to take effect***
"

fallback=$(grep fallback= $CFG_PATH/asopt.conf)
pertask=$(grep pertask= $CFG_PATH/asopt.conf)
[ -z $fallback ] && fallback="fallback=0"
[ -z $pertask ] && pertask="pertask=1"

rm -rf /data/adb/asopt /data/asopt.conf /sdcard/Android/asopt /sdcard/Android/naki/asopt/asopt.log
mkdir -p $CFG_PATH
echo "$note
$fallback
$pertask" > $CFG_PATH/asopt.conf

chmod 755 $MODPATH/AsoulOpt
