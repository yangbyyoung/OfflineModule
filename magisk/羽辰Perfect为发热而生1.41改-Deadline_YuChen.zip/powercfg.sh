#!/system/bin/sh
#羽辰Perfect调度
mods=$1

if [ "$scene" = "standby" ]; then
    echo "待机"
    sh /data/adb/modules/YuChen/mods/standby.sh
elif [ "$mods" = "powersave" ]; then
    echo "省电"
    sh /data/adb/modules/YuChen/mods/powersave.sh
elif [ "$mods" = "balance" ]; then
    echo "均衡"
    sh /data/adb/modules/YuChen/mods/balance.sh
elif [ "$mods" = "performance" ]; then
    echo "性能"
    sh /data/adb/modules/YuChen/mods/performance.sh
elif [ "$mods" = "fast" ]; then
    echo "极速"
    sh /data/adb/modules/YuChen/mods/fast.sh
fi
