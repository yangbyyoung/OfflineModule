#!/system/bin/sh
MODDIR=${0%/*}

# XtremeSensivity🔥
# Author: @Jonathannjss © 2023

sleep 5

 # Set Touch Sampling Rate
    write /sys/module/msm_ts/parameters/debug_mask 1
    write /sys/module/msm_ts/parameters/input_poll_boost 0
    write /sys/module/msm_ts/parameters/timer_rate 0
    write /sys/module/msm_ts/parameters/delta 5
    write /sys/module/msm_ts/parameters/vtg_level 120
    write /sys/class/input/event0/sampling_rate 5
    write /sys/class/input/event7/sampling_rate 5

exit 0