#默认不动
SKIPMOUNT=false
#如果想启用system.prop的参数，则改为true
PROPFILE=false
#开机前执行的命令，想启用则改为true
POSTFSDATA=false
#开机后执行的命令，想启用则改为true
LATESTARTSERVICE=false

#安装模块时打印的信息，不需要的部分可以自己删除，也可以自己添加。
print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 - MIUI版本: $MIUI  $Version
 ****************************
 "
}

#开始安装（shell命令）
on_install() {
ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

#设置权限
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
}