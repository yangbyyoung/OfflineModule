mkdir -p "$MODPATH/system/"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
chcon -r u:object_r:system_file:s0 "$MODPATH/system"
chgrp -r root root "$MODPATH/system"
chgrp -r root root "$MODPATH/system/*"
chmod 644 "$MODPATH/system/priv-app/PermissionDog/PermissionDog.apk"
chmod 644 "$MODPATH/system/priv-app/PermissionDog/oat/arm64/*"
chmod 644 "$MODPATH/system/etc/permissions/privapp-permissions-PermissionDog.xml"
mkdir "$MODPATH/worker"
