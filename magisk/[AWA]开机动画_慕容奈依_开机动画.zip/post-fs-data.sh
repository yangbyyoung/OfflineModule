Murong_Naiyi=${0%/*}
