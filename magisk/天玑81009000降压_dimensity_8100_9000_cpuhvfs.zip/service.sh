MODDIR=${0%/*}
# MODDIR=/data/adb/modules/dimensity_8100_9000_hvfs

conf=/data/eem_offset.conf

sleep 120

insmod $MODDIR/cpuhvfs.ko

if [[ -f $conf ]];then
  grep '=' $conf | while read row
  do
    prop=$(echo $row | cut -f1 -d '=')
    value=$(echo $row | cut -f2 -d '=')
    case "$prop" in
      "little")
        echo little $value
        echo 0 $value > /proc/eem/eem_offset
      ;;
      "middle")
        echo middle $value
        echo 1 $value > /proc/eem/eem_offset
      ;;
      "big")
        echo big $value
        echo 2 $value > /proc/eem/eem_offset
      ;;
      "cci")
        echo cci $value
        echo 3 $value > /proc/eem/eem_offset
      ;;
    esac
  done
fi
