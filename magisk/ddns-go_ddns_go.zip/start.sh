#!/system/bin/sh
MODDIR=${0%/*}
while true;
do 
PIDS=`ps -ef | grep ddns-go | grep -v grep | awk '{print $2}'` 
if [ "$PIDS" != "" ]; then
 kill $(pgrep ddns-go)
 $MODDIR/bin/ddns-go -dns 114.114.114.114 -c $MODDIR/config/ddns_go_config.yaml
else
 $MODDIR/bin/ddns-go -dns 114.114.114.114 -c $MODDIR/config/ddns_go_config.yaml
fi
sleep 20 ;

done ;