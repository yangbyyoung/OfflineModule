MODDIR=${0%/*}
sleep 10
echo 110000 > /sys/class/thermal/thermal_zone46/trip_point_1_temp
echo 110000 > /sys/class/thermal/thermal_zone46/trip_point_3_temp
echo 110000 > /sys/class/thermal/thermal_zone47/trip_point_1_temp
echo 110000 > /sys/class/thermal/thermal_zone47/trip_point_3_temp
rm -rf /data/vendor/thermal/config/*