#!/system/bin/sh
if [ "$(getprop ro.system.build.version.release)" == "13" ]; then
setprop debug.sf.auto_latch_unsignaled false
setprop debug.sf.latch_unsignaled true
else
echo 
fi
chattr -i /data/system/mcd/df
pm clear com.xiaomi.joyose
pm clear com.xiaomi.powerchecker
am start --windowingMode 5 -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
sleep 2s
am force-stop com.xiaomi.joyose
rm -f /cache/miui-thermal/*
rm -f /data/vendor/thermal/config/*
rm -f /data/system/package_cache/*

