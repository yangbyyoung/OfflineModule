#!/system/bin/sh
MODDIR=${0%/*}

Unzip()
{
   unzip -o $1 -d $MODDIR/system/media/audio/alarms/
   unzip -o $2 -d $MODDIR/system/media/audio/ui/
   touch $MODDIR/$3 || sed -i "/^description=/c description=创建错误" "$MODDIR/module.prop"
   rm $MODDIR/$4 || sed -i "/^description=/c description=删除错误" "$MODDIR/module.prop"
   sed -i "/^description=/c description=$5" "$MODDIR/module.prop" || sed -i "/^description=/c description=错误" "$MODDIR/module.prop"
}

for x in $MODDIR/* ; do
   case "${x##*/}" in
   HuTao)
      Unzip $MODDIR/Genshin/HuTao/alarms/*.zip $MODDIR/Genshin/HuTao/ui/*.zip YunJin HuTao HuTao
      break;
   ;;
   YunJin)
      Unzip $MODDIR/Genshin/YunJin/alarms/*.zip $MODDIR/Genshin/YunJin/ui/*.zip Eula YunJin YunJin
      break;   
   ;;
   Eula)
      Unzip $MODDIR/Genshin/Eula/alarms/*.zip $MODDIR/Genshin/Eula/ui/*.zip Keqing Eula Eula
      break;   
   ;;
   Keqing)
      Unzip $MODDIR/Genshin/Keqing/alarms/*.zip $MODDIR/Genshin/Keqing/ui/*.zip Klee Keqing Keqing
      break;   
   ;;
   Klee)
      Unzip $MODDIR/Genshin/Klee/alarms/*.zip $MODDIR/Genshin/Klee/ui/*.zip RaidenShogun Klee Klee
      break;   
   ;;
   RaidenShogun)
      Unzip $MODDIR/Genshin/RaidenShogun/alarms/*.zip $MODDIR/Genshin/RaidenShogun/ui/*.zip YaeMiko RaidenShogun YaeMiko
      break;   
   ;;
   YaeMiko)
      Unzip $MODDIR/Genshin/YaeMiko/alarms/*.zip $MODDIR/Genshin/YaeMiko/ui/*.zip Noelle YaeMiko YaeMiko
      break;   
   ;;
   Noelle)
      Unzip $MODDIR/Genshin/Noelle/alarms/*.zip $MODDIR/Noelle/Noelle/ui/*.zip HuTao Noelle Noelle
      break;   
   ;;
   esac
done