#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
until [ $(getprop init.svc.bootanim) = "stopped" ]
do
sleep 2
done
function settings()
{
    cat /sdcard/Android/doze.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
Log() {
  txt="/sdcard/Android/doze.log"
  am start -n com.kmou424.ToastCreator/com.kmou424.ToastCreator.MainActivity --es msg "$1" >/dev/null 2>&1
  echo "$(date '+%T') $1" >> $txt
}
a=$(settings a)
b=$(settings b)
c=$(settings c)
d=$(settings d)
e=$(settings e)
f=$(settings f)
g=$(settings g)
h=$(settings h)
i=$(settings i)
j=$(settings j)
[[ -n $a ]] && dumpsys deviceidle whitelist +$a 
[[ -n $b ]] && dumpsys deviceidle whitelist +$b 
[[ -n $c ]] && dumpsys deviceidle whitelist +$c
[[ -n $d ]] && dumpsys deviceidle whitelist +$d 
[[ -n $e ]] && dumpsys deviceidle whitelist +$e 
[[ -n $f ]] && dumpsys deviceidle whitelist +$f 
[[ -n $g ]] && dumpsys deviceidle whitelist +$g 
[[ -n $h ]] && dumpsys deviceidle whitelist +$h 
[[ -n $i ]] && dumpsys deviceidle whitelist +$i 
[[ -n $j ]] && dumpsys deviceidle whitelist +$j

sleep 10 && Log "for 臭逼橘子 希望橘子玩啥都连跪 嘻嘻嘻嘻"
[[ -e /sdcard/Android/doze.log ]] && rm -rf /sdcard/Android/doze.log
while :
do
sleep 2
sh /data/adb/modules/doze/doze.sh
done