pm uninstall -k --user 0 com.milink.service >/dev/null 2>&1
pm uninstall -k --user 0 com.xiaomi.mi_connect_service >/dev/null 2>&1
pm uninstall -k --user 0 com.xiaomi.mirror >/dev/null 2>&1
pm uninstall -k --user 0 com.xiaomi.mis >/dev/null 2>&1