#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}

# 此脚本将在late_start service 模式执行

wait_sys_boot_completed() {
	while true
	do
		sleep 10
		boot_completed=$(getprop sys.boot_completed)
		if [[ "$boot_completed" == "1" ]];then
			return
		fi
	done
}
wait_sys_boot_completed
killall -9 com.xiaomi.market
killall -9 com.miui.screenrecorder
killall -9 com.miui.bugreport
killall -9 com.miui.analytics
sleep 10
settings put Secure speed_mode_enable 1
settings put system speed_mode 1
exit 0