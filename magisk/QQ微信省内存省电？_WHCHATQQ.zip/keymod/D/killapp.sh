app="
com.tencent.mobileqq
com.tencent.mm
"

for i in $app;do killall -9 "$i" ;done




