#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

# 这个脚本将以 post-fs-data 模式执行
# 更多信息请访问 Magisk 主题
mkdir -p $MODDIR/system/etc/permissions
\cp -rf /system/etc/permissions/privapp-permissions-platform.xml $MODDIR/system/etc/permissions/privapp-permissions-platform.xml
sed -i "/<permissions>/a\    <privapp-permissions package=\"Simplicity.LT.Fps\">\n        <permission name=\"android.permission.RECEIVE_BOOT_COMPLETED\"\/>\n        <permission name=\"android.permission.INTERNET\"\/>\n        <permission name=\"android.permission.READ_PHONE_STATE\"\/>\n        <permission name=\"android.permission.ACCESS_NETWORK_STATE\"\/>\n        <permission name=\"android.permission.ACCESS_WIFI_STATE\"\/>\n        <permission name=\"android.permission.WRITE_EXTERNAL_STORAGE\"\/>\n        <permission name=\"android.permission.WRITE_SETTINGS\"\/>\n        <permission name=\"miui.permission.WRITE_STEPS\"\/>\n        <permission name=\"miui.permission.READ_STEPS\"\/>\n    <\/privapp-permissions>" $MODDIR/system/etc/permissions/privapp-permissions-platform.xml



<!-- 开机启动 -->
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <!-- 拥有完全的网络访问权限 -->
    <uses-permission android:name="android.permission.INTERNET" />
    <!-- 读取手机状态和身份 -->
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <!-- 查看网络连接 -->
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <!-- 查看WLAN连接 -->
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <!-- 修改或删除您的USB存储设备中的内容 -->
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <!-- 修改系统设置 -->
    <uses-permission android:name="android.permission.WRITE_SETTINGS" />
    <uses-permission android:name="miui.permission.WRITE_STEPS" />
    <uses-permission android:name="miui.permission.READ_STEPS" />