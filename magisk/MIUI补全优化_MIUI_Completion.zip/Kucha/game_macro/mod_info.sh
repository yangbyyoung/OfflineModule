# 安装时显示的模块名称
mod_name="游戏工具箱补全"
mod_install_desc="可能只是UI开关✨$mod_name"
# 安装时显示的提示
mod_install_info="是否安装$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
source $TMPDIR/features.sh
sed -i 's/<bool name=\"support_mi_game_macro\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_mi_game_macro\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i 's/<bool name=\"support_game_gunsight\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_game_gunsight\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*


sed -i 's/<bool name=\"support_SR_for_image_display\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_SR_for_image_display\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"support_mi_game_macro\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_mi_game_macro\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"support_game_gunsight\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_game_gunsight\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"support_SR_for_image_display\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_SR_for_image_display\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}
