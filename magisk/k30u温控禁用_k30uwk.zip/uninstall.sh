
/sbin/.magisk/busybox/chattr -i  /data/vendor/thermal/config
  
  rm -rf /data/user/0/com.miui.powerkeeper/*
  rm -rf /data/system/package_cache/*
  rm -rf /data/app/com.miui.powerkeeper/*