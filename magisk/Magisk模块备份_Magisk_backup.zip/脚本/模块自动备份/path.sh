#自动备份文件的路径
#①"模块自动备份.tar"是文件名。
#②"模块自动备份.tar"之前是路径。
# "①②"点，如果要改动备份路径，不能漏掉任何其中一个。
Backup_path="/data/media/0/Android/Magisk备份/模块自动备份/模块自动备份.tar"
#手动备份文件的路径
Backup_path2="/data/media/0/Android/Magisk备份/模块手动备份/模块手动备份.tar"

