#!/system/bin/sh
SET_TRIP_POINT_TEMP_MAX=105000
MODDIR=${0%/*}
wait_sys_boot_completed()
{
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done
}
perfboost()
{
	for CPU in `ls /sys/devices/system/cpu/cpu*/online`; do
		if [ -f $CPU ]; then
			echo "1" > $CPU
		fi
	done
	for POLICY_PATH in `ls -d /sys/devices/system/cpu/cpufreq/policy*`; do
		if [ -f $POLICY_PATH/cpuinfo_max_freq ] && [ -f $POLICY_PATH/scaling_max_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_max_freq)" > $POLICY_PATH/scaling_max_freq
		fi
		if [ -f $POLICY_PATH/cpuinfo_min_freq ] && [ -f $POLICY_PATH/scaling_min_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_min_freq)" > $POLICY_PATH/scaling_min_freq
		fi
	done
	for THERMAL_ZONE in `ls /sys/class/thermal/thermal_zone*/type`; do
		if cat $THERMAL_ZONE | grep -E "cpu|gpu|ddr" >/dev/null; then
			for TRIP_POINT_TEMP in `ls ${THERMAL_ZONE%/*}/trip_point_*_temp`; do
				if [ "$(cat $TRIP_POINT_TEMP)" -lt "$SET_TRIP_POINT_TEMP_MAX" ]; then
					echo "$SET_TRIP_POINT_TEMP_MAX" > $TRIP_POINT_TEMP
				fi
			done
		fi
	done
}
set_def_pwrlevel()
{
	local MODEL=$1
	local SERIALNO=$2
	local PWRLEVEL=$3
	if [[ "$(getprop ro.soc.model)" ==  "$MODEL" ]] && [[ "$(getprop ro.serialno)" = *"$SERIALNO"* ]]; then
		echo "$PWRLEVEL" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
		echo "$PWRLEVEL" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
	fi
}
set_miui_val()
{
	if getprop | grep "miui.ui.version" >/dev/null; then
		settings put system POWER_SAVE_PRE_HIDE_MODE performance
		settings put Secure speed_mode_enable 1
		settings put system speed_mode 1
	fi
}
wait_sys_boot_completed && perfboost
if [ "$(getprop sutoliu.extension)" ==  "Y" ]; then
	nohup $MODDIR/SutoLiu.sh >/dev/null 2>&1 &
fi
if [ "$(getprop ro.product.brand)" == "Xiaomi" ]; then
	set_miui_val
	set_def_pwrlevel "SM8475" "a898518" "7"
	set_def_pwrlevel "SM8350" "f22a68c" "6"
	set_def_pwrlevel "SM8475" "92b7edb" "7"
	CLEANLIST="com.xiaomi.joyose com.miui.powerkeeper com.miui.bugreport com.miui.analytics com.xiaomi.mirror com.miui.securitycenter com.miui.securitycenter:ui com.android.quicksearchbox com.android.quicksearchbox:widgetProvider com.miui.carlink com.xiaomi.mtb com.xiaomi.market com.miui.screenrecorder"
	for PACKAGE_NAME in $CLEANLIST; do
		if killall -9 $PACKAGE_NAME >/dev/null; then
			sleep 1
		else
			sleep 5
			killall -9 $PACKAGE_NAME
		fi
	done
fi
