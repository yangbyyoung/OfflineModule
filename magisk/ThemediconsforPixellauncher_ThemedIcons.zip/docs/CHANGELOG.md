# v1.1.4
Add icons:
* Cricbuzz
* Flamingo for Twitter
* Hill Climb Racing
* MirPay
* Shadowsocks
* Snapp Passenger (Local App)
* Microsoft SwiftKey
* WoMic

# v1.1.3
Add icons:
* Another Widget
* Apex Legends
* Macrodroid
* Modo
* Owlgram
* Picto
* Pixel Launcher Mods
* Sim Toolkit
* Unofficial telegram stickers for WhatsApp
* Volume Styles
* uTorrent
* Generic Weather Icon (please link as many weather apps as possible)
* Chess aifactory
* Gojek
* Medium
* PeduliLindugi
* Tachiji2k
* Zoom
* NoiseFit

# v1.1.2

Add credit

# v1.1.1
Fix a part of the module so it can actually install

# v1.1.0
Update icons to latest icons from Pixel Launcher Mod

# v1.0.0
Initial release, unedited files from the origional module.
