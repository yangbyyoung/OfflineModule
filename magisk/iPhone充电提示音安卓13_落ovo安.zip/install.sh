SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
print_modname() {
 
 
 ui_print "   
 作者 酷安@落安112966
 "
 
}
on_install() {

 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/charging.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/disconnect.ogg' -d $MODPATH >&2

 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/IncomingMessage.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Lock.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/LowBattery.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/MessageSent.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Unlock.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/alarms/Daydream.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ringtones/Mi.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ringtones/MiRemix.ogg' -d $MODPATH >&2
}
