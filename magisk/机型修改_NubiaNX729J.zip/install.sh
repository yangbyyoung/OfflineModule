PROPFILE=true
print_modname() {
  ui_print "*******************************"
  ui_print " 机型修改为 红魔8 Pro "
  ui_print " 模块作者：酷安@雨は実刑 "
  ui_print "*******************************"
}
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
 
}