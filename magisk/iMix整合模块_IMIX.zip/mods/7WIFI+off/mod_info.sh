# 安装时显示的模块名称
mod_name="关闭高通wifi日志"
# 模块介绍
mod_install_desc="✨$mod_name"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
#清理wifi 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
add_sysprop "wifi.supplicant_scan_interval=250"
add_service_sh $MOD_FILES_DIR/service.sh

am kill tcpdump
killall -9 tcpdump

am kill cnss_diag
killall -9 cnss_diag

stop cnss_diag 2> /dev/null
killall -9 cnss_diag 2> /dev/null

stop tcpdump 2> /dev/null
killall -9 tcpdump 2> /dev/null

    return 0
}

mod_install_no()
{
    return 0
}
