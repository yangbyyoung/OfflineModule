ui_print " "
ui_print " ******************************************"
ui_print " "
ui_print "  安装小黄鸟根证书以解决不能抓https包的问题"
ui_print " "
ui_print "   SystemINFO:"
ui_print "   - MAGISK:$MAGISK_VER API:$API ARCH:$ARCH"
ui_print " "
ui_print "           -----by 酷安@安洋"
ui_print "          -----个人qq 2890172527"
ui_print " "
ui_print " ******************************************"
ui_print " "
chmod 0644 $MODPATH/system/etc/security/cacerts/87bc3517.0
cp -f $MODPATH/files/87bc3517.0 /system/etc/security/cacerts/87bc3517.0
chmod 0600 /system/etc/security/cacerts/87bc3517.0

