#!/system/bin/sh
MODDIR=${0%/*}
sleep 60
$MODDIR/Hgroups.sh 2>&1 1>/dev/null &