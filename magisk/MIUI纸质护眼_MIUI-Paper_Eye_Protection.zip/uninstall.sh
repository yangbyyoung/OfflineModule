#!/system/bin/sh
rm -rf /data/system/package_cache/*
