#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
#boot detection
until [ $(getprop init.svc.bootanim) = "stopped" ]
do
sleep 2
done

#删除文件
rm -f /data/data/com.miui.securitycenter/files/gamebooster/freeformlist

 dir=$(ls -l /data/data/ |awk '/^d/ {print $NF}')
for i in $dir
do
 echo $i >>/data/data/com.miui.securitycenter/files/gamebooster/freeformlist
done
#权限设置
chmod 444 /data/data/com.miui.securitycenter/files/gamebooster/freeformlist