rm -rf /data/adb/modules/miuihomemod/
rm -rf /data/system/package_cache/