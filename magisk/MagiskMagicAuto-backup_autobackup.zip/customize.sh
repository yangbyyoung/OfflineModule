# Magisk 模块脚本配置

# 说明：
# 1. 将你要替换的文件放入 system 文件夹 (删除 placeholder 文件)
# 2. 将模块信息写入 module.prop
# 3. 在这个文件中进行设置 (customize.sh)
# 4. 如果你需要在启动时执行命令, 请把它们加入 post-fs-data.sh 或 service.sh
# 5. 如果需要修改系统属性(build.prop), 请把它加入 system.prop

# 如果你需要启用 Magic Mount 请把它设置为 true 不启用则设置为 false
# 大多数模块都需要启用它
AUTOMOUNT=true
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

echo "
 ***********************************
       Magisk Magic Auto-backup

        作者：酷安@Hex_TyRz

           QQ：603157521
 ***********************************
         KMI工作室原创作品
 ***********************************
 "

on_install() {
  ui_print "- unzipping"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

#set_permissions
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0755
}

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}

Rec_path=/sdcard/MRec/magiskbackup.tar
Rec_file=/sdcard/MRec/Magisk备份文件.tar
a=/sdcard/MRec/adb.tar
e=/sdcard/MRec/com.topjohnwu.magisk
d=/sdcard/MRec/magiskuser.tar

if [[ ! -d /data/adb/modules/FUCK-SHIT-FILE ]]; then
  echo "- 环境正常！"
else
  echo "! 检测到您安装了我师父的【循环吃掉乱拉屎的文件/文件夹】模块"
  echo "！这可能会导致本模块无法自动备份，请三思！"
fi

echo "- 正在进行恢复文件检查（如需恢复模块建议在Recovery刷入本模块）"

if [[ -f "$Rec_path" ]]; then
  echo "! 错误！本版本的Magisk框架备份不支持Epic4.0及其以下版本备份文件恢复"
fi


if [[ -f "$Rec_file" ]]; then
	echo "
 ———————————————————————————————————
      发现Magisk框架恢复文件夹！
	  
        是否要进行恢复操作？
 ———————————————————————————————————
       如果您现在已安装模块
        或者是配置超级用户
 将会删除原有的模块和超级用户并恢复
 ———————————————————————————————————
         【音量+】进行恢复
		 
         【音量-】不进行恢复
 ———————————————————————————————————
 "
	if [[ $(get_choose) == 0 ]]; then
		echo "- 已允许恢复，正在进行恢复"
		echo "- 正在解压恢复文件"
        cd /sdcard/MRec
        tar -xf /sdcard/MRec/Magisk备份文件.tar
		echo "- 解压完毕！"
		if [[ ! -d /sdcard/MRec/MagiskScript ]]; then
            echo "- 未发现Magisk指令文件，不进行恢复"
        else
            echo "- 发现Magisk指令文件，正在清除并恢复"
			rm -rf /data/adb
			cp -rf /sdcard/MRec/MagiskScript /data/adb
			rm -rf /sdcard/MRec/MagiskScript
			echo "- Magisk指令文件恢复成功！"
        fi
		if [[ ! -d /sdcard/MRec/MagiskFrameworkData ]]; then
            echo "- 未发现Magisk框架文件，不进行恢复"
        else
            echo "- 发现Magisk框架文件，正在清除并恢复"
			rm -rf /data/user_de/0/com.topjohnwu.magisk
			cp -rf /sdcard/MRec/MagiskFrameworkData /data/user_de/0/com.topjohnwu.magisk
			rm -rf /sdcard/MRec/MagiskFrameworkData
			echo "- Magisk框架文件恢复成功！"
        fi
		if [[ ! -d /sdcard/MRec/MagiskUserData ]]; then
            echo "- 未发现Magisk用户配置文件，不进行恢复"
        else
            echo "- 发现Magisk用户配置文件，正在清除并恢复"
			rm -rf /data/data/com.topjohnwu.magisk
			cp -rf /sdcard/MRec/MagiskUserData /data/data/com.topjohnwu.magisk
			rm -rf /sdcard/MRec/MagiskUserData
			echo "- Magisk用户配置文件恢复成功！"
        fi
		echo "- 正在删除恢复文件"
		rm -rf /sdcard/MRec/Magisk备份文件.tar
		echo "- 恭喜！Magisk恢复成功！您可能需要重启以应用新的Magisk框架"
	else
		echo "- 已选择不恢复"
	fi
fi




if [[ ! -d /sdcard/MBackup ]]; then
  mkdir /sdcard/MBackup
  echo "! 没有发现备份文件夹，已自动创建在/sdcard/MBackup"
else
  echo "- MBackup文件正常"
fi

if [[ ! -d /sdcard/MRec ]]; then
  mkdir /sdcard/MRec
  echo "! 没有发现恢复文件夹，已自动创建在/sdcard/Mrec"
else
  echo "- MRec文件正常"
fi

echo "
 ***********************************
                说明

 1.备份文件路径为
 /sdcard/MBackup。每3天进行一次备份
 2.备份时将会清除原有文件夹中的备份
 3.每次开机时会进行一次备份
 4.恢复方法请见酷安@Hex_TyRz的帖子
 ***********************************
 "
 
echo - 欢迎各位酷安客官关注我的账号~
sleep 3

coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
if [[ "$coolapkTesting" != "" ]];
then
am start -d 'coolmarket://u/2420306' >/dev/null 2>&1
fi


echo - 模块安装完毕，变更将会在重启后生效。