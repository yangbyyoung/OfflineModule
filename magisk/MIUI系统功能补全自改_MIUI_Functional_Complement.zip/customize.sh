SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false
#########此处勿改，一经发现直接拍死#########################################
print_modname() {
 ui_print "#########################"
 ui_print "- 模块: $MODNAME"
 ui_print "- 模块ID: $MODID"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- Shell指令开荒：书寻卿"
 ui_print "- 素材来源: 风雪如花剑如霜/天命233"
 ui_print "- 介绍: $MODdescription"
 ui_print "#########################"
 ui_print "- 设备相关信息↓"
 ui_print "- SDK: $Sdk"
 ui_print "- 设备: $Device"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- MIUI版本: $MIUI  $Version"
 ui_print "#########################"
}
#########################################################################
on_install() {
 ui_print " "
 ui_print "- 此模块仅为挂载, 并不会直接修改系统文件, 卸载可恢复 . "
 ui_print " "
# 系统版本检测
 if [ $MIUI = "V11" ];then :;elif [ $MIUI = "V12" ];then :;elif [ $MIUI = "V125" ];then :;elif [ $MIUI = "V130" ];then : 
 else ui_print "- 你的设备不支持此模块" && abort; fi
 ui_print "- 设备支持, 正在执行.."
 ui_print " "
sleep 0.5
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
# 拷贝挂载指定路径文件
cp -rf /system/vendor/etc/device_features/* $MODPATH/system/vendor/etc/device_features/
cp -rf /system/etc/device_features/* $MODPATH/system/etc/device_features/
########################################################
# 功能开关变量（! 这里面的别动）
########################################################
Dolby0="support_dolby\">false"
Dolby1="support_dolby\">true"
HiFi0="support_hifi\">false"
HiFi1="support_hifi\">true"
AiJian0="support_ai_task\">false"
AiJian1="support_ai_task\">true"
Assist0="support_sound_assist\">false"
Assist1="support_sound_assist\">true"
Paper0="support_paper_eyecare\">false"
paper1="support_paper_eyecare\">true"
smart0="support_smart_eyecare\">false"
smart1="support_smart_eyecare\">true"
Aod0="support_aod\">false"
Aod1="support_aod\">true"
keycode0="aod_support_keycode_goto_dismiss\">false"
keycode1="aod_support_keycode_goto_dismiss\">true"
touchfeature0="support_touchfeature_gamemode\">false"
touchfeature1="support_touchfeature_gamemode\">true"
displayfeature0="support_displayfeature_gamemode\">false"
displayfeature1="support_displayfeature_gamemode\">true"
gamemi0="support_game_mi_time\">false"
gamemi1="support_game_mi_time\">true"
ledcolor0="support_led_color\">false"
ledcolor1="support_led_color\">true"
ledlight0="support_led_light\">false"
ledlight1="support_led_light\">true"
videotool0="support_video_tool_box\">false"
videotool1="support_video_tool_box\">true"
Fps0="defaultFps\">60<"
Fps1="defaultFps\">90<"
screenF="18x9_ratio_screen\">false"
screenT="18x9_ratio_screen\">true"
########################################################
#以下不想要的，整段删除保存重刷即可（system.prop里面的也同个道理）
#只有存在才会被开启
########################################################
ui_print "- 以下开启支持将根据你的系统版本及型号开启, 若不存在或存在无效果, 则是“硬件不支持”."

ui_print " "
# 杜比音效
sleep 0.4
sed -i "s/$Dolby0/$Dolby1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$Dolby0/$Dolby1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 杜比音效"

# HiFi
sleep 0.4
sed -i "s/$HiFi0/$HiFi1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$HiFi0/$HiFi1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: HiFi"

# Ai键
sleep 0.4
sed -i "s/$AiJian0/$AiJian1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$AiJian0/$AiJian1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: Ai键"

# 声音助手
sleep 0.4
sed -i "s/$Assist0/$Assist1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$Assist0/$Assist1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 声音助手"

# 息屏显示
sleep 0.4
sed -i "s/$Aod0/$Aod1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$Aod0/$Aod1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 息屏显示"

# 息屏显示时点击一下显示10秒
sleep 0.4
sed -i "s/$keycode0/$keycode1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$keycode0/$keycode1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 息屏显示时点击一下显示10秒"

# 高级游戏模式
sleep 0.4
sed -i "s/$touchfeature0/$touchfeature1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$touchfeature0/$touchfeature1/" $MODPATH/system/etc/device_features/*
sed -i "s/$displayfeature0/$displayfeature1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$displayfeature0/$displayfeature1/" $MODPATH/system/etc/device_features/*
sed -i "s/$gamemi0/$gamemi1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$gamemi0/$gamemi1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 隐藏的高级游戏模式"

# 呼吸灯的颜色
sleep 0.4
sed -i "s/$ledcolor0/$ledcolor1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$ledcolor0/$ledcolor1/" $MODPATH/system/etc/device_features/*
sed -i "s/$ledlight0/$ledlight1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$ledlight0/$ledlight1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 可更改呼吸灯的颜色"

# 视频工具箱
sleep 0.4
sed -i "s/$videotool0/$videotool1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$videotool0/$videotool1/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 视频工具箱"

# 默认屏幕刷新率
sleep 0.4
sed -i "s/$Fps0/$Fps1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$Fps0/$Fps1/" $MODPATH/system/etc/device_features/*
echo "- 默认调节: 屏幕刷新率60调为90, 若不是60则不改动"

if [ $MIUI != "125" ];then
#支持相机中拍摄18x9比例的屏幕(全屏)
sleep 0.4
sed -i "s/$screenF/$screenT/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$screenF/$screenT/" $MODPATH/system/etc/device_features/*
echo "- 开启支持: 相机中拍摄18x9比例的屏幕(全屏)"
else :; fi
         
#这里是复制粘贴@风雪如花剑如霜的模块内容，已经过同意#########################################################################
# 这里不需要的也可以删除（一整段）

# 游戏英雄死亡倒计时
sed -i '/<\/features>/i\    <bool name=\"support_mi_game_countdown\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_mi_game_countdown\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
echo "- 开始支持: MIUI12.5游戏英雄死亡倒计时"
# DC调光
sleep 0.4
sed -i '/<\/features>/i\    <bool name=\"support_dc_backlight\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_dc_backlight\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
echo "- 开启支持: DC调光"
# 呼吸灯
sleep 0.4
sed -i '/<\/features>/i\    <bool name=\"support_led_color\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_led_color\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_led_light\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_led_light\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
echo "- 开启支持: 呼吸灯"
# 息屏显示时点击一下显示10秒
sed -i '/<\/features>/i\    <bool name=\"aod_support_keycode_goto_dismiss\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"aod_support_keycode_goto_dismiss\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 视频工具箱
sed -i '/<\/features>/i\    <bool name=\"is_support_video_tool_box\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"is_support_video_tool_box\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 息屏显示
sed -i '/<\/features>/i\    <bool name=\"support_aod\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_aod\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 双人脸（可能导致相机中的FULL模式卡画面，如果需要请删除下面的#号保存重刷开启）
sleep 0.4
#sed -i '/<\/features>/i\    <bool name=\"support_multi_face_input\">true<\/bool>' $MODPATH/system/etc/device_features/*
#sed -i '/<\/features>/i\    <bool name=\"support_multi_face_input\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
echo "- 开启支持: 双人脸 默认关闭, 原因为可能导致相机Full卡画面, 需要请自行开启. "
# 高级游戏模式
sed -i '/<\/features>/i\    <bool name=\"support_displayfeature_gamemode\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_displayfeature_gamemode\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_touchfeature_gamemode\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_touchfeature_gamemode\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# HiFi
sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 杜比
sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# Ai键
sed -i '/<\/features>/i\    <bool name=\"support_ai_task\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_ai_task\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 声音助手
sed -i '/<\/features>/i\    <bool name=\"support_sound_assist\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_sound_assist\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# 纸质护眼代码, 提取自K30
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/etc/device_features/*
echo "- 开启支持: 纸质护眼"
# 支持选择屏幕刷新率
sleep 0.4
sed -i '/<\/features>/i\   <integer-array name=\"fpsList\">' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\   <integer-array name=\"fpsList\">' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <item>144<\/item>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <item>144<\/item>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <item>120<\/item>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <item>120<\/item>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <item>90<\/item>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <item>90<\/item>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <item>60<\/item>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <item>60<\/item>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <\/integer-array>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <\/integer-array>' $MODPATH/system/etc/device_features/*
echo "- 开启支持: 多个屏幕刷新率选项"
##################################################################
ui_print " "

sleep 0.5
#以下不要改动#######################################################
#system.prop
ui_print "################################"
echo "- system.prop 对应 build.prop"
ui_print "################################"
ui_print " "
ui_print "- 以下部分功能默认关闭, 需要请在system.prop中, 删除代码前面的#号保存重刷即可开启"
sleep 0.8
ui_print " "
ui_print "- 数据加速（来自@bugme7）默认关闭, 需要请在system.prop中开启重刷"
ui_print "- ro.vendor.net.enable_sla=1"
sleep 0.3
#ui_print " "
ui_print "- AI预载（来自@bugme7）默认关闭, 需要请在system.prop中开启重刷"
ui_print "- persist.sys.ai_preload_cloud=1"
sleep 0.3
#ui_print " "
ui_print "- 微信视频美颜(miui)默认关闭，需要请在system.prop中开启重刷"
ui_print "- persist.vendor.vcb.enable=true"
ui_print "- persist.vendor.vcb.ability=true"
sleep 0.3
#ui_print " "
ui_print "- 扬声器清理(miui)"
ui_print "- ro.vendor.audio.spk.clean=true"
ui_print "- ro.vendor.audio.spk.stereo=true"
sleep 0.3
#ui_print " "
ui_print "- 视频工具箱-音效-影音功能(miui)（UI开关）"
ui_print "- ro.vendor.audio.vocal.support=true"
ui_print "- ro.vendor.audio.surround.support=true"
ui_print "- ro.vendor.audio.scenario.support=true"
ui_print "- ro.vendor.audio.vocal.support=true"
ui_print "- debug.media.vpp.enable=true"
ui_print "- debug.media.video.frc=true"
ui_print "- debug.media.video.vpp=true"
ui_print "- ro.vendor.media.video.frc.support=true"
ui_print "- ro.vendor.media.video.vpp.support=true"
ui_print "- vendor.media.vpp.debug.value.use=false"
ui_print "- vendor.media.vpp.aie.cade=100"
ui_print "- vendor.media.vpp.aie.ltm=1"
ui_print "- vendor.media.vpp.aie.ltmsatgain=55"
ui_print "- vendor.media.vpp.aie.ltmsatoff=55"
ui_print "- vendor.media.vpp.aie.ltmacestr=37"
ui_print "- vendor.media.vpp.aie.ltmacebril=20"
ui_print "- vendor.media.vpp.aie.ltmacebrih=0"
sleep 0.3
#ui_print " "
ui_print "- 启用游戏变声器(miui)（UI开关）"
ui_print "- ro.vendor.audio.voice.change.support=true"
ui_print "- ro.vendor.audio.game.effect=true"
sleep 0.3
#ui_print " "
ui_print "- 听感调节（UI开关）"
ui_print "- ro.vendor.audio.sfx.earadj=true"
ui_print "- ro.vendor.audio.soundfx.usb=true"
ui_print "- ro.audio.monitorRotation=true"
#Time
sleep 0.3
ui_print " "
description=$MODPATH/module.prop
time0=$(date "+%Y-%m-%d %H:%M")
echo "- 当前时间: $time0"
echo "$time0" >> $MODULE
sleep 1.6
}
###############################################################################################################
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
#Author of this module: ABajiang
#Here is the author's cool home page, if there is a problem with the use of modules can contact the author!
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
if [[ "$coolapkTesting" != "" ]];then am start -d 'coolmarket://u/1132618' >/dev/null 2>&1 ; fi
#Please do not modify this line of code, respect the author. Thank.
}
###############################################################################################################