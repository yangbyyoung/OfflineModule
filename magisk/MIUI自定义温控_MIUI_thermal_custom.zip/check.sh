test "$(getprop ro.miui.ui.version.name)" = "" && abort "●———— 非MIUI ————●"

grep_thermal_845(){
	find /data/adb/modules/*/system -type f -iname "*thermal*"| sed '/.*.sh/d' |cut -d'/' -f5 | uniq 
}

for i in $(ls /data/adb/modules);do
	for o in $(grep_thermal_845);do
		name=$(cat /data/adb/modules/$i/module.prop | grep 'name'| cut -d = -f2 )
		author=$(cat /data/adb/modules/$i/module.prop | grep 'author'| cut -d = -f2 )
		description=$(cat /data/adb/modules/$i/module.prop | grep 'description'| cut -d = -f2 )
		size=` du -sh /data/adb/modules/$i |awk '{print $1}'`
		if test "$i" = "$o" -a "$i" != "$id" ;then
			echo " "
			echo "∞————————————————————————∞"
			echo ""
			echo "－名称：$name"
			echo "－作者：$author"
			echo "－简介：$description"
			echo " "
			echo "－大小：$size"
			echo " "
			echo "－ 该模块含有温控修改，已经停用该模块！"
			echo "∞————————————————————————∞"
			echo " "
			touch "/data/adb/modules/$i/disable"
		fi
	done
done
