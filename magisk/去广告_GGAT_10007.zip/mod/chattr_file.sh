id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH


#运行chattr +i广告文件
function chattr_ad_file() {
local packagename="${1}"
find /data/user/$packagename /data/data/$packagename /data/media/*/Android/data/$packagename -iname "douban_ad" -type d -o -iname "splashCache" -type d -o -iname "ads" -type d -o -iname "SplashPreload" -type d -o -iname "ad" -type d -o -iname "splash_image" -type d -o -iname "splashCache" -type d -o -iname "SplashData" -type d -o -iname "TMEAds" -type d -o -iname "qad_cache" -type d -o -iname "SplashPreload" -type d -o -iname "splash_ad_cache" -type d -o -iname "GDTDOWNLOAD" -type d -o -iname "app_adnet" -type d  -o -iname "tad_cache" -type d  -o -iname "app_ad" -type d -o -iname "TTCache" -type d  -o -iname "app_ad" -type d  -o -iname "cachett_ad" -type d  -o -iname "tt_tmpl_pkg" -type d  -o -iname "com_qq_e_download"  -type d  -o -iname "pangle_com.byted.pangle" -type d  2>/dev/null | while read adfile ;do
X_file "${adfile}" 2>/dev/null
done
}

#配置文件，读取应用包名
conf_file="${0%/*}/apps.conf"
#执行chattr
for i in $(cat $conf_file | sed '/^#/d;/^[[:space:]]*$/d' )
do
test "$i" = "" && continue
chattr_ad_file "$i"
done



