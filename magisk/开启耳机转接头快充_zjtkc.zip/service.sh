#!/system/bin/sh
MODDIR=${0%/*}

sleep 10s

chmod 777 /sys/class/power_supply/main/current_max

while true; do
    echo '3000000' > /sys/class/power_supply/main/current_max
    sleep 30s
done