thermaldir="$MODPATH/system/vendor/etc"
file="$MODPATH/thermal.conf"

mkdir -p $thermaldir

for i in $(find /system/vendor/etc/ -type f -name "thermal*.conf" | sed "s/.*map.*\.conf//g" | grep -v "thermal-engine.conf");do
cp -rf $file "$MODPATH$i"
done





