package main

import (
	"fmt"
	"io"
	"net/http"
	"os"

	"github.com/schollz/progressbar/v3"
)

func downloadFile(url, filePath string) error {
	// 发送HTTP请求获取文件
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// 创建目标文件
	file, err := os.Create(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	// 获取文件大小
	size := resp.ContentLength

	// 使用progressbar创建进度条
	bar := progressbar.DefaultBytes(
		size,
		"downloading",
	)

	// 创建多写的Writer，用于同时写文件和更新进度条
	writer := io.MultiWriter(file, bar)

	// 将HTTP响应体写入文件并更新进度条
	_, err = io.Copy(writer, resp.Body)
	if err != nil {
		return err
	}

	return nil
}

func main() {
	url := "https://example.com/file_to_download.txt"
	filePath := "ADhosts"

	err := downloadFile(url, filePath)
	if err != nil {
		fmt.Printf("下载文件失败: %v\n", err)
		return
	}

	fmt.Println("\n文件下载成功并保存到 ADhosts")
}
