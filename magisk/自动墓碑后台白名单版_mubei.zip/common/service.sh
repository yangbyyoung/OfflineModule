#!/system/bin/sh
MODDIR=${0%/*}
sd=/data/media/0/Android/墓碑日志.log

# 该脚本将在设备开机后作为延迟服务启动
wait_boot_completed() {
  i=5
  while true; do
    sleep $i
    completed=$(getprop sys.boot_completed)
    if [[ "$completed" == "1" ]];then
      return
    fi
  done
}

wait_boot_completed
    
#chmod a+x $MODDIR/mb/*.sh
chmod 777 -R /data/adb/modules/mubei

sleep 15
echo "$(date '+%T') 开机启动，已删除旧日志！" >$sd

 nohup /data/adb/modules/mubei/mb/mb.sh > /dev/null 2>&1 &
 
 sleep 2
 	name="mb.sh"
    mb_id=$(pgrep -f "mb.sh" )   
	if [ "$mb_id" != "" ]; then
	sed -i 's/\[.*\]/\[ 模式：kill -19 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
    echo "$(date '+%T') 墓碑 运行成功" >>$sd 
	else
	sed -i 's/\[.*\]/\[ 墓碑 启动失败 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	exit 0
    fi
