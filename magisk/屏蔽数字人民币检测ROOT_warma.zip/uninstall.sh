#!/bin/sh

cd /data/user/0/cn.gov.pbc.dcep/

chattr -i envc.push