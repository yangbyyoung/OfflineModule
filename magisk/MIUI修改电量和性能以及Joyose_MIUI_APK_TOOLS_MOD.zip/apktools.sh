#!/system/bin/sh

function system_app_cache() {
	folder="${1}"
	find "$folder/system" -iname "*app" -type d 2>/dev/null | grep -v 'overlay' | while read app; do
		find $app -type d -maxdepth 1 2>/dev/null | while read dir; do
			app_dir=${dir##*/}
			test $app_dir = "priv-app" && continue
			test $app_dir = "app" && continue
			cat <<key >>${folder}/uninstall.sh
rm -rf /data/dalvik-cache/*/system@*@${app_dir}* 2>/dev/null
rm -rf /data/system/package_cache/* 2>/dev/null
key
		done && sed -i "1i #!/system/bin/sh\n#清理系统应用的缓存" ${folder}/uninstall.sh
		trimmer_file ${folder}/uninstall.sh
	done
}

function trimmer_file() {
	local file=$1
	sed -i '/^[[:space:]]*$/d' ${file}
	oldfile=$(sort -n ${file} | uniq)
	echo "$oldfile" >${file}
}

echo ""
echo "∞————————————————————————∞"
echo ""
echo "- 设置Apktools 中……"
mkdir -p /data/local/Apktool
/data/adb/magisk/busybox tar xJf $MODPATH/apktools.tar.xz -C /data/local/Apktool >/dev/null
chmod -R 777 /data/local/Apktool
test ! -e /data/data/per.pqy.openjdk && {
	cp -rf /data/local/Apktool/per.pqy.openjdk /data/data
	chmod -R 777 /data/data/per.pqy.openjdk
}

echo "- 配置完成！"

apktool=/data/local/Apktool/apktool/apktool.sh
zipalign=/data/local/Apktool/apktool/openjdk/bin/zipalign

#运行修改Smali文件
key_source $MODPATH/com.miui.powerkeeper_sed.sh
key_source $MODPATH/com.xiaomi.joyose_sed.sh

echo "- 清理应用缓存和无用文件……"
system_app_cache "${MODPATH}"
source "$MODPATH/uninstall.sh"
rm -rf /data/system/package_cache/* /data/local/Apktool /data/data/per.pqy.openjdk $MODPATH/apk $MODPATH/apktools.tar.xz
echo "- 完成！"
echo ""
echo "∞————————————————————————∞"

