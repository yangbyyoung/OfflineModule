[ -z "$ab" ] && MODDIR=${0%/*} || MODDIR=$MODPATH

. $MODDIR/mount_bind.sh
#echo '' >> $MODDIR/mo.log

wait_true || logs "! 检测失败" 1

#新路径#*#旧路径
LG="
/data/media/0/Download/QQfile#*#/data/media/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv
/data/media/0/Download/TIMfile#*#/data/media/0/Android/data/com.tencent.tim/Tencent/TIMfile_recv
"

for TT in $LG; do
mo $TT
done

#log_ln
