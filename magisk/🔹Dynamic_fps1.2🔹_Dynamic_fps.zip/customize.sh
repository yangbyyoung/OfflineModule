MyPrint() {
	echo "$@"
	sleep 0.3
}
#设置权限
set_perm_recursive $MODPATH 0 0 0755 0644
rm -rf "/sdcard/Android/动态刷新率/"
MyPrint "清理配置残留。。。"
MyPrint "╔════════════════════════════════════"
MyPrint "║   - [&]   动态刷新率 C语言版    "
MyPrint "╠════════════════════════════════════"
MyPrint "║ 温馨提示："
MyPrint "║   - 1.如果你不是从作者发布链接获取此模块，将承担未知风险"
MyPrint "║   - 2.使用说明位于配置文件"
MyPrint "║   - 3.现在你阔以重启系统了"
MyPrint "║"
MyPrint "╚════════════════════════════════════"
echo " "
echo 
echo 



