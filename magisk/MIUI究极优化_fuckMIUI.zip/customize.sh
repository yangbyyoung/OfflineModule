 ui_print "*******************************"
  ui_print "MIUI究极优化模块刷入中"
  ui_print "数据由彭彭331、温暖、迪、、、、莫莫笑提供"
  ui_print "*******************************"
  ui_print "MIUI究极优化模块刷入完成"
  ui_print "               By 魔威"
  

  
  
  set_perm_recursive  $MODPATH  0  0  0755  0644


AUTOMOUNT=true

MOD_Version="`grep_prop version $TMPDIR/module.prop`"
MOD_Author="`grep_prop author $TMPDIR/module.prop`"
MOD_Description="`grep_prop description $TMPDIR/module.prop`"
MarketName="`getprop ro.product.marketname`"
Device="`getprop ro.product.device`"
Model="`getprop ro.product.model`"
MIUI="`getprop ro.miui.ui.version.name`"
Version="`getprop ro.build.version.incremental`"
Android="`getprop ro.build.version.release`"
za=$MODPATH/YuK/7za #$za a -tzip -mx=7 -mmt

