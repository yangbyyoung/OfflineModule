clean
tmp_list="ThemeManager"
chattr -i /data/system/theme/rights
rm -rf /data/system/package_cache/*
rm -rf /data/app/com.android.thememanager*
rm -rf /data/system/theme/rights
