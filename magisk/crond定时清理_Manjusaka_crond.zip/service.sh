#!/system/bin/sh
 
Module_Path="/data/adb/modules"
       
   if [[ -f "/data/adb/ksud" ]]; then  
          S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')     
          if [[ "$S" = "v0.3" ]]; then
            Module_Path="/data/adb/ksu/modules"
          fi
   fi
crond_path="$Module_Path/Manjusaka_crond"

# 更改文件夹及其子文件夹权限为755

find "$crond_path" -type d -exec chmod -R 755 {} + >/dev/null 2>&1

 #写入计时器
 if [[ ! -f "$crond_path/cron.d/root" ]]; then
 echo "*/1 * * * * /system/bin/sh $crond_path/Manjusaka_crond.sh" >"$crond_path/cron.d/root"
 fi

  if [[ -f "/data/adb/ksud" ]]; then  
          /data/adb/ksu/bin/busybox crond -c $crond_path/cron.d/
          else
          $( magisk --path )/.magisk/busybox/crond -c $crond_path/cron.d/
  fi
