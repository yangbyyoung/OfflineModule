 echo ----------------------------
script_name="mb.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
    echo -----"$lastID"已经启动过了-----
else
    nohup /data/adb/modules/mubei/mb/mb.sh > /dev/null 2>&1 &
    echo -----"$lastID"启动成功了-----
fi
echo ----------------------------

       