SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

print_modname() {
  ui_print "请确保已删除自带的系统推送服务(如果有)后再重启"
  ui_print "by酷安 @極彩"
}

REPLACE="
"

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}

