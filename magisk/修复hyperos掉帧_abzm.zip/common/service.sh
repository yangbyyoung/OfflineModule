#!/system/bin/sh
MODDIR=${0%/*}
resetprop ro.crypto.state encrypted
