#!/system/bin/sh
# if Magisk change its mount point in the future
MODDIR=${0%/*}

sleep 40

# =========
# Gpu 
# =========
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling
echo '0' > /sys/class/kgsl/kgsl-3d0/bus_split
echo '1' > /sys/class/kgsl/kgsl-3d0/force_no_nap
echo '1' > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo '100000' > /sys/class/kgsl/kgsl-3d0/idle_timer

# =========
# Panic Off
# =========
echo '0' > /proc/sys/kernel/panic
echo '0' > /proc/sys/kernel/panic_on_oops
echo '0' > /proc/sys/kernel/panic_on_warn
echo '0' > /sys/module/kernel/parameters/panic
echo '0' > /sys/module/kernel/parameters/panic_on_warn
echo '0' > /sys/module/kernel/parameters/pause_on_oops

# =========
# Input Boost
# =========
echo '128' > /sys/module/cpu_input_boost/parameters/input_boost_duration

# =========
# Schedutil Advanced
# =========
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
for i in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/hispeed_load
do
echo '85' > $i
done
chmod 444 /sys/devices/system/cpu/cpu*/cpufreq/schedutil/hispeed_load

chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
for i in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/down_rate_limit_us
do
echo '5000' > $i
done
chmod 444 /sys/devices/system/cpu/cpu*/cpufreq/schedutil/down_rate_limit_us

chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/iowait_boost_enable
for i in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/iowait_boost_enable
do
echo '0' > $i
done
chmod 444 /sys/devices/system/cpu/cpu*/cpufreq/schedutil/iowait_boost_enable

chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
for i in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/pl
do
echo '0' > $i
done
chmod 444 /sys/devices/system/cpu/cpu*/cpufreq/schedutil/pl

chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
for i in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/up_rate_limit_us
do
echo '1000' > $i
done
chmod 444 /sys/devices/system/cpu/cpu*/cpufreq/schedutil/up_rate_limit_us

# =========
# Stune Boost
# =========
echo "0" > /dev/stune/schedtune.boost
echo "1" > /dev/stune/schedtune.sched_boost_enabled
echo "0" > /dev/stune/schedtune.sched_boost_no_override
echo "1" > /dev/stune/schedtune.prefer_idle
echo "0" > /dev/stune/cgroup.clone_children

# =========
# Top app
# =========
echo "0" > /dev/stune/top-app/schedtune.boost
echo "1" > /dev/stune/top-app/schedtune.sched_boost_enabled
echo "0" > /dev/stune/top-app/schedtune.sched_boost_no_override
echo "1" > /dev/stune/top-app/schedtune.prefer_idle
echo "0" > /dev/stune/top-app/cgroup.clone_children

# =========
# Root
# =========
echo "0" > /dev/stune/rt/schedtune.boost
echo "1" > /dev/stune/rt/schedtune.sched_boost_enabled
echo "0" > /dev/stune/rt/schedtune.sched_boost_no_override
echo "1" > /dev/stune/rt/schedtune.prefer_idle
echo "0" > /dev/stune/rt/cgroup.clone_children

# =========
# Foreground app
# =========
echo "0" > /dev/stune/foreground/schedtune.boost
echo "1" > /dev/stune/foreground/schedtune.sched_boost_enabled
echo "0" > /dev/stune/foreground/schedtune.sched_boost_no_override
echo "1" > /dev/stune/foreground/schedtune.prefer_idle
echo "0" > /dev/stune/foreground/cgroup.clone_children

# =========
# Background app
# =========
echo "0" > /dev/stune/background/schedtune.boost
echo "1" > /dev/stune/background/schedtune.sched_boost_enabled
echo "0" > /dev/stune/background/schedtune.sched_boost_no_override
echo "1" > /dev/stune/background/schedtune.prefer_idle
echo "0" > /dev/stune/background/cgroup.clone_children

# =========
# Cpu Set's
# =========
echo '0-7' > /dev/cpuset/audio-app/cpus
echo '0-7' > /dev/cpuset/background/cpus
echo '0-7' > /dev/cpuset/camera-daemon/cpus
echo '0-7' > /dev/cpuset/foreground/cpus
echo '' > /dev/cpuset/restricted/cpus
echo '0-7' > /dev/cpuset/system-background/cpus
echo '0-7' > /dev/cpuset/top-app/cpus


# =========
# Set I/O Scheduler 
# =========
echo 'fiops' > /sys/block/sda/queue/scheduler
echo 'fiops' > /sys/block/sdb/queue/scheduler
echo 'fiops' > /sys/block/sdc/queue/scheduler
echo 'fiops' > /sys/block/sdd/queue/scheduler
echo 'fiops' > /sys/block/sde/queue/scheduler
echo 'fiops' > /sys/block/sdf/queue/scheduler

echo '2048' > /sys/block/sda/queue/read_ahead_kb
echo '2048' > /sys/block/sdb/queue/read_ahead_kb
echo '2048' > /sys/block/sdc/queue/read_ahead_kb
echo '2048' > /sys/block/sdd/queue/read_ahead_kb
echo '2048' > /sys/block/sde/queue/read_ahead_kb
echo '2048' > /sys/block/sdf/queue/read_ahead_kb

echo '512' > /sys/block/sda/queue/nr_requests
echo '512' > /sys/block/sdb/queue/nr_requests
echo '512' > /sys/block/sdc/queue/nr_requests
echo '512' > /sys/block/sdd/queue/nr_requests
echo '512' > /sys/block/sde/queue/nr_requests
echo '512' > /sys/block/sdf/queue/nr_requests

# =========
# Virtual Machine, Low Memory Killer
# =========
echo "2560,4096,6144,12288,14336,18432" > /sys/module/lowmemorykiller/parameters/minfree
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo "0" > /proc/sys/vm/laptop_mode
echo "10" > /proc/sys/vm/swappiness
echo "50" > /proc/sys/vm/vfs_cache_pressure
echo "40" > /proc/sys/vm/dirty_ratio
echo "10" > /proc/sys/vm/dirty_background_ratio
echo '1' > /proc/sys/vm/overcommit_memory
echo '500' > /proc/sys/vm/dirty_expire_centisecs
echo '1000' > /proc/sys/vm/dirty_writeback_centisecs

# =========
# Fsync ON
# =========
echo 'Y' > /sys/module/sync/parameters/fsync_enabled

# =========
# Off log
# =========
echo '0' > /sys/module/earlysuspend/parameters/debug_mask
echo '0' > /sys/module/alarm/parameters/debug_mask
echo '0' > /sys/module/alarm_dev/parameters/debug_mask
echo '0' > /sys/module/binder/parameters/debug_mask
echo '0' > /sys/devices/system/edac/cpu/log_ce
echo '0' > /sys/devices/system/edac/cpu/log_ue
echo '0' > /sys/module/binder/parameters/debug_mask
echo 'Y' > /sys/module/bluetooth/parameters/disable_ertm
echo 'Y' >/sys/module/bluetooth/parameters/disable_esco
echo '0' > /sys/module/debug/parameters/enable_event_log
echo '0' > /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
echo '0' > /sys/module/dwc3/parameters/ep_addr_txdbg_mask
echo '0' > /sys/module/edac_core/parameters/edac_mc_log_ce
echo '0' > /sys/module/edac_core/parameters/edac_mc_log_ue
echo '0' > /sys/module/glink/parameters/debug_mask
echo '0' > /sys/module/hid_apple/parameters/fnmode
echo '0' > /sys/module/hid_magicmouse/parameters/emulate_3button
echo 'N' > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo 'N' > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo '0' > /sys/module/lowmemorykiller/parameters/debug_level
echo 'N' > /sys/module/mdss_fb/parameters/backlight_dimmer
echo '0' > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo '0' > /sys/module/msm_smd/parameters/debug_mask
echo '0' > /sys/module/msm_smem/parameters/debug_mask
echo 'N' > /sys/module/otg_wakelock/parameters/enabled
echo '0' > /sys/module/service_locator/parameters/enable
echo 'N' > /sys/module/sit/parameters/log_ecn_error
echo '0' > /sys/module/smem_log/parameters/log_enable
echo '0' > /sys/module/smp2p/parameters/debug_mask
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' > /sys/module/touch_core_base/parameters/debug_mask 
echo '0' > /sys/module/usb_bam/parameters/enable_event_log
echo 'Y' > /sys/module/printk/parameters/console_suspend
echo '0' > /proc/sys/debug/exception-trace
echo '0 0 0 0' > /proc/sys/kernel/printk
echo '0' > /proc/sys/kernel/compat-log

# =========
# Network Buffer size
# =========
setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.lte 524288,1048576,2097152,524288,1048576,2097152
setprop net.tcp.buffersize.hsdpa 6144,87380,1048576,6144,87380,1048576
setprop net.tcp.buffersize.hspa 6144,87380,524288,6144,16384,262144
setprop net.tcp.buffersize.umts 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.edge 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.gprs 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.evdo_b 6144,87380,1048576,6144,87380,1048576

# =========
# Finger Boost
# =========
echo '1' > /sys/kernel/fp_boost/enabled

# =========
# Disable / stop system logging
# =========
stop logd

# =========
# Clean shit
# =========
rm -Rf /cache/*.apk;
rm -f /data/*.log;
rm -f /data/*.txt;
rm -f /data/anr/*;
rm -f /data/backup/pending/*.tmp;
rm -f /data/cache/*.*;
rm -f /data/data/*.log;
rm -f /data/data/*.txt;
rm -f /data/log/*.log;
rm -f /data/log/*.txt;
rm -f /data/local/*.apk;
rm -f /data/local/*.log;
rm -f /data/local/*.txt;
rm -f /data/local/tmp/*;
rm -f /data/last_alog/*.log;
rm -f /data/last_alog/*.txt;
rm -f /data/last_kmsg/*.log;
rm -f /data/last_kmsg/*.txt;
rm -f /data/mlog/*;
rm -f /data/system/*.log;
rm -f /data/system/*.txt;
rm -f /data/system/dropbox/*;
rm -Rf /data/system/usagestats/*;
rm -f /data/system/shared_prefs/*;
rm -f /data/tombstones/*;
rm -Rf /sdcard/LOST.DIR;
rm -Rf /sdcard/found000;
rm -Rf /sdcard/LazyList;
rm -Rf /sdcard/albumthumbs;
rm -Rf /sdcard/kunlun;
rm -Rf /sdcard/.CacheOfEUI;
rm -Rf /sdcard/.bstats;
rm -Rf /sdcard/.taobao;
rm -Rf /sdcard/Backucup;
rm -Rf /sdcard/MIUI/debug_log;
rm -Rf /sdcard/wlan_logs;
rm -Rf /sdcard/ramdump;
rm -Rf /sdcard/UnityAdsVideoCache;
rm -f /sdcard/*.log;
rm -f /sdcard/*.CHK;

echo " -- Done..."