#配合一键转换vmess工具使用
#在mode=后填   "固定"   或   "跟随" （不包括双引号）
#例(mode=跟随 或 mode=固定)
#填"跟随"则混淆为导入的节点的混淆
#填"固定"则混淆固定为下文填写的混淆
#不填则默认"跟随"，不按规矩填也默认"跟随"
###############


mode=固定


###############


host=gw.alicdn.com


###############
#↑↑填写固定的混淆↑↑自带网易云混淆

#执行即可！！





































































zt=`sed -n 10p ./混淆设置.sh`
hx=`sed -n 16p ./混淆设置.sh`
host=`echo ${hx##*=}`


echo "\E[1;36m"
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
if [[ "mode=" == ${zt} ]]||[[ "mode=跟随" == ${zt} ]]; then
echo "混淆模式=跟随节点"
sed -i '2998s/tsoh/host/g'   ./一键转换vmess并使用.sh
sed -i "2999c #"  ./一键转换vmess并使用.sh
sed -i "5c #"  ./订阅导入.sh


elif [[ "mode=固定" == ${zt} ]]; then
echo -e "混淆模式=固定\n固定的混淆为"$host""
sed -i '2998s/host/tsoh/g'   ./一键转换vmess并使用.sh
sed -i "2999c host=$host"  ./一键转换vmess并使用.sh
sed -i "242c host=$host"  ./订阅导入.sh
sed -i "7c host=$host" ./节点配置文件/*.ini




else
echo -e "提示:填写不合规\n混淆模式=跟随节点"
sed -i '2998s/tsoh/host/g'   ./一键转换vmess并使用.sh
sed -i "2999c #"  ./一键转换vmess并使用.sh
sed -i "242c #"  ./订阅导入.sh
fi
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
rm -f ./*.bak