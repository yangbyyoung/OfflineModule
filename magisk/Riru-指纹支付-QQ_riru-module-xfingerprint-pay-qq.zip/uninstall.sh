#!/sbin/sh
MODDIR=${0%/*}
rm -f "/data/local/tmp/libriru-module-xfingerprint-pay-qq.dex" || true
