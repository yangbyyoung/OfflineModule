#!/system/bin/sh
# LKT V5.1
# Author: korom42
# Credits: Matt Yang

BASEDIR="$(dirname "$0")"
. $BASEDIR/libcommon.sh
. $BASEDIR/libuperf.sh

# $1: power_mode
apply_power_mode()
{
    uperf_set_powermode "$1"
    echo "Applying $1 done."
}

# $1: power_mode
verify_power_mode()
{
    # fast -> performance
    case "$1" in
        "powersave"|"balance"|"performance") echo "$1" ;;
        "fast") echo "performance" ;;
        *) echo "balance" ;;
    esac
}

save_panel()
{
    clear_panel
    write_panel ""
    write_panel "LKT v5.0 by @korom42"
   # write_panel "Script Credits: Matt Yang"
    write_panel "Last performed: $(date '+%Y-%m-%d %H:%M:%S')"
    write_panel ""
    write_panel "[LKT status]"
    write_panel "$(uperf_status)"
    write_panel ""
    write_panel "[Settings]"
    write_panel "# The default profile applied at boot"
    write_panel "# Available Profiles: balanced powersave performance"
    write_panel "default_mode=$default_mode"
}

# 1. target from exec parameter
action="$1"
if [ "$action" != "" ]; then
    action="$(verify_power_mode "$action")"
    apply_power_mode "$action"
    exit 0
fi

# 2. target from panel
#default_mode="$(read_cfg_value default_mode)"
#default_mode="$(verify_power_mode "$default_mode")"
#apply_power_mode "$default_mode"

# save mode for automatic applying mode after reboot
#save_panel

exit 0
