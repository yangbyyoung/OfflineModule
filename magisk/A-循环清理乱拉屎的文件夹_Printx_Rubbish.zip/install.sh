##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
print_modname() {
    return
}

echo "**********************************************"
echo "－品牌: `getprop ro.product.brand`"
echo "－代号: `getprop ro.product.device`"
echo "－模型: `getprop ro.product.model`"
echo "－安卓版本: `getprop ro.build.version.release`"
echo "    "
test -n `getprop ro.miui.ui.version.name` && echo "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
echo "    "
echo "－内核版本: `uname -a `"
echo "    "
echo "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
echo "    "
echo "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
echo "***********************************************"

# Copy/extract your module files into $MODPATH in on_install.
on_install() {
  unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null
  ui_print "- 更新日志: 1.4.0_Steady"
  ui_print "    "
  ui_print "- 新增游戏清理: 原神，王者荣耀，和平精英等多个游戏清理"
  ui_print "    "
  ui_print "- 新增123云盘清理"
  ui_print "    "
  ui_print "- 新增多条抖音规则"
  ui_print "    "
  ui_print "- 新增淘宝，京东，拼多多 清理"
  ui_print "    "
  ui_print "- 新增夸克，支付宝多条规则"
  ui_print "    "
  ui_print "-重新修改白名单规则"
  ui_print "    "
  ui_print "- 已累计新增38个第三方应用的缓存清理规则"
  ui_print "    "
  ui_print "- 已累计694条规则"
  ui_print "    "
  ui_print "- 默认关闭空文件夹扫描"
  ui_print "    "
  ui_print "- 配置文件路径：/data/media/0/Android/PrintX/清理垃圾/"
  ui_print "    "
  ui_print "- 模块文件路径: /data/adb/modules/Printx_Rubbish/"
  ui_print "    "
  ui_print "- 酷安：@只喝橘子味汽水"
  ui_print "    "
  ui_print "- 群组：699459180"
  ui_print "    "
  ui_print "- WeChat(个人)：Suonian-XingHe"
  
PrintX(){
printf "- $1\n"
}
PrintX_PATH="/data/media/0/Android/PrintX/清理垃圾"
PrintX_Detect() {
    PrintX "音量键测试"
    PrintX "请按音量+或-键"
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > "$TMPDIR"/events && return 0 || return 1
}

PrintX_get() {
    while true; do
        /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > "$TMPDIR"/events
        cat "$TMPDIR"/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null && break
    done
    cat "$TMPDIR"/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null && return 1 || return 0
}

PrintX_Start() {
    PrintX_Detect && {
        PrintX_KEY=PrintX_get
        PrintX "音量键测试完成\n"
    } || {
        PrintX_KEY=false
        PrintX " ！错误：没有检测到音量键选择"
    }
}

PrintX_Run() {
    PrintX "是否保留本地的黑白名单？\n"
    PrintX "音量+ 保留"
    PrintX "音量- 替换"
    
    "$PrintX_KEY" && {
        PrintX "已替换"
        rm -rf "$PrintX_PATH"
    } || PrintX "已保留"
}
    [ -d "${PrintX_PATH}" ] && {
    PrintX_Start
    PrintX_Run
} || PrintX "不存在黑白名单 跳过选择"
  # 作者：只喝橘子味汽水
  # 群组：699459180
}
set_permissions() {
    return
}