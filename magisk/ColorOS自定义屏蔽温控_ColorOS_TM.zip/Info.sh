#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}
# show Message
title="description=移除ColorOS的温控、移除设备所有温控文件、关闭CPU降频策略，包含链接库等："
model1=""
model2=""
model3=""
model4=""
model5=""
model6=""
model7=""
model8=""
model9=""
model10=""
model11=""
model12=""
model13=""
model14=""
model15=""
model16=""
model17=""

if [ -f "/data/adb/modules/ColorOS_TM/module.prop" ];then
sleep 40
model1="✲状态：已运行"
fi



description=$title$model1$model2$model3$model4$model5$model6$model7$model8$model9$model10$model11$model12$model13$model14$model15$model16$model17$endname7
sed -i "s/description=.*$/$description/g" $MODDIR/module.prop




