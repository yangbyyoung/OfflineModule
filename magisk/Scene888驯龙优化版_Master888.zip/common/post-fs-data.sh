#setenforce 0
#重定向文件
rm -f /data/powercfg.sh
rm -f /data/powercfg.json
cp /data/adb/modules/Master888/config/powercfg.sh /data
cp /data/adb/modules/Master888/config/powercfg.json /data
chmod 0644 /data/powercfg.sh
chmod 0644 /data/powercfg.json