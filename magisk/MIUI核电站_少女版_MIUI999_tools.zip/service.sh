#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

# 开机等待时间，时间过短会导致脚本无法正确执行(即使你找到了最佳的最短时间也是建议保留部分时间加载系统资源再执行脚本)

sleep 20

# ------清理脚本------

# Magisk_该模块缓存
rm -rf /storage/emulated/0/Android/开机运行日志.txt
rm -rf /storage/emulated/0/Android/Doze日志.txt
sleep 10
echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt
echo "$(date "+%Y-%m-%d %H:%M:%S") [Magisk_该模块缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt
# Magisk_该模块缓存

# Magisk日志[新旧版本路径一致]
rm -rf /cache/magisk.log
echo "$(date "+%Y-%m-%d %H:%M:%S") [Magisk日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt
# Magisk日志[新旧版本路径一致]

# 清理MIUI桌面日志-系统目录
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
# 清理MIUI桌面日志-存储目录
rm -rf /storage/emulated/0/MIUI/debug_log
echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI桌面日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt
# 清理MIUI系统日志
rm -rf /data/vendor/charge_logger
echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI系统日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理wlan_logs日志
rm -rf /data/vendor/wlan_logs
echo "$(date "+%Y-%m-%d %H:%M:%S") [Wlan_Logs日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt
echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# BATKILL x5 uc 缓存禁用
# 说明:原理就是去除文件夹的写入权限(chmod 000)，防删处理(chattr +i)达到禁用效果
echo "$(date "+%Y-%m-%d %H:%M:%S") [X5_UC_内核] 清理开始 " >> /storage/emulated/0/Android/开机运行日志.txt

# 高德地图
# 垃圾文件
rm -rf /data/media/0/amap
touch /data/media/0/amap
chmod 000 /data/media/0/amap
echo "$(date "+%Y-%m-%d %H:%M:%S") [高德地图] 垃圾文件已清理" >> /storage/emulated/0/Android/开机运行日志.txt

# 哔哩哔哩
# 日志文件
rm -rf /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
touch /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
chmod 000 /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
echo "$(date "+%Y-%m-%d %H:%M:%S") [哔哩哔哩] 日志文件已清理" >> /storage/emulated/0/Android/开机运行日志.txt

# 铁路12306
# 启动广告
rm -rf /data/data/com.MobileTicket/databases/ads_database
rm -rf /data/data/com.MobileTicket/databases/ads_database-journal
touch /data/data/com.MobileTicket/databases/ads_database
touch /data/data/com.MobileTicket/databases/ads_database-journal
chmod 000 /data/data/com.MobileTicket/databases/ads_database
chmod 000 /data/data/com.MobileTicket/databases/ads_database-journal
echo "$(date "+%Y-%m-%d %H:%M:%S") [铁路12306] 启动广告已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 腾讯QQ
# 日志文件
rm -rf /data/media/0/tencent/msflogs
rm -rf /data/media/0/tencent/wtlogin
rm -rf /data/media/0/tencent/wns/Logs
touch /data/media/0/tencent/msflogs
touch /data/media/0/tencent/wtlogin
touch /data/media/0/tencent/wns/Logs
chmod 000 /data/media/0/tencent/msflogs
chmod 000 /data/media/0/tencent/wtlogin
chmod 000 /data/media/0/tencent/wns/Logs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯QQ] 日志文件已清理" >> /storage/emulated/0/Android/开机运行日志.txt

rm -rf /data/media/0/tencent/tbs
rm -rf /data/media/0/tbs
rm -rf /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
touch /data/media/0/tencent/tbs
touch /data/media/0/tbs
touch /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
chmod 000 /data/media/0/tencent/tbs
chmod 000 /data/media/0/tbs
chmod 000 /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
echo "$(date "+%Y-%m-%d %H:%M:%S") [QQ] X5内核备份和日志已清理" >> /storage/emulated/0/Android/开机运行日志.txt

# X5内核禁用
# 腾讯网盘
rm -rf //data/data/com.qq.qcloud/app_tbs
touch //data/data/com.qq.qcloud/app_tbs
chmod 000 //data/data/com.qq.qcloud/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯网盘] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 腾讯地图
rm -rf /data/data/com.tencent.map/app_tbs
touch /data/data/com.tencent.map/app_tbs
chmod 000 /data/data/com.tencent.map/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯地图] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 腾讯QQ
rm -rf /data/data/com.tencent.mobileqq/app_tbs
touch /data/data/com.tencent.mobileqq/app_tbs
chmod 000 /data/data/com.tencent.mobileqq/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯QQ] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# QQ邮箱
rm -rf /data/data/com.tencent.androidqqmail/app_tbs
touch /data/data/com.tencent.androidqqmail/app_tbs
chmod 000 /data/data/com.tencent.androidqqmail/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [QQ邮箱] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 京喜
rm -rf /data/data/com.jd.pingou/app_tbs
touch /data/data/com.jd.pingou/app_tbs
chmod 000 /data/data/com.jd.pingou/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京喜] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 京东
rm -rf /data/data/com.jingdong.app.mall/app_tbs
touch /data/data/com.jingdong.app.mall/app_tbs
chmod 000 /data/data/com.jingdong.app.mall/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京东] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 京东极速版
rm -rf /data/data/com.jd.jdlite/app_tbs
touch /data/data/com.jd.jdlite/app_tbs
chmod 000 /data/data/com.jd.jdlite/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京东极速版] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 歌词适配
rm -rf /data/data/com.mylrc.mymusic/app_tbs
touch /data/data/com.mylrc.mymusic/app_tbs
chmod 000 /data/data/com.mylrc.mymusic/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [歌词适配] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 哔哩哔哩
rm -rf /data/data/tv.danmaku.bili/app_tbs
touch /data/data/tv.danmaku.bili/app_tbs
chmod 000 /data/data/tv.danmaku.bili/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [哔哩哔哩] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 朴朴超市
rm -rf /data/data/com.pupumall.customer/app_tbs
touch /data/data/com.pupumall.customer/app_tbs
chmod 000 /data/data/com.pupumall.customer/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [朴朴超市] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 叮咚买菜
rm -rf /data/data/com.yaya.zone/app_tbs
touch /data/data/com.yaya.zone/app_tbs
chmod 000 /data/data/com.yaya.zone/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [叮咚买菜] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# 和彩云网盘
rm -rf /data/data/com.chinamobile.mcloud/app_tbs
touch /data/data/com.chinamobile.mcloud/app_tbs
chmod 000 /data/data/com.chinamobile.mcloud/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [和彩云网盘] X5内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

# UC内核禁用
# 铁路12306
rm -rf /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
rm -rf /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
touch /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
touch /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
chmod 000 /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
chmod 000 /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
echo "$(date "+%Y-%m-%d %H:%M:%S") [铁路12306] UC内核已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

echo "$(date "+%Y-%m-%d %H:%M:%S") [X5_UC_内核] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# SD Maid 清理
# 路径由“SD Maid”提取
echo "$(date "+%Y-%m-%d %H:%M:%S") [SD Maid] 清理开始 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理“应用程序无响应”事件日志
rm -rf /data/anr
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用程序无响应] 事件日志 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理Android系统临时文件
rm -rf /data/local/tmp
echo "$(date "+%Y-%m-%d %H:%M:%S") [Android系统临时文件] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理Android系统日志文件
rm -rf /data/log
rm -rf /data/logger
echo "$(date "+%Y-%m-%d %H:%M:%S") [Android系统日志文件] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# Dropbox 文件夹包含不断生成的日志文件
# 说明：logcat
rm -rf /data/system/dropbox
echo "$(date "+%Y-%m-%d %H:%M:%S") [Logcat日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理应用启动统计信息
# 说明：权限管理-使用分析（Google/Firebase Analytics等）
rm -rf /data/system/usagestats
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用使用分析统计信息] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 清理应用崩溃日志
rm -rf /data/tombstones
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用崩溃日志] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

echo "$(date "+%Y-%m-%d %H:%M:%S") [SD Maid] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# ------开始清理微信无用垃圾-------
# 大美制作 酷安@孤Lrkc   21.04.04
# 转发修改请保留原作者信息 谢啦๑ᵔ⌔ᵔ๑
# 酷安@嫖丶总 改成了老版本的目录，精准妲己！！
# 微信清理无用垃圾（不包含聊天记录）
# 微信清理脚本 20210628
# 说明:适用于7.0.15以前的版本，没有修改缓存路径的版本就是15以前的版本，从15以后就换路径了，本人用的7.0.3"

echo "$(date "+%Y-%m-%d %H:%M:%S") [微信垃圾日志_缓存] 清理开始 " >> /storage/emulated/0/Android/开机运行日志.txt

# 开始处理根目录文件 
# 日志文件
rm -rf /data/data/com.tencent.mm/files/xlog/
rm -rf /data/media/0/tencent/MicroMsg/xlog
rm -rf /data/media/0/Android/data/com.tencent.mm/files/tbslog
rm -rf /data/data/com.tencent.mm/files/live_log/
rm -rf /data/data/com.tencent.mm/files/com.tencent.mm:tools/logging_cache/
rm -rf /data/data/com.tencent.mm/files/webnet/cacheinfo/
rm -rf /data/data/com.tencent.mm/app_appcache/
rm -rf /data/data/com.tencent.mm/cache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [日志文件] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

# 主缓存 
rm -rf /data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
rm -rf /data/data/com.tencent.mm/cache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [主缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

# 插件
rm -rf /data/data/com.tencent.mm/app_xwalk_[0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z]/
rm -rf /data/data/com.tencent.mm/app_xwalkplugin/
#rm -rf /data/data/com.tencent.mm/files/host/
echo "$(date "+%Y-%m-%d %H:%M:%S") [插件] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

# 视频缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/cache
echo "$(date "+%Y-%m-%d %H:%M:%S") [视频缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 升级缓存
rm -rf /data/media/0/tencent/MicroMsg/CheckResUpdate
echo "$(date "+%Y-%m-%d %H:%M:%S") [升级缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# 广告缓存
rm -rf /data/media/0/tencent/MicroMsg/sns_ad_landingpages
echo "$(date "+%Y-%m-%d %H:%M:%S") [广告缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# WebView缓存
rm -rf /data/data/com.tencent.mm/app_webview/GPUCache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [WebView缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# TBS插件 X5内核
rm -rf /data/data/com.tencent.mm/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [TBS插件 X5内核] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

# 直播
rm -rf /data/data/com.tencent.mm/files/public/live/
rm -rf /data/data/com.tencent.mm/files/public/fts/
rm -rf /data/data/com.tencent.mm/files/public/OCR
rm -rf /data/data/com.tencent.mm/files/public/cityService/
rm -rf /data/data/com.tencent.mm/files/public/tagsearch/
rm -rf /data/data/com.tencent.mm/files/public/box/
rm -rf /data/data/com.tencent.mm/files/public/CheckResUpdate/
rm -rf /data/data/com.tencent.mm/files/public/websearch/
echo "$(date "+%Y-%m-%d %H:%M:%S") [直播] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

# 开始处理内部存储目录文件
rm -rf /storage/emulated/0/tencent/micromsg/xlog/
rm -rf /storage/emulated/0/tencent/wtlogin/
rm -rf /storage/emulated/0/tencent/WeixinWork/src_log/
rm -rf /storage/emulated/0/tencent/msflogs/
rm -rf /storage/emulated/0/tencent/MicroMsg/wxanewfiles/5c1669df814221fd564749b945374831/miniprogramLog/
rm -rf /storage/emulated/0/tencent/XG/Logs/
rm -rf /storage/emulated/0/tencent/MicroMsg/7013ef886407f01edd3cb3bb5dea60a8/logcat/
rm -rf /storage/emulated/0/tencent/Wmp/com.tencent.wework/log/
rm -rf /storage/emulated/0/tencent/MobileQQ/log/
rm -rf /storage/emulated/0/tencent/tga/liveplugin/log/
rm -rf /storage/emulated/0/tencent/MicroMsg/7013ef886407f01edd3cb3bb5dea60a8/locallog/
rm -rf /storage/emulated/0/tencent/WeixinWork/gyoospb/
echo "$(date "+%Y-%m-%d %H:%M:%S") [公共目录垃圾日志_缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") [微信垃圾日志_缓存] 清理完成 " >> /storage/emulated/0/Android/开机运行日志.txt

# ---------微信清理完成---------

# ------清理脚本------

# ------优化脚本------

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# Doze参数调整_省电休眠策略
# Doze省电休眠策略
dumpsys deviceidle unforce
dumpsys deviceidle disable light
dumpsys deviceidle aggressive true
dumpsys deviceidle >> /storage/emulated/0/Android/Doze日志.txt
# Doze参数调整
settings put global device_idle_constants light_after_inactive_to=30000,light_pre_idle_to=60000,light_idle_to=60000,light_idle_factor=2.0,light_max_idle_to=900000,light_idle_maintenance_min_budget=60000,light_idle_maintenance_max_budget=180000,min_light_maintenance_time=5000,min_deep_maintenance_time=10000,inactive_to=300000,sensing_to=0,locating_to=0,location_accuracy=1000,motion_inactive_to=0,idle_after_inactive_to=10000,idle_pending_to=0,max_idle_pending_to=0,idle_pending_factor=2.0,idle_to=600000,max_idle_to=21600000,idle_factor=2,min_time_to_alarm=600000,max_temp_app_whitelist_duration=300000,mms_temp_app_whitelist_duration=60000,sms_temp_app_whitelist_duration=20000,notification_whitelist_duration=30000,wait_for_unlock=true
echo "$(date "+%Y-%m-%d %H:%M:%S") [Doze省电休眠策略] 参数调整已完成，请配合Doze激进模式使用 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# MIUI耗电进程优化

echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI耗电进程优化] 开始 " >> /storage/emulated/0/Android/开机运行日志.txt

# 干掉mdnsd
if [ ! -f "/system/bin/mdnsd" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]mdnsd已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在mdnsd，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill mdnsd
  killall -9 mdnsd
  stop mdnsd
  rm -rf /system/bin/mdnsd
fi

# 干掉mdnsd.rc
if [ ! -f "/system/etc/init/mdnsd.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]mdnsd.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在mdnsd.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill mdnsd.rc
  killall -9 mdnsd.rc
  stop mdnsd.rc
  rm -rf /system/etc/init/mdnsd.rc
fi

# 干掉logd
if [ ! -f "/system/bin/logd" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]logd已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在logd，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill logd
  killall -9 logd
  stop logd
  rm -rf /system/bin/logd
fi

# 干掉logd.rc
if [ ! -f "/system/etc/init/logd.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]logd.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在logd.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill logd.rc
  killall -9 logd.rc
  stop logd.rc
  rm -rf /system/etc/init/logd.rc
fi

# 干掉dumpstate
# dumpstatez 生成一个压缩的错误报告，但也使用套接字打印一次文件位置
if [ ! -f "/system/bin/dumpstate" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]dumpstate已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在dumpstate，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill dumpstate
  killall -9 dumpstate
  stop dumpstate
  rm -rf /system/bin/dumpstate
fi

# 干掉dumpstate.rc
if [ ! -f "/system/etc/init/dumpstate.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]dumpstate.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在dumpstate.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill dumpstate.rc
  killall -9 dumpstate.rc
  stop dumpstate.rc
  rm -rf /system/etc/init/dumpstate.rc
fi

# 干掉dpmd
if [ ! -f "/system/bin/dpmd" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]dpmd已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在dpmd，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill dpmd
  killall -9 dpmd
  stop dpmd
  rm -rf /system/bin/dpmd
fi

# 干掉dpmd.rc
if [ ! -f "/system/etc/init/dpmd.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]dpmd.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在dpmd.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill dpmd.rc
  killall -9 dpmd.rc
  stop dpmd.rc
  rm -rf /system/etc/init/dpmd.rc
fi

# 干掉qseelogd
if [ ! -f "/system/bin/qseelogd" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]qseelogd已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在qseelogd，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill qseelogd
  killall -9 qseelogd
  stop qseelogd
  rm -rf /system/bin/qseelogd
fi

# 干掉qseelogd.rc
if [ ! -f "/system/etc/init/qseelogd.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]qseelogd.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在qseelogd.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill qseelogd.rc
  killall -9 qseelogd.rc
  stop qseelogd.rc
  rm -rf /system/etc/init/qseelogd.rc
fi

# 干掉tcpdump
if [ ! -f "/vendor/bin/tcpdump" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]tcpdump已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在tcpdump，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill tcpdump
  killall -9 tcpdump
  stop tcpdump
  rm -rf /vendor/bin/tcpdump
fi

# 干掉cnss_diag
if [ ! -f "/vendor/bin/cnss_diag" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]cnss_diag已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在cnss_diag，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill cnss_diag
  killall -9 cnss_diag
  stop cnss_diag
  rm -rf /vendor/bin/cnss_diag
fi

# 干掉charge_logger
if [ ! -f "/vendor/bin/charge_logger" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]charge_logger已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/开机运行日志.txt
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在charge_logger，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/开机运行日志.txt
  am kill charge_logger
  killall -9 charge_logger
  stop charge_logger
  rm -rf /vendor/bin/charge_logger
fi

echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI耗电进程优化] 完成 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 10

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# 阶梯式充电限制 @White白话君
#echo '0' > /sys/class/power_supply/battery/step_charging_enabled
#echo "$(date "+%Y-%m-%d %H:%M:%S") [阶梯式充电限制 @White白话君] 已禁用" >> /storage/emulated/0/Android/开机运行日志.txt

sleep 2

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# MIUI12优化 @水龙
echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI12 水龙优化 @水龙] 脚本开始 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用binder调试
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/binder_alloc/parameters/debug_mask
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用binder调试 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用内核调试
echo "0" > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo "N" > /sys/kernel/debug/debug_enabled
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用内核调试 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用用户空间向dmesg写入日志
echo "off" > /proc/sys/kernel/printk_devkmsg
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用用户空间向dmesg写入日志 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用sched_autogroup
echo "0" > /proc/sys/kernel/sched_autogroup_enabled
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用sched_autogroup " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用f2fs I/O数据收集统计
echo "0" > /sys/fs/f2fs/sda34/iostat_enable
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用f2fs I/O数据收集统计 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用调度统计
echo "0" > /proc/sys/kernel/sched_schedstats
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用调度统计 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用I/O统计
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdd/queue/iostats
echo "0" > /sys/block/sde/queue/iostats
echo "0" > /sys/block/sdf/queue/iostats
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用I/O统计 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用(存储I/O)调试帮助
echo "0" > /sys/block/sda/queue/nomerges
echo "0" > /sys/block/sdb/queue/nomerges
echo "0" > /sys/block/sdc/queue/nomerges
echo "0" > /sys/block/sdd/queue/nomerges
echo "0" > /sys/block/sde/queue/nomerges
echo "0" > /sys/block/sdf/queue/nomerges
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用(存储I/O)调试帮助 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用I/O调试，UFS 和EMMC皆可用
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用I/O调试，UFS 和EMMC皆可用 " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用不必要的转储 RAMDUMP
echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo "0" > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用不必要的转储 RAMDUMP " >> /storage/emulated/0/Android/开机运行日志.txt

# 禁用调试驱动
echo "0" > /sys/module/millet_core/parameters/millet_debug
echo "0" > /proc/sys/migt/migt_sched_debug
echo "$(date "+%Y-%m-%d %H:%M:%S") 已禁用调试驱动 " >> /storage/emulated/0/Android/开机运行日志.txt

echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI12 水龙优化 @水龙] 脚本完成 " >> /storage/emulated/0/Android/开机运行日志.txt
# MIUI12优化 @水龙

sleep 10

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/开机运行日志.txt

# ------Google Doze脚本------
# 禁用Google全家桶
pm disable com.google.android.gms
pm disable com.google.android.gsf
pm disable com.android.vending
pm disable com.google.android.syncadapters.contacts
pm disable com.google.android.onetimeinitializer
pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver

sleep 5

# 禁用双开的Google服务
pm disable-user --user 999 com.google.android.gms
pm disable-user --user 999 com.google.android.gsf

# GMS Doze
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
cmd appops set com.google.android.gms AUTO_START ignore
cmd appops set com.google.android.ims AUTO_START ignore

echo "$(date "+%Y-%m-%d %H:%M:%S") [Google Doze优化] 脚本执行完成。 " >> /storage/emulated/0/Android/开机运行日志.txt

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") [脚本结束] 每次重启都会生成该脚本，大概2分钟可以执行完毕！" >> /storage/emulated/0/Android/开机运行日志.txt

done
# ------Google Doze脚本------

# ------优化脚本------
