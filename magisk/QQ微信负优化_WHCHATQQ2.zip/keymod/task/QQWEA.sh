#!/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

function show_value() {
	local value=$1
	local file=/data/media/0/Android/QQ微信负优化/QQ微信负优化.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function pose() {
	local file=/data/media/0/Android/QQ微信负优化/亮屏清理进程.conf
	if test $(show_value "亮屏目标应用") == QQ; then
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d;/com.tencent.mm/d'
	elif test $(show_value "亮屏目标应用") == 微信; then
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d;/com.tencent.mobileqq/d'
	else
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d'
	fi
}

function topapp() {
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
	echo "$app"
}

function killapp() {
	for i in $(pose); do
		pgrep -f "$i" | while read PID; do
			test "$(topapp)" = "com.tencent.mm" && break
			test "$(topapp)" = "com.tencent.mobileqq" && break
			kill -9 "$PID"
		done
	done
}

function calculate_mem() {
	local memWE=$(dumpsys meminfo com.tencent.mm | grep -w "TOTAL:" | sed 's|[[:space:]]|\n|g' | sed -n '/^[[:digit:]]/p' | sed -n '1p' )
	local memQQ=$(dumpsys meminfo com.tencent.mobileqq | grep -w "TOTAL:" | sed 's|[[:space:]]|\n|g' | sed -n '/^[[:digit:]]/p' | sed -n '1p' )
	test -n "$memQQ" -o -n "$memWE" && {
		if test -n "$memQQ" -a -n "$memWE"; then
			memQQ=$(($memQQ / 1024))
			memWE=$(($memWE / 1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB，微信运行内存 "$memWE" MB。配置文件目录在 [ /data/media/0/Android/QQ微信负优化 ]" "$MODPATH/module.prop"
		elif test -n "$memQQ"; then
			memQQ=$(($memQQ / 1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB。配置文件目录在 [ /data/media/0/Android/QQ微信负优化 ] " "$MODPATH/module.prop"
		elif test -n "$memWE"; then
			memWE=$(($memWE / 1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，微信运行内存 "$memWE" MB。配置文件目录在 [ /data/media/0/Android/QQ微信负优化 ] " "$MODPATH/module.prop"
		fi
	}
}

if test -e $MODPATH/disable -o -e $MODPATH/remove; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

if test "$(topapp)" != "com.tencent.mm" -a "$(topapp)" != "com.tencent.mobileqq"; then
	killapp
	calculate_mem
fi


