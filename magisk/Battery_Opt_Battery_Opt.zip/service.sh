#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动
until [ "$(getprop sys.boot_completed)" -eq "1" ]; do
  sleep 2
done
sleep 10
dumpsys deviceidle disable all
sleep 0.2
dumpsys deviceidle unforce
sleep 0.2
source /data/adb/modules/Battery_Opt/common/GClean.sh

# 息屏Doze
while :
do
    #识别屏幕和Doze状态
    screen=`dumpsys window policy | grep "mInputRestricted"|cut -d= -f2`
    dumpsys deviceidle | grep -q Enabled=true
    check=$?

    #进入或退出Doze
    if [[ $screen = true ]]; then
        if [[ $check = 1 ]]; then
            # 执行清理垃圾脚本
            sh /data/adb/modules/Battery_Opt/common/GClean.sh
            Time=$(date +%Y-%m-%d-%H:%M:%S) 
            echo "开始睡眠时间: "$Time"" >> $txt
            sleep 2
            dumpsys deviceidle enable deep
            sleep 0.2
            dumpsys deviceidle force-idle deep
        fi
    else
        if [[ $check = 0 ]]; then
            dumpsys deviceidle disable all
            sleep 0.2
            dumpsys deviceidle unforce
            AwakeTime=$(date +%Y-%m-%d-%H:%M:%S)
            echo "结束睡眠时间: "$AwakeTime"" >> $txt
        fi
    fi
   sleep 8
done
