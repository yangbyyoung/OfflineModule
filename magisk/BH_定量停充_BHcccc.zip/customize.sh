SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************
 "


confbh="/data/media/0/Android/BHcharging"
conf="$confbh/files.conf"
mkdir $confbh
if [[ -f $MODPATH/files.conf ]]; then
	Stop_charging=$(sed '/^Stop_charging=/!d;s/.*=//' $conf)
	Start_charging=$(sed '/^Start_charging=/!d;s/.*=//' $conf)
	Specify_milliseconds=$(sed '/^Specify_milliseconds=/!d;s/.*=//' $conf)
	Cycle_time=$(sed '/^Cycle_time=/!d;s/.*=//' $conf)
else
	Stop_charging=100
	Start_charging=80
	Specify_milliseconds=20
	Cycle_time=20
fi
cat $MODPATH/files.conf > $conf
sed -i "/Stop_charging/c Stop_charging=$Stop_charging" $conf
sed -i "/Start_charging/c Start_charging=$Start_charging" $conf
sed -i "/Specify_milliseconds/c Specify_milliseconds=$Specify_milliseconds" $conf
sed -i "/Cycle_time/c Cycle_time=$Cycle_time" $conf
echo "/data/adb/modules/BHcccc/Q.sh" > $confbh/加入q群.sh
pathd='/proc/driver/charger_limit&开始=100&停止=1
/proc/driver/charger_limit_enable&开始=0&停止=1
/proc/mtk_battery_cmd/en_power_path&开始=1&停止=0
/sys/class/power_supply/battery/batt_slate_mode&开始=0&停止=1
/sys/class/power_supply/battery/battery_charging_enabled&开始=1&停止=0
/sys/class/power_supply/battery/charge_charger_state&开始=1&停止=0
/sys/class/power_supply/battery/connect_disable&开始=0&停止=1
/sys/class/power_supply/battery/store_mode&开始=0&停止=1
/sys/class/power_supply/idt/pin_enabled&开始=1&停止=0
/sys/class/power_supply/main/adapter_cc_mode&开始=0&停止=1
/sys/kernel/debug/google_charger/chg_mode&开始=1&停止=0
/sys/kernel/debug/google_charger/chg_suspend&开始=0&停止=1
/sys/kernel/debug/google_charger/input_suspend&开始=0&停止=1
/sys/class/qcom-battery/input_suspend&开始=0&停止=1
/sys/class/battery/input_suspend&开始=0&停止=1
/sys/class/power_supply/battery/input_suspend&开始=0&停止=1'
#这排序是有说法的瞎改会失效
for i in $pathd; do
	hpath=$(echo $i | cut -d '&' -f1)
	ks=$(echo $i | cut -d '&' -f2 | sed '/^开始=/!d;s/.*=//')
	tz=$(echo $i | cut -d '&' -f3 | sed '/^停止=/!d;s/.*=//')
	if [[ ! $i == '' ]]; then
		if [[ -f $hpath ]]; then
			sed -i "/USBpath/c USBpath=$hpath" $conf
			sed -i "/start/c start=$ks" $conf
			sed -i "/stop/c stop=$tz" $conf
		fi
	fi
done
set_perm_recursive $MODPATH 0 0 0755 0777