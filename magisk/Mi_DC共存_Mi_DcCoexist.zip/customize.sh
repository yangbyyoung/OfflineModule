#!/system/bin/sh
DUBUG_FLAG=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=false

on_install() {
#代码是从某位大佬那里截过来的，我只是保存了代码，时间有点长了忘了是谁了。原代码大佬看见请见谅，可私聊我维权
#DC与120并存 
    mkdir -p $MODPATH/system/product/etc/device_features/
    mkdir -p $MODPATH/system/vendor/etc/device_features/
    cp -rf /product/etc/device_features/* $MODPATH/system/product/etc/device_features/
    cp -rf /vendor/etc/device_features/* $MODPATH/system/vendor/etc/device_features/
    sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODPATH/system/vendor/etc/device_features/*
    sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODPATH/vendor/etc/device_features/*
    sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODPATH/system/product/etc/device_features/*
    echo "- Mi Dc Coexist，重启即可↘"
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}