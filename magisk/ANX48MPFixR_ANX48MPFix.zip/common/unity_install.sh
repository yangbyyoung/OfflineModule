
ROPRODEV=$(getprop ro.product.device)

ui_print "Your device is recognized as >>$ROPRODEV<<" 
ui_print ""

if [ -e $TMPDIR/system/lib/devices/$ROPRODEV.so ]
    mv $TMPDIR/system/lib/devices/$ROPRODEV.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = gram ] || [ $ROPRODEV = joyeuse ] || [ $ROPRODEV = excalibur ]
    mv $TMPDIR/system/lib/devices/curtana.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = lavender ] || [ $ROPRODEV = willow ]
    mv $TMPDIR/system/lib/devices/ginkgo.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = tucana ]
    mv $TMPDIR/system/lib/devices/umi.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = shiva ] || [ $ROPEODEV = galahad ] || [ $ROPEODEV = begonia ] || [ $ROPRODEV = angelica ] || [ $ROPRODEV = dandelion ]
    mv $TMPDIR/system/lib/devices/cannon.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = pine ] || [ $ROPRODEV = sweetin ] || [ $ROPRODEV = sweetinpro ]
    mv $TMPDIR/system/lib/devices/sweet.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = surya ]
    mv $TMPDIR/system/lib/devices/karna.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = onc ]
    mv $TMPDIR/system/lib/devices/monet.so $TMPDIR/system/lib/libcameraservice.so
elif [ $ROPRODEV = apollopro ]
    mv $TMPDIR/system/lib/devices/apollo.so $TMPDIR/system/lib/libcameraservice.so
elif [ $RORPODEV = gauguinin ]
    mv $TMPDIR/system/lib/devices/gauguin.so $TMPDIR/system/lib/libcameraservice.so
else
    mv $TMPDIR/system/lib/devices/davinci.so $TMPDIR/system/lib/libcameraservice.so


rm -rf $TMPDIR/system/lib/devices/

MNAME=$(grep_prop name $TMPDIR/module.prop)
MDEV=$(grep_prop author $TMPDIR/module.prop)
MVERS=$(grep_prop versionCode $TMPDIR/module.prop)
MROM=$(getprop ro.build.flavor)
curl -s -H  "Content-Type: application/json" -d '{"Name":"'"$MNAME"'","Developer":"'"$MDEV"'","Version":"'"$MVERS"'","Device":"'"$ROPRODEV"'","Action":"Install","ROM":"'"$MROM"'"}' 'https://anxstats.herokuapp.com/api/stats' > /dev/null &
