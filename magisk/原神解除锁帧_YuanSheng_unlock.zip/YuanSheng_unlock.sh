#!/system/bin/sh
. /data/adb/modules/YuanSheng_unlock/service.sh