#!/system/bin/sh

function kmsg_logcat(){
if test -e /proc/kmsg ;then
	echo -e "\n抓取kmsg内核日志中……"
	echo "在后台运行20s……"
	echo "可退出终端界面……"
	timeout 20s cat /proc/kmsg | grep -Ei 'charger|batteryd|healthd|charge|battery' > "${0%/*}/kmsg_charge.json"
else
	echo "不存在/proc/kmsg！"
fi
}

function Running_logcat(){
if test "$(which -a logcat)" != "" ;then
	echo -e "\n抓取logcat日志中……"
	echo "在后台运行20s……"
	echo -e "\n可退出终端界面……\n"
	timeout 20s logcat -b all -v color | grep -Ei 'charger|batteryd|healthd|charge|battery' > "${0%/*}/logcat_charge.json"
else
	echo "不存在logcat！"
fi
}

function Running_dmesg(){
if test "$(which -a dmesg)" != "" ;then
	echo -e "\n抓取dmesg日志中……"
	dmesg | grep -Ei 'charger|batteryd|healthd|charge|battery' > "${0%/*}/dmesg_charge.json"
	echo "可退出终端界面……"
else
	echo "不存在dmesg！"
fi
}


if test "$(dumpsys deviceidle get charging)" = "true" ;then
	(kmsg_logcat &)
	(Running_logcat &)
	(Running_dmesg &)
else
	echo -e '\n\n请尝试在\e[31;40m充电\e[0m时尝试抓取日志！\n\n'
	(kmsg_logcat &)
	(Running_logcat &)
	(Running_dmesg &)
fi

