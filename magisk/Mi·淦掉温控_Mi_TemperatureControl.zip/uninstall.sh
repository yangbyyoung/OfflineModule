chmod 777 /data/vendor/thermal/config
chmod 777 /data/vendor/thermal/config/*
chattr -i /data/vendor/thermal/config/*
cp -f $MODPATH/backup/* /data/vendor/thermal/config/
rm -rf /data/adb/modules/Mi_TemperatureControl/
rm -rf /data/user/0/com.miui.powerkeeper/*
rm -rf /data/system/package_cache/*
rm -rf /data/app/com.miui.powerkeeper/*