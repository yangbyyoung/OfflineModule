#!/sbin/sh

SKIPUNZIP=0

ui_print "- 安装..."
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
