﻿OIFS=$IFS; IFS=\|

case $(echo $(basename $ZIPFILE) | tr '[:upper:]' '[:lower:]') in
	*clearG1*) microG=true; clearG1=true; clearG2=false; clearG3=false;;
	*clearG2*) microG=true; clearG1=false; clearG2=true; clearG3=false;;
	*clearG3*) microG=true; clearG1=false; clearG2=false; clearG3=true;;
	*clearG4*) microG=false; clearG4=true; clearG5=false; clearG6=true;;
	*clearG5*) microG=false; clearG4=false; clearG5=true; clearG6=true;;
	*clearG6*) microG=false; clearG4=false; clearG5=false; clearG6=true;;
	*nmicroG*) microG=false; clearG1=false; clearG2=false; clearG3=false;;
esac
case $(echo $(basename $ZIPFILE) | tr '[:upper:]' '[:lower:]') in
	*nk*) NK=true;;
esac
IFS=$OIFS


		if
		 [ -z $microG ] || [ -z $clearG1 ] || [ -z $clearG2 ] || [ -z $clearG3 ]; then
			echo " _________   ________       ______       _________   ________       ______      ";
			echo "/________/\ /_______/\     /_____/\     /________/\ /_______/\     /_____/\     ";
			echo "\__.::.__\/ \::: _  \ \    \:::_ \ \    \__.::.__\/ \::: _  \ \    \:::_ \ \    ";
			echo "   \::\ \    \::(_)  \ \    \:\ \ \ \      \::\ \    \::(_)  \ \    \:\ \ \ \   ";
			echo "    \::\ \    \:: __  \ \    \:\ \ \ \      \::\ \    \:: __  \ \    \:\ \ \ \  ";
			echo "     \::\ \    \:.\ \  \ \    \:\_\ \ \      \::\ \    \:.\ \  \ \    \:\_\ \ \ ";
			echo "      \__\/     \__\/\__\/     \_____\/       \__\/     \__\/\__\/     \_____\/ ";
			echo "                                                                                ";
			ui_print "- 准备好配置zram选项了吗 ?"
			ui_print "   Ready to configure your zram options?"
			ui_print "- 按下音量加=是，按下音量减=不，我是高贵的MIUI用户我需要我的vip通道"
			ui_print "   Press Volume plus = Yes, press Volume down = No, I am a noble MIUI user and I need my VIP access "
			if $VKSEL; then
				ui_print " "
				ui_print " "
				ui_print " "
				ui_print "- 是否需要开启2G大小的zram？"
#				ui_print "   Pick among 1, 2 or 3" 
				ui_print "   Do I need to turn on a 2GB zram?" 
				ui_print " "
#				ui_print "   Vol+ = Icon Pack-1, Vol- = Show next"
				ui_print "- 按下音量加=是，按下音量减=显示下一个选项"
				ui_print "   Vol+ = Yes, Vol- = Show the next option"
				microG=true
				if $VKSEL; then
					clearG1=true
					clearG2=false
					clearG3=false					
				else
				    ui_print " "
				    ui_print " "
					ui_print "- 选择开启4G大小的zram或者直接关闭zram(关闭后也可自定义zram大小)"
					ui_print "   Choose to turn on the 4G zRAM or turn off the ZRAM directly (you can also customize the zRAM size after turning off)" 
					ui_print "   Vol+ = Yes, custom, Vol- = Close the zram"
					if $VKSEL; then
						clearG1=false
						clearG2=true
						clearG3=false	
					else
						clearG1=false
						clearG2=false
						clearG3=true	
					fi
				fi
			else
				microG=false
#				ui_print "- 安装被取消，模块已卸载" 
#				ui_print "  Installation cancelled, module uninstalled" 
#				exit 1
#				if $VKSEL; then
				ui_print " "
				ui_print " "
				ui_print " "
				ui_print "- 是否需要开启2G大小的zram？"
#				ui_print "   Pick among 1, 2 or 3" 
				ui_print "   Do I need to turn on a 2GB zram?" 
				ui_print " "
#				ui_print "   Vol+ = Icon Pack-1, Vol- = Show next"
				ui_print "- 按下音量加=是，按下音量减=显示下一个选项"
				ui_print "   Vol+ = Yes, Vol- = Show the next option"
				if $VKSEL; then
					clearG4=true
					clearG5=false
					clearG6=false					
				else
				    ui_print " "
				    ui_print " "
					ui_print "- 选择开启4G大小的zram或者直接关闭zram(关闭后也可自定义zram大小)"
					ui_print "   Choose to turn on the 4G zRAM or turn off the ZRAM directly (you can also customize the zRAM size after turning off)" 
					ui_print "   Vol+ = Yes, custom, Vol- = Close the zram"
					if $VKSEL; then
						clearG4=false
						clearG5=true
						clearG6=false	
					else
						clearG4=false
						clearG5=false
						clearG6=true	
					fi
				fi
			fi
		else
			ui_print "- 模块出错，意外退出" 
	     	ui_print "  The microG has been installed successfully" 
			exit 1
		fi
	

#ui_print "- Follow github：taoaoooo/qq群：273145623"
#ui_print "  Follow Github: taoaoooo/QQ group: 273145623"

mkdir -p $TMPDIR/system/vendor/bin
mkdir -p $TMPDIR/system/etc

if $microG; then
	ui_print ">"
	if $clearG1; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:80 lines"
		ui_print "-  case 1 Copy the file to be operated..."
		cp -f /system/vendor/bin/init.qcom.post_boot.sh $TMPDIR/system/vendor/bin || echo "error code:120 lines"
#		vi -e $TMPDIR/system/vendor/bin/init.qcom.post_boot.sh<<-!
#		sed ' s/echo\(.*\)\/sys\/block\/zram0\/disksize/echo 2147483648 \> \/sys\/block\/zram0\/disksize/g ' $TMPDIR/system/vendor/bin/init.qcom.post_boot.sh
		cd $TMPDIR/system/vendor/bin || echo "error code:123 lines"
		ls
		sed -ie ' s/echo\(.*\)\/sys\/block\/zram0\/disksize/echo\ 2147483648\ \>\ \/sys\/block\/zram0\/disksize/g ' init.qcom.post_boot.sh
#		:wq
#		!
		ui_print "-  恢复根目录只读..."
		mount -o ro,remount /
#		卸载gsf
	elif $clearG2; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:80 lines"
		ui_print "-  Copy the file to be operated..."
		cp -f /system/vendor/bin/init.qcom.post_boot.sh $TMPDIR/system/vendor/bin || echo "error code:84 lines"
#		vi -e $TMPDIR/system/vendor/bin/init.qcom.post_boot.sh<<-!
#		:1,%s/echo\(.*\)\/sys\/block\/zram0\/disksize/echo 4294967296 \> \/sys\/block\/zram0\/disksize/g
#		:%s/echo.*\/sys\/block\/zram0\/disksize/echo 4294967296 \> \/sys\/block\/zram0\/disksize/g

#		:wq
#		!
		cd $TMPDIR/system/vendor/bin || echo "error code:142 lines"
		ls
		sed -ie ' s/echo\(.*\)\/sys\/block\/zram0\/disksize/echo\ 4294967296\ \>\ \/sys\/block\/zram0\/disksize/g ' init.qcom.post_boot.sh
		ui_print "-  恢复根目录只读..."
		mount -o ro,remount /
	elif $clearG3; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:80 lines"
		ui_print "-  Copy the file to be operated..."
		cp -f /system/vendor/bin/init.qcom.post_boot.sh $TMPDIR/system/vendor/bin || echo "error code:84 lines"
		cd $TMPDIR/system/vendor/bin || echo "error code:142 lines"
		sed -ie ' s/echo\(.*\)\/sys\/block\/zram0\/disksize/echo\ 0\ \>\ \/sys\/block\/zram0\/disksize/g ' init.qcom.post_boot.sh

		ui_print "-  Zram已关闭，如果你后续需要开启请重新运行此安装程序"
		ui_print "   Zram has been turned off, please re-run this setup if you need to turn it on later"
		ui_print "-  或者你也可以在/data/adb/modules/Zram_tao/system/vendor/bin下修改sh实现自定义大小"
		ui_print "   Alternatively, you can modify sh under /data/adb/modules/Zram_tao/system/vendor/bin"
		ui_print "-  找到”echo 0 > /sys/block/zram0/disksize“修改0的值大小，比如4294967296是4G，保存后重启生效"
		ui_print "   Find ”echo 0 > /sys/block/zram0/disksize“ modify zero value size, such as 4294967296 is 4 g, save after restart to take effect"
		mount -o ro,remount /
		ui_print "-  恢复根目录只读..."
	fi
else
	if $clearG4; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:156 lines"
		ui_print "-  Copy the file to be operated..."
		cp -f /system/etc/mcd_default.conf $TMPDIR/system/etc || echo "error code:158 lines"
		cd $TMPDIR/system/etc || echo "error code:142 lines"
		sed -ie ' s/"zram_size_MB"\: "\(.*\)"\,/"zram_size_MB"\: "512 1536:2049 2560:2049 3256:2049 4915:2049 6553:2049 8892:2049 12888:2049"\,/g ' mcd_default.conf
		ui_print "-  恢复根目录只读..."
		mount -o ro,remount /
#		卸载gsf
	elif $clearG5; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:80 lines"
		ui_print "-  Copy the file to be operated..."
		cp -f /system/etc/mcd_default.conf $TMPDIR/system/etc || echo "error code:158 lines"
		cd $TMPDIR/system/etc || echo "error code:142 lines"
		sed -ie ' s/"zram_size_MB"\: "\(.*\)"\,/"zram_size_MB"\: "512 1536:4097 2560:4097 3256:4097 4915:4097 6553:4097 8892:4097 12888:4097"\,/g ' mcd_default.conf
		ui_print "-  恢复根目录只读..."
		mount -o ro,remount /
	elif $clearG6; then
		ui_print "-  挂载根目录..."
		mount -o rw,remount / || echo "error code:80 lines"
		ui_print "-  MIUI Copy the file to be operated..."
		cp -f /system/etc/mcd_default.conf $TMPDIR/system/etc || echo "error code:158 lines"
		cd $TMPDIR/system/etc || echo "error code:142 lines"
		sed -ie ' s/"zram_size_MB"\: "\(.*\)"\,/"zram_size_MB"\: "512 1536:0 2560:0 3256:0 4915:0 6553:0 8892:0 12888:0"\,/g ' mcd_default.conf
		ui_print "-  Zram已关闭，如果你想自定义zram..."
		ui_print "   Zram is closed, if you want to customize Zram..."
		ui_print "-  你也可以在/data/adb/modules/Zram_tao/system/etc下修改conf实现自定义大小"
		ui_print "   You can also customize conf sizes in /data/adb/modules/Zram_tao/system/etc"
		ui_print "-  找到” \"zram_device_num\": 1,“修改下一行冒号后所有0的值，比如1024是改成1G，保存后重启生效"
		ui_print "   Find” \"zram_device_num\": 1,“change the value of all zeros after the colon in the next line, for example, change 1024 to 1G, save and restart"
		mount -o ro,remount /
		ui_print "-  恢复根目录只读..."
	fi
fi




ui_print " "
ui_print " "
ui_print "- Done  -"
