#!/bin/bash

PROCESS_NAME="shizuku_server"
# 获取脚本目录
script_dir=$(dirname $0)
# 拼接 log 文件路径
log_file="$script_dir/log.txt"
# 创建 log 文件
touch $log_file

echo "$(date): 开机了" >$log_file

sleep 20

while [ ! -e "/storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh" ]; do
    echo "$(date): 正在寻找Shizuku启动文件，请确保安装了Shizuku应用" >>$log_file
    sleep 10
done

if [ ! -e "/storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh" ]; then
    echo "$(date): Shizuku启动文件不存在" >>$log_file
    exit
else
    echo "$(date): 已找到Shizuku启动文件" >>$log_file
fi

if pgrep -f $PROCESS_NAME >/dev/null; then
    echo "$(date): 进程 $PROCESS_NAME 正在运行" >>$log_file
    echo "$(date): 脚本退出，未执行任何动作" >>$log_file
    exit
else
    echo "$(date): 进程 $PROCESS_NAME 未运行，正在尝试启动" >>$log_file
    sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh
fi

sleep 10

if pgrep -f $PROCESS_NAME >/dev/null; then
    echo "$(date): 进程 $PROCESS_NAME 运行成功" >>$log_file
    echo "$(date): Shizuku启动完成，脚本退出" >>$log_file
    exit
else
    echo "$(date): 未知的错误导致 $PROCESS_NAME 无法启动，请前往社区交流" >>$log_file
fi

echo "$(date): 脚本退出" >>$log_file
exit
