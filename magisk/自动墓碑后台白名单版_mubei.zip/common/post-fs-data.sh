#!/system/bin/sh

MODDIR=${0%/*}
#以下代码来自@myflavor 非常感谢大佬。
resetprop -n persist.sys.gz.enable false
resetprop -n persist.sys.brightmillet.enable false
resetprop -n persist.sys.powmillet.enable false
resetprop -n persist.sys.millet.handshake false
#resetprop -n persist.sys.millet.newversion false
#resetprop -n persist.sys.millet.cgroup1 true
