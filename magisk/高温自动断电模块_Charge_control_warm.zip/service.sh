#!/system/bin/sh
/sbin/magisk su -c 'sh /data/adb/modules/Charge_control_warm/data.sh'
