# Zygisk - Cleaner Hooks

Provide hooks for Cleaner.
