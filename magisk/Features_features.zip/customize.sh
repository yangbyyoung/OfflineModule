
print_modname() {
  ui_print "酷安@主张"
}

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}


CommonPath=$MODPATH/common
if [ ! -d ${CommonPath} ];then
  ui_print "最好下个救砖模块"
  
elif [ "`ls -A ${CommonPath}`" = "" ];then
    ui_print "模块高级设置为空!"
    rm  -rf  ${CommonPath}
else

  ui_print "最好下个救砖模块"
  mv  ${CommonPath}/*  $MODPATH
  rm  -rf ${CommonPath}

fi


