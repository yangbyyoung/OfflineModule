#!/system/bin/sh
#来自酷安@风雪如花剑如霜
/sbin/.magisk/busybox/chattr -i -a -A /cache/magisk.log
chmod 777 /cache/magisk.log

/sbin/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.miui.home/cache/debug_log
chmod 777 /data/user_de/0/com.miui.home/cache/debug_log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log

then 
K=/sbin/.magisk/busybox/chattr
$K -i $D/tad
$K -i $D/GX_Download
$K -i $D/miad
$K -i $D/umeng_cache
$K -i $D/sina/weibo/imageMapper_cache