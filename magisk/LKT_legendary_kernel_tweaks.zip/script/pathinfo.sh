#!/system/bin/sh
# Module Path Header
# LKT V5.1
# Author: korom42
# Credits: Matt Yang

SCRIPT_DIR="/script"
BIN_DIR="/bin"
MODULE_PATH="$(dirname $(readlink -f "$0"))"
MODULE_PATH="${MODULE_PATH%$SCRIPT_DIR}"
PANEL_FILE="/data/LKT_panel.txt"
PATH="/sbin/.magisk/busybox:/sbin:/system/sbin:/product/bin:/apex/com.android.runtime/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin"
