file=/system/vendor/etc/wifi/WCNSS_qcom_cfg.ini
logdir=/data/vendor/wlan_logs

if test -e $file;then
mkdir -p $MODPATH$(dirname $file)
cp -rf $file $MODPATH$(dirname $file)
sed 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
sed -i 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
fi

test -e $logdir && rm -rf "$logdir/*"