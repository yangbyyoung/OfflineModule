#!/system/bin/sh
setenforce 0
echo 0 > /sys/fs/selinux/enforce