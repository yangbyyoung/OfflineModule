SKIPUNZIP=0
MODDIR=${0%/*}

prop=$(getprop)

ui_print "——————————"
ui_print "The module can customize some display parameters including MEMC and HDR"
ui_print "Configuration file is in /data/adb/modules/iris_helper"
if [ -f /data/adb/modules/scene_systemless/iris/iriscfgcustomize.conf ]; then
  ui_print "Hydro BrÛleur (outdated version) with Iris Helper detected"
  abort
fi
if [ -f /data/adb/modules/ab_optimizer/iris/iriscfgcustomize.conf ]; then
  ui_print "Hydro BrÛleur with Iris Helper detected"
  abort
fi
if [ -f /data/adb/modules/iris_helper/iriscfgcustomize.conf ]; then
  cp /data/adb/modules/iris_helper/iriscfgcustomize.conf $MODPATH/iris/iriscfgcustomize.conf
fi
sleep 0.3

ui_print "——————————"
ui_print "Installation completed"
ui_print "Please ensure that you have been aware of the above precautions"
sleep 0.2
ui_print "Now, you will rejoice this! "