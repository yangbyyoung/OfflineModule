  #!/sbin/sh
  status=$(cat /sys/class/power_supply/battery/status)
  current=$(cat /sys/class/power_supply/battery/current_now)
  if [[ $status == "Charging" ]]
  then
    ui_print "! 请拔出充电器再安装!"
    exit 1
  fi
  if [[ $current -gt 0 ]]
  then
    ui_print "! 检测到与作者测试手机相反的电流极性!"
    ui_print "! 您可能需要将模块目录下的minus的值改为-1"
    ui_print "! 否则模块将显示相反的电量!"
    sleep 5
  fi
  ui_print "- Installing..."
  ui_print "- 理论上来说，模块目录位于/data/adb/modules/10wslowcharge"
  ui_print "- 正常充电电流被设定为 2000 mA,配置文件为current_target"
  ui_print "- 降流电量阈值被设定为 80 ,配置文件为capacity_limit"
  ui_print "- 高温降流阈值被设定为 42 °C,配置文件为temperature_limit"
  ui_print "- 降流电流被设定为 500 mA,配置文件为current_limit"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 配置导入完成,如有需要请前往模块根目录修改"