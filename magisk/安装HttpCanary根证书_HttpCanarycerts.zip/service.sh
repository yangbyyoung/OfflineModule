MODDIR=${0%/*}

touch /data/data/com.guoshi.httpcanary/cache/HttpCanary.jks
chmod 0600 /data/data/com.guoshi.httpcanary/cache/HttpCanary.jks