rm -rf /data/adb/BATTERYOPT
