#!/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

function show_value() {
	local value=$1
	local file=/data/media/0/Android/QQ微信负优化/QQ微信负优化.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function pose() {
	local file=/data/media/0/Android/QQ微信负优化/息屏清理进程.conf
	if test $(show_value "息屏目标应用") == QQ; then
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d;/com.tencent.mm/d'
	elif test $(show_value "息屏目标应用") == 微信; then
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d;/com.tencent.mobileqq/d'
	else
		cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d'
	fi
}

if $(dumpsys deviceidle get screen); then
	exit 0
else
	for i in $(pose); do
		pgrep -f "$i" | while read PID; do
			kill -9 "$PID"
		done
	done
fi
