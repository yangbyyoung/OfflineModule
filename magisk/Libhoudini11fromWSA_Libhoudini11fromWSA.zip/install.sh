SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=true

print_modname() {
  ui_print "**********************************"
  ui_print " Libhoudini for x86_64 Android11 "
  ui_print "**********************************"
}

ui_print "- Device sdk: $API"
ui_print "- Device ARCH: $ARCH"

# Check Android Version
if [[ "$API" -lt 30 ]]; then
  ui_print "! Unsupported sdk: $API"
  abort "- [ABORT] This module only support sdk 30 (Android 11) and higher versions."
fi

# Check Device Architecture
if [[ $ARCH != x64 ]]; then
  ui_print "! Unsupported ARCH: $ARCH"
  abort "- [ABORT] This module only support x86_64(x64) devices!"
fi

REPLACE="
/system/lib/arm
/system/lib64/arm64
/system/bin/arm
/system/bin/arm64
/system/vendor/etc/binfmt_misc
"

on_install() {
  ui_print "- Copying files in your operating-system"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Default permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/houdini 0 0 0755
set_perm $MODPATH/system/bin/houdini64 0 0 0755
set_perm $MODPATH/system/bin/arm/linker 0 0 0755
set_perm $MODPATH/system/bin/arm64/linker64 0 0 0755
set_perm $MODPATH/system/vendor/lib/libhoudini.so 0 0 0755
set_perm $MODPATH/system/vendor/lib64/libhoudini.so 0 0 0755
set_perm $MODPATH/system/lib/libhoudini.so 0 0 0755
set_perm $MODPATH/system/lib64/libhoudini.so 0 0 0755
set_perm_recursive $MODPATH/system/vendor/etc/binfmt_misc 0 0 0755 0755
set_perm_recursive $MODPATH/system/lib/arm 0 0 0755 0755
set_perm_recursive $MODPATH/system/lib/arm/nb 0 0 0755 0755
set_perm_recursive $MODPATH/system/lib64/arm64 0 0 0755 0755
set_perm_recursive $MODPATH/system/lib64/arm64/nb 0 0 0755 0755