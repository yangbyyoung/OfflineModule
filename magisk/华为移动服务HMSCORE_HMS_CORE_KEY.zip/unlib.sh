#/system/bin/sh

function unzip_lib() {
	alias unzip="$(magisk --path)/.magisk/busybox/unzip"

	case "$ARCH" in
	arm64*) libtype='arm64' lib='arm64-v8a' ;;
	arm*) libtype='arm' lib='armeabi-v7a' ;;
	x86_64*) libtype='x86_64' lib='x86_64' ;;
	x86*) libtype='x86' lib='x86' ;;
	esac
	echo ""
	echo "∞————————————————————————∞"
	echo ""
	echo "－您的设备架构是：$lib"
	echo "－正在为您解压lib中……"
	for file in $(find $MODPATH -iname "*.apk" -type f); do
		folder=${file%/*}
		unlib="lib/$lib"
		test -e "$folder/lib/$libtype" && rm -rf "$folder/lib/$libtype"
		unzip -o -q "$file" "$unlib/*" -d "$folder" && {
			test -d $folder/lib/armeabi -a ! -d $folder/lib/armeabi-v7a -a "$libtype" = "arm" && lib='armeabi'
			mv "$folder/lib/$lib" "$folder/lib/$libtype"
		}
	done && {
		echo "－完成！"
		echo ""
		echo "∞————————————————————————∞"
	}
}

unzip_lib
