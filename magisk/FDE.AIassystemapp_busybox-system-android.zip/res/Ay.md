### Información IA

FDE tiene una implementación de IA, que funciona en cualquier dispositivo igual que el propio FDE.
Su propósito es comprobar el escenario de uso actual y adaptar algunos parámetros del sistema sobre
la marcha para dar la mejor experiencia para cada escenario de uso. Todos los boost/turbos se apagan
automáticamente cuando la pantalla está apagada. Todas las acciones se registran. Lo mejor de todo
es que NO consume batería.

---

#### Lo que se activa automáticamente cuando es posible:

**GPU Turbo**:\
IA detectará si tu GPU puede ejecutar la implementación FDE GPU Turbo y te lo hará saber en el log.
GPU Turbo medirá la carga de la GPU, y si se mantiene alta (bajo la carga pesada) IA empujará la GPU
al máximo durante unos 30 segundos hasta que se produzca la siguiente comprobación de carga. Una vez
que la carga de la GPU disminuya, por defecto se restaurarán las frecuencias originales. Esto no
hará que sus juegos se ejecuten más rápido, pero debe hacerlos más estables, porque el gobernador
no saltará de una frecuencia a otra bajo carga pesada. Esto no depende del nombre
del paquete - monitoriza directamente las cargas de la GPU por cualquier razón
(juego, benchmark, etc.), lo que lo hace universal. También depende de la temperatura - los valores
umbral son dinámicos, por lo que no aumentará la frecuencia si el dispositivo se sobrecalienta.
Activo sólo cuando la pantalla está encendida. Soportado en la mayoría de Adreno y Mali GPU.
No entra en conflicto con la implementación GPU Turbo de Huawei.

**GPU Turbo heredado**:\
Este modo Turbo se seleccionará si el driver GPU de tu kernel no proporciona información de carga en
tiempo real. La diferencia con el modo GPU Turbo normal es que el modo heredado sólo se activará
en cualquier proceso o juego de la lista de aplicaciones pesadas que se esté ejecutando sin depender
de la carga de la GPU en tiempo real. También puedes activar el GPU turbo heredado cambiando
manualmente el modo IA a rendimiento. Activa la opción de refuerzo de juegos pesados en la
configuración para que este modo funcione automáticamente. Activo sólo cuando la pantalla está
encendida. Compatible con algunas GPUs Mali y Vivante.

**Refuerzo Framebuffer**:\
IA detectará si tu SoC puede ejecutar la implementación FDE Refuerzo Framebuffer y te lo hará saber
en el log. IA aumenta automáticamente las frecuencias de framebuffer, cuando la pantalla está
encendida y la carga de la GPU es superior al 30%. Esto resultará en un framerate más estable
mientras se renderiza la pantalla. Activo sólo cuando la pantalla está encendida. Compatible con
algunos SoCs Qualcomm.

**CPU Turbo**:\
La IA detectará si tu CPU puede ejecutar la implementación FDE CPU Turbo y te lo hará saber en el
registro. CPU Turbo medirá la carga de la CPU, y si se mantiene alta (bajo la carga pesada) IA
hará que el gobernador de la CPU CPU más sensible y hará que mantenga la frecuencia de la CPU
por encima de la 'frecuencia de alta velocidad' (~la mitad de la máxima). durante ~30 segundos hasta
que se produzca la siguiente comprobación de carga. Esto no depende del nombre del paquete controla
directamente la carga de la CPU por cualquier razón (juego, benchmark, etc.), haciendo esto
universal. Esto depende de la temperatura - los valores umbral son dinámicos, y no aumentará
las cosas si el dispositivo se está sobrecalentando. Sólo se activa cuando la pantalla está
encendida. Compatible con interactive, ondemand, schedutil y otros gobernadores basados en estos.

**Aprendizaje automático**:\
Aprendizaje automático (ML) se utiliza si tu dispositivo soporta CPU y/o GPU Turbo. ML aprenderá
cómo tu dispositivo adaptará algunos parámetros del sistema sobre la marcha. Si juegas mucho, la IA
obtendrá más rendimiento para ti. Si solo chateas y ves vídeos, la IA ahorrará energía. Si juegas
y chateas, la IA decidirá qué hacer por ti - eso es por lo que el aprendizaje automático esta ahi.
En FDE.AI el comportamiento de la aplicación,la elección hecha por el ML se puede configurar para
preferir siempre el ahorro de energía o la optimización del rendimiento.

**Sintonizador dinámico VM**:\
Comprueba el uso de RAM cada ~30 segundos y ajusta algunos parámetros de la máquina virtual
basándose en esta comprobación. Esto mejora la gestión de la caché en RAM. También informará si
el sistema tiene muy poca RAM libre. Activo sólo cuando la pantalla está encendida.

**El controlador thermal**:\
IA comprueba la temperatura del dispositivo e informa en el registro si el dispositivo se está
sobrecalentando. Los umbrales de CPU/GPU Turbo se calculan basándose en el valor leído del
controlador thermal, de modo que si que su dispositivo CPU/GPU Turbo dejará de aumentar la potencia
de tu dispositivo y/o lo hará con menos frecuencia. Si la temperatura del dispositivo es demasiado
alta, anulará cualquier configuración de throttling y lo activará hasta que la temperatura baje
un poco después de que se restaura a los anteriores parámetros de throttling.

**Detector de estado de carga**:\
La IA comprueba si el dispositivo se está cargando o no. Si se está cargando, la IA configura la VM
para un rendimiento óptimo. Una vez desenchufado el dispositivo, el perfil VM anterior se
restablecerá de acuerdo con el perfil de IA aprendido. El modo Force Doze (si está activado)
también se basa en esto, evitando que se ejecute mientras el dispositivo se está cargando.
Esta función no aumenta ninguna frecuencia y sólo ajusta la configuración de VM, por lo que no
es peligroso y no hará que el dispositivo se sobrecaliente. Si el throttling fue desactivado por el
usuario o por la IA (para aplicaciones/juegos pesados) - se activará de nuevo mientras el
dispositivo se está cargando. También mientras IA está en modo avanzado, se supervisa el estado
de ahorro de energía del sistema operativo Android. automáticamente al modo de ahorro de energía
y no activará el modo de rendimiento.
