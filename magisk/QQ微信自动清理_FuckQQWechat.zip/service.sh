#!/system/bin/sh
MODDIR=${0%/*}
sleep 5
chmod -R 777 $MODDIR/clean/*
crond -c $MODDIR/clean
