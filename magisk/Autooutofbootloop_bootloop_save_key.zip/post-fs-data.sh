#!/system/bin/sh

source "${0%/*}/util_functions.sh"

IFS=$'\n'

dir="
/cache
/cust
/d
/data
/dev
/lost+found
/mnt
/odm
/oem
/sdcard
/storage
/metadata 
/persist 
/mnt/vendor/persist
/data/unencrypted
"

for target in $dir 
do
if test -f "$target/dismod" ;then
change_description "[I] 已执行手动命令。" "[I] Manual command executed." "false" "true"
	run_main
		rm -rf "$target/dismod"
	reboot
	break
elif test -f "$target/remod" ;then
change_description "[I] 已执行手动命令。" "[I] Manual command executed." "false" "true"
	remove_module
		run_main
		rm -rf "$target/remod"
	reboot
	break
fi
done




