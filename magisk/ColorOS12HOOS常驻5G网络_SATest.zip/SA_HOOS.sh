#!/system/bin/sh
MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:$(magisk --path)/.magisk/busybox:/data/adb/modules/C++Busybox/busybox" 2>/dev/null

#HOOS
#5G状态
settings put system system 5g_nr_working 1
#不要问,这是关联5G命令行
resetprop persist.radio.testmode ture
resetprop persist.vendor.radio.optelopt_debug false
resetprop persist.vendor.radio.default_smart_sa_enabled false
resetprop persist.radio.ischinatelecom false
resetprop persist.radio.ischinamobile false
resetprop persist.vendor.radio.pingpong.duration false
resetprop persist.vendor.radio.smart_sa_screen_off_min false
resetprop persist.vendor.radio.smart_sa_dereg_timer_min false
resetprop persist.vendor.radio.smart_sa_enable_timeout_min false
resetprop persist.vendor.radio.smart_sa_keep_disable_min false
resetprop persist.vendor.radio.pingpong.count false
#不要问,这是打开5G开关
resetprop persist.vendor.radio.sa_enabled ture
# 这个开关 1.2.3.4
resetprop persist.vendor.radio.arfcn_test_mode 4
#不要问,这是智能5G开关
resetprop smart_fiveg false
settings put system system smart_fiveg false
#不要问,这是智能5G开关
resetprop persist.radio.usersetting.smart5g false
resetprop persist.radio.userchange.smart5g false
#不要问,这是智能SA/NSA开关
resetprop persist.vendor.radio.default_sa_enabled ture
resetprop persist.vendor.radio.default_smart_sa_enabled false

