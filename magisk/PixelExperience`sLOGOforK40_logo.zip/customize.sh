if [[ ! -f /data/adb/logo/OK ]];
then
    if [[ ! -d /data/adb/logo ]];
    then
      mkdir -p /data/adb/logo
      dd if="/dev/block/by-name/logo" of="/data/adb/logo/logo.img"
    fi
    dd if="$MODPATH/logo.img" of="/dev/block/by-name/logo"
    rm -f $MODPATH/logo.img
    touch /data/adb/logo/OK
else
  dd if="/data/adb/logo/logo.img" of="/dev/block/by-name/logo"
  rm -rf \
  $MODPATH /data/adb/modules/logo /data/adb/logo \
fi
fi