rm -rf /data/system/package_cache/*
rm -rf /data/adb/modules_update/MIUI_MiuiCamera
rm -rf /data/adb/modules/MIUI_MiuiCamera
