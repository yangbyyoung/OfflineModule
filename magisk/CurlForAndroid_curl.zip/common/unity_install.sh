mv -f $TMPDIR/$ARCH $TMPDIR/system
