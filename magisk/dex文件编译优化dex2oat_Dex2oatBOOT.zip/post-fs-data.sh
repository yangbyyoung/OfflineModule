#定义相关路径和文件
MODDIR=${0%/*}
DEX2OAT_CONFIG="/data/adb/Dex2oatBOOT/dex2oat基础配置.prop"

#读取配置
dexopt_ota=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^更新系统时=" | cut -f2 -d '=')
dexopt_boot=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^系统启动时=" | cut -f2 -d '=')
dexopt_install=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^安装应用时=" | cut -f2 -d '=')

resetprop -n pm.dexopt.ab-ota $dexopt_ota
resetprop -n pm.dexopt.boot $dexopt_boot
resetprop -n pm.dexopt.install $dexopt_install
