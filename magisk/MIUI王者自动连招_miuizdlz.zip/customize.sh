SKIPUNZIP=0
REPLACE="
/system/priv-app/MIUISecurityCenter
/system/priv-app/SecurityCenter
"