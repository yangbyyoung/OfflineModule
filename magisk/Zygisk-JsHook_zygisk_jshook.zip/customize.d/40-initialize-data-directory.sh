MODULE_DATA_PATH="/data/system/jshook"

if [ ! -f "$MODULE_DATA_PATH" ]; then
  ui_print "- Initialize module data directory"

  mkdir -p "$MODULE_DATA_PATH"
fi

echo "dataDirectory=$MODULE_DATA_PATH" >> "$MODPATH/module.prop"
