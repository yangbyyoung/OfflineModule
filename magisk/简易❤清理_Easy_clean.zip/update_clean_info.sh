DIR=$(dirname $(readlink -f $0))
#echo 清理目录：$1
#echo 清理文件：$2
#echo 当前目录：$DIR
info_path="/sdcard/Android/EasyClean"
path_num_d=$info_path/files/num_d
path_num_f=$info_path/files/num_f
#清理备份文件
num_dir=$(cat $path_num_d)
num_file=$(cat $path_num_f)
#开始计数
let num_dir=num_dir+$1
let num_file=numfile+$2
#保存计数
echo $num_dir >$path_num_d
echo $num_file >$path_num_f

sed -i "/^description=/c description=自动清理文件(夹)，超低功耗，配置位于：/sdcard/Android/EasyClean/Rules/ ✨累计清理: $num_dir个目录 | $num_file个文件 ✨" "$DIR/module.prop"
