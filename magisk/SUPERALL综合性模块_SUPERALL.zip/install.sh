SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'service_5Charge.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'service_7OffHW.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/media/theme/default/com.miui.packageinstaller' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/media/theme/default/com.android.settings' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/overlay/GestureLineOverlay.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/overlay/BsCharge.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermald-devices.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/hosts' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/sysconfig/qti_whitelist.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/sysconfig/power-save-conf.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/sysconfig/com.miui.core.config.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/auto-install2.json' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/auto-install.json' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall_0.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall_1.sh' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}