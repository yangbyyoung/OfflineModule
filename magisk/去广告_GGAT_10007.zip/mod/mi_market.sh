#!/bin/sh

sleep 10s

if test "$(getprop ro.miui.ui.version.name)" = "" ;then 
	echo "非MIUI！"
	exit 0
fi

disable_list='
com.xiaomi.market/com.xiaomi.market.testsupport.DebugService
com.xiaomi.market/com.xiaomi.gamecenter.preload.PreloadService
com.xiaomi.market/com.xiaomi.downloader.service.DownloadService
com.xiaomi.market/com.xiaomi.market.reverse_ad.wakeup.ReverseAdWakeUpService
com.xiaomi.market/com.xiaomi.market.reverse_ad.service.ReverseAdScheduleService
com.xiaomi.market/com.xiaomi.market.reverse_ad.page.WebReverseAdActivity
com.xiaomi.market/com.xiaomi.market.business_ui.directmail.SourceFileDownloadAdsActivity
'

for target in ${disable_list} ;do
	pm disable "${target}" >/dev/null
done

