MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    umount $2
    chmod +w $2

    echo "$1" | tee /dev/asopt_mask $2
    /bin/find $2 -exec mount /dev/asopt_mask {} \;
    rm /dev/asopt_mask
}

rm -rf /data/adb/modules/ct_module
lock_val "0" "/sys/devices/system/cpu/cpu*/core_ctl/enable"

killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
