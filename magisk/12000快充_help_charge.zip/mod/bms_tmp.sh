#!/system/bin/sh

export PATH=/system/bin:/data/adb/modules/Magisk_help_charge/busybox:$PATH

function key_echo(){
test -f "${2}" && {
	chmod 0644 "${2}" 
	echo "${1}" > "${2}"
	}
}

key_echo "200" "/sys/class/power_supply/bms/temp"

