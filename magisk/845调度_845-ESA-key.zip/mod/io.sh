function set_value() {
	if test -f "$2" ;then
		chmod 0777 "$2" > /dev/null 2>&1
		echo "$1" > "$2" 2>/dev/null
		chmod 0755 "$2" > /dev/null 2>&1
	fi
}


for i in $(find /sys/block/sd*/queue/iostats  /sys/block/sd*/queue/nomerges  /sys/block/dm*/queue/iostats /sys/block/dm*/queue/nomerges 2>/dev/null);do
set_value 0 "$i"
done