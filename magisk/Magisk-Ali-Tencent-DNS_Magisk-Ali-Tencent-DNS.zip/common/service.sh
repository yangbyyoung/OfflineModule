#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 119.29.29.29:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 119.29.29.29:53

ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to destination 2001:da8:202:10::36
ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to destination 2606:4700:4700::1001
ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2001:da8:202:10::36
ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2606:4700:4700::1001

ndc resolver flushif
ndc resolver flushdefaultif
if ifconfig -a | grep rmnet0; then
	ndc resolver clearnetdns rmnet0
	ndc resolver setnetdns rmnet0 "" 223.5.5.5 119.29.29.29
fi
if ifconfig -a | grep rmnet_data0; then
	ndc resolver clearnetdns rmnet_data0
	ndc resolver setnetdns rmnet_data0 "" 223.5.5.5 119.29.29.29
fi
if ifconfig -a | grep wlan0; then
	ndc resolver clearnetdns wlan0
	ndc resolver setnetdns wlan0 "" 223.5.5.5 119.29.29.29
fi
