SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
 ui_print "*******************************"
 ui_print "     	shadow3我爱你哇        "
 ui_print "二改自酷安@huber，二改作者酷安@shadow3"
 ui_print "*******************************"
}

boot_first_load(){
    update_path="/data/adb/modules_update/XagaSoundBoostTest"
    conf="/data/data/com.miui.misound/shared_prefs/mi_sound_preference.xml"
    pm disable com.miui.misound
    #pm clear com.miui.misound
    mkdir -p /data/data/com.miui.misound/shared_prefs
    cp -f $update_path/config/normal.xml $conf
    pm enable com.miui.misound
    am start com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
    sleep 2
    am force-stop com.miui.misound
    am force-stop com.android.settings
    cp -f $update_path/system/app/MiSound/MiSound.apk $update_path/system/product/app/MiSound/MiSound.apk
}

on_install() {
pm uninstall-system-updates com.miui.misound
rm -rf /data/system/package_cache/*
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'LICENSE' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'aml.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'mly' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'sepolicy.rule' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2

 boot_first_load
}

set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}
#pangu fix
mkdir -p $MODPATH/system/product/
cp -r /product/pangu/system/* $MODPATH/system/product/