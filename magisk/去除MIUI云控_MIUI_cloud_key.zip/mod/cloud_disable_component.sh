#!/system/bin/sh

function disable_component(){
local option="${1}"
test "$option" = "" && option="disable"
local list='
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
'
for i in ${list}
do
pm "$option" "${i}"  >/dev/null 2>&1
done
#云控界面
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity >/dev/null 2>&1
#Joyose智能服务
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity  >/dev/null 2>&1
#如果还锁帧的话，尝试禁用以下项
#来自酷安@果冻拌饭
#这个项会设置夜间睡眠杀后台打盹以及性能管理
#如果不需要你可以禁用
#pm disable com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService >/dev/null 2>&1
}

disable_component "disable"

