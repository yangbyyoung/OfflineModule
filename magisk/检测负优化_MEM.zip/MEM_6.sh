echo "
————————————————————🍂🍃🍂🍃
"
. $MODPATH/shell.sh
echo "
●————————⑦老旧/危险代码检测(shell)————————●
"
echo "－请你自行考虑是否要移除或者禁用模块。"
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
for i in $(selinux_1);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块可能包含了关闭selinux指令。"
echo "－当前selinux状态：$(getenforce)"
echo "－Enforcing=开启selinux(安全)，保护系统不受攻击。"
echo "－Permissive=关闭selinux(危险)。"
echo "－如果蝰蛇之类的无法开启，可以尝试使用旧的蝰蛇sepolicy.rule"
echo "－模块里边有，可以拆包放入音效模块内，重新刷入使用。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
for i in $(selinux_2);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块可能包含了关闭selinux指令。"
echo "－当前selinux状态：$(getenforce)"
echo "－Enforcing=开启selinux(安全)，保护系统不受攻击。"
echo "－Permissive=关闭selinux(危险)。"
echo "－如果蝰蛇之类的无法开启，可以尝试使用旧的蝰蛇sepolicy.rule"
echo "－模块里边有，可以拆包放入音效模块内，重新刷入使用。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
done
echo "
————————————————————🍂🍃🍂🍃
"
echo ""
echo ""