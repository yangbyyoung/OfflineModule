MODDIR=${0%/*}
#简易触发器
	function update_info(){
		diskfree=$(/bin/df /data | grep -w block | awk '{print $2,$3,$4}')
		diskfree=$(echo $diskfree | awk '{print $3}')
		sleep_scale=$(echo "scale=0; $diskfree/5000" | bc)
		if [ "$sleep_scale" -ge "86400" ] ; then
			sleep_scale=86400
		fi
		unuse_block=`cat "/sys/fs/f2fs/$userdata/unusable"`
		scale_gc=$(echo "scale=0; $diskfree*3/40" | bc)
		count_trim=`cat "$MODDIR/datafile/count_trim"`
  		count_gc=`cat "$MODDIR/datafile/count_gc"`
  		if [ `cat "$MODDIR/datafile/trim_disable"` == "Y" ] ; then
  			sed -i "s/\[.*\]/\[ 已停用TRIM，已GC $count_gc 次 \]/g" "$MODDIR/module.prop"
  		else
			sed -i "s/\[.*\]/\[ 已TRIM $count_trim 次，已GC $count_gc 次 \]/g" "$MODDIR/module.prop"
		fi
	}

echo 0 >$MODDIR/datafile/count_trim
echo 0 >$MODDIR/datafile/count_gc
userdata=`cat "$MODDIR/datafile/userdata_num"`
echo "UnLock" > $MODDIR/datafile/SleepLocker
while true ; do
	update_info
  	if [ `cat "$MODDIR/datafile/SleepLocker"` == "Lock" ] ; then
  		count=0
  		sleep_scale=114514
		until [ "$count" -ge "$sleep_scale" ] ; do
			update_info
			if [ "$unuse_block" -ge "$scale_gc" ] ; then
				break 1
  			fi
			sleep 60
			count=$(($count + 60 ))
  		done
  		echo "UnLock" > $MODDIR/datafile/SleepLocker
  	else
		level=0
		until [ "$level" -ge "12" ] ; do
			info_old=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
			total_old=$(echo $info_old | awk '{print $1+$2+$3+$4+$5+$6+$7}')
			usage_old=$(echo $info_old | awk '{print $1+$2+$3}')
			sleep 5
			info_new=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
			total_new=$(echo $info_new | awk '{print $1+$2+$3+$4+$5+$6+$7}')
			usage_new=$(echo $info_new | awk '{print $1+$2+$3}')
			busy=$(($usage_new - $usage_old))
			cputime=$(($total_new - $total_old))
			usage=$(echo "scale=0; $busy*100/$cputime" | bc)
			if [ "$usage" -le "39" ] ; then
				level=$(($level + 1 ))
			else
				if [ "$level" -ge "2" ] ; then
					level=$(($level - 2 ))
				fi
  			fi
  		done
  		if [ `cat "$MODDIR/datafile/trim_disable"` == "N" ] ; then
  			sh $MODDIR/main_1.sh
  		else
  			sh $MODDIR/main_2.sh
  		fi
  	fi
done
