#!/system/bin/sh
MODDIR=${0%/*}
Stop=$(sed '/^随机ID=/!d;s/.*=//' $MODDIR/配置.conf)
ID=$(sed '/^固定ID=/!d;s/.*=//' $MODDIR/配置.conf)

function rand(){ 
min=$1
max=$(($2-$min+1))
num=$(cat /dev/urandom | head -n 10 | cksum | awk -F ' ' '{print $1}')
echo $(($num%$max+$min))
}

if [[ $Stop == "Y" ]] ;then
echo $(rand 1100000000 2000000000) > $MODDIR/ID
elif [[ $Stop == "N" ]] ;then
echo $ID > $MODDIR/ID
fi

$MODDIR/H $(cat $MODDIR/ID)