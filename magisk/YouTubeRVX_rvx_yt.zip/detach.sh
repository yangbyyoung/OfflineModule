#!/system/bin/sh
# Detach script - Disable Play store updates for ReVanced Extended 


if ! SQLITE3=$(which sqlite3) > /dev/null 2>&1; then
    SQLITE3="${0%/*}/system/bin/sqlite3"
fi

PS=com.android.vending
DB=/data/data/$PS/databases
LDB=$DB/library.db
LADB=$DB/localappstate.db
PKG=$(grep description "${0%/*}"/module.prop | sed -n 's/.*(//;s/).*//p')
GET_LDB=$($SQLITE3 $LDB "SELECT doc_id,doc_type FROM ownership" | grep "$PKG" | head -n 1 | grep -o 25)

# Main script
if [ "$GET_LDB" != "25" ]; then
    # Disable Play store
    cmd appops set --uid $PS GET_USAGE_STATS ignore
    pm disable $PS > /dev/null 2>&1
    
    # Update database
    $SQLITE3 $LDB "UPDATE ownership SET doc_type = '25' WHERE doc_id = '$PKG'";
    $SQLITE3 $LADB "UPDATE appstate SET auto_update = '2' WHERE package_name = '$PKG'";
    
    # Remove cache
    rm -rf /data/data/$PS/cache/*
    
    # Re-enable Play store
    pm enable $PS > /dev/null 2>&1
    
fi