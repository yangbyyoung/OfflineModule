SKIPUNZIP=0
var_device="`getprop ro.product.mod_device`"
echo "当前手机型号是: $var_device "
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "只适合小米11，11Pro，小米11 Ultra，mix4，平板5，其它机型别乱刷哦，出问题自己解决！"
  ui_print "install..."
  ui_print "done..."
  