sleep 2s

#优化cpu分配
echo "0-2" > /dev/cpuset/background/cpus
echo "3-5" > /dev/cpuset/system-background/cpus
echo "0-2" > /dev/cpuset/audio-app/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
echo "1-3" > /dev/cpuset/restricted/cpus
#调节cpu激进度
echo "100" > /dev/stune/foreground/schedtune.boost
echo "100" > /dev/stune/top-app/schedtune.boost
echo "0" > /dev/stune/background/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.boost
#大小核心分配优化
echo "49" > /proc/sys/kernel/sched_downmigrate
echo "50" > /proc/sys/kernel/sched_upmigrate
echo "0" > /proc/sys/kernel/sched_boost
#io优化
echo "2" > /sys/block/mmcblk0/queue/rq_affinity

echo schedutil > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo schedutil > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

function white_list()
{
  echo -n "  + $1 "
  pgrep -o $1 | while read pid; do
  renice -n 5 -p $pid
  done
}

#surfaceflinger
white_list surfaceflinger
#系统服务
white_list system_server

#dns优化

setprop net.eth0.dns1 223.5.5.5
setprop net.eth0.dns2 223.6.6.6

setprop net.dns1 223.5.5.5
setprop net.dns2 223.6.6.6

setprop net.ppp0.dns1 223.5.5.5
setprop net.ppp0.dns2 223.6.6.6

setprop net.rmnet0.dns1 223.5.5.5
setprop net.rmnet0.dns2 223.6.6.6

setprop net.rmnet1.dns1 223.5.5.5
setprop net.rmnet1.dns2 223.6.6.6

setprop net.pdpbr1.dns1 223.5.5.5
setprop net.pdpbr1.dns2 223.6.6.6

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 223.6.6.6:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 223.6.6.6:53