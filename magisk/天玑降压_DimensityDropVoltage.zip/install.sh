#!/sbin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
unzip -qjo "$ZIPFILE" 'service.sh' -d $MODPATH
unzip -qjo "$ZIPFILE" 'drop' -d $MODPATH
unzip -qjo "$ZIPFILE" 'drop.conf' -d $MODPATH
