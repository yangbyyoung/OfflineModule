#!/system/bin/sh
#官宣粉丝交流群：别缺那颗勇敢的心 风华正茂的年纪 你应该所向披靡
#ColorOS玩机交流群：872254795
#禁止商用*转载请获取作者许可
MODDIR=${0%/*}
mount --bind $MODDIR/my_product/vendor/etc/multimedia_app_scale_list.xml /my_product/vendor/etc/multimedia_app_scale_list.xml
