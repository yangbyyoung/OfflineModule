#!/system/bin/sh
MODDIR=/data/adb/modules/Mi_DcCoexist
cp -rf /product/etc/device_features/* $MODDIR/system/product/etc/device_features/
cp -rf /vendor/etc/device_features/* $MODDIR/system/vendor/etc/device_features/
sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODDIR/system/vendor/etc/device_features/*
sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODDIR/vendor/etc/device_features/*
sed -i 's/dc_backlight_fps_incompatible\">true/dc_backlight_fps_incompatible\">false/g' $MODDIR/system/product/etc/device_features/*