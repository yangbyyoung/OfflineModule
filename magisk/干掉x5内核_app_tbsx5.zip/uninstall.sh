#!/sbin/sh
X5=`find /data/data -name '*app_tbs*' -type f -o -name '*app_tbs_64*' -type f -o -iname '*app_x5webview*' -type f -o -iname '*app_xwalk*' -type f`
X5backup=`find /data/media -name '*.tbs.*' -type f`
for i in $X5;do
rm -rf $i 2>/dev/null
done
for i in $X5backup;do
rm -rf $i 2>/dev/null
done