print_modname() {
  ui_print "                      "
  ui_print "*********************"
  ui_print "  Magisk-息屏听剧  "
  ui_print "                     "
  ui_print "   by @依心所言   "
  ui_print "                     "
  ui_print "*********************"
  ui_print "                      "
}
print_modname
SKIPUNZIP=1
ui_print "- 正在释放文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
ui_print "- 正在设置权限"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/scc 2000 2000 0755 u:object_r:system_file:s0
ui_print "- 完成权限设置"