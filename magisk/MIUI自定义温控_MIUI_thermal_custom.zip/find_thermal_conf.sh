#!/system/bin/sh

mkdir -p "$MODPATH/system/vendor/etc" "${MODPATH}/自定义温控"

find $(magisk --path)/.magisk/mirror/vendor/etc -maxdepth 1 -iname "*thermal*.conf" -type f 2>/dev/null | while read file ;do
	cp -rf "${file}" "$MODPATH/system/vendor/etc/${file##*/}"
	echo "找到温控配置文件 [ ${file##*/} ]"
done


local count=`find $(magisk --path)/.magisk/mirror/vendor/etc -maxdepth 1 -iname "*thermal*.conf" -type f 2>/dev/null | wc -l `
test "${count}" = "0" && echo "温控文件未找到！自己想办法找一个或者自己写吧😂？"

#解密MIUI温控
function decrypt_mi_thermal(){
local target="${1}"
local output="${2}"
$MODPATH/mod/miui-thermal -i="${target}" -o="${output}" -d='true' >/dev/null
}

if test "$(show_value '启用自定义温控替换')" = "否" ;then
	decrypt_mi_thermal "$MODPATH/system/vendor/etc" "${MODPATH}/自定义温控"
else
	local count2=`find ${MODPATH}/自定义温控 -iname "*thermal*.conf" | wc -l `
	if test "$count2" != "0" ;then
		ecrypt_mi_thermal "${MODPATH}/自定义温控" "$MODPATH/system/vendor/etc"
		ecrypt_mi_thermal "${MODPATH}/自定义温控" "/data/vendor/thermal/config"
	else
		decrypt_mi_thermal "$MODPATH/system/vendor/etc" "${MODPATH}/自定义温控"
	fi
fi
