MODDIR=${0%/*}

bootLog="[$(date "+%Y-%m-%d %H:%M:%S")]"

grep_prop() {
    local REGEX="s/^$1=//p"
    shift
    local FILES=$@
    [ -z "$FILES" ] && FILES='/system/build.prop'
    cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

mountV2Frozen() {
    if [[ -d /sys/fs/cgroup/frozen ]] && [[ -d /sys/fs/cgroup/unfrozen ]]; then
        bootLog="${bootLog} -> 原生支持FreezerV2(frozen)"
        return
    fi

    if [ ! -d /sys/fs/cgroup/frozen ]; then
        mkdir -p /sys/fs/cgroup/frozen
        bootLog="${bootLog} -> 创建v2Frozen"
    fi
    if [ ! -d /sys/fs/cgroup/unfrozen ]; then
        mkdir -p /sys/fs/cgroup/unfrozen
        bootLog="${bootLog} -> 创建v2Unfrozen"
    fi

    sleep 1

    if [[ -f /sys/fs/cgroup/frozen/cgroup.freeze ]] && [[ -f /sys/fs/cgroup/unfrozen/cgroup.freeze ]]; then
        echo 1 >/sys/fs/cgroup/frozen/cgroup.freeze
        echo 0 >/sys/fs/cgroup/unfrozen/cgroup.freeze
        bootLog="${bootLog} -> 已挂载 FreezerV2(frozen)"
    else
        bootLog="${bootLog} -> 依旧不支持 FreezerV2(frozen)"
    fi
}

mountFreezerV2() {
    for modDir in cgroupfix cgroupv1 cgroup_freezer_mount; do
        fullDir="/data/adb/modules/$modDir"
        if [[ -d $fullDir ]] && [[ ! -f $fullDir/disable ]]; then
            bootLog="${bootLog} -> 该模块[$modDir][$(grep_prop name $fullDir/module.prop)]正在挂载，本模块将退出竞争"
            return
        fi
    done

    if [ -f /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        bootLog="${bootLog} -> 原生支持FreezerV2(uid)"
        mountV2Frozen
        return
    fi

    if [ -f /sys/fs/cgroup/frozen/cgroup.freeze ]; then
        bootLog="${bootLog} -> 原生支持FreezerV2(frozen)"
        return
    fi

    for path in "/sys/fs/cgroup/freezer" "/sys/fs/cgroup" "/dev/freezer" "/dev/op_cgroup/freezer" "/dev/op_cgroup/freezer" "/dev/op_cgroup"; do
        if [ -d $path ]; then
            umount $path
        fi
    done

    umount /sys/fs/cgroup/*
    sleep 1

    bootLog= "${bootLog} -> 正在挂载cgroup2"
    mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup
    sleep 1

    if [ -f /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        bootLog="${bootLog} -> 已挂载 FreezerV2(uid)"
    else
        bootLog="${bootLog} -> 不支持 FreezerV2(uid)"
    fi

    mountV2Frozen
}

androidVersion=$(getprop ro.build.version.release)
if [[ $androidVersion -ge 11 ]] && [[ $androidVersion -le 13 ]]; then
    mountFreezerV2
else
    bootLog="${bootLog} 仅支持[Android 11-13]挂载FreezerV2, 当前[Android $androidVersion]"
fi

cat >$MODDIR/module.prop <<EOF
id=jark_mount_freezerv2
name=挂载FreezerV2
version=v1.1
versionCode=11
author=JARK006
description=$bootLog
EOF
