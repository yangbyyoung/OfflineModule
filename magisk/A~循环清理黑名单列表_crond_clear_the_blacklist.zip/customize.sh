SKIPUNZIP=0

MyPrint() {
	echo "$@"
	sleep 0.04
}

MyPrint " "
MyPrint "╔════════════════════════════════════"
MyPrint "║   - [&]请先阅读 避免一些不必要的问题"
MyPrint "╠════════════════════════════════════"
MyPrint "║"
MyPrint "║   - 1.模块刷入重启后，只在用户解锁设备才开始生效。"
MyPrint "║   - 2.使用crond定时命令，不会浪费或占用系统资源。"
MyPrint "║   - 3.模块自定义路径: /sdcard/Android/clear_the_blacklist/"
MyPrint "║ "
MyPrint "║   - ps: 只要你手机开机，只要你使用任何软件，设备本身就已经开始进"
MyPrint "║ "
MyPrint "╚════════════════════════════════════"

black_and_white_list_path="/sdcard/Android/clear_the_blacklist"
cron_set_dir="${black_and_white_list_path}/定时任务"

Black_List="${black_and_white_list_path}/黑名单.prop"
White_List="${black_and_white_list_path}/白名单.prop"
cron_set_file="${cron_set_dir}/定时设置.ini"
Run_cron_sh="${cron_set_dir}/Run_cron.sh"

magisk_util_functions="/data/adb/magisk/util_functions.sh"
grep -q 'lite_modules' "${magisk_util_functions}"
if [[ -f "/data/adb/ksud" ]]; then
	Module_Path="/data/adb/modules"
	S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')
	if [[ $S == "v0.3" ]]; then
		Module_Path="/data/adb/ksu/modules"
	fi
fi
if [[ -f "/data/adb/magisk/magiskboot" ]]; then
	Module_Path="/data/adb/modules"
elif [[ -d "/data/adb/lite_modules" ]]; then
	Module_Path="/data/adb/lite_modules"
fi

mod_path="${Module_Path}/crond_clear_the_blacklist"
script_dir="${mod_path}/script"

crond_pid="$(ps -ef | grep -v 'grep' | grep 'crond' | grep 'crond_clear_the_blacklist' | awk '{print $1}')"
if [[ -n ${crond_pid} ]]; then
	for kill_pid in ${crond_pid}; do
		kill -9 ${kill_pid} && MyPrint "- 杀死crond进程: ${kill_pid}"
	done
fi
tmp_date="$MODPATH/script/tmp/DATE/$(date '+%Y%m%d')"
mkdir -p $tmp_date
echo "0" >$tmp_date/file
echo "0" >$tmp_date/dir
rm -rf ${black_and_white_list_path} && MyPrint "- 删除${black_and_white_list_path}文件夹"
MyPrint " "

[[ -d ${cron_set_dir} ]] || mkdir -p ${cron_set_dir}
[[ -f ${Black_List} ]] || cp -r ${MODPATH}/AndroidFile/黑名单.prop ${black_and_white_list_path}/
[[ -f ${White_List} ]] || cp -r ${MODPATH}/AndroidFile/白名单.prop ${black_and_white_list_path}/
[[ -f ${cron_set_file} ]] || cp -r ${MODPATH}/AndroidFile/定时任务/定时设置.ini ${cron_set_dir}/
[[ -f ${Run_cron_sh} ]] && rm -rf ${Run_cron_sh}
cp -r ${MODPATH}/AndroidFile/定时任务/Run_cron.sh ${cron_set_dir}/
rm -rf ${MODPATH}/AndroidFile/
echo "test" >${cron_set_dir}/test.bak
