#!/bin/env sh

#>> 交流群组：308265111

Yixin=${0%/*}
chmod -R 755 "$Yixin"
{
	#Use system interpreter
	/system/bin/sh "$Yixin/activity.sh" &
	#Leave the current process
	exit 0
}
