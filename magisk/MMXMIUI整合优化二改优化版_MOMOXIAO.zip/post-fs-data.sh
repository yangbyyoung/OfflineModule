#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 此脚本将在post-fs-data模式下执行

#禁止mi-rcs写入日志（来自酷安@风雪如花剑如霜）
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#禁用lsposed日志
rm -rf /data/adb/lspd/log
touch /data/adb/lspd/log
chmod 000 /data/adb/lspd/log

#关闭HW叠加层
while :
do
if [ $sf -eq 1 ]
then
service call SurfaceFlinger 1008 i32 1
break
else
sf=$(service list | grep -c "SurfaceFlinger")
sleep 2
fi
done

#开启maliGPU游戏模式
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
echo 1 >/sys/module/ged/parameters/gx_game_mode

#修复ROOT后F2FS性能下降的问题(如不生效请手动将sdc59改成你自己手机机型下的目录)
while [[ "$(cat /sys/fs/f2fs/sdc59/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/sdc59/cp_interval
done

while [[ "$(cat /sys/fs/f2fs/sdc59/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/sdc59/gc_urgent_sleep_time
done

while [[ "$(cat /sys/fs/f2fs/sdc59/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/sdc59/iostat_enable
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
done

#删除无用垃圾(来自酷安@风雪如花剑如霜)
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /storage/emulated/0/.com.android.providers.downloads
rm -rf /storage/emulated/0/.com.android.providers.downloads.ui
rm -rf /data/user/0/com.douban.frodo/app_rexxar-douban
rm -rf /data/user/0/com.douban.frodo/cache
rm -rf /data/vendor/wlan_logs
rm -rf /data/user/0/com.picsart.studio/files/bitmap_cache/editor/view
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#内核优化
echo “8″ > /proc/sys/vm/page-cluster
echo “64000″ > /proc/sys/kernel/msgmni
echo “64000″ > /proc/sys/kernel/msgmax
echo “10″ > /proc/sys/fs/lease-break-time
echo “500,512000,64,2048″ > /proc/sys/kernel/sem

#来自酷安@风雪如花剑如霜
if
rm -rf /cache/magisk.log
touch   /cache/magisk.log
chmod 000  /cache/magisk.log
/sbin/.magisk/busybox/chattr +i  /cache/magisk.log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 


then
echo "清理成功"
fi

#开启联发科GPU无限缓存
echo Y > /sys/kernel/debug/mali0/ctx/defaults/infinite_cache

#UFS（来自酷安@风雪如花剑如霜）
#禁用I/O统计
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sdb/queue/iostats
echo 0 > /sys/block/sdc/queue/iostats
echo 0 > /sys/block/sdd/queue/iostats
echo 0 > /sys/block/sde/queue/iostats
echo 0 > /sys/block/sdf/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/sda/queue/nomerges
echo 0 > /sys/block/sdb/queue/nomerges
echo 0 > /sys/block/sdc/queue/nomerges
echo 0 > /sys/block/sdd/queue/nomerges
echo 0 > /sys/block/sde/queue/nomerges
echo 0 > /sys/block/sdf/queue/nomerges

#EMMC
#禁用I/O 统计(EMMC)
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/mmcblk0/queue/nomerges
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats


#禁用I/O调试，UFS 和EMMC皆可用
echo 0 > /sys/block/loop0/queue/iostats
echo 0 > /sys/block/loop1/queue/iostats
echo 0 > /sys/block/loop2/queue/iostats
echo 0 > /sys/block/loop3/queue/iostats
echo 0 > /sys/block/loop4/queue/iostats
echo 0 > /sys/block/loop5/queu

#禁用binder活页夹日志
echo 0 > /sys/module/binder/parameters/debug_mask

# 禁用用户空间向dmesg写入日志
echo off > /proc/sys/kernel/printk_devkmsg

# 禁用调度统计
echo 0 > /proc/sys/kernel/sched_schedstats

#更改磁盘I/O预读大小
echo 128 > /sys/block/sda/queue/read_ahead_kb
echo 128 > /sys/block/sdb/queue/read_ahead_kb
echo 128 > /sys/block/sdc/queue/read_ahead_kb
echo 128 > /sys/block/sde/queue/read_ahead_kb
#eMMC设备使用命令:
echo 128 > /sys/block/mmcblk0/queue/read_ahead_kb

#调整虚拟内存更新/刷新间隔
echo 20 > /proc/sys/vm/stat_interval

#调整page页面集群大小
echo 0 > /proc/sys/vm/page-cluster

# 调整脏页写回策略时间
echo 3000 > /proc/sys/vm/dirty_expire_centisecs

# ZRAM分区参数调整
echo 128 > /sys/block/zram0/queue/read_ahead_kb
echo 36 > /sys/block/zram0/queue/nr_requests

# 禁用内核调试
echo "0" > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo "N" > /sys/kernel/debug/debug_enabled

#开启F2FS加速回收
# 启用f2fs_gc_booster
echo "1" > /sys/fs/f2fs/sdc59/gc_booster

#存储io激进程度
echo "2" > /sys/block/mmcblk0/queue/rq_affinity
echo "2" > /sys/block/sda/queue/rq_affinity
echo "2" > /sys/block/sdb/queue/rq_affinity
echo "2" > /sys/block/sdc/queue/rq_affinity

#提升IO速度与网络速度
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo noop > /sys/block/sda/queue/scheduler
echo noop > /sys/block/sdc/queue/scheduler
echo noop > /sys/block/sdb/queue/scheduler
echo noop > /sys/block/mmcblk0/queue/scheduler

#安卓tcp优化（调整initcwnd和initrwnd，减少数据包的传递次数，提高传输速度）
ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 40;
done

#进程可打开文件数优化
echo 2390251 > /proc/sys/fs/file-max

#主动整理内存碎片，提升系统性能
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

alias free=$(magisk --path)/.magisk/busybox/free
test -e /sbin/.magisk/busybox/ && alias free=/sbin/.magisk/busybox/free

function M(){
all=`free -m|grep "Mem"|awk '{print $2}'`
use=`free -m|grep "Mem"|awk '{print $3}'`
echo $(($use*100/$all))
}

if [ $(M) -ge 60 ];then
sync 
echo 3 > /proc/sys/vm/drop_caches  
echo 1 > /proc/sys/vm/compact_memory
sync
fi

#关闭LMK调试提升性能
echo 0 > /sys/module/lowmemorykiller/parameters/debug_level

#ZRAM线程增加到8线程，提升压缩效率和流畅度
echo 8 > /sys/block/zram0/max_comp_streams