SKIPMOUNT=false PROPFILE=true

print_modname() {
 ui_print "#######################"
 ui_print "- 模块: $MODNAME"
 ui_print "- 模块ID: $MODID"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 介绍: $MODdescription"
 ui_print "#######################"
 ui_print " "
}

on_install() {
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
 set_perm_recursive  $MODPATH  0  0  0755  0644
}