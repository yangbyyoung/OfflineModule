resetprop  ro.boot.vbmeta.device_state locked
resetprop  ro.secureboot.lockstate locked
resetprop ro.boot.flash.locked 1
