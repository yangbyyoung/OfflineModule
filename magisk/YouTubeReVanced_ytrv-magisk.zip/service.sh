#!/system/bin/sh
# shellcheck disable=SC2086
MODDIR=${0%/*}
MODULES=${MODDIR%/*}
RVPATH=${MODULES%/*}/rvhc/com.google.android.youtube_rv.apk

until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 1; done
while
	BASEPATH=$(pm path com.google.android.youtube)
	svcl=$?
	[ $svcl = 20 ]
do sleep 1; done
sleep 5

err() {
	[ ! -f $MODDIR/err ] && cp $MODDIR/module.prop $MODDIR/err
	sed -i "s/^des.*/description=⚠️ Module is inactive: '${1}'/g" $MODDIR/module.prop
}

if [ $svcl = 0 ]; then
	BASEPATH=${BASEPATH##*:}
	BASEPATH=${BASEPATH%/*}
	if [ -d $BASEPATH/lib ]; then
		VERSION=$(dumpsys package com.google.android.youtube | grep -m1 versionName)
		VERSION="${VERSION#*=}"
		if [ "$VERSION" = 18.05.40 ]; then
			grep com.google.android.youtube /proc/mounts | while read -r line; do
				mp=${line#* }
				mp=${mp%% *}
				umount -l ${mp%%\\*}
			done
			if chcon u:object_r:apk_data_file:s0 $RVPATH; then
				mount -o bind $RVPATH $BASEPATH/base.apk
				am force-stop com.google.android.youtube
				[ -f $MODDIR/err ] && mv -f $MODDIR/err $MODDIR/module.prop
			else
				err "mount failed"
			fi
		else
			err "version mismatch (installed:${VERSION}, module:18.05.40)"
		fi
	else
		err "invalid installation"
	fi
else
	err "app not installed"
fi
