mkdir -p /storage/emulated/0/Android/data/com.sunshine.freeform/files/Documents
cp -rf $MODPATH/Documents/freeform-server.jar /storage/emulated/0/Android/data/com.sunshine.freeform/files/Documents