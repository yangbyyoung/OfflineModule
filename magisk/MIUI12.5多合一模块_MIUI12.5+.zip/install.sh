# Magisk多合一模块
# 脚本底包: 酷安@cjybyjk
# 脚本编写: 酷安@董小豪
# 版本: v2.0
# 开: true; 关: false

# 功能来源
COOLAPK="- 来自酷安"

# 调试模式标记
DEBUG_FLAG=false

# 自动挂载
SKIPMOUNT=false
# 对应/common/system.prop
PROPFILE=false
# 对应/common/post-fs-data.sh
POSTFSDATA=false
# 对应/common/service.sh
LATESTARTSERVICE=false

# 网络更新脚本，默认开
update_switch=false
# 音量选择网络更新脚本，默认开
update_remind=true

# 获取系统信息
var_sdk="`grep_prop ro.*version.sdk`"
var_name="`grep_prop ro.*version.name`"
var_brand="`grep_prop ro.product.*brand`"
var_model="`grep_prop ro.product.*model`"
var_device="`grep_prop ro.product.*device`"
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.*version.incremental`"
var_manufacturer="`grep_prop ro.product.*manufacturer`"

if [ -f "$MODUIES/$MODID/module.prop" ]; then
[ -f $MODUIES/$MODID/module.prop.bak ] || cp -rf $MODUIES/$MODID/module.prop $MODUIES/$MODID/module.prop.bak
version_1="(已安装版本：$VERSION_1)"
fi

print_modname() {
# 在这里设置你想要在模块安装过程中显示的信息
	ui_print "----------------------------"
	ui_print "  模块名称：$MODNAME"
	ui_print "  模块作者：$AUTHOR"
	ui_print "  模块版本：$VERSION $version_1"
	ui_print "----------------------------"
	ui_print "  设备型号：$var_model ($var_device)"
	ui_print "  系统版本：$var_name $var_version"
	ui_print "  设备版本：$var_release (SDK$var_sdk)"
	ui_print "----------------------------"
}

Dolby0="support_dolby\">false"
Dolby1="support_dolby\">true"
HiFi0="support_hifi\">false"
HiFi1="support_hifi\">true"
AiJian0="support_ai_task\">false"
AiJian1="support_ai_task\">true"
Assist0="support_sound_assist\">false"
Assist1="support_sound_assist\">true"
Paper0="support_paper_eyecare\">false"
paper1="support_paper_eyecare\">true"
smart0="support_smart_eyecare\">false"
smart1="support_smart_eyecare\">true"
Aod0="support_aod\">false"
Aod1="support_aod\">true"
keycode0="aod_support_keycode_goto_dismiss\">false"
keycode1="aod_support_keycode_goto_dismiss\">true"
touchfeature0="support_touchfeature_gamemode\">false"
touchfeature1="support_touchfeature_gamemode\">true"
displayfeature0="support_displayfeature_gamemode\">false"
displayfeature1="support_displayfeature_gamemode\">true"
gamemi0="support_game_mi_time\">false"
gamemi1="support_game_mi_time\">true"
ledcolor0="support_led_color\">false"
ledcolor1="support_led_color\">true"
ledlight0="support_led_light\">false"
ledlight1="support_led_light\">true"
videotool0="support_video_tool_box\">false"
videotool1="support_video_tool_box\">true"
Fps0="defaultFps\">60<"
Fps1="defaultFps\">90<"
sfxspkF="ro.vendor.audio.sfx.spk.stereo=false"
sfxspkT="ro.vendor.audio.sfx.spk.stereo=true"
spkstereoF="ro.vendor.audio.spk.stereo=false"
spkstereoT="ro.vendor.audio.spk.stereo=true"
earadjF="ro.vendor.audio.sfx.earadj=false"
earadjT="ro.vendor.audio.sfx.earadj=true"
clouds0="persist.sys.ai_preload_cloud=0"
clouds1="persist.sys.ai_preload_cloud=1"
screenF="18x9_ratio_screen\">false"
screenT="18x9_ratio_screen\">true"
# 检测手机品牌

# 设置统一权限
set_permissions() {
	set_perm_recursive $MODPATH 0 0 0755 0755
}

initmods() {
	mod_name=""
	mod_install_info=""
	mod_select_yes_text=""
	mod_select_yes_desc=""
	mod_select_no_text=""
	mod_select_no_desc=""
	mod_require_device=""
	mod_require_version=""
	INSTALLED_FUNC="`trim $INSTALLED_FUNC`"
	MOD_SKIP_INSTALL=false
	framework=false
	cd $TMPDIR/mods
}

keytest() {
	ui_print "----------------------------"
	ui_print "- 音量键测试 -"
	ui_print "   请按下 [音量➕] 键："
	ui_print "   无反应或传统模式无法正确安装时，请触摸一下屏幕后继续。"
	(/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
	return 0
}

chooseport() {
#note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
	while (true); do
		/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
		if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
			break
		fi
	done
	if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
		return 0
	else
		return 1
	fi
}

chooseportold() {
# Calling it first time detects previous input. Calling it second time will do what we want
	$KEYCHECK
	$KEYCHECK
	SEL=$?
	$DEBUG_FLAG && ui_print "  调试：选择portold：$1,$SEL"
	if [ "$1" == "UP" ]; then
		UP=$SEL
	elif [ "$1" == "DOWN" ]; then
		DOWN=$SEL
	elif [ $SEL -eq $UP ]; then
		return 0
	elif [ $SEL -eq $DOWN ]; then
		return 1
	else
		abort "   未检测到音量键!"
	fi
}

on_install() {

# 解压文件
	unzip -o "$ZIPFILE" 'mods/*' -d "$TMPDIR/" >&2
# 公用函数
	source $TMPDIR/util_funcs.sh

# Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
	KEYCHECK=$TMPDIR/keycheck
	chmod 755 $KEYCHECK
	
#zip
  MYZIP=$TMPDIR/zip
  chmod 755 $MYZIP
  MYTMPDIR=$TMPDIR/tmp

# 测试音量键
	if keytest; then
		VOLKEY_FUNC=chooseport
		ui_print "----------------------------"
	else
		VOLKEY_FUNC=chooseportold
		ui_print "----------------------------"
		ui_print "- 检测到遗留设备！使用旧的 keycheck 方案"
		ui_print "- 进行音量键录入 -"
		ui_print "   录入：请按下 [音量➕] 键："
		$VOLKEY_FUNC "UP"
		ui_print "   已录入 [音量➕] 键。"
		ui_print "   录入：请按下 [音量➖] 键："
		$VOLKEY_FUNC "DOWN"
		ui_print "   已录入 [音量➖] 键。"
	ui_print "----------------------------"
	fi

# 生成工作目录
ui_print "正在生成工作目录"
rm -rf /storage/emulated/0/Android/MIUI12.5+/
sleep 1s
unzip -o $ZIPFILE 'MIUI12.5+/*' -d /storage/emulated/0/Android
#安装p7zip命令，使用方法自行百度7za命令，压缩apk格式必须加-mx0后缀表示无压缩
#	ui_print "----------------------------"
#	ui_print "   正在安装文件..."
#		sleep 1
#		cp -rf $TMPDIR/7z /sbin/.magisk/busybox/ || 
#		cp -rf $TMPDIR/7za /sbin/.magisk/busybox/ || 
#		cp -rf $TMPDIR/7zr /sbin/.magisk/busybox/ || 
#		cp -rf $TMPDIR/7z.so /system/lib64/ || 
#		cp -rf $TMPDIR/zip /sbin/.magisk/busybox/ || 
#		chmod 777 /sbin/.magisk/busybox/*
#		chmod 777 /system/lib64/7z.so
#	if [ -e /system/lib64/7z.so ] && [ -e /sbin/.magisk/busybox/7z ] && [ -e /sbin/.magisk/busybox/7za ] && [ -e /sbin/.magisk/busybox/7zr ]; then
#	ui_print "   [✔]安装文件成功"
#		var_p7zip=true
#	else
#	ui_print "   "
#		var_p7zip=false
#	fi

# 替换文件夹列表
	REPLACE="
"

# 已安装模块
	MODS_SELECTED_YES=""
	MODS_SELECTED_NO=""

# 加载可用模块
	initmods
	for MOD in $(ls)
	do
		if [ -f $MOD/mod_info.sh ]; then
			MOD_FILES_DIR="$TMPDIR/mods/$MOD/files"
			source $MOD/mod_info.sh
			$DEBUG_FLAG && ui_print "----------------------------"
			$DEBUG_FLAG && ui_print "  调试：加载 [$MOD]"
			$DEBUG_FLAG && ui_print "  调试：[$MOD]的名称：[$mod_name]"
			$DEBUG_FLAG && ui_print "  调试：[$mod_name]的设备要求：$mod_require_device"
			$DEBUG_FLAG && ui_print "  调试：[$mod_name]的版本要求：$mod_require_version"
			if [ -z $mod_require_device ]; then
				mod_require_device=$var_device
				$DEBUG_FLAG && ui_print "  调试：替换[$mod_name]的设备要求：$mod_require_device"
			fi
			if [ -z $mod_require_version ]; then
				mod_require_version=$var_version
				$DEBUG_FLAG && ui_print "  调试：替换[$mod_name]的版本要求：$mod_require_version"
			fi
			if $MOD_SKIP_INSTALL ; then
				ui_print "  跳过$mod_name安装"
				initmods
				continue
			fi
			if [ "`echo $var_device | egrep $mod_require_device`" = "" ]; then
				echo -e "\n----------------------------\n"
				ui_print "   $mod_name不支持你的设备。"
				ui_print "   $mod_name支持你的设备是[$mod_require_device]。"
			elif [ "`echo $var_name | egrep $mod_require_version`" = "" ]; then
				echo -e "\n----------------------------\n"
				ui_print "   $mod_name不支持你的系统版本。"
				ui_print "   $mod_name支持你的系统版本是[$mod_require_version]。"
			elif [ "`echo $var_release | egrep $mod_require_release`" = "" ]; then
				echo -e "\n----------------------------\n"
				ui_print "   $mod_name不支持你的设备版本。"
				ui_print "   $mod_name支持你的设备版本是[$mod_require_release]。"
			else
				echo -e "\n\n----------------------------\n\n"
			echo -e "  ☆★☆★☆$mod_name☆★☆★☆"
            ui_print "  ◎ 功能来源: $ORIGIN"
            echo -e "  ♢ 功能介绍: $mod_install_desc\n"
			ui_print "  - 请按音量键选择$mod_install_info -"
			ui_print "   [音量➕]：$mod_select_yes_text"
			ui_print "   [音量➖]：$mod_select_no_text"
				if $VOLKEY_FUNC; then
					ui_print "   已选择安装。"
					mod_install_yes
					run_result=$?
					if [ $run_result -eq 0 ]; then
						MODS_SELECTED_YES="$MODS_SELECTED_YES ($MOD)"
						INSTALLED_FUNC="$mod_select_yes_desc $INSTALLED_FUNC"
					else
						ui_print "   失败。错误：$run_result"
					fi
				else
					ui_print "   已选择不安装。"
					mod_install_no
					run_result=$?
					if [ $run_result -eq 0 ]; then
						MODS_SELECTED_NO="$MODS_SELECTED_NO ($MOD)"
						INSTALLED_FUNC="$mod_select_no_desc $INSTALLED_FUNC"
					else
						ui_print "   失败。错误：$run_result"
					fi
				fi
				run_time
			fi
		else
			$DEBUG_FLAG && ui_print "  调试：找不到 $MOD 的mod_info.sh"
		fi
		initmods
	done

if [ $THEME == true ]; then
$DEBUG_FLAG && ui_print "调试：</MIUI_Theme_Values>..."
for i in com.android.systemui com.android.settings com.miui.player com.miui.securitycenter com.miui.weather2 framework-res; do
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/00_theme/$i/theme_fallback.xml
	echo "</MIUI_Theme_Values>" >> $TMPDIR/mods/00_theme/$i/theme_values.xml
	cd $TMPDIR/mods/00_theme/$i
	[ `awk 'END{print NR}' theme_fallback.xml` -le 3 ] && rm -f theme_fallback.xml
	[ `awk 'END{print NR}' theme_values.xml` -le 3 ] && rm -f theme_values.xml
	if [ -f theme_fallback.xml ] || [ -f theme_values.xml ]; then
		$DEBUG_FLAG && ui_print "调试：zip_theme_files：*.xml..."
		zip -r ${MODPATH}/system/media/theme/default/$i ./* >/dev/null
	fi
done
	cp -rf ${MODPATH}/system/media/theme/default/framework-res.zip $TMPDIR/framework-res
	cp -rf $INSTALLER/framework-res ${MODPATH}/system/media/theme/default/
	rm -rf ${MODPATH}/system/media/theme/default/framework-res.zip
fi

	if [ -z "$INSTALLED_FUNC" ]; then
		ui_print "未安装任何功能 即将退出安装..."
		rm -rf $TMPDIR
		exit
	fi

	echo "description=安装时间：[`date "+%F %T"`]	安装的功能: $INSTALLED_FUNC" >> $TMPDIR/module.prop
	[ -d "/storage/emulated/0/Download/"$MODID"_update" ] && rm -rf /storage/emulated/0/Download/"$MODID"_update
	sleep 1s
	rm -rf /data/system/package_cache/*
ui_print "  缓存清理完毕"
if [ -d /data/data/com.coolapk.market ]; then
   ui_print " "
   ui_print "  ★☆★☆★检测到你安装了酷安★☆★☆★"
   ui_print "        >>>是否跳转到作者主页<<<"
   ui_print "           [音量➕] = 好呀！"
   ui_print "           [音量➖] = 不要！"
   if chooseport; then
     ui_print "          正在跳转..."
     sleep 1s
     am start -d 'coolmarket://u/3705066' >/dev/null 2>&1
   fi
fi
}
