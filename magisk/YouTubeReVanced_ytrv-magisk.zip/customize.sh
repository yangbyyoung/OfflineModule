# shellcheck disable=SC2148,SC2086
ui_print ""

if [ $ARCH = "arm" ]; then
	#arm
	ARCH_LIB=armeabi-v7a
	alias cmpr='$MODPATH/bin/arm/cmpr'
elif [ $ARCH = "arm64" ]; then
	#arm64
	ARCH_LIB=arm64-v8a
	alias cmpr='$MODPATH/bin/arm64/cmpr'
else
	abort "ERROR: unsupported arch: ${ARCH}"
fi
set_perm_recursive $MODPATH/bin 0 0 0755 0777

nsenter -t1 -m -- grep com.google.android.youtube /proc/mounts | while read -r line; do
	ui_print "* Un-mount"
	mp=${line#* }
	mp=${mp%% *}
	nsenter -t1 -m -- umount -l "${mp%%\\*}"
done
am force-stop com.google.android.youtube

INS=true
if BASEPATH=$(pm path com.google.android.youtube); then
	BASEPATH=${BASEPATH##*:}
	BASEPATH=${BASEPATH%/*}
	if [ ${BASEPATH:1:6} = system ]; then
		ui_print "* com.google.android.youtube is a system app"
	elif [ ! -d ${BASEPATH}/lib ]; then
		ui_print "* Invalid installation found. Uninstalling..."
		pm uninstall -k --user 0 com.google.android.youtube
	elif [ ! -f $MODPATH/com.google.android.youtube.apk ]; then
		ui_print "* Stock com.google.android.youtube APK was not found"
		VERSION=$(dumpsys package com.google.android.youtube | grep -m1 versionName)
		VERSION="${VERSION#*=}"
		if [ "$VERSION" = 18.19.35 ] || [ -z "$VERSION" ]; then
			ui_print "* Skipping stock installation"
			INS=false
		else
			abort "ERROR: Version mismatch
			installed: $VERSION
			module:    18.19.35
			"
		fi
	elif cmpr $BASEPATH/base.apk $MODPATH/com.google.android.youtube.apk; then
		ui_print "* com.google.android.youtube is up-to-date"
		INS=false
	fi
fi
if [ $INS = true ]; then
	if [ ! -f $MODPATH/com.google.android.youtube.apk ]; then
		abort "ERROR: Stock com.google.android.youtube apk was not found"
	fi
	ui_print "* Updating com.google.android.youtube to 18.19.35"
	settings put global verifier_verify_adb_installs 0
	SZ=$(stat -c "%s" $MODPATH/com.google.android.youtube.apk)
	if ! SES=$(pm install-create --user 0 -i com.android.vending -r -d -S "$SZ" 2>&1); then
		ui_print "ERROR: install-create failed"
		abort "$SES"
	fi
	SES=${SES#*[}
	SES=${SES%]*}
	set_perm "$MODPATH/com.google.android.youtube.apk" 1000 1000 644 u:object_r:apk_data_file:s0
	if ! op=$(pm install-write -S "$SZ" "$SES" "com.google.android.youtube.apk" "$MODPATH/com.google.android.youtube.apk" 2>&1); then
		ui_print "ERROR: install-write failed"
		abort "$op"
	fi
	if ! op=$(pm install-commit "$SES" 2>&1); then
		ui_print "ERROR: install-commit failed"
		abort "$op"
	fi
	settings put global verifier_verify_adb_installs 1
	if BASEPATH=$(pm path com.google.android.youtube); then
		BASEPATH=${BASEPATH##*:}
		BASEPATH=${BASEPATH%/*}
	else
		abort "ERROR: install com.google.android.youtube manually and reflash the module"
	fi
fi
BASEPATHLIB=${BASEPATH}/lib/${ARCH}
if [ -z "$(ls -A1 ${BASEPATHLIB})" ]; then
	ui_print "* Extracting native libs"
	mkdir -p $BASEPATHLIB
	if ! op=$(unzip -j $MODPATH/base.apk lib/${ARCH_LIB}/* -d ${BASEPATHLIB} 2>&1); then
		ui_print "ERROR: extracting native libs failed"
		abort "$op"
	fi
	set_perm_recursive ${BASEPATH}/lib 1000 1000 755 755 u:object_r:apk_data_file:s0
fi
ui_print "* Setting Permissions"
set_perm $MODPATH/base.apk 1000 1000 644 u:object_r:apk_data_file:s0

ui_print "* Mounting com.google.android.youtube"
mkdir -p $NVBASE/rvhc
RVPATH=$NVBASE/rvhc/com.google.android.youtube_rv.apk
mv -f $MODPATH/base.apk $RVPATH

if ! op=$(nsenter -t1 -m -- mount -o bind $RVPATH $BASEPATH/base.apk 2>&1); then
	ui_print "ERROR: Mount failed!"
	ui_print "$op"
fi
am force-stop com.google.android.youtube
ui_print "* Optimizing com.google.android.youtube"
nohup cmd package compile --reset com.google.android.youtube >/dev/null 2>&1 &

ui_print "* Cleanup"
rm -rf $MODPATH/bin $MODPATH/com.google.android.youtube.apk

for s in "uninstall.sh" "service.sh"; do
	sed -i "2 i\NVBASE=${NVBASE}" $MODPATH/$s
done

ui_print "* Done"
ui_print "  by j-hc (github.com/j-hc)"
ui_print " "
