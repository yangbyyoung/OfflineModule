#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

dpi=$(getprop persist.d_origin_dpi)

if [ "$dpi" == "" ]; then

size=$(wm size | head -1 | cut -f2 -d ":" | cut -f1 -d "x")
if [ "$size" == 1440 ]; then
  echo "2K"
  dpi=560
elif [ "$size" == 1200 ]; then
  echo "1200P"
  dpi=440
elif [ "$size" == 1080 ]; then
  echo "1080P"
  dpi=440
else
  echo "720P"
  dpi=320
fi

fi


resetprop ro.sf.lcd_density $dpi
if [[ $(getprop ro.build.version.sdk) -gt 30 ]]; then
  resetprop persist.miui.density_v2 $dpi
fi
resetprop vendor.display.lcd_density $dpi
wm density $dpi
sleep 10
wm density $dpi
sleep 20
wm density $dpi
