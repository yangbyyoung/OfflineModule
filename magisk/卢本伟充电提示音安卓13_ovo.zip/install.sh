SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
print_modname() {
 
 
 ui_print "   
 作者 酷安@肸垚_
 "
 
}
on_install() {

 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/charging.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/disconnect.ogg' -d $MODPATH >&2
 
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/LowBattery.ogg' -d $MODPATH >&2

}
