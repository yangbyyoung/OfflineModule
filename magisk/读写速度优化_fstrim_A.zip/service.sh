#!/system/bin/sh
MODDIR=${0%/*}
sleep 30
while true ;do
if
/sbin/.magisk/busybox/fstrim -v /data
/sbin/.magisk/busybox/fstrim -v /cache
/sbin/.magisk/busybox/fstrim -v /system
/sbin/.magisk/busybox/fstrim -v /vendor
then : 
elif
/dev/*/.magisk/busybox/fstrim -v /data
/dev/*/.magisk/busybox/fstrim -v /cache
/dev/*/.magisk/busybox/fstrim -v /system
/dev/*/.magisk/busybox/fstrim -v /vendor
then : 
else
echo "- fstrim失败"
fi
sleep 3d
done