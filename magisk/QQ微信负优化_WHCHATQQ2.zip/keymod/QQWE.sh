
function set_up_proc (){
pose="
com.tencent.mm:sandbox*
com.tencent.mm:exdevice*
com.tencent.mobileqq:tool*
com.tencent.mobileqq:qzone*
com.tencent.mobileqq:mini*
com.tencent.mm:tools*
com.tencent.mm:appbrand*
com.tencent.mobileqq:picture*
com.tencent.mobileqq:TMAssistantDownloadSDKService*
com.tencent.mobileqq:video*
com.tencent.mm:hotpot*
com.tencent.mobileqq:hotpot*
"


#开机建议全部清理这些进程
for i in $pose
do
	pgrep -f "$i" | while read PID;do kill -9 "$PID" ;done
done

for i in com.tencent.mobileqq com.tencent.mm ;do
	pgrep -f "$i" | while read pid ;do
		echo 15 > /proc/$pid/oom_adj
		echo 1000 > /proc/$pid/oom_score_adj
	done
done
}

until $(dumpsys deviceidle get screen) ;do
	sleep 5
done

a=0
while :;do
set_up_proc 2>/dev/null
a=$(($a+1))
test $a == 2 && break
done