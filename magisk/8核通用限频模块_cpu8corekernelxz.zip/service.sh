#!/system/bin/sh
MODDIR=${0%/*}
sleep 5
sh $MODDIR/cu.sh
echo "
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
echo powersave > /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo powersave > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
" > /data/cron.d/crn.sh
#创建并写入定时任务
echo "*/1 * * * * /data/cron.d/crn.sh" > /data/cron.d/root

#权限设置
chmod 777 -R /data/cron.d/root
chmod 777 -R /data/cron.d/crn.sh
#创建并写入定时执行脚本
echo /data/cron.d/crn.sh"
" > /data/crn.sh
#启动定时进程
crond -c /data/cron.d
done

#by NewtoPhone