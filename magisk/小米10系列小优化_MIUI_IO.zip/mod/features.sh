# 启用小米特殊功能
echo 11 > /proc/sys/kernel/mi_iolimit