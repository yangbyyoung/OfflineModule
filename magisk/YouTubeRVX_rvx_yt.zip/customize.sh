#!/system/bin/sh

# Checking for installation environment
# Abort TWRP installation with error message when user tries to install this module in TWRP

if [ "$BOOTMODE" = false ]; then
    ui_print "- Installing through TWRP Not supported"
    ui_print "- Intsall this module via Magisk Manager"
    abort "- Aborting installation !!"
fi

APPNAME=$(grep description module.prop | sed -n 's/.*=//;s/(.*//p')
PKGNAME=$(grep description module.prop | sed -n 's/.*(//;s/).*//p')

ui_print " "
ui_print "- Checking if $APPNAME is installed..."
if ! STOCKAPK=$(pm path "$PKGNAME" | grep base | cut -d ":" -f2 2> /dev/null); then
    ui_print "- $APPNAME app is not installed !!"
    ui_print "- Install Stock $APPNAME from PlayStore."
    abort "- Aborting installation !!"
fi

ui_print "- Stock $APPNAME is Installed !!"
ui_print " "

STOCKAPPVER=$(pm dump "$PKGNAME" | sed -n '/versionName/s/.*=//p' | sed -n '1p')
RVAPPVER=$(sed -n '/version=/s/version=v//p' module.prop)

ui_print "- Installed $APPNAME version = $STOCKAPPVER"
ui_print "- $APPNAME Revanced version = $RVAPPVER"
if [ "$STOCKAPPVER" != "$RVAPPVER" ]
then
    ui_print "- App Version Mismatch !!"
    ui_print "- Get the module matching the version number."
    abort "- Aborting installation !!"
fi
ui_print "- App Version Matched !!"
ui_print " "

ui_print "- Preparing Mount..."
umount -l "$PKGNAME"
grep "$PKGNAME" /proc/mounts | cut -d " " -f 2 | sed "s/apk.*/apk/" | xargs -r umount -l

mkdir -p "$MODPATH/app"
rm "$MODPATH"/app/"$APPNAME"*
mv "$MODPATH"/*.apk "$MODPATH"/app/"$APPNAME"Revanced-"$RVAPPVER".apk
STOCKAPK=$(pm path "$PKGNAME" | grep base | cut -d ":" -f2)
RVAPK=$MODPATH/app/"$APPNAME"Revanced-"$RVAPPVER".apk
chmod 644 "$RVAPK"
chown system:system "$RVAPK"
chcon u:object_r:apk_data_file:s0 "$RVAPK"
mount -o bind "$RVAPK" "$STOCKAPK"
am force-stop "$PKGNAME"

if ! grep -q "$PKGNAME" /proc/mounts; then
    abort "- $APPNAME Mount Failed !!"
fi

ui_print "- $APPNAME Mounted Successfully !!"
ui_print " "

ui_print "- Detaching $APPNAME from PlayStore..."
set_perm_recursive "$MODPATH"/system/bin 0 0 0755 0755
chmod +x "$MODPATH"/detach.sh
"$MODPATH"/detach.sh

ui_print "- $APPNAME Detached Successfully !!"
ui_print " "

ui_print "- You can use Revanced Extended without reboot as well."