#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

#以下均来自酷安@风雪如花剑如霜

#来源于scene（感谢@嘟嘟斯基）（感谢酷安@戟鲸的测试）
sleep 5

am kill logd
killall -9 logd
am kill logd.rc
killall -9 logd.rc
stop logd 2> /dev/null
killall -9 logd 2> /dev/null
stop logd.rc 2> /dev/null
killall -9 logd.rc 2> /dev/null

#开启maliGPU游戏模式
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
echo 1 >/sys/module/ged/parameters/gx_game_mode

#开启联发科GPU无限缓存
echo Y > /sys/kernel/debug/mali0/ctx/defaults/infinite_cache

#禁用lsposed日志
rm -rf /data/adb/lspd/log
touch /data/adb/lspd/log
chmod 000 /data/adb/lspd/log

#---耗电无用进程优化---
am kill cnss_diag
killall -9 cnss_diag
stop cnss_diag
#禁用tcpdump
am kill tcpdump
killall -9 tcpdump
stop tcpdump

#开机释放缓存（尝试清理）
sleep 10
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory

#干掉iorap.cmd.compiler
am kill iorap.cmd.compiler
killall -9 iorap.cmd.compiler
stop iorap.cmd.compiler

#清理wifi 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs

#关闭HW叠加层
while :
do
if [ $sf -eq 1 ]
then
service call SurfaceFlinger 1008 i32 1
break
else
sf=$(service list | grep -c "SurfaceFlinger")
sleep 2
fi
done

#利用fstrim对设备读写进行优化（来自酷安@温亮平）
mkdir 777 /data/cron.d
echo "*/20 * * * * /data/cron.sh" > /data/cron.d/root
echo "
fstrim /data
fstrim /cache
fstrim /system
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
" > /data/cron.sh
crond -c /data/cron.d

#修复ROOT后F2FS性能下降的问题(如不生效请手动将sdc59改成你自己手机机型下的目录)
while [[ "$(cat /sys/fs/f2fs/sdc59/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/sdc59/cp_interval
done

while [[ "$(cat /sys/fs/f2fs/sdc59/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/sdc59/gc_urgent_sleep_time
done

while [[ "$(cat /sys/fs/f2fs/sdc59/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/sdc59/iostat_enable
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
done

#app清理＋去广告来(自酷安@风雪如花剑如霜)
C=/sbin/.magisk/busybox/rm
#清理内容
D=/data/media/0
$C -rf $D/360
$C -rf $D/tad
$C -rf $D/mivideo
$C -rf $D/MT2/.temp/*
$C -rf $D/MiMarket
$C -rf $D/OSSLog
$C -rf $D/QQBrowser
$C -rf $D/bytedance
$C -rf $D/cache
$C -rf $D/dctp
$C -rf $D/did
$C -rf $D/duilite
$C -rf $D/tbs
$C -rf $D/tga
$C -rf $D/ttscache
$C -rf $D/txrtmp
$C -rf $D/.cc
$C -rf $D/.com.taobao.dp
$C -rf $D/.DataStorage
$C -rf $D/.gs_file
$C -rf $D/.OAIDSystemConfigh
$C -rf $D/.OAIDSystemConfig
$C -rf $D/.tbs
$C -rf $D/.turingdebug
$C -rf $D/.UTSystemConfig
$C -rf $D/.vivo
$C -rf $D/umeng_cache
$C -rf $D/.gs_fs0
$C -rf $D/.gs_fs3
$C -rf $D/.gs_fs6
$C -rf $D/mipush
$C -rf $D/.turing.dat
$C -rf $D/.zzz
$C -rf $D/.um
$C -rf $D/.a.dat
$C -rf $D/.a.dat
$C -rf $D/.uxx
$C -rf $D/.*Trash*
$C -rf $D/.Android
$C -rf $D/.BD_SAPI_CACHE
$C -rf $D/.ColombiaMedia
$C -rf $D/.volley.cache
$C -rf $D/at
$C -rf $D/baidu
$C -rf $D/libs
$C -rf $D/setup
$C -rf $D/sitemp
$C -rf $D/Subtitles
$C -rf $D/GX_Download
$C -rf $D/1
$C -rf $D/.UTSystemConfig
$C -rf $D/.turingdebug
$C -rf $D/.Trusfort
$C -rf $D/.pzir
$C -rf $D/.protected_image
$C -rf $D/.mm_sdk_source
$C -rf $D/.lm_device
$C -rf $D/.INSTALLATION
$C -rf $D/.Download
$C -rf $D/.dlprovider
$C -rf $D/.andro
$C -rf $D/miad
$C -rf $D/sina/weibo/imageMapper_cache
$C -rf $D/logs
$C -rf $D/logger
$C -rf $D/eg.a
$C -rf $D/Download/.cu
$C -rf /proc/sys/debug/*
$C -rf /sys/kernel/debug/*
$C -rf /data/system/dropbox/*
$C -rf /dev/fscklogs/*
$C -rf /data/system/package_cache/*
$C -rf /data/tombstones/*
$C -rf /data/local/*
$C -rf /data/system/nativedebug/*
$C - rf  /data/media/0/.com.android.providers.downloads.ui/*
$C - rf  /data/media/0/.com.android.providers.downloads/*
find $D/ -name '.td-3' -type f -print -exec rm -rf {} \;
find $D/ -name '.tdck' -type f -print -exec rm -rf {} \;
find $D/ -name '*.log' -type f -print -exec rm -rf {} \;
find $D/ -name '*.tmp' -type f -print -exec rm -rf {} \;
find $D/ -name '*.log.*' -type f -print -exec rm -rf {} \;
find $D/ -name '*._log.*' -type f -print -exec rm -rf {} \;
K=/sbin/.magisk/busybox/chattr
#禁用广告
touch $D/sina/weibo/imageMapper_cache
touch $D/tad
touch $D/GX_Download
touch $D/miad
touch $D/umeng_cache
$K +i $D/tad
$K +i $D/GX_Download
$K +i $D/miad
$K +i $D/umeng_cache
$K +i $D/sina/weibo/imageMapper_cache

#UFS(来自酷安@风雪如花剑如霜)
#禁用I/O统计
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sdb/queue/iostats
echo 0 > /sys/block/sdc/queue/iostats
echo 0 > /sys/block/sdd/queue/iostats
echo 0 > /sys/block/sde/queue/iostats
echo 0 > /sys/block/sdf/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/sda/queue/nomerges
echo 0 > /sys/block/sdb/queue/nomerges
echo 0 > /sys/block/sdc/queue/nomerges
echo 0 > /sys/block/sdd/queue/nomerges
echo 0 > /sys/block/sde/queue/nomerges
echo 0 > /sys/block/sdf/queue/nomerges

#EMMC
#禁用I/O 统计(EMMC)
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/mmcblk0/queue/nomerges
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats


#禁用I/O调试，UFS 和EMMC皆可用
echo 0 > /sys/block/loop0/queue/iostats
echo 0 > /sys/block/loop1/queue/iostats
echo 0 > /sys/block/loop2/queue/iostats
echo 0 > /sys/block/loop3/queue/iostats
echo 0 > /sys/block/loop4/queue/iostats
echo 0 > /sys/block/loop5/queue/iostats
echo 0 > /sys/block/loop6/queue/iostats
echo 0 > /sys/block/loop7/queue/iostats
echo 0 > /sys/block/loop8/queue/iostats
echo 0 > /sys/block/loop9/queue/iostats
echo 0 > /sys/block/loop10/queue/iostats
echo 0 > /sys/block/loop11/queue/iostats
echo 0 > /sys/block/loop12/queue/iostats
echo 0 > /sys/block/loop13/queue/iostats
echo 0 > /sys/block/loop14/queue/iostats
echo 0 > /sys/block/loop15/queue/iostats

#关闭RAMDUMP
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps

# 禁用驱动程序调试(和i/o无关)
echo 0 > /sys/module/binder/parameters/debug_mask
echo 0 > /sys/module/binder_alloc/parameters/debug_mask
echo 0 > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo 0 > /sys/module/millet_core/parameters/millet_debug
echo 0 > /proc/sys/migt/migt_sched_debug
echo N > /sys/kernel/debug/debug_enabled

#禁用binder活页夹日志
echo 0 > /sys/module/binder/parameters/debug_mask

# 禁用用户空间向dmesg写入日志
echo off > /proc/sys/kernel/printk_devkmsg

# 禁用调度统计
echo 0 > /proc/sys/kernel/sched_schedstats

#更改磁盘I/O预读大小
echo 128 > /sys/block/sda/queue/read_ahead_kb
echo 128 > /sys/block/sdb/queue/read_ahead_kb
echo 128 > /sys/block/sdc/queue/read_ahead_kb
echo 128 > /sys/block/sde/queue/read_ahead_kb
#* eMMC设备使用命令:
echo 128 > /sys/block/mmcblk0/queue/read_ahead_kb

#调整虚拟内存更新/刷新间隔
echo 20 > /proc/sys/vm/stat_interval

#6. 调整page页面集群大小
echo 0 > /proc/sys/vm/page-cluster

# 调整脏页写回策略时间
echo 3000 > /proc/sys/vm/dirty_expire_centisecs

# ZRAM分区参数调整
echo 128 > /sys/block/zram0/queue/read_ahead_kb
echo 36 > /sys/block/zram0/queue/nr_requests

#开机40秒清理电池优化名单(来自酷安@大铁 早起刷刷机)
sleep 40
#优化白名单，（添加应用包名后，将保留应用不被移出电池优化）
#示例：+com.tencent.mm +后面是微信包名
noDozes="
+com.tencent.mm 
+com.tencent.mobileqq
"
#执行移出电池优化名单
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes

#安卓UI流畅度优化，提高ui相关进程优先级
sleep 2s

function white_list()
{
  pgrep -o $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white_list surfaceflinger
white_list webview_zygote

function white()
{
  pgrep -f $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white android.hardware.graphics.composer@2.2-service
white zygote
white zygote64
white com.android.systemui

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 1 > /dev/stune/rt/schedtune.prefer_idle
echo 20 > /dev/stune/rt/schedtune.boost
echo 20 > /dev/stune/top-app/schedtune.boost
echo 1 > /dev/stune/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 50 > /dev/memcg/memory.swappiness

#开启F2FS加速回收
# 启用f2fs_gc_booster
echo "1" > /sys/fs/f2fs/sdc59/gc_booster

#存储io激进程度
echo "2" > /sys/block/mmcblk0/queue/rq_affinity
echo "2" > /sys/block/sda/queue/rq_affinity
echo "2" > /sys/block/sdb/queue/rq_affinity
echo "2" > /sys/block/sdc/queue/rq_affinity

#提升IO速度与网络速度
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo noop > /sys/block/sda/queue/scheduler
echo noop > /sys/block/sdc/queue/scheduler
echo noop > /sys/block/sdb/queue/scheduler
echo noop > /sys/block/mmcblk0/queue/scheduler

#安卓tcp优化（调整initcwnd和initrwnd，减少数据包的传递次数，提高传输速度）
ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 40;
done

#进程可打开文件数优化
echo 2390251 > /proc/sys/fs/file-max

#主动整理内存碎片，提升系统性能
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

alias free=$(magisk --path)/.magisk/busybox/free
test -e /sbin/.magisk/busybox/ && alias free=/sbin/.magisk/busybox/free

function M(){
all=`free -m|grep "Mem"|awk '{print $2}'`
use=`free -m|grep "Mem"|awk '{print $3}'`
echo $(($use*100/$all))
}

if [ $(M) -ge 60 ];then
sync 
echo 3 > /proc/sys/vm/drop_caches  
echo 1 > /proc/sys/vm/compact_memory
sync
fi

#关闭LMK调试提升性能
echo 0 > /sys/module/lowmemorykiller/parameters/debug_level

#ZRAM线程增加到8线程，提升压缩效率和流畅度
echo 8 > /sys/block/zram0/max_comp_streams