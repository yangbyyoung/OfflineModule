# uninstall running

Remove_dalvik_cache()
{
	local target_file
	local target_path="/data/dalvik-cache/"
	for target_file in $(find $target_path -type f -iname '*securitycenter*' -o -iname '*securityadd*' -o -iname '*barrage*'); do
		rm -f $target_file
	done
}
Remove_dalvik_cache
