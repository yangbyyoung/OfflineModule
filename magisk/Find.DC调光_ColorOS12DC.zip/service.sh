#!/system/bin/sh
MODDIR=${0%/*}

chmod 777 /data/adb/modules/ColorOS-DC/service.sh

until [[ $(getprop sys.boot_completed) -eq 1 ]] && [[ $hbm -eq 0 ]];do
echo 1 > /sys/kernel/oplus_display/dimlayer_hbm
sleep 0
done

$MODDIR/service.sh $(cat $MODDIR/proc/cpuinfo)