SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
on_install() {
 unzip -o "$ZIPFILE" 'GPU_backuper/cp' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'GPU_backuper/find' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'GPU_backuper/backup.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'GPU_backuper/update_backup.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libllvm-glnext.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libq3dtools_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libc2d30_bltlib.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libGLESv2_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libOpenCL.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libfastcvopt.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/hw/vulkan.msmnile.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libqseed3.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libEGL_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libgsl.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libadreno_utils.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libCB.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libllvm-qcom.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libQTapGLES.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/eglSubDriverAndroid.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libGLESv1_CM_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libq3dtools_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libGLESv2_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libEGL_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/egl/libq3dtools_esx.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libhdr_tm.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/libC2D2.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.version.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.software.vulkan.deqp.level.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.level.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.compute.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.opengles.aep.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.compute-0.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.level-1.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/permissions/android.hardware.vulkan.version-1_1.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libllvm-glnext.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libq3dtools_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libc2d30_bltlib.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libGLESv2_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libOpenCL.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libfastcvopt.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/hw/vulkan.msmnile.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libqseed3.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libEGL_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libgsl.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libadreno_utils.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libCB.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libllvm-qcom.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libQTapGLES.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/eglSubDriverAndroid.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libGLESv1_CM_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libq3dtools_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libGLESv2_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libEGL_adreno.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/egl/libq3dtools_esx.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libhdr_tm.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/libC2D2.so' -d $MODPATH >&2
 ui_print " ";
ui_print "正在清除GPU缓存，一般情况需要较长时间，请耐心等待~";
sleep 9;
for i in "$(find /data \( -path /data/media -o -path /data/data \) -prune -o -type f -name '*shader*')"; do
  rm -f $i
done;
ui_print "清除完成~";
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}