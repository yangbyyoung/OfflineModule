MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

source ${0%/*}/path.sh

if test -e "$Backup_path2" ; then
	echo "正在进行还原..."
	cd /data/adb
	# 对需要恢复的原来模块进行删除
	for mod2 in $( tar -tf $Backup_path2; ); do
		if test -d "$mod2" ; then
			rm -rf $mod2
		fi
	done
	tar -xf $Backup_path2
	echo "还原模块完成"
else
	echo "还原文件 $Backup_path2 不存在!"
fi

