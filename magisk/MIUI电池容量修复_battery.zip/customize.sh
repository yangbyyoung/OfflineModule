SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

echo ' ********************************************************'
echo ''
echo " - 模块: $MODNAME"
echo " - 模块ID: $MODID"
echo " - 模块版本: $MODversion"
echo " - 模块代号: $MODversionCode"
echo " - 模块描述: $MODdescription"
echo " - 作者: $MODAUTHOR"
echo ' ********************************************************'
echo ""

if [[ -f /sys/class/power_supply/bms/charge_full ]]; then
    echo ' - 检测到/sys/class/power_supply/bms/charge_full文件存在，刷入模块成功！'
else
    echo '未找到电量文件，不支持此手机，模块刷入失败！'
    exit 1
fi

echo ""
echo " ********************************************************"
