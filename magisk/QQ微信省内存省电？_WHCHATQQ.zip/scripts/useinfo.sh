MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

function opts2(){
	reset
	clear
	echo ""
	echo ""
	echo "●——————模块使用手册————●"
	echo ""
	echo ""
	echo "\e[0;33m1. 定时任务？\e[0m"
	echo ""
	echo "\e[0;33m2. 如何让QQ和微信更\e[0;31m耗电\e[0m ？\e[0m"
	echo ""
	echo "\e[0;33m3. 是否需要息屏清理？\e[0m"
	echo ""
	echo "\e[0;33m4. ifw禁用组件和pm禁用组件有什么不同？\e[0m"
	echo ""
	echo "\e[0;33m5. 是否需要编译应用？编译应用有什么用？\e[0m"
	echo ""
	echo "\e[0;33m6. 编译应用后怎么恢复？\e[0m"
	echo ""
	echo "\e[0;33m7. 模块副作用怎么办？\e[0m"
	echo ""
	echo "\e[0;33m8. 我的省电方案是什么？\e[0m"
	echo ""
	echo "\e[0;33m9. 微信/QQ闪退公众号/网页闪退？\e[0m"
	echo ""
	echo "10. 回到模块控制台"
	echo ""
	echo ""
	read d1
	if test $d1 == 1  ;then
		A1
	elif [ $d1 == 2 ];then
		A2
	elif [ $d1 == 3 ];then
		A3
	elif [ $d1 == 4 ];then
		A4
	elif [ $d1 == 5 ];then
		A5
	elif [ $d1 == 6 ];then
		A6
	elif [ $d1 == 7 ];then
		A7
	elif [ $d1 == 8 ];then
		A8
	elif [ $d1 == 9 ];then
		A9
	elif [ $d1 == 10 ];then
		source $MODPATH/scripts/qw.sh
	elif [ "$d1" != "*[0-9]*" ];then
		reset
		clear
		opts2
	fi
}

backopt2(){
	echo ""
	echo ""
	echo "∞————————————————————————∞"
	echo ""
	echo ""
	echo "1.回到使用手册"
	echo ""
	echo "2.回到模块终端控制器"
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	read d
	if test $d == 1 ;then
		opts2
	elif [ $d == 2 ];then
		source $MODPATH/scripts/qw.sh
	fi
	echo ""
	echo "∞————————————————————————∞"
}

A1(){
	reset
	clear
	echo "\e[0;33m1. 定时任务？\e[0m"
	echo " 模块当前使用的是 crond 定时任务来清理进程。"
	echo ""
	echo " 当前的定时任务有亮屏清理，息屏清理，空闲内存回收"
	echo ""
	echo " 模块清理的进程，并不影响QQ或者微信的主进程，所以影响消息延迟的情况基本不存在。"
	echo ""
	echo ""
	echo " \e[0;41m一般我也只开亮屏清理任务就够了，因为亮屏清理任务不是指仅在亮屏清理，息屏也一样。\e[0m"
	backopt2
}


A2(){
	reset
	clear
	echo "\e[0;33m2. 如何让QQ和微信更耗电？\e[0m"
	echo ""
	echo " 把模块控制台的所有任务全部打开，ifw和pm一起用。"
	echo ""
	backopt2
}

A3(){
	reset
	clear
	echo "\e[0;33m3. 是否需要息屏清理？\e[0m"
	echo ""
	echo " 目前来说，我觉得并不需要。"
	echo " \e[0;31m因为息屏清理只会增加不断唤醒设备的几率。\e[0m"
	echo ""
	backopt2
}

A4(){
	reset
	clear
	echo "\e[0;33m4. ifw禁用组件和pm禁用组件有什么不同？\e[0m"
	echo ""
	echo " ifw 和 pm 都是禁用组件的好手"
	echo ""
	echo " ifw 可以快速并且很稳地压制应用活动"
	echo ""
	echo " pm 禁用会重启应用，而且压制毒瘤的能力没有ifw强和快"
	echo ""
	echo " \e[0;31m但是由于版本限制，安卓10以后ifw 开始水土不服，容易出现bug，例如卡开机之类的。\e[0m"
	echo ""
	echo " \e[0;31m所以这两种模式建议都试试，那个感觉好，就用哪个。\e[0m"
	echo ""
	backopt2
}

A5(){
	reset
	clear
	echo ""
	echo "\e[0;33m编译应用是什么原理呢？\e[0m"
	echo ""
	echo " 现今应用加载之前需要先编译一段时间，才能运行。"
	echo ""
	echo " 而如果你提前编译了应用就不用重新编译一遍然后再运行"
	echo ""
	echo " \e[0;31m 这样就能够降低CPU使用率 \e[0m"
	echo ""
	echo " 降低了使用率，温度，耗电，不就都降下来了吗？"
	echo ""
	echo " \e[0;33m 那么为何说能够增加运存呢？\e[0m"
	echo ""
	echo " ①因为现在许多rom都自带虚拟运存，虚拟运存需要消耗CPU。"
	echo " 少了编译应用的那部分CPU消耗，虚拟运存搬运的那份精力自然就有了。"
	echo " ②运行应用时，不能够完全编译完，有时候会一边使用一边编译"
	echo " 如果提前编译好，就会降低一个应用的运存占用。"
	echo ""
	echo "\e[0;33m 为什么采用speed 而不是 everything ？\e[0m"
	echo ""
	echo " ①理论上everything和speed 优化程度都差不多，但是储存空间却比speed 大许多。"
	echo " \e[0;31m ②很多应用喜欢热更新，everything 就显得很鸡肋 \e[0m"
	echo ""
	echo ""
	echo "\e[0;33m 为什么不编译全部应用？而是系统应用？\e[0m"
	echo ""
	echo " ①试问你每个应用都需要像系统应用一样时时运行吗？"
	echo " ②编译系统应用和全部应用，实际体验流畅效果都差不多。"
	echo ""
	echo ""
	backopt2
}



A6(){
	reset
	clear
	echo "\e[0;33m6. 编译应用后怎么恢复？\e[0m"
	echo ""
	echo " ①清除\e[0;42m/data/dalvik-cache/\e[0m这个文件夹"
	echo ""
	echo " 然后重启，接着你就需要等待8-20分钟才能开机。"
	echo " 开机后也会发热和耗电，所以编译以后别问我怎么恢复。"
	echo ""
	echo " ②覆盖刷入完整包"
	echo ""
	echo " 不会丢失任何数据，开机时间在5分钟内。"
	echo ""
	echo ""
	backopt2
}



A7(){
	reset
	clear
	echo "\e[0;33m7. 模块副作用怎么办？\e[0m"
	echo ""
	echo "\e[0;41m       卸载这垃圾模块！！！ \e[0m"
	echo ""
	echo "\e[0;41m       卸载这垃圾模块！！！ \e[0m"
	echo ""
	echo "\e[0;41m       卸载这垃圾模块！！！ \e[0m"
	echo ""
	backopt2
}

A8(){
	reset
	clear
	echo "\e[0;33m8. 我的省电方案？\e[0m"
	echo ""
	echo "\e[0;41m①开启亮屏清理任务\e[0m"
	echo ""
	echo "\e[0;41m②编译QQ微信，以及系统应用 \e[0m"
	echo ""
	echo "\e[0;41m③利用ifw或者pm压住不必要的进程\e[0m"
	echo ""
	backopt2
}

A9(){
	reset
	clear
	echo "\e[0;33m9. 微信/QQ闪退公众号/网页闪退？\e[0m"
	echo ""
	echo "①理清楚逻辑"
	echo ""
	echo "②QQ，微信，这些我只保留了接受消息的进程"
	echo ""
	echo "③所以会清除有关QQ和微信其他进程。"
	echo ""
	echo "④清理的时间就是亮屏任务的时间(没设置就是默认一分钟)。"
	echo ""
	echo "⑤另外清理进程，有限制，就是QQ或者微信在前台(也就是你打开的时候)不清理。"
	echo ""
	echo "⑥如果在到了清理间隔的时间，你下滑状态栏/打开传送门之类的，让QQ/微信，不在前台，就会公众号/网页被清理掉。"
	echo ""
	echo ""
	echo ""
	backopt2
}

opts2
