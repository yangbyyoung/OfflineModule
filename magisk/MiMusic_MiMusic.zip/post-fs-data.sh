mount -o rw,remount /data
MODDIR=${0%/*}

# cleaning
FILE=$MODDIR/cleaner.sh
if [ -f $FILE ]; then
  sh $FILE
  rm -f $FILE
fi




