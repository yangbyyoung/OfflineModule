#!/system/bin/sh

until $(dumpsys deviceidle get screen) ;do
	sleep 5
done


export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH

file=${0%/*}/ads.conf

ads="$(cat $file | sed '/^[[:space:]]*$/d;/^.*#/d' )"

function cads(){
	if test -e "$1" ;then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function recoveryads(){
	if test -e "$1" ;then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

function cadsclear(){
	for i in $ads;do
		file=`find "$i" 2> /dev/null`
		cads $file 2> /dev/null
	done
}

function readclear(){
	for i in $ads;do
		file=`find "$i" 2> /dev/null`
		recoveryads $file 2> /dev/null
	done
}


cadsclear

