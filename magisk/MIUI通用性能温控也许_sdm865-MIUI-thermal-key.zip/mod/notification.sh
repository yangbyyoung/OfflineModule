#!/system/bin/sh

sleep 3m

function echo_head_info(){
echo "品牌=`getprop ro.product.brand`"
echo "代号=`getprop ro.product.device`"
echo "模型=`getprop ro.product.model`"
echo "安卓版本=`getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && echo "MIUI版本=MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
echo "内核版本=`uname -a `"
echo "处理器=$(getprop ro.board.platform)"
echo "上次云控更新日期:$(content query --uri 'content://com.miui.powerkeeper.configure/SimpleSettings/misc' --where "name='last_sync_cloud_info'" | sed 's|.*value=||g;s|,.*||g')"
}

function magisk_app_uid(){
local package userid
if test "$( pm list package | grep -w 'com.topjohnwu.magisk' )" != "" ;then
	package='com.topjohnwu.magisk'
elif test "$( pm list package | grep -w 'io.github.huskydg.magisk' )" != "" ;then
	package='io.github.huskydg.magisk'
else
	package=`magisk --sqlite "SELECT value FROM strings where key='requester'"`
fi
if test "$package" != '' ;then
	userid="$(dumpsys package "${package}" | grep userId | uniq | tr -cd '[0-9]' | head -n 1)"
	echo "${userid}"
else
	echo '1000'
fi
}



function notification_simulation(){
local title="${2}"
local text="${1}"
local author="${3}"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
	test -z "${title}" && title='10007'
		test -z "${text}" && text='您未给出任何信息'
	test "`echo "${author}" | grep -E '^[0-9].*[0-9]$'`" = "" && author="2000"
su -lp "${author}" -c "cmd notification post -S messaging --conversation '${title}' --message '${title}':'${text}' 'Tag' '$(echo $RANDOM)' " >/dev/null 2>&1
}


notification_simulation "$(echo_head_info)" "MIUI性能温控" "2000"


