#!/system/bin/sh
MODDIR=${0%/*}
cat /data/media/0/Android/TNT配置/eveio.conf > ${MODDIR}/eveio.conf
chmod 777 ${MODDIR}/eveio.conf
sh ${MODDIR}/eveio.conf
rm-rf /data/system/batterystats.bin
echo $Preread > /sys/class/power_supply/battery/charge_full_design
echo $Preread > /sys/class/power_supply/bms/charge_full_design