#!/system/bin/sh


dir="${0%/*}"
MODPATH="${dir%/*}"


#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

target_value="$(show_value '智能刷新率')"


if test "$target_value" = "是" ;then
settings put system is_smart_fps 1
	settings put global is_smart_fps 1
		settings put secure is_smart_fps 1
		settings put system support_smart_fps true
	settings put global support_smart_fps true
settings put secure support_smart_fps true
else
settings put system is_smart_fps 0
	settings put global is_smart_fps 0
		settings put secure is_smart_fps 0
		settings put system support_smart_fps false
	settings put global support_smart_fps false
settings put secure support_smart_fps false
fi





