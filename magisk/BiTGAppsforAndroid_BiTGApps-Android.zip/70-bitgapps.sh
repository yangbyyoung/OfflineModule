#!/sbin/sh
#
# This file is part of The BiTGApps Project

# ADDOND_VERSION=3

if [ -z "$backuptool_ab" ]; then
  SYS="$S"
  TMP=/tmp
else
  SYS="/postinstall/system"
  TMP="/postinstall/tmp"
fi

# Required for SetupWizard
setup_config="false"

. /tmp/backuptool.functions

list_files() {
cat <<EOF
app/FaceLock/FaceLock.apk
app/GoogleCalendarSyncAdapter/GoogleCalendarSyncAdapter.apk
app/GoogleContactsSyncAdapter/GoogleContactsSyncAdapter.apk
app/GoogleExtShared/GoogleExtShared.apk
priv-app/ConfigUpdater/ConfigUpdater.apk
priv-app/GmsCoreSetupPrebuilt/GmsCoreSetupPrebuilt.apk
priv-app/GoogleExtServices/GoogleExtServices.apk
priv-app/GoogleLoginService/GoogleLoginService.apk
priv-app/GoogleServicesFramework/GoogleServicesFramework.apk
priv-app/Phonesky/Phonesky.apk
priv-app/PrebuiltGmsCore/PrebuiltGmsCore.apk
priv-app/GoogleBackupTransport/GoogleBackupTransport.apk
priv-app/GoogleRestore/GoogleRestore.apk
priv-app/SetupWizardPrebuilt/SetupWizardPrebuilt.apk
etc/default-permissions/default-permissions.xml
etc/default-permissions/gapps-permission.xml
etc/permissions/com.google.android.dialer.support.xml
etc/permissions/com.google.android.maps.xml
etc/permissions/privapp-permissions-google.xml
etc/permissions/split-permissions-google.xml
etc/preferred-apps/google.xml
etc/sysconfig/google.xml
etc/sysconfig/google_build.xml
etc/sysconfig/google_exclusives_enable.xml
etc/sysconfig/google-hiddenapi-package-whitelist.xml
etc/sysconfig/google-rollback-package-whitelist.xml
etc/sysconfig/google-staged-installer-whitelist.xml
framework/com.google.android.dialer.support.jar
framework/com.google.android.maps.jar
product/overlay/PlayStoreOverlay.apk
EOF
}

case "$1" in
  backup)
    list_files | while read FILE DUMMY; do
      backup_file $S/"$FILE"
    done
  ;;
  restore)
    list_files | while read FILE REPLACEMENT; do
      R=""
      [ -n "$REPLACEMENT" ] && R="$S/$REPLACEMENT"
      [ -f "$C/$S/$FILE" ] && restore_file $S/"$FILE" "$R"
    done
    if [ "$setup_config" = "true" ]; then
      for i in $SYS/app $SYS/priv-app; do
        rm -rf $i/ManagedProvisioning $i/Provision $i/LineageSetupWizard
      done
      for i in $SYS/product/app $SYS/product/priv-app; do
        rm -rf $i/ManagedProvisioning $i/Provision $i/LineageSetupWizard
      done
      for i in $SYS/system_ext/app $SYS/system_ext/priv-app; do
        rm -rf $i/ManagedProvisioning $i/Provision $i/LineageSetupWizard
      done
    fi
    rm -rf $SYS/app/ExtShared $SYS/priv-app/ExtServices
    for i in $(list_files); do
      chown root:root "$SYS/$i" 2>/dev/null
      chmod 644 "$SYS/$i" 2>/dev/null
      chmod 755 "$(dirname "$SYS/$i")" 2>/dev/null
    done
  ;;
esac
