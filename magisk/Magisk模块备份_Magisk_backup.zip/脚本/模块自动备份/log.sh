
MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

source ${0%/*}/path.sh

L=${Backup_path%/*}/模块自动备份.tar

test ! -e $L && echo "不存在文件$L" && exit 1

MOD=`tar -tf $L|cut -f2 -d "/"|uniq|grep -v "[a-zA-Z].db"|grep -v "[a-zA-Z].sh"|sed '/^[[:space:]]*$/d'`

grep_prop(){
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

for i in $MOD;do
Bak=`tar -xvf $L modules/$i/module.prop 2>/dev/null`
done
echo "☞=======================================☜" >>${Backup_path%/*}/备份日志.log
echo "时间:$(date +%y年%m月%H点%M分)" >>${Backup_path%/*}/备份日志.log
for o in $(ls ${Backup_path%/*}/modules);do
name=$(grep_prop 'name' ${Backup_path%/*}/modules/$o/module.prop )
echo ""
echo "∞————————————————————————∞"
echo "备份模块名称: $name "
echo "∞————————————————————————∞"
echo ""
echo "
模块:【$name】备份完成">>${Backup_path%/*}/备份日志.log
done
rm -rf ${Backup_path%/*}/modules
echo -e "☞=======================================☜\n" >>${Backup_path%/*}/备份日志.log