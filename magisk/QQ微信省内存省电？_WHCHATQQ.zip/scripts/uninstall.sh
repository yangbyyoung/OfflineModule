file="
/data/system/ifw/com.tencent.mm.xml
/data/system/ifw/com.tencent.mm$.xml
/data/system/ifw/com.tencent.mobileqq.xml
/data/system/ifw/com.tencent.mobileqq$.xml
/data/media/0/Android/QQ微信小模块
"
for i in $file;do
test -e "$i"  && rm -rf "$i"
done