#!/system/bin/sh

MODDIR=${0%/*}

PROCESS()
{
	ps -ef | grep "Clear_Script.sh" | grep -v grep | wc -l
}

while :
do
	if [[ ! -f $MODDIR/disable ]]; then
		if [[ $(PROCESS) -eq 0 ]]; then
			nohup sh $MODDIR/Clear_Script.sh &
		fi
	else
		if [[ $(PROCESS) -ne 0 ]]; then
			kill -9 $(ps -ef | grep Clear_Script.sh | grep -v grep | awk '{ print $2 }')
			[[ $? == 0 ]] && sed -i "/^description=/c description=已手动停止运行 (重新打开则继续运行 无需重启)" "$MODDIR/module.prop"
		fi
	fi
	sleep 5
done