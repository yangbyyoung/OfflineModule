#!/system/bin/sh
MODDIR=${0%/*}
#开机休眠
until [ $(getprop sys.boot_completed) == 1 ]; do
sleep 1
done

#电量和性能
pm disable com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
pm disable com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
#手机管家
pm disable com.miui.securitycenter/com.miui.permcenter.root.RootUpdateReceiver
pm disable com.miui.securitycenter/com.miui.antivirus.receiver.UpdaterReceiver
#耗电检测
pm disable com.xiaomi.powerchecker/com.xiaomi.powerchecker.cloudcontrol.CloudUpdateJobService
pm disable com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
#MIUI质量服务
pm disable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm disable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
#pm uninstall -k --user 0 com.miui.analytics
#清除数据休眠
sleep 10s


cp $MODDIR/data/vendor/thermal/config/*.conf /data/vendor/thermal/config/

cp $MODDIR/data/user_configure.db /data/user/0/com.miui.powerkeeper/databases/

cp $MODDIR/data/SmartP.db /data/user/0/com.xiaomi.joyose/databases/


echo FUCC by 小花生FMR  >> /cache/magisk.log