am start-activity -a android.intent.action.MAIN -c android.intent.category.HOME -n android/com.android.internal.app.ResolverActivity
