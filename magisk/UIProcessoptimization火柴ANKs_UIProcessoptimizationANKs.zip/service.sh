#!/system/bin/sh
MODDIR=${0%/*}
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
sleep 1
crond -c /data/adb/modules/UIProcessoptimization/cron.d