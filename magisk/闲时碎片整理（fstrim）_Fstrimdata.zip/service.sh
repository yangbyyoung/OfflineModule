#!/system/bin/sh
MODDIR=${0%/*}
touch $MODDIR/fstrim.log
chmod +rwx $MODDIR/fstrim
sh $MODDIR/fstrim >>$MODDIR/fstrim.log
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c $MODDIR/cron.d
