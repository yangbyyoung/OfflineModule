#!/system/bin/sh
MODDIR=${0%/*}
echo ----------------------------
mb_id="$(pgrep 'mb.sh' | wc -l)"
mb1_id="$(pgrep 'mb1.sh' | wc -l)"
mb2_id="$(pgrep 'mb2.sh' | wc -l)"

if [ "$mb_id" != "0" ]; then
    echo "\n️ 当前模式：\e[32mKill墓碑\e[0m正在运行！"
elif [ "$mb1_id" != "0" ]; then
    echo "\n ️当前模式：\e[32mFreeze v1墓碑\e[0m正在运行！"
elif [ "$mb2_id" != "0" ]; then
    echo "\n ️当前模式：\e[32mFreeze v2墓碑\e[0m正在运行！"
else
    echo "\n\e[31m墓碑已经关闭……！\e[0m"   
fi
    echo " "
echo ----------------------------

: '
@l奋斗的小青年

进程状态是指进程当前的状态，通常由一个字母表示。常见的状态包括：

R（运行）：进程正在运行或在队列中等待 CPU 时间。
S（休眠）：进程处于休眠状态，等待某个事件的发生。
D（不可中断的休眠）：进程正在等待 I/O 操作完成或收到信号。
Z（僵尸）：进程已经结束，但其父进程尚未对其进行善后处理，导致进程资源没有释放。
T（停止）：进程已经被停止或暂停。
'
echo "\e[36mpid  冻结方式 状态<R运行|S休眠|D待休眠|Z僵尸|T停止> 包名 \e[0m"
ps -A | grep -E "refrigerator|do_freezer|signal" | awk '{print $2, $6, $8, $9}' | sed -E 's/(.*:)[^:]*$/\1/' | sed 's/do_signal_stop/Kill_stop模式/g; s/do_freezer_trap/freezer_v2模式/g; s/__refrigerator/freezer_v1模式/g' | cut -c -50