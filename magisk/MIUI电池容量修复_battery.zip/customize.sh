SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
 
 ui_print "##################"
 ui_print "- 模块相关信息 -"
 ui_print "- 模块: $MODNAME"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 介绍: $MODdescription"
 ui_print "##################"
 ui_print "- 设备相关信息 -"
 ui_print "- 设备SDK: $Sdk"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- 当前版本: $Version"
 ui_print "##################"
if [[ -f /sys/class/power_supply/bms/charge_full ]]; then
    echo ' - 检测到/sys/class/power_supply/bms/charge_full文件存在，刷入模块成功！'
else
    echo '未找到电量文件，不支持此手机，模块刷入失败！'
    exit 1
fi

echo ""
echo " ********************************************************"
