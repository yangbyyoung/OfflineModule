# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

# Set what you want to display when installing your module

print_modname() {
  ui_print "*******************************"
  ui_print "     𝘼𝙡𝙡 𝙞𝙣 𝙊𝙣𝙚 𝙋𝙚𝙧𝙨𝙤𝙣𝙖𝙡   "
  ui_print "      𝙈𝙤𝙙𝙪𝙡𝙚𝙨 𝙍𝙖𝙫𝙚𝙣𝙨𝙞𝙖    "
  ui_print "*******************************"
}
#
on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'assets/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  service=$TMPDIR/service.sh
  module=$TMPDIR/module.prop
  ravensmod=$MODPATH/config/ravensmod
  mods=/data/adb/modules
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh
  cp -af $TMPDIR/configs $MODPATH/configs;
  cp -af $TMPDIR/seederinjector $MODPATH/seederinjector;
  cp -af $TMPDIR/weareseeder $MODPATH/weareseeder;
  cp -af $TMPDIR/WeAreRavenS_extra $MODPATH/WeAreRavenS_extra;
  cp -af $TMPDIR/portal.sh $MODPATH/portal.sh;
ui_print ""
ui_print "* NOTES :"
ui_print "   * Enable 𝙎𝙝𝙤𝙬 𝙃𝙞𝙙𝙙𝙚𝙣 𝙁𝙞𝙡𝙚 in your File Manager app."
ui_print "   * Go to folder /𝙨𝙩𝙤𝙧𝙖𝙜𝙚/𝙚𝙢𝙪𝙡𝙖𝙩𝙚𝙙/0/.𝙬𝙚𝙖𝙧𝙚𝙧𝙖𝙫𝙚𝙣𝙨."
ui_print "   * 𝙁𝙡𝙪𝙨𝙝4, now it will export all your app list as config."
ui_print "   * Edit file 𝙬𝙚𝙖𝙧𝙚𝙧𝙖𝙫𝙚𝙣𝙨_𝙛𝙡𝙪𝙨𝙝.𝙘𝙤𝙣𝙛."
ui_print "   * 𝘈𝘥𝘥 𝘱𝘢𝘤𝘬𝘢𝘨𝘦 𝘢𝘱𝘱 𝘯𝘢𝘮𝘦 𝘵𝘩𝘢𝘵 𝘺𝘰𝘶 𝘸𝘢𝘯𝘵 𝘵𝘰 𝘴𝘵𝘰𝘱 𝘶𝘴𝘪𝘯𝘨 𝘧𝘭𝘶𝘴𝘩4 𝘤𝘰𝘮𝘮𝘢𝘯𝘥."
ui_print "   * 𝘖𝘳 𝘳𝘦𝘮𝘰𝘷𝘦 𝘱𝘢𝘤𝘬𝘢𝘨𝘦 𝘯𝘢𝘮𝘦 𝘢𝘱𝘱 𝘵𝘰 𝘸𝘩𝘪𝘵𝘦𝘭𝘪𝘴𝘵."
ui_print ""
  }

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
  set_perm $MODPATH/portal.sh 0 0 0755 0755
  set_perm $MODPATH/seederinjector 0 0 0755 0755
  set_perm $MODPATH/weareseeder 0 0 0755 0755
  set_perm $MODPATH/WeAreRavenS_extra 0 0 0755 0755
  set_perm_recursive $MODPATH/assets 0 0 0755 0755
  set_perm_recursive $MODPATH/assets/binary 0 0 0755 0755

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# Custom Variables for Install AND Uninstall - Keep everything within this function - runs before uninstall/install
unity_custom() {
  : # Remove this if adding to this function
}

# You can add more functions to assist your custom script code
