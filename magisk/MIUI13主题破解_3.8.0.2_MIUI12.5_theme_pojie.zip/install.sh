SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'system/app/MIUIThemeManager/oat/arm64/MIUIThemeManager.vdex' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MIUIThemeManager/oat/arm64/MIUIThemeManager.odex' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MIUIThemeManager/MIUIThemeManager.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MIUIThemeManager/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MiuiBugReport/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/mab/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MSA/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/MIUIThemeManagerPad/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/ThemeManager/.replace' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}