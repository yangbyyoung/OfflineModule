mod_name="无奈版"
mod_install_desc="$mod_name"
mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"


if [ "`check_mod_install`" = "yes" ]; then
MOD_SKIP_INSTALL=true
fi




mod_install_yes()
{
#设置工具权限
unzip -oq "$ZIPFILE" 'common/*' -d $TMPDIR >&2
set_perm $TMPDIR/common/zip 0 2000 0755 u:object_r:clatd_exec:s0

case "$(getprop ro.miui.ui.version.name)" in
V12 )
#移动文件
if find /data/adb/modules/*/system/media/theme/default/com.miui.home ;then
ui_print "- 发现冲突模块，可能会失效，模块将自动合并，不保证能成功。" 
mkdir -p $MODPATH/system/media/theme/default/com.miui.home/nightmode
mv /data/adb/modules/*/system/media/theme/default/com.miui.home $MODPATH/system/media/theme/com.miui.home.zip
unzip -oq "$MODPATH/system/media/theme/com.miui.home.zip" -d "$MODPATH/system/media/theme/default/com.miui.home" >&2
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home/nightmode
else
ui_print "- 无冲突模块，可正常使用。"
mkdir -p $MODPATH/system/media/theme/default/com.miui.home/nightmode
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home/nightmode
cp -r $MOD_FILES_DIR/com.miui.home.zip $MODPATH/system/media/theme/
fi
#加入手势动画
cd $MODPATH/system/media/theme/default/com.miui.home
$TMPDIR/common/zip -r $MODPATH/system/media/theme/com.miui.home.zip ./* >/dev/null
#清理临时文件
rm -r $MODPATH/system/media/theme/default/com.miui.home
mv $MODPATH/system/media/theme/com.miui.home.zip $MODPATH/system/media/theme/default/com.miui.home
;;

V125 )
if find /data/adb/modules/*/system/media/theme/default/com.miui.home ;then
ui_print "- 发现冲突模块，可能会失效，模块将自动合并，不保证能成功。" 
mkdir -p $MODPATH/system/media/theme/default/com.miui.home/nightmode
mv /data/adb/modules/*/system/media/theme/default/com.miui.home $MODPATH/system/media/theme/com.miui.home.zip
unzip -oq "$MODPATH/system/media/theme/com.miui.home.zip" -d "$MODPATH/system/media/theme/default/com.miui.home" >&2
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home/nightmode
else
ui_print "- 无冲突模块，可正常使用。"
mkdir -p $MODPATH/system/media/theme/default/com.miui.home/nightmode
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.miui.home/nightmode
cp -r $MOD_FILES_DIR/com.miui.home.zip $MODPATH/system/media/theme/
fi
#加入手势动画
cd $MODPATH/system/media/theme/default/com.miui.home
$TMPDIR/common/zip -r $MODPATH/system/media/theme/com.miui.home.zip ./* >/dev/null
#清理临时文件
rm -r $MODPATH/system/media/theme/default/com.miui.home
mv $MODPATH/system/media/theme/com.miui.home.zip $MODPATH/system/media/theme/default/com.miui.home
;;

V11 )
if  find /data/adb/modules/*/system/media/theme/default/com.android.systemui ;then
ui_print "- 发现冲突模块，可能会失效，模块将自动合并，不保证能成功。" 
mkdir -p $MODPATH/system/media/theme/default/com.android.systemui/nightmode
mv /data/adb/modules/*/system/media/theme/default/com.android.systemui $MODPATH/system/media/theme/com.android.systemui.zip
unzip -oq "$MODPATH/system/media/theme/com.android.systemui.zip" -d "$MODPATH/system/media/theme/default/com.android.systemui" >&2
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui/nightmode
else
ui_print "- 无冲突模块，可正常使用。"
mkdir -p $MODPATH/system/media/theme/default/com.android.systemui/nightmode
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui/nightmode
cp -r $MOD_FILES_DIR/com.android.systemui.zip $MODPATH/system/media/theme/
fi
#加入手势动画
cd $MODPATH/system/media/theme/default/com.android.systemui
$TMPDIR/common/zip -r $MODPATH/system/media/theme/com.android.systemui.zip ./* >/dev/null
#清理临时文件
rm -r $MODPATH/system/media/theme/default/com.android.systemui
mv $MODPATH/system/media/theme/com.android.systemui.zip $MODPATH/system/media/theme/default/com.android.systemui
;;

V10 )
#移动文件
if  find /data/adb/modules/*/system/media/theme/default/com.android.systemui ;then
ui_print "- 发现冲突模块，可能会失效，模块将自动合并，不保证能成功。" 
mkdir -p $MODPATH/system/media/theme/default/com.android.systemui/nightmode
mv /data/adb/modules/*/system/media/theme/default/com.android.systemui $MODPATH/system/media/theme/com.android.systemui.zip
unzip -oq "$MODPATH/system/media/theme/com.android.systemui.zip" -d "$MODPATH/system/media/theme/default/com.android.systemui" >&2
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui/nightmode
else
ui_print "- 无冲突模块，可正常使用。"
mkdir -p $MODPATH/system/media/theme/default/com.android.systemui/nightmode
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui
cp -r $MOD_FILES_DIR/res $MODPATH/system/media/theme/default/com.android.systemui/nightmode
cp -r $MOD_FILES_DIR/com.android.systemui.zip $MODPATH/system/media/theme/
fi
#加入手势动画
cd $MODPATH/system/media/theme/default/com.android.systemui
$TMPDIR/common/zip -r $MODPATH/system/media/theme/com.android.systemui.zip ./* >/dev/null
#清理临时文件
rm -r $MODPATH/system/media/theme/default/com.android.systemui
mv $MODPATH/system/media/theme/com.android.systemui.zip $MODPATH/system/media/theme/default/com.android.systemui
;;
esac

return 0

}

mod_install_no()
{
    return 0
}