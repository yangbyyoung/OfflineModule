## Changelog

* v1 - Initial Release
* v2 - Fixed the earpiece not working throughout the system
* v3 - Fixed the earpiece not working during call
* v4 - Converted to Unity module and added AML support
* v5 - Improved patching logic to improve reliability
* v6 - Fixed patch syntax to improve reliability
* v7 - Fixed patch line numbers to improve reliability
* v8 - Fixed phone earpiece issue on AOSP / TreskMod
