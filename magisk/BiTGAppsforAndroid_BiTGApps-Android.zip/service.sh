#!/system/bin/sh
#
# This file is part of The BiTGApps Project

# Mount system partition
mount -o remount,rw,errors=continue / 2>/dev/null
mount -o remount,rw,errors=continue /dev/root 2>/dev/null
mount -o remount,rw,errors=continue /dev/block/dm-0 2>/dev/null
mount -o remount,rw,errors=continue /system 2>/dev/null

# Enable GooglePlayServices APK
for i in PrebuiltGmsCore; do
  if [ -f "/system/priv-app/$i/$i.dpk" ]; then
    mv -f /system/priv-app/$i/$i.dpk /system/priv-app/$i/$i.apk 2>/dev/null
  fi
done
