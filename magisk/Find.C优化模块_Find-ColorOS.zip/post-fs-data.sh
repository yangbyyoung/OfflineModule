#!/system/bin/sh
MODDIR=${0%/*}

chmod 777 /data/adb/modules/Find-ColorOS/service.sh

Tcp=$(sed '/^网络优化=/!d;s/.*=//' $MODDIR/FindC.conf)
HZ=$(sed '/^触控采样率=/!d;s/.*=//' $MODDIR/FindC.conf)
BD=$(sed '/^温度伪装=/!d;s/.*=//' $MODDIR/FindC.conf)
FT=$(sed '/^温控解除=/!d;s/.*=//' $MODDIR/FindC.conf)
DC=$(sed '/^DC调光=/!d;s/.*=//' $MODDIR/FindC.conf)
until [[ $(getprop sys.boot_completed) -eq 1 ]]; do
	sleep 2
done

function tcp(){ 
max=$(dumpsys netstats | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
echo "$max"
}

if [[ $Tcp == "Y" ]] ;then
echo 32768 > /proc/sys/net/core/somaxconn
elif [[ $Tcp == "N" ]] ;then
echo 128 > /proc/sys/net/core/somaxconn
fi
if [[ $HZ == "Y" ]] ;then
echo 1 > /proc/touchpanel/game_switch_enable
elif [[ $HZ == "N" ]] ;then
echo 0 > /proc/touchpanel/game_switch_enable
fi
if [[ $DC == "Y" ]] ;then
sh /data/adb/modules/Find-ColorOS/files/FindDC.sh
sleep 0
fi
if [[ $BD == "Y" ]] ;then
sh /data/adb/modules/Find-ColorOS/files/FindCT.sh
sleep 0
Double=/sys/class/thermal/*/temp
chmod 0000 $Double
elif [[ $BD == "N" ]] ;then
Double=/sys/class/thermal/*/temp
chmod 0444 $Double
fi
if [[ $FT == "Y" ]] ;then
mount --bind $MODDIR/sys/sys_high_temp_protect_OPPO_20061.xml /odm/etc/temperature_profile/sys_high_temp_protect_OPPO_20061.xml
mount --bind $MODDIR/sys/sys_thermal_control_config.xml /odm/etc/temperature_profile/sys_thermal_control_config.xml
mount --bind $MODDIR/sys/sys_thermal_config.xml /odm/etc/ThermalServiceConfig/sys_thermal_config.xml
fi

$MODDIR/service.sh $(cat $MODDIR/proc/sys/net/core/somaxconn)