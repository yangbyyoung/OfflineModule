#!/system/bin/sh

MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

alias free=$BUSYBOXDIR/free


function M(){
	all=`free -m|grep "Mem"|awk '{print $2}'`
	use=`free -m|grep "Mem"|awk '{print $3}'`
	echo $(($use*100/$all))
}

if test $(M) -ge 80 ;then
	sync
	echo 3 > /proc/sys/vm/drop_caches
	echo 1 > /proc/sys/vm/compact_memory
	sync
fi


