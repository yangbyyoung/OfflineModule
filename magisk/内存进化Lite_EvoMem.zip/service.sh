#!/system/bin/sh
EvoMem=${0%/*}
rm -rf /cache/EvoMem.log
cp -n $EvoMem/EvoMem.conf /data
get_prop() {
  EvoMem_config="/data/EvoMem.conf"
  cat $EvoMem_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
log() {
  if ${loge}; then
    log_file="/cache/EvoMem.log"
    touch /cache/EvoMem.log
    echo "[$(date | awk '{print $4}')] $@" >>"$log_file"
  fi
}
efficient=$(get_prop ZramEfficient)
parameter=$(get_prop Modpara)
ramopt=$(get_prop RamOpt)
romopt=$(get_prop RomOpt)
loge=$(get_prop EnableLog)
log "模块运行："
. $EvoMem/EvoMem