## XiaoMi Push Framework Fake

This module will add `miui` prop in your `build.prop` to fake your device to `xiaomi`.

If you want to use XiaoMiPushFramework, please visit [https://github.com/Trumeet/MiPushFramework](https://github.com/Trumeet/MiPushFramework)

If you want to disable XiaoMiPushFramework, please visit [https://github.com/cubesky/MiPushFrameworkFake](https://github.com/cubesky/MiPushFrameworkFake)