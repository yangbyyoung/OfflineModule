Changelog:

Version 1:
- Initial Release
- Added stereo sound effect