SKIPUNZIP=0

PATH="$PATH:/system/xbin:/data/ManjusakaTool"

on_install() {
    $BOOTMODE || abort "! cannot be installed in recovery."
    [ $ARCH == "arm64" ] || abort "! ONLY support arm64 platform."
    filepath="/data/ManjusakaTool"
 if [[ ! -f $filepath ]]; then
    mkdir "$filepath"
 fi    
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -x "Manjusaka.sh" -x "module.prop" -x "service.sh" -x "一键卸载模块+残留文件.sh" -d "/data/ManjusakaTool" >/dev/null
    chmod 777 $filepath/busybox
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null
    ui_print "- Author:Manjusaka"
	ui_print "- Group:647299031"
	  #欢迎拆包查看 请勿二改
	  #作者:Manjusaka(酷安@曼珠沙华Y)
	  #群组:647299031
	  #Busybox存放地址
 busybox="$filepath/busybox"
      #释放地址    
 #检查Busybox并释放
 if [[ -f $busybox ]]; then
 #存在Busybox开始释放
    ui_print "- Releasing BusyBox"
	"$busybox" --list | while read; do
		if [[ $REPLY != tar && ! -f $filepath/$REPLY ]]; then
			ln -fs "$busybox" "$filepath/$REPLY"
		fi
	done
	ui_print "- Complete Release"
    ui_print "- 云端版5.3.0:"
    ui_print "- [1] 仅更换云端地址,其余核心代码均未改动"
    ui_print "- [2] 云端仓库地址: https://gitee.com/qiuleyo/Third-Party-Redirect"
    ui_print "- 如果你想要的应用没有重定向 请在评论区反馈"
    ui_print "- 我会进行适配"
 else
 #不存在Busybox输出
	abort "- Busybox does not exist !!!"
 fi
 
 if [[ ! -z $(which curl) ]]; then
	echo "- Binary_System=$(which curl)"
	echo "Binary_System=\"$(which curl)\"" >> $MODPATH/files/Variable.sh
 elif [[ ! -z $(which wget) ]]; then
	echo "- Binary_System=$(which wget)"
	echo "Binary_System=\"$(which wget)\"" >> $MODPATH/files/Variable.sh
 else
	abort "- [!] 命令缺失: busybox curl/wget 二进制"
 fi

 [[ -d /storage/emulated/0/Download ]] && path="Download" || path="download"

}