Magisk_mod=`grep -w 'local MODDIRNAME' /data/adb/magisk/util_functions.sh | cut -d= -f2 | tr -d [[:space:]] `

files="
$MODPATH/脚本/模块手动备份/log.sh
$MODPATH/脚本/模块手动备份/模块手动备份.sh
$MODPATH/脚本/模块手动备份/模块恢复.sh
$MODPATH/脚本/模块手动备份/查看备份的模块名称.sh
$MODPATH/脚本/模块手动备份/path.sh
$MODPATH/脚本/模块自动备份/log.sh
$MODPATH/脚本/模块自动备份/模块恢复.sh
$MODPATH/脚本/模块自动备份/查看备份的模块名称.sh
$MODPATH/脚本/模块自动备份/path.sh
$MODPATH/system/bin/magiskbackup
$MODPATH/keymod/zip.sh
$MODPATH/keymod/timetable.sh
$MODPATH/keymod/path.sh
$MODPATH/keymod/magiskbackup.sh
$MODPATH/timetable/backup.sh
"

timetablefile=/data/adb/$Magisk_mod/$id/timetable/root
timetabledirtype=$( cat $timetablefile | cut -d* -f5 | cut -d/ -f4 )
timetablekeymod=$( cat $timetablefile | grep -q -w keymod | wc -l )

if test ! -e "$timetablefile" -o "$timetabledirtype" != "$Magisk_mod" -o "$timetablekeymod" -ge "1" ;then
echo "0 */6 * * *  /data/adb/$Magisk_mod/$id/timetable/backup.sh" > $MODPATH/timetable/root
fi

for file in $files ;do
	if test $Magisk_mod == lite_modules ;then
		sed -i "/^MODPATH=\".*\"/c MODPATH=/data/adb/"$Magisk_mod"/Magisk_backup " $file 2>/dev/null
	elif test $Magisk_mod == modules ;then
		sed -i "/^MODPATH=\".*\"/c MODPATH=/data/adb/"$Magisk_mod"/Magisk_backup " $file 2>/dev/null
	else
		abort "－ 出现了一些问题！终止安装！请您点击Magisk Manager上方的保存按钮，把日志发给开发者！"
	fi
done

test ! -e /data/adb/$Magisk_mod/$id && mkdir -p /data/adb/$Magisk_mod/$id
cp -rf $MODPATH/* /data/adb/$Magisk_mod/$id

