# Magisk多合一模块
# 脚本底包: 来自酷安@cjybyjk
# 编写: 酷安@皮卡丶皮卡丘

		cat $TMPDIR/mods/00_log/模块介绍.log|sed -e 's/*//g;s/`//g;s/#//g;s/ →.*//g'
		ui_print "----------------------------"
		ui_print "   [音量+]：继续安装"
		ui_print "   [音量-]：退出安装（不可选择）"
		if $VOLKEY_FUNC; then
		ui_print "  已选择[继续安装]"
		else
		ui_print "   已选择[退出安装]"
		sleep 1
		rm -rf $TMPDIR
		rm -rf $MODUIES_UPDATE/$MODID
		[ -f $MODUIES/$MODID/update ] && rm -rf $MODUIES/$MODID/update && cp -rf $MODUIES/$MODID/module.prop.bak $MODUIES/$MODID/module.prop && rm -rf $MODUIES/$MODID/module.prop.bak
		ui_print "----------------------------"
		exit 1
		fi
