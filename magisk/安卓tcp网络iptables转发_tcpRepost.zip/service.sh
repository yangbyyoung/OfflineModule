MODDIR=${0%/*}

chmod 777 /data/adb/modules/tcpRepost/service.sh

echo "
net.ipv4.ip_forward = 1
net.ipv4.ip_dynaddr = 1
" > /data/sysctl.conf

chmod 777 /data/sysctl.conf

sysctl -p /data/sysctl.conf

ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 20;
done