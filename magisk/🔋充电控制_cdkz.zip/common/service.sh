#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 35
chmod 777 /sys/class/*/* 2>/dev/null &
chmod 777 /sys/class/*/*/* 2>/dev/null &
chmod 777 /sys/module/*/*/* 2>/dev/null &
rm -f /data/system/batterystats.bin 2>/dev/null &
rm -f /data/system/batterystats-daily.xml 2>/dev/null &
rm -f /data/system/batterystats-checkin.bin 2>/dev/null &
until * ;do
echo '1' > /sys/kernel/fast_charge/failsafe 2>/dev/null &
echo '1' > /sys/kernel/fast_charge/force_fast_charge 2>/dev/null &
echo '0' > /sys/class/qcom-battery/restricted_charging 2>/dev/null &
echo '0' > /sys/module/smb_lib/parameters/skip_thermal 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/sw_jeita_enabled 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/safety_timer_enabled 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/restricted_charging 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/system_temp_level 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/input_current_limited 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/step_charging_enabled 2>/dev/null &
echo '0' > /sys/class/power_supply/battery/dynamic_fv_enabled 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/pd_allowed 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/pd_authentication 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/hvdcp_opti_allowed 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/smb_en_mode 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/smb_en_reason 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/pe_start 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/hvdcp3_type 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/adapder_cc_mode 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/typec_cc_orientation 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/quick_charge_type 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/connector_type 2>/dev/null &
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed 2>/dev/null &
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3 2>/dev/null &
echo '1' > /sys/class/power_supply/usb/boost_current 2>/dev/null &
echo '1' > /sys/module/smb5_lib/parameters/skip_thermal 2>/dev/null &
echo '0' > /sys/module/msm_thermal/core_control/enabled 2>/dev/null &
echo '0' > /sys/module/msm_thermal/vdd_restriction/enabled 2>/dev/null &
echo '0' > /sys/module/msm_thermal/parameters/enabled 2>/dev/null &
echo '0' > /sys/module/subsystem_restart/parameters/enable_ramdum 2>/dev/null &ps
echo '0' > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps 2>/dev/null &
echo '130' > /sys/class/power_supply/bms/temp_cool 2>/dev/null &
echo '550' > /sys/class/power_supply/bms/temp_warm 2>/dev/null &
echo '600' > /sys/class/power_supply/bms/temp_hot 2>/dev/null &
#echo '3500000' > /sysclass/power_supply/battery/charge_full 2>/dev/null &
#echo '3500000' > /sys/class/power_supply/battery/charge_full_design 2>/dev/null &
echo '3000' > /syskernel/fast_charge/ac_charge_level 2>/dev/null &
echo '3000' > /sys/kernel/fast_charge/usb_charge_level 2>/dev/null &
echo '3000' > /sys/kernel/fast_charge/wireless_charge_level 2>/dev/null &
echo '3000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma 2>/dev/null &ma
echo '3000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma 2>/dev/null &
echo '3000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma 2>/dev/null &
echo '3000' > /sys/module/dwc3_msm/parameters/dcp_max_current 2>/dev/null &
echo '3000' > /sys/module/dwc3_msm/parameters/hvdcp_max_current 2>/dev/null &
echo '3000' > /sys/module/phy_msm_usb/parameters/dcp_max_current 2>/dev/null &
echo '3000' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current 2>/dev/null &
echo '3000' > /sys/module/phy_msm_usb/parameters/lpm_disconnect_thresh 2>/dev/null &
echo '500000' > /sys/module/smb_lib/parameters/SDP_CURRENT_UA 2>/dev/null &
echo '1500000' > /sys/module/smb_lib/parameters/CDP_CURRENT_UA 2>/dev/null &
echo '2500000' > /sys/module/smb_lib/parameters/DCP_CURRENT_UA 2>/dev/null &
echo '3500000' > /sys/module/smb_lib/parameters/HVDCP2_CURRENT_UA 2>/dev/null &
echo '4000000' > /sys/module/smb_lib/parameters/HVDCP3_CURRENT_UA 2>/dev/null &
echo '2800000' > /sys/module/smb_lib/parameters/TYPEC_DEFAULT_CURRENT_UA 2>/dev/null &
echo '3300000' > /sys/module/smb_lib/parameters/TYPEC_MEDIUM_CURRENT_UA 2>/dev/null &
echo '3000000' > /sys/module/smb_lib/parameters/TYPEC_HIGH_CURRENT_UA 2>/dev/null &
echo '3000000' > /sys/class/power_supply/battery/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/bms/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/wireless/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/parallel/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/main/input_current_settled 2>/dev/null &
echo '3000000' > /sys/class/power_supply/dc/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/main/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/parallel/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/pc_port/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/qpnp-dc/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/battery/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/wireless/current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/battery/input_current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/hw_current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/pd_current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/ctm_current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/sdp_current_max 2>/dev/null &
echo '3000000' > /sys/class/power_supply/usb/current_max 2>/dev/null &
echo '4000000' > /sys/class/qcom-battery/restricted_current 2>/dev/null &
echo '4000000' > /sys/class/power_supply/dc/constant_charge_current 2>/dev/null &
echo '4000000' > /sys/class/power_supply/usb/constant_charge_current 2>/dev/null &
echo '4000000' > /sys/class/power_supply/main/constant_charge_current 2>/dev/null &
echo '4000000' > /sys/class/power_supply/battery/constant_charge_current 2>/dev/null &
echo '4000000' > /sys/class/power_supply/wireless/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/dc/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/usb/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/bms/constant_charge_current_max 2>/dev/null &
echo '3300000' > /sys/class/power_supply/main/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/main/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/parallel/constant_charge_current_max 2>/dev/null &
echo '4000000' > /sys/class/power_supply/battery/constant_charge_current_max 2>/dev/null &
sleep 1
done
