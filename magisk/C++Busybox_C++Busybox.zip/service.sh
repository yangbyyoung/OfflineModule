#!/bin/env sh
MODDIR=${0%/*}
export PATH="$PATH:$(magisk --path)/.magisk/busybox"

chmod -R 755 $MODDIR/
cd $MODDIR/
sleep 15
if [ ! -f APK ];then
pm install -r /data/adb/modules/C++Busybox/system/priv-app/AndroidxColorOS/Android.apk
touch APK
fi

#sleep 15
#{
#"$PWD/Setup_CPU.sh"
#}
exit 0