#!/system/bin/sh

echo "- 尝试第一种控制方法……"

find $MODPATH -type f -name "DisplayFrameSetting.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method public static isFeatureOn()Z/,/^\.end method/d' $file
cat <<"key" >>$file
.method public static isFeatureOn()Z
    .locals 1
    const/4 v0, 0x0
    return v0
.end method
key
done

echo "- 尝试第二种控制方法……"

find $MODPATH -type f -name "DisplayFrameSetting.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method private setScreenEffect(Ljava\/lang\/String;II)V/,/^\.end method/d' $file
cat <<"key" >>$file
.method private setScreenEffect(Ljava/lang/String;II)V
    .locals 1
    return-void
.end method
key
done

echo "- 完成！"
