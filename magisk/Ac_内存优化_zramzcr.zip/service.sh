#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动
chmod 777 service.ch

# Wait
sleep 2
stop perfd

# Memory
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotal=${MemTotalStr:16:8}
MemTotalPg=$((MemTotal / 4))

# zRAM
echo '75000' > /proc/sys/vm/extra_free_kbytes
swapoff /dev/block/zram0 > /dev/null 2>&1
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize
echo '1' > /sys/block/zram0/max_comp_streams
echo $((MemTotal * 1098)) > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1

sleep 35 #延迟
echo '75000' > /proc/sys/vm/extra_free_kbytes
#echo '150' > /proc/sys/vm/swappiness
