# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0

SKIPMOUNT=true
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname()
{
ui_print "
 ********************************************************
 
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 -      模块介绍↓
 - 使用C语言编写，gcc编译器编译
 - 删除温控，关闭阶梯式充电
 - 检测手机中温控文件，并且生成对应空文件
 - 原作者酷安@诺鸡鸭  由酷安@灵聚神生进行二改

 ********************************************************
 "
}

on_install()
{
thermals=`ls /system/bin/*thermal* /system/vendor/bin/*thermal* /system/*thermal*.rc /system/*/*thermal*.rc /system/*/*/*thermal*.rc /system/*/*/*/*thermal*.rc /system/*/*/*/*/*thermal*.rc /system/*/*/*/*/*/*thermal*.rc /system/*thermal*.conf /system/*/*thermal*.conf /system/*/*/*thermal*.conf /system/*/*/*/*thermal*.conf /system/*/*/*/*/*thermal*.conf /system/*/*/*/*/*/*thermal*.conf /system/*thermal*.cfg /system/*/*thermal*.cfg /system/*/*/*thermal*.cfg /system/*/*/*/*thermal*.cfg /system/*/*/*/*/*thermal*.cfg /system/*/*/*/*/*/*thermal*.cfg /system/*thermal*.txt /system/*/*thermal*.txt /system/*/*/*thermal*.txt /system/*/*/*/*thermal*.txt /system/*/*/*/*/*thermal*.txt /system/*/*/*/*/*/*thermal*.txt /system/*thermal*.so /system/*/*thermal*.so /system/*/*/*thermal*.so /system/*/*/*/*thermal*.so /system/*/*/*/*/*thermal*.so /system/*/*/*/*/*/*thermal*.so`
for thermal in $thermals
do
	[[ ! -d $MODPATH/${thermal%/*} ]] && mkdir -p $MODPATH/${thermal%/*}
	touch $MODPATH/$thermal
done
[[ -f /data/current ]] && rm -rf /data/current
chattr -i /data/vendor/thermal
chattr -i /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
chattr +i /data/vendor/thermal/config
chattr +i /data/vendor/thermal
rm -rf /data/adb/modules_update/NoCloudThermal/*.conf
rm -rf /data/adb/modules_update/NoCloudThermal//system/*hardware* 
rm -rf /data/adb/modules_update/NoCloudThermal/system/*/*hardware* 
rm -rf /data/adb/modules_update/NoCloudThermal/system/*/*/*hardware* 
rm -rf /data/adb/modules_update/NoCloudThermal/system/*/*/*/*hardware* 
rm -rf /data/adb/modules_update/NoCloudThermal/system/*/*/*/*/*hardware* 
rm -rf /data/adb/modules_update/NoCloudThermal/system/*/*/*/*/*/*hardware*
}


