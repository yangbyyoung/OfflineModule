MODDIR=${0%/*}
MODANIMDIR="$MODDIR/system/vendor/overlay/BsCharge"
# rename $MODANIMDIR/BsCh
# cp -pf $MO
mv -f $MODANIMDIR/BsCharge0.apk $MODANIMDIR/BsCharge3
mv -f $MODANIMDIR/BsCharge1 $MODANIMDIR/BsCharge0.apk
mv -f $MODANIMDIR/BsCharge2 $MODANIMDIR/BsCharge1
mv -f $MODANIMDIR/BsCharge3 $MODANIMDIR/BsCharge2
chmod 0644 $MODANIMDIR/*
chown root:root $MODANIMDIR/*
chcon "u:object_r:vendor_overlay_file:s0" $MODANIMDIR/BsCharge0.apk
