#!/system/bin/sh
# 请不要假设你的模块位于何处
# 如果你需要知道该脚本的位置, 或是该模块的位置, 请始终使用 $MODDIR 变量获取
# 这样做可以保证将来如果 Magisk 更改了挂载点, 你的模块仍然可以正常工作
MODDIR=${0%/*}

# 该脚本会在 late_start 服务模式下执行
crond -c /data/crond1