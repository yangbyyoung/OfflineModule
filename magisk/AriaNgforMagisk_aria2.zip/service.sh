#!/system/bin/sh
[ "$KSU" != "true" ] && busybox=/data/adb/magisk/busybox || busybox=/data/adb/ksu/bin/busybox
mkdir /dev/busybox && $busybox --install -s /dev/busybox
export PATH=$PATH:/dev/busybox

#程序路径
aria2="${0%/*}/core/bin/aria2c"
lighttpd="${0%/*}/core/bin/lighttpd"
aria2conf="${0%/*}/core/etc/aria2.conf"
lighttpdconf="${0%/*}/core/etc/lighttpd.conf"

#终止程序
pkill aria2 lighttpd

#更新bt-tracker
for i in $(seq 1 10); do
bt=`wget --no-check-certificate -qO- https://gitea.com/XIU2/TrackersListCollection/raw/branch/master/all.txt | awk NF | tr '\n' ',' | sed 's/,$//'`
if [ ! -z "$bt" ]; then
sed -i '/bt-tracker=/d' $aria2conf
echo "bt-tracker=$bt" >> $aria2conf
break
fi
done

#启动程序
$lighttpd -f $lighttpdconf
$aria2 --conf-path=$aria2conf -D
