MODDIR=${0%/*}
userdata=`cat "$MODDIR/datafile/userdata_num"`
if [ `dumpsys deviceidle | grep mScreenOn` == "mScreenOn=true" ] ; then
	#init
	function log_out(){
  		count_trim=`cat "$MODDIR/datafile/count_trim"`
  		count_gc=`cat "$MODDIR/datafile/count_gc"`
  		if [ "$trimed" == "1" ] ; then
  			echo " # " >> $MODDIR/datafile/TRIM_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_TRIM.log > $MODDIR/datafile/TRIM_tmpO.log
			cat $MODDIR/datafile/TRIM_tmpN.log $MODDIR/datafile/TRIM_tmpO.log >/sdcard/Android/fsopt/FSopt_TRIM.log
			sed -i '101,109d' /sdcard/Android/fsopt/FSopt_TRIM.log
			count_trim=$(($count_trim + 1 ))
		fi
		if [ "$gced" == "1" ] ; then
			echo " # " >> $MODDIR/datafile/GC_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_GC.log > $MODDIR/datafile/GC_tmpO.log
			cat $MODDIR/datafile/GC_tmpN.log $MODDIR/datafile/GC_tmpO.log >/sdcard/Android/fsopt/FSopt_GC.log
			sed -i '97,109d' /sdcard/Android/fsopt/FSopt_GC.log
			count_gc=$(($count_gc + 1 ))
		fi
		echo "$count_trim" > $MODDIR/datafile/count_trim
		echo "$count_gc" > $MODDIR/datafile/count_gc
	}
	
	function cpud(){
		out=$(echo "scale=$4; $1*$2/$3" | bc)
		echo $out
		return $?
	}
	
	function tf_gc(){
		if [ "$2" -ge "$3" ] ; then
			out=$(cpud $2 $5 $6 2)
			if [ "$2" -ge "$4" ] ; then
				out=$(cpud $2 $5 $7 2)
				echo " --- $1: $out GB " >> $MODDIR/datafile/GC_tmpN.log
			else
				echo " --- $1: $out MB " >> $MODDIR/datafile/GC_tmpN.log
			fi
		else
			out=$(cpud $2 $5 $8 2)
			echo " --- $1: $out KB " >> $MODDIR/datafile/GC_tmpN.log
		fi
	}

	function gc_main(){
		echo lock_me >/sys/power/wake_lock
		if [ -e /d/f2fs/status ] ; then
			mv_block_init=$(cat /d/f2fs/status | grep -A130 "$userdata" | grep -w "Try to move" | awk '{print $4}')
		else
			mv_block_init=$(cat /proc/fs/f2fs/status | grep -A130 "$userdata" | grep -w "Try to move" | awk '{print $4}')
		fi
		initunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
		gc_calls=0
		gc_call=114514
		until [ "$gc_call" -le "10000" ] ; do
			gc_call=`$MODDIR/bin/f2fs-fggc /data`
			gc_call=`echo $gc_call | tr -cd "[0-9]"`
			gc_calls=$(($gc_calls + $gc_call))
			sleep 1
		done
		echo lock_me >/sys/power/wake_unlock
		if [ -e /d/f2fs/status ] ; then
			mv_block_ed=$(cat /d/f2fs/status | grep -A130 "$userdata" | grep -w "Try to move" | awk '{print $4}')
		else
			mv_block_ed=$(cat /proc/fs/f2fs/status | grep -A130 "$userdata" | grep -w "Try to move" | awk '{print $4}')
		fi
		free_space=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		endunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
		mv_blocks=$(($mv_block_ed - $mv_block_init))
		unusegc=$(($initunuse - $endunuse))
		if [ $unusegc -lt "0" ];then
		    unusegc=0
		fi
	}

	function d_rate(){
		if [ -e /d/f2fs/status ] ; then
			drate=$(cat /d/f2fs/status | grep -A130 "$userdata" | grep -w BDF | awk '{print $2}')
		else
			drate=$(cat /proc/fs/f2fs/status | grep -A130 "$userdata" | grep -w BDF | awk '{print $2}')
		fi
		drate=`echo $drate | tr -cd "[0-9]"`
		drate=$((100 - $drate))
	}
	
	function fstrim_c(){
		rundata=`date "+%Y-%m-%d %H:%M:%S"`
		echo " # " > $MODDIR/datafile/TRIM_tmpN.log
		echo " --- $rundata " >> $MODDIR/datafile/TRIM_tmpN.log
		trim_fail=`cat "$MODDIR/datafile/trim_fail"`
		$MODDIR/bin/busybox fstrim -v /data > $MODDIR/datafile/trim_inf
		trim=`cat "$MODDIR/datafile/trim_inf" | tr -cd "[0-9]"`
		if [ `cat "$MODDIR/datafile/trim_disable"` = "Y" ] ;then
			if [ "$trim" != "0" -a "$trim" != "" -a "$trim" != "NULL" ] ; then
				echo "N" > $MODDIR/datafile/trim_disable
				echo "Lock" > $MODDIR/datafile/SleepLocker
			fi
		else
			if [ "$trim" == "0" -o "$trim" == "" -o "$trim" == "NULL" ] ; then
				echo " --- DATA: 无需TRIM " >> $MODDIR/datafile/TRIM_tmpN.log
				trim_fail=$(($trim_fail + 1 ))
				echo "$trim_fail" > $MODDIR/datafile/trim_fail
			else
				trimed=1
				echo 0 > $MODDIR/datafile/trim_fail
				if [ "$trim" -ge "1000000" ] ; then
					out=$(cpud $trim 1 1000000 2)
					if [ "$trim" -ge "1000000000" ] ; then
						out=$(cpud $trim 1 1000000000 2)
						echo " --- DATA: $out GB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
					else
						echo " --- DATA: $out MB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
					fi
				else
					out=$(cpud $trim 1 1000 2)
					echo " --- DATA: $out KB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
				fi
			fi
		fi
		echo "NULL" > $MODDIR/datafile/trim_inf
		if [ "$trimed" == "1" ] ; then
			echo "Lock" > $MODDIR/datafile/SleepLocker
		fi
	}

	#Main
	get_userdata
	d_rate
	gced=0
	trimed=0
	if [ "$drate" -gt "10" ] ; then
		if [ `cat "/sys/class/power_supply/battery/status"` = "Charging" -o `cat "/sys/class/power_supply/battery/capacity"` -ge "30" ] ;then
			fstrim_c
			rundata=`date "+%Y-%m-%d %H:%M:%S"`
			echo " # " > $MODDIR/datafile/GC_tmpN.log
			echo " --- $rundata " >> $MODDIR/datafile/GC_tmpN.log
			gc_main
			echo " --- 前台GC_Calls: $gc_calls "  >> $MODDIR/datafile/GC_tmpN.log
			tf_gc "GC迁移数据量" $mv_blocks 245 244141 4096  1000000 1000000000 1000
			if [ `cat "$MODDIR/datafile/gc_log"` = "C" ] ; then
				tf_gc "已回收空间" $unusegc 245 244141 4096  1000000 1000000000 1000
				tf_gc "待回收空间" $endunuse 245 244141 4096 1000000 1000000000 1000
				tf_gc "空闲块空间" $free_space 1 476 2097152 1000000 1000000000 1
			fi
			gced=1
			d_rate
			if [ "$drate" -ge "5" ] ; then
				echo "UnLock" > $MODDIR/datafile/SleepLocker
			fi
		else
			fstrim_c
		fi
	else
		fstrim_c
	fi
	if [ "$trim_fail" -ge "10" ] ; then
		echo "Y" > $MODDIR/datafile/trim_disable
	fi
	log_out
fi