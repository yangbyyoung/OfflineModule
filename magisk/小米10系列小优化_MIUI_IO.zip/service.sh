#!/system/bin/sh
MODDIR=${0%/*}
function bbsh (){
sh $1 2>/dev/null
}
#执行优化
#IO调整
bbsh /data/adb/modules/MIUI_IO/mod/IO.sh
#调试禁用
bbsh /data/adb/modules/MIUI_IO/mod/debug_disable.sh
#清理WLAN日志
bbsh /data/adb/modules/MIUI_IO/mod/log.sh
#清理电池白名单(保留QQ和微信)
bbsh /data/adb/modules/MIUI_IO/mod/white.sh
#禁用ARN错误
bbsh /data/adb/modules/MIUI_IO/mod/error.sh
#SWAP调整
bbsh /data/adb/modules/MIUI_IO/mod/swap.sh
#特色功能
bbsh /data/adb/modules/MIUI_IO/mod/features.sh