SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "爽歪歪"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'module.prop.bak' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/bin/thermalserviced' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/init/init.thermald.rc' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/init/thermalservice.rc' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/perf/wlc_model.tflite' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/lib64/libthermalservice.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/bin/mi_thermald' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/bin/thermal-engine' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/bin/thermal_factory' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/init/init.mi_thermald.rc' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/init/init_thermal-engine.rc' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/perf/thermalboost.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/powerhint.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-4k.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-8k.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-camera.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-chg-only.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-class0.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-engine.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-map.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-mgame.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-navigation.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-nolimits.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-normal.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-notlimits.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-phone.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-tgame.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-video.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal-youtube.config' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermal.current.ini' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermald-devices.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/hw/thermal.kona.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/hw/thermal.kona.so' -d $MODPATH >&2
 ui_print "======================================"
 ui_print " "
 ui_print "   【不是阶梯式充电你有啥实力啊，直接给我坐下】"
 ui_print " "
 ui_print "======================================"
 ui_print "    😡关闭阶梯式充电😡"
 ui_print " "
 ui_print " "

 ui_print "-  Extracting Zip file解压文件。。。"
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print "-  Overriding config覆盖配置中。。。"
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}