# 安装时显示的模块名称
mod_name="[系统精简]"
# 功能来源
ORIGIN="@Mimiao_al"
# 模块介绍
mod_install_desc="\n  ◆ 精简无用的系统应用"
# 安装时显示的提示
mod_install_info="是否安装？"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc=""
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device=".{0,}" #全部
# 支持的系统版本，持正则表达式
mod_require_version="V12|V125" #全部
# 支持的设备版本，持正则表达式
mod_require_release=".{0,}" #全部



# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
#	mkdir -p $MODPATH/system/
#	cp -r $MOD_FILES_DIR/* $MODPATH/system/
	INSTALLED_FUNC="$mod_name $INSTALLED_FUNC"

		# 附加值到 system.prop
#		add_sysprop ""
		# 从文件附加值到 system.prop
#		add_sysprop_file $MOD_FILES_DIR/system.prop
		# 添加service.sh
#		add_service_sh $MOD_FILES_DIR/service.sh
		# 添加post-fs-data.sh
#		add_postfsdata_sh $MOD_FILES_DIR/post-fs-data.sh

#精简的系统应用
REPLACE="
/system/priv-app/BuiltInPrintService
/system/product/app/PhotoTable
/system/app/BasicDreams
/system/app/ModemTestBox
/system/app/Cit
/system/app/talkback
/system/app/AntHalService
/system/product/priv-app/EmergencyInfo
/system/priv-app/MiRcs
/system/app/mi_connect_service
/system/app/WMService
/system/app/WAPPushManager
/system/app/Traceur
/system/app/MiuiBugReport
/system/priv-app/MiService
/system/app/MiuiDaemon
/system/app/Userguide
/system/priv-app/UserDictionaryProvider
/system/priv-app/BlockedNumberProvider
/system/app/Stk
/system/app/SimAppDialog
/system/app/SimContact
/system/app/CatchLog
/system/app/AnalyticsCore
/system/app/MSA
/system/priv-app/NewHome
/system/app/PrintSpooler
/system/app/BuiltInPrintService
/system/app/goodix_sz
/system/product/app/aiasst_service
/system/priv-app/YellowPage
/system/app/HybridPlatform
"

    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
		return 0
}
