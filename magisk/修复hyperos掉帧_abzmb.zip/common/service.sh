#!/system/bin/sh
MODDIR=${0%/*}
sleep 10
service call SurfaceFlinger 1008 i32 1
resetprop ro.crypto.state encrypted
 
