#!/system/bin/sh
# by Han | 情非得已c
# 请尽量使用$MODDIR获取本模块路径，即使Magisk将来更改挂载路径也依然有效
# 编写你的shell脚本，post-fs-data.sh是开机前阻塞运行的，执行完本脚本才启动开机流程和挂载模块，请不要写运行时间太久的代码，否则后果自负
MODDIR=${0%/*}
M=$(free -m|grep "Mem"|awk '{print $2}' ) 
echo $Z
sleep 10
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo $(echo $M/2 |bc)M> /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0