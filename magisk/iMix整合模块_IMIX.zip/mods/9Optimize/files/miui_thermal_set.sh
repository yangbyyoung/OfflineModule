export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH
am broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
services=`settings get secure enabled_accessibility_services | grep -v 'null'`
service='com.qualcomm.qti.perfdump/com.qualcomm.qti.perfdump.AutoDetectService'
check=$(echo $services | grep $service | wc -l)
if test "$check" -lt "1" ;then
	settings put secure accessibility_enabled 1
	settings put secure enabled_accessibility_services "$service:$services"
fi