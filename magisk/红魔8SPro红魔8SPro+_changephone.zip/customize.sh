SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false
Market_Name=`getprop ro.product.marketname`
Device=`getprop ro.product.device`
Model=`getprop ro.product.model`
Version=`getprop ro.build.version.incremental`
Android=`getprop ro.build.version.release`
CPU_ABI=`getprop ro.product.cpu.abi`
CommonPath=$MODPATH/common
print_modname() {
  ui_print "*******************************"
  ui_print " 机型修改：$MODNAME "
  ui_print " 模块作者：Coolapk @澪洛依 "
  ui_print 
  ui_print " 相关信息："
  ui_print " 机型：$Market_Name"
  ui_print " 设备代号：$Device"
  ui_print " 认证型号：$Model"
  ui_print " 安卓版本：Android $Android"
  ui_print " 系统版本：$Version"
  ui_print " CPU架构：$CPU_ABI"
  ui_print "*******************************"
}

print_modname

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
 
}

ui_print "- 正在进入酷安（点个关注吧qwq）"
mv  ${CommonPath}/*  $MODPATH
rm  -rf ${CommonPath}

sleep 1
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolmarket://u/9960587' >/dev/null 2>&1
  fi