MODDIR=${0%/*}
wait_until_login() {
while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 1
done
local test_file="/sdcard/Android/.PERMISSION_TEST"
true >"$test_file"
while [ ! -f "$test_file" ]; do
true >"$test_file"
sleep 1
done
rm "$test_file"
}
wait_until_login
#一定要等待系统启动完成后再执行操作
#否则可能卡机进不去系统！
info_path="/sdcard/Android/EasyClean"
path_forbid_clean=$info_path/files/forbid
scriptfile=EasyClean1.0.beta2
chmod 755 $MODDIR/$scriptfile
chmod 755 $MODDIR/Start.sh
#设置允许执行清理
echo 0 >$path_forbid_clean
#后台启动主进程
/system/bin/sh $MODDIR/Start.sh