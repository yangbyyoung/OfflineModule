######################
#
# Magisk模块安装脚本
# 编写:酷安@Bugme7
#
######################

# 调试
# ui_print() {
# echo "$1"
# }

# 调试标记
DUBUG_FLAG=false

SKIPMOUNT=false

# 是否加载 system.prop
PROPFILE=false

# 是否执行 post-fs-data 脚本
POSTFSDATA=false

# 是否执行 service 脚本
LATESTARTSERVICE=false

REPLACE=""

# 获取机型
var_device="`grep_prop ro.product.*device`"

# 获取Android 版本
var_version="`grep_prop ro.build.version.release`"

# 获取模块版本
module_version="`grep_prop version $TMPDIR/module.prop`"

# 获取模块名称
module_name="`grep_prop name $TMPDIR/module.prop`"

# 获取模块id
module_id="`grep_prop id $TMPDIR/module.prop`"


run_exit() {
  rm -rf /data/adb/modules/$module_id/
  rm -rf /data/adb/modules_update/$module_id/
  rm -rf /data/system/package_cache/*
  ui_print "- 已退出安装"
  exit 0
}

# 介绍等
print_modname() {
  ui_print "-------------------------------------"
  ui_print "- $module_name "
  ui_print "- 作者: 酷安@Lemon3"
  ui_print "- 版本: $module_version"
  ui_print "-------------------------------------"
  ui_print "- 机型: $var_device"
  ui_print "- Android 版本: $var_version"
}

# 安装脚本
on_install() {

  require_version="9|10"

  # 检测Android 版本是否为10
  if [ "`echo $var_version | egrep $require_version`" = "" ]; then
    ui_print "- 您的Android 版本不支持此模块"
    run_exit
  fi

  [ -f /system/app/VoiceTrigger.apk ]
  if [ $? -eq "0" ]; then
    ui_print "- 您的机型无法支持语音找手机"
  fi

  ui_print "- 正在安装..."

  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

}

# 设置权限
set_permissions() {
  # 普通权限
  set_perm_recursive $MODPATH 0 0 0755 0644

}
