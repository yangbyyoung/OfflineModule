
if [ "$API" -lt 30 ]; then
     abort " 安卓版本低于11.0 安装失败!"
fi
if [ -f /odm/firmware/28_*.bin ] || [ -f /odm/firmware/38_*.bin ]; then
A="odm"
elif [ -f /vendor/firmware/28_*.bin ] || [ -f /vendor/firmware/38_*.bin ]; then
A="vendor"
fi
M="$MODPATH"
C="$A/firmware"
D="$M/system/$A/firmware"
if [ -f /$C/28_*.bin ] || [ -f /$C/38_*.bin ]; then
ui_print "     <<请按音量键选择版本>>"
ui_print " 音量加+:映射版   音量减—: 独立版"
ui_print ""
key_click=""
while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
done
case "$key_click" in
        "KEY_VOLUMEUP")
		 ui_print "———————————安装映射版———————————"
		 cp -rf $M/prop/* $M
		 ;;
        *)
	   	 ui_print "———————————安装独立版———————————"
esac
MODNAME="`grep_prop name $M/module.prop`"
MODAuthor="`grep_prop author $TMPDIR/module.prop`"
MODVersion="`grep_prop version $TMPDIR/module.prop`"
ui_print " 模块名: $MODNAME"
ui_print " 作者: $MODAuthor"
ui_print " 版本: $MODVersion"
ui_print "———————————————————————————————"
rm -rf $MODPATH/prop
mv -f $M/system/vendor $M/system/$A
File="/$C/90_*.bin"
ui_print " 任务清理:$(basename ${File}) 修改注意大小写"
cp -rf $D/93_*.bin $D/$(basename ${File})
File="/$C/43_*.bin"
mv -f $D/43_*.bin $D/$(basename ${File})
File="/$C/76_*.bin"
mv -f $D/76_*.bin $D/$(basename ${File})
File="/$C/85_*.bin"
mv -f $D/85_*.bin $D/$(basename ${File})
File="/$C/86_*.bin"
mv -f $D/86_*.bin $D/$(basename ${File})
File="/$C/87_*.bin"
mv -f $D/87_*.bin $D/$(basename ${File})
File="/$C/92_*.bin"
mv -f $D/92_*.bin $D/$(basename ${File})
File="/$C/93_*.bin"
mv -f $D/93_*.bin $D/$(basename ${File})
File="/$C/162_*.bin"
mv -f $D/162_*.bin $D/$(basename ${File})
File="/$C/163_*.bin"
mv -f $D/163_*.bin $D/$(basename ${File})
File="/$C/169_*.bin"
mv -f $D/169_*.bin $D/$(basename ${File})
File="/$C/171_*.bin"
mv -f $D/171_*.bin $D/$(basename ${File})
   if [ -f /$C/28_*_P_RTP.bin ] || [ -f /$C/38_*_P_RTP.bin ]; then
	 ui_print " 马达驱动目录: $C/ [**_P_RTP.bin]类型"
     if [ "$C" = "odm/firmware" ]; then
         ui_print " 请使用Delta面具安装，否则振动软绵/异常!"
         sleep 1
     fi
  	 ui_print ""
   else
	 ui_print " 马达驱动目录: $C/ [**_RTP.bin]类型"
	 ui_print ""
	 File="/$C/MiRemix_*.bin"
     cp -rf $D/43_*.bin $D/$(basename ${File})
	 File="/$C/Unlock_Failed_*.bin"
     cp -rf $D/76_*.bin $D/$(basename ${File})
	 File="/$C/screenshot_*.bin"
	 cp -rf $D/85_*.bin $D/$(basename ${File})
	 File="/$C/lockscreen_camera_*.bin"
	 cp -rf $D/86_*.bin $D/$(basename ${File})
	 File="/$C/launcher_edit_*.bin"
	 cp -rf $D/87_*.bin $D/$(basename ${File})
	 File="/$C/task_cleanall_*.bin"
	 cp -rf $D/90_*.bin $D/$(basename ${File})
	 File="/$C/notification_remove_*.bin"
	 cp -rf $D/92_*.bin $D/$(basename ${File})
	 File="/$C/notification_cleanall_*.bin"
     cp -rf $D/93_*.bin $D/$(basename ${File})
	 File="/$C/Gesture_Back_Pull_*.bin"
     cp -rf $D/162_*.bin $D/$(basename ${File})
	 File="/$C/Gesture_Back_Release_*.bin"
     cp -rf $D/163_*.bin $D/$(basename ${File})
	 File="/$C/lockdown_*.bin"
     cp -rf $D/169_*.bin $D/$(basename ${File})
	 File="/$C/todo_alldone_*.bin"
     cp -rf $D/171_*.bin $D/$(basename ${File})
   fi
   if [ -f /$C/aw8697_haptic.bin ] && [ -f $D/aw8697*.bin ]; then
     ui_print " aw8697_haptic文件匹配.通知振动增强。"
	 ui_print " 如果不需要通知振动增强 ↓请到以下目录↓删除此文件"
   else
     rm -rf $MODPATH/system/*/firmware/aw8697*.bin
   fi
ui_print " 模块修改/卸载目录: data/adb/modules/$MODID"
ui_print " 模块并非万能,如果振动异常,说明不兼容,请删除本模块"
else
ui_print " 安装失败:关键文件28(38)_*.bin缺失或重复!"
ui_print " 请删除所有涉及振动的模块-重启,再安装。"
ui_print " 模块仅适配小米/红米MIUI-0809马达机型."
ui_print " 若是官改/移植包,且改过振动,可能不兼容。"
ui_print " 其他品牌刷MIUI移植包,由于底层不同,兼容性未知"
ui_print " 不支持其他国产UI/类原生。"
ui_print " —————————————————————"
ui_print " 如果问题依旧,查看vendor(odm)/firmware目录:"
ui_print " 28(38)_*.bin文件是否缺失/重复。"
ui_print " 找个小文件改成28(38)_*.bin补上,或删除重复,再安装"
abort " 水平有限,不能提供任何解答与指导.谢谢!"
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644
