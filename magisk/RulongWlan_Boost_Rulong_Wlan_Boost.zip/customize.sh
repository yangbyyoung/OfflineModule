# Check Enable
SKIPMOUNT=true

# system.prop
PROPFILE=false

# post-fs-data script
POSTFSDATA=false

# service script
LATESTARTSERVICE=true

# 获取系统信息
var_sdk="`grep_prop ro.*version.sdk`"
var_name="`grep_prop ro.*version.name`"
var_brand="`grep_prop ro.product.*brand`"
var_model="`grep_prop ro.product.*model`"
var_device="`grep_prop ro.product.*device`"
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.*version.incremental`"
var_manufacturer="`grep_prop ro.product.*manufacturer`"
ui_print "***************"
ui_print "设备型号：$var_model"
ui_print "系统版本：$var_version"
ui_print "设备版本：$var_release"
ui_print "请自行查看Rulong/Wlan配置文件位置.log"
ui_print "(如果位置不对，请自行修改模块wlan配置位置)"
ui_print "***************"
ui_print "主要邮箱: OLX_Team@88.com"
echo " "
echo "210925"
echo "如龙流控表: 提升上传速度"
echo "该版本开始千万不要再未更新并重启模块的前提下执行service.sh"
echo "否则你的数据将被清除"
echo " "
echo "210922"
echo "如龙网络加速大更新"
echo "合入如龙流控表：网速过快警告"
echo "流控表会自动判断手机配置给出最优方案"
echo " "
ui_print "210913"
ui_print "第一个版本"
# 释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH/system/xbin/busybox  0  2000  0755
  set_perm_recursive  $MODPATH/system/xbin/olx.wlan  0  2000  0755
}
