dataDir="/data/adb/cmfm"

RmData() {
    rm -rf ${dataDir}
}

RmData