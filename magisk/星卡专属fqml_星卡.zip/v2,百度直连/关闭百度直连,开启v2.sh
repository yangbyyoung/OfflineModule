${0%/*}/*/ZJL -c -d
cd ${0%/*}
chmod -R 777 .
. ./config.ini
./核心/"$exec".bin start
./核心/"sohigh".bin start