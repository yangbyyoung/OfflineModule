#!/system/bin/sh
disable_zram()
{
	for ZRAM_DEV in `blkid -o device | grep "zram"`; do
		echo "$(echo ${ZRAM_DEV##*/} | grep -o "[0-9]*$")" > /sys/class/zram-control/hot_remove
		swapoff "$ZRAM_DEV"
		echo "1" > /sys/block/${ZRAM_DEV##*/}/reset
		echo "0" > /sys/block/${ZRAM_DEV##*/}/disksize
	done
}
sleep 15 && disable_zram
[ -e /sys/kernel/mi_reclaim/enable ] && echo "0" > /sys/kernel/mi_reclaim/enable
echo "0" > /proc/sys/vm/swappiness || sysctl -w vm.swappiness=0
[ "$(settings get global zram_enabled)" == 1 ] && settings put global zram_enabled 0
