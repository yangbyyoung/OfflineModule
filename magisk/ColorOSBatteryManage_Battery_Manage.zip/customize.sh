SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 官宣粉丝交流群↴
 - 群号938499734
 - 切勿手动执行模块如果执行后果自负
 ****************************
 "
set_perm_recursive $MODPATH 0 0 0755 0777

#官宣粉丝交流群：938499734，搞机！外挂！文案！