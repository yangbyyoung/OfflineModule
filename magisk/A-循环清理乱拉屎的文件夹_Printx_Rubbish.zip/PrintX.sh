#!//bin/env sh
Module_Path="/data/adb/modules"

KernelSu() {
	[ -f "/data/adb/ksud" ] && {
		S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')
		[ "$S" = "v0.3" ] && Module_Path="/data/adb/ksu/modules"
	}

}
KernelSu
# 设置Printx_thermal路径
Rubbish_Path="$Module_Path/Printx_Rubbish"

PrintX_conf="/data/media/0/Android/PrintX/清理垃圾/配置文件.conf"
[ ! -f $PrintX_conf ] && {
    mkdir -p "/data/media/0/Android/PrintX/清理垃圾"
    echo "####################
####################
####################
# Author:作者:& 酷安@只喝橘子味汽水
# WeChat: Suonian-XingHe       
# QQ: 699459180
####################
####################
####################
#以下选项.开启填入：true，关闭填入：false

# 是否启用空文件夹扫描检查 
# 默认开启
PrintX_A=false

# 检查的目录
# 默认为/data/media/0
PrintX_B=/data/media/0

# 是否检查子目录
# 默认关闭
PrintX_C=false
# 开启后将则将递归检查该目录下的所有子目录
# 关闭后则只检查该目录

# 是否启用黑名单检查
# 默认开启
PrintX_Blacklist_check=true
" > $PrintX_conf
    exit 255
} || source $PrintX_conf

PrintX_Times="/data/media/0/Android/PrintX/清理垃圾/Times"
if [ -f "$PrintX_Times" ]; then
    source "$PrintX_Times"
    else
    touch "$PrintX_Times"
fi

# 初始化计数器
DIR=${DIR:-0}
FILE=${FILE:-0}

PrintX_D () {
    for dir in "$1"/*; do
        [ -d "$dir" ] && {
            [ "$(command ls -A "$dir")" ] || {
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除空文件夹: $dir" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
                command rmdir "$dir"
                let DIR++
            }
            [ "${PrintX_C}" = true ] && PrintX_D "$dir"
        }
    done
}

PrintX_Blacklist () {
    [ ! -f /data/media/0/Android/PrintX/清理垃圾/黑名单.conf ] && {
        mkdir -p /data/media/0/Android/PrintX/清理垃圾
        echo "
#yc调度
/data/media/0/yc/uperf/log_uperf.txt.bak
/data/media/0/Android/log_uperf.txt.bak
/data/media/0/Android/panel_uperf.txt.bak

#★系统专清★——————₍˄·͈༝·͈˄*₎◞ ̑̑
#MIUI专清
#ColorOS专清
/data/media/0/ColorOS/

#DuoQin专清
#保护/data/media/0/MIUI/
/data/media/0/switchota/
/data/media/0/QinWT/
/data/media/0/googleota/
/data/media/0/Notifications/

#【系统应用专区】——————₍˄·͈༝·͈˄*₎◞ ̑̑
#【通用应用】
#Android系统
/data/user/0/android/code_cache/
/data/user/0/android/cache/
#ColorOS
#系统桌面专清
/data/user/0/com.android.launcher/cache/
/data/user/0/com.android.launcher/code_cache/
#系统界面专清
/data/user/0/com.android.systemui/cache/
/data/user/0/com.android.systemui/code_cache/
#Android系统
/data/user/0/oplus/cache/
/data/user/0/oplus/code_cache/
#软件商店
/data/user/0/com.heytap.market/app_49448_com.heytap.market/
/data/user/0/com.heytap.market/app_files_tbl_64/
/data/user/0/com.heytap.market/app_hera_odex/
/data/user/0/com.heytap.market/app_plugin/
/data/user/0/com.heytap.market/app_sslcache/
/data/user/0/com.heytap.market/app_textures/
/data/user/0/com.heytap.market/app_track_sslcache/
/data/user/0/com.heytap.market/app_update_rhea_plugin_p2p_plugin_001/
/data/user/0/com.heytap.market/app_update_rhea_plugin_xy_plugin_sdk/
/data/user/0/com.heytap.market/cache/
/data/user/0/com.heytap.market/code_cache/
#MIUI
#游戏中心专清
#保护/data/media/0/Xiaomi/
/data/media/0/migamecenter/
#蓝牙
#保护/data/media/0/com.xiaomi.bluetooth/
#小米商城专清
/data/media/0/mishop/
/data/user/0/com.xiaomi.shop/.cesium/
/data/user/0/com.xiaomi.shop/app_/
/data/user/0/com.xiaomi.shop/app_bugly/
/data/user/0/com.xiaomi.shop/app_patch_plugin/
/data/user/0/com.xiaomi.shop/app_pluginOutDex/
/data/user/0/com.xiaomi.shop/app_textures/
/data/user/0/com.xiaomi.shop/code_cache/
#★第三方应用专区★——————₍˄·͈༝·͈˄*₎◞ ̑̑
#【通用】
#浏览器产生的临时文件和缓存目录
/data/media/0/browser/
#软件运行产生的临时文件夹
/data/media/0/Catfish/
#部分应用毒瘤unity引擎
/sdcard/unity_jail
#【应用日志文件专清】
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/log/
/data/media/0/Android/data/com.coolapk.market/files/log/
/data/media/0/tencent/tmp/vodPcdnMSdkPeerId.log
/data/media/0/Android/data/com.quark.browser/files/tnetlogs/inapp_20230503.log
/data/media/0/Android/data/com.tencent.mobileqq/files/tencent/msflogs/com/tencent/mobileqq/
#【玩机应用专区】
#MT管理器
#保护/data/media/0/MT2/
#EX内核管理器专清
/data/media/0/Android/data/flar2.exkernelmanager/cache/
#SD Maid专清
/data/media/0/Android/data/eu.thedarken.sdm/cache/
#爱玩机工具箱专清
/data/media/0/Android/data/com.byyoung.setting/cache/
#Sunshine.ToolBox专清
/data/user/0/com.Sunshine.ToolBox/code_cache/
/data/user/0/com.Sunshine.ToolBox/cache/
#【游戏专区】
#碧蓝航线专清（哔哩哔哩服）
/data/user/0/com.bilibili.azurlane/app_cobbler_cache1ddaf36d551afc859800b0009a6cef88/
/data/user/0/com.bilibili.azurlane/app_cobbler_cachec828aff264d49a2c51c71a0a2de3ef28/
/data/user/0/com.bilibili.azurlane/app_cobbler_cached1898625068207895147033b32aaaf1d/
/data/user/0/com.bilibili.azurlane/app_cobbler_cacheed379bd4db0aad6e79d2927f0334ef2d/
/data/user/0/com.bilibili.azurlane/app_cobbler_cacheee77806d438a9d187f77c5d886cb25bb/
/data/user/0/com.bilibili.azurlane/app_pp/
/data/user/0/com.bilibili.azurlane/app_textures/
/data/user/0/com.bilibili.azurlane/code_cache/
#原神专清（哔哩哔哩服）
/data/user/0/com.miHoYo.ys.bilibili/app_bugly/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cache0dd00f1af7d102a16de6cd1ab02d81cd/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cache8a0632781cbed4f26bacc5ec6f579173/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cache66e8c803428371e9212cab052fe39518/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cache27774749b688c3fe192c5fc704d3284d/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cacheb262041bdce0d77c696bde800f32a061/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cachecde3d09b2e1a9226d8a6c83f9b18d191/
/data/user/0/com.miHoYo.ys.bilibili/app_cobbler_cachee6213920d34c7dddfb5e975919cf5afa/
/data/user/0/com.miHoYo.ys.bilibili/app_pp/
/data/user/0/com.miHoYo.ys.bilibili/app_textures/
/data/user/0/com.miHoYo.ys.bilibili/code_cache/
#崩坏三专清（哔哩哔哩服）
/data/user/0/com.miHoYo.bh3.bilibili/app_bugly/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cache0dd00f1af7d102a16de6cd1ab02d81cd/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cache8a0632781cbed4f26bacc5ec6f579173/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cache66e8c803428371e9212cab052fe39518/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cache27774749b688c3fe192c5fc704d3284d/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cacheb262041bdce0d77c696bde800f32a061/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cachecde3d09b2e1a9226d8a6c83f9b18d191/
/data/user/0/com.miHoYo.bh3.bilibili/app_cobbler_cachee6213920d34c7dddfb5e975919cf5afa/
/data/user/0/com.miHoYo.bh3.bilibili/app_pp/
/data/user/0/com.miHoYo.bh3.bilibili/app_textures/
/data/user/0/com.miHoYo.bh3.bilibili/code_cache/
#王牌竞速（哔哩哔哩服）
/data/user/0/com.netease.aceracer.bilibili/app_cache/
/data/user/0/com.netease.aceracer.bilibili/app_cobbler_cache1ddaf36d551afc859800b0009a6cef88/
/data/user/0/com.netease.aceracer.bilibili/app_cobbler_cachec828aff264d49a2c51c71a0a2de3ef28/
/data/user/0/com.netease.aceracer.bilibili/app_cobbler_cached1898625068207895147033b32aaaf1d/
/data/user/0/com.netease.aceracer.bilibili/app_cobbler_cacheed379bd4db0aad6e79d2927f0334ef2d/
/data/user/0/com.netease.aceracer.bilibili/app_cobbler_cacheee77806d438a9d187f77c5d886cb25bb/
/data/user/0/com.netease.aceracer.bilibili/app_pp/
/data/user/0/com.netease.aceracer.bilibili/app_textures/
/data/user/0/com.netease.aceracer.bilibili/code_cache/
#无极仙途（哔哩哔哩服）
/data/user/0/com.windforce.wjxt.bilibili/app_bugly/
/data/user/0/com.windforce.wjxt.bilibili/app_cobbler_cache3bccd6c33b1ed69ab6c09c7ae276b47d/
/data/user/0/com.windforce.wjxt.bilibili/app_cobbler_cache39775e6265c3e5fcf08edd178d910fbc/
/data/user/0/com.windforce.wjxt.bilibili/app_kws/
/data/user/0/com.windforce.wjxt.bilibili/app_pp/
/data/user/0/com.windforce.wjxt.bilibili/app_textures/
/data/user/0/com.windforce.wjxt.bilibili/app_tt_pangle_bykv_file/
/data/user/0/com.windforce.wjxt.bilibili/code_cache/
/data/user/0/com.windforce.wjxt.bilibili/pangle_com.byted.pangle/
#和平精英专清
/data/user/0/com.tencent.tmgp.pubgmhd/app_bugly/
/data/user/0/com.tencent.tmgp.pubgmhd/app_crashSight/
/data/user/0/com.tencent.tmgp.pubgmhd/app_dex/
/data/user/0/com.tencent.tmgp.pubgmhd/app_midasodex/
/data/user/0/com.tencent.tmgp.pubgmhd/app_pluginlib/
/data/user/0/com.tencent.tmgp.pubgmhd/app_textures/
/data/user/0/com.tencent.tmgp.pubgmhd/app_turingdfp/
/data/user/0/com.tencent.tmgp.pubgmhd/app_turingsmi/
/data/user/0/com.tencent.tmgp.pubgmhd/code_cache/
#王者荣耀专清
/data/user/0/com.tencent.tmgp.sgame/app_crashSight/
/data/user/0/com.tencent.tmgp.sgame/app_dex/
/data/user/0/com.tencent.tmgp.sgame/app_midasodex/
/data/user/0/com.tencent.tmgp.sgame/app_textures/
/data/user/0/com.tencent.tmgp.sgame/app_tomb/
/data/user/0/com.tencent.tmgp.sgame/code_cache/
#【腾讯专区】
#杂项专清
/data/media/0/Android/data/com.tencent.ams/cache/
/data/media/0/Android/data/com.tencent.mobileqq/cache/
/data/media/0/Tencent/ams/
/data/media/0/Tencent/msflogs/
/data/media/0/Android/data/com.tencent.ams/
#QQ专清
/data/media/0/com.tencent.mobileqq/
/data/media/0/Android/data/com.tencent.mobileqq/files/tbs/file_locks/
/data/media/0/Android/data/com.tencent.mobileqq/files/tencent/MobileQQ/data/longMsgList.ini
/data/media/0/Android/data/com.tencent.mobileqq/qzone/video_cache/
/data/media/0/Android/data/com.tencent.mobileqq/qzone/zip_cache/
/data/media/0/Android/data/com.tencent.mobileqq/files/tencent/MobileQQ/ocr/cache/
/data/media/0/Android/data/com.tencent.mobileqq/files/tencent/MobileQQ/chatpic/chatraw/3b2/
/data/media/0/Android/data/com.tencent.mobileqq/files/tencent/MobileQQ/chatpic/chatthumb/
/data/media/0/Android/data/com.tencent.mobileqq/files/.info/
/data/media/0/Android/data/com.tencent.mobileqq/files/.turingdebug/
/data/user/0/com.tencent.mobileqq/cache/capture_ptv_template/
/data/user/0/com.tencent.mobileqq/cache/dov_doodle_music/
/data/user/0/com.tencent.mobileqq/cache/dov_doodle_sticker/
/data/user/0/com.tencent.mobileqq/cache/dynamic_text/
/data/user/0/com.tencent.mobileqq/cache/file/weishi/
/data/user/0/com.tencent.mobileqq/cache/information_paster/
/data/media/0/Android/data/com.tencent.mobileqq/qzone/gallerytmp/
/data/media/0/Android/data/com.tencent.mobileqq/files/tbs/
/storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/nt_qq_784df7287b17c6974e4f5a2f6a56f071/
/storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/nt_data/
/storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.guildtmp/
/data/user/0/com.tencent.mobileqq/app_.emojiSticker_v2.1/
/data/user/0/com.tencent.mobileqq/app_appcache_tool/
/data/user/0/com.tencent.mobileqq/app_debug_plugin_info/
/data/user/0/com.tencent.mobileqq/app_database_tool/
/data/user/0/com.tencent.mobileqq/app_crashrecord/
/data/user/0/com.tencent.mobileqq/app_dex/
/data/user/0/com.tencent.mobileqq/app_cache/
/data/user/0/com.tencent.mobileqq/app_bugly/
/data/user/0/com.tencent.mobileqq/lib/
/data/user/0/com.tencent.mobileqq/code_cache/
/data/user/0/com.tencent.mobileqq/app_turingdfp/
/data/user/0/com.tencent.mobileqq/app_textures/
/data/user/0/com.tencent.mobileqq/app_storage/
/data/user/0/com.tencent.mobileqq/app_qzoneupload/
/data/user/0/com.tencent.mobileqq/app_qqwifi_dir/
/data/user/0/com.tencent.mobileqq/app_odex/
/data/user/0/com.tencent.mobileqq/app_midaspluginsTemp/
/data/user/0/com.tencent.mobileqq/app_midasodex/
/data/user/0/com.tencent.mobileqq/app_x5webview/
/data/user/0/com.tencent.mobileqq/app_x5webview_mini/
/data/user/0/com.tencent.mobileqq/app_x5webview_mini1/
/data/user/0/com.tencent.mobileqq/app_webview_tool/
/data/user/0/com.tencent.mobileqq/app_webview/
/data/user/0/com.tencent.mobileqq/cache/
#TIM专清
/data/user/0/com.tencent.tim/cache/
/data/user/0/com.tencent.tim/code_cache/
/data/user/0/com.tencent.tim/app_x5webview/
/data/user/0/com.tencent.tim/app_cache/
/data/user/0/com.tencent.tim/app_bugly/
/data/user/0/com.tencent.tim/app_storage/
/data/user/0/com.tencent.tim/app_x5webview_mini/
/data/user/0/com.tencent.tim/.vfs/
/data/user/0/com.tencent.tim/app_odex/
/data/user/0/com.tencent.tim/app_qqwifi_dir/
/data/user/0/com.tencent.tim/app_dex/
/data/user/0/com.tencent.tim/app_exposured_ad/
/data/user/0/com.tencent.tim/app_database_tool/
/data/user/0/com.tencent.tim/app_crashrecord/
/data/user/0/com.tencent.tim/app_.emojiSticker_v2.1/
/data/user/0/com.tencent.tim/app_appcache_tool/
/data/user/0/com.tencent.tim/cert/
/data/user/0/com.tencent.tim/immer/
/data/user/0/com.tencent.tim/filescommonCache/
/data/user/0/com.tencent.tim/app_tombs/
/data/user/0/com.tencent.tim/app_theme_810/
/data/user/0/com.tencent.tim/app_textures/
/data/user/0/com.tencent.tim/app_TBSqmsp/
/data/user/0/com.tencent.tim/app_qzoneupload/
#微信专清
/data/media/0/Android/data/com.tencent.mm/MicroMsg/xlog/
/data/user/0/com.tencent.mm/app_webview/GPUCache/
/data/user/0/com.tencent.mm/cache/appbrand/
/data/user/0/com.tencent.mm/cache/Default/HTTP Cache/Cache_Data/
/data/user/0/com.android.gallery3d/cache/image_manager_disk_cache/
/data/user/0/com.tencent.mm/app_flutter/
/data/user/0/com.tencent.mm/app_textures/
/data/user/0/com.tencent.mm/app_turingmm/
/data/user/0/com.tencent.mm/app_webview_com_tencent_mm/
/data/user/0/com.tencent.mm/app_webview_com_tencent_mm_appbrand0/
/data/user/0/com.tencent.mm/app_webview_com_tencent_mm_patch/
/data/user/0/com.tencent.mm/app_webview_com_tencent_mm_support/
/data/user/0/com.tencent.mm/app_webview_com_tencent_mm_tools/
/data/user/0/com.tencent.mm/app_webviewcache/
/data/user/0/com.tencent.mm/app_wv_reserved_space_shinker/
/data/user/0/com.tencent.mm/app_xwalk_-1/
/data/user/0/com.tencent.mm/smcertnew/
/data/user/0/com.tencent.mm/tinker_server/
/data/user/0/com.tencent.mm/cache/bizCoverImg/
/data/user/0/com.tencent.mm/cache/temp/topstory/template/dist/*.js
/data/user/0/com.tencent.mm/cache/temp/topstory/template/dist/*.css
#QQ浏览器专清
/data/media/0/MasterArchive/
#一般保护/data/media/0/QQBrowser/
#QQ音乐专清
/data/media/0/qqmusic/gift_anim_zip
/data/media/0/qqmusic/wxa_app_res
/data/media/0/qqmusiclite/firstPiece
/data/user/0/com.tencent.qqmusic/app_bugly/
/data/user/0/com.tencent.qqmusic/app_dex/
/data/user/0/com.tencent.qqmusic/app_fireeye/
/data/user/0/com.tencent.qqmusic/app_fireeye_crashrecord/
/data/user/0/com.tencent.qqmusic/app_klv/
/data/user/0/com.tencent.qqmusic/app_lcore_music/
/data/user/0/com.tencent.qqmusic/app_midasodex/
/data/user/0/com.tencent.qqmusic/app_qmsp/
/data/user/0/com.tencent.qqmusic/app_textures/
/data/user/0/com.tencent.qqmusic/app_TVKqmsp/
/data/user/0/com.tencent.qqmusic/cfont/
/data/user/0/com.tencent.qqmusic/code_cache/
/data/user/0/com.tencent.qqmusic/videosong/
/data/media/0/qqmusic/playerlog/
/data/media/0/qqmusic/mainLog
/data/media/0/qqmusic/safemode.slog
#QQ邮箱
/data/user/0/com.tencent.androidqqmail/app_bugly/
/data/user/0/com.tencent.androidqqmail/app_crashrecord/
/data/user/0/com.tencent.androidqqmail/app_patch/
/data/user/0/com.tencent.androidqqmail/app_textures/
/data/user/0/com.tencent.androidqqmail/app_turingdfp/
/data/user/0/com.tencent.androidqqmail/app_turingfd/
/data/user/0/com.tencent.androidqqmail/cache/
/data/user/0/com.tencent.androidqqmail/code_cache/
/data/user/0/com.tencent.androidqqmail/moai_cache/
/data/user/0/com.tencent.androidqqmail/app_webview/Default/GPUCache/
/data/user/0/com.tencent.androidqqmail/app_webview/Default/Local Storage/leveldb/*.log
/data/user/0/com.tencent.androidqqmail/app_webview/Default/Session Storage/*.log
#————————————————————————₍˄·͈༝·͈˄*₎◞ ̑̑
#【百度专区】
#杂项专清
#保护/data/media/0/baidu/
#保护/data/media/0/BaiduNetdisk/
#百度网盘专清
/data/media/0/baidunetdisk/.audiocache
/data/media/0/baidunetdisk/百度网盘收件箱/.thumbnails
#————————————————————————₍˄·͈༝·͈˄*₎◞ ̑̑
#安卓清理君专清
#保护/data/media/0/backups/
/data/media/0/backups/.adiu
/data/media/0/backups/653505bcb1f5e4c0c03ec31cf0e309a0
/data/media/0/backups/.SystemConfig/
#一般保护/data/media/0/backups/system/
#支付宝专清
/data/user/0/com.eg.android.AlipayGphone/app_crash/
/data/user/0/com.eg.android.AlipayGphone/app_cyclone/
/data/user/0/com.eg.android.AlipayGphone/app_plugins_delay/
/data/user/0/com.eg.android.AlipayGphone/app_plugins_opt/
/data/user/0/com.eg.android.AlipayGphone/app_plugins_patch/
/data/user/0/com.eg.android.AlipayGphone/app_scan_plugins_lib/
/data/user/0/com.eg.android.AlipayGphone/app_sslcache/
/data/user/0/com.eg.android.AlipayGphone/app_textures/
/data/user/0/com.eg.android.AlipayGphone/app_u4_webview/
/data/user/0/com.eg.android.AlipayGphone/app_u4_webview_1/
/data/user/0/com.eg.android.AlipayGphone/ccit/
/data/user/0/com.eg.android.AlipayGphone/code_cache/
/data/user/0/com.eg.android.AlipayGphone/permission_guard/
/data/user/0/com.eg.android.AlipayGphone/ucwa/
#钉钉专清
/data/user/0/com.alibaba.android.rimet/app_anr_com.alibaba.android.rimet/
/data/user/0/com.alibaba.android.rimet/app_anr_com.alibaba.android.rimet:push/
/data/user/0/com.alibaba.android.rimet/app_anr_com.alibaba.android.rimet:sandboxed_privilege_process0/
/data/user/0/com.alibaba.android.rimet/app_cache/
/data/user/0/com.alibaba.android.rimet/app_crash/
/data/user/0/com.alibaba.android.rimet/app_flutter/
/data/user/0/com.alibaba.android.rimet/app_fulltrace/
/data/user/0/com.alibaba.android.rimet/app_h5container/
/data/user/0/com.alibaba.android.rimet/app_plugins/
/data/user/0/com.alibaba.android.rimet/app_textures/
/data/user/0/com.alibaba.android.rimet/code_cache/
/data/user/0/com.alibaba.android.rimet/ucwa/
/data/media/0/Android/data/com.alibaba.android.rimet/cache/DtNest/
/data/media/0/Android/data/com.alibaba.android.rimet/cache/fulltrace/
/data/media/0/Android/data/com.alibaba.android.rimet/cache/open_encrypt/
#瑞幸咖啡
/data/user/0/com.lucky.luckyclient/cache/image_manager_disk_cache/
/data/user/0/com.lucky.luckyclient/cache/net_cache_2/
/data/user/0/com.lucky.luckyclient/cache/net_cache_pure/
/data/user/0/com.lucky.luckyclient/cache/sentry/
/data/user/0/com.lucky.luckyclient/cache/TDCrash/
#微软桌面专清
/data/user/0/com.microsoft.launcher/code_cache/
#花瓣测速
/data/user/0/com.huawei.genexcloud.speedtest/code_cache/
/data/user/0/com.huawei.genexcloud.speedtest/cache/
#酷安专清
/data/media/0/Android/data/com.coolapk.market/files/event/
/data/media/0/Android/data/com.coolapk.market/files/eventUploading/
/data/media/0/Android/data/com.coolapk.market/files/pangle_com.byted.pangle.m/
/data/media/0/Android/data/com.coolapk.market/files/papm/
/data/media/0/Android/data/com.coolapk.market/files/papm4sdk/
/data/media/0/Android/data/com.coolapk.market/files/qCrash/
/data/media/0/Android/data/com.coolapk.market/files/rough_draft/
/data/media/0/Android/data/com.coolapk.market/files/tencent/
/data/media/0/Android/data/com.coolapk.market/files/logs/
/data/media/0/Android/data/com.coolapk.market/files/.*
/data/media/0/Android/data/com.coolapk.market/cache/
/data/media/0/Android/data/com.coolapk.market/files/TTCache/
/data/user/0/com.coolapk.market/app_webview/GPUCache/
/data/user/0/com.coolapk.market/cache/image_manager_disk_cache/
/data/media/0/Android/data/com.coolapk.market/cachett_ad/video_feed
/data/media/0/Android/data/com.coolapk.market/files/rough_draft/rough_draft.bin
/data/user_de/0/com.coolapk.market/code_cache/
/data/user/0/com.coolapk.market/.oabugaij/
/data/user/0/com.coolapk.market/app_bugly/
/data/user/0/com.coolapk.market/app_DUHOME/
/data/user/0/com.coolapk.market/app_e_qq_com_dex_97550f1d11c73369bbee8f7d47965447/
/data/user/0/com.coolapk.market/app_textures/
/data/user/0/com.coolapk.market/pangle_com.byted.pangle/
/data/user/0/com.coolapk.market/pangle_com.byted.rewardx/
/data/user/0/com.coolapk.market/qihooCrash/
#米游社专清
/data/user/0/com.mihoyo.hyperion/app_bugly/
/data/user/0/com.mihoyo.hyperion/app_databases/
/data/user/0/com.mihoyo.hyperion/app_flutter/
/data/user/0/com.mihoyo.hyperion/app_textures/
/data/user/0/com.mihoyo.hyperion/code_cache/
#拼多多专清
/data/user/0/com.xunmeng.pinduoduo/app_meco_textures/
/data/user/0/com.xunmeng.pinduoduo/app_textures/
/data/user/0/com.xunmeng.pinduoduo/cache/
/data/user/0/com.xunmeng.pinduoduo/app_webview/webrtc_event_logs/
/data/user/0/com.xunmeng.pinduoduo/app_webview/GPUCache/
/data/user/0/com.xunmeng.pinduoduo/code_cache/
#淘宝专清
/data/user/0/com.taobao.taobao/app_alipay_msp_disk_cache/
/data/user/0/com.taobao.taobao/app_anr_com.taobao.taobao/
/data/user/0/com.taobao.taobao/app_anr_com.taobao.taobao:channel/
/data/user/0/com.taobao.taobao/app_anr_com.taobao.taobao:gpu_process/
/data/user/0/com.taobao.taobao/app_anr_com.taobao.taobao:sandboxed_privilege_process0/
/data/user/0/com.taobao.taobao/app_crash/
/data/user/0/com.taobao.taobao/app_DaemonDir/
/data/user/0/com.taobao.taobao/app_flutter/
/data/user/0/com.taobao.taobao/app_SyncSDK_Data/
/data/user/0/com.taobao.taobao/app_tdata_v9/
/data/user/0/com.taobao.taobao/app_textures/
/data/user/0/com.taobao.taobao/app_tlog_v9/
/data/user/0/com.taobao.taobao/code_cache/
/data/user/0/com.taobao.taobao/cache/
#京东专清
/data/user/0/com.jingdong.app.mall/app_dex/
/data/user/0/com.jingdong.app.mall/app_flutter/
/data/user/0/com.jingdong.app.mall/app_foldBSPatch/
/data/user/0/com.jingdong.app.mall/app_reactISV/
/data/user/0/com.jingdong.app.mall/app_reactnative/
/data/user/0/com.jingdong.app.mall/app_reactpreload/
/data/user/0/com.jingdong.app.mall/app_textures/
/data/user/0/com.jingdong.app.mall/code_cache/
#夸克专清
/data/user/0/com.quark.browser/main/gilde_cache/
/data/user/0/com.quark.browser/cache/localThumbnails/
/data/user/0/com.quark.browser/cache/pangle_com.byted.pangle/tt_ad/image/
/data/user/0/com.quark.browser/cache/pangle_com.byted.pangle/tt_ad/video_default/
/data/user/0/com.quark.browser/cache/u4_webview/v8_cache/
/data/user/0/com.quark.browser/cache/xtts/
/data/media/0/com.quark.browser/
/data/media/0/ttscache/
/data/user/0/com.quark.browser/_tmp/
/data/user/0/com.quark.browser/app_flutter/
/data/user/0/com.quark.browser/app_jsi/
/data/user/0/com.quark.browser/app_libs/
/data/user/0/com.quark.browser/app_noah_log/
/data/user/0/com.quark.browser/app_textures/
/data/user/0/com.quark.browser/app_tt_pangle_bykv_file/
/data/user/0/com.quark.browser/code_cache/
/data/user/0/com.quark.browser/pangle_com.byted.pangle/
/data/user/0/com.quark.browser/mnn/
/data/user/0/com.quark.browser/watermark/
#Chrome专清
/data/user/0/com.android.chrome/app_chrome/Default/GPUCache/
/data/user/0/com.android.chrome/app_chrome/GrShaderCache/GPUCache/
/data/user/0/com.android.chrome/cache/Cache/
/data/user/0/com.android.chrome/cache/Code Cache/js/
/data/user/0/com.android.chrome/code_cache/
/data/user/0/com.android.chrome/databases/
/data/user/0/com.android.chrome/files/
#搜狗专清
/data/media/0/sogou/.hotexp
/data/media/0/sogou/.trick
#保护/data/media/0/sogou/download
/data/media/0/sogou/voice
/data/media/0/SogouExplorer
/data/data/com.sogou.novel/files/data/novel-image
/data/data/com.sogou.novel/files/data/version
/data/data/com.sogou.novel/files/html
/data/data/com.sogou.novel/files/splash
/data/data/com.sogou.toptennews/files/awcn_strategy
/data/data/com.sogou.appmall/image
/data/data/com.sogou.novel/files/.book
/data/data/com.sogou.novel/files/book
/data/data/com.sogou.novel/files/data/novel-download
#番茄免费小说专清
/data/user/0/com.dragon.read/app_accs/
/data/user/0/com.dragon.read/app_dex/
/data/user/0/com.dragon.read/app_librarian/
/data/user/0/com.dragon.read/app_textures/
/data/user/0/com.dragon.read/pangle_com.byted.pangle/
/data/user/0/com.dragon.read/app_webview_com.dragon.read:downloader/
/data/user/0/com.dragon.read/app_webview_com.dragon.read:miniappX/
/data/user/0/com.dragon.read/app_webview_com.dragon.read:push/
/data/user/0/com.dragon.read/app_webview_com.dragon.read:pushservice/
/data/user/0/com.dragon.read/app_webviewbytedance_com.dragon.read:miniappX/
/data/user/0/com.dragon.read/cache/
/data/user/0/com.dragon.read/code_cache/
/data/user/0/com.dragon.read/files/.envelope/
/data/user/0/com.dragon.read/files/.pangle_i/
/data/user/0/com.dragon.read/files/.patchs/
/data/user/0/com.dragon.read/files/.pre_download/
/data/user/0/com.dragon.read/files/ALOG/
/data/user/0/com.dragon.read/files/gecko-resume-net-work/
/data/user/0/com.dragon.read/files/hybrid_settings_downloader/
/data/user/0/com.dragon.read/files/mediattmp/
/data/user/0/com.dragon.read/files/netlog_temp/
/data/user/0/com.dragon.read/files/offline/
/data/user/0/com.dragon.read/files/offline_tts/
/data/user/0/com.dragon.read/files/offline_tts_log/
/data/user/0/com.dragon.read/files/splashCache/
/data/user/0/com.dragon.read/files/tdReadTemp/
/data/user/0/com.dragon.read/app_tt_pangle_bykv_file/
/data/user/0/com.dragon.read/app_webview/
/data/user/0/com.dragon.read/app_webviewbytedance_com.dragon.read/
/data/user/0/com.dragon.read/lib-main/
/data/user/0/com.dragon.read/small_emoji_res/
#抖音
#抖音缓存目录
/data/data/com.ss.android.ugc.aweme/code_cache/
/data/data/com.ss.android.ugc.aweme/awemeSplashCache/
/data/data/com.ss.android.ugc.aweme/app_sslcache/
/data/data/com.ss.android.ugc.aweme/app_webviewbytedance_com.ss.android.ugc.aweme/GPUCache/
/data/media/0/Android/data/com.ss.android.ugc.aweme/cache/
/data/data/com.ss.android.ugc.aweme/files/Pitaya/PACK/V2/PI/3/Library/addon_features/0.0.15/addon_features/utils/__pycache__/
/data/data/com.ss.android.ugc.aweme/files/Pitaya/PACK/V2/PI/3/Bridge/Bridge__3_3_26/rosetta/__pycache__/
/data/data/com.ss.android.ugc.aweme/cache/
#抖音临时文件
/data/data/com.ss.android.ugc.aweme/files/webview_bytedance/
#抖音log<日志>输出文件
/data/data/com.ss.android.ugc.aweme/files/logs/*
/data/data/com.ss.android.ugc.aweme/files/ALOG/*
#抖音下载的垃圾缓存文件
/data/data/com.ss.android.ugc.aweme/files/music/download/
#快手专清
/data/user/0/com.smile.gifmaker/app_.post/
/data/user/0/com.smile.gifmaker/app_kswebview_kwv_utils_process/
/data/user/0/com.smile.gifmaker/app_kswebview_mini0/
/data/user/0/com.smile.gifmaker/app_lib/
/data/user/0/com.smile.gifmaker/app_textures/
/data/user/0/com.smile.gifmaker/app_workspace/
/data/user/0/com.smile.gifmaker/code_cache/
/data/user/0/com.smile.gifmaker/cache/
/data/user/0/com.smile.gifmaker/exception/
/data/user/0/com.smile.gifmaker/robust2/
/data/user/0/com.smile.gifmaker/safe_mode/
#快手极速版专清
/data/media/0/Android/data/com.kuaishou.nebula/cache/
/data/media/0/Android/data/com.kuaishou.nebula/files/magic_emoji_resource/
/data/media/0/.com.kuaishou.nebula/
/data/user/0/com.kuaishou.nebula/app_.post/
/data/user/0/com.kuaishou.nebula/app_kswebview_commonMiniService/
/data/user/0/com.kuaishou.nebula/app_kswebview_mini1/
/data/user/0/com.kuaishou.nebula/app_kswebview_mini2/
/data/user/0/com.kuaishou.nebula/app_kswebview_mini3/
/data/user/0/com.kuaishou.nebula/app_kswebview_mini4/
/data/user/0/com.kuaishou.nebula/app_textures/
/data/user/0/com.kuaishou.nebula/app_tmf/
/data/user/0/com.kuaishou.nebula/app_workspace/
/data/user/0/com.kuaishou.nebula/code_cache/
/data/user/0/com.kuaishou.nebula/safe_mode/
/data/user/0/com.kuaishou.nebula/app_cache/
/data/user/0/com.kuaishou.nebula/app_kswebview/
/data/user/0/com.kuaishou.nebula/app_kswebview_kwv_utils_process/
/data/user/0/com.kuaishou.nebula/app_kswebview_mini0/
/data/user/0/com.kuaishou.nebula/app_kswebview_yodakw/
/data/user/0/com.kuaishou.nebula/app_live_rich_text/
/data/user/0/com.kuaishou.nebula/app_tflite/
/data/user/0/com.kuaishou.nebula/exception/
/data/user/0/com.kuaishou.nebula/robust2/
/data/user/0/com.kuaishou.nebula/app_lib/
/data/user/0/com.kuaishou.nebula/cache/
/data/media/0/Android/data/com.kuaishou.nebula/files/.warmup/
#快手概念版专清
/data/user/0/com.kwai.thanos/app_.post/
/data/user/0/com.kwai.thanos/app_gdata/
/data/user/0/com.kwai.thanos/app_kswebview_kwv_utils_process/
/data/user/0/com.kwai.thanos/app_textures/
/data/user/0/com.kwai.thanos/app_tflite/
/data/user/0/com.kwai.thanos/app_workspace/
/data/user/0/com.kwai.thanos/code_cache/
/data/user/0/com.kwai.thanos/exception/
#酷我音乐专清
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/.localhtml
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/.pendant
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/.videoUpload
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/.wx
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/centerpush
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/custombootcover
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/picture
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/push
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/screenad
/data/media/0/Android/data/cn.kuwo.player/files/KuwoMusic/welcome
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/.localhtml
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/.pendant
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/.videoUpload
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/.wx
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/centerpush
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/custombootcover
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/picture
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/push
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/screenad
/data/media/0/Android/data/cn.kuwo.player/files/kuwomusic/welcome
/data/user/0/com.xunmeng.pinduoduo/cache/pdd_video_cache/
#菜鸟专清
/data/media/0/Android/data/com.cainiao.wireless/files/amapcn
/data/media/0/Android/data/com.cainiao.wireless/files/images
/data/media/0/Android/data/com.cainiao.wireless/files/splash_ads
#咸鱼专清
/data/user/0/com.taobao.idlefish/cache/
/data/user/0/com.taobao.idlefish/code_cache/
/data/user/0/com.taobao.idlefish/app_crash/
/data/user/0/com.taobao.idlefish/app_cyclone/
/data/user/0/com.taobao.idlefish/app_flutter/
/data/user/0/com.taobao.idlefish/app_textures/
/data/user/0/com.taobao.idlefish/ucwa/
/data/media/0/Android/data/com.taobao.idlefish/app_webview/
#美团专清
/data/user/0/com.sankuai.meituan/app_patch_cache/
/data/user/0/com.sankuai.meituan/app_textures/
/data/user/0/com.sankuai.meituan/cache/
/data/user/0/com.sankuai.meituan/code_cache/
#招商银行专清
/data/user/0/cmb.pb/.cache/
/data/user/0/cmb.pb/app_webview/GPUCache/
/data/user/0/cmb.pb/cache/GlideCache/
/data/user/0/cmb.pb/cache/marketingcache/
/data/user/0/cmb.pb/cache/org.chromium.android_webview/
#今日头条专清
/data/user/0/com.ss.android.article.news/cache/image_cache/v2.ols100.1/
/data/user/0/com.ss.android.article.news/cache/org.chromium.android_webview/
/data/user/0/com.ss.android.article.news/cache/ss-http-cache-v2/
/data/user/0/com.ss.android.article.news/cache/ttnet_storage/prefs/
/data/user/0/com.ss.android.article.news/cache/webviewbytedance_com.ss.android.article.news/Default/HTTP Cache/
/data/user/0/com.ss.android.article.news/app_webviewbytedance_com.ss.android.article.news/Default/GPUCache/
#快手极速版专清
/data/user/0/com.kuaishou.nebula/cache/kswebview_kwv_utils_process/Default/HTTP Cache/Code Cache/
/data/user/0/com.kuaishou.nebula/cache/kxb_v2/tmp/
/data/user/0/com.kuaishou.nebula/cache/WebView/Default/HTTP Cache/
/data/user/0/com.kuaishou.nebula/files/image_cache/v2.ols100.1/
#哔哩哔哩专清
/data/user/0/tv.danmaku.bili/app_annual_report/
/data/user/0/tv.danmaku.bili/app_blog_v3/
/data/user/0/tv.danmaku.bili/app_bugly/
/data/user/0/tv.danmaku.bili/app_textures/
/data/user/0/tv.danmaku.bili/cache/
/data/user/0/tv.danmaku.bili/code_cache/
/data/user/0/tv.danmaku.bili/MainTopMenu/
#万象小组件专清
/data/media/0/Android/data/com.example.raccoon.dialogwidget/cache/
#APP分享专清
/data/media/0/Android/data/info.muge.appshare/cache/
#搜狗输入法专清
/data/media/0/Android/data/com.sohu.inputmethod.sogou/cache/
/data/user/0/com.sohu.inputmethod.sogou/app_crashrecord/
/data/user/0/com.sohu.inputmethod.sogou/app_firstplay/
/data/user/0/com.sohu.inputmethod.sogou/app_plugins_v3/
/data/user/0/com.sohu.inputmethod.sogou/app_plugins_v3_libs/
/data/user/0/com.sohu.inputmethod.sogou/cache/
/data/user/0/com.sohu.inputmethod.sogou/code_cache/
/data/user/0/com.sohu.inputmethod.sogou/app_e_qq_com_plugin_new_7ba137eae3252f7cf0decb76b6e548af/
/data/user/0/com.sohu.inputmethod.sogou/app_e_qq_com_plugin_new_cbf74f33052d727a488b657368e624b6/
/data/user/0/com.sohu.inputmethod.sogou/app_e_qq_com_setting_7ba137eae3252f7cf0decb76b6e548af/
/data/user/0/com.sohu.inputmethod.sogou/app_e_qq_com_setting_cbf74f33052d727a488b657368e624b6/
#微软桌面专清
/data/media/0/Android/data/com.microsoft.launcher/cache/
#中国电信专清
/data/user/0/com.ct.client/.cesium/
/data/user/0/com.ct.client/app_crash/
/data/user/0/com.ct.client/app_textures/
/data/user/0/com.ct.client/code_cache/
/data/user/0/com.ct.client/cache/
#123云盘专清
/data/media/0/123云盘/json/
/data/user/0/com.mfcloudcalculate.networkdisk/app_flutter/
/data/user/0/com.mfcloudcalculate.networkdisk/app_textures/
/data/user/0/com.mfcloudcalculate.networkdisk/code_cache/
/data/user/0/com.mfcloudcalculate.networkdisk/crashsdk/
#xVideos专清
/data/user/0/com.example.w.xVideos/app_tbs/
/data/user/0/com.example.w.xVideos/app_textures/
/data/user/0/com.example.w.xVideos/cache/
/data/user/0/com.example.w.xVideos/code_cache/
#【根目录综合清扫】
#一般保护/data/media/obb/
#一般保护/data/media/10/
#【sdcard清扫】
/sdcard/com.miui.voiceassist
/sdcard/AppTimer
/sdcard/Audiobooks
/sdcard/Alarms
/sdcard/DkMiBrowserDemo
/sdcard/duilite
/sdcard/images
/sdcard/ramdump
/sdcard/tbs
/sdcard/qqstory
#保护/sdcard/sogou
/sdcard/Ringtones
/sdcard/Podcasts
/sdcard//ByteDownload/
#重要保护/sdcard/Movies/
#重要保护/sdcard/Music/
#【外部Data清扫】
/data/media/0/5A968A4B377F25ED0A1FD3C67B0CEE31
/data/media/0/com.mfcloudcalculate.networkdisk/
/data/media/0/OSSLog/
/data/media/0/cmb/
/data/media/0/cmb.pb/
/data/media/0/mfcache/
/data/media/0/TWRP/
/data/media/0/data/
/data/media/0/.skvec
/data/media/0/monitor/
/data/media/0/alipay/
/data/media/0/Beizi/
/data/media/0/AMap/
#保护/data/media/0/Documents/
/data/media/0/Recordings/
/data/media/0/oua_classifier/
/data/media/0/umeng_cache/
/data/media/0/INSTALLATION_NEW
/data/media/0/ecloud/
/data/media/0/com/
/data/media/0/EEventSdk/
/data/media/0/supersdk/
/data/media/0/CrowdSourceLog/
/data/media/0/logan/
/data/media/0/msc/
/data/media/0/ramdump/
/data/media/0/diag_logs/
/data/media/0/qqmusicconfig/
/data/media/0/appupgrade/
/data/media/0/sslCache/
/data/media/0/apminsight/
/data/media/0/sitemp/
/data/media/0/MQ/
/data/media/0/at/
#【Android清扫】
/data/media/0/Android/.Android_819ee91f8d8cc1bb/
/data/media/0/Android/.Android_f0fcd2bde58f4ae8/
/data/media/0/Android/653505bcb1f5e4c0c03ec31cf0e309a0
/data/media/0/Android/.system_android_l2
#保护/data/media/0/Android/media/
#保护/data/media/0/Android/obb/
/data/media/0/Android/obj/
/data/media/0/Android/.vy/
#【应用外部数据存储清扫】
/data/media/0/Android/data/.um/
/data/media/0/Android/data/.nomedia
/data/media/0/Android/data/com.snssdk.api.embed/
/data/media/0/Android/data/System/
#【DCIM清扫】
/data/media/0/DCIM/100ANDRO/
/data/media/0/DCIM/.tmfs/
/data/media/0/DCIM/.android/
#【通配符清扫】
/data/.*
/data/media/0/.*
/data/media/0/..*
/data/media/0/Android/.*
#一般保护/data/media/0/DCIM/.*
" > /data/media/0/Android/PrintX/清理垃圾/黑名单.conf
    }
    PrintX_Blacklist_PATH="/data/media/0/Android/PrintX/清理垃圾/黑名单.conf"
    local IFS=$'\n'
    qiule=""
    for bl in $(cat $PrintX_Blacklist_PATH | grep -v '#'); do
        qiule="$qiule"$'\n'"$bl"
    done
    PrintX_whilelist_PATH="/data/media/0/Android/PrintX/清理垃圾/白名单.conf"
    [ ! -f "${PrintX_whilelist_PATH}" ] && {
    echo "#白名单列表
#白名单，勿删！勿删！勿删！删了一切后果自负！
/data/
/data/*/
/data/adb/*
/data/adb/*/*
/data/media/0
/data/media/0/Android/data
/data/media/0/Android/media
/data/media/0/Android/obb
/data/media/0/Download
/data/media/0/Android
/data/media/0/Android/data
/data/media/0/Android/media
/data/media/0/Android/obb
/data/media/0/DCIM
/data/media/0/MIUI
/data/media/0/Movies
/data/media/0/Music
/data/media/0/Pictures
/data/media/0/Documents
" > /data/media/0/Android/PrintX/清理垃圾/白名单.conf
}
    IFS=$'\n'
    printxxx=""
    for wt in $(cat $PrintX_whilelist_PATH | grep -v '#'); do
        printxxx="$printxxx"$'\n'"$wt"
    done

    function PrintX_direc() {
        local path=$1
        [[ -d "$path" ]] && {
            case $path in
                *'/.') continue ;;
                *'/./') continue ;;
                *'/..') continue ;;
                *'/../') continue ;;
            esac
            rm -rf "$path" && {
                let DIR++
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除文件夹 $path" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
            }
        }
        [[ -f "$path" ]] && {
            rm -rf "$path" && {
                let FILE++
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除文件 $path" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
            }
        }
    }
    white_list=()
    for wt in $(echo "$printxxx" | grep -v '*'); do
        white_list+=("$wt")
    done

    for PrintX_item in $(echo "$qiule" | grep -v '*'); do
        PrintX_skip=false
        for PrintX_WM in "${white_list[@]}"; do
            [[ "$PrintX_item" == "$PrintX_WM" ]] && {
                PrintX_skip=true
                break
            }
        done
        [[ "$PrintX_skip" = true ]] && echo "$(date +"%Y-%m-%d %H:%M:%S") 已跳过: $PrintX_item" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log && continue

        PrintX_direc "$PrintX_item"
    done
    
    chmod -R 755 "/data/media/0/Android/PrintX/清理垃圾"
    source "$PrintX_Times"
    echo "DIRS=$((DIRS+DIR))" > "$PrintX_Times"
    echo "FILES=$((FILES+FILE))" >> "$PrintX_Times"
    sed -i "/^description=/c description=🌟已累计清理: $DIRS个文件夹 | $FILES个文件" "$Rubbish_Path/module.prop"                         

}

[ "${PrintX_Blacklist_check}" = true ] && { PrintX_Blacklist & } && [ "${PrintX_A}" = true ] && { PrintX_D "$PrintX_B" & }