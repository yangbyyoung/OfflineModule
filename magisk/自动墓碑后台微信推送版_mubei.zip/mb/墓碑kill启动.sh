#!/system/bin/sh
MODDIR=${0%/*}

    sd=/data/media/0/Android/墓碑日志.log
    JB=/data/adb/modules/mubei/mb/mb.sh
    JB1=/data/adb/modules/mubei/mb/mb1.sh
    JB2=/data/adb/modules/mubei/mb/mb2.sh

ps -ef|grep $JB|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  done
ps -ef|grep $JB1|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  done    
ps -ef|grep $JB2|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  done  			
  
	(nohup $MODDIR/mb.sh > /dev/null 2>&1 &)&
	
    mb_id="$(pgrep 'mb.sh' | wc -l)"
    mb1_id="$(pgrep 'mb1.sh' | wc -l)"
    mb2_id="$(pgrep 'mb2.sh' | wc -l)"	
	
	if [ "$mb_id" != "0" ]; then
	sed -i 's/\[.*\]/\[ 模式：Kill 19 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	sed -i 's/墓碑.*启动.sh/墓碑kill启动.sh/g' "/data/adb/modules/mubei/service.sh" >/dev/null 2>&1
    echo "$(date '+%T') 已经切换到Kill19模式" >>$sd 
	else
	sed -i 's/\[.*\]/\[ Kill 19 启动失败 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	exit 0
fi