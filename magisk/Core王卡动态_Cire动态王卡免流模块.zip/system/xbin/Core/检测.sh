"${0%/*}"/Core/Chen qdjc
echo "━━━ nat ━━━"
iptables -t nat -S
echo "━━━ mangle ━━━"
iptables -t mangle -S