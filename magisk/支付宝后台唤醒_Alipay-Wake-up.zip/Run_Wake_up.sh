#!/system/bin/sh
# Default configuration
# 酷安@阿巴酱(Petit Abba)
# 请等待云端同步..
sleep 10