#!/sbin/sh

if test -e /system/etc/hosts.bak ;then
	magisk --unlock-blocks > /dev/null 2>&1

function mount_system() {
	a=0
	until test $a -gt 3
	do
		mount -o rw,remount /system
		mount -o rw,remount /
		mount -o rw,remount $(magisk --path)/.magisk/mirror/system_root
		mount -o rw,remount $(magisk --path)/.magisk/mirror/system_root/system
		a=$(($a + 1))
	done
}

	mount_system > /dev/null 2>&1
	rm -rf /system/etc/hosts.bak
fi

