${0%/*}/*/"v2ray".bin start
cd ${0%/*}
chmod -R 777 .
. ./config.ini
./核心/"sohigh".bin start