#!/sbin/sh
rm -rf /data/media/0/Android/支付宝后台唤醒/