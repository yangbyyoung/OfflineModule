#!/system/bin/sh
MODDIR=${0%/*}
echo $(date) "模块启动" > "$MODDIR"/log.log
chmod 777 /sys/class/power_supply/*/*
lasthint="DisCharging"
cp -f "$MODDIR/backup.prop" "$MODDIR/module.prop"
while true; do

  #读取配置文件和系统数据到变量

  status=$(cat /sys/class/power_supply/battery/status)
  capacity=$(cat /sys/class/power_supply/battery/capacity)
  capacity_limit=$(cat "$MODDIR"/capacity_limit)
  temp=$(cat /sys/class/power_supply/battery/temp)
  temp_limit=`expr $(cat "$MODDIR"/temp_limit) \* 10`
  current_target=`expr $(cat "$MODDIR"/current_target) \* 1000`
  current_limit=`expr $(cat "$MODDIR"/current_limit) \* 1000`
  minus=$(cat "$MODDIR"/minus)
  current=`expr $(cat /sys/class/power_supply/battery/current_now) \* $minus`
  show_current=`expr $current / 1000`

  #判断目前状态

  hint="DisCharging"

  if [[ $status == "Charging" ]]
  then
    hint="NormallyCharging"

    if [[ $show_current -gt `expr $current_target + 500` ]]
    then
      hint="HighCurrent"
    fi

    if [[ $current -lt 1000000 ]]
    then
      hint="LowCurrent"
    fi

    if [[ $capacity -gt `expr $capacity_limit - 5` ]]
    then
      hint="DoNothing"
    fi

    if [[ $capacity -gt $capacity_limit ]]
    then
      hint="AlreadyFinish"
    fi
    
    if [[ $temp -gt $temp_limit ]]
    then
      hint="HighTemperature"
    fi
  fi

  #进行相应操作

  if [[ $hint == "DisCharging" ]]
  then
    sed -i "/^description=/c description=[ 🔋未在充电 电流:${show_current}mA ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
  elif [[ $hint == "NormallyCharging" ]]
  then
    sed -i "/^description=/c description=[ ✅正常充电中 电流:${show_current}mA ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
  elif [[ $hint == "HighCurrent" ]]
  then
    sed -i "/^description=/c description=[ ❗电流:${show_current}mA 电流高于阈值太多，尝试重设中... ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
    echo '0' > /sys/class/power_supply/battery/input_current_limited
    echo '1' > /sys/class/power_supply/usb/boost_current
    echo ${current_target} > /sys/class/power_supply/usb/ctm_current_max
    echo ${current_target} > /sys/class/power_supply/usb/current_max
    echo ${current_target} > /sys/class/power_supply/usb/sdp_current_max
    echo ${current_target} > /sys/class/power_supply/usb/hw_current_max
    echo ${current_target} > /sys/class/power_supply/usb/constant_charge_current
    echo ${current_target} > /sys/class/power_supply/usb/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/main/current_max
    echo ${current_target} > /sys/class/power_supply/main/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/dc/current_max
    echo ${current_target} > /sys/class/power_supply/dc/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/battery/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/battery/constant_charge_current
    echo ${current_target} > /sys/class/power_supply/battery/current_max
    echo ${current_target} > /sys/class/power_supply/pc_port/current_max
    echo ${current_target} > /sys/class/power_supply/qpnp-dc/current_max
  elif [[ $hint == "LowCurrent" ]]
  then
    sed -i "/^description=/c description=[ 🔋电流:${show_current}mA 电流偏低 ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
    echo '0' > /sys/class/power_supply/battery/input_current_limited
    echo '1' > /sys/class/power_supply/usb/boost_current
    echo ${current_target} > /sys/class/power_supply/usb/ctm_current_max
    echo ${current_target} > /sys/class/power_supply/usb/current_max
    echo ${current_target} > /sys/class/power_supply/usb/sdp_current_max
    echo ${current_target} > /sys/class/power_supply/usb/hw_current_max
    echo ${current_target} > /sys/class/power_supply/usb/constant_charge_current
    echo ${current_target} > /sys/class/power_supply/usb/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/main/current_max
    echo ${current_target} > /sys/class/power_supply/main/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/dc/current_max
    echo ${current_target} > /sys/class/power_supply/dc/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/battery/constant_charge_current_max
    echo ${current_target} > /sys/class/power_supply/battery/constant_charge_current
    echo ${current_target} > /sys/class/power_supply/battery/current_max
    echo ${current_target} > /sys/class/power_supply/pc_port/current_max
    echo ${current_target} > /sys/class/power_supply/qpnp-dc/current_max
  elif [[ $hint == "HighTemperature" ]]
  then
  sed -i "/^description=/c description=[ ❗温度过高 进入限流模式 电流:${show_current}mA ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
    echo ${current_limit} > /sys/class/power_supply/usb/ctm_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/current_max
    echo ${current_limit} > /sys/class/power_supply/usb/sdp_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/hw_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/constant_charge_current
    echo ${current_limit} > /sys/class/power_supply/usb/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/main/current_max
    echo ${current_limit} > /sys/class/power_supply/main/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/dc/current_max
    echo ${current_limit} > /sys/class/power_supply/dc/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/battery/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/battery/constant_charge_current
    echo ${current_limit} > /sys/class/power_supply/battery/current_max
    echo ${current_limit} > /sys/class/power_supply/pc_port/current_max
    echo ${current_limit} > /sys/class/power_supply/qpnp-dc/current_max
  elif [[ $hint == "AlreadyFinish" ]]
  then
  sed -i "/^description=/c description=[ ✅达到阈值 进入限流模式 电流:${show_current}mA ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
    echo ${current_limit} > /sys/class/power_supply/usb/ctm_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/current_max
    echo ${current_limit} > /sys/class/power_supply/usb/sdp_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/hw_current_max
    echo ${current_limit} > /sys/class/power_supply/usb/constant_charge_current
    echo ${current_limit} > /sys/class/power_supply/usb/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/main/current_max
    echo ${current_limit} > /sys/class/power_supply/main/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/dc/current_max
    echo ${current_limit} > /sys/class/power_supply/dc/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/battery/constant_charge_current_max
    echo ${current_limit} > /sys/class/power_supply/battery/constant_charge_current
    echo ${current_limit} > /sys/class/power_supply/battery/current_max
    echo ${current_limit} > /sys/class/power_supply/pc_port/current_max
    echo ${current_limit} > /sys/class/power_supply/qpnp-dc/current_max
  elif [[ $hint == "DoNothing" ]]
  then
    sed -i "/^description=/c description=[ ✅维持现状 电流:${show_current}mA ]不只是一个慢充模块，本模块可以后台低负载运行，降低充电电流，同时提供到达指定电量降流，高温降流功能，从而保护电池和养老。(当然也可修改模块目录下的配置当作快充模块使用)" "$MODDIR/module.prop"
  fi 

  #写入日志

  if [[ $lasthint != $hint ]]
  then 
    echo $(date) $hint"事件" >> "$MODDIR"/log.log 
  fi
  lasthint=$hint
  sleep 2
done
exit