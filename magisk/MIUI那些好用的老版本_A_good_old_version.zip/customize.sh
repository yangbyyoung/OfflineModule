SKIPUNZIP=0
i=0

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "${choose}" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "${branch}"
		break
	done
	sleep 0.5
}

#启动前检测脚本
Before_starting() {
	echo '#!/system/bin/sh' > ${Startup_Script1}${1}
	echo "if [[ ! -d ${Absolute_Path}/${MODID}${Default_Path} ]]; then" >> ${Startup_Script1}${1}
	echo "	rm -rf ${Buffer_Path}" >> ${Startup_Script1}${1}
	echo "	rm -rf ${Startup_Script1}${1}" >> ${Startup_Script1}${1}
	echo "fi" >> ${Startup_Script1}${1}
	chmod 777 ${Startup_Script1}${1}
}

#启动后检测脚本
After_start_up() {
	echo '#!/system/bin/sh' > ${Startup_Script2}${1}
	echo 'until [[ $(getprop sys.boot_completed) -eq 1 ]]; do' >> ${Startup_Script2}${1}
	echo '	sleep 2' >> ${Startup_Script2}${1}
	echo 'done' >> ${Startup_Script2}${1}
	echo 'sdcard_rw() {' >> ${Startup_Script2}${1}
	echo "	local test_file=\"/sdcard/Android/.A_good_old_version_${i}\"" >> ${Startup_Script2}${1}
	echo '	touch $test_file' >> ${Startup_Script2}${1}
	echo '	while [[ ! -f $test_file ]]; do' >> ${Startup_Script2}${1}
	echo '		touch $test_file' >> ${Startup_Script2}${1}
	echo '		sleep 1' >> ${Startup_Script2}${1}
	echo '	done' >> ${Startup_Script2}${1}
	echo '	rm $test_file' >> ${Startup_Script2}${1}
	echo '}' >> ${Startup_Script2}${1}
	echo 'sdcard_rw' >> ${Startup_Script2}${1}
	echo "if [[ ! -d ${Absolute_Path}/${MODID}${Default_Path} ]]; then" >> ${Startup_Script2}${1}
	echo "	pm uninstall --user 0 ${Apk_Package_Name} >/dev/null 2>&1" >> ${Startup_Script2}${1}
	echo "	rm -rf ${Buffer_Path}" >> ${Startup_Script2}${1}
	echo "	pm install --user 0 -d ${Default_Path}/${Apk_Name} >/dev/null 2>&1" >> ${Startup_Script2}${1}
	echo '	while [[ $? != 0 ]]; do' >> ${Startup_Script2}${1}
	echo '		sleep 3' >> ${Startup_Script2}${1}
	echo "		pm install --user 0 -d ${Default_Path}/${Apk_Name} >/dev/null 2>&1" >> ${Startup_Script2}${1}
	echo '	done' >> ${Startup_Script2}${1}
	echo "	rm -rf ${Startup_Script2}${1}" >> ${Startup_Script2}${1}
	echo "fi" >> ${Startup_Script2}${1}
	chmod 777 ${Startup_Script2}${1}
}

#通用安装函数
Apk_install() {
	rm -rf ${Buffer_Path}
	mktouch ${MODPATH}${Default_Path}/oat/.replace
	mv -f ${MODPATH}/File/${Apk_CN}.apk ${MODPATH}${Default_Path}/${Apk_Name}
	pm uninstall ${Apk_Package_Name} >/dev/null 2>&1
	echo "rm -rf ${Buffer_Path}" >> ${MODPATH}/uninstall.sh
	if [[ ${1} == 1 ]]; then
		cp ${MODPATH}${Default_Path}/${Apk_Name} /data/local/tmp/
		pm install --user 0 -d /data/local/tmp/${Apk_Name} >/dev/null 2>&1
		rm /data/local/tmp/${Apk_Name}
		#输出脚本名称
		Before_starting "${Apk_Name}.sh"
		After_start_up "${Apk_Name}.sh"
	fi
	echo -n "[${i}].${BRIEFING} " >> ${MODPATH}/module.prop
	echo "- 完成"
}



if [[ -d /data/adb/lite_modules/ ]]; then
	#Magisk Lite
	Absolute_Path="/data/adb/lite_modules"
else
	#Magisk
	Absolute_Path="/data/adb/modules"
fi

Startup_Script1="/data/adb/post-fs-data.d/${MODID}_"
Startup_Script2="/data/adb/service.d/${MODID}_"

echo ""
echo "##################"
echo "- 按音量键＋: 安装 √"
echo "- 按音量键－: 跳过 ×"
echo "##################"

##################################################
#		默认路径: Default_Path=""
#		缓存路径: Buffer_Path=""
#		apk名称: Apk_Name=""
#		apk包名: Apk_Package_Name=""
#		apk中文名: Apk_CN=""
#		安装函数: Apk_install 0或者1 如果是普通的替换只需要0即可
##################################################

#文件管理
BRIEFING="文件管理v4.2.1.1(可查看Android目录的最后一个版本)"
echo ""
echo " * [1/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	echo "- 安装"
	if [[ -d /system/app/FileExplorer ]]; then
		name="FileExplorer"
	elif [[ -d /system/app/MIUIFileExplorer ]]; then
		name="MIUIFileExplorer"
	else
		echo "- 不存在目标: FileExplorer"
		echo "- 跳过"
		name="0"
	fi
	if [[ $name != 0 ]]; then
		i=$(expr ${i} + 1)
		Default_Path="/system/app/${name}"
		Buffer_Path="/data/system/package_cache/*/*FileExplorer*"
		Apk_Name="${name}.apk"
		Apk_Package_Name="com.android.fileexplorer"
		Apk_CN="文件管理"
		Apk_install 0
	fi
else
	echo "- 跳过"
fi

#应用包管理组件
BRIEFING="应用包管理组件v2.0.6(无引流入口的版本 破除云控:感谢@雄氏老方)"
echo ""
echo " * [2/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	i=$(expr ${i} + 1)
	echo "- 安装"
	Default_Path="/system/priv-app/MiuiPackageInstaller"
	Buffer_Path="/data/system/package_cache/*/*MiuiPackageInstaller*"
	Apk_Name="MiuiPackageInstaller.apk"
	Apk_Package_Name="com.miui.packageinstaller"
	Apk_CN="应用包管理组件"
	Apk_install 0
else
	echo "- 跳过"
fi

#全局搜索
BRIEFING="全局搜索v9.1.3.5(拥有高斯模糊的第一个版本)"
echo ""
echo " * [3/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	i=$(expr ${i} + 1)
	echo "- 安装"
	Default_Path="/system/priv-app/QuickSearchBox"
	Buffer_Path="/data/system/package_cache/*/*QuickSearchBox*"
	Apk_Name="QuickSearchBox.apk"
	Apk_Package_Name="com.android.quicksearchbox"
	Apk_CN="搜索"
	Apk_install 0
else
	echo "- 跳过"
fi

#智能助理
BRIEFING="智能助理v3.8.1921(旧版最后一个版本)"
echo ""
echo " * [4/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	echo "- 安装"
	if [[ -d /system/priv-app/PersonalAssistant ]]; then
		name2="PersonalAssistant"
	elif [[ -d /system/priv-app/MIUIPersonalAssistant ]]; then
		name2="MIUIPersonalAssistant"
	else
		echo "- 不存在目标: PersonalAssistant"
		echo "- 跳过"
		name2="0"
	fi
	if [[ $name2 != 0 ]]; then
		i=$(expr ${i} + 1)
		Default_Path="/system/priv-app/${name2}"
		Buffer_Path="/data/system/package_cache/*/*PersonalAssistant*"
		Apk_Name="${name2}.apk"
		Apk_Package_Name="com.miui.personalassistant"
		Apk_CN="智能助理"
		Apk_install 1
	fi
else
	echo "- 跳过"
fi

#手机管家
BRIEFING="手机管家v5.5.1(弹出“未知来源应用权限管理:发送通知,连接网络等”的前一个版本)"
echo ""
echo " * [5/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	echo "- 安装"
	if [[ -d /system/priv-app/MIUISecurityCenter/ ]]; then
		name3="MIUISecurityCenter"
	elif [[ -d /system/priv-app/SecurityCenter/ ]]; then
		name3="SecurityCenter"
	else
		echo "- 不存在目标: MIUISecurityCenter"
		echo "- 跳过"
		name3="0"
	fi
	if [[ $name3 != 0 ]]; then
		i=$(expr ${i} + 1)
		Default_Path="/system/priv-app/${name3}"
		Buffer_Path="/data/system/package_cache/*/*SecurityCenter*"
		Apk_Name="${name3}.apk"
		Apk_Package_Name="com.miui.securitycenter"
		Apk_CN="手机管家"
		Apk_install 1
	fi
else
	echo "- 跳过"
fi

#传送门
BRIEFING="传送门v2.3.1(全屏识别文字/图片和图片识别可右下角直接编辑/分享的版本)"
echo ""
echo " * [6/6] ${BRIEFING}"
if [[ $(get_choose) == 0 ]]; then
	i=$(expr ${i} + 1)
	echo "- 安装"
	Default_Path="/system/priv-app/ContentExtension"
	Buffer_Path="/data/system/package_cache/*/*ContentExtension*"
	Apk_Name="ContentExtension.apk"
	Apk_Package_Name="com.miui.contentextension"
	Apk_CN="传送门"
	Apk_install 1
else
	echo "- 跳过"
fi

echo ""
[[ ${i} == 0 ]] && abort "- 啥也没安装玩个锤子"

echo -n "| 安装: [${i}/6]" >> ${MODPATH}/module.prop
rm -rf ${MODPATH}/File/