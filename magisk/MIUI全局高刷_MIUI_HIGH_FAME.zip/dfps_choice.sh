#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

target_value="$(show_value '智能刷新率')"


if test "$target_value" = "是" ;then
	echo "- 您已选择 [ 智能刷新率 开启 ]！"
	cp -rf "$MODPATH/prop/enable_smart_dfps.prop" "${MODPATH}/system.prop"
else
	echo "- 您已选择 [ 智能刷新率 关闭 ]！"
	cp -rf "$MODPATH/prop/disable_smart_dfps.prop" "${MODPATH}/system.prop"
fi




