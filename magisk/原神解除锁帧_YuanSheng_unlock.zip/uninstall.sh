#!/system/bin/sh

until [ $(getprop sys.boot_completed) -eq 1 ] ; do
    sleep 5
done

until [ -d "/data/data" ] ; do
    sleep 1
done

rm -rf /data/adb/service.d/YuanSheng_unlock.sh

find /data/data -name "com.miHoYo.Yuanshen" -o -name "com.miHoYo.GenshinImpact" -o -name "com.miHoYo.ys.bilibili" -o -name "com.miHoYo.ys.mi" -type f | while read i; do
   data_path="$i/shared_prefs"
   if [ -e $data_path/com.miHoYo.Yuanshen.v2.playerprefs.xml.bak ]; then
      rm -rf $data_path/com.miHoYo.Yuanshen.v2.playerprefs.xml
      cp -f $data_path/com.miHoYo.Yuanshen.v2.playerprefs.xml.bak $data_path/com.miHoYo.Yuanshen.v2.playerprefs.xml
   fi
   chmod 771 $data_path
done
