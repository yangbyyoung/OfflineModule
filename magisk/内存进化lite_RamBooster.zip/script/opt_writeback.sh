#!/bin/sh
app=com.miui.home
check(){
TIMEs=0
until [ "$TIMEs" == 15 ]
do
APP=`dumpsys activity lru | grep 'TOP'|awk 'NR==1'|awk -F '[ :/]+' '{print $7}'`
      if [ "$APP" != "$apps" ]; then
      let 'TIMEs+=1'
      apps="$APP"
#      echo "$TIMEs/15 前台应用切换为$APP"
      fi
      sleep 3
done
}
wrote(){
	echo "第${TIMES}次运行"
	echo "" `date "+%Y-%m-%d %H:%M:%S"`
	originDATA=$(cat /sys/block/zram0/bd_stat)
	oldSIZE=$(echo ${originDATA} | awk '{print $1}')
	echo "调用回写中..."
	    writeback "huge"
	newDATA=$(cat /sys/block/zram0/bd_stat)
	newSIZE=$(echo ${newDATA} | awk '{print $1}')
	READ=$(echo ${newDATA} | awk '{print $2}')
	WRITE=$(echo ${newDATA} | awk '{print $3}')
	let deltaSIZE=${newSIZE}-${oldSIZE}
	let deltaSIZE=${deltaSIZE}*4/1024
	let READ=${READ}*4/1024
	let WRITE=${WRITE}*4/1024
	echo "本次写入${deltaSIZE}MB"
	echo "总读取：${READ}MB  总写入：${WRITE}MB"
	echo "--------------------------------------------"
}
writeback(){
		let 'TIMES+=1'
		echo ${1} > /sys/block/zram0/writeback
		sleep 30
}
BootOptimization(){
      echo "进入开机优化..."
      sleep 3m
      echo all > /sys/block/zram0/idle
      sleep 2m
      writeback "idle"
      echo "" `date "+%Y-%m-%d %H:%M:%S"`
      echo "完成！"
      echo "--------------------------------------------"
}

    echo "模块挂载正常"
    BootOptimization
	while [ true ]; do
	  check
	  wrote
     sleep 15
done
