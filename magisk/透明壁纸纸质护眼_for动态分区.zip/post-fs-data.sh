#!/system/bin/sh

MODDIR=${0%/*}
mount --bind $MODDIR/my_product/decouping_wallpaper/common/inlay_wallpaper1.png /my_product/decouping_wallpaper/common/inlay_wallpaper1.png
