#!/system/bin/sh
#sqlite3下载地址
#脚本编写@coolapk 10007
#https://keytoolazy.coding.net/p/hms-core/d/HMS-CORE/git/raw/master/Sqlite3/Sqlite1.zip

export PATH="${0%/*}:/system/bin":$PATH

test "$(which -a sqlite3)" = "" && echo "请安装sqlite3！" && exit 1

#添加需要修改的游戏包名
Gamepackage=`cat "${0%/*}/Joyose/应用包名.prop" 2>/dev/null | sed '/^#/d;/^[[:space:]]*$/d'`

if test "${Gamepackage}" = "" ;then
Gamepackage='
com.qqgame.hlddz
com.pubg.imobile
com.tencent.tmgp.cod
com.riotgames.league.wildrift
com.tencent.tmgp.wdsj666
com.tencent.tmgp.qqx5
com.tencent.shootgame
com.tencent.tmgp.bh3
com.tencent.tmgp.dwrg
com.fungames.sniper3d
com.netease.hyxd
com.tencent.tmgp.cf
com.tencent.tmgp.speedmobile
com.tencent.lolm
com.miHoYo.Yuanshen
com.miHoYo.GenshinImpact
com.miHoYo.ys.bilibili
com.miHoYo.ys.mi
'
fi



#输出最终文件
function echo_package_config(){
local target_fps="`echo_target_hightest_fps`"
for package in ${Gamepackage}
do
	echo -n "{\"game_name\":\"${package}\",\"dynamic_fps\":\"10:${target_fps},46:${target_fps},50:${target_fps},55:90,60:60\",\"dynamic_fps_M\":\"10:${target_fps},46:${target_fps},48:${target_fps},50:90,55:60\",\"scene_ovrride\":[]},"
done
echo -n "{\"game_name\":\"DEFAULT_COMMON_CONFIG\",\"dynamic_fps\":\"10:${target_fps},46:${target_fps},50:${target_fps},55:90,60:60\",\"dynamic_fps_M\":\"10:${target_fps},46:${target_fps},48:${target_fps},50:90,55:60\",\"scene_ovrride\":[]}"
}

function echo_target_hightest_fps(){
local tune_fps=`dumpsys display | grep 'DisplayModeRecord' | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' | grep -Eo '^90$|^120$' `
if test "${tune_fps}" = "120" ;then
	target_fps="120"
elif test "${tune_fps}" = "90" ;then
	target_fps="90"
else
	target_fps="120"
fi
echo -n "${target_fps}"
}

function echo_support_fps_list_all(){
echo -n "`dumpsys display | grep 'DisplayModeRecord' | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' | sort -n | uniq | sed ':a;N;\$!ba;s|\n|,|g'`"
}


function output_boost_json(){
local target_fps="`echo_target_hightest_fps`"
local device_support_fps="`echo_support_fps_list_all`"
cat << key
{"header":{"version":"2022051701","index_enable":true,"network_improve":true,"mqs_enable":true},"game_booster":{"booster_enable":true,"cpuset_enable":true,"tuner_enable":true,"monitor":{"monitor_enable":false,"analytics_enable":false,"default_interval":2},"migl_enable":true,"migl_config":["yuanshen:com.miHoYo.Yuanshen#com.miHoYo.GenshinImpact#com.miHoYo.ys.mi#com.miHoYo.ys.bilibili;1280;576;-1","pubg:com.tencent.tmgp.pubgmhd;-1;-1;1"],"support_display_refresh_rates":[${device_support_fps}],"support_dynamic_refresh_rate_games":[],"support_highfps_app":["com.tencent.tmgp.speedmobile:${target_fps}","com.tencent.tmgp.pubgmhd:${target_fps}","com.tencent.tmgp.sgame:${target_fps}","com.tencent.tmgp.sgamece:${target_fps}","com.tencent.tmgp.cf:${target_fps}","com.netease.moba.mi:${target_fps}","com.miHoYo.bh3.mi:${target_fps}","com.miHoYo.enterprise.NGHSoD:${target_fps}","com.t2ksports.nba2k20and:${target_fps}","com.miHoYo.Yuanshen:${target_fps}","com.miHoYo.ys.mi:${target_fps}","com.tencent.lolm:${target_fps}","com.guandan.mi:${target_fps}","com.tencent.af:${target_fps}"],"support_motor_app":[],"booster_config":{"default_config":[],"scene_config":[],"ovrride_config":[`echo_package_config`]}}}
key
}

function echo_common_package_name(){
pm list package -3 | sed 's|package:||g' | while read package ;do
	echo -n "\"${package}\","
done
echo -n "\"keytoolazy\""
}

function output_common_json(){
cat << key
{"support_app":[`echo_common_package_name`],"debug_log_collect_config":{}}
key
}

function disable_joyose(){
if test -f /data/data/com.xiaomi.joyose/databases/SmartP.db ;then
#解除chattr 锁定/data/data/com.xiaomi.joyose/databases/SmartP.db
chattr -R -i /data/data/com.xiaomi.joyose
chmod 0777 /data/data/com.xiaomi.joyose/databases/SmartP.db
local userid="$(dumpsys package com.xiaomi.joyose | grep userId | uniq | tr -cd '[0-9]' | head -n 1)"
if test "${userid}" != "" ;then
	chown -R "${userid}:${userid}" /data/data/com.xiaomi.joyose/databases
fi
sqlite3 "/data/data/com.xiaomi.joyose/databases/SmartP.db" << EOF
#update cloud_config set enable='0' where config_name='common_config';
#update cloud_config set enable='0' where config_name='booster_config';
delete from cloud_config where group_name='booster_config'; 
delete from cloud_config where group_name='common_config';
insert into cloud_config (config_name,group_name,params,with_model,model,version) values('booster_config','booster_config','`output_boost_json`','0','null','2023012412');
insert into cloud_config (config_name,group_name,params,with_model,model,version) values('common_config','common_config','`output_common_json`','0','null','2023012412');
update cloud_config set enable='1';
#update cloud_config set params='`output_boost_json`' where group_name='booster_config';
#update cloud_config set params='`output_common_json`' where group_name='common_config';
EOF
#resetprop persist.sys.sc_allow_conn false
#对/data/data/com.xiaomi.joyose/databases/SmartP.db 添加 chattr锁定
#chattr +i /data/data/com.xiaomi.joyose/databases/SmartP.db
chmod 0755 /data/data/com.xiaomi.joyose/databases/SmartP.db
fi
}


function disable_power(){
sqlite3 "/data/data/com.miui.powerkeeper/databases/user_configure.db" << EOF
#重建，以防无数据读取
delete from misc where name='thermal_group'; 
insert into misc (name,value) values('thermal_group','{"game":""}');
update misc set value='{"game":""}' where name='thermal_group';
delete from misc where name='key_thermal_enable'; 
insert into misc (name,value) values('key_thermal_enable','true');
#update misc set value='false' where name='key_thermal_enable';
#修改
update misc set value='0' where name='key_temp_threshold_xo_thermal_check';
update misc set value='120' where name='key_temp_threshold_xo_thermal';
update misc set value='120' where name='key_temp_threshold_bl_thermal';
update misc set value='0' where name='key_temp_threshold_battery_level';
update misc set value='120' where name='key_temp_threshold';
update misc set value='120' where name='xo_temp_threshold';
update misc set value='120' where name='xo_temp_thresholdclr';
#测试项
#delete from misc where name='key_thermal_cloud_switch';
#delete from misc where name='enable'; 
update misc set value='true' where name='enable';
EOF
}


function Running_Joyose_mod_cycle(){
for i in `seq 1 20`
do
	disable_joyose && sleep 3s
	test "${i}" = "20" && break
	sleep 15s
done
}



disable_joyose
disable_power

(Running_Joyose_mod_cycle &)


