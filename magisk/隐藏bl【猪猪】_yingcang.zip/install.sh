SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "       Make By 猪猪          "
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'classes.dex' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'zygisk/x86.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'zygisk/x86_64.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'zygisk/arm64-v8a.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'zygisk/armeabi-v7a.so' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}