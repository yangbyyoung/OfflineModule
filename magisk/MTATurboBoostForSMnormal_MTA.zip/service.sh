#!/system/bin/sh
MODDIR=${0%/*}

chmod -R 777 $MODDIR/system/lib64/android.frameworks.displayservice@1.0.so

rm -rf /data/data/com.xiaomi.joyose/cache
rm -rf /data/data/com.miui.powerkeeper/cache

sleep 5
rm -rf /data/system/package_cache/*
