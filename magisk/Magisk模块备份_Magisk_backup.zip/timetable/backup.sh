
MODPATH="/data/adb/modules/Magisk_backup"
source $MODPATH/keymod/path.sh
chmod 777 -R $Backup_path

#创建备份路径
test ! -e $Backup_path && mkdir -p ${Backup_path%/*}
#用tar备份
cd /data/adb
tar -cf $Backup_path * --exclude=magisk --exclude=modules_update --exclude=lite_modules_update
#输出日志
sh ${Backup_path%/*}/log.sh

function limitlog(){  
local logfile=$1  
local maxsize=$2 
filesize=`ls -l $logfile | awk '{ print $5 }'`
if [ $filesize -gt $maxsize ];then
echo " " > $logfile
fi
}

MAX=$((1024*100))

limitlog ${Backup_path%/*}/备份日志.log $MAX