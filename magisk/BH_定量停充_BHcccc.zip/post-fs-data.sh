#!/system/bin/sh
MODDIR=${0%/*}
resetprop ro.debuggable 1
resetprop sys.boot_completed 1
sed -i "s/状态：.*/状态：启动中]/g" $MODDIR/module.prop