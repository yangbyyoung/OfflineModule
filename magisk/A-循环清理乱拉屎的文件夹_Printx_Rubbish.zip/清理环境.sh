rm -rf /data/media/0/Android/PrintX
rm -rf /data/adb/modules/Printx_Rubbish