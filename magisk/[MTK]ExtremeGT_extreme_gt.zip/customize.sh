set_perm_recursive $MODPATH 0 0 0755 0644

setprop persist.sys.oplus.wifi.sla.game_high_temperature 48
setprop persist.oplus.display.vrr 0
setprop persist.sys.environment.temp 25
setprop persist.sys.horae.enable 0
