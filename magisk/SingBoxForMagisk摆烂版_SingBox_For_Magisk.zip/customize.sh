SKIPUNZIP=1

dataDir="/data/adb/sfm"
timeStamp=$(date "+%Y%m%d%H%M")
UIPrint="ui_print"
SetPerm="set_perm"
SetPermRecursive="set_perm_recursive"
termuxEnv="/data/data/com.termux/files/usr/bin"

case "${ARCH}" in
  arm64)
    ;;
  *)
    abort "不支持的架构"
esac

if [ ! -f ${termuxEnv}/node ] ; then
  abort "未检测到 termux node 环境，请安装后再刷写"
fi

unzip -o "${ZIPFILE}" -x 'META-INF/*' -d ${MODPATH} >&2

if [ -d ${dataDir} ] ; then
  ${SetPerm} ${MODPATH}/transfers 0 0 7777
  modulePath=$(cat ${dataDir}/src/modulePath)
  propPath="${modulePath}/module.prop"
  versionCode=$(cat ${propPath} | grep versionCode | awk -F= '{print $2}' )
  if [ ${versionCode} -lt 5 ]; then
    abort "版本太低，请先升级到 202303042355 再刷写此版本"
  fi
  mkdir -p ${dataDir}.old/${timeStamp}/
  mv -f ${dataDir}/* ${dataDir}.old/${timeStamp}/
  cp -rf ${MODPATH}/sfm/* ${dataDir}/
  cp -rf ${dataDir}.old/${timeStamp}/box.json ${dataDir}/box.json
  cp -rf ${dataDir}.old/${timeStamp}/ProxyProviders/*.hjson ${dataDir}/ProxyProviders/
  cp -rf ${dataDir}.old/${timeStamp}/RuleProviders/*.yaml ${dataDir}/RuleProviders/
  cp -rf ${dataDir}.old/${timeStamp}/src/FileProviders/* ${dataDir}/src/FileProviders/
  cp -f ${dataDir}.old/${timeStamp}/src/cache.db ${dataDir}/src/cache.db
  cp -f ${dataDir}.old/${timeStamp}/src/config.hjson ${dataDir}/src/config.hjson
  cp -f ${dataDir}.old/${timeStamp}/src/modulePath ${dataDir}/src/modulePath
  if [ -f ${dataDir}.old/${timeStamp}/src/proxyProviders.hjson ] ; then
    ${termuxEnv}/node ${MODPATH}/transfer "--dir=${dataDir}.old/${timeStamp}/"
  fi
  cp -f ${dataDir}.old/${timeStamp}/src/baseConfig.hjson ${dataDir}/src/baseConfig.hjson
else
  mkdir -p ${dataDir}
  cp -rf ${MODPATH}/sfm/* ${dataDir}/
fi

rm -rf ${MODPATH}/transfer
rm -rf ${MODPATH}/sfm

sleep 1

${UIPrint} "- 开始设置环境权限"
${SetPermRecursive} ${MODPATH} 0 0 7777 7777
${SetPermRecursive} ${dataDir} 0 0 7777 7777