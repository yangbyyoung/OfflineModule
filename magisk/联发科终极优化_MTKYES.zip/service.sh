#!/system/bin/sh
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo noop > /sys/block/sda/queue/scheduler
echo cfq > /sys/block/sdb/queue/scheduler
echo deadline > /sys/block/sdc/queue/scheduler
echo 64 > /sys/block/sda/queue/read_ahead_kb
echo 64 > /sys/block/sdb/queue/read_ahead_kb
echo 64 > /sys/block/sdc/queue/read_ahead_kb
echo 0 > /sys/block/dm-0/queue/iostats
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats
echo 0 > /sys/block/mmcblk1/queue/iostats
echo 0 > /sys/block/loop0/queue/iostats
echo 0 > /sys/block/loop1/queue/iostats
echo 0 > /sys/block/loop2/queue/iostats
echo 0 > /sys/block/loop3/queue/iostats
echo 0 > /sys/block/loop4/queue/iostats
echo 0 > /sys/block/loop5/queue/iostats
echo 0 > /sys/block/loop6/queue/iostats
echo 0 > /sys/block/loop7/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
echo 2 > /sys/block/sda/queue/rq_affinity
echo Y > /sys/kernel/debug/mali0/ctx/defaults/infinite_cache
until [[ $supercharge == true ]]; do
chmod 777 /sys/class/power_supply/battery/fast_charge_current
chmod 777 /sys/class/power_supply/battery/thermal_input_current
chmod 777 /sys/class/power_supply/battery/input_suspend
chmod 777 /sys/class/power_supply/usb/current_max
chmod 777 /sys/class/power_supply/battery/battery_charging_enabled
echo 0 > /sys/class/power_supply/battery/input_suspend
echo 1 > /sys/class/power_supply/battery/battery_charging_enabled
echo 12000000 > /sys/class/power_supply/battery/fast_charge_current
echo 12000000 > /sys/class/power_supply/battery/thermal_input_current
sleep 2s
done