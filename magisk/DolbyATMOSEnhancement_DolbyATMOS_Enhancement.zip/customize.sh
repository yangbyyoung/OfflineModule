#By Coolapk @Skai6087
#转载或使用调音文件/代码请注明出处

# 配置
########################################
# 如果你需要启用 Magic Mount, 请把它设置为 true
# 大多数模块都需要启用它
AUTOMOUNT=true
# 如果你需要加载 system.prop, 请把它设置为 true
PROPFILE=true
# 如果你需要执行 post-fs-data 脚本, 请把它设置为 true
POSTFSDATA=false
# 如果你需要执行 service 脚本, 请把它设置为 true
LATESTARTSERVICE=false
SKIPMOUNT=false
########################################
# 安装信息
########################################
M="$MODPATH"
sve="$M/system/vendor/etc"
sved="$M/system/vendor/etc/dolby"
mix="$M/mixer_xml"
dbdx="$M/dolby_dax"
dbal="$M/dolby_dax/Balance"
dbas="$M/dolby_dax/Bass"
# 获取设备代号
DEVICE=$(getprop ro.product.vendor.device)
# 获取Android版本
VERSION=$(getprop ro.build.version.release)

# 检测设备代号
diting_audio() {
if [ "$DEVICE" == "diting" ]; then
# 如果是K50U，则弹出是否使用音量增强
mixer_paths_xml
fi
}

#识别音量键
key_click() {
kc=""
while [ "$kc" = "" ]; do
kc="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
sleep 0.2
done
}

#音量增强
mixer_paths_xml() {
ui_print "-     是否安装音量增强(MIUI14/HyperOS可用) "
ui_print "　　　        音量↑:是│音量↓:否            "
key_click
case "$kc" in
"KEY_VOLUMEUP")
ui_print "　　　         　✓"
ui_print "- 安装成功！"
mv -f $mix/* $sve/
rm -rf $mix
sleep 0.4
;;
"KEY_VOLUMEDOWN")
ui_print "　　　　　　　　　　    　　✓"
ui_print "- 已取消安装 "
rm -rf $mix
sleep 0.4
esac
}

#选择EQ
dolby_dax() {
ui_print "-              请选择你喜欢的EQ  "
ui_print "　　     音量↑:均衡还原│音量↓:浑厚低音            "
key_click
case "$kc" in
"KEY_VOLUMEUP")
ui_print "　　　         　✓"
ui_print "- 已选择：均衡还原 "
mv -f $dbal/* $sved/
rm -rf $dbdx
sleep 0.4
;;
"KEY_VOLUMEDOWN")
ui_print "　　　　　　　　　    　     　　✓"
ui_print "- 已选择：浑厚低音 "
mv -f $dbas/* $sved/
rm -rf $dbdx
sleep 0.4
esac
}

#是否加载prop
audio_prop() {
ui_print "-             是否加载system.prop "
ui_print "  (不加载prop可避免某些奇怪的bug，但会影响音效)"
ui_print "　　　        音量↑:是│音量↓:否            "
key_click
case "$kc" in
"KEY_VOLUMEUP")
ui_print "　　　         　✓"
ui_print "- 加载成功！"
sleep 0.4
;;
"KEY_VOLUMEDOWN")
ui_print "　　　　　　　　　     　　✓"
ui_print "- 已取消加载 "
sed -i '/#audio_prop/,/#audio/d' $M/system.prop
sleep 0.4
esac
}

ui_print "***************************"
ui_print ""
ui_print "- Dolby ATMOS loading... "
sleep 0.7
ui_print "- Speaker Sound Enhancement -"
ui_print "- Design By Skai6087 "
ui_print "- 设备代号:$DEVICE "
ui_print "- Android版本:$VERSION "
sleep 0.05
diting_audio
dolby_dax
audio_prop
ui_print "- 对1012/1216扬声器重新调音 "
ui_print "- 正在清理package_cache... "
ui_print ""
sleep 0.8
ui_print "- 清理完成 "
ui_print "- 请重启你的设备 "
ui_print "- Coolapk @Skai6087 "
ui_print ""
ui_print "***************************"

#清理缓存
rm -rf /data/system/package_cache/*

#######################################
# 替换列表
#######################################

# 列出你想在系统中直接替换的所有目录
# 查看文档，了解更多关于Magic Mount如何工作的信息，以及你为什么需要它

# 这是个示例
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里构建你自己的列表，它将覆盖上面的示例
# 如果你不需要替换任何东西，!千万不要! 删除它，让它保持现在的状态
REPLACE=""
#######################################
# 权限设置
#######################################

set_permissions() {
  # 只有一些特殊文件需要特定的权限
  # 默认的权限应该适用于大多数情况

  # 下面是 set_perm 函数的一些示例:

  # set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755        0644

  # set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000      0755       u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000      0755       u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0         0644

  # 以下是默认权限，请勿删除
  set_perm_recursive $MODPATH 0 0 0755 0644
}
