# Wifi Bonding for MediaTek

Enable 40Mhz channel width for MediaTek based phone.
