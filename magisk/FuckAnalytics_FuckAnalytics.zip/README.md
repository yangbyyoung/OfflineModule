# Magisk Module 模板

**警告：模块id 不能包含 英文字母，数字和半角符号 之外的字符，否则模块将无法正常加载/卸载！**

**由于官方没有发布新模板模块,如遇到 bug 请及时向 [我](http://www.coolapk.com/u/1124169) 反馈**

由于新模板模块的巨大变动 我会尽快更新教程 敬请留意 [我的酷安主页](http://www.coolapk.com/u/1124169)

有关模块和存储库的更多信息，请参阅 [官方文档](https://github.com/topjohnwu/Magisk/blob/master/docs/guides.md)
