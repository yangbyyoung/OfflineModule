#Temperature camouflage：30℃
while  
do 
su -c echo 30000 > /sys/class/thermal/thermal_zone49/temp
sleep 0
done