#来自王者荣耀VT优化：Koolight&听风辰
wz=/data/data/com.tencent.tmgp.sgame/shared_prefs
prefs=$wz/com.tencent.tmgp.sgame.v2.playerprefs.xml
CF=$TMPDIR/OpenGLES3Config.xml
CF_Path=$wz/OpenGLES3Config.xml
on_install() {
rm -rf $CF_Path
if [ ! -f "$prefs" ]; then
ui_print "- 未找到王者优化参数文件"
exit;
fi
ui_print "- 开始移除优化参数";
sed -i '/.*<int name="VulkanTryCount" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableVulkan" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableGLES3" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableMTR" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="DisableMTR" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="sgame_ALL_HighFPS" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableHWVendorOpt" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="UnityGraphicsQuality" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableGPUReport" value=".*" \/>/'d "$prefs"
ui_print "- 优化参数移除成功"
ui_print "- 配置文件权限恢复成功"
chmod 771 $wz
chmod 660 $prefs
}