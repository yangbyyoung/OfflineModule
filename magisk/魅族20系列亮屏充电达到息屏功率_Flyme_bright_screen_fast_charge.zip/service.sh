#!/system/bin/sh
MODDIR=${0%/*}
sleep 60
echo 8 > /sys/class/meizu/charger/wired_level
sleep 10
chmod 444 /sys/class/meizu/charger/wired_level