# 高级显示
sed -i 's/<bool name=\"support_display_expert_mode\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_display_expert_mode\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_display_expert_mode\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_display_expert_mode\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

# AI大师画质引擎
sed -i 's/<bool name=\"support_screen_enhance_engine\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_screen_enhance_engine\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_screen_enhance_engine\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_screen_enhance_engine\">true<\/bool>' $MODPATH/system/etc/device_features/*

# 纸质护眼(包含部分参数)
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_value\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_value\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_min_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_min_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_max_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_max_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_value\">91.0<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_value\">91.0<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_texture\">18<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_texture\">18<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_min_texture\">0<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_min_texture\">0<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_max_texture\">35<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_max_texture\">35<\/bool>' $MODPATH/system/etc/device_features/*

# 真彩显示
sed -i 's/<bool name=\"support_truetone\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_truetone\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_truetone\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_truetone\">true<\/bool>' $MODPATH/system/etc/device_features/*

# 视频工具箱
# sed -i 's/<bool name=\"support_videobox_display_effect\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_videobox_display_effect\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_videobox_display_effect\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_videobox_display_effect\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

# 游戏工具箱
# 这一部分不知道为啥会导致人脸识别丢失，所以我注释掉了，反正我不用
# sed -i 's/<bool name=\"support_displayfeature_gamemode\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_displayfeature_gamemode\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i 's/<bool name=\"support_touchfeature_gamemode\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_touchfeature_gamemode\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i 's/<bool name=\"support_game_mi_time\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_game_mi_time\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_displayfeature_gamemode\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_displayfeature_gamemode\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_touchfeature_gamemode\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_touchfeature_gamemode\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_game_mi_time\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_game_mi_time\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

# hifi和dolby
# 避免音频bug，注释掉了
# sed -i 's/<bool name=\"support_hifi\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_hifi\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i 's/<bool name=\"support_dolby\">.*<\/bool>//g' $MODPATH/system/etc/device_features/* 
# sed -i 's/<bool name=\"support_dolby\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_hifi\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_dolby\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*

# 双人脸录入
# 纯纯加着玩，本身就支持，之前debug的时候用了一下
# sed -i 's/<bool name=\"support_multi_face_input\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
# sed -i 's/<bool name=\"support_multi_face_input\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_multi_face_input\">true<\/bool>' $MODPATH/system/etc/device_features/*
# sed -i '/<\/features>/i\    <bool name=\"support_multi_face_input\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
