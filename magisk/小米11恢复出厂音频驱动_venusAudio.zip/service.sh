#!/system/bin/sh
MODDIR=${0%/*}
sleep 7
pm uninstall --user 0 com.miui.misound
sleep 5
pm install --user 0 $MODPATH/system/app/MiSound/MiSound.apk