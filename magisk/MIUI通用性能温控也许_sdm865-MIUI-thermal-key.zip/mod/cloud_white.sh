#!/system/bin/sh
#sqlite3下载地址
#脚本编写@coolapk 10007
#https://keytoolazy.coding.net/p/hms-core/d/HMS-CORE/git/raw/master/Sqlite3/Sqlite1.zip
dir="${0%/*}"
MODPATH="${dir%/*}"

#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g' | head -n 1
}

function show_transfer_value(){
local file="${1}"
local separator="${2}"
test -z "${separator}" && separator=','
test -f "${file}" && cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' | sed ":a;N;\$!ba;s|\n|${separator}|g" 
}

function Running_clear_add_white(){
local exclude="$(show_transfer_value "${load_custom_file}" '\|' )"
local add_list="$(show_transfer_value "${load_custom_file}" '\n' )"
dumpsys deviceidle whitelist | cut -d',' -f2 | grep -Ev "${exclude}" | while read package ;do
	dumpsys deviceidle whitelist -"${package}"
done
for i in ${add_list};do dumpsys deviceidle whitelist +"${i}" ;done
}


if test "$(show_value '清空云控电池白名单' )" = "否" ;then
	exit 0
fi



export PATH="${0%/*}:/system/bin":$PATH

test "$(which -a sqlite3)" = "" && echo "请安装sqlite3！" && exit 1

file="/data/data/com.miui.powerkeeper/databases/cloud_configure.db"

load_custom_file="${MODPATH}/mod/云控部分可定义项/电池白名单.prop"
cloud_white_list="$(show_transfer_value "${load_custom_file}" ':' )"
Running_clear_add_white
killall -15 com.android.settings
Running_clear_add_white
killall -15 com.android.settings

sqlite3 "$file" << EOF
delete from GlobalFeatureTable where configureName='dozeWhiteListApps'; 
insert into GlobalFeatureTable (configureName,configureParam) values('dozeWhiteListApps','');
update GlobalFeatureTable set configureParam="${cloud_white_list}" where configureName='dozeWhiteListApps' ;
update GlobalFeatureTable set configureParam='com.tencent.mobileqq;com.tencent.mm;com.ximalaya.ting.android;com.tencent.qqmusic;com.kugou.android;com.netease.cloudmusic;com.tencent.karaoke;cn.kuwo.player;cmccwm.mobilemusic;com.changba;com.miui.player;com.fitbit.FitbitMobile;com.garmin.android.apps.connectmobile;com.huami.watch.hmwatchmanager' where configureName='FrozenNewWhiteList' ;
#update GlobalFeatureTable set configureParam='true' where configureName='miui_idle' ;
#update GlobalFeatureTable set configureParam='true' where configureName='miui_standby' ;
#update GlobalFeatureTable set configureParam='true' where configureName='broadcastAlarmControlStatus' ;
EOF




