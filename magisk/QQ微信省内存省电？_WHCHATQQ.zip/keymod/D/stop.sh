MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

TA(){
ProcessA=`ps -ef | grep -w "$MODPATH/keymod/A" |grep -v grep |awk '{print $2}'`
for i in $ProcessA;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
touch $MODPATH/keymod/D/akeep
done
}
TA

TB(){
ProcessB=`ps -ef | grep -w "$MODPATH/keymod/B" |grep -v grep |awk '{print $2}'`
for i in $ProcessB;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
touch $MODPATH/keymod/D/bkeep
done
}
TB