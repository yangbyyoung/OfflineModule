#!/system/bin/sh
MODDIR=${0%/*}
#关闭Magisk/LSP/edXP/MIUI桌面/mircs/WiFi/LMK日志/减少耗电消耗
RIRU_PATH="/data/adb/riru"
RIRU_PROP="$(magisk --path)/.magisk/modules/riru-core/module.prop"
TARGET="${RIRU_PATH}/modules"
LSPMISC_PATH=$(cat /data/adb/lspd/misc_path)
LSPBASE_PATH="/data/misc/$LSPMISC_PATH"
EDXPMISC_PATH=$(cat /data/adb/edxp/misc_path)
EDXPBASE_PATH="/data/misc/$EDXPMISC_PATH"
EDXPLOG_PATH="${EDXPBASE_PATH}/0/log"
LSP_NEW_LOG_PATH="/data/adb/lspd/log"
LSPLOG_PATH="${LSPBASE_PATH}/log"
#定义整型变量
a=1
while true
do
sleep 3
rm "${LSPLOG_PATH}/modules.log" 
rm "${LSPLOG_PATH}/all.log"
rm "${LSPBASE_PATH}/0/log/error.log" 
rm "${LSPBASE_PATH}/0/log/all.log" 
rm "${EDXPLOG_PATH}/error.log" 
rm "${EDXPLOG_PATH}/all.log" 
rm "${LSP_NEW_LOG_PATH}/modules.log" 
rm "${LSP_NEW_LOG_PATH}/all.log" 
mkdir -p /cache/
mkdir -p /data/user_de/0/com.miui.home/cache/
mkdir -p /data/media/0/
mkdir -p /data/vendor/
mkdir -p /sys/module/lowmemorykiller/parameters/
rm /cache/magisk.log
rm /data/user_de/0/com.miui.home/cache/debug_log
rm /data/media/0/JuphoonService
rm /data/vendor/wlan_logs
rm /sys/module/lowmemorykiller/parameters/debug_leve
a=$(($a+1))
echo $a
if [[ $a>5 ]]; then
break
fi
done
