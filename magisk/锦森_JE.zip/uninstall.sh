#!/system/bin/sh
chattr -i /data/system/mcd/df
pm clear com.xiaomi.joyose
pm clear com.xiaomi.powerchecker
am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
sleep 2s
am force-stop com.xiaomi.joyose
rm -f /data/cache/miui-thermal/*
rm -f /data/vendor/thermal/config/*
rm -f /data/system/package_cache/*
cp /vendor/etc/thermal*.conf /data/vendor/thermal/config/
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
pm enable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
pm enable com.xiaomi.joyose/predownload.PreDownloadJobScheduler
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
pm enable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm enable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm enable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver