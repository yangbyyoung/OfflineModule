#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
chmod -R 777 $MODDIR/mod
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
sed -i "s|/data/adb/[[:alpha:]]*[[:alpha:]]/|/data/adb/$Magisk_mod/|g" $MODDIR/mod/root
crond -c $MODDIR/mod

for i in $MODDIR/mod/*.sh ;do
	$i 2>/dev/null
done