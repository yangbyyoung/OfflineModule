SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""
# 移除旧模块
if [ -d "/data/adb/modules/scene_swap_controller/" ];then
rm -rf "/data/adb/modules/scene_swap_controller/"
fi
if [ -d "/data/adb/modules_update/scene_swap_controller/" ];then
rm -rf "/data/adb/modules_update/scene_swap_controller/"
fi
rm -rf /data/writeback
print_modname() {
  echo " **************************************** "
  echo " "
  echo "  ✔配置参数文件：/data/swap_config.conf "
  echo " "
  echo "  ✔模块log文件：/cache/swap.log "
  echo " "
  echo "  ✔你可以前往酷安关注我：“开心小阳光123” "
  echo " "
}
swap_config="/data/swap_config.conf"
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotalKB=${MemTotalStr:16:8}
update_overlay() {
  local prop="$1"
  local value="$2"
  sed -i "s/Name=\"$prop\" Value=\".*\"/Name=\"$prop\" Value=\"$value\"/" $overlay_file
}
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $TMPDIR/system.prop
}
get_prop() {
  cat $swap_config | grep "^$1=" | cut -f2 -d '='
}

# 检测内核支持的压缩方式
check_result1=`cat /sys/block/zram0/comp_algorithm | grep lz4`
check_result2=`cat /sys/block/zram0/comp_algorithm | grep zstd`
if [[ "$check_result1" != "" ]]; then
  comp_algorithm=lz4
elif [[ "$check_result2" != "" ]]; then
  comp_algorithm=zstd
else
  comp_algorithm=lzo
fi

# 内存管理方式
sdk_version=$(getprop ro.build.version.release)
if [[ "$sdk_version" == "13" ]]; then
use_ram=psi1
else
use_ram=lmk
fi

# 创建配置参数
swap=false
swap_size=0
swap_priority=-2
swap_use_loop=false
zram_enable=true
zram_size=6144
zram_writeback=true
oom_kill=false
swappiness=60
min_free_kbytes=4096
extra_free_kbytes=8192
kswapd_cpus=default
watermark_scale_factor=60
writeback_force=false
writeback_size=3072
writeback_sleep=10
writeback_number=10
writeback_lock=true
writeback_writeback=10

# ①询问Scene版本号
echo ""
echo " **************************************** "
echo ""
echo "  ★是否正在使用5.0.3以下旧版本Scene（1/4） "
echo ""
echo "  △若按键无反应请更新面具版本或联系作者"
echo ""
echo "  ☞音量加：是的 "
echo ""
echo "  ☞音量减：不是 "
echo ""
volume=1
action=1
while [ $volume == 1 ]; do
action=`getevent -lqc 1`
if [[ "${action}" == "*KEY_VOLUMEUP*" ]];then 
volume=0
echo "  ✔已选择：是的 "
update_system_prop vtools.swap.controller magisk
elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]];then
volume=0
echo "  ✔已选择：不是 "
fi
done
echo ""
echo " **************************************** "

# ②保留旧版模块参数
swap_config="/data/swap_config.conf"
volume=1
action=1
sleep 0.75
if [[ -f $swap_config ]]; then
echo ""
echo "  ★是否保留旧模块参数（2/4） "
echo ""
echo "  ☞音量加：保留 "
echo ""
echo "  ☞音量减：不保留 "
echo ""
while [ $volume == 1 ]; do
action=`getevent -lqc 1`
if [[ "${action}" == "*KEY_VOLUMEUP*" ]];then 
volume=0
echo "  ✔已选择：保留 "
# 读取参数
current_swap=$(get_prop swap)
current_swap_size=$(get_prop swap_size)
current_swap_priority=$(get_prop swap_priority)
current_swap_use_loop=$(get_prop swap_use_loop)
current_zram_enable=$(get_prop zram)
current_zram_size=$(get_prop zram_size)
current_zram_writeback=$(get_prop zram_writeback)
current_oom_kill=$(get_prop oom_kill)
current_comp_algorithm=$(get_prop comp_algorithm)
current_use_ram=$(get_prop use_ram)
current_swappiness=$(get_prop swappiness)
current_min_free_kbytes=$(get_prop min_free_kbytes)
current_extra_free_kbytes=$(get_prop extra_free_kbytes)
current_watermark_scale_factor=$(get_prop watermark_scale_factor)
current_kswapd_cpus=$(get_prop kswapd_cpus)
current_writeback_force=$(get_prop writeback_force)
current_writeback_size=$(get_prop writeback_size)
current_writeback_sleep=$(get_prop writeback_sleep)
current_writeback_number=$(get_prop writeback_number)
current_writeback_lock=$(get_prop writeback_lock)
current_writeback_writeback=$(get_prop writeback_writeback)
# 应用参数
if [[ "$current_swap" != "" ]]; then
swap="$current_swap"
fi
if [[ "$current_swap_size" != "" ]]; then
swap_size="$current_swap_size"
fi
if [[ "$current_swap_priority" != "" ]]; then
swap_priority="$current_swap_priority"
fi
if [[ "$current_swap_use_loop" != "" ]]; then
swap_use_loop="$current_swap_use_loop"
fi
if [[ "$current_zram_enable" != "" ]]; then
zram_enable="$current_zram_enable"
fi
if [[ "$current_zram_size" != "" ]]; then
zram_size="$current_zram_size"
fi
if [[ "$current_zram_writeback" != "" ]]; then
zram_writeback="$current_zram_writeback"
fi
if [[ "$current_oom_kill" != "" ]]; then
oom_kill="$current_oom_kill"
fi
if [[ "$current_comp_algorithm" != "" ]]; then
comp_algorithm="$current_comp_algorithm"
fi
if [[ "$current_use_ram" != "" ]]; then
use_ram="$current_use_ram"
fi
if [[ "$current_swappiness" != "" ]]; then
swappiness="$current_swappiness"
fi
if [[ "$current_min_free_kbytes" != "" ]]; then
min_free_kbytes="$current_min_free_kbytes"
fi
if [[ "$current_extra_free_kbytes" != "" ]]; then
extra_free_kbytes="$current_extra_free_kbytes"
fi
if [[ "$current_watermark_scale_factor" != "" ]]; then
watermark_scale_factor="$current_watermark_scale_factor"
fi
if [[ "$current_kswapd_cpus" != "" ]]; then
kswapd_cpus="$current_kswapd_cpus"
fi
if [[ "$current_writeback_force" != "" ]]; then
writeback_force="$current_writeback_force"
fi
if [[ "$current_writeback_size" != "" ]]; then
writeback_size="$current_writeback_size"
fi
if [[ "$current_writeback_sleep" != "" ]]; then
writeback_sleep="$current_writeback_sleep"
fi
if [[ "$current_writeback_number" != "" ]]; then
writeback_number="$current_writeback_number"
fi
if [[ "$current_writeback_lock" != "" ]]; then
writeback_lock="$current_writeback_lock"
fi
if [[ "$current_writeback_writeback" != "" ]]; then
writeback_writeback="$current_writeback_writeback"
fi
elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]];then
volume=0
echo "  ✔已选择：不保留 "
fi
done
echo ""
else
echo ""
echo "  ★未发现旧版模块配置参数文件☞将自动跳过（2/3）"
echo ""
fi
echo " **************************************** "

# ③安装内存扩展回写
if [[ -f '/sys/block/zram0/backing_dev' ]]; then
volume=1
action=1
sleep 0.75
echo ""
echo "  ★是否安装内存扩展回写（3/4） "
echo ""
echo "  ☞音量加：安装 "
echo ""
echo "  ☞音量减：不安装 "
echo ""
while [ $volume == 1 ]; do
action=`getevent -lqc 1`
if [[ "${action}" == "*KEY_VOLUMEUP*" ]];then 
volume=0
echo "  ✔已选择：安装 "
kqhx=2
elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]];then
volume=0
echo "  ✔已选择：不安装 "
kqhx=1
fi
done
echo ""
echo " **************************************** "
else
echo ""
echo "  ★当前设备内核不支持回写功能☞不影响使用（3/3）"
echo ""
echo "  ✔模块有内存管理优化、VM参数优化等其他多项功能 "
echo ""
echo "  ✔这些功能是所有设备通用的，你可以正常使用本模块 "
echo ""
echo " **************************************** "
kqhx=0
fi

# ④关注作者的酷安
volume=1
action=1
sleep 0.75
echo ""
echo "  ★是否关注作者酷安（4/4） "
echo ""
echo "  ☞音量加：关注 "
echo ""
echo "  ☞音量减：不关注 "
echo ""
while [ $volume == 1 ]; do
action=`getevent -lqc 1`
if [[ "${action}" == "*KEY_VOLUMEUP*" ]];then 
volume=0
echo "  ✔已选择：关注（感谢关注～） "
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
if [[ "$coolapkTesting" != "" ]];then
am start -d 'coolmarket://u/3520868' >/dev/null 2>&1
fi
elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]];then
volume=0
echo "  ✔已选择：不关注（好的吧～） "
fi
done
echo ""

on_install() {
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

oom_kill_config="
# oom_kill杀后台机制（仅限lmk可开启）
# 当运存爆满时，将自动触发杀后台防死机，若使用lmk易死机，建议开启。
# 注意：开启oom_kill杀后台机制后，将与任何有修改oom功能的模块冲突！
oom_kill=$oom_kill
"

use_ram_config="
# 系统内存管理方式（请根据需要进行选择）
# 保后台能力：lmk > psi1 > psi2 > psi3
# lmk偏向保后台，psi偏向流畅度，其中的psi3为省电优化
use_ram=$use_ram
"

if [ "$kqhx" == "2" ]; then
zram_writeback_config="
---------------------------------------------------------------------------
# 内存扩展（Writeback）
# 模块的智能内存扩展回写功能，由模块配置回写块并进行智能回写（需关闭系统的内存扩展，并将模块的zram配置为true，填default表示保持系统默认配置）
zram_writeback=$zram_writeback

# 强制开启智能内存扩展（一般不需要）
# 若关闭系统的内存扩展仍无法使用，可尝试开启
writeback_force=$writeback_force

# 内存扩展回写块大小，建议填写：2048-8192
# 修改后需手动删除/data/writeback回写块文件
writeback_size=$writeback_size

# 检测切换进程的间隔，建议填写：5-20
writeback_sleep=$writeback_sleep

# 进行回写需切换的进程数，建议填写：5-20
writeback_number=$writeback_number

# 达到指定回写次数后，true表示锁屏大回写一次，false表示立即大回写一次
writeback_lock=$writeback_lock

# 累计回写阈值，建议填写：5-20
# writeback_lock为true时，表示达到小回写次数后锁屏大回写一次
# writeback_lock为false时，表示达到小回写次数后立即大回写一次
# 填写0表示每次都是小回写，填写1表示每次都是大回写
writeback_writeback=$writeback_writeback
"
elif [ "$kqhx" == "1" ]; then
zram_writeback_config="
---------------------------------------------------------------------------
# 内存扩展回写功能未安装，如需使用可重新覆盖安装本模块
"
rm -f /data/writeback
elif [ "$kqhx" == "0" ]; then
zram_writeback_config="
# 当前设备内核不支持回写功能（不影响使用）
# 模块有内存管理优化、VM参数优化等其他多项功能
# 这些功能是所有设备通用的，你可以正常使用本模块
"
fi
echo " **************************************** "
echo ""
echo "- Installing "

echo "★模块版本1.6，修改参数后需重启手机，true为开启、false为关闭
---------------------------------------------------------------------------

# 配置swapfile（不推荐）
swap=$swap

# swap大小[MB]（不推荐）
# 修改后需手动删除/data/swapfile文件
swap_size=$swap_size

# swapfile使用顺序（不推荐）
# 0(与zram同时使用)、-2(用完zram再使用)、5(优于zram使用)
swap_priority=$swap_priority

# swapfile挂载为回环设备（不推荐）
swap_use_loop=$swap_use_loop

---------------------------------------------------------------------------

# 配置zram
# 注意：设为false表示保持系统默认配置，如需关闭系统默认开启的zram，应设为true并配置zram_size为0
zram=$zram_enable

# zram大小 [MB]（一般不超过8G）
zram_size=$zram_size

# zram压缩算法（模块在安装时会自动选择压缩方式）
comp_algorithm=$comp_algorithm

# 使用SWAP的积极性（一般填写0-100）
swappiness=$swappiness

# 保留物理内存 [kbytes]（数值越大越容易触发内存回收）
min_free_kbytes=$min_free_kbytes
extra_free_kbytes=$extra_free_kbytes

# 内存水位线（数值越大内存回收越积极）
watermark_scale_factor=$watermark_scale_factor

# 设置kswapd进程cpu亲和
# 需要填写8位数字，填default表示保持系统默认设置
# 例如填写：00001111，表示使用CPU4~7（也就是使用中大核）
kswapd_cpus=$kswapd_cpus
$oom_kill_config$use_ram_config$zram_writeback_config"> $swap_config
}
