#!/system/bin/sh
MODDIR=${0%/*}

echo "

#COS
#SA测试
persist.oplus.network.nr_mode_test=false
#SA城市白名单
persist.oplus.radio.loc_control_switch=false
persist.sys.oplus.radio.loc_control_switch=false
#SA回落未返回
persist.oplus.software.radio.sa_rat_control=1
persist.sys.oplus.software.radio.sa_rat_control=1
#TAC变化尝试恢复SA
persist.oplus.software.radio.sa_tac_control=1
persist.sys.oplus.software.radio.sa_tac_control=1
#灭屏回退SA
persist.oplus.software.radio.screen_off_disable_sa_enabled=0
persist.sys.oplus.software.radio.screen_off_disable_sa_enabled=0
#SA注册失败回退SA
persist.oplus.software.radio.sa_reg_timeout_enabled=false
persist.sys.oplus.software.radio.sa_reg_timeout_enabled=false
#查询SA状态失败回退SA
persist.oplus.software.radio.backoff_sa_cause_network_reject=false
persist.sys.oplus.software.radio.backoff_sa_cause_network_reject=false
#PING SA/PING失败回退SA
persist.oplus.software.radio.sa_pingpong_control_disabled=false
persist.sys.oplus.software.radio.sa_pingpong_control_disabled=false
#SA数据拨号失败回退SA
persist.oplus.software.radio.data_call_control_disabled=ture
persist.sys.oplus.software.radio.data_call_control_disabled=ture
#关闭5G DUMP测试
persist.oplus.software.radio.disable_5g_nr_5gdump=false
persist.sys.oplus.software.radio.disable_5g_nr_5gdump=false
#IMS通信注册异常回退SA
persist.oplus.software.radio.sa_ims_control_disabled=false
persist.sys.oplus.software.radio.sa_ims_control_disabled=false
#禁用SA信号弱退回4G
persist.oplus.radio.enable_weak_signal_backoff=0
persist.sys.oplus.radio.enable_weak_signal_backoff=0
#WIFI通话回退SA
persist.oplus.software.radio.wfc_disable_nrsa=false
persist.sys.oplus.software.radio.wfc_disable_nrsa=false
#DND异常回退SA
persist.oplus.software.radio.smart5g_rtt_check_sa=false
persist.sys.oplus.software.radio.smart5g_rtt_check_sa=false
#强制恢复SA
persist.oplus.software.radio.recovery_nrmode=true
persist.sys.oplus.software.radio.recovery_nrmode=true

#屏蔽SA最小值
persist.oplus.network.sa_screen_off_min=0
persist.oplus.network.sa_nw_rej_sec=0
persist.oplus.network.sa_pingpong_duration=0
persist.oplus.network.sa_reg_timeout_min=0
persist.oplus.network.sa_tac_change_min=0

persist.sys.assert.panic=false
persist.sys.oplus.radio.backoff_sa_cause_weak_signal=false
persist.sys.oplus.radio.backoff_sa_cause_weak_signal.config=false
persist.sys.oplus.radio.weak_sa.backoff=false
persist.sys.oplus.radio.weak_sa.backoff_daily_count=0
persist.sys.oplus.radio.weak_sa.dot_daily_count=0

ro.oplus.radio.disable_sa_dump_times=0
ro.oplus.radio.tac_changed_timer=0
ro.oplus.radio.sa_backoff_recover_time=3

persist.sys.oplus.operator.opta=0
persist.vendor.radio.lte_con_stat_delay_timer=0
persist.vendor.radio.scg_con_stat_delay_timer=0

" > /data/COS_SA.conf

chmod 777 /data/COS_SA.conf

sysctl -p /data/COS_SA.conf

ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 20;
done

