#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

target_thermal="$(show_value '温控配置')"
conf_file="${MODPATH}/thermal/$target_thermal.conf"


if test -f "$conf_file" ;then
	echo "- 您已选择 [ $target_thermal ℃ ]！"
	echo -e "\n∞————————————————————————∞\n"
	cp -rf "$conf_file" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
else
	echo "- 不存在配置文件！"
	echo "- 自动选择46℃温控文件！"
	echo -e "\n∞————————————————————————∞\n"
	cp -rf "${MODPATH}/thermal/46.conf" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
fi


sed -i '/description=/d' "$MODPATH/module.prop"
sed -i "/author=.*/a\description= 当前已选择[ $target_thermal ]。温度配置可以在[ 模块目录/配置.prop ]下选择，有[ 43℃，46℃，48℃，无限制 ]几种选择，更改完执行[ 模块目录/service.sh ]就行，无需重启。" "$MODPATH/module.prop"


