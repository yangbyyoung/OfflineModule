#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

# 下面，你也可以添加一些自己的代码
# 最大功耗，，0是最大的，数字大就小
echo "0" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel

# 默认功耗，数字6哪里根据自己的GPU频率表设置，记住一点是从0开始数，不是从1开始数的
echo "4" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel