#是否全权接管安装流程
#SKIPUNZIP=1

#替换或新增文件放入system文件夹
#vendor product system-ext等目录前加system/
#若需启动时执行命令的使用post-fs-data.sh或service.sh
#修改系统属性build.prop,使用system.prop

# 以下为精简列表，填入文件夹路径而不是文件
# 一行一个，例system/app/yomol/
REPLACE="
/system/system_ext/app/Stk/
/system/product/priv-app/dmp/
/system/product/app/GlobalSearch/
/system/system_ext/app/OBrain/
/system/product/app/Browser/
/system/product/app/Pictorial/
/system/product/app/Instant/
/system/system_ext/app/LogKit/
/system/product/app/BaiduInput_S_Product/
/system/product/app/OplusOperationManual/
/system/product/app/ADS/
/system/system_ext/app/Shelper/
/system/product/app/OplusThirdKit/
/system/product/app/ChildrenSpace/
/system/product/app/OplusSecurityKeyboard/
/system/product/app/FloatAssistant/
/system/system_ext/app/OTrace/
/system/app/Traceur/
"
# 此文件将被安装脚本在 util_functions.sh 之后 source 化（设置为环境变量）
# 若需自定义操作, 请在此以函数方式定义它，然后在update-binary调用这些函数
# 不要直接向update-binary添加代码，因为这样不方便模块迁移
# 尽量不要对update-binary文件做其他修改，尽量只在其中执行函数调用

#以下为清理精简应用的数据
#来自酷安 @代号10007 的图文
rm rf /data/system/package_cache/*
rm rf /data/dalvik-cache/*/system@*@Stk*
rm rf /data/dalvik-cache/*/system@*@dmp*
rm rf /data/dalvik-cache/*/system@*@GlobalSearch*
rm rf /data/dalvik-cache/*/system@*@OBrain*
rm rf /data/dalvik-cache/*/system@*@Browser*
rm rf /data/dalvik-cache/*/system@*@Pictorial*
rm rf /data/dalvik-cache/*/system@*@Instand*
rm rf /data/dalvik-cache/*/system@*@LogKit*
rm rf /data/dalvik-cache/*/system@*@BaiduInput_S_Product*
rm rf /data/dalvik-cache/*/system@*@OplusOperationManual*
rm rf /data/dalvik-cache/*/system@*@ADS*
rm rf /data/dalvik-cache/*/system@*@Shelper*
rm rf /data/dalvik-cache/*/system@*@OplusThirdKit*
rm rf /data/dalvik-cache/*/system@*@ChildrenSpace*
rm rf /data/dalvik-cache/*/system@*@OplusSecurityKeyboard*
rm rf /data/dalvik-cache/*/system@*@FloatAssistant*
rm rf /data/dalvik-cache/*/system@*@OTrace*
rm rf /data/dalvik-cache/*/system@*@Traceur*
print_modname() {
ui_print "
**************************************************************
- 模块: $MODNAME
- 模块ID: $MODID
- 作者: $MODAUTHOR
- 介绍: $MODdescription
**************************************************************
 "
}
