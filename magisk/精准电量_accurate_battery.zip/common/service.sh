#!/system/bin/sh
MODDIR=${0%/*}
capacity_file=capacity_file
nohup ${MODDIR}/accurate_battery ${capacity_file} &
