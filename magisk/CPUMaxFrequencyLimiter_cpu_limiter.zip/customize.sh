CFG_PATH="/sdcard/Android/naki/clmt/clmt.conf"
LOG_PATH="/sdcard/Android/naki/clmt/clmt.log"
UPERF_PATH="/data/adb/modules/uperf"

if [[ -d $UPERF_PATH ]] && [[ ! -f $UPERF_PATH/disable ]]; then
    if [[ -z $(grep Limiter $UPERF_PATH/module.prop) ]]; then
        echo
        echo "- 禁止与Uperf同时使用！"
        echo
        exit 1
    fi
fi

echo
echo "- 配置文件位于 $CFG_PATH"
echo "- 日志文件位于 $LOG_PATH"
echo "- 必须查看配置文件内注释！"
echo

mkdir -p /sdcard/Android/naki/clmt

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/cpu_limiter 0 0 0755 0755

note="
# 系统温度墙的实现方式劣化处理器能效\n
# 此模块实现的温度墙，在核心温度略低\n
# 并提供相同性能时，功耗相比默认更低\n
# 如果只想最大化性能，保留默认值即可\n
# 此模块不兼容任何Uperf等第三方调度\n\n

# 注意！注意！此模块并不会修改系统温度墙！\n
# 填写值不得高于系统温度墙！否则将无效果！\n
# 某些机型（小米）可能有不同的温度墙\n
# 需自行测试温度墙数值从而最大化性能\n\n

# targetTemp为目标核心温度\n
# 其余变量为不同模式的温度墙\n
# 填写值需x1000，如95°C=95000"

tempUser=$(grep targetTemp= $CFG_PATH)
tempUserM1=$(grep powersave= $CFG_PATH)
tempUserM2=$(grep balance= $CFG_PATH)
tempUserM3=$(grep performance= $CFG_PATH)
tempUserM4=$(grep fast= $CFG_PATH)
tempPresetM1="powersave=60000"
tempPresetM2="balance=75000"
tempPresetM3="performance=95000"
tempPresetM4="fast=85000"

if [[ -z $tempUser ]]; then
    tempUser=$(grep targetTemp= /data/cpu_limiter.conf)
    tempUserM1=$(grep powersave= /data/cpu_limiter.conf)
    tempUserM2=$(grep balance= /data/cpu_limiter.conf)
    tempUserM3=$(grep performance= /data/cpu_limiter.conf)
    tempUserM4=$(grep fast= /data/cpu_limiter.conf)
fi

if [[ -z $tempUser ]]; then
    tempUser="targetTemp=95000"
fi

for i in 1 2 3 4; do
    eval tmp=\$tempUserM${i}
    if [[ -z $tmp ]]; then
        eval tmp=\$tempPresetM${i}
        eval tempUserM${i}=${tmp}
    fi
done

output="$note\n\n
$tempUser\n
$tempUserM1\n
$tempUserM2\n
$tempUserM3\n
$tempUserM4\n"

rm /data/cpu_limiter.conf
echo -e $output | sed "s/ //g" | sed "s/#/# /g" > $CFG_PATH
