export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

ads="
/data/media/*/sina/weibo/.weiboadcache
/data/media/*/sina/weibo/.weibo_ad_universal_cache
/data/media/*/sina/weibo/.weibo_refreshad_cache
/data/media/*/sina/weibo/.weibo_video_cache_new

/data/media/*/Android/data/com.ss.android.article.news/splashCache

/data/media/*/Android/data/com.coolapk.market/cachett_ad

/data/media/*/netease/cloudmusic/Ad

/data/media/*/kugou/.splash

/data/media/*/Android/data/com.ss.android.ugc.aweme/splashCache

/data/media/*/Android/data/com.tencent.weishi/splash_cache

/data/media/*/Tencent/MobileQQ/splahAD

/data/media/*/Tencent/TMAssistantSDK

/data/media/*/autonavi/splash
/data/media/*/autonavi/afpSplash

/data/media/*/Android/data/com.gotokeep.keep/files/keep/ads/

/data/data/com.tencent.qqmusic/files/tad_cache/

/data/media/*/Android/data/com.handsgo.jiakao.android/cache/reward_video_cache_*
/data/media/*/Android/data/com.handsgo.jiakao.android/cache/splash_ad_cache
/data/data/com.handsgo.jiakao.android/cache/GDTDOWNLOAD/image
/data/data/com.handsgo.jiakao.android/cache/image_manager_disk_cache

/data/data/com.tencent.mtt/files/tad_cache/splash_img/jpeg

/data/data/com.yyets.pro/app_ad
/data/data/com.douban.frodo/cache/douban_ad

/data/media/*/netease/cloudmusic/Ad
/data/media/*/netease/adcache
/data/media/*/Android/data/com.netease.cloudmusic/cache/Ad

/data/data/com.tencent.qqmusic/files/tad_cache
/data/data/com.tencent.qqmusic/app_adnet
/data/media/*/qqmusic/splash

/data/media/*/sina/weibo/.weiboadcache
/data/media/*/sina/weibo/.weibo_ad_universal_cache
/data/media/*/sina/weibo/.weibo_refreshad_cache
/data/media/*/sina/weibo/.weibo_video_cache_new
/data/media/*/sina/weibo/storage/biz_keep/.weibo_ad_universal_cache
/data/media/*/sina/weibo/storage/biz_keep/.weibo_refreshad_cache

/data/media/*/Android/data/com.ss.android.ugc.aweme/awemeSplashCache
/data/media/*/Android/data/com.ss.android.ugc.aweme/liveSplashCache
/data/media/*/Android/data/com.ss.android.ugc.aweme/splashCache
/data/data/com.ss.android.ugc.aweme/files/.umeng
/data/data/com.ss.android.ugc.aweme/files/umeng_it.cache
/data/data/com.ss.android.ugc.aweme/files/umeng_it.cache
/data/data/com.ss.android.ugc.aweme/files/.umeng
/data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_BINDumeng:*.xml
/data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_SDK_CHANNEL.xml
/data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_SDK.xml
/data/data/com.ss.android.ugc.aweme/shared_prefs/umeng_general_config.xml
/data/data/com.ss.android.ugc.aweme/shared_prefs/umeng_message_state.xml
"

function cads(){
	if test -e "$1" ;then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function recoveryads(){
	if test -e "$1" ;then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

function cadsclear(){
	for i in $ads;do
		file=`find "$i" 2> /dev/null`
		cads $file 2> /dev/null
	done
}

function readclear(){
	for i in $ads;do
		file=`find "$i" 2> /dev/null`
		recoveryads $file 2> /dev/null
	done
}


cadsclear

