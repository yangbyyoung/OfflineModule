#!/system/bin/sh
# shellcheck disable=SC2086
MODDIR=${0%/*}
RVPATH=${NVBASE}/rvhc/com.google.android.youtube_rv.apk
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 1; done
until [ "$(getprop init.svc.bootanim)" = stopped ]; do sleep 1; done
sleep 3

err() {
	cp -n $MODDIR/module.prop $MODDIR/err
	sed -i "s/^des.*/description=⚠️ Module is inactive: ${1}/g" $MODDIR/module.prop
}

BASEPATH=$(pm path com.google.android.youtube | grep base)
BASEPATH=${BASEPATH#*:}
if [ $BASEPATH ]; then
	if [ -d ${BASEPATH%base.apk}lib ]; then
		VERSION=$(dumpsys package com.google.android.youtube | grep -m1 versionName)
		if [ ${VERSION#*=} = 18.03.36 ]; then
			grep com.google.android.youtube /proc/mounts | while read -r line; do
				mp=${line#* }
				mp=${mp%% *}
				umount -l ${mp%%\\*}
			done
			if chcon u:object_r:apk_data_file:s0 $RVPATH; then
				mount -o bind $RVPATH $BASEPATH
				am force-stop com.google.android.youtube
				[ -f $MODDIR/err ] && mv -f $MODDIR/err $MODDIR/module.prop
			else
				err "mount failed"
			fi
		else
			err "version mismatch (${VERSION#*=})"
		fi
	else
		err "invalid installation"
	fi
else
	err "app not installed"
fi
