# 安装时显示的模块名称
mod_name="自动跳过"
# 模块介绍
mod_install_desc="一个自动跳过广告的软件"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"


# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{

mkdir -p $MODPATH/system
cp -rf $MOD_FILES_DIR/system/* $MODPATH/system
    set_perm_recursive  $MODPATH  0  0  0755  0644
    
    return 0
}

mod_install_no()
{
    return 0
}