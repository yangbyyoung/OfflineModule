set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/xz 0 0 0755 0755