targetdir=/data/media/0/Android/Magisk备份
test ! -e $targetdir && mkdir -p $targetdir
cp -rf $MODPATH/keymod/magiskbackup.sh $targetdir

for i in `find $targetdir -iname "path.sh" `;do
	cp -rf $MODPATH/keymod/path.sh "$i"
done
