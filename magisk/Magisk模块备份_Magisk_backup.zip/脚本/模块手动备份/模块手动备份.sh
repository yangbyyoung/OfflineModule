
MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

source ${0%/*}/path.sh

test ! -e $Backup_path2 && mkdir -p ${Backup_path2%/*}
cd /data/adb
tar -cf $Backup_path2 * --exclude=magisk --exclude=modules_update --exclude=lite_modules_update
test $? == 0 && echo "备份完成！"
