#模块脚本来自酷安@相见即是缘，感谢😘！
cd /data/adb/modules
for module_id in $(ls);do
if [[ "$module_id" != "sqlite_Amktiao" ]];then
let id++
module_name=$(cat $module_id/module.prop | grep 'name')
module_author=$(cat $module_id/module.prop | grep 'author')
module_description=$(cat $module_id/module.prop | grep 'description')
if [ -e "$module_id/system/media/theme/default/framework-res" ];then
ui_print " "
ui_print " "
ui_print "－****************************** "
ui_print "－名称：${module_name:5}"
ui_print "－作者：${module_author:7}"
ui_print "－简介：${module_description:12}"
ui_print "－此模块与本模块冲突"
ui_print "－正在合并两个模块内容"
ui_print "－不用担心"
ui_print "－****************************** "
file=$MODPATH/system/media/theme/default/framework-res/theme_values.xml
file2=$MODPATH/system/media/theme/default/framework-res/nightmode/theme_values.xml
mkdir -p $MODPATH/system/media/theme/default/framework-res/nightmode
unzip -o $module_id/system/media/theme/default/framework-res -d $MODPATH/system/media/theme/default/framework-res >&2
rm -rf $module_id/system/media/theme/default/framework-res
if [[ ! -e $file ]];then
cat <<EOF>> $file
<?xml version="1.0" encoding="utf-8"?>
<MIUI_Theme_Values>
<string name="db_default_sync_mode">OFF</string>
<string name="db_wal_sync_mode">OFF</string>
</MIUI_Theme_Values>
EOF
cat <<EOF>> $file2
<?xml version="1.0" encoding="utf-8"?>
<MIUI_Theme_Values>
<string name="db_default_sync_mode">OFF</string>
<string name="db_wal_sync_mode">OFF</string>
</MIUI_Theme_Values>
EOF
elif [[ -e $file ]];then
sed -i 's/<string name=\"db_default_sync_mode\">.*<\/string>//g'  $file
sed -i 's/<string name=\"db_wal_sync_mode\">.*<\/string>//g'  $file
sed -i 's/<string name=\"db_default_sync_mode\">.*<\/string>//g'  $file2
sed -i 's/<string name=\"db_wal_sync_mode\">.*<\/string>//g'  $file2
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_default_sync_mode\">OFF<\/string>' $file
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_wal_sync_mode\">OFF<\/string>' $file
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_default_sync_mode\">OFF<\/string>' $file2
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_wal_sync_mode\">OFF<\/string>' $file2
fi
fi
fi
done


cd /data/adb/modules_update
for module_id in $(ls);do
if [[ "$module_id" != "sqlite_Amktiao" ]];then
let id++
module_name=$(cat $module_id/module.prop | grep 'name')
module_author=$(cat $module_id/module.prop | grep 'author')
module_description=$(cat $module_id/module.prop | grep 'description')
if [ -e "$module_id/system/media/theme/default/framework-res" ];then
ui_print " "
ui_print " "
ui_print "－****************************** "
ui_print "－名称：${module_name:5}"
ui_print "－作者：${module_author:7}"
ui_print "－简介：${module_description:12}"
ui_print "－此模块与本模块冲突"
ui_print "－正在合并两个模块内容"
ui_print "－不用担心"
ui_print "－****************************** "
file=$MODPATH/system/media/theme/default/framework-res/theme_values.xml
file2=$MODPATH/system/media/theme/default/framework-res/nightmode/theme_values.xml
mkdir -p $MODPATH/system/media/theme/default/framework-res/nightmode
unzip -o $module_id/system/media/theme/default/framework-res -d $MODPATH/system/media/theme/default/framework-res >&2
rm -rf $module_id/system/media/theme/default/framework-res
if [[ ! -e $file ]];then
cat <<EOF>> $file
<?xml version="1.0" encoding="utf-8"?>
<MIUI_Theme_Values>
<string name="db_default_sync_mode">OFF</string>
<string name="db_wal_sync_mode">OFF</string>
</MIUI_Theme_Values>
EOF
cat <<EOF>> $file2
<?xml version="1.0" encoding="utf-8"?>
<MIUI_Theme_Values>
<string name="db_default_sync_mode">OFF</string>
<string name="db_wal_sync_mode">OFF</string>
</MIUI_Theme_Values>
EOF
elif [[ -e $file ]];then
sed -i 's/<string name=\"db_default_sync_mode\">.*<\/string>//g'  $file
sed -i 's/<string name=\"db_wal_sync_mode\">.*<\/string>//g'  $file
sed -i 's/<string name=\"db_default_sync_mode\">.*<\/string>//g'  $file2
sed -i 's/<string name=\"db_wal_sync_mode\">.*<\/string>//g'  $file2
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_default_sync_mode\">OFF<\/string>' $file
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_wal_sync_mode\">OFF<\/string>' $file
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_default_sync_mode\">OFF<\/string>' $file2
sed -i '/<\/MIUI_Theme_Values>/i\    <string name=\"db_wal_sync_mode\">OFF<\/string>' $file2
fi
fi
fi
done