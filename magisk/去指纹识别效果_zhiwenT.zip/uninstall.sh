#!/system/bin/sh

# 清理列表

rm -rf /data/adb/zhiwen/
