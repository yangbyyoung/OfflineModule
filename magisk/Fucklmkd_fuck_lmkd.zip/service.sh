MODDIR=${0%/*}
echo 1280000 > /proc/sys/vm/extra_free_kbytes
echo 256 > /proc/sys/vm/watermark_scale_factor