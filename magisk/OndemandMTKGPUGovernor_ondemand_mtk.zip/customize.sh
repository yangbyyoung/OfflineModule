CFG_PATH="/sdcard/Android/naki/od_mtk/od_mtk.conf"
TBL_PATH="/proc/gpufreqv2/stack_working_opp_table"

echo
echo "- 配置文件位于 $CFG_PATH 需自行调试"
echo "- 最终保留的频率建议不大于15个"
echo "- 配置文件修改后立即生效"
echo
echo "- 该模块将在开机60秒后启动"
echo "- 若遇到稳定性问题，可在开机后60秒内及时禁用模块"
echo
echo "- 建议搭配AsoulOpt使用，此模块与其联动"
echo "- 可智能判定目前场景所需GPU性能，降低功耗"
echo "- 且AsoulOpt亦可提升游戏表现"
echo
echo "- 如果你在使用过程中遇到了"
echo "- 不生效、死机、闪屏、突发卡顿"
echo "- 则代表频率/电压配置有误"
echo "- 必须详细阅读 $CFG_PATH 内注释"
echo

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/ondemand_mtk 0 0 0755 0755

mkdir -p /sdcard/Android/naki/od_mtk

soc=$(getprop ro.hardware)
if [[ "$soc" != "mt6983" ]] && [[ "$soc" != "mt6895" ]]; then
  echo
  echo
  echo "此模块仅适用于天玑8100/9000"
  echo
  echo

  exit 1
fi

defVolts=$(cat $TBL_PATH | awk '{print $5}')
defFreqs=$(cat $TBL_PATH | awk '{print $3}')

while read line
do
    line=$(echo $line | awk '{print $3$5}' | sed "s/.$//" | sed "s/,/ /g")
    defOpps="$defOpps\n$line"
done < $TBL_PATH

while read line
do
    if [[ -z $(echo $line | grep "#") ]] && [[ -n "$line" ]]; then
        userOpps="$userOpps\n$line"
    fi
done < $CFG_PATH

if [[ -z $userOpps ]]; then
    while read line
    do
        if [[ -z $(echo $line | grep "#") ]] && [[ -n "$line" ]]; then
            userOpps="$userOpps\n$line"
        fi
    done < /sdcard/Android/od_mtk/od_mtk.conf

    rm -rf /sdcard/Android/od_mtk
fi

if [[ -z $userOpps ]]; then
    while read line
    do
        if [[ -z $(echo $line | grep "#") ]] && [[ -n "$line" ]]; then
            userOpps="$userOpps\n$line"
        fi
    done < /data/gpu_freq_table.conf
fi

note="
# Volt(GPU电压) 建议是以下值之一\n
# $defVolts\n\n

# 天玑9000不支持低于50000的电压\n
# 相同电压下不同频率能效相同，但最大功耗不同\n
# 例如，在3DMark Wild Life中，349MHz约3.5W, 484MHz约4.1W\n
# 电压每625为一档，需要更低电压可自行计算，计算错误将导致死机\n\n

# Freq(GPU频率) 必须是以下值之一\n
# $defFreqs\n\n

# 以下为频率/电压表配置内容\n
# 必须将频率/电压值以从低到高的顺序配置\n\n

# Freq Volt"

note=$(echo $note | sed "s/ #/#/g")
output="$note$userOpps"

if [[ -z $userOpps ]]; then
    output="$note$defOpps"
fi

echo -e $output > $CFG_PATH
