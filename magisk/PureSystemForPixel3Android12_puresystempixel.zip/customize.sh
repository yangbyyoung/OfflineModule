REPLACE="
/system/app/atfwd/
/system/app/BasicDreams/
/system/app/BookmarkProvider/
/system/app/EasterEgg/
/system/app/GooglePrintRecommendationService/
/system/app/HTMLViewer/
/system/app/KeyChain/
/system/app/PartnerBookmarksProvider/
/system/app/SafetyRegulatoryInfo/
/system/app/Stk/
/system/app/Traceur/
/system/app/uimremoteclient/
/system/app/uimremoteserver/
/system/app/WallpaperBackup/


/system/priv-app/BackupRestoreConfirmation/
/system/priv-app/BuiltInPrintService/
/system/priv-app/CallLogBackup/
/system/priv-app/CellBroadcastLegacyApp/
/system/priv-app/DynamicSystemInstallationService/
/system/priv-app/InputDevices/
/system/priv-app/MusicFX/
/system/priv-app/SharedStorageBackup/
/system/priv-app/TagGoogle/


/system/product/app/arcore/
/system/product/app/CalendarGooglePrebuilt/
/system/product/app/Chrome/
/system/product/app/Chrome-Stub/
/system/product/app/DiagnosticsToolPrebuilt/
/system/product/app/DMAgent/
/system/product/app/Drive/
/system/product/app/GoogleContactsSyncAdapter/
/system/product/app/GoogleTTS/
/system/product/app/GoogleVrCore/
/system/product/app/LocationHistoryPrebuilt/
/system/product/app/Maps/
/system/product/app/MobileFeliCaClient/
/system/product/app/MobileFeliCaMenuMainApp/
/system/product/app/MobileFeliCaSettingApp/
/system/product/app/MobileFeliCaWebPlugin/
/system/product/app/MobileFeliCaWebPluginBoot/
/system/product/app/Music2/
/system/product/app/NexusWallpapersStubPrebuilt2018/
/system/product/app/Ornament/
/system/product/app/PrebuiltGmail/
/system/product/app/SoundAmplifierPrebuilt/
/system/product/app/talkback/
/system/product/app/Tycho/
/system/product/app/Videos/
/system/product/app/WallpapersBReel2018/
/system/product/app/YouTube/


/system/product/priv-app/AmbientSensePrebuilt/
/system/product/priv-app/AndroidAutoFullPrebuilt/
/system/product/priv-app/AndroidMigratePrebuilt/
/system/product/priv-app/BetaFeedback/
/system/product/priv-app/CarrierWifi/
/system/product/priv-app/DMService/
/system/product/priv-app/DreamlinerPrebuilt/
/system/product/priv-app/DreamlinerUpdater/
/system/product/priv-app/EuiccGoogle/
/system/product/priv-app/EuiccSupportPixel/
/system/product/priv-app/HelpRtcPrebuilt/
/system/product/priv-app/MyVerizonServices/
/system/product/priv-app/NovaBugreportWrapper/
/system/product/priv-app/PartnerSetupPrebuilt/
/system/product/priv-app/SafetyHubLprPrebuilt/
/system/product/priv-app/ScribePrebuilt/
/system/product/priv-app/TurboPrebuilt/
/system/product/priv-app/Velvet/
/system/product/priv-app/WellbeingPrebuilt/


/system/system_ext/priv-app/EuiccSupportPixelPermissions/
/system/system_ext/priv-app/StorageManagerGoogle/
/system/system_ext/priv-app/TurboAdapter/
/system/system_ext/priv-app/YadaYada/
"