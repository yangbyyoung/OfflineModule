#!/system/bin/sh
MODDIR=${0%/*}
wait_sys_boot_completed()
{
	while true; do
		if [ "$(getprop sys.boot_completed)" ==  "1" ]; then
			return
		else
			sleep 1
		fi
	done
}
wait_sys_boot_completed
if [ "$(getprop suto.bypass_charge)" ==  "Y" ]; then
	nohup $MODDIR/Bypass_Charge.sh > /dev/null 2>&1 &
fi
