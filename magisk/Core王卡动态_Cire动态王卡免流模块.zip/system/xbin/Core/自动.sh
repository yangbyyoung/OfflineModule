while true
do
../动态/开启.sh
sleep 500
done