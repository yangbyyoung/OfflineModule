#!/system/bin/sh
MODDIR=${0%/*}

INJECT_BIN_64="$MODDIR/bin/inject64"
INJECT_BIN_32="$MODDIR/bin/inject32"
INIT_VERSION=""
IS_ENABLE="false"

inject () {
    local isSupport="$(getprop ro.feas.enable)"
    if [ "${isSupport}" != "true" ]; then
        [ -f "${INJECT_BIN_64}" ] && ${INJECT_BIN_64} > /dev/null 2>&1
        [ -f "${INJECT_BIN_64}" ] && ${INJECT_BIN_32} > /dev/null 2>&1
    fi
}

enableFEAS() {
    INIT_VERSION="$(getprop ro.feas.init.ver)"
    if [ "${INIT_VERSION}" -gt -1 ]; then
        resetprop ro.feas.enable true
        IS_ENABLE="true"
    fi
    local policyBin="${MODDIR}/bin/magiskpolicy --live "
    ${policyBin} "deny zygote init unix_stream_socket connectto"
    ${policyBin} "deny zygote property_socket sock_file write"
    ${policyBin} "deny zygote default_prop property_service set"
}

wait_boot_completed() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 0.5
    done
}

wait_login() {
    # no need to start before the user unlocks the screen
    local test_file="/sdcard/Android/.LOGIN_PERMISSION_TEST"
    true > "$test_file"
    while [ ! -f "$test_file" ]; do
        true > "$test_file"
        sleep 0.5
    done
    rm "$test_file"
}

wait_boot_completed
inject

wait_login
enableFEAS

Original_introduction="添加或开启FEAS支持"
if [ "${IS_ENABLE}" = "true" ]; then
    sed -i "s/description=[^*]*/description=\[\😋 FEASEnabler已激活, Ver: ${INIT_VERSION} \] $Original_introduction/g" "$MODDIR/module.prop"
else
    sed -i "s/description=[^*]*/description=\[\😰 FEASEnabler未激活\] $Original_introduction/g" "$MODDIR/module.prop"
fi