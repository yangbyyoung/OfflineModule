/data/adb/magisk/busybox chattr -i  /data/thermal
/data/adb/magisk/busybox chattr -i  /data/vendor/thermal