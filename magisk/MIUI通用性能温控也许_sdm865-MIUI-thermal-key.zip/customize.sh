SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/check.sh
key_source $MODPATH/update.sh
key_source $MODPATH/thermal_choice.sh
key_source $MODPATH/thermalkill.sh
key_source $MODPATH/kii_other_thermal.sh
key_source $MODPATH/selinux.sh
key_source $MODPATH/package_extra.sh
set_perm_recursive  $MODPATH  0  0  0755  0644
key_source $MODPATH/install_Sqlite3.sh
