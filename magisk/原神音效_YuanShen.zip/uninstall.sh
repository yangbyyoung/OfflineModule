# uninstall running
MODDIR=${0%/*}
rm -rf $MODDIR/Genshin