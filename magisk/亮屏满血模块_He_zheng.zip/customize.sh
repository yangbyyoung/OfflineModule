SKIPUNZIP=0
REPLACE=""
echo " "
echo "*******************"
echo "- 手机信息"
echo "- SDK: $(getprop ro.build.version.sdk)"
echo "- 设备: $(getprop ro.fota.oem)"
echo "- 设备代号: $(getprop ro.product.device)"
echo "- 安卓版本: Android $(getprop ro.build.version.release)"
echo "*******************"
echo "更新支持A13   MIUI14"
echo "此模块不删温控！！！"
echo "此模块不删温控！！！"
echo "我是真该死啊！🕊️王！QAQ"
echo "别问，问就是🕊️"
echo "*******************"
echo "ps:当然你要是删温控了那就持续满血"
echo "能发出来，应该是问题不大了"
echo "感谢群友的测试！！！谢谢！！"
echo "*******************"
echo "3.0版本更新如下"
echo "修复nfc，卡米"

var_device="`getprop ro.fota.oem`"
echo "当前设备代号为为: $(getprop ro.fota.oem)"
case "${var_device}" in
"samsung")
  rm -rf $MODPATH/*
  abort "- ${var_device} 当前机型未适配！"
;;
"*")
cache_path=/data/dalvik-cache/arm
[ -d $cache_path"64" ] && cache_path=$cache_path"64"
for fileName in $system_ext_cache; do
  rm -f $cache_path/system_ext@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done	
for fileName in $system_cache; do
  rm -f $cache_path/system@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done
productDirPath=$MODPATH/system/product
if [ ! -d "$productDirPath" ]; then
  mkdir -p ${productDirPath}
  cp -p -a -R /system/product/pangu/system/* ${productDirPath}
fi
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
;;
esac