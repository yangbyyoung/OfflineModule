SKIPUNZIP=0
[[ $(getprop ro.product.manufacturer) != Xiaomi ]] && abort "- 此模块仅支持小米设备"
MyPrint() 
{
	echo "$@"
	sleep 0.05
}
MyPrint " "
MyPrint "- 模块配置路径: [ /sdcard/Android/步数管理配置/ ]"
MyPrint " "
MyPrint "- v3.2更新："
MyPrint "- 修复“24点过后是否自动重新运行”选项的一个小bug"
MyPrint "- 优化部分shell命令"
MyPrint " "
MyPrint "-------------------------------------------------------------------"
MyPrint "- 模块简介: 修改/模拟 系统步数 第三方应用步数同步"
MyPrint " "
MyPrint "- Magisk版优势:"
MyPrint "  ①无需核心破解"
MyPrint "  ②无需app后台"
MyPrint "  ③运行时cpu占用小"
MyPrint "  ④完全自定义修改"
MyPrint "  ⑤与一次性修改步数或倍率提升步数的修改软件相比 Magisk版更具真实步数"
MyPrint " "
MyPrint "- 当前版本支持的功能:"
MyPrint "  *自定义间隔多久运行一次"
MyPrint "  *自定义运行增加多少步数"
MyPrint "  *自定义达到多少步数则退出进程/停止运行"
MyPrint "  *自定义除了当前日志之前日志是否保留"
MyPrint "  *自定义随机步数开关和数值"
MyPrint "  *自定义24点过后是否自动重新运行"
MyPrint "  *附属模块(用于控制主模块核心进程 实时生效)"
MyPrint "  *显示模块运行状态(模块介绍)"
MyPrint "  *息屏/亮屏判断"
MyPrint "  *息屏10-20秒后开始启用随机时间(在你设置的时间左右) 可以有效防止被第
三方应用检测伪步数 [ 实现随机步频/随机步数 ]"
MyPrint "-------------------------------------------------------------------"
MyPrint " "
MyPrint "- 请勿冻结电量与性能，否则可能导致运行失败"
MyPrint "- 请确认设备时间与网络时间是否同步"
MyPrint " "
MyPrint "-------------------------------------------------------------------"
MyPrint "- 免责声明: 使用此模块后如果任何社交类账号或支付类账号出现任何异常，均
与本人无关，本人不负任何法律责任。"
MyPrint " "
rm -rf /sdcard/Android/步数修改配置/ >/dev/null
rm -rf /data/adb/modules/STEPS-RUNNING/ >/dev/null
rm -rf /data/adb/modules/STEPS-Switch/ >/dev/null