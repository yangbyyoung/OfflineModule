#!/system/bin/sh
# 脚本的目录
MODDIR=${0%/*}

# 设置 Magisk Busybox 环境变量
#export 
PATH=$PATH:$(magisk --path)/.magisk/busybox; # 优先使用系统自带的命令，如果不存在则使用Magisk的busybox。
#export PATH=$(magisk --path)/.magisk/busybox:$PATH; # 优先使用Magisk的busybox。

(

# 检查配置文件是否存在
config_path="$MODDIR/config.prop"
    [ ! -f "$config_path" ] && echo "错误：检测到配置文件$config_path不存在，请创建它并添加相应参数！" && exit 1

# 获取配置参数
get_config() {
    sed -n "s/^$1=//p" "$config_path"
}

# 获取路由接口
get_interface() {
    ip route 2>/dev/null | grep -oi "$1[^ ]*"
}

# 获取 config.prop 参数值
wifi_status="$(get_config Wi-Fi)"
mobile_data="$(get_config 移动数据)"
airplane_mode="$(get_config 飞行模式)"
personal_hotspot="$(get_config 个人热点)"
click_coordinates="$(get_config 点击坐标)"
usb_shared_network="$(get_config USB共享网络)"

# 判断飞行模式是否开启
is_airplane_mode_on() {
    local airplane_mode_on="$(settings get global airplane_mode_on)"
    [ "$airplane_mode_on" = "1" ]
}

# 判断Wi-Fi是否开启
is_wifi_on() {
    local wifi_on="$(settings get global wifi_on)"
    local wifi_interface="$(getprop wifi.interface)"
    [ -n "$(get_interface $wifi_interface)" ] || [ "$wifi_on" = "1" ]
}

# 判断移动数据是否开启
is_mobile_data_on() {
    [ -n "$(get_interface rmnet_data)" ] || for var in "mobile_data" "mobile_data0" "mobile_data1" "mobile_data2" "mobile_data3"; do
        [ "$(settings get global "${var}")" = "0" ] && return 1
    done
    return 0
}


# 判断个人热点是否开启
is_personal_hotspot_on() {
    local personal_hotspot_on="$(getprop init.svc.hostapd)"
    local personal_hotspot_ona="$(getprop wlan.driver.status)"
    local wifi_interface="$(getprop wifi.interface)"
    [ -n "$(get_interface wlan | grep -v $wifi_interface)" ] || [ "$personal_hotspot_on" = "running" ]
}

# 判断USB共享网络是否开启
is_usb_shared_network_on() {
    local usb_shared_network_on="$(getprop sys.usb.state | grep rndis)"
    [ -n "$(get_interface rndis)" ] || [ "$usb_shared_network_on" != "" ]
}

# 开启 飞行模式
enable_airplane_mode() {
    if is_airplane_mode_on; then
        echo "飞行模式已经处于开启状态！"
        return
    fi

        echo "正在开启飞行模式，请稍候..."
    settings put global airplane_mode_on 1 >/dev/null 2>/dev/null
    am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true >/dev/null 2>/dev/null
    sleep 3
    if is_airplane_mode_on; then
        echo "飞行模式开启成功！"
    else
        echo "飞行模式开启失败！"
    fi
}

# 关闭 飞行模式
disable_airplane_mode() {
    if ! is_airplane_mode_on; then
        echo "飞行模式已经处于关闭状态！"
        return
    fi

        echo "正在关闭飞行模式，请稍候..."
    settings put global airplane_mode_on 0 >/dev/null 2>/dev/null
    am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false >/dev/null 2>/dev/null
    sleep 3
    if ! is_airplane_mode_on; then
        echo "飞行模式关闭成功！"
    else
        echo "飞行模式关闭失败！"
    fi
}

# 开启 Wi-Fi
enable_wifi() {
    if is_wifi_on; then
        echo "Wi-Fi已经处于开启状态！"
        return
    fi

        echo "正在开启Wi-Fi，请稍候..."
    svc wifi enable
    sleep 3
    if is_wifi_on; then
        echo "Wi-Fi开启成功！"
    else
        echo "Wi-Fi开启失败！"
    fi
}

# 关闭 Wi-Fi
disable_wifi() {
    if ! is_wifi_on; then
        echo "Wi-Fi已经处于关闭状态！"
        return
    fi

        echo "正在关闭Wi-Fi，请稍候..."
    svc wifi disable
    sleep 3
    if ! is_wifi_on; then
        echo "Wi-Fi关闭成功！"
    else
        echo "Wi-Fi关闭失败！"
    fi
}

# 开启 移动数据
enable_mobile_data() {
    if is_mobile_data_on; then
        echo "移动数据已经处于开启状态！"
        return
    fi

        echo "正在开启移动数据，请稍候..."
    svc data enable
    sleep 3
    if is_mobile_data_on; then
        echo "移动数据开启成功！"
    else
        echo "移动数据开启失败！"
    fi
}

# 关闭 移动数据
disable_mobile_data() {
    if ! is_mobile_data_on; then
        echo "移动数据已经处于关闭状态！"
        return
    fi

        echo "正在关闭移动数据，请稍候..."
    svc data disable
    sleep 3
    if ! is_mobile_data_on; then
        echo "移动数据关闭成功！"
    else
        echo "移动数据关闭失败！"
    fi
}

# 开启 个人热点
enable_personal_hotspot() {
    if is_personal_hotspot_on; then
        echo "个人热点已经处于开启状态！"
        return
    fi

        echo "正在开启个人热点，请稍候..."
    am start -n com.android.settings/.TetherSettings >/dev/null 2>/dev/null
    sleep 3
    input tap $click_coordinates
    sleep 1
    input keyevent 4
    sleep 1
    input keyevent 3
    if is_personal_hotspot_on; then
        echo "个人热点开启成功！"
    else
        echo "个人热点开启失败！"
    fi
}

# 关闭 个人热点
disable_personal_hotspot() {
    if ! is_personal_hotspot_on; then
        echo "个人热点已经处于关闭状态！"
        return
    fi

        echo "正在关闭个人热点，请稍候..."
    am start -n com.android.settings/.TetherSettings >/dev/null 2>/dev/null
    sleep 3
    input tap $click_coordinates
    sleep 1
    input keyevent 4
    sleep 1
    input keyevent 3
    if ! is_personal_hotspot_on; then
        echo "个人热点关闭成功！"
    else
        echo "个人热点关闭失败！"
    fi
}

# 开启 USB共享网络
enable_usb_shared_network_data() {
    if is_usb_shared_network_on; then
        echo "USB共享网络已经处于开启状态！"
        return
    fi

        echo "正在开启USB共享网络，请稍候..."
    svc usb setFunction rndis >/dev/null 2>/dev/null
    sleep 1
    svc usb setFunctions rndis >/dev/null 2>/dev/null
    sleep 2
    if is_usb_shared_network_on; then
        echo "USB共享网络开启成功！"
    else
        echo "USB共享网络开启失败！"
    fi
}

# 关闭 USB共享网络
disable_usb_shared_network_data() {
    if ! is_usb_shared_network_on; then
        echo "USB共享网络已经处于关闭状态！"
        return
    fi

        echo "正在关闭USB共享网络，请稍候..."
    svc usb setFunction >/dev/null 2>/dev/null
    sleep 1
    svc usb setFunctions >/dev/null 2>/dev/null
    sleep 2
    if ! is_usb_shared_network_on; then
        echo "USB共享网络关闭成功！"
    else
        echo "USB共享网络关闭失败！"
    fi
}


# 根据参数值执行相应的操作
case "$airplane_mode" in
    开) enable_airplane_mode ;;
    关) disable_airplane_mode ;;
    *) echo "错误：［飞行模式］参数值不正确，请检查$config_path文件！参数值输出结果为：$airplane_mode" ;;
esac

case "$wifi_status" in
    开) enable_wifi ;;
    关) disable_wifi ;;
    *) echo "错误：［Wi-Fi］参数值不正确，请检查$config_path文件！参数值输出结果为：$wifi_status" ;;
esac

case "$mobile_data" in
    开) enable_mobile_data ;;
    关) disable_mobile_data ;;
    *) echo "错误：［移动数据］参数值不正确，请检查$config_path文件！参数值输出结果为：$mobile_data" ;;
esac

case "$personal_hotspot" in
    开) enable_personal_hotspot ;;
    关) disable_personal_hotspot ;;
    *) echo "错误：［个人热点］参数值不正确，请检查$config_path文件！参数值输出结果为：$personal_hotspot" ;;
esac

case "$usb_shared_network" in
    开) enable_usb_shared_network_data ;;
    关) disable_usb_shared_network_data ;;
    *) echo "错误：［USB共享网络］参数值不正确，请检查$config_path文件！参数值输出结果为：$usb_shared_network" ;;
esac

) | tee $MODDIR/PortableWifiLog.txt

# 重置环境变量
#unset PATH

exit 0



