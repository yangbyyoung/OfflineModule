#!/system/bin/sh

test "$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit


#自定义的settings函数
function settings_option_dump(){
local IFS=$'\n'
local target="${1}"
local option="${2}"
local dumpsys_value="${3}"
local use_system_value="${4}"
test -z "${dumpsys_value}" && dumpsys_value="false"
test -z "${use_system_value}" && use_system_value="true"
test "$(echo "${option}" | grep -E 'delete|put|get' )" = "" && echo "错误的命令！" && return 1
test -z "${target}" && echo "错误！不存在筛选值！" && return 1
for i in `settings list system | grep -iw "${target}"`
do
value=`echo "${i}" | cut -d'=' -f2`
value_before=`echo "${i}" | cut -d'=' -f1`
if test "${dumpsys_value}" = "true" ;then
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		echo "settings "${option}" system "${value_before}""
	else
		if test "${use_system_value}" = "true" ;then
			echo "settings "${option}" system "${value_before}" "${value}""
		else
			echo "settings "${option}" system "${value_before}" "${use_system_value}"" 
		fi
	fi
else
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		settings "${option}" system "${value_before}"
	else
		if test "${use_system_value}" = "true" ;then
			settings "${option}" system "${value_before}" "${value}"
		else
			settings "${option}" system "${value_before}" "${use_system_value}"
		fi
	fi
fi
done
for i in `settings list global | grep -iw "${target}"`
do
value=`echo "${i}" | cut -d'=' -f2`
value_before=`echo "${i}" | cut -d'=' -f1`
if test "${dumpsys_value}" = "true" ;then
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		echo "settings "${option}" global "${value_before}""
	else
		if test "${use_system_value}" = "true" ;then
			echo "settings "${option}" global "${value_before}" "${value}""
		else
			echo "settings "${option}" global "${value_before}" "${use_system_value}"" 
		fi
	fi
else
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		settings "${option}" global "${value_before}"
	else
		if test -z "${use_system_value}" = "true" ;then
			settings "${option}" global "${value_before}" "${value}"
		else
			settings "${option}" global "${value_before}" "${use_system_value}"
		fi
	fi
fi
done
for i in `settings list secure | grep -iw "${target}"`
do
value=`echo "${i}" | cut -d'=' -f2`
value_before=`echo "${i}" | cut -d'=' -f1`
if test "${dumpsys_value}" = "true" ;then
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		echo "settings "${option}" secure "${value_before}""
	else
		if test "${use_system_value}" = "true" ;then
			echo "settings "${option}" secure "${value_before}" "${value}""
		else
			echo "settings "${option}" secure "${value_before}" "${use_system_value}"" 
		fi
	fi
else
	if test "$(echo "${option}" | grep -E 'put|get' )" = "" ;then
		settings "${option}" secure "${value_before}"
	else
		if test "${use_system_value}" = "true" ;then
			settings "${option}" secure "${value_before}" "${value}"
		else
			settings "${option}" secure "${value_before}" "${use_system_value}"
		fi
	fi
fi
done
}

function dump_settings(){
local IFS=$'\n'
local value="${1}"
local option="${2}"
local dumpsys_value="${3}"
local use_system_value="${4}"
test -z "${use_system_value}" && use_system_value="true"
test -z "${dumpsys_value}" && dumpsys_value="false"
test "$(echo "${option}" | grep -E 'delete|put|get' )" = "" && echo "错误的命令！" && return 1
test -z "${value}" && echo "错误！不存在筛选值！" && return 1
for i in $(dumpsys settings | grep -i "${value}" | sed 's/.*name://g;s/[[:space:]].*//g')
do
	#删除对应的settings值进行操作
	settings_option_dump "${i}" "${option}" "${dumpsys_value}" "${use_system_value}"
done
}


#定义分隔符
local IFS=$'\n'

#输出文件
folder="${0%/*}/刷新率"
test -d "$folder" && rm -rf "$folder"
mkdir -p "$folder"

#输出刷新率命令
for i in $(dumpsys display | grep 'DisplayModeRecord' )
do
level_id="$(echo $i | grep -wo 'id=[0-9].*[0-9],' | sed 's|id=||g;s|,.*||g' )"
cmd_id="$(($level_id - 1))"
fps_level="$(echo $i | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' )"
width="$(echo $i | grep -wo 'width=[0-9].*[0-9],' | sed 's|width=||g;s|,.*||g;s|height=[0-9].*[0-9]||g' )"
height="$(echo $i | grep -wo 'height=[0-9].*[0-9],' | sed 's|height=||g;s|,.*||g;s|width=[0-9].*[0-9]||g' )"
cat << key >> "$folder/"$fps_level"_"$width"X"$height".sh" && echo -e "\n生成 [ 刷新率: "$fps_level" 分辨率: "$width"X"$height" ] 脚本！"
#!/system/bin/sh
#@coolapk 10007
#service方法
#dumpsys display | grep 'DisplayModeRecord'
#可以看到 "档数=(id - 1)"
#利用service call SurfaceFlinger 1035 i32 档数 实现刷新率自定义。
#刷新率: $fps_level ($level_id) 
#档位: $cmd_id
#屏幕分辨率: $width X $height
#但是启用智能刷新率后无法用"service code"和 "settings 刷新率" 来修改刷新率
#以及会和dfps会冲突(因为dfps用的就是这两个反复写入。)
#命令:
test "\$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit

service call SurfaceFlinger 1035 i32 $cmd_id
settings put secure support_highfps 1
$(dump_settings 'refresh_rate' 'put' 'true' "${fps_level}")
resetprop persist.vendor.dfps.level $fps_level
#启动MIUI刷新率检测
if test "$(getprop ro.miui.ui.version.name)" != "" ;then
	su -c cmd activity startservice -n com.miui.powerkeeper/.ui.framerate.FrameRateService >/dev/null 2>&1
fi
key
done

cat << key > "$folder/恢复.sh" && echo -e "\n已生成恢复脚本！"
#!/system/bin/sh
#@coolapk 10007
#service方法
#dumpsys display | grep 'DisplayModeRecord'
#可以看到 "档数=(id - 1)"
#利用service call SurfaceFlinger 1035 i32 档数 实现刷新率自定义。
#刷新率: $fps_level ($level_id)
#命令:
test "\$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit
service call SurfaceFlinger 1035 i32 -1
settings delete secure support_highfps
$(dump_settings 'refresh_rate' 'delete' 'true' )
resetprop -p ro.vendor.smart_dfps.enable true
resetprop --delete persist.vendor.dfps.level
if test "$(getprop ro.miui.ui.version.name)" != "" ;then
	am force-stop com.miui.powerkeeper >/dev/null 2>&1
	su -c cmd activity startservice -n com.miui.powerkeeper/.ui.framerate.FrameRateService >/dev/null 2>&1
fi
key


echo -e "\n已生成文件夹 "$folder" \n\n请到文件夹里用root执行脚本，修改刷新率\n"



