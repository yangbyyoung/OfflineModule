##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
print_modname() {
    return
}

# Copy/extract your module files into $MODPATH in on_install.
on_install() {
    $BOOTMODE || abort "! cannot be installed in recovery."
    [ $ARCH == "arm64" ] || abort "! ONLY support arm64 platform."
    filepath="/data/ManjusakaTool"
 if [[ ! -f $filepath ]]; then
    mkdir "$filepath"
 fi    
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -x "Manjusaka.sh" -x "module.prop" -x "service.sh" -x "Exclude_Thermal_Files.sh" -d "/data/ManjusakaTool" >/dev/null
    chmod 777 $filepath/busybox
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null
    ui_print "- Author:Manjusaka"
	ui_print "- Group:647299031"
	  #欢迎拆包查看 请勿二改
	  #作者:Manjusaka(酷安@曼珠沙华Y)
	  #群组:647299031
	  #Busybox存放地址
 busybox="$filepath/busybox"
      #释放地址    
 #检查Busybox并释放
 if [[ -f $busybox ]]; then
 #存在Busybox开始释放
    ui_print "- Releasing BusyBox"
	"$busybox" --list | while read; do
		if [[ $REPLY != tar && ! -f $filepath/$REPLY ]]; then
			ln -fs "$busybox" "$filepath/$REPLY"
		fi
	done
	ui_print "- Complete Release"
 else
 #不存在Busybox输出
	abort "- Busybox does not exist !!!"
 fi

}
set_permissions() {
    return
}
