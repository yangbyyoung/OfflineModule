ui_print " "
ui_print "————————————————————————"
ui_print " "

if [[ "$bootpath" != "" ]];then
ui_print "自動查詢到的文件："
for i in $bootpath;do
ui_print "$i"
[[ -z $i ]] && abort "！！！警告！！！未檢測到有效的開機文件（可能文件丟失或者損壞）"
done
bootanimation_check=1
fi
ui_print " "

animnam=$MODPATH/*.zip
ui_print "正在使用的開機動畫文件：$(basename ${animnam} .zip)" >> $MODPATH/module.prop

if [[ "$bootpath_dark" != "" ]];then
ui_print "自動查詢到的文件："
for i in $bootpath_dark;do
ui_print "$i"
[[ -z $i ]] && abort "！！！警告！！！未檢測到有效的開機文件（可能文件丟失或者損壞）"
done
bootanimation_check=2
fi
ui_print " "
ui_print "————————————————————————"