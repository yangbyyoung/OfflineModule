#!/system/bin/sh
# By written tytydraco

# Wait for boot to finish completely
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# sleep 70 to ensure other module executed before 
sleep 60

# execute
disable-useless