#!/system/bin/sh
MODDIR=${0%/*}
wait_sys_boot_completed()
{
	while true; do
		if [ "$(getprop sys.boot_completed)" ==  "1" ]; then
			return
		else
			sleep 1
		fi
	done
}
perfboost()
{
	for CPU in `ls /sys/devices/system/cpu/cpu*/online`; do
		if [ -f $CPU ]; then
			echo "1" > $CPU
		fi
	done

	for POLICY_PATH in `ls -d /sys/devices/system/cpu/cpufreq/policy*`; do
		if [ -f $POLICY_PATH/cpuinfo_max_freq ] && [ -f $POLICY_PATH/scaling_max_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_max_freq)" > $POLICY_PATH/scaling_max_freq
		fi
		if [ -f $POLICY_PATH/cpuinfo_min_freq ] && [ -f $POLICY_PATH/scaling_min_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_min_freq)" > $POLICY_PATH/scaling_min_freq
		fi
	done
}
set_def_pwrlevel()
{
	local MODEL=$1
	local SERIALNO=$2
	local PWRLEVEL=$3
	if [[ "$(getprop ro.soc.model)" ==  "$MODEL" ]] && [[ "$(getprop ro.serialno)" = *"$SERIALNO"* ]]; then
		echo "$PWRLEVEL" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
		echo "$PWRLEVEL" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
	fi
}
set_miui_val()
{
	if getprop | grep "miui.ui.version" >/dev/null; then
		settings put system POWER_SAVE_PRE_HIDE_MODE performance
		settings put Secure speed_mode_enable 1
		settings put system speed_mode 1
	fi
}
wait_sys_boot_completed
perfboost
set_miui_val
if [ "$(getprop sutoliu.extension)" ==  "Y" ]; then
	nohup $MODDIR/SutoLiu.sh >/dev/null 2>&1 &
fi
if getprop | grep "Xiaomi" >/dev/null; then
	set_def_pwrlevel "SM8475" "bda8c55" "7"
	set_def_pwrlevel "SM8350" "f22a68c" "7"
	set_def_pwrlevel "SM8475" "92b7edb" "7"
	CLEANLIST="com.xiaomi.joyose com.miui.powerkeeper com.miui.bugreport com.miui.analytics com.xiaomi.mirror com.miui.securitycenter com.miui.securitycenter:ui com.android.quicksearchbox com.android.quicksearchbox:widgetProvider com.miui.carlink com.xiaomi.mtb com.xiaomi.market com.miui.screenrecorder"
	for PACKAGE_NAME in $CLEANLIST; do
		if killall -9 $PACKAGE_NAME >/dev/null; then
			sleep 1
		else
			sleep 5
			killall -9 $PACKAGE_NAME
		fi
	done
	set_miui_val
fi
