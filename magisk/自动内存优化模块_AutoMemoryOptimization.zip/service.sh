#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

# Wait
sleep 10
stop perfd

# LMK
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '10240,16384,18432,20480,30720,33280' > /sys/module/lowmemorykiller/parameters/minfree
echo '56250' > /sys/module/lowmemorykiller/parameters/vmpressure_file_min
adjZeroMinFree=14746
echo '262144' > /proc/sys/vm/extra_free_kbytes

# Memory
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotal=${MemTotalStr:16:8}
MemTotalPg=$((MemTotal / 4))

# zRAM
echo '100' > /proc/sys/vm/swappiness
swapoff /dev/block/zram0 > /dev/null 2>&1
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize
echo '1' > /sys/block/zram0/max_comp_streams
echo 'lz4' > /sys/block/zram0/comp_algorithm
echo $((MemTotal * 1024)) > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1