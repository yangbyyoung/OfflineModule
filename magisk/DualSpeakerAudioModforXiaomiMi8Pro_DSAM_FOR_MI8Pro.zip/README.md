# Dual Speaker Audio Mod for Xiaomi Mi 8 Pro
Added stereo sound effect and improved sound quality. Based in initial work of Kommandoz from 4PDA updated by Seyaru

## Changelog
### v4:
- Based on 9.11.7 vendor 
### v3:
- Updated Magisk template
### v2:
- Based on 9.10.24 vendor 
### v1:
- Initial Release
- Added stereo sound effect
- Sound volume increased
- Built mod according to instructions from Dante63

