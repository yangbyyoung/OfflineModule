#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=/data/adb/magisk/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
test -e $MODDIR/crond && {
	chmod -R 777 $MODDIR/crond
	until $(dumpsys deviceidle get screen) ;do
		sleep 4
	done
	for i in $MODDIR/crond/*.sh ;do
		$i 2> /dev/null
	done
}

crond -c $MODDIR/crond

sleep 18
pm list packages -3  | sed 's/package://g' > $MODDIR/crond/1.conf
awk '{print $0}' $MODDIR/crond/1.conf $MODDIR/crond/黑-白名单.conf |sort|uniq -u >$MODDIR/crond/退后台名单.conf
rm -f $MODDIR/crond/1.conf

