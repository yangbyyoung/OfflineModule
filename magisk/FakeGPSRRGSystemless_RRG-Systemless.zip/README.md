# Official Modul magisk FakeGPS untuk Driver Online

<p align="center">
<b> RRG-Systemless </b><br>
  <img src="http://telegra.ph/file/e983e0b6b68f52d9b908a.png">
</p>

## Module Explanation:
English:
A very simple module just to make Fake GPS work as app systemlessly, It'll simply inject a folder with the apk into the path: /system/priv-app. If it shows RRG-Systemless.

Indonesia:
Modul yang sangat sederhana hanya untuk membuat GPS palsu berfungsi sebagai aplikasi tanpa sistem, Ini hanya akan menyuntikkan folder dengan apk ke jalur: /system/priv-app. Jika itu menunjukkan RRG-Systemless.

* Note: You won't get any xposed-side features, since magisk is NOT xposed!

## Changelog:
- Rilis Pertama
- Support Android Nougat 7.x.x & Android Oreo 8.x.x


## Requirements: 
- Android 5.0+ (Magisk requirement)
- Magisk v15.3+

## Instruction:
* Downloads this Module
* Reboot into TWRP
* Install RRG-Systemless
* Reboot

# Module by:
* Telegram - [1241h417](https://t.me/l241h417 "Official Project")

# Credits:

* Join On Telegram - [RRG〽️DeV910](https://t.me/joinchat/HpcJ_07yRKoxi6Ie7s0CmQ "RRG〽️DeV910 Official Telegram Grup").

* Magisk Developer - [Topjohnwu](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445 "Magisk official XDA thread").

* Lexa Fake GPS - [lexa](droid.develope@gmail.com "Contact").

## Third party code used:
* [Unity Template](https://github.com/Zackptg5/Unity "Template's repository").


