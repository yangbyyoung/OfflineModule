MODDIR=${0%/*}

rm -rf /data/fonts

if getprop ro.product.system.manufacturer |
        grep -qE -e "^samsung"; then
		cp $MODDIR/system/fonts/NotoColorEmoji.ttf $MODDIR/system/fonts/SamsungColorEmoji.ttf
fi