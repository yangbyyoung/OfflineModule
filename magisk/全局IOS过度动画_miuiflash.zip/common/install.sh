#!/system/bin/sh
P7Z=$TMPDIR/common/tools/7za
addfile=$TMPDIR/common/addfile
chmod 755 $P7Z
cp -f /system/framework/framework-res.apk $TMPDIR/framework-res.zip
$P7Z a $TMPDIR/framework-res.zip $addfile/res
cp $TMPDIR/framework-res.zip $MODPATH/system/framework/framework-res.apk