ShellVersion="W-1.6"
mkdir -p /sdcard/Android/DM/log/
LogDir="/sdcard/Android/DM/log/QVClean.log"
if [ ! -f "$LogDir" ];then
  touch $LogDir
fi
datename=$(date +%Y-%m-%d-%H:%M:%S) 
echo "Wechat清理完成！ Shell版本："$ShellVersion" \nWechat清理执行时间: "$datename"" >> $LogDir
echo "-----------------------"
echo "微信清理脚本版本:"$ShellVersion""
echo "适配系统:Android系统理论通用 需要root"
echo "推荐系统:Android R"
echo "-----------------------"
echo ""
echo "-开始处理-"
echo "日志文件"
am force-stop com.tencent.mm
sleep 1
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/files/onelog/
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/xlog/
rm -rf /data/data/com.tencent.mm/files/xlog/
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/wxacache/
rm -rf /data/data/com.tencent.mm/files/live_log/
rm -rf /data/data/com.tencent.mm/files/com.tencent.mm:tools/logging_cache/
rm -rf /data/data/com.tencent.mm/files/webnet/cacheinfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/files/backup
rm -rf /data/data/com.tencent.mm/app_appcache/
echo "TBS备份"
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/files/VideoCache
echo "视频缓存"
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/.tmp/
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/Cache
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/wxacache/
rm -rf /data/data/com.tencent.mm/cache/
echo "主缓存"
#rm -rf /data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
rm -rf /data/data/com.tencent.mm/cache/
echo "无用重复组网插件"
rm -rf /data/data/com.tencent.mm/MicroMsg/webservice/codecache/
rm -rf /data/data/com.tencent.mm/MicroMsg/mmslot/webcached/
sleep 1
echo "web缓存"
rm -rf /data/data/com.tencent.mm/MicroMsg/CronetCache/
echo "Cronet 缓存"
rm -rf /data/data/com.tencent.mm/app_x5webview/Cache/
rm -rf /data/data/com.tencent.mm/app_x5webview/GPUCache/
rm -rf /data/data/com.tencent.mm/app_x5webview/Service Worker/CacheStorage/
echo "X5内核缓存"
echo "腾讯地图SDK日志"
rm -rf /data/data/com.tencent.mm/files/tencentMapSdk/logos/
echo "host"
echo "正则匹配信息"
rm -rf /data/data/com.tencent.mm/app_xwalk_[0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z]/
rm -rf /data/data/com.tencent.mm/app_xwalkplugin/
##rm -rf /data/data/com.tencent.mm/files/host/
echo "TBS插件"
rm -rf /data/data/com.tencent.mm/app_tbs/
rm -rf /data/data/com.tencent.mm/app_tbs_64/
echo "小程序"
rm -rf /data/data/com.tencent.mm/files/liteapp/
echo "直播"
sleep 1
rm -rf /data/data/com.tencent.mm/files/public/live/
rm -rf /data/data/com.tencent.mm/files/public/fts/
rm -rf /data/data/com.tencent.mm/files/public/OCR
rm -rf /data/data/com.tencent.mm/files/public/cityService/
rm -rf /data/data/com.tencent.mm/files/public/tagsearch/
rm -rf /data/data/com.tencent.mm/files/public/box/
rm -rf /data/data/com.tencent.mm/files/public/CheckResUpdate/
rm -rf /data/data/com.tencent.mm/files/public/websearch/
echo "tab_live日志"
rm -rf /sdcard/Android/data/com.tencent.mm/files/Tencent/tbs_live_log/
rm -rf /sdcard/Tencent/tbs_common_log/
echo "检查的资源更新"
rm -rf /sdcard/Android/data/com.tencent.mm/MicroMsg/CheckResUpdate/
echo "恢复日志"
rm -rf /data/data/com.tencent.mm/MicroMsg/recovery/recovery_log/
echo "临时文件"
rm -rf /data/data/com.tencent.mm/MicroMsg/tmp/
echo "未知web相关文件(占用特别大)"
rm -rf /data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
echo "广告js"
rm -rf /data/data/com.tencent.mm/MicroMsg/webcompt/wxAd/
echo "appBrandJs缓存"
rm -rf /data/data/com.tencent.mm/MicroMsg/appbrand/jscache/
cd /data/data/com.tencent.mm/files/
mkdir xlog
echo "处理老版本上xlog问题"
chattr -R -i xlog
rm -rf xlog
sleep 1
am start com.tencent.mm/.ui.LauncherUI
echo "执行重启微信操作…"
echo "------------------"
echo "大美制作 酷安@孤Lrkc   21.04.04"
echo "更新  21.09.12"
echo "转发修改请保留原作者信息 谢啦๑ᵔ⌔ᵔ๑"
EndTime=$(date +%Y-%m-%d-%H:%M:%S) 
echo "Wechat清理完成时间: "$EndTime"\n_-_-_-_-_-_-_-_-_-_-_-_-_-_-_" >> $LogDir
echo "Successful"
echo "清理完毕，5秒后返回上一级操作，如现在是终端里，则会退出终端"
sleep 5
input keyevent BACK


