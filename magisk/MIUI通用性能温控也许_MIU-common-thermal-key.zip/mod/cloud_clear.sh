#!/system/bin/sh
#sqlite3下载地址
#脚本编写@coolapk 10007
#https://keytoolazy.coding.net/p/hms-core/d/HMS-CORE/git/raw/master/Sqlite3/Sqlite1.zip

test "$(which -a sqlite3)" = "" && echo "请安装sqlite3！" && exit 1

function disable_joyose(){
sqlite3 "/data/data/com.xiaomi.joyose/databases/SmartP.db" << EOF
#update cloud_config set enable='0' where config_name='common_config';
#update cloud_config set enable='0' where config_name='booster_config';
update cloud_config set enable='0';
update cloud_config set version='2999122801';
#update cloud_config set params='';
EOF
pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver >/dev/null 2>&1
#pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService >/dev/null 2>&1
resetprop persist.sys.sc_allow_conn false
}


function disable_dfps_charge(){
local IFS=$'\n'
local target="
fps_exclude_pkg
fps_top_video_pkg
fps_group
dfps_group
key_top_names
"
for name in $target
do
sqlite3 "/data/data/com.miui.powerkeeper/databases/user_configure.db" << EOF
delete from misc where name="$name"; 
insert into misc (name,value) values("$name",'');
update misc set value="" where name="$name";
EOF
done
}


function disable_power(){
sqlite3 "/data/data/com.miui.powerkeeper/databases/user_configure.db" << EOF
update misc set value='{"game":""}' where name='thermal_group';
EOF
disable_dfps_charge
pm disable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver >/dev/null 2>&1
pm disable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService >/dev/null 2>&1
}

disable_joyose
disable_power

