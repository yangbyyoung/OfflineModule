# 安装时显示的模块名称
mod_name="视频工具箱补全+ai大师画质引擎"
mod_install_desc="✨包含动态补偿，画面增强，ai大师画质引擎"
# 安装时显示的提示
mod_install_info="是否安装$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
add_sysprop "#视频工具箱-音效-影音功能(miui)（UI开关）
ro.vendor.video_box.version=2
debug.config.media.video.aie.support=true
debug.config.media.video.ais.support=true

debug.media.video.frc=false
debug.media.video.vpp=false
debug.media.video.style=false
ro.vendor.media.video.frc.support=true
ro.vendor.media.video.vpp.support=true
ro.vendor.media.video.style.support=false
"

#ai大师画质引擎
sed -i 's/<bool name=\"support_screen_enhance_engine\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_screen_enhance_engine\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_screen_enhance_engine\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_screen_enhance_engine\">true<\/bool>' $MODPATH/system/etc/device_features/*

        return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}
