##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
#
# Function Callbacks
#
# The following functions will be called by the installation framework.
# You do not have the ability to modify update-binary, the only way you can customize
# installation is through implementing these functions.
#
# When running your callbacks, the installation framework will make sure the Magisk
# internal busybox path is *PREPENDED* to PATH, so all common commands shall exist.
# Also, it will make sure /data, /system, and /vendor is properly mounted.
#
##########################################################################################
##########################################################################################
#
# The installation framework will export some variables and functions.
# You should use these variables and functions for installation.
#
# ! DO NOT use any Magisk internal paths as those are NOT public API.
# ! DO NOT use other functions in util_functions.sh as they are NOT public API.
# ! Non public APIs are not guranteed to maintain compatibility between releases.
#
# Available variables:
#
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#
# Availible functions:
#
# ui_print <msg>
#     print <msg> to console
#     Avoid using 'echo' as it will not display in custom recovery's console
#
# abort <msg>
#     print error message <msg> to console and terminate installation
#     Avoid using 'exit' as it will skip the termination cleanup steps
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# If you need boot scripts, DO NOT use general boot scripts (post-fs-data.d/service.d)
# ONLY use module scripts as it respects the module status (remove/disable) and is
# guaranteed to maintain the same behavior in future Magisk releases.
# Enable boot scripts by setting the flags in the config section above.
##########################################################################################

# Set what you want to display when installing your module

print_modname() { # 这里会将一些模块信息打印出来
  ui_print "*******************************"
  ui_print " ★★★★★★★★★★★★★★★★★★★★★★★★★★★ "
  ui_print " 赛博朋克2077 1080版  "
  ui_print " 作者   酷安@EMUI系统 "
  ui_print " 喜欢可以去酷安关注作者 "
  ui_print " 我们的组织【EmotionTeam Project】 793488322 "
  ui_print "【移动N2(Yureka2) ET Project分部】155268606 "
  ui_print " 感谢支持♤♤♤♤♤♤♤♤"
  ui_print " ★★★★★★★★★★★★★★★★★★★★★★★★★★★★"
  ui_print " "
  ui_print " 删除模块请到/data/adb/modules下删除即可 "  
  ui_print " ★★★★★★★★★★★★★★★★★★★★★★★★★★★ "
  
  
  
  ui_print " 素材来着抖音解析去水印 属实不易不喜勿喷  "
  
  ui_print "*******************************"
}


keytest() { # 测试按键
  ui_print "- 我们需要进行音量键测试来确保你的音量键工作正常"
  ui_print "- 音量键测试"
  ui_print "  - 请按下 [音量+](音量上) 键："
  (/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
  return 0
}

chooseport() { # 新版的按键检测（基于已知的key code）
  while (true); do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
    if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
      break
    fi
  done
  if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
    return 0
  else
    return 1
  fi
}

chooseportold() { # 旧版的按键检测（基于录入的key code）
  $KEYCHECK
  $KEYCHECK
  SEL=$?
  $DEBUG_FLAG && ui_print "   chooseportold: $1,$SEL"
  if [ "$1" == "UP" ]; then
    UP=$SEL
  elif [ "$1" == "DOWN" ]; then
    DOWN=$SEL
  elif [ $SEL -eq $UP ]; then
    return 0
  elif [ $SEL -eq $DOWN ]; then
    return 1
  else
    abort "   未检测到音量键！"
  fi
}


initmod() { # 初始化每个小模块的内部变量
  mod_id=""
  mod_name=""
  mod_info_text=""
  mod_install_info=""
  mod_yes_text=""
  mod_no_text=""
  mod_select_yes_text=""
  mod_select_no_text=""
  files="files"
}

# Copy/extract your module files into $MODPATH in on_install.


on_install() { # 在安装时会调用的函数
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  # 模块自带的解压system命令
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2


  # 设置后面要使用的变量
  DEBUG_FLAG=true
  KEYCHECK=$TMPDIR/keycheck
  P7Z=$TMPDIR/7za
  MODS_SELECTED_YES=""
  MODS_SELECTED_NO=""
  num=0
  service=false
  # choosed=""


  # 给KEYCHECK和P7Z执行权限以免无法执行
  chmod 755 $KEYCHECK
  chmod 755 $P7Z


  # 检测按键
  if keytest; then
    FUNCTION=chooseport
    $DEBUG_FLAG && ui_print "   func: $FUNCTION"
    ui_print "   已检测到音量键   "
  else
    FUNCTION=chooseportold
    $DEBUG_FLAG && ui_print "   func: $FUNCTION"
    ui_print "*******************************"
    ui_print "- 检测不到音量键！使用旧的 keycheck 方案 -"
    ui_print "- 进行音量键录入 -"
    ui_print "   录入：请按下 [音量+] 键："
    $FUNCTION "UP"
    ui_print "   已录入 [音量+] 键。"
    ui_print "   录入：请按下 [音量-] 键："
    $FUNCTION "DOWN"
    ui_print "   已录入 [音量-] 键。"
  fi


  # 使用解压出来的7z文件解压模块关键内容
  ui_print "   解压模块文件"
  $P7Z x -tzip $ZIPFILE -o$TMPDIR -ir!pejian/* -y > /dev/null


  # 开始选择安装的模块
  cd $TMPDIR/pejian
  for MOD in $(ls); do
    initmod
    cd $TMPDIR/pejian
    if [ -d $MOD ]; then
      if [ -f $MOD/mod_info.sh ]; then
        ui_print "*******************************"
        source $MOD/mod_info.sh
        MODFILEDIR="$TMPDIR/pejian/$MOD/$files"
        $DEBUG_FLAG && ui_print "mod_id: [$mod_id]"
        $DEBUG_FLAG && ui_print "mod_name: [$mod_name]"
        $DEBUG_FLAG && ui_print "load_mods: $TMPDIR/pejian/$MOD/mod_info.sh"
        $DEBUG_FLAG && ui_print "load_files: $TMPDIR/pejian/$MOD/$files/"
        ui_print "- 请按音量键选择$mod_install_info -"
        [ "$mod_info_text" != "" ] && ui_print "   $mod_info_text。"
        ui_print "   [音量+]：$mod_yes_text"
        ui_print "   [音量-]：$mod_no_text"
        if $FUNCTION; then
          # choosed="$choosed$mod_id "
          echo -n "$mod_select_yes_text" >> $TMPDIR/module.prop
          MODS_SELECTED_YES="$MODS_SELECTED_YES ($MOD)"
          [ "$mod_name" != "" ] && ui_print "   已安装[$mod_name]。"
          let num++
          mod_install_yes
        else
          echo -n "$mod_select_no_text" >> $TMPDIR/module.prop
          MODS_SELECTED_NO="$MODS_SELECTED_NO ($MOD)"
          [ "$mod_name" != "" ] && ui_print "   未安装[$mod_name]。"
          mod_install_no
        fi
      else
        $DEBUG_FLAG && ui_print "未检测到配置文件：$TMPDIR/pejian/$MOD/mod_info.sh"
      fi
    fi
    initmod
  done


  # touch $MODPATH/choosed.txt
  # echo $choosed > $MODPATH/choosed.txt


  # DEBUG模式需要暂停
  if [ $DEBUG_FLAG == true ]; then
    ui_print "- 调试模式中 所选模块安装完毕 目前已暂停  -"
    ui_print "- 再次按下音量键以结束  -"
    if $FUNCTION; then
      ui_print ""
    fi
  fi

  ui_print "- 模块安装完毕  -"

  [ $num == 0 ] && echo -n "您未安装任何功能" >> $TMPDIR/module.prop
  ui_print "*******************************"
  ui_print "   "
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code













