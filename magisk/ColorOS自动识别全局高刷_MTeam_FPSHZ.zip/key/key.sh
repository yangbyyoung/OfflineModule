#函数们
PROP="`ls /odm/etc/*/build.default.prop`"
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.vendor.device`"
var_id="`getprop ro.build.display.id`"
prjname="`getprop ro.boot.prjname`"
locale="`getprop ro.product.locale`"
var_type="`getprop ro.oplus.image.my_product.type`"
var_version="`getprop ro.build.version.release`"
var_oplusrom="`getprop ro.build.version.oplusrom`"
name="`grep_prop name $TMPDIR/module.prop`"
author="`grep_prop author $TMPDIR/module.prop`"
inf_version="`grep_prop version $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
MANUFACTURER=$(getprop ro.product.vendor.brand)
[[ -e /proc/scsi/scsi ]] && UFS_MODEL=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $2}') && Particles=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $4}') || UFS_MODEL="unknown"
#闪存类型
[[ -e /sys/block/sda/size ]] && ROM_TYPE="UFS" || ROM_TYPE="eMMC"

_grep_prop() {
  local REGEX="s/$1=//p"
  shift
  local FILES=$@
  [[ -z $FILES ]] && FILES="/system/build.prop /vendor/build.prop /product/build.prop"
  sed -n $REGEX $FILES 2>/dev/null | head -n 1
}

#打开文件
Read() {
  [[ -f $1 ]] && cat $1
}

nvid=`getprop ro.build.oplus_nv_id`
function chkNvid(){
case $nvid in
	10010111) echo CN 中国 China;;
	00011010) echo TW 中国台湾省 Taiwan;;
	00110111) echo RU 俄罗斯 Russia;;
	01000100) echo GDPR 欧盟 EU;;
	10001101) echo GDPR 欧洲 Europe;;
	00011011) echo GDPR 欧洲 Europe;;
	00011011) echo IN 印度 India;;
	00110011) echo ID 印度尼西亚 Indonesia;;
	00111000) echo MY 马来西亚 Malaysia;;
	00111001) echo TH 泰国 Thailand;;
	00111110) echo PH 菲律宾 Philippines;;
	10000011) echo SA 沙特阿拉伯 Saudi Arabia;;
	10011010) echo LATAM 拉丁美洲 Latin America;;
	10011110) echo BR 巴西 Brazil;;
	10100110) echo MEA 中东和非洲 The Middle East and Africa;;
	*) echo "当前国家/地区代码 = $nvid";;
esac
}

#ColorOS版本
function ColorOS_version() {
ColorOS=$(getprop ro.build.display.id)
rui_version=`getprop ro.build.version.realmeui`
if [ $rui_version ];then
echo "– RealmeUI版本: $(getprop ro.build.version.realmeui)"
fi
if [ $ColorOS ];then
echo "– ColorOS版本: $(getprop ro.build.display.id)"
else
echo "– 系统版本: 淦 找不到相关信息"
fi
}
#系统当前槽位
function ColorOS_suffix() {
if [[ $(getprop ro.boot.slot_suffix) = _a ]];then
echo "A槽位"
fi
if [[ $(getprop ro.boot.slot_suffix) = _b ]];then
echo "B槽位"
fi
if [ -e /dev/block/bootdevice/by-name/dtbo ]; then
echo "动态分区"
fi
}

function get_magisk_lite(){
local until_function=/data/adb/magisk/util_functions.sh
grep -q lite_modules $until_function && echo "- 🌙当前为: Magisk Lite◎$MAGISK_VER_CODE" || echo "- ☀当前为: Magisk Official◎$MAGISK_VER_CODE" 
}

function hello_master(){
if test -n "$(getprop persist.sys.device_name)" ;then
	echo ""
	echo "- ●您好！"$(getprop persist.sys.device_name)"！●"
	echo "- ●欢迎使用本模块！●"
	get_magisk_lite
	echo ""
elif test -n "$(pm list users | cut -d : -f2 )" ;then
	echo ""
	echo  - ●您好！ $(pm list users | cut -d : -f2 )！●
	echo "- ●欢迎使用本模块！●"
	get_magisk_lite
	echo ""
fi
}

echo ""
echo "∞————————————————————————∞"
hello_master
echo "  ※ 系统详情 ※"
echo "– 销售地区: $(chkNvid)"
echo "– 厂商信息: $MANUFACTURER"
echo "– 商品型号: $(getprop ro.product.device)"
echo "– 设备型号: $(getprop ro.product.model)"
echo "– 设备代号: $(getprop ro.boot.prjname)"
echo "– ColorOS项目: $(getprop ro.separate.soft)"
echo "– ColorOS固件: $(getprop ro.build.version.oplusrom)"
$(ColorOS_version) 
echo "– Android版本: $(getprop ro.build.version.release)"
echo "– Android槽位: $(ColorOS_suffix)"
echo "– RAM: $(Read /proc/meminfo | head -n 1 | awk '{print $2/1000}')MB"
echo "– SDK: $(getprop ro.build.version.sdk)"
echo "– CPU: $(getprop ro.build.device_family) $(($(Read /sys/devices/system/cpu/kernel_max) + 1))核心"
echo "– 架构: $(getprop ro.product.cpu.abi)"
echo "– 闪存类型: $ROM_TYPE"
echo "– 闪存颗粒: $UFS_MODEL $Particles"
echo "– 内核版本: $(uname -r)"
echo "– 运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
echo "– Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
sleep 0.1
echo "∞————————————————————————∞"
echo "  ※ 模块信息 ※"
echo "– 名称：$name    "
echo "– 作者：$author"
echo "– $description    "
echo "∞————————————————————————∞"

#开始输入
ui_print "- 当前模块版本：$inf_version"
ui_print "- 更新日志查看：README.md"
ui_print "- *******************************"
ui_print "
- 如果卡第一屏或开机动画请在
- REC→高级→文件管理
- data/adb/modules
- 删除$id这个文件夹
"

name="`grep_prop name $TMPDIR/module.prop`"
nvid=`getprop ro.build.oplus_nv_id`
[ -z $nvid ] && abort "当前系统不是ColorOS 或者 realmeUI"
if [ $API -lt 30 ]; then 
abort "- Not support Android 10 and older Android version."
elif [ $API -eq 30 ]; then 
abort "- Not support Android 11 and older Android version."
elif [ $API -le 32 ]; then 
echo "- Hello, Android 12 user. ❛‿˂̵✧"
ui_print "- 开始安装$name"
key_source $MODPATH/key/Switches.sh &>/dev/null
set_perm_recursive  $MODPATH  0  0  0777  0777
rm -rf /data/adb/modules/MTeamS_COS_Strengthen/SurfaceFlinger
rm -rf /data/adb/modules/MTeamS_COS_Strengthen/MTeam_FPS.sh
rm -rf /data/adb/modules_update/MTeam_FPSHZ/key/Refresh.sh 
elif [ $API -eq 33 ]; then 
echo "- Hello, Android 13 user. (＾Ｕ＾)ノ~"
ui_print "- 开始安装$name"
key_source $MODPATH/key/Switches.sh &>/dev/null
set_perm_recursive  $MODPATH  0  0  0777  0777
rm -rf /data/adb/modules/MTeamS_COS_Strengthen/SurfaceFlinger
rm -rf /data/adb/modules/MTeamS_COS_Strengthen/MTeam_FPS.sh
rm -rf /data/adb/modules_update/MTeam_FPSHZ/key/Refresh.sh 
fi

if [ -f "/data/adb/modules/C++Busybox/module.prop" ];then
Module=`cat "/data/adb/modules/C++Busybox/module.prop" | grep 'version=' | awk -F '=' '{print $2}'`
if [ "$Module" = 88.0 ];then
echo "- C++库无需更新"
rm -rf $MODPATH/key/C++Busybox
else
rm -rf /data/adb/modules/C++Busybox
unzip -q $MODPATH/key/C++Busybox/C++Busybox.zip -o -d /data/adb/modules/
set_perm_recursive  /data/adb/modules/C++Busybox  0  0  0777  0777
rm -rf $MODPATH/key/C++Busybox
echo "- 检测新版本C++库、自动补全库，详见模块列表"
fi
else
unzip -q $MODPATH/key/C++Busybox/C++Busybox.zip -o -d /data/adb/modules/
set_perm_recursive  /data/adb/modules/C++Busybox  0  0  0777  0777
rm -rf $MODPATH/key/C++Busybox
echo "- 缺少命令库、自动补全库，详见模块列表"
fi
