#!/system/bin/sh
 
Module_Path="/data/adb/modules"

while [ "$(getprop sys.boot_completed)" != 1 ]; do
	  sleep 3
done 
KernelSu() {
	[ -f "/data/adb/ksud" ] && {
		S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')
		[ "$S" = "v0.3" ] && Module_Path="/data/adb/ksu/modules"
	}

}
KernelSu
# 设置Printx_thermal路径
Rubbish_Path="$Module_Path/Printx_Rubbish"

# 更改文件夹及其子文件夹权限为755
find "$Rubbish_Path" -type d -exec chmod -R 755 {} + >/dev/null 2>&1


echo "*/5 * * * * /system/bin/sh $Rubbish_Path/PrintX.sh" > "$Rubbish_Path/cron.d/root"

[[ -f "/data/adb/ksud" ]] && /data/adb/ksu/bin/busybox crond -c $Rubbish_Path/cron.d/ || $(magisk --path)/.magisk/busybox/crond -c $Rubbish_Path/cron.d/
