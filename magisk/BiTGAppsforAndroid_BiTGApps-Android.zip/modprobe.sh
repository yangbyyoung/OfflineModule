#!/system/bin/sh
#
# This file is part of The BiTGApps Project

# Set default module
MODULE="/data/adb/modules/BiTGApps"

# Mount system partition
mount -o remount,rw,errors=continue / 2>/dev/null
mount -o remount,rw,errors=continue /dev/root 2>/dev/null
mount -o remount,rw,errors=continue /dev/block/dm-0 2>/dev/null
mount -o remount,rw,errors=continue /system 2>/dev/null

# Remove application data
if [ -f "$MODULE/disable" ]; then
  rm -rf /data/app/com.android.vending*
  rm -rf /data/app/com.google.android*
  rm -rf /data/app/*/com.android.vending*
  rm -rf /data/app/*/com.google.android*
  rm -rf /data/data/com.android.vending*
  rm -rf /data/data/com.google.android*
fi

# Disable GooglePlayServices APK
if [ -f "$MODULE/disable" ]; then
  for i in PrebuiltGmsCore; do
    mv -f /system/priv-app/$i/$i.apk /system/priv-app/$i/$i.dpk 2>/dev/null
  done
fi
