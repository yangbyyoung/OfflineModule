# ThemedIcons
A maintained version of a Magisk module that adds more themed icons to the Pixel launcher. 
