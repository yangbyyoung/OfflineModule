#define LOG_TAG "EffectVisualizer"
//#define LOG_NDEBUG 0
#include <cutils/log.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <new>
#include <time.h>
#include <audio_effects/effect_visualizer.h> //包含头文件
#>ro.vendor.audio.sfx.harmankardon=1
extern "C" {

// effect_handle_t interface implementation for visualizer effect
extern const struct effect_interface_s gVisualizerInterface;

//------音效引擎描述结构体system/priv-app/MIUIMusic

//定义音效类型Type、实现引擎UUID、版本、连接模式、实现者等信息，与Java中的Descriptor类对应
//注意：在配置文件audio_effects.conf中effects的uuid元素是指实现引擎engine-uuid，而Java层的AudioEffect.java中定义的EFFECT_TYPE_XXX是音效类型effect-type。
//当AudioEffect.java的构造函数中只指定type参数（uuid参数为EFFECT_TYPE_NULL）时，系统自动查找该音效类型可用的实现引擎。若只指定uuid参数（type参数为EFFECT_TYPE_NULL）时，系统直接使用指定的音效实现引擎。

// Google Effect Type    : e46b26a0-dddd-11db-8afd-0002a5d5c51b
// Google Visualizer UUID: d069d9e0-8329-11df-9168-0002a5d5c51b
const effect_descriptor_t gVisualizerDescriptor = {
        {0xe46b26a0, 0xdddd, 0x11db, 0x8afd, {0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b}}, // effect-type 音效类型
        {0xd069d9e0, 0x8329, 0x11df, 0x9168, {0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b}}, // engine-uuid 实现引擎
        EFFECT_CONTROL_API_VERSION, //版本
        (EFFECT_FLAG_TYPE_INSERT | EFFECT_FLAG_INSERT_FIRST), //连接模式
        0, // CPU load
        1, // Data memory
        "Visualizer", // 音效名
        "The Android Open Source Project", //实现者
};

//------音效引擎状态
enum visualizer_state_e {
    VISUALIZER_STATE_UNINITIALIZED,//未初始化
    VISUALIZER_STATE_INITIALIZED,//已初始化
    VISUALIZER_STATE_ACTIVE,//激活
};

//------包装上下文
//持有一些处理对象
//***持有SoundTouch对象
struct VisualizerContext {
    const struct effect_interface_s *mItfe;
    effect_config_t mConfig;
    uint32_t mCaptureIdx;
    uint32_t mCaptureSize;
    uint32_t mScalingMode;
    uint8_t mState;
    uint8_t mLastCaptureIdx;
    uint32_t mLatency;
    struct timespec mBufferUpdateTime;
    uint8_t mCaptureBuf[CAPTURE_BUF_SIZE];
};

//------局部方法
//重置上下文
void Visualizer_reset(VisualizerContext *pContext)

//设置I/O配置：采样率、声道、格式等
int Visualizer_setConfig(VisualizerContext *pContext, effect_config_t *pConfig)

//依据配置初始化音效引擎
int Visualizer_init(VisualizerContext *pContext)


//------音效库接口实现

//每个音效库都必须有名为AUDIO_EFFECT_LIBRARY_INFO_SYM的audio_effect_library_t结构体，该结构体的定义位于audio_effect.h，它定义了音效库的5个音效处理函数指针。
//（按C/C++语法，该结构体的赋值应位于使用的5个函数指针定义之后，提前在这是为了为了方便理解）
audio_effect_library_t AUDIO_EFFECT_LIBRARY_INFO_SYM = {
    tag : AUDIO_EFFECT_LIBRARY_TAG,
    version : EFFECT_LIBRARY_API_VERSION,
    name : "Visualizer Library",
    implementor : "The Android Open Source Project",
#if EFFECT_API_VERSION_MAJOR(EFFECT_LIBRARY_API_VERSION) <= 2
    query_num_effects : VisualizerLib_QueryNumberEffects,
    query_effect : VisualizerLib_QueryEffect,
#endif
    create_effect : VisualizerLib_Create,
    release_effect : VisualizerLib_Release,
    get_descriptor : VisualizerLib_GetDescriptor,
};
//该结构体中5个函数的定义分别为：

//音效库兼容性检查
//audio_effect_library_t的定义在audio_effect.h中，该结构体在Android4.3+时有发生变化，query_num_effects()和query_effect()被删除。如果希望做库兼容性，需要检测EFFECT_LIBRARY_API_VERSION
#if EFFECT_API_VERSION_MAJOR(EFFECT_LIBRARY_API_VERSION) <= 2
//查询音效数量（API版本检查）
int VisualizerLib_QueryNumberEffects(uint32_t *pNumEffects) 
//查询音效（API版本检查）
int VisualizerLib_QueryEffect(uint32_t index, effect_descriptor_t *pDescriptor)
#endif

//创建音效库
int VisualizerLib_Create(const effect_uuid_t *uuid, int32_t sessionId, int32_t ioId, effect_handle_t *pHandle)
//释放音效库
int VisualizerLib_Release(effect_handle_t handle)
//获取音效描述（gVisualizerDescriptor）
int VisualizerLib_GetDescriptor(const effect_uuid_t *uuid, effect_descriptor_t *pDescriptor) 

//------音效控制接口实现

//音效控制接口effect_interface_s的实现
//effect_handle_s的定义位于audio_effect.h，定义了用于音效控制的3个函数指针
//（按C/C++语法，该结构体的赋值应位于使用的5个函数指针定义之后，提前在这是为了为了方便理解）
const struct effect_interface_s gVisualizerInterface = {
        Visualizer_process,//音效处理 函数指针
        Visualizer_command,//命令执行 函数指针
        Visualizer_getDescriptor,//获取音效描述 函数指针
        NULL,//见定义
};
//该结构体中3个函数的定义分别为：

//音效处理：对音频数据进行处理，实现具体效果
//***SoundTouch的处理应放在此处
int Visualizer_process(effect_handle_t self,audio_buffer_t *inBuffer, audio_buffer_t *outBuffer)

//执行命令：执行对音效的指定操作命令
int Visualizer_command(effect_handle_t self, uint32_t cmdCode, uint32_t cmdSize, void *pCmdData, uint32_t *replySize, void *pReplyData) {
    VisualizerContext * pContext = (VisualizerContext *)self;
    int retsize;

    if (pContext == NULL || pContext->mState == VISUALIZER_STATE_UNINITIALIZED) {
        return -EINVAL;
    }

    switch (cmdCode) {//预设音效命令在audio_effect.h中定义
    case EFFECT_CMD_INIT://初始化
        if (pReplyData == NULL || *replySize != sizeof(int)) {
            return -EINVAL;
        }
        *(int *) pReplyData = Visualizer_init(pContext);
        break;
    case EFFECT_CMD_SET_CONFIG://配置
    case EFFECT_CMD_GET_CONFIG://读取配置
    case EFFECT_CMD_RESET://重置
    case EFFECT_CMD_ENABLE://启用
    case EFFECT_CMD_DISABLE://禁用
    case EFFECT_CMD_GET_PARAM: {//获取参数
        //...
        //根据传入的音效参数枚举，返回对应值
        switch (*(uint32_t *)p->data) {//（音效参数枚举在effect_visualizer.h中定义）
        case VISUALIZER_PARAM_CAPTURE_SIZE://音效参数之一
            ALOGV("get mCaptureSize = %d", pContext->mCaptureSize);
            *((uint32_t *)p->data + 1) = pContext->mCaptureSize;
            p->vsize = sizeof(uint32_t);
            *replySize += sizeof(uint32_t);
            break;
        case VISUALIZER_PARAM_SCALING_MODE://
        default://
        }
        } break;
    case EFFECT_CMD_SET_PARAM: {//设置参数
        //根据传入的音效参数枚举与值，设置参数
        switch (*(uint32_t *)p->data) {
        case VISUALIZER_PARAM_CAPTURE_SIZE://音效参数之一
            pContext->mCaptureSize = *((uint32_t *)p->data + 1);
            ALOGV("set mCaptureSize = %d", pContext->mCaptureSize);
            break;
        case VISUALIZER_PARAM_SCALING_MODE://
        case VISUALIZER_PARAM_LATENCY://
        default://
        }
        } break;
    case EFFECT_CMD_SET_DEVICE:
    case EFFECT_CMD_SET_VOLUME:
    case EFFECT_CMD_SET_AUDIO_MODE:
        break;

    //Visualizer自增的命令
    case VISUALIZER_CMD_CAPTURE:
        //...
        break;
    default://
    }

    return 0;
}

//获取音效描述（gVisualizerDescriptor）
//与int VisualizerLib_GetDescriptor(const effect_uuid_t *uuid, effect_descriptor_t *pDescriptor) 不同
int Visualizer_getDescriptor(effect_handle_t self, effect_descriptor_t *pDescriptor)
�read/system/priv_app/AudioEffect/AudioEffect_1.4.apk                ro.vendor.audio.sfx.harmankardon=1audio player; music player==turepublic Equalizer(int priority, int audioSession)
    throws IllegalStateException, IllegalArgumentException,
           UnsupportedOperationException, RuntimeException {
        super(EFFECT_TYPE_EQUALIZER, EFFECT_TYPE_NULL, priority, audioSession);LOCAL_PATH:= $(call my-dir)

# Visualizer library
include $(CLEAR_VARS)

LOCAL_SRC_FILES:= \
    EffectVisualizer.cpp #实现源码.cpp

LOCAL_CFLAGS+= -O2

LOCAL_SHARED_LIBRARIES := \
    libcutils \
    libdl 

LOCAL_MODULE_PATH := $(TARGET_OUT_SHARED_LIBRARIES)/soundfx #编译出so的输出位置，默认/system/lib/soundfx/
LOCAL_MODULE:= libvisualizer #so库名：libvisualizer.so

LOCAL_C_INCLUDES := \
    $(call include-path-for, graphics corecg) \
    $(call include-path-for, audio-effects) # 调用宏定义函数批量引入库，audio-effects的定义位于/build/core/pathmap.mk，其值为system/media/audio_effects/include ，该位置包含了effect_visualizer.h

include $(BUILD_SHARED_LIBRARY)