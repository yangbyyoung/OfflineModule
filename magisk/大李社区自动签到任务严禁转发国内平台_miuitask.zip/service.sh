#!/system/bin/sh
MODDIR=${0%/*}

nohup ${MODDIR}/miuitask