cd $TMPDIR/mods
echo ""
echo "∞————————————————————————∞"
echo "－当前可选的模块功能有："
#来自酷安@嘟嘟斯基，感谢大佬
function get_prop() {
  cat $MOD/mod_info.sh | grep "^$1=" | cut -f2 -d '='|sed 's/\"/ 🕸 ️/g'
}
for MOD in `ls $TMPDIR/mods`;do
echo "－ $(get_prop "mod_name") "
done
echo ""
echo "∞————————————————————————∞"
#abort