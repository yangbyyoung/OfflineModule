cd /data/adb/modules/
for module_id in $(ls)
do
if [ ! "$module_id" = "zhiwentexiao_ndcoloros" ];then
  let id++
  module_name=$(cat $module_id/module.prop | grep 'name')
  module_author=$(cat $module_id/module.prop | grep 'author')
  module_description=$(cat $module_id/module.prop | grep 'description')
  if [ -e "$module_id/system/media/theme/default/com.android.systemui" ];then
    ui_print "******************************"
    ui_print "******************************"
    ui_print "    模块id：$module_id"
    ui_print "    名称：${module_name:5}"
    ui_print "    作者：${module_author:7}"
    ui_print "    简介：${module_description:12}"
    ui_print "  此模块已安装SystemUI主题相关内容"
    ui_print "******************************"
    ui_print "- 移动此模块内容移至本模块"
    mkdir -p $MODPATH/zhiwen
    unzip -o $module_id/system/media/theme/default/com.android.systemui -d $MODPATH/zhiwen >&2
    mkdir -p $MODPATH/system/
    cp -rf $module_id/system $MODPATH
    rm -rf $MODPATH/system/media/theme/default/com.android.systemui
    rm -rf $module_id/system
    sed -i '5,$d' $module_id/module.prop
    echo -e "author=相见即是缘\ndescription=${module_description:12}模块已被清空不会生效" >> $module_id/module.prop
  fi
fi
done
cd /data/adb/modules_update/
for module_id in $(ls)
do
if [ ! "$module_id" = "zhiwentexiao_ndcoloros" ];then
  let id++
  module_name=$(cat $module_id/module.prop | grep 'name')
  module_author=$(cat $module_id/module.prop | grep 'author')
  module_description=$(cat $module_id/module.prop | grep 'description')
  if [ -e "$module_id/system/media/theme/default/com.android.systemui" ];then
    ui_print "******************************"
    ui_print "******************************"
    ui_print "    模块id：$module_id"
    ui_print "    名称：${module_name:5}"
    ui_print "    作者：${module_author:7}"
    ui_print "    简介：${module_description:12}"
    ui_print "  此模块已安装SystemUI主题相关内容"
    ui_print "******************************"
    ui_print "- 正在删除此模块内容"
    ui_print "- 并移动此模块内容移至本模块"
    mkdir -p $MODPATH/zhiwen
    unzip -o $module_id/system/media/theme/default/com.android.systemui -d $MODPATH/zhiwen >&2
    mkdir -p $MODPATH/system/
    cp -rf $module_id/system $MODPATH
    rm -rf $MODPATH/system/media/theme/default/com.android.systemui
    rm -rf $module_id
  fi
fi
done
