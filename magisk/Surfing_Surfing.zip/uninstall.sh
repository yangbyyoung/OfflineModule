#!/system/bin/sh

rm -rf /data/adb/service.d/Surfing_service.sh
rm -rf /data/adb/box_bll
# 2>/dev/null