echo ----------------------------
script_name="mb.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
    echo "查杀 $lastID"
    kill -KILL $lastID
    echo -----------已关闭-----------
else
    echo -----你都没启动呢-----
fi
echo ----------------------------
