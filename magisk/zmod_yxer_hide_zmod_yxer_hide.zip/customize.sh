#!/system/bin/sh

# Android 11.0 or newer
if [[ "$(getprop ro.build.version.sdk)" -lt 30 ]]; then
    ui_print ""
    ui_print "Requires Android 11+"
    ui_print ""
abort
fi

v=26300
if [ "$MAGISK_VER_CODE" -lt "$v" ]; then
  ui_print "*********************************************************"
  ui_print "! Magisk version is too old!"
  ui_print "! Please update Magisk to latest version"
  abort    "*********************************************************"
fi

chmod 755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/resetprop"
