#! /vendor/bin/sh
MODDIR=${0%/*}
# 应用配置
{
sh /system/bin/swap.sh
# sh /system/bin/hw.sh
sh /system/bin/snow.sh
sh /system/bin/fstrim.sh
printf "模块启动完成"
echo $(date +%F%n%T)
} >>/cache/snow.log