#!/system/bin/sh
sdcard="/data/media/0/Android"
log="$sdcard/MIUI小优化配置/日志.log"
echo_Log () {
    echo "$(date "+%T") $@" >> $log
}
Permission_Setting() {
chmod 0644 $1
chown root:root $1
}
[[ -d /data/adb/modules/fstrim_A ]] && return
[[ -d /data/adb/modules/fstrim_y ]] && return
[[ ! -d /data/adb/modules/fstrim_y ]] && mkdir -p /data/adb/modules/fstrim_y

# 输出到module.prop
echo "id=sdcardfs_y
name=fstrim读写优化
version=$(date +"%Y%m%d")
versionCode=20210224
author=阿巴酱
description=用于将已挂载的文件系统的未使用块进行回收操作，将在每次重启30分钟后执行一次 ; 由【MIUI小优化模块】自动创建: $(date "+%T")" > /data/adb/modules/fstrim_y/module.prop

# 输出到service.sh
echo '#!/system/bin/sh
sleep 30m
    if [[ $(getprop ro.build.version.release) -ge 11 ]]; then
      /dev/*/.magisk/busybox/fstrim -v /system
      /dev/*/.magisk/busybox/fstrim -v /vendor
      /dev/*/.magisk/busybox/fstrim -v /cache
      /dev/*/.magisk/busybox/fstrim -v /data
    else
      /sbin/.magisk/busybox/fstrim -v /system
      /sbin/.magisk/busybox/fstrim -v /vendor
      /sbin/.magisk/busybox/fstrim -v /cache
      /sbin/.magisk/busybox/fstrim -v /data
    fi' > /data/adb/modules/fstrim_y/service.sh

Permission_Setting /data/adb/modules/fstrim_y/service.sh >/dev/null
echo_Log "fstrim安装成功 重启生效"