#!/system/bin/sh

###禁用sdcardfs，恢复fuse
setprop persist.fuse_sdcard true
setprop persist.sys.fuse.default_fuse_enabled true
setprop persist.sys.fflag.override.settings_fuse true
setprop persist.device_config.storage_native_boot.fuse_enabled true
setprop ro.sys.sdcardfs false
setprop persist.sys.fuse true
