$BOOTMODE || abort "
!!! ONLY be installed on magisk. 
!!! 仅支持在 Magisk 下安装。
"
[ $API -ge 30 ] || abort "
!!! ONLY support Android 11 (API 30) or above. 
!!! 仅支持 安卓11 或以上。
"
[ $ARCH == "arm64" ] || abort "
!!! ONLY support ARM64 platform. 
!!! 仅支持 ARM 64位 平台。
"

chmod a+x $MODPATH/service.sh

echo "- 安装完毕，重启生效"
