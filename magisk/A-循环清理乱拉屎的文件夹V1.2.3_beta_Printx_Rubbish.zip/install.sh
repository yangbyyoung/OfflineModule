##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
print_modname() {
    return
}


# Copy/extract your module files into $MODPATH in on_install.
on_install() {
  unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "- 酷安：@只喝橘子味汽水"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "- 警告⚠：酷安第三刷机委提醒您：规则填写不规范,机主两行泪！！！"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "-Magisk用户配置文件路径：/storage/emulated/0/Android/PrintX/清理垃圾/"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "-KernelSU用户配置文件路径: /data/media/0/Android/PrintX/清理垃圾/"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "- 群组：699459180"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"
  
  ui_print "- WeChat(个人)：Suonian-XingHe"
  ui_print "- ⚠⚠⚠————————————————————————————————————————————————————————————————"

  # 作者：只喝橘子味汽水
  # 群组：699459180
}
set_permissions() {
    return
}