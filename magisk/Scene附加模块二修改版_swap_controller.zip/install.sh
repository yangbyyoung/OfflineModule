SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""

# 移除旧模块
rm -rf "/data/adb/modules/scene_swap_controller/"
rm -rf "/data/adb/modules_update/scene_swap_controller/"
rm -rf "/data/adb/modules/scene_swap_controller_modified/"
rm -rf "/data/adb/modules_update/scene_swap_controller_modified/"
rm -rf "/data/swap_config.conf"
rm -rf "/cache/swap.log"
if [[ -f /data/writeback ]]; then
  chmod 777 /data/writeback 2>/dev/null
  chown system:system /data/writeback 2>/dev/null
fi

update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $MODPATH/swap/keep.conf
}

print_modname() {

  # 获取模块版本号
  TMPDIR=/dev/tmp
  swap_version="$TMPDIR/module.prop"
  function get_prop() {
    cat $swap_version | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
  }
  module=$(get_prop version)

  # 输出信息
  echo " ****************************************"
  echo "  ☞模块版本：$module"
  echo "  ☞设备型号：$model"
  echo "  ☞安卓版本：Android$sdk"
  echo " ****************************************"
  echo "  ✔配置文件位置：详见模块介绍"
  echo "  ✔欢迎加入模块交流QQ群：582189751"
  echo "  ✔你可以前往酷安关注我：“开心小阳光123”"
  echo " ****************************************"
}

# 检测内核支持的压缩方式
check_result1=`cat /sys/block/zram0/comp_algorithm | grep lz4`
check_result2=`cat /sys/block/zram0/comp_algorithm | grep zstd`
check_result3=`cat /sys/block/zram0/comp_algorithm | grep lzo-rle`
if [[ "$check_result1" != "" ]]; then
  comp_algorithm=lz4
elif [[ "$check_result2" != "" ]]; then
  comp_algorithm=zstd
elif [[ "$check_result3" != "" ]]; then
  comp_algorithm=lzo-rle
else
  comp_algorithm=lzo
fi

# 内存管理方式
model=$(getprop ro.product.marketname)
[ ! "$model" ] && model=$(getprop ro.product.name)
model=${model// /-}
sdk=$(getprop ro.build.version.release)
conf=/data/adb/modules/swap_controller/swap

if [[ "$sdk" == "13" ]]; then
attention="
# 注意：安卓13仅部分设备支持lmk，否则建议选择psi"
memory_control=psi1
else
memory_control=lmk
attention=""
fi

# 创建配置参数
swap=false
swap_size=0
swap_priority=-2
swap_use_loop=false
zram=true
zram_size=6144
swappiness=100
min_free_kbytes=8192
extra_free_kbytes=8192
zram_writeback=true
watermark_scale_factor=100
writeback_size=2048
writeback_sleep=10
writeback_number=10
writeback_writeback=10

# 开始安装
on_install() {
unzip -o "$ZIPFILE" 'system/*' 'swap/*' -d $MODPATH >&2
function get_prop() {
  cat $conf/keep.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
# 读取参数
current_swap=$(get_prop swap)
current_swap_size=$(get_prop swap_size)
current_swap_priority=$(get_prop swap_priority)
current_swap_use_loop=$(get_prop swap_use_loop)
current_zram=$(get_prop zram)
current_zram_size=$(get_prop zram_size)
current_comp_algorithm=$(get_prop comp_algorithm)
current_swappiness=$(get_prop swappiness)
current_min_free_kbytes=$(get_prop min_free_kbytes)
current_extra_free_kbytes=$(get_prop extra_free_kbytes)
current_watermark_scale_factor=$(get_prop watermark_scale_factor)
current_memory_control=$(get_prop memory_control)
current_zram_writeback=$(get_prop zram_writeback)
current_writeback_size=$(get_prop writeback_size)
current_writeback_sleep=$(get_prop writeback_sleep)
current_writeback_number=$(get_prop writeback_number)
current_writeback_writeback=$(get_prop writeback_writeback)
# 应用参数
if [[ "$current_swap" != "" ]]; then
swap="$current_swap"
update_system_prop swap $swap
fi
if [[ "$current_swap_size" != "" ]]; then
swap_size="$current_swap_size"
update_system_prop swap_size $swap_size
fi
if [[ "$current_swap_priority" != "" ]]; then
swap_priority="$current_swap_priority"
update_system_prop swap_priority $swap_priority
fi
if [[ "$current_swap_use_loop" != "" ]]; then
swap_use_loop="$current_swap_use_loop"
update_system_prop swap_use_loop $swap_use_loop
fi
if [[ "$current_zram" != "" ]]; then
zram="$current_zram"
update_system_prop zram $zram
fi
if [[ "$current_zram_size" != "" ]]; then
zram_size="$current_zram_size"
update_system_prop zram_size $zram_size
fi
if [[ "$current_comp_algorithm" != "" ]]; then
comp_algorithm="$current_comp_algorithm"
update_system_prop comp_algorithm $comp_algorithm
fi
if [[ "$current_swappiness" != "" ]]; then
swappiness="$current_swappiness"
update_system_prop swappiness $swappiness
fi
if [[ "$current_min_free_kbytes" != "" ]]; then
min_free_kbytes="$current_min_free_kbytes"
update_system_prop min_free_kbytes $min_free_kbytes
fi
if [[ "$current_extra_free_kbytes" != "" ]]; then
extra_free_kbytes="$current_extra_free_kbytes"
update_system_prop extra_free_kbytes $extra_free_kbytes
fi
if [[ "$current_watermark_scale_factor" != "" ]]; then
watermark_scale_factor="$current_watermark_scale_factor"
update_system_prop watermark_scale_factor $watermark_scale_factor
fi
if [[ "$current_memory_control" != "" ]]; then
memory_control="$current_memory_control"
update_system_prop memory_control $memory_control
fi
if [[ "$current_zram_writeback" != "" ]]; then
zram_writeback="$current_zram_writeback"
update_system_prop zram_writeback $zram_writeback
fi
if [[ "$current_writeback_size" != "" ]]; then
writeback_size="$current_writeback_size"
update_system_prop writeback_size $writeback_size
fi
if [[ "$current_writeback_sleep" != "" ]]; then
writeback_sleep="$current_writeback_sleep"
update_system_prop writeback_sleep $writeback_sleep
fi
if [[ "$current_writeback_number" != "" ]]; then
writeback_number="$current_writeback_number"
update_system_prop writeback_number $writeback_number
fi
if [[ "$current_writeback_writeback" != "" ]]; then
writeback_writeback="$current_writeback_writeback"
update_system_prop writeback_writeback $writeback_writeback
fi

# 配置回写
if [[ -f '/sys/block/zram0/backing_dev' ]]; then
zram_writeback_config="---------------------------------------------------------------------------
# 内存扩展回写（default表示保持系统默认配置）
zram_writeback=$zram_writeback

# 回写块大小 [MB]（修改后需手动删除/data/writeback文件）
writeback_size=$writeback_size

# 检测间隔 [秒]（检测前台应用是否切换的频率）
writeback_sleep=$writeback_sleep

# 切换进程数 [个]（前台应用切换达到该值后运行一次回写）
writeback_number=$writeback_number

# 回写阈值 [次]（填写0为表示只进行小回写，填写1则表示只进行大回写）
# 当小回写次数达到该值时进行一次大回写，否则进行小回写
writeback_writeback=$writeback_writeback"
else
zram_writeback_config=""
fi

echo "✔ 模块版本：$module，设备型号：$model，安卓版本：Android$sdk
✔ 注意：修改参数后需重启手机才能生效（true为开启，false为关闭）
---------------------------------------------------------------------------
# 配置swapfile
swap=$swap

# swap大小 [MB]（修改后需手动删除/data/swapfile文件）
swap_size=$swap_size

# swapfile使用顺序
# [0]与zram同时使用，[-2]用完zram后再使用，[5]优先于zram使用
swap_priority=$swap_priority

# swapfile挂载为回环设备
swap_use_loop=$swap_use_loop
---------------------------------------------------------------------------
# 配置zram
zram=$zram

# zram大小 [MB]
zram_size=$zram_size

# zram压缩算法
comp_algorithm=$comp_algorithm

# swap积极性
swappiness=$swappiness

# 保留物理内存 [kbytes]（数值越大越易触发内存回收）
min_free_kbytes=$min_free_kbytes
extra_free_kbytes=$extra_free_kbytes

# 内存水位线（数值越大内存回收越积极）
watermark_scale_factor=$watermark_scale_factor

# 内存管理方式（请根据需要进行选择）
# 保后台能力：lmk > psi1 > psi2 > psi3
# lmk偏向保后台，psi偏向流畅度，psi3为省电模式${attention}
memory_control=$memory_control
$zram_writeback_config" > $MODPATH/swap/swap.conf
echo "请先重启手机！" >$conf/swap.conf
}
