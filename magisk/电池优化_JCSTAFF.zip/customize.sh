#!/sbin/sh
SKIPUNZIP=0
REPLACE=""

ui_print "install..."
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
ui_print "done"
set_perm_recursive $MODPATH 0 0 0755 0777
mkdir -p /sdcard/Android/TNT配置
cat $MODPATH/eveio.conf > /sdcard/Android/TNT配置/eveio.conf