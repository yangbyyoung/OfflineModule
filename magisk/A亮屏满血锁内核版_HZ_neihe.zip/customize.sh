SKIPUNZIP=0
REPLACE=""
echo " "
echo "*******************"
echo "- 手机信息"
echo "- SDK: $(getprop ro.build.version.sdk)"
echo "- 设备: $(getprop ro.fota.oem)"
echo "- 设备代号: $(getprop ro.product.device)"
echo "- 安卓版本: Android $(getprop ro.build.version.release)"
echo "*******************"
echo "此版为锁内核版，切不删温控，卸载恢复"
echo "与亮屏闪充可同时安装但是不推荐"
echo "理论全机型可用"
echo "此模块不删温控！！！"
echo "别再问删不删温控了，模块不删温控！！"
echo "*******************"
echo "22.06.30已加班更新"
echo "*******************"
echo " "
var_device="`getprop ro.fota.oem`"
echo "当前设备代号为为: $(getprop ro.fota.oem)"
case "${var_device}" in
"samsung")
  rm -rf $MODPATH/*
  abort "- ${var_device} 当前机型未适配！"
;;
"*")
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
;;
esac