#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

install_magisk_busybox 2>/dev/null

id="$(echo "${0%/*}" | cut -d'/' -f5)"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"


function show_value() {
	local value=$1
	local file="${MODPATH}/配置.conf"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function limitlog(){
	local logfile="${2}"
	local size="${1}"
	local maxsize="$((1024*$size))"
	test ! -f "${logfile}" && echo "日志不存在！" && return 1 
	local filesize="$(ls -l "${logfile}" | awk '{print $5}')"
	if test "$filesize" -gt "$maxsize" ;then
		echo " " > "${logfile}"
	else 
		return 1
	fi
}

function change_description(){
local file="$MODPATH/module.prop"
local logfile="$MODPATH/Running.log"
local count_file="$MODPATH/time"
test ! -f "$count" && count="0" || count="$(cat $count_file)"
local mod_description="$3"
local add_log="$4"
test -z $add_log && add_log="false"
test -z $mod_description && mod_description="false"
local value=$(getprop persist.sys.locale)
test "$value" = "" && value=$(getprop ro.product.locale)
if test "$(echo $value | grep -w "zh")" != "" ;then
	$mod_description && sed -i "/^description=/c description=[ $(date '+%F %T') ]，"$1" || 已经为您救砖 [ $count ] 次 || 在 [ /cache /data /mnt/vendor/persist /data/unencrypted ] 目录创建文件 [ dismod ] 可禁用模块，[ remod ]则移除所有模块，其他情况会自动救砖。" "$file"
		$add_log && echo "$(date '+%F %T') $1" >> "$logfile"
	else
		$mod_description && sed -i "/^description=/c description=[ $(date '+%F %T') ]，"$2" ||  has solved the loop start for you [ $count ] times || Create a file [dismod] in [ /cache /data /mnt/vendor/persist/ data/unencrypted ] directory to disable the modules, and [remod] to remove all modules. Otherwise, the brick will be saved automatically." "$file"
	$add_log && echo "$(date '+%F %T') $2" >> "$logfile"
fi
limitlog "10" "$logfile" 
}


function disable_module(){
for i in $(ls -d ${MODPATH%/*}/* )
do
	test "$id" = "${i##*/}" && continue
	touch "$i/disable"
done
change_description "[I]已经禁用所有模块！" "[I]Disable all modules." "false" "true"
}

function kill_package_cache(){
	rm -rf /data/resource-cache/*
	test -e "/data/system/package_cache" && rm -rf /data/system/package_cache/*
}

function recovery_disable_app(){
	rm -rf /data/system/users/0/package-restrictions.xml
}

function remove_settings(){
	mv -f /data/system/users/0/settings_secure.xml /data/system/users/0/settings_secure.xml.bak
	mv -f /data/system/display-manager-state.xml /data/system/display-manager-state.xml.bak
}

function disable_magisk_service_post(){
if test -d "/data/adb/service.d" -o -d "/data/adb/post-fs-data.d" ;then
	mv -f "/data/adb/post-fs-data.d" "/data/adb/post-fs-data.d.bak"
	mv -f "/data/adb/service.d" "/data/adb/service.d.bak"
fi
}


function remove_module(){
for i in $(ls -d ${MODPATH%/*}/* )
do
	test "$id" = "${i##*/}" && continue
	touch "$i/remove"
done
change_description "[W]已经禁用所有模块！" "[W]Remove all modules." "false" "true"
}

function find_zygote(){
local pross="zygote"
local pross64="zygote64"
if test "$(pidof "$pross64")" != "" ;then
	echo "$(pidof "$pross64" )"
	return 0
elif test "$(pidof "$pross")" != "" ;then
	echo "$(pidof "$pross" )"
	return 0
fi
}

function compare_value(){
local value1="$1"
local value2="$2"
for i in $value1
do
	for o in $value2
			do
		test "$i" = "$o" && BOOTMODE="true" || BOOTMODE="false"
	done
done
echo "$BOOTMODE"
}

function run_main(){
if test $(show_value "模块") == 禁用 ;then
	disable_module
elif test $(show_value "模块") == 移除 ;then
	remove_module 
fi

if test $(show_value "清理缓存") == 是 ;then
	kill_package_cache 2>/dev/null
	change_description "[I] 已删除 [/data/system/package_cache]" "[I] Delete [/data/system/package_cache]" "false" "true"
	change_description "[I] 已删除 [/data/resource-cache]" "[I] Delete [/data/resource-cache]" "false" "true"
fi

if test $(show_value "解冻") == 是 ;then
	recovery_disable_app 2>/dev/null
	change_description "[I] 已删除 [/data/system/users/0/package-restrictions.xml]" "[I] Delete [/data/system/users/0/package-restrictions.xml]" "false" "true"
fi

if test $(show_value "屏幕分辨率恢复") == 是 ;then
	remove_settings 2>/dev/null
	change_description "[I] 已经将 [/data/system/users/0/settings_secure.xml] 和 [/data/system/display-manager-state.xml] 改后缀名为 [bak] " "[I] Rename [/data/system/display-manager-state.xml.bak] and [/data/system/users/0/settings_secure.xml.bak]" "false" "true"
fi

if test $(show_value "禁用magisk自定义脚本") == 是 ;then
	disable_magisk_service_post 2>/dev/null
	change_description "[I] 已经将magisk自定义脚本改名为 [/data/adb/service.d.bak] 和 [/data/adb/post-fs-data.d.bak]" "[I] Rename [/data/adb/post-fs-data.d.bak] and [/data/adb/service.d.bak]" "false" "true"
fi

if test -f "$MODPATH/time" ;then
	echo "$(( $(cat $MODPATH/time) +1 ))" > "$MODPATH/time"
else 
	echo "1" > "$MODPATH/time"
fi
}



