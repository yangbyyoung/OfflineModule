SKIPUNZIP=0
REPLACE=""
echo " "
echo "*******************"
echo "- 手机信息"
echo "- SDK: $(getprop ro.build.version.sdk)"
echo "- 设备: $(getprop ro.fota.oem)"
echo "- 设备代号: $(getprop ro.product.device)"
echo "- 安卓版本: Android $(getprop ro.build.version.release)"
echo "*******************"
sleep 1
echo "！！！请仔细阅读以下说明！！！"
echo "-------------------------------------"
echo "现已支持安卓13版本，以及MIUI14"
echo "小米12x测试通过"
echo "非小米手机有卡米风险，请自测"
echo "！此模块不删温控"
echo "与温控模块不冲突，但删除温控=此模块无效"
echo "暂未收到跳电反馈"
echo "MIUI 13考虑使用2.7版本"
echo "任何问题 关闭模块即恢复 无残留"
echo "*******************"
sleep 1
echo "2.7.2版本更新如下:"
echo "1，修改温度墙，44度降流，46度撞墙"
echo "2，支持MIUI14，NFC正常（感谢@御坂Thepoor）"
echo "3，修复上版本降流错误问题"
echo "功劳都是两位大佬的，本人仅仅是将其整合了一下"
echo "2.7.3版本更新如下:"
echo "同步御坂大佬8.5.6温控删除策略"
echo " "
var_device="`getprop ro.fota.oem`"
echo "当前设备代号为为: $(getprop ro.fota.oem)"
case "${var_device}" in
"samsung")
  rm -rf $MODPATH/*
  abort "- ${var_device} 当前机型未适配！"
;;
"*")
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
;;
esac