#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}
sleep 6
stop lmkd
sleep 1
echo 0 > /sys/module/lowmemorykiller/parameters/enable_lmk
echo 0 > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo 0 > /sys/module/process_reclaim/parameters/enable_process_reclaim
# echo 0 > /sys/module/process_mm_reclaim/parameters/process_reclaim_enable
echo "5120,7680,10240,12800,19200,25600" > /sys/module/lowmemorykiller/parameters/minfree
resetprop --file $MODDIR/system.prop
echo 1 > /sys/module/lowmemorykiller/parameters/enable_lmk
start lmkd