#!/system/bin/sh
am start -a android.intent.action.VIEW -d https://gitee.com/Petit-Abba/wake-up >/dev/null 2>&1