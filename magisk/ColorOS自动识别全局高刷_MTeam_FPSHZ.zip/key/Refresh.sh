<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<!-- format: mode_auto-mode_90-mode_60-mode_120
     value: 0(unspecified), 1(90Hz), 2(60Hz), 3(120Hz)
     rateId="3-1-2-3" the preferred refresh rate id per setting mode
     setting mode: auto  ,90hz     ,60hz  ,120hz
     refresh rate: 120hz ,default,  60hz  ,120hz
-->
<refresh_rate_config version="20220817" ratemagic="865R60_90_120">
<!-- cts activity -->
  <item package="android.view.cts" activity="android.view.cts/.DisplayRefreshRateCtsActivity" rateId="3-1-2-3" />  <!--CTS测试fail-->
  <item package="android.view.cts" activity="android.view.cts/.surfacevalidator.CapturedActivity" rateId="3-1-2-3" />  <!--CTS测试fail-->
<!-- other activity -->
  <item package="com.orange.live" activity="com.orange.live/com.tg.live.ui.activity.RoomActivity" rateId="3-1-2-3" />  <!--桔色直播中直播场景-->
  <item package="com.fosung.lighthouse" activity="com.fosung.lighthouse/.master.amodule.main.activity.NewsDetailActivity" rateId="3-1-2-3" />  <!--灯塔党建中视频-->
  <item package="com.quanmincai.caipiao" activity="com.quanmincai.caipiao/com.quanmincai.activity.information.ActionDetailActivity" rateId="3-1-2-3" />  <!--全民彩票中视频-->
  <item package="io.dcloud.UNI098B211" activity="io.dcloud.UNI098B211/io.dcloud.PandoraEntryActivity" rateId="3-1-2-3" />  <!--短视频去水印中视频-->
  <item package="com.ctdsbwz.kct" activity="com.ctdsbwz.kct/.ui.activity.NewsDetailActivity" rateId="3-1-2-3" />  <!--看楚天中视频-->
  <item package="com.cjtec.fmradio" activity="com.cjtec.fmradio/com.yidian.newssdk.core.detail.article.video.YdVideoActivity" rateId="3-1-2-3" />  <!--FM手机调频收音机中视频-->
  <item package="com.coloros.video" activity="com.coloros.video/com.oppo.video.mycenter.MoviePlayerActivity" rateId="3-1-2-3" />  <!--内置视频-->
  <item package="com.tencent.android.qqdownloader" activity="com.tencent.android.qqdownloader/com.tencent.cloud.activity.VideoActivityV2" rateId="3-1-2-3" />  <!--应用宝中视频-->
  <item package="com.qqgame.hlddz" activity="com.qqgame.hlddz/com.tencent.msdk.webview.WebViewActivity" rateId="3-1-2-3" />  <!--欢乐斗地主中视频-->
  <item package="com.suning.mobile.epa" activity="com.suning.mobile.epa/com.suning.webview.H5UCBaseActivity" rateId="3-1-2-3" />  <!--苏宁金融中视频-->
  <item package="com.kwai.videoeditor" activity="com.kwai.videoeditor/.activity.WebActivity" rateId="3-1-2-3" />  <!--快影中视频-->
  <item package="com.chinamobile.mcloud" activity="com.chinamobile.mcloud/cn.hotview.tv.PlayerActivity" rateId="3-1-2-3" />  <!--和彩云中视频-->
  <item package="com.uroad.carclub" activity="com.uroad.carclub/.FM.activity.ArticleDetailActivity" rateId="3-1-2-3" />  <!--ETC车宝中视频-->
  <item package="com.dalongtech.cloud" activity="com.dalongtech.cloud/.app.home.HomePageActivity" rateId="3-1-2-3" />  <!--云电脑中视频-->
  <item package="com.superstar.fantuan" activity="com.superstar.fantuan/com.asiainno.starfan.imagereview.ImagePagerActivity" rateId="3-1-2-3" />  <!--超级星饭团中视频播放-->
  <item package="com.superstar.fantuan" activity="com.superstar.fantuan/com.asiainno.starfan.media.VideoDetailActivity" rateId="3-1-2-3" />  <!--超级星饭团中视频播放-->
  <item package="com.xm.csee" activity="com.xm.csee/com.xworld.MainActivity" rateId="3-1-2-3" />  <!--超级看看中视频-->
  <item package="info.red.virtual" activity="info.red.virtual/com.yidian.newssdk.core.detail.article.video.YdVideoActivity" rateId="3-1-2-3" />  <!--微信多开悟空分身中视频-->
  <item package="com.fiberhome.exmobi.client.gaeaclientandroidedn7262" activity="com.fiberhome.exmobi.client.gaeaclientandroidedn7262/com.wdtrgf.homepage.ui.activity.ProductDetailActivity" rateId="3-1-2-3" />  <!--天然工坊中视频-->
  <item package="com.cloudwallet" activity="com.cloudwallet/.ui.activity.VideoWebActivity" rateId="3-1-2-3" />  <!--云钱包中视频-->
  <item package="kaixin4.xiaoshuo3" activity="kaixin4.xiaoshuo3/.MainActivity" rateId="3-1-2-3" />  <!--小公主苏菲亚全集中视频-->
  <item package="com.sicent.app.baba" activity="com.sicent.app.baba/.ui.setting.BabaWebActivity" rateId="3-1-2-3" />  <!--网喵中视频-->
  <item package="com.tencent.qqgame.xq" activity="com.tencent.qqgame.xq/com.tencent.msdk.webview.WebViewActivity" rateId="3-1-2-3" />  <!--天天象棋中视频-->
  <item package="com.husor.beibei" activity="com.husor.beibei/.pdtdetail.PdtDetailActivity" rateId="3-1-2-3" />  <!--贝贝中视频-->
  <item package="com.truckhome.bbs" activity="com.truckhome.bbs/.news.activity.VideoDetailsActivity" rateId="3-1-2-3" />  <!--卡车之家中视频-->
  <item package="com.yirendai" activity="com.yirendai/.ui.more.WebActivity" rateId="3-1-2-3" />  <!--宜人贷借款中视频-->
  <item package="com.gdhbgh.activity" activity="com.gdhbgh.activity/com.telecom.vhealth.ui.activities.movement.MovementWebActivity" rateId="3-1-2-3" />  <!--翼健康中视频-->
  <item package="com.gdhbgh.activity" activity="com.gdhbgh.activity/com.telecom.vhealth.ui.activities.main.MainActivity5" rateId="3-1-2-3" />  <!--翼健康中视频-->
  <item package="com.greenline.guahao" activity="com.greenline.guahao/.webkit.MainProcessCommonWebActivity" rateId="3-1-2-3" />  <!--微医中视频-->
  <item package="com.youliao.topic" activity="com.youliao.topic/.MainActivity" rateId="3-1-2-3" />  <!--有料看看中视频-->
  <item package="com.jx.privatebrowser" activity="com.jx.privatebrowser/com.cy.browser.BrowserActivity" rateId="3-1-2-3" />  <!--私密浏览器中视频-->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/dov.com.qq.im.QIMCameraCaptureActivity" rateId="3-1-2-3" />  <!--QQ中拍摄场景-->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/.activity.aio.photo.AIOGalleryActivity" rateId="3-1-2-3" />  <!--QQ聊天界面播放小视频-->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/.gallery.view.AIOGalleryActivity" rateId="3-1-2-3" />  <!--QQ聊天界面播放小视频,新版本-->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/.minigame.ui.GameActivity3" rateId="3-1-2-3" />  <!--QQ小游戏-->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/com.tencent.av.ui.AVActivity" rateId="3-1-2-3" />  <!-- bug 627267 -->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/com.tencent.av.ui.VideoInviteActivity" rateId="3-1-2-3" />  <!-- bug 627267 -->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/.olympic.activity.ScanTorchActivity" rateId="3-1-2-3" />  <!-- bug 700656 -->
  <item package="com.tencent.mobileqq" activity="com.tencent.mobileqq/com.tencent.av.ui.VChatActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!-- bug 2946142 qq通话页面 -->
  <item package="com.youloft.calendar" activity="com.youloft.calendar/.WebActivity" rateId="3-1-2-3" />  <!--万年历中播放视频-->
  <item package="com.taobao.mobile.dipei" activity="com.taobao.mobile.dipei/com.alipay.mobile.nebulacore.ui.H5Activity" rateId="3-1-2-3" />  <!--口碑中视频播放-->
  <item package="com.Qunar" activity="com.Qunar/com.mqunar.hy.browser.activity.HyWebActivity01" rateId="3-1-2-3" />  <!--去哪旅行中视频播放-->
  <item package="com.yiban.app" activity="com.yiban.app/.activity.LightAppActivity" rateId="3-1-2-3" />  <!--易班中视频播放-->
  <item package="com.dotamax.app" activity="com.dotamax.app/com.max.app.module.live.WebViewActivity" rateId="3-1-2-3" />  <!--max+中视频播放-->
  <item package="video.vue.android" activity="video.vue.android/.footage.ui.timeline.fullscreen.FullScreenVideoActivity" rateId="3-1-2-3" />  <!--vue中视频播放-->
  <item package="com.xinhang.mobileclient" activity="com.xinhang.mobileclient/.ui.activity.HomeActivity" rateId="3-1-2-3" />  <!--河南移动中小视频播放-->
  <item package="com.taobao.taobao" activity="com.taobao.taobao/com.taobao.taolive.room.TaoLiveVideoActivity" rateId="3-1-2-3" />  <!--淘宝中直播界面-->
  <item package="com.sina.weibo" activity="com.sina.weibo/.video.recommend.RecommendVideoFeedActivity" rateId="3-1-2-3" />  <!--微博中视频播放-->
  <item package="com.sina.weibo" activity="com.sina.weibo/.video.detail.VideoDetailActivity" rateId="3-1-2-3" />  <!--微博中视频播放-->
  <item package="com.sina.weibo" activity="com.sina.weibo/.story.gallery.activity.VVSActivity" rateId="3-1-2-3" />  <!--微博中视频播放-->
  <item package="com.ss.android.article.news" activity="com.ss.android.article.news/com.ss.android.video.impl.feed.immersion.ImmerseDetailActivity" rateId="3-1-2-3" />  <!--今日头条中视频播放-->
  <item package="com.ss.android.article.news" activity="com.ss.android.article.news/com.ss.android.live.host.livehostimpl.LivePlayerActivity" rateId="3-1-2-3" />  <!--今日头条中视频播放-->
  <item package="com.ss.android.article.news" activity="com.ss.android.article.news/com.ss.android.live.host.livehostimpl.LivePlayerTransActivity" rateId="3-1-2-3" />  <!--今日头条中视频播放-->
  <item package="com.ss.android.article.news" activity="com.ss.android.article.news/com.ss.android.ugc.detail.detail.ui.v2.view.TikTokDetailActivity" rateId="3-1-2-3" />  <!--今日头条中视频播放-->
  <item package="com.xingin.xhs" activity="com.xingin.xhs/com.xingin.matrix.videofeed.ui.VideoFeedActivityV2" rateId="3-1-2-3" />  <!--小红书中视频播放-->
  <item package="com.ss.android.article.news" activity="com.ss.android.article.news/com.ss.android.publisher.PublisherActivity" rateId="3-1-2-3" />  <!--今日头条中相机拍摄-->
  <item package="com.hipu.yidian" activity="com.hipu.yidian/com.yidian.news.ui.newsmain.NewsActivity" rateId="3-1-2-3" />  <!--一点资讯中视频播放-->
  <item package="com.hipu.yidian" activity="com.hipu.yidian/com.yidian.news.ui.content.video.vine.VineActivity" rateId="3-1-2-3" />  <!--一点资讯中视频播放-->
  <item package="com.tencent.reading" activity="com.tencent.reading/.video.immersive.activity.ImmersiveVideoActivity" rateId="3-1-2-3" />  <!--天天快报中视频播放-->
  <item package="com.tencent.reading" activity="com.tencent.reading/.bixin.video.detail.BixinVideoDetailActivity" rateId="3-1-2-3" />  <!--天天快报中视频播放-->
  <item package="com.tencent.news" activity="com.tencent.news/.kkvideo.shortvideo.VerticalVideoVideoActivity" rateId="3-1-2-3" />  <!--腾讯新闻中视频播放-->
  <item package="com.tencent.news" activity="com.tencent.news/.rose.RoseLiveDetailActivity" rateId="3-1-2-3" />  <!--腾讯新闻中视频播放-->
  <item package="com.tencent.news" activity="com.tencent.news/.kkvideo.detail.KkAlbumDarkModeActivity" rateId="3-1-2-3" />  <!--腾讯新闻中视频播放-->
  <item package="com.heytap.browser" activity="com.heytap.browser/.video.news.VideoDetailActivity" rateId="3-1-2-3" />  <!--OPPO浏览器播放视频-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.recordvideo.activity.MMRecordUI" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信中拍摄场景-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.ui.chatting.gallery.ImageGalleryUI" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信聊天界面播放小视频-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.appbrand.ui.AppBrandUI1" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信小程序-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.appbrand.ui.AppBrandUI2" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信小程序-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.sns.ui.SnsOnlineVideoActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信朋友圈播放视频-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.voip.ui.VideoActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!--bug 2946142 微信语音/视频聊天界面-->
  <item package="com.tencent.mm" activity="com.tencent.mm/.plugin.scanner.ui.BaseScanUI" rateId="3-1-2-3" disableViewOverride="false" />  <!--微信扫一扫页面-->
  <item package="com.netease.cloudmusic" activity="com.netease.cloudmusic/.activity.MLogVideoActivity" rateId="3-1-2-3" />  <!--bugID 628394 网易云音乐发热严重-->
  <item package="com.netease.cloudmusic" activity="com.netease.cloudmusic/com.netease.play.livepage.LiveViewerActivity" rateId="3-1-2-3" />  <!--bugID 628394 网易云音乐发热严重-->
  <item package="com.netease.cloudmusic" activity="com.netease.cloudmusic/.activity.MainPageMoreLiveActivity" rateId="3-1-2-3" />  <!--bugID 628394 网易云音乐发热严重-->
  <item package="com.taobao.taobao" activity="com.taobao.taobao/com.etao.feimagesearch.FEISCaptureActivity" rateId="3-1-2-3" />  <!--bugID 700656-->
  <item package="com.taobao.taobao" activity="com.taobao.idlefish/com.taobao.fleamarket.zxing.activity.QrCaptureActivity" rateId="3-1-2-3" />  <!--bugID 700656-->
  <item package="com.taobao.idlefish" activity="com.taobao.idlefish/com.idlefish.flutterbridge.flutterboost.IdleFishFlutterActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 闲鱼 BugID 2950544 -->

<!-- 60 -90-120 -->
  <item package="com.alicloud.databox" rateId="3-1-2-3" disableViewOverride="false" />  <!--1054230 阿里云盘-->
  <item package="com.sina.weibo" rateId="3-1-2-3" disableViewOverride="false" />  <!--微博-->
  <item package="com.ss.android.article.news" rateId="3-1-2-3" />  <!--今日头条-->
  <item package="com.xingin.xhs" rateId="3-1-2-3" />  <!--小红书-->
  <item package="com.hipu.yidian" rateId="3-1-2-3" />  <!--一点资讯-->
  <item package="com.tencent.news" rateId="3-1-2-3" />  <!--腾讯新闻-->
  <item package="com.ss.android.article.lite" rateId="3-1-2-3" />  <!--今日头条极速版-->
  <item package="cn.weli.story" rateId="3-1-2-3" />  <!--微鲤-->
  <item package="com.sina.news" rateId="3-1-2-3" />  <!--新浪新闻-->
  <item package="com.tencent.news.lite" rateId="3-1-2-3" />  <!--腾讯新闻极速版-->
  <item package="com.netease.newsreader.activity" rateId="3-1-2-3" />  <!--网易新闻-->
  <item package="com.coohua.xinwenzhuan" rateId="3-1-2-3" />  <!--淘新闻-->
  <item package="com.cashtoutiao" rateId="3-1-2-3" />  <!--惠头条-->
  <item package="com.sina.weibolite" rateId="3-1-2-3" />  <!--微博极速版-->
  <item package="com.chaozh.iReaderFree" rateId="3-1-2-3" />  <!--掌阅-->
  <item package="com.qidian.QDReader" rateId="3-1-2-3"  />  <!--起点读书-->
  <item package="com.ophone.reader.ui" rateId="3-1-2-3"  />  <!--咪咕阅读-->
  <item package="com.weibo.comic" rateId="3-1-2-3" />  <!--微博动漫 -->
  <item package="com.ss.android.auto" rateId="3-1-2-3" />  <!--懂车帝-->
  <item package="com.baidu.tieba" rateId="3-1-2-3" disableViewOverride="false" />  <!--百度贴吧-->
  <item package="com.zhihu.android" rateId="3-1-2-3"  />  <!--知乎-->
  <item package="com.qzone" rateId="3-1-2-3" disableViewOverride="false" />  <!--QQ空间-->
  <item package="com.baidu.iknow" rateId="3-1-2-3" />  <!--百度知道-->
  <item package="com.douban.frodo" rateId="3-1-2-3" />  <!--豆瓣-->
  <item package="com.skyplatanus.crucio" rateId="3-1-2-3" />  <!--快点-->
  <item package="com.eg.android.AlipayGphone" rateId="3-1-2-3" enableFodHighRate="true" />  <!--支付宝 -->
  <item package="com.tencent.tribe" rateId="3-1-2-3"/>  <!--兴趣部落-->
  <item package="com.android.chrome" rateId="3-1-2-3" disableViewOverride="false" />  <!--Chrome浏览器-->
  <item package="org.mozilla.firefox" rateId="3-1-2-3" disableViewOverride="false" />  <!--火狐浏览器-->
  <item package="com.opera.browser"  rateId="3-1-2-3" disableViewOverride="false" />  <!--opera浏览器-->
  <item package="com.alibaba.android.rimet" rateId="3-1-2-3" />  <!--钉钉-->
  <item package="com.tencent.wework" rateId="3-1-2-3" />  <!--企业微信-->
  <item package="com.immomo.momo" rateId="3-1-2-3" />  <!--MOMO陌陌-->
  <item package="com.tencent.mobileqq"  rateId="3-1-2-3" disableViewOverride="false" enableFodHighRate="true"  />  <!-- QQ -->
  <item package="com.tencent.mm" rateId="3-1-2-3" disableViewOverride="false" enableFodHighRate="true" />  <!-- 微信 bugid: 2895068,2896023-->
  <item package="com.xlptznvr.xlbe" rateId="3-1-2-3" />  <!--闲聊-->
  <item package="io.liuliu.music" rateId="3-1-2-3" />  <!--音遇-->
  <item package="com.zhenai.android" rateId="3-1-2-3" />  <!--珍爱网-->
  <item package="cn.neoclub.uki" rateId="3-1-2-3" />  <!--Uki-->
  <item package="com.qingshu520.chat"  rateId="3-1-2-3" />  <!--聊客-->
  <item package="com.welove520.qqsweet" rateId="3-1-2-3" />  <!--情侣空间-->
  <item package="com.wzf.fan" rateId="3-1-2-3" />  <!--我是谜-->
  <item package="com.tencent.qqlite" rateId="3-1-2-3" disableViewOverride="false" />  <!--QQ轻聊版(QQ极速版)-->
  <item package="com.mosheng" rateId="3-1-2-3" />  <!--陌声交友聊天-->
  <item package="com.android.incallui" rateId="3-1-2-3" />  <!-- 通话-->
  <item package="com.suning.mobile.ebuy" rateId="3-1-2-3" />  <!--苏宁易购-->
  <item package="com.cainiao.wireless" rateId="3-1-2-3" />  <!--菜鸟裹裹-->
  <item package="com.shizhuang.duapp" rateId="3-1-2-3" />  <!--得物(毒)-->
  <item package="com.xunmeng.pinduoduo" rateId="3-1-2-3" />  <!--拼多多-->
  <item package="com.baidu.netdisk" rateId="3-1-2-3" />  <!--百度网盘 -->
  <item package="com.tencent.reading" rateId="3-1-2-3" />  <!-- 看点快报  -->
  <item package="com.tencent.qt.qtl" rateId="3-1-2-3" />  <!-- 掌上英雄联盟  -->
  <item package="com.mt.mtxx.mtxx" rateId="3-1-2-3" />  <!-- 美图秀秀  -->
  <item package="com.baidu.BaiduMap" rateId="3-1-2-3" />  <!-- 百度地图  -->
  <item package="com.autonavi.minimap" rateId="3-1-2-3"  />  <!-- 高德地图 953441  -->
  <item package="com.tencent.map" rateId="3-1-2-3" />  <!-- 腾讯地图  -->
  <item package="com.sdu.didi.psnger" rateId="3-1-2-3" />  <!-- 滴滴出行  -->
  <item package="com.didi.es.psngr" rateId="3-1-2-3" />  <!-- 滴滴企业版  -->
  <item package="com.sdu.didi.gsui" rateId="3-1-2-3" />  <!-- 滴滴车主  -->
  <item package="com.didapinche.booking" rateId="3-1-2-3" />  <!-- 嘀嗒出行  -->
  <item package="com.jingyao.easybike" rateId="3-1-2-3" />  <!-- 哈啰出行  -->
<!-- all 60hz -->
  <item package="com.ss.android.ugc.aweme" rateId="3-1-2-3" />  <!--抖音-->
  <item package="com.kugou.android" rateId="3-1-2-3" />  <!--酷狗音乐-->
  <item package="com.jifen.qukan" rateId="3-1-2-3" />  <!--趣头条-->
  <item package="com.p1.mobile.putong" rateId="3-1-2-3" />  <!--探探-->
  <item package="com.lechuan.midunovel" rateId="3-1-2-3" />  <!--米读小说-->
  <item package="my.maya.android" rateId="3-1-2-3" />  <!--多闪-->
  <item package="com.kmxs.reader" rateId="3-1-2-3" />  <!--七猫免费小说-->
  <item package="com.ushaqi.zhuishushenqi.adfree" rateId="3-1-2-3" />  <!--追书神器免费版-->
  <item package="com.chinasofti.rcs" rateId="3-1-2-3" />  <!--和飞信-->
  <item package="com.zenmen.palmchat" rateId="3-1-2-3" />  <!--连信-->
  <item package="com.tencent.gamehelper.smoba" rateId="3-1-2-3" />  <!--王者营地-->
  <item package="com.qiyi.video.reader" rateId="3-1-2-3" />  <!--爱奇艺免费阅读-->
  <item package="com.wifi.reader.free" rateId="3-1-2-3" />  <!--连尚免费读书-->
  <item package="com.aikan" rateId="3-1-2-3" />  <!--免费小说大全-->
  <item package="com.yuewen.cooperate.reader.free" rateId="3-1-2-3" />  <!--飞读免费小说-->
  <item package="me.yidui" rateId="3-1-2-3" />  <!--伊对相亲交友-->
  <item package="com.baidu.searchbox.mission" rateId="3-1-2-3" />  <!--看多多-->
  <item package="com.mianfeizs.book" rateId="3-1-2-3" />  <!--免费追书-->
  <item package="com.ushaqi.zhuishushenqi" rateId="3-1-2-3" />  <!--追书神器-->
  <item package="com.kwai.sogame" rateId="3-1-2-3" />  <!--快手小游戏-->
  <item package="com.zsqbmfxs.novel" rateId="3-1-2-3" />  <!--追书全本免费小说-->
  <item package="com.tongzhuo.tongzhuogame" rateId="3-1-2-3" />  <!--同桌游戏-->
  <item package="com.chaozh.iReader.dj" rateId="3-1-2-3" />  <!--得间免费小说-->
  <item package="me.ddkj.cp" rateId="3-1-2-3" />  <!--处CP-->
  <item package="cn.zepeto.main" rateId="3-1-2-3" />  <!--崽崽ZEPETO-->
  <item package="cc.quanben.novel" rateId="3-1-2-3" />  <!--全本免费阅读书城-->
  <item package="cn.youth.news" rateId="3-1-2-3" />  <!--中青看点-->
  <item package="com.huluxia.gametools" rateId="3-1-2-3" />  <!--葫芦侠修改器-->
  <item package="com.nd.android.pandareader" rateId="3-1-2-3" />  <!--熊猫看书-->
  <item package="com.wifi.reader" rateId="3-1-2-3" />  <!--连尚读书-->
  <item package="com.tomato.reading" rateId="3-1-2-3" />  <!--番茄小说-->
  <item package="com.tadu.read" rateId="3-1-2-3" />  <!--免费小说阅读-->
  <item package="com.mianfeia.book" rateId="3-1-2-3" />  <!--免费电子书-->
  <item package="com.fanli.android.apps" rateId="3-1-2-3" />  <!--返利-->
  <item package="com.dongqiudi.news" rateId="3-1-2-3" />  <!--懂球帝-->
  <item package="com.xw.art.aquarium3d" rateId="3-1-2-3" />  <!--3d水族馆-->
  <item package="com.UCMobile" rateId="3-1-2-3" disableViewOverride="false"  />  <!--UC浏览器-->
  <item package="org.xbmc.kodi" rateId="3-1-2-3"  disableAnimHighRate="true" />  <!--kodi  bugID-813659 -->
  <item package="com.xunlei.downloadprovider" rateId="3-1-2-3" />  <!--迅雷-->
  <item package="com.lingan.seeyou" rateId="3-1-2-3" />  <!--美柚-->
  <item package="com.all.video" rateId="3-1-2-3" />  <!--聚视影视大全-->
  <item package="com.le123.ysdq" rateId="3-1-2-3" />  <!--影视大全-->
  <item package="com.cmcc.cmvideo" rateId="3-1-2-3" lowfreq="true" />  <!--咪咕视频-->
  <item package="com.bokecc.dance" rateId="3-1-2-3" />  <!--糖豆-->
  <item package="com.duoduo.child.story" rateId="3-1-2-3" />  <!--儿歌多多-->
  <item package="com.jm.video" rateId="3-1-2-3" />  <!--刷宝短视频-->
  <item package="tv.pps.mobile" rateId="3-1-2-3" />  <!--爱奇艺极速版-->
  <item package="com.babycloud.hanju" rateId="3-1-2-3" />  <!--韩剧tv-->
  <item package="com.oplus.play" rateId="3-1-2-3" />  <!--小游戏-->
  <item package="com.korean.tv" rateId="3-1-2-3" />  <!--韩剧大全-->
  <item package="com.meelive.ingkee" rateId="3-1-2-3" />  <!--映客-->
  <item package="com.diyidan" rateId="3-1-2-3" />  <!--第一弹-->
  <item package="com.iqiyi.acg" rateId="3-1-2-3" />  <!--叭哒动漫-->
  <item package="com.qiyi.video.child" rateId="3-1-2-3" />  <!--爱奇艺奇巴布-->
  <item package="com.netease.cc" rateId="3-1-2-3" />  <!--CC直播-->
  <item package="com.baidu.minivideo" rateId="3-1-2-3" />  <!--全民小视频-->
  <item package="dopool.player" rateId="3-1-2-3" />  <!--手机电视-->
  <item package="com.jjwxc.reader" rateId="3-1-2-3" />  <!--晋江小说阅读-->
  <item package="com.huanshou.taojj" rateId="3-1-2-3" />  <!--淘集集-->
  <item package="com.songheng.eastnews" rateId="3-1-2-3" />  <!--东方头条-->
  <item package="cn.soulapp.android" rateId="3-1-2-3" />  <!--soul-->
  <item package="com.qq.reader" rateId="3-1-2-3" />  <!--QQ阅读-->
  <item package="com.kuaikan.comic" rateId="3-1-2-3" />  <!--快看漫画-->
  <item package="com.qiyi.video.pad" rateId="3-1-2-3" />  <!--爱奇艺HD-->
  <item package="com.chinatelecom.bestpayclient" rateId="3-1-2-3" />  <!--翼支付-->
  <item package="com.c2vl.kgamebox" rateId="3-1-2-3" />  <!--狼人杀-->
  <item package="com.netease.mc.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的世界-->
  <item package="com.android.launcher" rateId="3-1-2-3" />
  <item package="com.antutu.ABenchMark" rateId="3-1-2-3" />  <!--安兔兔-->
  <item package="com.tencent.tmgp.cf" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false" />  <!--穿越火线：枪战王者-->
  <item package="com.netease.blqx.nearme.gamecenter" rateId="3-1-2-3" />  <!--堡垒前线：破坏与创造-->
  <item package="com.happyelements.AndroidAnimal" rateId="3-1-2-3" />  <!--开心消消乐-->
  <item package="com.qqgame.hlddz" rateId="3-1-2-3" />  <!--欢乐斗地主-->
  <item package="com.minitech.miniworld.nearme.gamecenter" rateId="3-1-2-3" />  <!--迷你世界-->
  <item package="com.wepie.snake.nearme.gamecenter" rateId="3-1-2-3" />  <!--贪吃蛇大作战?-->
  <item package="com.qqgame.happymj" rateId="3-1-2-3" />  <!--腾讯欢乐麻将-->
  <item package="com.nearme.gamecenter.ddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢喜斗地主-->
  <item package="com.outfit7.talkingtomgoldrun.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤姆猫跑酷-->
  <item package="com.zengame.zrttddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天斗地主（真人版）-->
  <item package="com.netease.tom.nearme.gamecenter" rateId="3-1-2-3" />  <!--猫和老鼠-->
  <item package="com.mfp.jelly.oppo" rateId="3-1-2-3" />  <!--宾果消消消?-->
  <item package="com.netease.dwrg.nearme.gamecenter" rateId="3-1-2-3" />  <!--第五人格-->
  <item package="com.tencent.tmgp.pubgm" rateId="3-1-2-3" />  <!--绝地求生全军出击-->
  <item package="com.netease.mrzh.nearme.gamecenter" rateId="3-1-2-3" />  <!--明日之后-->
  <item package="com.imangi.templerun2" rateId="3-1-2-3" />  <!--神庙逃亡2-->
  <item package="com.cmplay.tiles2_cn" rateId="3-1-2-3" />  <!--钢琴块2-->
  <item package="com.ztgame.bob" rateId="3-1-2-3" />  <!--球球大作战-->
  <item package="com.kiloo.subwaysurf" rateId="3-1-2-3" />  <!--地铁跑酷-->
  <item package="com.popcap.pvz2cthdop" rateId="3-1-2-3" />  <!--植物大战僵尸2-->
  <item package="com.outfit7.mytalkingtomfree.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的汤姆猫-->
  <item package="com.outfit7.mytalkingtom2.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的汤姆猫2-->
  <item package="com.outfit7.mytalkingangelafree.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的安吉拉-->
  <item package="com.netease.hyxd.nearme.gamecenter" rateId="3-1-2-3" />  <!--荒野行动-->
  <item package="com.turbochilli.rollingsky_cn.nearme.gamecenter" rateId="3-1-2-3" />  <!--滚动的天空-->
  <item package="com.hsh.cqyzs.nearme.gamecenter" rateId="3-1-2-3" />  <!--斗罗大陆-->
  <item package="com.tencent.peng" rateId="3-1-2-3" />  <!--天天爱消除-->
  <item package="cn.jj" rateId="3-1-2-3" />  <!--JJ斗地主-->
  <item package="com.tencent.gwgo" rateId="3-1-2-3" />  <!--一起来捉妖-->
  <item package="com.tencent.pao" rateId="3-1-2-3" />  <!--天天酷跑-->
  <item package="com.tencent.game.rhythmmaster" rateId="3-1-2-3" />  <!--腾讯节奏大师-->
  <item package="com.jsdw.Kbunainai.nearme.gamecenter" rateId="3-1-2-3" />  <!--溜出去-->
  <item package="com.ChillyRoom.nearme.gamecenter" rateId="3-1-2-3" />  <!--元气骑士-->
  <item package="com.mingya.realdriving.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实公路汽车-->
  <item package="com.supercell.clashofclans.nearme.gamecenter" rateId="3-1-2-3" />  <!--部落冲突-->
  <item package="com.tencent.tmgp.qqx5" rateId="3-1-2-3" />  <!--QQ炫舞-->
  <item package="com.ledou.mhhy.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦幻花园-->
  <item package="com.joym.legendhero.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼传奇英雄-->
  <item package="com.hlddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐斗地主四人玩法-->
  <item package="com.tencent.qqgame.xq" rateId="3-1-2-3" />  <!--天天象棋-->
  <item package="com.zsfz.hcgtr3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴钢铁人3D-->
  <item package="com.sy.ydcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--一刀传世-->
  <item package="com.fingersoft.hillclimb.noncmcc" rateId="3-1-2-3" />  <!--登山赛车-->
  <item package="com.fgol.hsw.nearme.gamecenter" rateId="3-1-2-3" />  <!--饥饿鲨：世界-->
  <item package="com.cmcm.arrowio_cn.nearme.gamecenter" rateId="3-1-2-3" />  <!--弓箭手大作战-->
  <item package="com.cmplay.dancingline.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳舞的线-->
  <item package="com.tomato.joy.fkkpcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂酷跑传奇-->
  <item package="com.pandadastudio.ninjamustdie3.nearme.gamecenter" rateId="3-1-2-3" />  <!--忍者必须死3-->
  <item package="com.yodo1.rodeo.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂动物园-->
  <item package="com.tencent.wmsj" rateId="3-1-2-3" />  <!--完美世界-->
  <item package="com.bairimeng.dmmdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--逃跑吧！少年-->
  <item package="com.jsdw.huochaizzx2.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤米快跑-->
  <item package="com.wedobest.xiangqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--象棋-->
  <item package="com.pokercity.bydrqp.nearme.gamecenter" rateId="3-1-2-3" />  <!--波克捕鱼-->
  <item package="com.supercell.clashroyale.nearme.gamecenter" rateId="3-1-2-3" />  <!--皇室战争-->
  <item package="com.yingxiong.heroo.nearme.gamecenter" rateId="3-1-2-3" />  <!--王牌战争-->
  <item package="com.outfit7.talkingtomcandyrun.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤姆猫快跑-->
  <item package="com.tencent.shootgame" rateId="3-1-2-3" />  <!--魂斗罗:归来-->
  <item package="com.sleeeeepfly.knife.io.jrtt" rateId="3-1-2-3" />  <!--我飞刀玩得贼6-->
  <item package="com.tcyhx.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--逃出银河系-->
  <item package="com.outfit7.mytalkinghank.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的汉克狗-->
  <item package="com.brianbaek.popstar" rateId="3-1-2-3" />  <!--消灭星星全新版-->
  <item package="com.moli.minigame.hole.nearme.gamecenter" rateId="3-1-2-3" />  <!--黑洞大作战-->
  <item package="com.fingersoft.hrc2.cn.noncmcc.nearme.gamecenter" rateId="3-1-2-3" />  <!--登山赛车2-->
  <item package="jjzccj.csfkjy.nearme.gamecenter" rateId="3-1-2-3" />  <!--狙击战场求生-->
  <item package="com.tencent.tmgp.hjol" rateId="3-1-2-3" />  <!--红警OL-->
  <item package="com.outfit7.talkingtompool.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤姆猫水上乐园-->
  <item package="com.jshcr.nearme.gamecenter" rateId="3-1-2-3" />  <!--极速火柴人-->
  <item package="com.popcap.pvz2op" rateId="3-1-2-3" />  <!--植物大战僵尸2-->
  <item package="com.mf.xxyzgame.wpp.game.hlqsgdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐切水果大作战-->
  <item package="com.joygame.atm.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼热血英雄-->
  <item package="com.joyfort.merge.car.jrtt" rateId="3-1-2-3" />  <!--全民漂移-->
  <item package="com.joym.combatman.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼之格斗超人-->
  <item package="com.sgshd.nearme.gamecenter" rateId="3-1-2-3" />  <!--三国杀-->
  <item package="com.e8game.lgsfq.nearme.gamecenter" rateId="3-1-2-3" />  <!--找到老公的私房钱-->
  <item package="org.cocos2dx.VirusVsVirus2.nearme.gamecenter" rateId="3-1-2-3" />  <!--红蓝大作战2-->
  <item package="com.zengame.ttddzzrb.nearme.gamecenter" rateId="3-1-2-3" />  <!--单机斗地主（欢乐版）-->
  <item package="com.gamedo.hlw.nearme.gamecenter" rateId="3-1-2-3" />  <!--葫芦娃-->
  <item package="com.hegu.dnl.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--阿拉德之怒-->
  <item package="com.yunbu.cookingchef.nearme.gamecenter" rateId="3-1-2-3" />  <!--美食烹饪家-->
  <item package="com.gameloft.android.ANMP.GloftDMCN" rateId="3-1-2-3" />  <!--神偷奶爸：小黄人快跑-->
  <item package="com.cbxd.sy.nearme.gamecenter" rateId="3-1-2-3" />  <!--屠龙破晓-->
  <item package="com.hero.sm.nearme.gamecenter" rateId="3-1-2-3" />  <!--创造与魔法-->
  <item package="com.soulgame.bear.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的熊大熊二-->
  <item package="com.outfit7.talkingtomjetski.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤姆猫的摩托艇-->
  <item package="com.netease.onmyoji.nearme.gamecenter" rateId="3-1-2-3" />  <!--阴阳师-->
  <item package="com.outfit7.talkingtom.nearme.gamecenter" rateId="3-1-2-3" />  <!--会说话的汤姆猫-->
  <item package="com.netease.my.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦幻西游-->
  <item package="com.ledou.mhjy.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦幻家园-->
  <item package="com.netease.l10.nearme.gamecenter" rateId="3-1-2-3" />  <!--倩女幽魂-->
  <item package="com.matman.city.nearme.gamecenter" rateId="3-1-2-3" />  <!--城市忍者联盟-->
  <item package="com.tomato.joy.hcrnh.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人你好-->
  <item package="com.csdj.hcrYC.nearme.gamecenter" rateId="3-1-2-3" />  <!--战警联萌-->
  <item package="com.fgol.oppo" rateId="3-1-2-3" />  <!--饥饿鲨：进化-->
  <item package="com.outfit7.talkingtom2free.nearme.gamecenter" rateId="3-1-2-3" />  <!--会说话的汤姆猫2-->
  <item package="com.liuguan.mnjxyy.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟极限越野-->
  <item package="com.yodo1.sniper3dv2.nearme.gamecenter" rateId="3-1-2-3" />  <!--狙击行动：代号猎鹰-->
  <item package="com.koodroid.chicken" rateId="3-1-2-3" />  <!--快乐小鸡-->
  <item package="com.yingxiong.dftk.nearme.gamecenter" rateId="3-1-2-3" />  <!--巅峰坦克-->
  <item package="com.anzhuojpzmg.ckhd.nearme.gamecenter" rateId="3-1-2-3" />  <!--极品芝麻官-->
  <item package="com.tencent.pocket" rateId="3-1-2-3" />  <!--腾讯桌球-->
  <item package="com.wooduan.ssjj.nearme.gamecenter" rateId="3-1-2-3" />  <!--生死狙击-->
  <item package="com.tq.he.nearme.gamecenter" rateId="3-1-2-3" />  <!--英魂之刃-->
  <item package="com.kendall.humflatfall.xc" rateId="3-1-2-3" />  <!--人类一败涂地-->
  <item package="com.yodo1.ctr2.OPPO_01" rateId="3-1-2-3" />  <!--割绳子2-->
  <item package="com.wedobest.szhrd.nearme.gamecenter" rateId="3-1-2-3" />  <!--数字华容道-->
  <item package="com.leqi.buyu.nearme.gamecenter" rateId="3-1-2-3" />  <!--小玛丽捕鱼-->
  <item package="com.tencent.tmgp.sgamece" rateId="3-1-2-3" />  <!--王者荣耀体验服-->
  <item package="com.tencent.tmgp.qjnn" rateId="3-1-2-3" />  <!--奇迹暖暖-->
  <item package="com.byzft.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼炸翻天-->
  <item package="com.rovio.angrybirds.op" rateId="3-1-2-3" />  <!--愤怒的小鸟-->
  <item package="com.ue.jylh.nearme.gamecenter" rateId="3-1-2-3" />  <!--剑与轮回-->
  <item package="com.wb.yqrd.nearme.gamecenter" rateId="3-1-2-3" />  <!--一球入洞-->
  <item package="com.example.gcloudu3ddemo.nearme.gamecenter" rateId="3-1-2-3" />  <!--激斗火柴人-->
  <item package="com.outfit7.talkingangelafree.nearme.gamecenter" rateId="3-1-2-3" />  <!--会说话的安吉拉-->
  <item package="com.tongcn.qmkljj.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民恐龙狙击-->
  <item package="com.bolibei.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐玻璃杯-->
  <item package="com.qqgame.mic" rateId="3-1-2-3" />  <!--英雄杀-->
  <item package="com.quduoduo.city.nearme.gamecenter" rateId="3-1-2-3" />  <!--大众战争-->
  <item package="com.zsfz.wjjmn3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--挖掘机模拟3D-->
  <item package="com.hlbyr.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐捕鱼人-->
  <item package="com.wedobest.hdxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--同桌大作战-->
  <item package="fish.soonyo.nearme.gamecenter" rateId="3-1-2-3" />  <!--满贯捕鱼-->
  <item package="com.ycoolgame.sqmx.nearme.gamecenter" rateId="3-1-2-3" />  <!--石器冒险-->
  <item package="com.tomato.joy.hcryy.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人越狱2-->
  <item package="com.zsfz.gdjzmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--工地建造模拟-->
  <item package="com.tianli.fivechess.nearme.gamecenter" rateId="3-1-2-3" />  <!--五子棋-->
  <item package="com.mahjong.sichuang" rateId="3-1-2-3" />  <!--熊猫四川麻将-->
  <item package="com.bairimeng.snake.nearme.gamecenter" rateId="3-1-2-3" />  <!--蛇蛇争霸-->
  <item package="com.zsfz.ysccc.nearme.gamecenter" rateId="3-1-2-3" />  <!--勇士冲冲冲-->
  <item package="com.netease.zjz2.nearme.gamecenter" rateId="3-1-2-3" />  <!--终结者2:审判日（电影官方手游）-->
  <item package="com.GF.PalaceM2_cn_cn.hwy_android_oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--熹妃传-->
  <item package="com.csdj.czc3D.nearme.gamecenter" rateId="3-1-2-3" />  <!--烈焰飙车-->
  <item package="com.tencent.tmgp.NBA" rateId="3-1-2-3" />  <!--最强NBA-->
  <item package="com.junguang.luckydoll.nearme.gamecenter" rateId="3-1-2-3" />  <!--幸运娃娃机-->
  <item package="com.mewe.wolf" rateId="3-1-2-3" />  <!--饭局狼人-->
  <item package="com.shuiguotang.gymc.nearme.gamecenter" rateId="3-1-2-3" />  <!--鬼语迷城-->
  <item package="com.tencent.tmgp.dpcq" rateId="3-1-2-3" />  <!--斗破苍穹-->
  <item package="com.duole.paodekuai.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐跑得快-->
  <item package="com.jsdw.ppxia.nearme.gamecenter" rateId="3-1-2-3" />  <!--攀爬侠-->
  <item package="com.yunbu.cakeshop.nearme.gamecenter" rateId="3-1-2-3" />  <!--奇妙蛋糕制作-->
  <item package="com.blizzard.wtcg.hearthstone" rateId="3-1-2-3" />  <!--炉石传说-->
  <item package="com.yunbu.barbiemakeup.nearme.gamecenter" rateId="3-1-2-3" />  <!--芭比时尚美妆-->
  <item package="com.huale.justicearrive.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼正义降临-->
  <item package="com.joym.xiongdakuaipao2018.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之熊大快跑2018-->
  <item package="com.happyelements.AndroidAnimal.qq" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.hxjy.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--火线精英-->
  <item package="com.zengame.ttmjscb.nearme.gamecenter" rateId="3-1-2-3" />  <!--四川麻将（血战到底）-->
  <item package="com.jbdfw.nearme.gamecenter" rateId="3-1-2-3" />  <!--金币大富翁-->
  <item package="com.zsfz.llcj.nearme.gamecenter" rateId="3-1-2-3" />  <!--雷龙出击-->
  <item package="com.gghz.scq.nearme.gamecenter" rateId="3-1-2-3" />  <!--生存球-->
  <item package="com.yinhan.skzh.nearme.gamecenter" rateId="3-1-2-3" />  <!--时空召唤-->
  <item package="com.yunbu.bubbleelfsaga.nearme.gamecenter" rateId="3-1-2-3" />  <!--泡泡精灵传奇-->
  <item package="com.jsdw.huochaiZZX.nearme.gamecenter" rateId="3-1-2-3" />  <!--在奔跑-->
  <item package="com.tencent.qqgame.qqhlupwvga" rateId="3-1-2-3" />  <!--欢乐升级-->
  <item package="com.appicstudio.qingsongduobi.nearme.gamecenter" rateId="3-1-2-3" />  <!--轻松躲避-->
  <item package="com.zk.cfsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--超凡赛车-->
  <item package="com.zsfz.tzbdscmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--特种部队生存模拟-->
  <item package="com.tomato.joy.sjpd.nearme.gamecenter" rateId="3-1-2-3" />  <!--派对大作战-摔跤派对-->
  <item package="com.yodo1.OPPO_01.SkiSafari" rateId="3-1-2-3" />  <!--滑雪大冒险-->
  <item package="com.ledo.kof97ol.nearme.gamecenter" rateId="3-1-2-3" />  <!--拳皇97OL-->
  <item package="com.playrix.township.chukong.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦想城镇-->
  <item package="com.netease.moba.nearme.gamecenter" rateId="3-1-2-3" />  <!--决战！平安京-->
  <item package="com.pfu.popstar" rateId="3-1-2-3" />  <!--消消星星乐：最新版-->
  <item package="com.tencent.tmgp.carrot3" rateId="3-1-2-3" />  <!--保卫萝卜3（重名）-->
  <item package="com.soulgame.mysuperwings.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的超级飞侠-->
  <item package="com.outfit7.talkingtomcamp.nearme.gamecenter" rateId="3-1-2-3" />  <!--汤姆猫战营-->
  <item package="com.qidian.dldl.nearme.gamecenter" rateId="3-1-2-3" />  <!--新斗罗大陆-->
  <item package="com.mfkj.mnlsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟狼生存-->
  <item package="com.gbits.atm.nearme.gamecenter" rateId="3-1-2-3" />  <!--问道-->
  <item package="com.ns.unlimited.speed.nearme.gamecenter" rateId="3-1-2-3" />  <!--功夫疾走-->
  <item package="com.carrot.carrotfantasy" rateId="3-1-2-3" />  <!--保卫萝卜-->
  <item package="com.wanmei.zhuxian.nearme.gamecenter" rateId="3-1-2-3" />  <!--诛仙-->
  <item package="com.tencent.tmgp.jx3m" rateId="3-1-2-3" />  <!--剑网3：指尖江湖-->
  <item package="com.xingyugame.gt.nearme.gamecenter" rateId="3-1-2-3" />  <!--宫廷秘传-->
  <item package="com.quduoduo.bussubway.nearme.gamecenter" rateId="3-1-2-3" />  <!--跑酷飞侠快跑-->
  <item package="com.skymoons.croods.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂原始人-->
  <item package="com.ea.simcitymobile.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟城市:我是市长-->
  <item package="com.rzdld.nearme.gamecenter" rateId="3-1-2-3" />  <!--忍者大乱斗-->
  <item package="com.tianyi.mnkczsjs.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟卡车真实驾驶-->
  <item package="com.happyelements.AndroidClover.nearme.gamecenter" rateId="3-1-2-3" />  <!--海滨消消乐-->
  <item package="com.libii.weddingmall.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦幻婚纱店-->
  <item package="com.hcrzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人之战-->
  <item package="net.mobigame.zombietsunami.oppo" rateId="3-1-2-3" />  <!--僵尸尖叫-->
  <item package="com.tanwan.ltcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙腾传世-->
  <item package="com.greatefunhy.sdgs.nearme.gamecenter" rateId="3-1-2-3" />  <!--商道高手-->
  <item package="com.next.netcraft.nearme.gamecenter" rateId="3-1-2-3" />  <!--奶块-->
  <item package="com.joym.armorbear.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之机甲熊大-->
  <item package="com.netease.wyclx.nearme.gamecenter" rateId="3-1-2-3" />  <!--楚留香-->
  <item package="com.june.doudizhu.nearme.gamecenter" rateId="3-1-2-3" />  <!--单机斗地主-->
  <item package="com.PB.palacem4cncn.hwyad.nearme.gamecenter" rateId="3-1-2-3" />  <!--宫廷计手游-->
  <item package="com.phoneu.goldtoadfish.nearme.gamecenter" rateId="3-1-2-3" />  <!--一起玩捕鱼-->
  <item package="com.tong.cn.cjyxdz.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级英雄队长-->
  <item package="com.oppo.goldminer" rateId="3-1-2-3" />  <!--变形机器人英雄-->
  <item package="com.wb.gqfk.nearme.gamecenter" rateId="3-1-2-3" />  <!--钢琴方块-->
  <item package="com.cmge.dz.xyermj.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐真人麻将-->
  <item package="com.pkwan.op.nearme.gamecenter" rateId="3-1-2-3" />  <!--航海王：燃烧意志-->
  <item package="com.whjf.bxjqrzdy.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形机器人总动员-->
  <item package="com.yunbu.cottoncandyshop.nearme.gamecenter" rateId="3-1-2-3" />  <!--彩虹棉花糖小店-->
  <item package="com.tencent.nntg.linekong" rateId="3-1-2-3" />  <!--闹闹天宫-->
  <item package="com.zsfz.bbbwdsjcqll.nearme.gamecenter" rateId="3-1-2-3" />  <!--爸爸把我的手机藏起来了-->
  <item package="com.tencent.game.VXDGame" rateId="3-1-2-3" />  <!--天天炫斗-->
  <item package="com.pdragon.new2048.nearme.gamecenter" rateId="3-1-2-3" />  <!--新2048-->
  <item package="com.supercell.boombeach.nearme.gamecenter" rateId="3-1-2-3" />  <!--海岛奇兵-->
  <item package="com.jsdw.Zhdzd.nearme.gamecenter" rateId="3-1-2-3" />  <!--最后的子弹-->
  <item package="com.metek.ultraman.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼系列OL-->
  <item package="com.huiyao.zhdfx.nearme.gamecenter" rateId="3-1-2-3" />  <!--生化围城-->
  <item package="com.yunbu.royalwedding.nearme.gamecenter" rateId="3-1-2-3" />  <!--冰雪皇家婚礼-->
  <item package="com.zhongM.xlcc.nearme.gamecenter" rateId="3-1-2-3" />  <!--消林传说-->
  <item package="com.tencent.cldts" rateId="3-1-2-3" />  <!--光荣使命-->
  <item package="com.igame.kbfcd.nearme.gamecenter" rateId="3-1-2-3" />  <!--狂暴飞车-->
  <item package="com.zywx.sjpd.nearme.gamecenter" rateId="3-1-2-3" />  <!--摔跤派对-->
  <item package="com.tomato.ditchingwork2.nearme.gamecenter" rateId="3-1-2-3" />  <!--走出办公室2-->
  <item package="com.g37.brdz.nearme.gamecenter" rateId="3-1-2-3" />  <!--兵人大战-->
  <item package="com.invictus.impossiball" rateId="3-1-2-3" />  <!--永不言弃!!-->
  <item package="com.melestudio.babysitter.nearme.gamecenter" rateId="3-1-2-3" />  <!--照顾宝宝过家家-->
  <item package="com.libii.tutotoons.pandalucare.nearme.gamecenter" rateId="3-1-2-3" />  <!--照顾熊猫宝宝璐璐-->
  <item package="com.ustwo.monumentvalleyzz" rateId="3-1-2-3" />  <!--纪念碑谷-->
  <item package="com.zsfz.xzbrwjxx.nearme.gamecenter" rateId="3-1-2-3" />  <!--校长不让我进学校-->
  <item package="com.JindoBlu.Antistress" rateId="3-1-2-3" />  <!--Antistress-->
  <item package="com.igame.mszz.nearme.gamecenter" rateId="3-1-2-3" />  <!--猫鼠之战-->
  <item package="com.yunbu.pool.nearme.gamecenter" rateId="3-1-2-3" />  <!--街机台球大师-->
  <item package="com.ycoolgame.smcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--神秘传奇-->
  <item package="cn.ultralisk.gameapp.game23.nearme.gamecenter" rateId="3-1-2-3" />  <!--叶罗丽精灵梦-->
  <item package="com.xingfei.jsbbz.nearme.gamecenter" rateId="3-1-2-3" />  <!--就是憋不住-->
  <item package="com.tencent.tmgp.ttmj" rateId="3-1-2-3" />  <!--麻将来了-->
  <item package="lyzzr.nearme.gamecenter" rateId="3-1-2-3" />  <!--恋与制作人-->
  <item package="com.tomato.joy.bhqq.nearme.gamecenter" rateId="3-1-2-3" />  <!--保护我-->
  <item package="com.tencent.feiji" rateId="3-1-2-3" />  <!--全民飞机大战-->
  <item package="com.caohua.atm.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼英雄归来-->
  <item package="com.tencent.tmgp.tstl" rateId="3-1-2-3" />  <!--天龙八部-->
  <item package="com.enjoymisgzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--三国战纪-->
  <item package="com.hcrjt.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人军团-->
  <item package="com.lz.wcdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--围城大作战-->
  <item package="com.lywx.hddts.nearme.gamecenter" rateId="3-1-2-3" />  <!--黑洞大吞噬-->
  <item package="com.xf.lcby.hede.nearme.gamecenter" rateId="3-1-2-3" />  <!--霸刀战神-->
  <item package="com.tomatojoy.zjt.nearme.gamecenter" rateId="3-1-2-3" />  <!--指尖陀螺-->
  <item package="com.wepie.blade.nearme.gamecenter" rateId="3-1-2-3" />  <!--刀剑大作战-->
  <item package="com.joym.xiongdakuaipao" rateId="3-1-2-3" />  <!--熊出没之熊大快跑-->
  <item package="ttaby.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天爱捕鱼-->
  <item package="com.libiitech.princessbeautysalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--甜心公主美容院-->
  <item package="com.cjml.xysd.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级里奥酷跑-->
  <item package="com.yinhan.hunter.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--时空猎人-->
  <item package="com.mahjong.danji.nearme.gamecenter" rateId="3-1-2-3" />  <!--单机麻将-->
  <item package="com.igame.wztt.nearme.gamecenter" rateId="3-1-2-3" />  <!--武者弹跳-->
  <item package="com.cqwx.yykcmnkcjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--越野卡车：模拟卡车驾驶-->
  <item package="com.lskl.cnzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--超能战鸡-->
  <item package="com.mili.dghcr.nearme.gamecenter" rateId="3-1-2-3" />  <!--倒钩火柴人-->
  <item package="com.kabam.marvelbattle.netease.nesh.nearme.gamecenter" rateId="3-1-2-3" />  <!--漫威：超级争霸战-->
  <item package="com.tomato.joy.zzr.nearme.gamecenter" rateId="3-1-2-3" />  <!--粘住火柴蜘蛛人-->
  <item package="com.igame.hlxsg.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐消水果-->
  <item package="com.tencent.raziel" rateId="3-1-2-3" />  <!--拉结尔-->
  <item package="com.yt.zjsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--终极赛车狂飙-->
  <item package="com.tomato.ditchingwork.nearme.gamecenter" rateId="3-1-2-3" />  <!--走出办公室-->
  <item package="com.tencent.fifamobile" rateId="3-1-2-3" />  <!--FIFA足球世界-->
  <item package="com.lanse.chinachess.nearme.gamecenter" rateId="3-1-2-3" />  <!--中国象棋竞技版-->
  <item package="com.sofunny.Chicken" rateId="3-1-2-3" />  <!--香肠派对-->
  <item package="com.hzah.pvzstar.nearme.gamecenter" rateId="3-1-2-3" />  <!--植物大战僵尸全明星-->
  <item package="com.dtszjkhd.nearme.gamecenter" rateId="3-1-2-3" />  <!--精灵盛典-->
  <item package="com.zsfz.fywzmxzl2.nearme.gamecenter" rateId="3-1-2-3" />  <!--飞鱼王子冒险之旅-->
  <item package="com.yaoji.byhlz.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼欢乐炸-->
  <item package="com.shhxz.zhuzhuxiawulinkupao.nearme.gamecenter" rateId="3-1-2-3" />  <!--猪猪侠之五灵酷跑-->
  <item package="com.sjxx.zycs.nearme.gamecenter" rateId="3-1-2-3" />  <!--注意车速-->
  <item package="com.lywx.ytdd.nearme.gamecenter" rateId="3-1-2-3" />  <!--一跳到底-->
  <item package="com.netease.dhxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--大话西游-->
  <item package="com.tencent.hlfish" rateId="3-1-2-3" />  <!--腾讯欢乐捕鱼-->
  <item package="com.tencent.clover" rateId="3-1-2-3" />  <!--雷霆战机-->
  <item package="com.mf.game.dwdlm.nearme.gamecenter" rateId="3-1-2-3" />  <!--动物大联盟（老虎求生战场）-->
  <item package="com.tuyoo.doudizhu.maintu.nearme.gamecenter" rateId="3-1-2-3" />  <!--途游斗地主-->
  <item package="com.ipeaksoft.pitDadGame" rateId="3-1-2-3" />  <!--史上最坑爹的游戏-->
  <item package="com.tencent.ggame" rateId="3-1-2-3" />  <!--腾讯广东麻将-->
  <item package="com.racergame.cityracing3d" rateId="3-1-2-3" />  <!--城市飞车-->
  <item package="com.crisisfire.android.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民枪战2-->
  <item package="com.tianyi.fkclpkmn.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂车轮跑酷模拟-->
  <item package="cn.ultralisk.gameapp.game37.nearme.gamecenter" rateId="3-1-2-3" />  <!--叶罗丽美颜公主-->
  <item package="com.pepper.bfyfj.nearme.gamecenter" rateId="3-1-2-3" />  <!--八分音符酱-->
  <item package="com.tongcn.hcrdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人大作战-->
  <item package="com.kuiyi.twdcr.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--逃亡的超人-->
  <item package="com.chaojitangxian.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级探险-->
  <item package="com.prgame5.fish2.online.nearme.gamecenter" rateId="3-1-2-3" />  <!--街机达人捕鱼-->
  <item package="com.zsfz.klzsmn3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐龙真实模拟3D-->
  <item package="com.mfkj.mnsdzxc.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟山地自行车-->
  <item package="com.huati" rateId="3-1-2-3" />  <!--葫芦侠3楼-->
  <item package="com.wb.hcrcj.new.nearme.gamecenter" rateId="3-1-2-3" />  <!--暴击火柴人-->
  <item package="com.noAds.SubwaySimulator" rateId="3-1-2-3" />  <!--城市蜘蛛人英雄冬季版-->
  <item package="com.playcrab.kos.nearme.gamecenter" rateId="3-1-2-3" />  <!--一拳超人：最强之男-->
  <item package="com.taiyouxi.jiwushuang.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--极无双-->
  <item package="com.tencent.tmgp.jnbg2" rateId="3-1-2-3" />  <!--纪念碑谷2-->
  <item package="com.e8game.lpsfq.nearme.gamecenter" rateId="3-1-2-3" />  <!--找到老婆的私房钱-->
  <item package="com.tencent.shihun.android" rateId="3-1-2-3" />  <!--侍魂-胧月传说-->
  <item package="com.zsfz.wjjjzmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--挖掘机建造模拟-->
  <item package="com.ea.android.chs.nbamobile.nearme.gamecenter" rateId="3-1-2-3" />  <!--NBALIVE-->
  <item package="com.redwoods.qmpy.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民漂移：狂野飙车-->
  <item package="com.tencent.imprison" rateId="3-1-2-3" />  <!--记忆重构-->
  <item package="com.zsfz.hscqhlb.nearme.gamecenter" rateId="3-1-2-3" />  <!--海蛇传奇-->
  <item package="com.lew.game.pianoblock.nearme.gamecenter" rateId="3-1-2-3" />  <!--节奏的钢琴白块-->
  <item package="com.netease.hzmbqs.nearme.gamecenter" rateId="3-1-2-3" />  <!--绘真·妙笔千山-->
  <item package="com.carrot.iceworld" rateId="3-1-2-3" />  <!--保卫萝卜2-->
  <item package="com.sg.bjjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血奥特曼（暴击僵尸）-->
  <item package="com.k7k7.goujihd.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐够级-->
  <item package="com.libii.gymnasticsqueen.nearme.gamecenter" rateId="3-1-2-3" />  <!--体操少女-->
  <item package="com.jiami.landlords.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐人人斗地主-->
  <item package="com.minidip.cftzdj.nearme.gamecenter" rateId="3-1-2-3" />  <!--超凡特战队-->
  <item package="com.duole.zhuojimjhd.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐贵阳捉鸡麻将-->
  <item package="com.mfkj.hhjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--豪华竞速-->
  <item package="com.ubisoft.rabbidsrunner.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂兔子：无敌跑跑-->
  <item package="com.libii.pethospital.nearme.gamecenter" rateId="3-1-2-3" />  <!--毛绒宠物医院-->
  <item package="com.joym.armorbear2.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没机甲熊大2-->
  <item package="com.huale.ultraman2.nearme.gamecenter" rateId="3-1-2-3" />  <!--酷跑奥特曼2-->
  <item package="com.wb.mbdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--麦比大作战-->
  <item package="com.cats.idreamsky.nearme.gamecenter" rateId="3-1-2-3" />  <!--喵星大作战-->
  <item package="com.mf.monsterblast.nearme.gamecenter" rateId="3-1-2-3" />  <!--飞屋消消消-->
  <item package="com.mfkj.ldzjcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--雷电战机-传奇-->
  <item package="com.tomatojoy.nkdyx.nearme.gamecenter" rateId="3-1-2-3" />  <!--纽扣的游戏-->
  <item package="com.libii.lovediary.nearme.gamecenter" rateId="3-1-2-3" />  <!--公主恋爱日记-->
  <item package="tong.mfgame.bxzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形装甲-->
  <item package="com.yunbu.superdocdor.nearme.gamecenter" rateId="3-1-2-3" />  <!--宝宝超级医生-->
  <item package="com.ikoalabear.x5online.nearme.gamecenter" rateId="3-1-2-3" />  <!--炫舞浪漫爱-->
  <item package="com.cmplay.tiles2" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.racinggames.euro_truck.simulator_driver" rateId="3-1-2-3" />  <!--欧洲卡车模驾驶拟器2018-->
  <item package="com.mars.fkdqq.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂的球球-->
  <item package="com.yunbu.royalwedding2.nearme.gamecenter" rateId="3-1-2-3" />  <!--冰雪皇家婚礼2-->
  <item package="com.mas.wawagame.nearme.gamecenter" rateId="3-1-2-3" />  <!--真人斗地主2-->
  <item package="com.yzxx.pixelwildworld.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素求生战场-->
  <item package="com.thgame.maze.nearme.gamecenter" rateId="3-1-2-3" />  <!--迷宫解谜-->
  <item package="com.guandan.nearme.gamecenter" rateId="3-1-2-3" />  <!--掼蛋-->
  <item package="com.tencent.ft" rateId="3-1-2-3" />  <!--妖精的尾巴：魔导少年-->
  <item package="com.KingOfTank.nearme.gamecenter" rateId="3-1-2-3" />  <!--坦克前线：帝国OL-->
  <item package="com.dkm.wmsg.nearme.gamecenter" rateId="3-1-2-3" />  <!--文明曙光-->
  <item package="com.tencent.kof" rateId="3-1-2-3" />  <!--拳皇命运-->
  <item package="com.leiben.bridgebuilder.nearme.gamecenter" rateId="3-1-2-3" />  <!--翻滚飞车-->
  <item package="com.igame.mrzl.nearme.gamecenter" rateId="3-1-2-3" />  <!--明日之恋-->
  <item package="com.tomato.joy.cqpz.nearme.gamecenter" rateId="3-1-2-3" />  <!--彩球碰撞-->
  <item package="com.whjf.qmcjzc.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民吃鸡战场-->
  <item package="np.idreamsky.horizonchase.nearme.gamecenter" rateId="3-1-2-3" />  <!--疾风飞车世界-->
  <item package="com.tencent.yunmeng" rateId="3-1-2-3" />  <!--云梦四时歌-->
  <item package="com.zhexinit.haimianbaobaopaoku.nearme.gamecenter" rateId="3-1-2-3" />  <!--海绵宝宝-->
  <item package="com.joym.bearforward.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊大熊二向前冲-->
  <item package="com.huochairen.breaking.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人必须死-->
  <item package="com.liuguan.jjsdzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--狙击手大追击-->
  <item package="com.cmge.lzjx.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙珠觉醒-->
  <item package="com.shenhaichuidiao.net.nearme.gamecenter" rateId="3-1-2-3" />  <!--深海垂钓-->
  <item package="ao.qjxsr.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素人前进-->
  <item package="com.xyjx.hardtime.nearme.gamecenter" rateId="3-1-2-3" />  <!--玄元剑仙-->
  <item package="com.jd.game.onetfruit.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心水果连连看2-->
  <item package="com.jianyou.jszzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--僵尸榨汁机-->
  <item package="com.sg.atmlmzbbcr.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼联盟之百变超人-->
  <item package="com.joym.runningbear.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊熊乐园奔跑吧熊大-->
  <item package="com.GF.apcgcncn.hwyad.nearme.gamecenter" rateId="3-1-2-3" />  <!--熹妃Q传-->
  <item package="com.tomato.joy.zjfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--致命漂移-->
  <item package="com.e8game.lpsfq2.nearme.gamecenter" rateId="3-1-2-3" />  <!--找到老婆的私房钱2-->
  <item package="air.com.martian.RoomEscape1.oppo" rateId="3-1-2-3" />  <!--密室逃脱1逃离地牢-->
  <item package="com.zsfz.cjpk.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级跑酷-->
  <item package="com.tencent.game.SSGame" rateId="3-1-2-3" />  <!--天天飞车-->
  <item package="com.tencent.WeFire" rateId="3-1-2-3" />  <!--全民突击-->
  <item package="com.yunbu.princessmagic.nearme.gamecenter" rateId="3-1-2-3" />  <!--公主魔法美妆-->
  <item package="com.fingertip.tyt.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心跳一跳-->
  <item package="com.netease.pes.nearme.gamecenter" rateId="3-1-2-3" disableAnimHighRate="true" />  <!--实况足球 商店版 -->
  <item package="com.netease.pes" rateId="3-1-2-3" disableAnimHighRate="true" />  <!--实况足球 官网版-->
  <item package="com.junhai.tgfml.nearme.gamecenter" rateId="3-1-2-3" />  <!--太古封魔录-->
  <item package="com.tencent.hyrzol" rateId="3-1-2-3" />  <!--火影忍者：忍者新世代-->
  <item package="com.yunbu.magicprincess.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔法公主礼仪学院-->
  <item package="com.mlmhxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦幻逍遥-->
  <item package="com.tomato.joy.ybh.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心玻璃杯-->
  <item package="com.yodo1.tew.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形金刚:地球之战-->
  <item package="com.bingougame.tgsw.nearme.gamecenter" rateId="3-1-2-3" />  <!--太古神王-->
  <item package="com.tyqy.nearme.gamecenter" rateId="3-1-2-3" />  <!--天影奇缘-->
  <item package="com.zsfz.tss.nearme.gamecenter" rateId="3-1-2-3" />  <!--贪食蛇-->
  <item package="com.zsfz.dsmtc.nearme.gamecenter" rateId="3-1-2-3" />  <!--登山摩托车-->
  <item package="com.libii.libbychef.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主之梦幻餐厅-->
  <item package="com.ViperGames.StickmanDismount" rateId="3-1-2-3" />  <!--弄死火柴人（StickmanDismounting）-->
  <item package="com.liuguan.xqs.nearme.gamecenter" rateId="3-1-2-3" />  <!--小枪手-->
  <item package="com.tencent.tmgp.sskgame" rateId="3-1-2-3" />  <!--圣斗士星矢(腾讯)-->
  <item package="com.netease.wotb.nearme.gamecenter" rateId="3-1-2-3" />  <!--坦克世界闪击战-->
  <item package="com.noodlecake.gettingoverit" rateId="3-1-2-3" />  <!--掘地求升-->
  <item package="com.jiguang.dtszj.nearme.gamecenter" rateId="3-1-2-3" />  <!--永恒纪元：戒-->
  <item package="com.pujiadev.skipschool3.nearme.gamecenter" rateId="3-1-2-3" />  <!--我要翘课-->
  <item package="com.jiami.quickmj.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐四川麻将3D版-->
  <item package="com.netease.frxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--非人学园-->
  <item package="com.yichao.fish.nearme.gamecenter" rateId="3-1-2-3" />  <!--乐金捕鱼-->
  <item package="com.quduoduo.penrun.nearme.gamecenter" rateId="3-1-2-3" />  <!--奔跑的笔-->
  <item package="com.jd.game.onetpet.nearme.gamecenter" rateId="3-1-2-3" />  <!--宠物连连消-->
  <item package="com.zsfz.ppd3.nearme.gamecenter" rateId="3-1-2-3" />  <!--泡泡弹-->
  <item package="com.libii.puppysalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主之宠物沙龙-->
  <item package="com.netease.stzb.nearme.gamecenter" rateId="3-1-2-3" />  <!--率土之滨-->
  <item package="com.jhtc.snake.nearme.gamecenter" rateId="3-1-2-3" />  <!--贪吃蛇大乱斗-->
  <item package="com.libii.princessnewbaby.nearme.gamecenter" rateId="3-1-2-3" />  <!--公主的新生小宝宝-->
  <item package="com.supertapx.lovedots.nearme.gamecenter" rateId="3-1-2-3" />  <!--恋爱球球-->
  <item package="com.zsfz.hcryx.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人英雄-->
  <item package="com.onemore.d2" rateId="3-1-2-3" />  <!--极品狂飙Ⅱ-->
  <item package="com.jym.fungames.flightpilot.nearme.gamecenter" rateId="3-1-2-3" />  <!--机械飞行师-->
  <item package="com.zsfz.xnny3dmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--虚拟女友模拟-->
  <item package="com.XCMTS.BearLimitejection.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之极限弹射-->
  <item package="com.idreamsky.mygarfield.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的加菲猫-->
  <item package="com.k7k7.BaoHuang.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐保皇-->
  <item package="com.onesyn.syobonaction_online" rateId="3-1-2-3" />  <!--猫里奥-->
  <item package="com.xplaygame.tuoluo.nearme.gamecenter" rateId="3-1-2-3" />  <!--旋转陀螺多人对战-->
  <item package="com.hswy.wrddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--万人斗地主-->
  <item package="com.tencent.tmgp.projectg" rateId="3-1-2-3" />  <!--和平精英体验服-->
  <item package="com.fengniao.qtdl.nearme.gamecenter" rateId="3-1-2-3" />  <!--抢滩登陆3D-->
  <item package="com.mili.mnhxdr.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟大恐龙-->
  <item package="com.zsfz.klbddhdl.nearme.gamecenter" rateId="3-1-2-3" />  <!--可乐被弟弟喝掉了-->
  <item package="com.qzyx2.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--英雄枪战-->
  <item package="com.wifi.popstar.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳一跳加强版-->
  <item package="com.wb.qqccc.nearme.gamecenter" rateId="3-1-2-3" />  <!--球球冲冲冲-->
  <item package="com.mfkj.pmdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--泡面大作战-->
  <item package="com.tetrisAn.nearme.gamecenter" rateId="3-1-2-3" />  <!--俄罗斯方块-->
  <item package="com.xcqy.nearme.gamecenter" rateId="3-1-2-3" />  <!--星辰奇缘-->
  <item package="com.frontline.DesertEscape.nearme.gamecenter" rateId="3-1-2-3" />  <!--沙漠逃生-->
  <item package="com.k7k7.shengjihd.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐升级-->
  <item package="com.joym.armorultraman.nearme.gamecenter" rateId="3-1-2-3" />  <!--机甲奥特曼-->
  <item package="com.yingxiong.dfzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--巅峰战舰-->
  <item package="com.netease.nshhelper.nearme.gamecenter" rateId="3-1-2-3" />  <!--遇见逆水寒-->
  <item package="com.kuiyi.lysq.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级步兵-->
  <item package="com.lemonjamstudio.drawacar.nearme.gamecenter" rateId="3-1-2-3" />  <!--画个车-->
  <item package="com.jsh.hcsy.nearme.gamecenter" rateId="3-1-2-3" />  <!--豪车盛宴-->
  <item package="com.mojang.minecraftpe" rateId="3-1-2-3" />  <!--我的世界-->
  <item package="com.pdragon.weiqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--围棋-->
  <item package="com.centurysoft.roboking" rateId="3-1-2-3" />  <!--机战王-->
  <item package="com.nova.Exciting.nearme.gamecenter" rateId="3-1-2-3" />  <!--刺激狂飙-->
  <item package="com.wingjoy.mylife.nearme.gamecenter" rateId="3-1-2-3" />  <!--第二人生-->
  <item package="com.mfkj.fkdpd.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂的拍打-->
  <item package="com.tianyi.jxmxtz3d.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--极限冒险挑战3D-->
  <item package="com.libii.princessroyalhorse.nearme.gamecenter" rateId="3-1-2-3" />  <!--皇家马术俱乐部-->
  <item package="com.e8game.gtfl.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼钢铁飞龙-->
  <item package="com.zlongame.yjqy.nearme.gamecenter" rateId="3-1-2-3" />  <!--御剑情缘-->
  <item package="com.gzbg.syyh.nearme.gamecenter" rateId="3-1-2-3" />  <!--神域永恒-->
  <item package="com.douapp.bricks" rateId="3-1-2-3" />  <!--砖块破坏者-->
  <item package="com.igame.hzmmgmx.nearme.gamecenter" rateId="3-1-2-3" />  <!--盒子猫-迷宫冒险-->
  <item package="com.xxyx.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--小小英雄-->
  <item package="com.game2048.nearme.gamecenter" rateId="3-1-2-3" />  <!--2048-->
  <item package="com.boyaa.chinesechess.nearme.gamecenter" rateId="3-1-2-3" />  <!--博雅中国象棋-->
  <item package="com.sns.yongzhelixianji.nearme.gamecenter" rateId="3-1-2-3" />  <!--勇者历险记-->
  <item package="com.ocean.nearme.gamecenter" rateId="3-1-2-3" />  <!--木筏求生-->
  <item package="com.sg.atmfkpk.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼疯狂跑酷-->
  <item package="com.mfkj.xhacj.nearme.gamecenter" rateId="3-1-2-3" />  <!--小虎爱吃鸡-->
  <item package="com.dramaton.slime" rateId="3-1-2-3" />  <!--粘液模拟器-->
  <item package="com.ftwxsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--废土行动-->
  <item package="com.libii.gloriamakeupsalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--洛娜公主美妆沙龙-->
  <item package="com.leqi.buyu2.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼比赛-->
  <item package="com.yunbu.motorider.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实摩托锦标赛-->
  <item package="com.tencent.tmgp.bydr3dx" rateId="3-1-2-3" />  <!--捕鱼来了-->
  <item package="cn.ultralisk.gameapp.game16.nearme.gamecenter" rateId="3-1-2-3" />  <!--叶罗丽公主水晶鞋-->
  <item package="com.shenghe.mfyx.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--原始传奇-->
  <item package="com.tencent.ssss" rateId="3-1-2-3" />  <!--三生三世十里桃花-->
  <item package="com.tencent.wok" rateId="3-1-2-3" />  <!--万王之王3D-->
  <item package="com.mfkj.tcscsdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--经典贪吃蛇-->
  <item package="com.zongyi.Popstar_HX.nearme.gamecenter" rateId="3-1-2-3" />  <!--消灭星星青春版-->
  <item package="com.dygame.hyqs.nearme.gamecenter" rateId="3-1-2-3" />  <!--荒岛求生-->
  <item package="com.morefun.crazyman.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂小野人-->
  <item package="com.melestudio.jigsaw.nearme.gamecenter" rateId="3-1-2-3" />  <!--拼图游戏挑战-->
  <item package="com.wemomo.game.smbb.nearme.gamecenter" rateId="3-1-2-3" />  <!--数码宝贝:相遇-->
  <item package="com.gagex.android.Orion.nearme.gamecenter" rateId="3-1-2-3" />  <!--众多回忆的食堂故事-->
  <item package="com.szgd.GGBondAmazingHero.nearme.gamecenter" rateId="3-1-2-3" />  <!--猪猪侠之百变英雄-->
  <item package="com.igame.wjfjzc.nearme.gamecenter" rateId="3-1-2-3" />  <!--玩具飞机战场-->
  <item package="com.qqbk.fnny.nearme.gamecenter" rateId="3-1-2-3" />  <!--球球与白块-->
  <item package="com.tencent.lycqsh" rateId="3-1-2-3" />  <!--蓝月传奇-->
  <item package="com.tencent.tmgp.wec" rateId="3-1-2-3" />  <!--乱世王者-->
  <item package="com.cw.gamebox" rateId="3-1-2-3" />  <!--1号玩家-->
  <item package="com.MXW.XY3D.nearme.gamecenter" rateId="3-1-2-3" />  <!--鲨鱼模拟猎杀3D-->
  <item package="com.xishanju.mysy.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔域手游-->
  <item package="com.MXW.JSKC.nearme.gamecenter" rateId="3-1-2-3" />  <!--极速卡车-->
  <item package="com.qp.tlj.nearme.gamecenter" rateId="3-1-2-3" />  <!--拖拉机-->
  <item package="com.libii.tutotoons.kikififibeautysalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--琪琪和菲菲宠物美容院-->
  <item package="com.Lxd.Bearsfantasyspace.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没奇幻空间-->
  <item package="com.wedobest.piano.nearme.gamecenter" rateId="3-1-2-3" />  <!--白块儿达人-->
  <item package="com.sjxx.qmfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--3D全民飞车-->
  <item package="com.jym.vegascrime2.two.nearme.gamecenter" rateId="3-1-2-3" />  <!--拉斯维加斯英雄归来-->
  <item package="com.zsfz.ayjjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--暗影狙击手-->
  <item package="com.longyuan.zzq.nearme.gamecenter" rateId="3-1-2-3" />  <!--多多自走棋-->
  <item package="com.wxhf.erzhanjuji.nearme.gamecenter" rateId="3-1-2-3" />  <!--二战狙击-->
  <item package="com.shrw.qsq.nearme.gamecenter" rateId="3-1-2-3" />  <!--多兰大陆-->
  <item package="com.jjh.Fish.nearme.gamecenter" rateId="3-1-2-3" />  <!--集结号捕鱼-->
  <item package="com.wqhz.hjtg.nearme.gamecenter" rateId="3-1-2-3" />  <!--出击英雄岛-->
  <item package="com.gzxm.saiche.nearme.gamecenter" rateId="3-1-2-3" />  <!--绝地飞车-->
  <item package="com.MXW.ZZYX.nearme.gamecenter" rateId="3-1-2-3" />  <!--蜘蛛英雄：惩罚罪恶-->
  <item package="com.sg.atmpk.oppo" rateId="3-1-2-3" />  <!--酷跑超人-->
  <item package="com.wali.ak.nearme.gamecenter" rateId="3-1-2-3" />  <!--小米枪战-->
  <item package="com.happyelements.happyfishandroidcns" rateId="3-1-2-3" />  <!--开心水族箱-->
  <item package="com.cqwx.hcrjjst.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人狙击手3-->
  <item package="com.HRYX.klls3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐龙猎杀3d-->
  <item package="com.tencent.tmgp.mituan" rateId="3-1-2-3" />  <!--疯狂动物城:筑梦日记-->
  <item package="com.hzfb.racing8.nearme.gamecenter" rateId="3-1-2-3" />  <!--速度与激情8-->
  <item package="com.ultralisk.game24.nearme.gamecenter" rateId="3-1-2-3" />  <!--神兽金刚3荣耀之战-->
  <item package="com.fingersoft.hillclimb.cn.noncmcc" rateId="3-1-2-3" />  <!--登山赛车之天朝历险-->
  <item package="com.jixiang.game" rateId="3-1-2-3" />  <!--吉祥棋牌-->
  <item package="com.gzxm.rhythm.nearme.gamecenter" rateId="3-1-2-3" />  <!--钢琴白块节奏-->
  <item package="com.wb.gzsj2.nearme.gamecenter" rateId="3-1-2-3" />  <!--果汁四溅2-->
  <item package="com.libii.libbyvampire.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比公主和精灵贝拉-->
  <item package="com.yinhan.hunter.tx" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.shenghe.wzcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--王者传奇-->
  <item package="com.saturngame.kdjd.nearme.gamecenter" rateId="3-1-2-3" />  <!--口袋决斗-->
  <item package="com.soonyo.byds.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼大师-->
  <item package="com.rappidstudios.simulatorbattlearmy" rateId="3-1-2-3" />  <!--军队战争模拟器-->
  <item package="com.tomato.joy.jdds.nearme.gamecenter" rateId="3-1-2-3" />  <!--掘地登山-->
  <item package="com.longtugame.rxjh.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血江湖-->
  <item package="air.FleeingtheComplex" rateId="3-1-2-3" />  <!--火柴人逃离监狱-->
  <item package="com.libiitech.sweetprincesshairsalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--甜心公主美发屋-->
  <item package="com.yunbu.cutekitty.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的宠物猫-->
  <item package="me.hypertext.local.jiong2" rateId="3-1-2-3" />  <!--最囧游戏-->
  <item package="com.youmeng.rexueaoteman.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血奥特超人跑酷-->
  <item package="com.zsfz.jsslz.nearme.gamecenter" rateId="3-1-2-3" />  <!--饥鲨狩猎者-->
  <item package="com.tencent.freestyle" rateId="3-1-2-3" />  <!--街头篮球-->
  <item package="com.libii.puppystory.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的心动小狗-->
  <item package="com.moli.minigame.rollball.nearme.gamecenter" rateId="3-1-2-3" />  <!--滚动大作战-->
  <item package="com.lywl.xbxxz.nearme.gamecenter" rateId="3-1-2-3" />  <!--想不想修真-->
  <item package="com.joypac.dagen.nearme.gamecenter" rateId="3-1-2-3" />  <!--抱紧大根-->
  <item package="com.igame.mmxbl.nearme.gamecenter" rateId="3-1-2-3" />  <!--萌萌小笨龙-->
  <item package="com.tencent.Qfarm" rateId="3-1-2-3" />  <!--全民农场-->
  <item package="com.huoshe.klblb.nearme.gamecenter" rateId="3-1-2-3" />  <!--快乐玻璃杯-->
  <item package="io.voodoo.paper2" rateId="3-1-2-3" />  <!--纸片大作战2-->
  <item package="com.blockycars.online.wf.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素车-->
  <item package="com.gamecoolsoft.daysnipe03" rateId="3-1-2-3" />  <!--天天狙击-->
  <item package="com.wb.hjqg.nearme.gamecenter" rateId="3-1-2-3" />  <!--黄金切割-->
  <item package="com.yunbu.fashionmakeup.nearme.gamecenter" rateId="3-1-2-3" />  <!--时尚美妆达人-->
  <item package="com.mingya.highwayracer.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实汽车锦标赛-->
  <item package="com.yifeng.samecolor.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳一跳大师-->
  <item package="com.libii.babycare.nearme.gamecenter" rateId="3-1-2-3" />  <!--公主宝宝照顾-->
  <item package="com.sy.lhxz.nearme.gamecenter" rateId="3-1-2-3" />  <!--精灵契约-->
  <item package="com.yifeng.elsfko.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐俄罗斯方块-->
  <item package="com.cmcm.killshotbravo.nearme.gamecenter" rateId="3-1-2-3" />  <!--狙神荣耀-->
  <item package="org.xiaoFeng.AboutYouself" rateId="3-1-2-3" />  <!--你了解自己吗-->
  <item package="com.xcdh.jumponejump.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂跳一跳-->
  <item package="com.yunbu.candyprincess.nearme.gamecenter" rateId="3-1-2-3" />  <!--彩虹糖果公主-->
  <item package="com.pdragon.tcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--贪吃蛇-->
  <item package="com.tianyi.xsmxsj.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素冒险世界-->
  <item package="com.igame.jsfczjkb.nearme.gamecenter" rateId="3-1-2-3" />  <!--急速飞车终极狂飙-->
  <item package="com.mfkj.mndb.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟大巴-->
  <item package="com.tencent.tmgp.jxqy" rateId="3-1-2-3" />  <!--新剑侠情缘-->
  <item package="com.wb.tkdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--坦克进化大作战-->
  <item package="com.uc108.mobile.gamecenter" rateId="3-1-2-3" />  <!--同城游-->
  <item package="com.igame.sqdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--神枪大作战-->
  <item package="com.soulgame.garfield.nearme.gamecenter" rateId="3-1-2-3" />  <!--加菲猫酷跑-->
  <item package="com.gameloft.android.ANMP.GloftDLCN.nearme.gamecenter" rateId="3-1-2-3" />  <!--萌龙大乱斗-->
  <item package="com.yunbu.princessmakeupshow.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔法公主美妆秀-->
  <item package="com.netease.lx12.nearme.gamecenter" rateId="3-1-2-3" />  <!--流星蝴蝶剑-->
  <item package="com.libii.perfectbeachday.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主的完美沙滩之旅-->
  <item package="zo.wz.xingd.nearme.gamecenter" rateId="3-1-2-3" />  <!--火线王者求生-->
  <item package="cn.jj.hall" rateId="3-1-2-3" />  <!--JJ比赛-->
  <item package="com.zyxd.mycm.nearme.gamecenter" rateId="3-1-2-3" />  <!--萌妖出没-->
  <item package="com.MXW.GTZCYY.nearme.gamecenter" rateId="3-1-2-3" />  <!--钢铁战场英雄-->
  <item package="com.joym.xiongchumo2.keke" rateId="3-1-2-3" />  <!--熊出没2-->
  <item package="com.asdk.pokemontcg.nearme.gamecenter" rateId="3-1-2-3" />  <!--口袋对决-->
  <item package="com.zsfz.czczsmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--出租车真实模拟-->
  <item package="com.libii.gymnasticssalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--体操沙龙-->
  <item package="com.zsfz.xfcjymn.qm3dsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--3D全民赛车-->
  <item package="com.joym.bearsadventure.keke" rateId="3-1-2-3" />  <!--熊出没大冒险-->
  <item package="com.ycoolgame.riseofsteel.nearme.gamecenter" rateId="3-1-2-3" />  <!--钢铁英雄-->
  <item package="com.gameloft.android.ANMP.GloftA9HM" rateId="3-1-2-3" />  <!--狂野飙车9-->
  <item package="com.ddy.cjwpscs.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级王牌赛车手-->
  <item package="com.hq.Ultramancszzdd.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼传说之战（重名）-->
  <item package="me.ht.local.hot" rateId="3-1-2-3" />  <!--最囧游戏2-->
  <item package="com.jycx.klqsz.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐龙求生战-->
  <item package="com.yunbu.archeryelite.nearme.gamecenter" rateId="3-1-2-3" />  <!--最强神射手-->
  <item package="cn.ultralisk.game20.nearme.gamecenter" rateId="3-1-2-3" />  <!--巨神战击队3-->
  <item package="com.xianlai.mahjonghainan" rateId="3-1-2-3" />  <!--琼崖海南麻将-->
  <item package="com.snsgz.apk.nearme.gamecenter" rateId="3-1-2-3" />  <!--少年三国志-->
  <item package="com.haoxin.ultramanyxcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼英雄传说-->
  <item package="com.fengguo.wpjz.nearme.gamecenter" rateId="3-1-2-3" />  <!--王牌机战-->
  <item package="com.dingogames.tastyblue" rateId="3-1-2-3" />  <!--美味深蓝-->
  <item package="com.kingnet.gundam.nearme.gamecenter" rateId="3-1-2-3" />  <!--敢达争锋对决-->
  <item package="air.jp.ne.hap.mom" rateId="3-1-2-3" />  <!--妈妈把我的游戏藏起来了2-->
  <item package="com.pdragon.junqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--军棋-->
  <item package="com.dodjoy.qhzs.nearme.gamecenter" rateId="3-1-2-3" />  <!--枪神对决-->
  <item package="com.patastudio.crazycooking.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天爱烹饪-->
  <item package="com.pixadventure.nearme.gamecenter" rateId="3-1-2-3" />  <!--荒野生存大冒险-->
  <item package="com.netmarble.ffightgm" rateId="3-1-2-3" />  <!--未来之战-->
  <item package="com.heimai666.ninja.nearme.gamecenter" rateId="3-1-2-3" />  <!--刃心-->
  <item package="com.yzyfs.net.nearme.gamecenter" rateId="3-1-2-3" />  <!--御封神-->
  <item package="com.gamelar.larva.nearme.gamecenter" rateId="3-1-2-3" />  <!--爆笑虫子大冒险-->
  <item package="com.libii.libbydessert.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主梦幻甜品店-->
  <item package="com.dodreams.driveahead" rateId="3-1-2-3" />  <!--撞头赛车-->
  <item package="com.jg.dtszj.nearme.gamecenter" rateId="3-1-2-3" />  <!--大天使之剑H5-->
  <item package="com.lc.jongthree.nearme.gamecenter" rateId="3-1-2-3" />  <!--创造大明星-->
  <item package="com.tencent.tmgp.mt4" rateId="3-1-2-3" />  <!--我叫MT4-->
  <item package="com.igame.lhzs.nearme.gamecenter" rateId="3-1-2-3" />  <!--烈火战神-->
  <item package="com.mingya.shark.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实模拟鲨鱼捕食-->
  <item package="com.jedigames.p16s.nearme.gamecenter" rateId="3-1-2-3" />  <!--银河战舰-->
  <item package="org.tinghood.TpsForMobile.nearme.gamecenter" rateId="3-1-2-3" />  <!--台球帝国-->
  <item package="com.njtd.zswqmnq.nearme.gamecenter" rateId="3-1-2-3" />  <!--让武器飞-->
  <item package="com.myappz.firegirlWaterboy" rateId="3-1-2-3" />  <!--森林冰火人-->
  <item package="it.rortos.airfighterspro" rateId="3-1-2-3" />  <!--模拟空战（AirFightersPro）-->
  <item package="com.qipai007.Black7.nearme.gamecenter" rateId="3-1-2-3" />  <!--升级-->
  <item package="com.nzyz.qmqzsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民枪战射击-->
  <item package="com.igame.kbzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--狂暴战机-->
  <item package="com.outfit7.tomsjetski.nearme.gamecenter" rateId="3-1-2-3" />  <!--动物快跑-->
  <item package="com.wedobest.cyxxx.nearme.gamecenter" rateId="3-1-2-3" />  <!--成语消消消-->
  <item package="com.yunbu.starlovestory.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉莎的梦幻之旅-->
  <item package="com.gameloft.android.ANMP.GloftA8HM" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.tencent.jian" rateId="3-1-2-3" />  <!--见-->
  <item package="com.tongcn.bxdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形大作战-->
  <item package="com.fingertip.feixingqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--飞行棋大作战-->
  <item package="com.mingya.crazytruck.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实货车模拟：模拟卡车-->
  <item package="com.leon.qyby.nearme.gamecenter" rateId="3-1-2-3" />  <!--趣游捕鱼-->
  <item package="com.zsfz.bbbwszjll.nearme.gamecenter" rateId="3-1-2-3" />  <!--爸爸把我锁在家里了-->
  <item package="com.igame.jqmx.nearme.gamecenter" rateId="3-1-2-3" />  <!--激情冒险-->
  <item package="com.ztgame.fir.nearme.gamecenter" rateId="3-1-2-3" />  <!--征途2-->
  <item package="ttby.zlkj.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天捕鱼电玩版-->
  <item package="com.joym.xiongchumo4.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没4丛林冒险-->
  <item package="com.zcjoy.hlsrddz.android.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐四人斗地主-->
  <item package="com.huoshe.qqtyt.nearme.gamecenter" rateId="3-1-2-3" />  <!--球球跳一跳-->
  <item package="com.hsfish.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--火山捕鱼-->
  <item package="com.playflame.oilhunt2" rateId="3-1-2-3" />  <!--OilHunt2-->
  <item package="com.ddianle.lovedance.nearme.gamecenter" rateId="3-1-2-3" />  <!--恋舞OL-->
  <item package="com.kaopu.lhjx.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙之怒吼-->
  <item package="com.miquwan.sgzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--三国战争-->
  <item package="com.zsfz.bxjqfl3d.mfgame.nearme.gamecenter" rateId="3-1-2-3" />  <!--暴走雷龙战机-->
  <item package="com.cdbabyjoy.pinyin" rateId="3-1-2-3" />  <!--儿童宝宝学拼音-->
  <item package="com.ShenY.DDiZHU.nearme.gamecenter" rateId="3-1-2-3" />  <!--斗地主经典版-->
  <item package="com.sngx.nearme.gamecenter" rateId="3-1-2-3" />  <!--少年歌行-->
  <item package="com.joym.armorbear2018.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没森林勇士-->
  <item package="com.libii.halloweenboutique.nearme.gamecenter" rateId="3-1-2-3" />  <!--万圣节时装店-->
  <item package="com.apowo.picatown.nearme.gamecenter" rateId="3-1-2-3" />  <!--皮卡堂3D-->
  <item package="com.wedobest.zjscs.nearme.gamecenter" rateId="3-1-2-3" />  <!--指尖神车手-->
  <item package="com.martian.hxjxgs.nearme.gamecenter" rateId="3-1-2-3" />  <!--滑翔极限高手-->
  <item package="com.shiyue.sszg.nearme.gamecenter" rateId="3-1-2-3" />  <!--闪烁之光-->
  <item package="com.liuguan.yddcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--拥堵的城市-->
  <item package="com.xt.mntcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐龙狙击狩猎-->
  <item package="com.wyd.hero.yqlfc.cb1.nearme.gamecenter" rateId="3-1-2-3" />  <!--一起来飞车-->
  <item package="com.nova.redwolf.nearme.gamecenter" rateId="3-1-2-3" />  <!--火线荣耀-->
  <item package="top.minnows.jiong3" rateId="3-1-2-3" />  <!--最囧游戏3-->
  <item package="com.igame.mntljnc.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟拖拉机农场-->
  <item package="com.gangqindaren.nearme.gamecenter" rateId="3-1-2-3" />  <!--白块儿钢琴达人-->
  <item package="com.droidhang.ad.nearme.gamecenter" rateId="3-1-2-3" />  <!--放置奇兵-->
  <item package="com.quantum.jwqy.nearme.gamecenter" rateId="3-1-2-3" />  <!--风云七剑-->
  <item package="com.kdjh.leisunet.net.nearme.gamecenter" rateId="3-1-2-3" />  <!--口袋进化-->
  <item package="com.sx.hlxj.nearme.gamecenter" rateId="3-1-2-3" />  <!--幻灵仙境-->
  <item package="com.ty.fishing.nearme.gamecenter" rateId="3-1-2-3" />  <!--享越疯狂钓鱼-->
  <item package="com.tencent.tako.muses" rateId="3-1-2-3" />  <!--云裳羽衣-->
  <item package="com.games.hc.acing.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人联盟2-->
  <item package="com.melestudio.ColoringBook.nearme.gamecenter" rateId="3-1-2-3" />  <!--儿童画画-->
  <item package="com.quduoduo.pixeldot.nearme.gamecenter" rateId="3-1-2-3" />  <!--画画数字填色-->
  <item package="com.ycgame.smsy.nearme.gamecenter" rateId="3-1-2-3" />  <!--蜀门-->
  <item package="com.invictus.giveitup2.oppo" rateId="3-1-2-3" />  <!--永不言弃2-->
  <item package="com.tianyi.qljzmn.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--桥梁建造模拟-->
  <item package="com.xiaoji.emulator" rateId="3-1-2-3" />  <!--小鸡模拟器-->
  <item package="com.igame.cstkdz.nearme.gamecenter" rateId="3-1-2-3" />  <!--超神坦克大战-->
  <item package="mykp.nyt.nearme.gamecenter" rateId="3-1-2-3" />  <!--妈呀快跑-->
  <item package="com.tencent.qqgame.qqfive" rateId="3-1-2-3" />  <!--欢乐五子棋-->
  <item package="city.truck.race3d" rateId="3-1-2-3" />  <!--3D火车驾驶员-->
  <item package="com.igame.klsl.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐龙狩猎-->
  <item package="com.tiandou.gameddsk.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟山羊-->
  <item package="com.martian.RoomEscape17.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱17守护公寓-->
  <item package="com.xigua.xmws.nearme.gamecenter" rateId="3-1-2-3" />  <!--剑与契约-->
  <item package="com.bear.UnLuckBear.nearme.gamecenter" rateId="3-1-2-3" />  <!--倒霉熊奇幻大冒险-->
  <item package="com.tencent.tmgp.TCrossSGJQ" rateId="3-1-2-3" />  <!--腾讯天天军棋-->
  <item package="com.feelingtouch.zf4.nearme.gamecenter" rateId="3-1-2-3" />  <!--僵尸前线4-->
  <item package="com.yunbu.coloringcreative2.nearme.gamecenter" rateId="3-1-2-3" />  <!--神奇像素画-->
  <item package="com.ripostegames.ctbz.nearme.gamecenter" rateId="3-1-2-3" />  <!--寸土必争-->
  <item package="com.pwrd.wlwz.nearme.gamecenter" rateId="3-1-2-3" />  <!--武林外传-->
  <item package="com.yunbu.restauranttycoon.nearme.gamecenter" rateId="3-1-2-3" />  <!--美食城大亨-->
  <item package="com.lxd.xcmzcldzw.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之丛林大战2-->
  <item package="com.zsfz.ncmn3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--农场模拟3D-->
  <item package="com.RoosterGames.TruckDriver2Multiplayer.t" rateId="3-1-2-3" />  <!--旋转轮胎-->
  <item package="com.yyzy.nearme.gamecenter" rateId="3-1-2-3" />  <!--月圆之夜-->
  <item package="com.halfbrick.fruitninja" rateId="3-1-2-3" />  <!--水果忍者-->
  <item package="com.saturngame.pm2.nearme.gamecenter" rateId="3-1-2-3" />  <!--口袋日月-->
  <item package="com.tnyoo.z.nearme.gamecenter" rateId="3-1-2-3" />  <!--黎明之路-->
  <item package="air.com.tencent.qqfarmios" rateId="3-1-2-3" />  <!--QQ农场-->
  <item package="com.wsy.wansuiye.nearme.gamecenter" rateId="3-1-2-3" />  <!--叫我万岁爷-->
  <item package="com.wedobest.shudu.nearme.gamecenter" rateId="3-1-2-3" />  <!--数独-->
  <item package="com.njyk.laoshumoni.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实老鼠模拟-->
  <item package="com.libii.mermaidparty" rateId="3-1-2-3" />  <!--美人鱼派对海底历险记-->
  <item package="com.leyo.cjfx.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级飞侠环球大冒险-->
  <item package="com.zplay.beatracer.nearme.gamecenter" rateId="3-1-2-3" />  <!--电音超跑-->
  <item package="com.netease.h48.nearme.gamecenter" rateId="3-1-2-3" />  <!--神都夜行录-->
  <item package="com.tencent.tmgp.ttwq" rateId="3-1-2-3" />  <!--腾讯围棋-->
  <item package="com.jumpw.mobile.nearme.gamecenter" rateId="3-1-2-3" />  <!--300大作战-->
  <item package="com.redwords.hcrxs.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人先生：刺激吃鸡-->
  <item package="com.sg.ultramanheros.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼超人大战小怪兽-->
  <item package="com.crazyant.tinyfatter.nearme.gamecenter" rateId="3-1-2-3" />  <!--你胖你先吃-->
  <item package="com.wq.PixelBumperCar.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素碰碰车-->
  <item package="com.outfit7.mytalkingtomfree" rateId="3-1-2-3" />  <!--我的汤姆猫（宠物养成游戏）-->
  <item package="com.liuguan.qhjj.nearme.gamecenter" rateId="3-1-2-3" />  <!--枪魂狙击-->
  <item package="com.igame.fcry.nearme.gamecenter" rateId="3-1-2-3" />  <!--飞车荣耀-->
  <item package="com.tomato.joy.xqdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--雪球大作战-->
  <item package="com.idreamsky.terraria.nearme.gamecenter" rateId="3-1-2-3" />  <!--泰拉瑞亚-->
  <item package="com.youmeng.rexueaotechaorengedou.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血奥特超人格斗-->
  <item package="cn.lemongrassmedia.loveworld.nearme.gamecenter" rateId="3-1-2-3" />  <!--恋世界-->
  <item package="com.igame.nldbp.nearme.gamecenter" rateId="3-1-2-3" />  <!--脑力大比拼-->
  <item package="com.seyeonsoft.pastel" rateId="3-1-2-3" />  <!--粉彩女孩-->
  <item package="com.huoshe.wdccc.nearme.gamecenter" rateId="3-1-2-3" />  <!--无敌冲冲冲-->
  <item package="com.outfit7.mytalkingangelafree" rateId="3-1-2-3" />  <!--我的安吉拉-->
  <item package="com.pape.nuannew.nearme.gamecenter" rateId="3-1-2-3" />  <!--暖暖环游世界-->
  <item package="com.BoonieBearsEntangledWorldsTWO.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没奇幻空间2-->
  <item package="com.wedobest.HD1010.nearme.gamecenter" rateId="3-1-2-3" />  <!--罗斯方块-->
  <item package="com.mfgame.qmfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民极品飞车2-->
  <item package="com.tencent.tmgp.rxcq" rateId="3-1-2-3" />  <!--热血传奇-->
  <item package="com.jd.game.babyline.nearme.gamecenter" rateId="3-1-2-3" />  <!--宝宝爱连线-->
  <item package="com.mfkj.djkysc.nearme.gamecenter" rateId="3-1-2-3" />  <!--单机狂野赛车-->
  <item package="com.pdragon.HD1010" rateId="3-1-2-3" />  <!--方块消除小游戏-->
  <item package="com.superevilmegacorp.game" rateId="3-1-2-3" />  <!--虚荣(Vainglory)-->
  <item package="com.pdragon.new2048" rateId="3-1-2-3" />  <!--新2048-->
  <item package="wb.gc.xmxx.zxb" rateId="3-1-2-3" />  <!--消灭糖果-->
  <item package="com.happygod.fireman" rateId="3-1-2-3" />  <!--火柴人大乱斗-->
  <item package="com.tiancan.trucksform.nearme.gamecenter" rateId="3-1-2-3" />  <!--3D变形卡车-->
  <item package="com.sj3975.rxcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血传说-->
  <item package="com.liuguan.cjmmmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级妈妈模拟-->
  <item package="com.whmd.ppcdmx.nearme.gamecenter" rateId="3-1-2-3" />  <!--碰碰车大冒险-->
  <item package="com.catfun.happydmm.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心躲猫猫-->
  <item package="zxby.nearme.gamecenter" rateId="3-1-2-3" />  <!--指心捕鱼-->
  <item package="com.tianyi.qjdhy.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--秋季大荒原-->
  <item package="com.wb.gttq.nearme.gamecenter" rateId="3-1-2-3" />  <!--高台跳球-->
  <item package="com.taiyouxi.pk.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--王牌御史-->
  <item package="com.zsfz.yrttt2.nearme.gamecenter" rateId="3-1-2-3" />  <!--野人跳跳跳-->
  <item package="com.zmxyol.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--造梦西游OL-->
  <item package="com.quduoduo.nearme.gamecenter" rateId="3-1-2-3" />  <!--黑洞大作战：洞洞大乱斗-->
  <item package="com.zq.kltoys.town.nearme.gamecenter" rateId="3-1-2-3" />  <!--快乐酷跑-->
  <item package="com.joym.bearfarm.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之熊大农场-->
  <item package="com.zsfz.ygcsdmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--油罐车山地模拟-->
  <item package="com.hgqn.xcmfkds.oppo" rateId="3-1-2-3" />  <!--熊出没之疯狂弹射-->
  <item package="com.eyu.piano" rateId="3-1-2-3" />  <!--DreamPiano-->
  <item package="com.mfkj.ryfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--荣耀飞车-->
  <item package="com.bomwan.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔天记3D-->
  <item package="com.tencent.tmgp.dragonnest" rateId="3-1-2-3" />  <!--龙之谷-->
  <item package="com.netease.my" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.xzuson.game.homeburger.nearme.gamecenter" rateId="3-1-2-3" />  <!--有家汉堡包-->
  <item package="com.nidong.cmswat.nearme.gamecenter" rateId="3-1-2-3" />  <!--正义枪战-->
  <item package="cn.ultralisk.gameapp.game12.nearme.gamecenter" rateId="3-1-2-3" />  <!--巴啦啦魔法美妆2-->
  <item package="com.weile.game" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.teayelp.whereareyou" rateId="3-1-2-3" />  <!--找你妹2015-->
  <item package="com.cjfx.xqc.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级飞侠向前冲-->
  <item package="com.njtd.hcmnq.nearme.gamecenter" rateId="3-1-2-3" />  <!--火箭飞车-->
  <item package="aiwan.DanceLine.nearme.gamecenter" rateId="3-1-2-3" />  <!--猎龙消消大作战-->
  <item package="com.XXX.XCMZCLWZ.eagme.nearme.gamecenter" rateId="3-1-2-3" />  <!--熊出没之丛林王者-->
  <item package="com.nnmyll.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔域神曲：魔域来了-->
  <item package="com.tencent.modoomarble" rateId="3-1-2-3" />  <!--天天富翁-->
  <item package="com.yunbu.lovemonogatari.nearme.gamecenter" rateId="3-1-2-3" />  <!--心动美妆物语-->
  <item package="com.gameloft.android.ANMP.GloftGGHM" rateId="3-1-2-3" />  <!--Gangstar4-->
  <item package="tong.mgames.shcy.nearme.gamecenter" rateId="3-1-2-3" />  <!--深海大鱼吃小鱼-->
  <item package="com.netease.ms3.nearme.gamecenter" rateId="3-1-2-3" />  <!--迷室3-->
  <item package="cn.ultralisk.balala4" rateId="3-1-2-3" />  <!--巴啦啦魔法变身2-->
  <item package="com.tianyi.kbgs.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--恐怖故事-->
  <item package="com.idreamsky.carcrash.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐赛车大战-->
  <item package="com.mfp.jelly.yingyongbao" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.lhyy.childrentaciturnly" rateId="3-1-2-3" />  <!--儿童宝宝蘑菇钉游戏-->
  <item package="com.easymobi.plagueinc.oppo" rateId="3-1-2-3" />  <!--瘟疫公司-->
  <item package="com.majiang.scmj3.nearme.gamecenter" rateId="3-1-2-3" />  <!--四川麻将-换三张-->
  <item package="com.jsdw.zzxdongjiB.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴蜘蛛侠冬季版-->
  <item package="com.qbankilltext.hualu.nearme.gamecenter" rateId="3-1-2-3" />  <!--谁是卧底-->
  <item package="com.MXW.JJJT3D.nearme.gamecenter" rateId="3-1-2-3" />  <!--机甲军团：机器人时代3D-->
  <item package="com.pspd.igame.nearme.gamecenter" rateId="3-1-2-3" />  <!--喷射派对-->
  <item package="com.yunbu.magicprincess2.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔法公主礼仪学院2-->
  <item package="com.whjf.byfjmnjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--波音飞机模拟驾驶-->
  <item package="com.men.swfgame.scrawl" rateId="3-1-2-3" />  <!--儿童涂颜色游戏-->
  <item package="com.lew.game.ballparkour.nearme.gamecenter" rateId="3-1-2-3" />  <!--球球跑酷-->
  <item package="com.lg.xhlxd.nearme.gamecenter" rateId="3-1-2-3" />  <!--新葫芦兄弟-->
  <item package="com.sg.atmdztcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼大战贪吃蛇-->
  <item package="bf.sgs.hdexp" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.tinybuildgames.helloneighbor" rateId="3-1-2-3" />  <!--你好邻居-->
  <item package="com.ltby.nearme.gamecenter" rateId="3-1-2-3" />  <!--雷霆霸业-->
  <item package="com.kaixinhuoguodian.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心火锅店-->
  <item package="com.supercell.clashofclans.uc" rateId="3-1-2-3" />  <!--部落冲突-->
  <item package="com.quanmai.pmp.nearme.gamecenter" rateId="3-1-2-3" />  <!--口袋新世代-->
  <item package="com.ycoolgame.bubg.nearme.gamecenter" rateId="3-1-2-3" />  <!--绝密飞行-->
  <item package="com.cy.lnkp.nearme.gamecenter" rateId="3-1-2-3" />  <!--露娜快跑-->
  <item package="com.tomatojoy.fktl.nearme.gamecenter" rateId="3-1-2-3" />  <!--疯狂投篮-->
  <item package="com.zsfz.wjjzsmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--挖掘机真实模拟-->
  <item package="com.yiru.yxsrs.zygame" rateId="3-1-2-3" />  <!--一小时人生-->
  <item package="com.pokercity.ddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--波克斗地主-->
  <item package="com.minidip.mrwj.nearme.gamecenter" rateId="3-1-2-3" />  <!--末日危机-->
  <item package="com.yunbu.flowergirl.nearme.gamecenter" rateId="3-1-2-3" />  <!--花花姑娘之美妆奇缘-->
  <item package="com.snxyj.apk.nearme.gamecenter" rateId="3-1-2-3" />  <!--少年西游记-->
  <item package="kiss.game.princess.kissing119731" rateId="3-1-2-3" />  <!--公主接吻-->
  <item package="com.mediocre.grannysmith.nearme.gamecenter" rateId="3-1-2-3" />  <!--跑酷老奶奶-->
  <item package="com.mfkj.tgqj.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖果奇迹-->
  <item package="com.cqwx.mmbwdyxcqll.nearme.gamecenter" rateId="3-1-2-3" />  <!--妈妈把我的游戏藏起来了-->
  <item package="com.chumeng.zeus.nearme.gamecenter" rateId="3-1-2-3" />  <!--掌机小精灵-->
  <item package="mobi.shoumeng.ttbc3d" rateId="3-1-2-3" />  <!--3D天天飙车-超爽赛车-->
  <item package="com.wb.shqq.nearme.gamecenter" rateId="3-1-2-3" />  <!--守护球球-->
  <item package="com.puppetsgame.miracing.nearme.gamecenter" rateId="3-1-2-3" />  <!--小米赛车-->
  <item package="com.sanjiu.cqss2.nearme.gamecenter" rateId="3-1-2-3" />  <!--传奇盛世2-->
  <item package="com.fg.cat.nearme.gamecenter" rateId="3-1-2-3" />  <!--喵星变形军团-->
  <item package="com.shijun.android.dwtd.nearme.gamecenter" rateId="3-1-2-3" />  <!--蠢蠢的死法-->
  <item package="com.igame.zfz.nearme.gamecenter" rateId="3-1-2-3" />  <!--征服者-->
  <item package="com.hzsf.hcrjjsxd.game.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人狙击手行动-->
  <item package="com.kpzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--卡片战争-->
  <item package="com.jym.kyfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的狂野飞车-->
  <item package="com.skiddy.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民疯狂漂移-->
  <item package="com.redwoods.hcrcjpd.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人吃鸡派对-->
  <item package="com.libii.CandyCakeShop.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖糖蛋糕店-->
  <item package="com.tencent.tmgp.gods" rateId="3-1-2-3" />  <!--全民超神-->
  <item package="com.yunbu.badmintonleague.nearme.gamecenter" rateId="3-1-2-3" />  <!--羽毛球高高手-->
  <item package="com.miniclip.bowmasters" rateId="3-1-2-3" />  <!--弓箭手们-->
  <item package="com.shandagames.shelter.nearme.gamecenter" rateId="3-1-2-3" />  <!--辐射：避难所Online-->
  <item package="com.libii.candydesserthouse.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖糖甜品屋-->
  <item package="com.cwxjlfk.nearme.gamecenter" rateId="3-1-2-3" />  <!--宠物小精灵复刻-->
  <item package="com.wb.qwcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--趣味彩球-->
  <item package="com.pdragon.doushouqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--斗兽棋-->
  <item package="com.wedobest.feixingqi.nearme.gamecenter" rateId="3-1-2-3" />  <!--飞行棋-->
  <item package="com.martian.RoomEscape8.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱8红色豪宅-->
  <item package="com.chn.snowballio.nearme.gamecenter" rateId="3-1-2-3" />  <!--雪地大作战-->
  <item package="com.xhlw.hardtime.nearme.gamecenter" rateId="3-1-2-3" />  <!--新葫芦娃-->
  <item package="air.com.martian.RoomEscape2.oppo" rateId="3-1-2-3" />  <!--密室逃脱古堡迷城2-->
  <item package="com.zsfz.ljfdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙卷风大作战-->
  <item package="com.tencent.tmgp.coslegend" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.csdj.motojsmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--城市摩托车驾驶-->
  <item package="com.wb.wmch.nearme.gamecenter" rateId="3-1-2-3" />  <!--完美重合-->
  <item package="com.pdragon.aa.nearme.gamecenter" rateId="3-1-2-3" />  <!--见缝插针-->
  <item package="so.wz.qius.nearme.gamecenter" rateId="3-1-2-3" />  <!--火线突击之热血反恐-->
  <item package="com.ttx5.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天炫舞-->
  <item package="zzyxzc.cjzzx.nearme.gamecenter" rateId="3-1-2-3" />  <!--蜘蛛英雄战场-->
  <item package="com.igame.hllbnc.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐萝卜农场-->
  <item package="com.sg.bjxgs.nearme.gamecenter" rateId="3-1-2-3" />  <!--奥特曼超人-->
  <item package="com.shouxin.hwby.nearme.gamecenter" rateId="3-1-2-3" />  <!--海王捕鱼-->
  <item package="com.tencent.everadventure" rateId="3-1-2-3" />  <!--无尽远征-->
  <item package="com.joym.armorbloodwar.nearme.gamecenter" rateId="3-1-2-3" />  <!--铠甲勇士热血战神-->
  <item package="com.funcity.carsbattletwo" rateId="3-1-2-3" />  <!--求生之王-->
  <item package="wdmn.sjqig.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的迷你世界-->
  <item package="com.zcsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--吃鸡战场生存-->
  <item package="com.igames.qmlcbs.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民列车比赛-->
  <item package="com.libii.libbyunicorn.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主梦幻独角兽-->
  <item package="com.longlangyx.hcrzzsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人战争：世界-->
  <item package="com.dc01.nearme.gamecenter" rateId="3-1-2-3" />  <!--九州飞凰录-->
  <item package="com.whmd.lkfy.nearme.gamecenter" rateId="3-1-2-3" />  <!--猎空风云-->
  <item package="com.wb.gddsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--滚动的世界-->
  <item package="com.duole.paohuzihd.nearme.gamecenter" rateId="3-1-2-3" />  <!--多乐跑胡子-->
  <item package="com.mycomp.cwjd.nearme.gamecenter" rateId="3-1-2-3" />  <!--宠物基地-->
  <item package="com.zwyx.tkzm.nearme.gamecenter" rateId="3-1-2-3" />  <!--天空之门-->
  <item package="com.zwtx.hjatcr.nearme.gamecenter" rateId="3-1-2-3" />  <!--合金奥特超人-->
  <item package="com.whmd.jcsdtw.nearme.gamecenter" rateId="3-1-2-3" />  <!--巨齿鲨大逃亡-->
  <item package="com.liuguan.xdfc.nearme.gamecenter" rateId="3-1-2-3" />  <!--炫动飞车-->
  <item package="com.mfkj.xxdfm.nearme.gamecenter" rateId="3-1-2-3" />  <!--小熊的蜂蜜-->
  <item package="com.galasports.basketball.nearme.gamecenter" rateId="3-1-2-3" />  <!--NBA篮球大师：最强王者-->
  <item package="com.wb.lxgs.nearme.gamecenter" rateId="3-1-2-3" />  <!--连线高手-->
  <item package="org.islq.move2048" rateId="3-1-2-3" />  <!--天天2048-->
  <item package="com.zsfz.hcrxdyx.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人侠盗英雄-->
  <item package="com.MXW.SCSCCZC.nearme.gamecenter" rateId="3-1-2-3" />  <!--赛车赛车-->
  <item package="com.yunbu.differences.nearme.gamecenter" rateId="3-1-2-3" />  <!--找茬高高手-->
  <item package="com.libii.libbycarnival.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主狂欢嘉年华-->
  <item package="com.xinyi.mori.nearme.gamecenter" rateId="3-1-2-3" />  <!--末日机甲风暴之霹雳对战-->
  <item package="com.zsfz.czczsmn.mfgame.nearme.gamecenter" rateId="3-1-2-3" />  <!--极品飙车-->
  <item package="com.zhuzhuxia.kuaipao.nearme.gamecenter" rateId="3-1-2-3" />  <!--猪猪侠快跑-->
  <item package="zombie.survival.craft.z" rateId="3-1-2-3" />  <!--地球末日生存-->
  <item package="com.qyj.net.nearme.gamecenter" rateId="3-1-2-3" />  <!--青云诀-->
  <item package="com.igame.cjfff.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级翻翻翻-->
  <item package="com.bf.HuoPinShuangKou.nearme.gamecenter" rateId="3-1-2-3" />  <!--火拼双扣-->
  <item package="pl.idreams.pottery.oppo" rateId="3-1-2-3" />  <!--一起玩陶艺-->
  <item package="gjssjdzz.gjssj.nearme.gamecenter" rateId="3-1-2-3" />  <!--弓箭手射箭大作战-->
  <item package="com.tencent.tmgp.wesix" rateId="3-1-2-3" />  <!--消除者联盟-->
  <item package="com.wedobest.llk.nearme.gamecenter" rateId="3-1-2-3" />  <!--连连看-->
  <item package="com.libii.furrypetsalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--毛绒宠物美容院-->
  <item package="com.libii.winterparty.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主之冰雪派对-->
  <item package="com.youmeng.aotekuaipao.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血奥特超人快跑-->
  <item package="com.zsfz.gjc3dmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--公交车3D模拟-->
  <item package="com.kunpo.travelstring.jrtt" rateId="3-1-2-3" />  <!--旅行串串-->
  <item package="com.mars.ssjjqlsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--神兽金刚青龙射击-->
  <item package="com.saiyun.qpbylwb.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼欢乐颂-->
  <item package="com.wepie.snake" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.kunqi.dywz.nearme.gamecenter" rateId="3-1-2-3" />  <!--钓鱼王者-->
  <item package="com.feamber.racing4.oppo" rateId="3-1-2-3" />  <!--猪猪侠百变飞车-->
  <item package="com.vectorunit.redcmgeplaycn" rateId="3-1-2-3" />  <!--激流快艇2-->
  <item package="com.jd.game.fruitsmasher.nearme.gamecenter" rateId="3-1-2-3" />  <!--水果消除-->
  <item package="com.tencent.tapenjoy.actx" rateId="3-1-2-3" />  <!--魂武者-->
  <item package="com.tomato.joy.hxdzjl.nearme.gamecenter" rateId="3-1-2-3" />  <!--红心大战接龙-->
  <item package="com.yr.yxsrs.nearme.gamecenter" rateId="3-1-2-3" />  <!--希望之村-->
  <item package="com.netease.ma71.nearme.gamecenter" rateId="3-1-2-3" />  <!--边境之旅-->
  <item package="com.tencent.tmgp.ddtank" rateId="3-1-2-3" />  <!--弹弹堂-->
  <item package="com.ggyx.hcrxzdg.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人勋章帝国-->
  <item package="com.huoshe.cjpkx.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级跑酷侠-->
  <item package="com.mytx.hcgtrqz.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴钢铁人枪战3D-->
  <item package="com.tongcn.ymmbpb.nearme.gamecenter" rateId="3-1-2-3" />  <!--羊咩咩奔跑吧-->
  <item package="com.quantum.ahjx.nearme.gamecenter" rateId="3-1-2-3" />  <!--暗黑觉醒-->
  <item package="com.fingertip.saolei.nearme.gamecenter" rateId="3-1-2-3" />  <!--扫雷世界-->
  <item package="com.fhxj.hardtime.nearme.gamecenter" rateId="3-1-2-3" />  <!--凤凰心计-->
  <item package="com.joygame.fish2.nearme.gamecenter" rateId="3-1-2-3" />  <!--金手指捕鱼-->
  <item package="com.djinnworks.StickmanBasketball.oppo" rateId="3-1-2-3" />  <!--火柴人篮球-->
  <item package="com.zhangdong.dolls.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐娃娃机-->
  <item package="com.joypac.kaihi3.nearme.gamecenter" rateId="3-1-2-3" />  <!--神回避3-->
  <item package="com.mfkj.shtyt.nearme.gamecenter" rateId="3-1-2-3" />  <!--深海探一探-->
  <item package="com.yunbu.mermaidprincess.nearme.gamecenter" rateId="3-1-2-3" />  <!--人鱼公主美妆秀-->
  <item package="com.mfkj.cltg.nearme.gamecenter" rateId="3-1-2-3" />  <!--初恋糖果-->
  <item package="com.forgame.mmxd.nearme.gamecenter" rateId="3-1-2-3" />  <!--美美小店-->
  <item package="com.igame.ozkc.nearme.gamecenter" rateId="3-1-2-3" />  <!--欧洲卡车-->
  <item package="com.hlys.hcrgd.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人格斗-->
  <item package="com.mfkj.jsqs.nearme.gamecenter" rateId="3-1-2-3" />  <!--急速轻松躲避-->
  <item package="com.dingogames.tastyplanet1lite" rateId="3-1-2-3" />  <!--美味星球-->
  <item package="com.mars.bx.nearme.gamecenter" rateId="3-1-2-3" />  <!--神兽金刚3变形-->
  <item package="org.cocos2d.jdqs2.nearme.gamecenter" rateId="3-1-2-3" />  <!--和王老汉一起攻克难关-->
  <item package="com.jiayi.mxcq.nearme.gamecenter" rateId="3-1-2-3" />  <!--冒险传奇-->
  <item package="com.zsfz.bxjqs3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形机器鲨3D-->
  <item package="com.xxhy.pokemon.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔王乱入-->
  <item package="com.zsfz.sxslj.nearme.gamecenter" rateId="3-1-2-3" />  <!--水下狩猎季-->
  <item package="com.zulong.nine.nearme.gamecenter" rateId="3-1-2-3" />  <!--九州天空城3D-->
  <item package="com.miragine.MiragineWar.nearme.gamecenter" rateId="3-1-2-3" />  <!--米拉奇战记-->
  <item package="com.t2ksports.nba2k15android" rateId="3-1-2-3" />  <!--NBA2K15直装版-->
  <item package="com.stickman.Stickman.nearme.gamecenter" rateId="3-1-2-3" />  <!--怒怼火柴人-->
  <item package="com.yunbu.girlmagicmakeup.nearme.gamecenter" rateId="3-1-2-3" />  <!--美少女魔法美妆-->
  <item package="com.martian.RoomEscape13.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱13秘密任务-->
  <item package="com.tencent.tmgp.dragonball" rateId="3-1-2-3" />  <!--龙珠激斗（七龙珠正版手游）-->
  <item package="com.libii.candytoystore.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖糖玩具店-->
  <item package="com.dlmqfqt.net.nearme.gamecenter" rateId="3-1-2-3" />  <!--麻雀飞青天-->
  <item package="com.libii.candymakeup.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖果美妆派对-->
  <item package="com.jg.cqjy.nearme.gamecenter" rateId="3-1-2-3" />  <!--斩月屠龙-->
  <item package="com.yh.nxzsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--虐心直升机-->
  <item package="com.melestudio.PenRun.nearme.gamecenter" rateId="3-1-2-3" />  <!--奔跑吧铅笔-->
  <item package="com.tencent.tmgp.ylm" rateId="3-1-2-3" />  <!--御龙在天-->
  <item package="com.yh.zjdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--空中蹦蹦跳-->
  <item package="com.mars.ssjghyjg.nearme.gamecenter" rateId="3-1-2-3" />  <!--神兽金刚3幻影金刚-->
  <item package="com.liuguan.TMSXHC.nearme.gamecenter.nearme.gamecenter" rateId="3-1-2-3" />  <!--赛车向前冲-->
  <item package="net.crimoon.pm.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血精灵王-->
  <item package="com.melestudio.PixelArtClassic.nearme.gamecenter" rateId="3-1-2-3" />  <!--数字填色像素涂色-->
  <item package="mzgz.bxqy.nearme.gamecenter" rateId="3-1-2-3" />  <!--云想衣裳-->
  <item package="com.rxsjfx.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--热血神剑-->
  <item package="com.zsfz.jbxpg3.nearme.gamecenter" rateId="3-1-2-3" />  <!--击爆小苹果-->
  <item package="air.com.oranginalplan.weaphonesvol2" rateId="3-1-2-3" />  <!--真实武器模拟2（weaphones）-->
  <item package="com.yunbu.schoolrockstar.nearme.gamecenter" rateId="3-1-2-3" />  <!--高中乐队明星-->
  <item package="cn.ultralisk.game39.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔幻陀螺3刺激对战-->
  <item package="com.jy.mj.hzmj.nearme.gamecenter" rateId="3-1-2-3" />  <!--来打红中麻将-->
  <item package="com.k7game.app.shuangkou.nearme.gamecenter" rateId="3-1-2-3" />  <!--双扣-->
  <item package="com.brdj.hyzl.nearme.gamecenter" rateId="3-1-2-3" />  <!--回忆之旅-->
  <item package="com.syxx.mfzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔法蜘蛛（重名）-->
  <item package="com.qrgame.xscczc.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素赛车战场-->
  <item package="com.yqsby.nearme.gamecenter" rateId="3-1-2-3" />  <!--摇钱树捕鱼-->
  <item package="com.zqhs.glcjjs.nearme.gamecenter" rateId="3-1-2-3" />  <!--公路超级竞赛-->
  <item package="com.cqwx.dsbc.nearme.gamecenter" rateId="3-1-2-3" />  <!--登山飙车-->
  <item package="com.xt.tytjdb.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳一跳口袋版-->
  <item package="com.thankcreate.NormalAdventure" rateId="3-1-2-3" />  <!--正常的大冒险-->
  <item package="com.tapblaze.pizzabusiness" rateId="3-1-2-3" />  <!--美味的披萨-->
  <item package="com.ball3d.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--翻滚球球-->
  <item package="com.huoshe.cjwxg.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级外星狗-->
  <item package="com.libii.promqueen" rateId="3-1-2-3" />  <!--校园舞会之浪漫约会夜-->
  <item package="com.snailgames.mydinosaur.nearme.gamecenter" rateId="3-1-2-3" />  <!--我的恐龙-->
  <item package="com.mars.twddy.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳舞的电音-->
  <item package="com.yw.jykl.nearme.gamecenter" rateId="3-1-2-3" />  <!--救援恐龙-->
  <item package="com.diyibo.snmj.nearme.gamecenter" rateId="3-1-2-3" />  <!--少年名将-->
  <item package="com.volvapps.ef5.x.nearme.gamecenter" rateId="3-1-2-3" />  <!--空战争锋-->
  <item package="com.eyesthegame.eyes" rateId="3-1-2-3" />  <!--恐怖之眼-->
  <item package="com.netease.avgqv.nearme.gamecenter" rateId="3-1-2-3" />  <!--失忆偶像出道中-->
  <item package="com.leyo.mxsg.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦想三国之勇往直击-->
  <item package="com.shandagames.falloutshelter.nearme.gamecenter" rateId="3-1-2-3" />  <!--辐射避难所-->
  <item package="com.zsfz.bxjqfl3d.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形机器飞龙3D-->
  <item package="com.walle.roadextreme.nearme.gamecenter" rateId="3-1-2-3" />  <!--公路极速-->
  <item package="com.zsfz.xfc3dmn.nearme.gamecenter" rateId="3-1-2-3" />  <!--消防车3D模拟-->
  <item package="com.mfkj.ldzjjh.nearme.gamecenter" rateId="3-1-2-3" />  <!--雷电战机-进化-->
  <item package="com.lywx.tdqq.nearme.gamecenter" rateId="3-1-2-3" />  <!--跳动的球球-->
  <item package="com.maichi.mcdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--萌宠大作战-->
  <item package="com.mf.igame.hjqst.nearme.gamecenter" rateId="3-1-2-3" />  <!--幻姬骑士团-->
  <item package="com.daqu.qmbfmt.OPPO.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民暴风摩托-->
  <item package="aj.dedg.gredfss.nearme.gamecenter" rateId="3-1-2-3" />  <!--棍子英雄联盟-->
  <item package="com.szgd.GGBondrunning.nearme.gamecenter" rateId="3-1-2-3" />  <!--猪猪侠向前冲-->
  <item package="com.rzmlb.nearme.gamecenter" rateId="3-1-2-3" />  <!--忍者大乱斗高爆版-->
  <item package="com.zongyi.colorelax.nearme.gamecenter" rateId="3-1-2-3" />  <!--涂色大师-->
  <item package="com.youguo.blocks.nearme.gamecenter" rateId="3-1-2-3" />  <!--被尘封的故事-->
  <item package="com.zsfz.jsyx.nearme.gamecenter" rateId="3-1-2-3" />  <!--僵尸游戏-->
  <item package="cn.ultralisk.gameapp.game09.nearme.gamecenter" rateId="3-1-2-3" />  <!--巴啦啦魔法变身3-->
  <item package="com.GreatLiu.TeachingFeeling" rateId="3-1-2-3" />  <!--与奴隶的生活汉化版-->
  <item package="com.nekki.shadowfight3" rateId="3-1-2-3" />  <!--ShadowFight3-->
  <item package="com.pdragon.tshy.nearme.gamecenter" rateId="3-1-2-3" />  <!--涂色花园-->
  <item package="com.zsfz.zwnzjsw3.nearme.gamecenter" rateId="3-1-2-3" />  <!--植物怒战僵尸王-->
  <item package="com.kamitu.drawsth.standalone.free.android" rateId="3-1-2-3" />  <!--疯狂猜成语-->
  <item package="com.tencent.tmgp.tcg" rateId="3-1-2-3" />  <!--贪吃小怪物-->
  <item package="com.igame.yhsc.nearme.gamecenter" rateId="3-1-2-3" />  <!--银河赛车-->
  <item package="com.gzyr.ksdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--考试大作战-->
  <item package="com.jd.game.piperoll.nearme.gamecenter" rateId="3-1-2-3" />  <!--宝宝开心接水管-->
  <item package="com.heitao.yhdzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--约战:精灵再临-->
  <item package="com.zsfz.ncmn3d.mfgame.nearme.gamecenter" rateId="3-1-2-3" />  <!--我消你蔬菜-->
  <item package="com.cqwx.hcrss.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人射手-->
  <item package="com.huoshe.hsdmx.nearme.gamecenter" rateId="3-1-2-3" />  <!--皇室大冒险-->
  <item package="com.fazbro.army.nearme.gamecenter" rateId="3-1-2-3" />  <!--反恐突击队：模拟武装运输-->
  <item package="com.tencent.zqry2018" rateId="3-1-2-3" />  <!--全民冠军足球-->
  <item package="com.wedobest.puzzlebubble.nearme.gamecenter" rateId="3-1-2-3" />  <!--泡泡龙消消乐-->
  <item package="com.taome.jjr.nearme.gamecenter" rateId="3-1-2-3" />  <!--一直奔向月-->
  <item package="com.yzy.hlqqwxcj.OPPO.nearme.gamecenter" rateId="3-1-2-3" />  <!--欢乐球球无限冲击-->
  <item package="com.mingya.hillclimbracing.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实山地越野：4X4拉力赛-->
  <item package="com.slbhrycslsm.efun.nearme.gamecenter" rateId="3-1-2-3" />  <!--冰火人勇闯森林神庙-->
  <item package="com.leyo.gbtg.nearme.gamecenter" rateId="3-1-2-3" />  <!--果宝特攻4热血机甲王-->
  <item package="com.tencent.tmgp.cysgj" rateId="3-1-2-3" />  <!--成语小秀才-->
  <item package="com.wuyaogamer.zhuzhuxiack.nearme.gamecenter" rateId="3-1-2-3" />  <!--猪猪侠机甲王-->
  <item package="com.mfgame.qll.nearme.gamecenter" rateId="3-1-2-3" />  <!--墙来了-->
  <item package="com.zsfz.ppdr.nearme.gamecenter" rateId="3-1-2-3" />  <!--跑跑达人-->
  <item package="com.mfkj.xhc.nearme.gamecenter" rateId="3-1-2-3" />  <!--小火车:开始比赛-->
  <item package="com.bjjy.mfzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔法蜘蛛-->
  <item package="com.mf.igame.fhzcj.nearme.gamecenter" rateId="3-1-2-3" />  <!--凤凰座出击-->
  <item package="com.wali.xmcs.nearme.gamecenter" rateId="3-1-2-3" />  <!--小米超神-->
  <item package="com.idreamsky.mekorama.nearme.gamecenter" rateId="3-1-2-3" />  <!--机械迷宫-->
  <item package="com.fourddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--四人斗地主-->
  <item package="com.hugenstar.jjjt.nearme.gamecenter" rateId="3-1-2-3" />  <!--机甲军团-->
  <item package="xjyll.yypk.nearme.gamecenter" rateId="3-1-2-3" />  <!--叶罗丽跑酷天团-->
  <item package="com.herotower.jrtt" rateId="3-1-2-3" />  <!--火枪英雄-->
  <item package="cn.ultralisk.gameapp.game17.nearme.gamecenter" rateId="3-1-2-3" />  <!--叶罗丽美甲梦-->
  <item package="com.baile.fish.nearme.gamecenter" rateId="3-1-2-3" />  <!--百乐捕鱼-->
  <item package="com.libii.christmashairsalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--圣诞美发屋-->
  <item package="com.jsys.nearme.gamecenter" rateId="3-1-2-3" />  <!--金鲨银鲨-->
  <item package="com.tencent.tmgp.kof98" rateId="3-1-2-3" />  <!--拳皇98终极之战-OL-->
  <item package="com.whjf.bbprs.nearme.gamecenter" rateId="3-1-2-3" />  <!--宝宝烹饪师-->
  <item package="com.tencent.tmgp.bh3" rateId="3-1-2-3" />  <!--\N-->
  <item package="com.zplay.ClashTank.nearme.gamecenter" rateId="3-1-2-3" />  <!--王牌大作战-->
  <item package="com.zazz.wandou.nearme.gamecenter" rateId="3-1-2-3" />  <!--豌豆大作战-->
  <item package="com.regexsoft.cruiseshipsimulator.nearme.gamecenter" rateId="3-1-2-3" />  <!--3D游轮驾驶模拟器-->
  <item package="com.tomato.joy.cjdyx.nearme.gamecenter" rateId="3-1-2-3" />  <!--吃鸡大英雄-->
  <item package="com.libii.talentedpetsshow" rateId="3-1-2-3" />  <!--天才宠物秀-->
  <item package="com.tencent.tmgp.ffom" rateId="3-1-2-3" />  <!--自由幻想-->
  <item package="com.hysjdxb.nearme.gamecenter" rateId="3-1-2-3" />  <!--海洋世界大寻宝-->
  <item package="com.ythk.bxjg.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形机器金刚-->
  <item package="com.martian.RoomEscape15.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱15神秘宫殿-->
  <item package="com.xlcw.hxct.mgdd.nearme.gamecenter" rateId="3-1-2-3" />  <!--火线冲突-->
  <item package="com.migame.kxddz.nearme.gamecenter" rateId="3-1-2-3" />  <!--开心斗地主-->
  <item package="com.FourFire.InfiniteSoul" rateId="3-1-2-3" />  <!--无尽之魂-->
  <item package="com.xf.lywz.nearme.gamecenter" rateId="3-1-2-3" />  <!--烈焰武尊-->
  <item package="com.jym.zszsj.nearme.gamecenter" rateId="3-1-2-3" />  <!--真实直升机-->
  <item package="com.yuhong.jbkb.nearme.gamecenter" rateId="3-1-2-3" />  <!--劲爆狂飙-->
  <item package="com.joym.armorhero3.nearme.gamecenter" rateId="3-1-2-3" />  <!--铠甲勇士战神联盟-->
  <item package="org.cocos2dx.zmxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--造梦西游4-->
  <item package="com.xm4399.hdczjh2.nearme.gamecenter" rateId="3-1-2-3" />  <!--皇帝成长计划2-->
  <item package="com.tuyoo.fish.oppo.bydzz.nearme.gamecenter" rateId="3-1-2-3" />  <!--捕鱼大作战-->
  <item package="com.qzyx.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--枪战英雄-->
  <item package="com.njtd.catsimulator.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟猫咪-->
  <item package="com.melestudio.CrazyPixelArt.nearme.gamecenter" rateId="3-1-2-3" />  <!--像素画画-->
  <item package="com.whmd.qmsjlm.nearme.gamecenter" rateId="3-1-2-3" />  <!--全民射击联盟-->
  <item package="com.zzonegame.aresvirus.nearme.gamecenter" rateId="3-1-2-3" />  <!--阿瑞斯病毒-->
  <item package="com.leyo.cjfx3.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级飞侠4缤纷乐园-->
  <item package="com.thinkygame.android.tank.hot1.oppo.nearme.gamecenter" rateId="3-1-2-3" />  <!--坦克雄心-->
  <item package="com.shandagames.mygj.nearme.gamecenter" rateId="3-1-2-3" />  <!--命运歌姬-->
  <item package="com.libii.fashionmall.nearme.gamecenter" rateId="3-1-2-3" />  <!--时尚购物商场-->
  <item package="com.lingmeng.oneline.nearme.gamecenter" rateId="3-1-2-3" />  <!--解谜一笔画-->
  <item package="main.opalyer" rateId="3-1-2-3" />  <!--橙光游戏-->
  <item package="com.bxfr.union.keke.nearme.gamecenter" rateId="3-1-2-3" />  <!--御剑修仙-->
  <item package="com.orange.org_player_new_alone748794.nearme.gamecenter" rateId="3-1-2-3" />  <!--我做夫人那些年-->
  <item package="com.tencent.tmgp.mhzxsy" rateId="3-1-2-3" />  <!--梦幻诛仙-->
  <item package="com.netease.ma59.nearme.gamecenter" rateId="3-1-2-3" />  <!--劲舞时代-->
  <item package="catobyte.superbunnyman" rateId="3-1-2-3" />  <!--超级兔子人-->
  <item package="com.mykdb.nearme.gamecenter" rateId="3-1-2-3" />  <!--魔域口袋版-->
  <item package="com.yzxx.zdxsjjzc.nearme.gamecenter" rateId="3-1-2-3" />  <!--子弹先生狙击战场-->
  <item package="com.zsfz.bxjqk.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形机器鲲-->
  <item package="com.yunbu.magicgarden.nearme.gamecenter" rateId="3-1-2-3" />  <!--花花姑娘之魔法花园-->
  <item package="com.ximigame.pengyouju" rateId="3-1-2-3" />  <!--朋友局-->
  <item package="com.q1.YZSY.android.nearme.gamecenter" rateId="3-1-2-3" />  <!--远征手游-->
  <item package="com.igame.cjzzr.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级蜘蛛人-->
  <item package="com.nnsdk.nnlczg.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙城战歌-->
  <item package="com.whmd.klsp.nearme.gamecenter" rateId="3-1-2-3" />  <!--快乐赛跑-->
  <item package="com.tcg.leon" rateId="3-1-2-3" />  <!--危鸡之夜-->
  <item package="com.tencent.tmgp.tmsk.qj2" rateId="3-1-2-3" />  <!--奇迹：觉醒-->
  <item package="com.martian.dm100.nearme.gamecenter" rateId="3-1-2-3" />  <!--100道神秘的门-->
  <item package="com.libii.cheffrance.nearme.gamecenter" rateId="3-1-2-3" />  <!--美食兄妹之法国餐厅-->
  <item package="com.libii.princessvacation.nearme.gamecenter" rateId="3-1-2-3" />  <!--莉比小公主的假期之环游世界-->
  <item package="it.uniud.hcilab.prepareforimpact" rateId="3-1-2-3" />  <!--PrepareforImpact-->
  <item package="com.realcreator.human" rateId="3-1-2-3" />  <!--人类一败涂地-->
  <item package="com.yymoon.LunaCNY" rateId="3-1-2-3" />  <!--干物少女-->
  <item package="com.Lxd.DargonWarriorRace.nearme.gamecenter" rateId="3-1-2-3" />  <!--超级飞侠之荒野大冒险-->
  <item package="com.youping.libi" rateId="3-1-2-3" />  <!--莉比公主时尚美甲-->
  <item package="com.martian.sgjjl.nearme.gamecenter" rateId="3-1-2-3" />  <!--水管接接乐-->
  <item package="com.ipeaksoft.keng16.nearme.gamecenter" rateId="3-1-2-3" />  <!--史上最坑爹的游戏16-->
  <item package="com.tomato.joy.mycs.nearme.gamecenter" rateId="3-1-2-3" />  <!--魅影车手-->
  <item package="com.tzy.jssc.nearme.gamecenter" rateId="3-1-2-3" />  <!--急速赛车-->
  <item package="com.popcap.pvzthird" rateId="3-1-2-3" />  <!--\N-->
  <item package="fly.sesgagames.mostafa_dragons2" rateId="3-1-2-3" />  <!--mostafafightdragon-->
  <item package="cn.flytalk.shudu" rateId="3-1-2-3" />  <!--全民数独-->
  <item package="com.nekki.shadowfight" rateId="3-1-2-3" />  <!--ShadowFight2-->
  <item package="com.zsfz.sxslj3.nearme.gamecenter" rateId="3-1-2-3" />  <!--水下狩猎季-->
  <item package="com.pld.shikongfeiche.nearme.gamecenter" rateId="3-1-2-3" />  <!--失控飞车-->
  <item package="com.hxyt.jpkyfc.OPPO.nearme.gamecenter" rateId="3-1-2-3" />  <!--狂野极品飞车-->
  <item package="com.yunbu.restauranttycoon.cake.nearme.gamecenter" rateId="3-1-2-3" />  <!--梦想蛋糕屋-->
  <item package="com.libii.candyhotel.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖糖假日-海滨酒店-->
  <item package="com.rcflightsim.cvplane2" rateId="3-1-2-3" />  <!--模拟遥控飞机-->
  <item package="com.yinhu.sdk.shcb.nearme.gamecenter" rateId="3-1-2-3" />  <!--守护大作战-->
  <item package="com.E8game.findcat2.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天躲猫猫2-->
  <item package="com.yifeng.battlesnake.nearme.gamecenter" rateId="3-1-2-3" />  <!--贪吃蛇蛇争霸-->
  <item package="xbh.ghbxtx.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形战车-突袭-->
  <item package="com.lsdj.Qqdazhan.nearme.gamecenter" rateId="3-1-2-3" />  <!--球球大战-->
  <item package="com.quduoduo.babysitter.nearme.gamecenter" rateId="3-1-2-3" />  <!--照顾宝宝-->
  <item package="com.melestudio.PonyPetSalon.nearme.gamecenter" rateId="3-1-2-3" />  <!--独角兽宝莉-->
  <item package="com.miniclip.angerofstick2.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人突击格斗-->
  <item package="com.mlfhsbz.nearme.gamecenter" rateId="3-1-2-3" />  <!--烽火十八州-->
  <item package="com.zfkzk.yhlm.nearme.gamecenter" rateId="3-1-2-3" />  <!--飓风空战队-->
  <item package="com.ttbn.ximao.opl.nearme.gamecenter" rateId="3-1-2-3" />  <!--天天捕鸟-->
  <item package="com.martian.RoomEscape21.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱21遗落梦境-->
  <item package="com.igame.ljfdld.nearme.gamecenter" rateId="3-1-2-3" />  <!--龙卷风大乱斗-->
  <item package="com.mingya.truckmaster.nearme.gamecenter" rateId="3-1-2-3" />  <!--模拟卡车大师-->
  <item package="com.joym.armorhero.oppo" rateId="3-1-2-3" />  <!--铠甲勇士之英雄传说-->
  <item package="com.martian.RoomEscape24.nearme.gamecenter" rateId="3-1-2-3" />  <!--密室逃脱24末日危机-->
  <item package="com.jd.game.jewelscrush.nearme.gamecenter" rateId="3-1-2-3" />  <!--宝石消灭-->
  <item package="com.baitian.szx.ywq.nearme.gamecenter" rateId="3-1-2-3" />  <!--螺旋圆舞曲-->
  <item package="com.shouxin.hbqq.nearme.gamecenter" rateId="3-1-2-3" />  <!--火爆球球-->
  <item package="com.sxiaoao.moto3dOnline" rateId="3-1-2-3" />  <!--3D摩托飞车-->
  <item package="com.qrgame.bxcr.nearme.gamecenter" rateId="3-1-2-3" />  <!--变形超人-->
  <item package="com.duoyi.m2csm.nearme.gamecenter" rateId="3-1-2-3" />  <!--传送门骑士-->
  <item package="com.tencent.tmgp.mff" rateId="3-1-2-3" />  <!--漫威:未来之战-->
  <item package="com.tuyoo.gomoku.nearme.gamecenter" rateId="3-1-2-3" />  <!--途游五子棋-->
  <item package="cn.ultralisk.game29.nearme.gamecenter" rateId="3-1-2-3" />  <!--爆兽猎人之龙魂觉醒-->
  <item package="com.fhgc.cq.nearme.gamecenter" rateId="3-1-2-3" />  <!--烽火攻城-->
  <item package="cn.ultralisk.gameapp.game31.nearme.gamecenter" rateId="3-1-2-3" />  <!--小花仙守护天使-->
  <item package="com.jd.game.candyfrenzy.nearme.gamecenter" rateId="3-1-2-3" />  <!--糖果天天消-->
  <item package="com.cbzj.nearme.gamecenter" rateId="3-1-2-3" />  <!--潮爆战纪-->
  <item package="com.candyrufusgames.survivalcrafttrial" rateId="3-1-2-3" />  <!--孤岛求生-->
  <item package="com.cqwx.hcrzb.nearme.gamecenter" rateId="3-1-2-3" />  <!--火柴人争霸-->
  <item package="com.tencent.tmgp.p2y9y.yujianxy.nearme.gamecenter" rateId="3-1-2-3" />  <!--御剑仙缘-->
  <item package="com.lqs.kaisi.bill.nearme.gamecenter" rateId="3-1-2-3" />  <!--2D桌球单机游戏-->
  <item package="com.ss.android.article.video" rateId="3-1-2-3"  lowfreq="true" />  <!--西瓜视频-->
  <item package="com.duowan.kiwi" rateId="3-1-2-3" />  <!--虎牙直播-->
  <item package="air.tv.douyu.android" rateId="3-1-2-3" />  <!--斗鱼直播-->
  <item package="com.duowan.mobile" rateId="3-1-2-3" />  <!--YY-->
  <item package="com.youku.phone" rateId="3-1-2-3"  lowfreq="true" />  <!--优酷视频-->
  <item package="com.smile.gifmaker" rateId="3-1-2-3" />  <!--快手-->
  <item package="com.ss.android.ugc.aweme.lite" rateId="3-1-2-3" />  <!--抖音极速版-->
  <item package="com.kuaishou.nebula" rateId="3-1-2-3" />  <!--快手极速版-->
  <item package="com.tencent.weishi" rateId="3-1-2-3" />  <!--微视-->

<!--Start High rate(120/90) oversea's app-->
  <item package="com.UCMobile.intl" rateId="3-1-2-3" disableViewOverride="false"  />
<!--start 60hz black app-->
  <item package="com.mxtech.videoplayer.ad" rateId="3-1-2-3" /><!--MX Player-->
  <item package="com.lazygeniouz.saveit" rateId="3-1-2-3" />
  <item package="org.videolan.vlc" rateId="3-1-2-3" />
  <item package=" com.zhiliaoapp.musically" rateId="3-1-2-3" /> <!--TikTok-->
  <item package="com.dev.hd.live.channel" rateId="3-1-2-3" /> <!--外国电视(HD Tv Live)-->
  <item package="com.google.android.apps.photos" rateId="3-1-2-3" />  <!--Google Photos-->
  <item package="com.sec.android.gallery3d" rateId="3-1-2-3" />  <!--Samsung Gallery-->
  <item package="com.motorola.camera" rateId="3-1-2-3" />  <!--Motorola Camera-->
  <item package="com.motorola.cameraone" rateId="3-1-2-3" />  <!--Moto Camera-->
  <item package="com.perfectcam.photoeditor" rateId="3-1-2-3" />  <!--YouCam Perfect - Best Selfie Camera & Photo Editor-->
  <item package="com.alensw.PicFolder" rateId="3-1-2-3" />  <!--QuickPic - Photo Gallery with Google Drive Support-->
  <item package="com.sonyericsson.album" rateId="3-1-2-3" />  <!--Album-->
  <item package="com.niksoftware.snapseed" rateId="3-1-2-3" />  <!--Snapseed-->
  <item package="com.linecorp.b612.android" rateId="3-1-2-3" />  <!--B612 - Beauty & Filter Camera-->
  <item package="com.commsource.beautyplus" rateId="3-1-2-3" />  <!--BeautyPlus - Easy Photo Editor & Selfie Camera-->
  <item package="com.google.android.GoogleCamera" rateId="3-1-2-3" />  <!--Google Camera-->
  <item package="com.venticake.retrica" rateId="3-1-2-3" />  <!--Retrica-->
  <item package="com.oneplus.gallery" rateId="3-1-2-3" />  <!--OnePlus Gallery-->
  <item package="com.camerasideas.instashot" rateId="3-1-2-3" />  <!--Video Editor & Video Maker - InShot-->
  <item package="com.cam001.selfie" rateId="3-1-2-3" />  <!--Sweet Selfie Camera:Beauty cam,photo&selfie editor-->
  <item package="com.asus.gallery" rateId="3-1-2-3" />  <!--ASUS Gallery-->
  <item package="com.mobsnake.verticalgallery" rateId="3-1-2-3" />  <!--Vertical Gallery-->
  <item package="makeupworld.selfiecamera.makeup.youcam.beautycamera.photoeditor.makeupcamera" rateId="3-1-2-3" />  <!--YouCam Makeup-Magic Selfie Cam & Virtual Makeovers-->
  <item package="com.roidapp.photogrid" rateId="3-1-2-3" />  <!--PhotoGrid: Video & Pic Collage Maker, Photo Editor-->
  <item package="com.asus.camera" rateId="3-1-2-3" />  <!--ASUS PixelMaster Camera-->
  <item package="com.joeware.android.gpulumera" rateId="3-1-2-3" />  <!--Candy Camera - selfie, beauty camera, photo editor-->
  <item package="vsin.t16_funny_photo" rateId="3-1-2-3" />  <!--Photo Lab Picture Editor: face effects, art frames-->
  <item package="com.atomicadd.fotos" rateId="3-1-2-3" />  <!--A+ Gallery - Photos & Videos-->
  <item package="com.cyngn.gallerynext" rateId="3-1-2-3" />  <!--Cyanogen Gallery-->
  <item package="com.adobe.lrmobile" rateId="3-1-2-3" />  <!--Adobe Lightroom - Photo Editor & Pro Camera-->
  <item package="com.pixlr.express" rateId="3-1-2-3" />  <!--Pixlr – Free Photo Editor-->
  <item package="com.adobe.psmobile" rateId="3-1-2-3" />  <!--Adobe Photoshop Express:Photo Editor Collage Maker-->
  <item package="com.cyberlink.photodirector" rateId="3-1-2-3" />  <!--PhotoDirector Photo Editor App, Picture Editor Pro-->
  <item package="com.jimmy.photobackup" rateId="3-1-2-3" />  <!--abPhoto (photo backup)-->
  <item package="net.sourceforge.opencamera" rateId="3-1-2-3" />  <!--Open Camera-->
  <item package="com.lyrebirdstudio.montagenscolagem" rateId="3-1-2-3" />  <!--Photo Editor Collage Maker Pro: Filters & Stickers-->
  <item package="com.htc.camera2" rateId="3-1-2-3" />  <!--HTC Camera　-->
  <item package="com.instagram.boomerang" rateId="3-1-2-3" />  <!--Boomerang from Instagram-->
  <item package="io.yoba.storysaverforinsta" rateId="3-1-2-3" />  <!--Story Saver App — Stories & Highlights Downloader-->
  <item package="com.PinkbirdStudio.SelfieCam_InstaBeauty" rateId="3-1-2-3" />  <!--InstaBeauty -Makeup Selfie Cam-->
  <item package="com.iudesk.android.photo.editor" rateId="3-1-2-3" />  <!--Photo Editor-->
  <item package="com.makeup.plus.youcam.camera" rateId="3-1-2-3" />  <!--MakeupPlus - Your Own Virtual Makeup Artist-->
  <item package="com.BeautifulPictureFramesmmhd" rateId="3-1-2-3" />  <!--Piktures - Beautiful Gallery-->
  <item package="com.kii.safe" rateId="3-1-2-3" />  <!--Keepsafe Photo Vault: Hide Private Photos & Videos-->
  <item package="photocollage.photoeditor.collagemaker" rateId="3-1-2-3" />  <!--Collage Maker - Photo Editor & Photo Collage-->
  <item package="com.imaginstudio.imagetools.pixellab" rateId="3-1-2-3" />  <!--PixelLab - Text on pictures-->
  <item package="com.ufotosoft.justshot" rateId="3-1-2-3" />  <!--Sweet Face Camera - live filter, Selfie face app-->
  <item package="com.instagram.layout" rateId="3-1-2-3" />  <!--Layout from Instagram: Collage-->
  <item package="kr.co.ladybugs.fourto" rateId="3-1-2-3" />  <!--FOTO Gallery-->
  <item package="jp.co.canon.ic.cameraconnect" rateId="3-1-2-3" />  <!--Canon Camera Connect-->
  <item package="com.google.android.apps.photos.scanner" rateId="3-1-2-3" />  <!--PhotoScan by Google Photos-->
  <item package="com.handycloset.android.eraser" rateId="3-1-2-3" />  <!--Background Eraser-->
  <item package="com.magix.camera_mx" rateId="3-1-2-3" />  <!--Camera MX - Photo & Video Camera-->
  <item package="com.vsco.cam" rateId="3-1-2-3" />  <!--VSCO-->
  <item package="io.faceapp" rateId="3-1-2-3" />  <!--FaceApp-->
  <item package="kr.co.manhole.hujicam" rateId="3-1-2-3" />  <!--Huji Cam-->
  <item package="com.google.android.apps.photosgo" rateId="3-1-2-3" />  <!--Gallery Go by Google Photos-->
  <item package="photo.editor.photoeditor.photoeditorpro" rateId="3-1-2-3" />  <!--Photo Editor Pro-->
  <item package="com.newbiz.mvmaster" rateId="3-1-2-3" />  <!--MV Master - Video Status Maker-->
  <item package="nocrop.photoeditor.squarepic" rateId="3-1-2-3" />  <!--Square Pic - No Crop Photo Editor for Instagram-->
  <item package="com.lightricks.pixaloop" rateId="3-1-2-3" />  <!--Enlight Pixaloop - Photo Animator-->
  <item package="com.xprodev.cutcam" rateId="3-1-2-3" />  <!--Cut Cut - CutOut & Photo Background Editor-->
  <item package="com.motorola.MotGallery2" rateId="3-1-2-3" />  <!--Motorola Gallery-->
  <item package="com.utorrent.client" rateId="3-1-2-3" />  <!--µTorrent®- Torrent Downloader-->
  <item package="com.google.android.videos" rateId="3-1-2-3" />  <!--Google Play Movies & TV-->
  <item package="com.mxtech.videoplayer.pro" rateId="3-1-2-3" />  <!--MX Player Pro-->
  <item package="com.radio.fmradio" rateId="3-1-2-3" />  <!--FM Radio-->
  <item package="com.thinkyeah.galleryvault" rateId="3-1-2-3" />  <!--Gallery Vault - Hide Pictures And Videos-->
  <item package="com.hideitpro" rateId="3-1-2-3" />  <!--Hide Photos, Video and App Lock - Hide it Pro-->
  <item package="com.quvideo.xiaoying" rateId="3-1-2-3" />  <!--VivaVideo - Video Editor & Video Maker-->
  <item package="com.google.android.apps.youtube.mango" rateId="3-1-2-3" />  <!--YouTube Go-->
  <item package="com.delphicoder.flud" rateId="3-1-2-3" />  <!--Flud - Torrent Downloader-->
  <item package="com.leo.privatezone" rateId="3-1-2-3" />  <!--Private Zone - AppLock, Video & Photo Vault-->
  <item package="video.like" rateId="3-1-2-3" />  <!--Likee - Formerly LIKE Video-->
  <item package="com.mxtech.videoplayer.beta" rateId="3-1-2-3" />  <!--MX Player Beta-->
  <item package="com.bittorrent.client" rateId="3-1-2-3" />  <!--BitTorrent®- Torrent Downloads-->
  <item package="video.player.videoplayer" rateId="3-1-2-3" />  <!--Video Player All Format - XPlayer-->
  <item package="com.nexstreaming.app.kinemasterfree" rateId="3-1-2-3" />  <!--KineMaster - Video Editor-->
  <item package="com.htc.video" rateId="3-1-2-3" />  <!--HTC Service—Video Player-->
  <item package="com.samsung.android.videolist" rateId="3-1-2-3" />  <!--Samsung Video Library-->
  <item package="com.tdo.showbox" rateId="3-1-2-3" />  <!--ShowBox-->
  <item package="org.videolan.vlc.betav7neon" rateId="3-1-2-3" />  <!--VLC for Android beta-->
  <item package="com.popularapp.videodownloaderforinstagram" rateId="3-1-2-3" />  <!--Video Downloader - for Instagram Repost App-->
  <item package="com.google.android.apps.youtube.creator" rateId="3-1-2-3" />  <!--YouTube Studio-->
  <item package="com.uc.vmate" rateId="3-1-2-3" />  <!--VMate-->
  <item package="com.naing.mp3converter" rateId="3-1-2-3" />  <!--Video to MP3 Converter-->
  <item package="com.xvideostudio.videoeditor" rateId="3-1-2-3" />  <!--VideoShow Video Editor, Video Maker, Photo Editor-->
  <item package="secret.hide.calculator" rateId="3-1-2-3" />  <!--Private Photo, Video Locker-->
  <item package="com.huawei.himovie" rateId="3-1-2-3" />  <!--HUAWEI Video Player-->
  <item package="all.video.downloader.allvideodownloader" rateId="3-1-2-3" />  <!--All downloader 2019-->
  <item package="com.mcu.iVMS" rateId="3-1-2-3" />  <!--iVMS-4500-->
  <item package="net.seesaa.sweet_baked_pie.AB_repeater" rateId="3-1-2-3" />  <!--abVideo-->
  <item package="com.stupeflix.replay" rateId="3-1-2-3" />  <!--Quik – Free Video Editor for photos, clips, music-->
  <item package="com.cyberlink.powerdirector.DRA140225_01" rateId="3-1-2-3" />  <!--PowerDirector - Video Editor App, Best Video Maker-->
  <item package="com.funcamerastudio.videomaker" rateId="3-1-2-3" />  <!--Video Maker of Photos with Music & Video Editor-->
  <item package="com.hecorat.screenrecorder.free" rateId="3-1-2-3" />  <!--AZ Screen Recorder - No Root-->
  <item package="com.sony.tvsideview.phone" rateId="3-1-2-3" />  <!--Video & TV SideView : Remote-->
  <item package="com.hikvision.hikconnect" rateId="3-1-2-3" />  <!--Hik-Connect-->
  <item package="com.wondershare.filmorago" rateId="3-1-2-3" />  <!--FilmoraGo - Free Video Editor-->
  <item package="co.we.torrent" rateId="3-1-2-3" />  <!--WeTorrent - Torrent Downloader-->
  <item package="com.camerasideas.trimmer" rateId="3-1-2-3" />  <!--YouCut - Video Editor & Video Maker, No Watermark-->
  <item package="com.rahul.videoderbeta" rateId="3-1-2-3" />  <!--Video Downloader-->
  <item package="com.ss.android.ugc.trill" rateId="3-1-2-3" />  <!--TikTok-->
  <item package="free.video.downloader.freevideodownloader" rateId="3-1-2-3" />  <!--Free Video Downloader-->
  <item package="com.vid007.videobuddy" rateId="3-1-2-3" />  <!--VideoBuddy — Fast Downloader, Video Detector-->
  <item package="com.ss.android.ugc.trill.go" rateId="3-1-2-3" />  <!--TikTok Lite-->
  <item package="mobi.charmer.myscreenrecorder" rateId="3-1-2-3" />  <!--Screen Recorder V Recorder - Audio, Video Editor-->
  <item package="com.opex.makemyvideostatus" rateId="3-1-2-3" />  <!--Lyrical.ly - Lyrical Video Status Maker-->
  <item package="video.like.lite" rateId="3-1-2-3" />  <!--Likee Lite - Formerly LIKE Lite Video-->
  <item package="com.vidmix.app" rateId="3-1-2-3" />  <!--VidMix-->
  <item package="com.google.android.youtube" rateId="3-1-2-3" />  <!--YouTube-->
  <item package="com.king.candycrushsaga" rateId="3-1-2-3" />  <!--Candy Crush Saga-->
  <item package="com.ludo.king" rateId="3-1-2-3" />  <!--Ludo King™-->
  <item package="com.supercell.clashofclans" rateId="3-1-2-3" />  <!--Clash of Clans-->
  <item package="com.miniclip.eightballpool" rateId="3-1-2-3" />  <!--8 Ball Pool-->
  <item package="com.word.puzzle.game.connect" rateId="3-1-2-3" />  <!--Word Link-->
  <item package="com.king.candycrushsodasaga" rateId="3-1-2-3" />  <!--Candy Crush Soda Saga-->
  <item package="com.dts.freefireth" rateId="3-1-2-3" />  <!--Garena Free Fire - Anniversary-->
  <item package="com.showtimeapp" rateId="3-1-2-3" />  <!--Loco - Play Free Games, Cricket and Win!-->
  <item package="com.ansangha.drdriving" rateId="3-1-2-3" />  <!--Dr. Driving-->
  <item package="com.fortune.sim.game.cash" rateId="3-1-2-3" />  <!--Hello Stars-->
  <item package="com.supercell.clashroyale" rateId="3-1-2-3" />  <!--Clash Royale-->
  <item package="com.riseup.game" rateId="3-1-2-3" />  <!--Rise Up-->
  <item package="com.nextwave.wcc2" rateId="3-1-2-3" />  <!--World Cricket Championship 2 - WCC2-->
  <item package="io.teslatech.callbreak" rateId="3-1-2-3" />  <!--Callbreak Multiplayer-->
  <item package="com.octro.teenpatti" rateId="3-1-2-3" />  <!--Teen Patti by Octro-->
  <item package="com.jetstartgames.chess" rateId="3-1-2-3" />  <!--Chess-->
  <item package="com.fingersoft.hillclimb" rateId="3-1-2-3" />  <!--Hill Climb Racing-->
  <item package="com.wordgame.puzzle.board.en" rateId="3-1-2-3" />  <!--Word Cross-->
  <item package="com.moonactive.coinmaster" rateId="3-1-2-3" />  <!--Coin Master-->
  <item package="com.imangi.templerun" rateId="3-1-2-3" />  <!--Temple Run-->
  <item package="com.game5mobile.lineandwater" rateId="3-1-2-3" />  <!--Happy Glass-->
  <item package="com.fungames.sniper3d" rateId="3-1-2-3" />  <!--Sniper 3D Gun Shooter: Free Elite Shooting Games-->
  <item package="com.ludo.master.hippo" rateId="3-1-2-3" />  <!--Ludo Master - New Ludo Game 2019 For Free-->
  <item package="uk.co.aifactory.chessfree" rateId="3-1-2-3" />  <!--Chess Free-->
  <item package="com.h8games.helixjump" rateId="3-1-2-3" />  <!--Helix Jump-->
  <item package="com.teenpatti.hd.gold" rateId="3-1-2-3" />  <!--Teen Patti Gold - With Poker & Rummy-->
  <item package="com.outfit7.talkingtom" rateId="3-1-2-3" />  <!--Talking Tom Cat-->
  <item package="com.firsttouchgames.dls3" rateId="3-1-2-3" />  <!--Dream League Soccer-->
  <item package="com.ea.gp.fifamobile" rateId="3-1-2-3" />  <!--FIFA Soccer-->
  <item package="bubbleshooter.orig" rateId="3-1-2-3" />  <!--Bubble Shooter-->
  <item package="com.skgames.trafficrider" rateId="3-1-2-3" />  <!--Traffic Rider-->
  <item package="com.firsttouchgames.story" rateId="3-1-2-3" />  <!--Score! Hero-->
  <item package="com.igg.android.lordsmobile" rateId="3-1-2-3" />  <!--Lords Mobile: Battle of the Empires - Strategy RPG-->
  <item package="com.bitmango.rolltheballunrollme" rateId="3-1-2-3" />  <!--Roll the Ball® - slide puzzle-->
  <item package="com.supertapx.lovedots" rateId="3-1-2-3" />  <!--Love Balls-->
  <item package="com.rovio.angrybirdsrio" rateId="3-1-2-3" />  <!--Angry Birds Rio-->
  <item package="com.differencetenderwhite.skirt" rateId="3-1-2-3" />  <!--Block Puzzle Jewel-->
  <item package="com.BuddyMattEnt.ChainReaction" rateId="3-1-2-3" />  <!--Chain Reaction-->
  <item package="com.bigduckgames.flow" rateId="3-1-2-3" />  <!--Flow Free-->
  <item package="com.nautilus.RealCricket3D" rateId="3-1-2-3" />  <!--Real Cricket™ 19-->
  <item package="com.ansangha.drjb" rateId="3-1-2-3" />  <!--Dr. Driving 2-->
  <item package="jp.konami.pesam" rateId="3-1-2-3" />  <!--PES 2019 PRO EVOLUTION SOCCER-->
  <item package="com.happyadda.jalebi" rateId="3-1-2-3" />  <!--Jalebi - A Desi Adda With Ludo Snakes & Ladders-->
  <item package="com.games24x7.ultimaterummy.playstore" rateId="3-1-2-3" />  <!--Ultimate RummyCircle - Play Rummy-->
  <item package="com.brainbaazi" rateId="3-1-2-3" />  <!--Live Quiz Games App, Trivia & Gaming App for Money-->
  <item package="com.outfit7.talkingtomgoldrun" rateId="3-1-2-3" />  <!--Talking Tom Gold Run-->
  <item package="com.noodlecake.altosodyssey" rateId="3-1-2-3" />  <!--Alto's Odyssey-->
  <item package="com.aim.racing" rateId="3-1-2-3" />  <!--Extreme Car Driving Simulator-->
  <item package="com.bentostudio.ballsvsblocks" rateId="3-1-2-3" />  <!--Snake VS Block-->
  <item package="com.droidhen.game.racingmoto" rateId="3-1-2-3" />  <!--Racing Moto-->
  <item package="com.bitmango.go.wordcookies" rateId="3-1-2-3" />  <!--Word Cookies!®-->
  <item package="com.dvloper.granny" rateId="3-1-2-3" />  <!--Granny-->
  <item package="com.episodeinteractive.android.catalog" rateId="3-1-2-3" />  <!--Episode - Choose Your Story-->
  <item package="com.playrix.township" rateId="3-1-2-3" />  <!--Township-->
  <item package="com.playgendary.kickthebuddy" rateId="3-1-2-3" />  <!--Kick the Buddy-->
  <item package="com.gta.real.gangster.crime" rateId="3-1-2-3" />  <!--Real Gangster Crime-->
  <item package="com.ketchapp.knifehit" rateId="3-1-2-3" />  <!--Knife Hit-->
  <item package="badminton.king.sportsgame.smash" rateId="3-1-2-3" />  <!--Badminton League-->
  <item package="com.miniclip.archery" rateId="3-1-2-3" />  <!--Archery King-->
  <item package="com.king.candycrushjellysaga" rateId="3-1-2-3" />  <!--Candy Crush Jelly Saga-->
  <item package="com.tencent.iglite" rateId="3-1-2-3" />  <!--PUBG MOBILE LITE-->
  <item package="com.ffgames.racingincar2" rateId="3-1-2-3" />  <!--Racing in Car 2-->
  <item package="com.nianticlabs.pokemongo" rateId="3-1-2-3" />  <!--Pokémon GO-->
  <item package="io.voodoo.holeio" rateId="3-1-2-3" />  <!--Hole.io-->
  <item package="com.mediocre.smashhit" rateId="3-1-2-3" />  <!--Smash Hit-->
  <item package="com.king.farmheroessaga" rateId="3-1-2-3" />  <!--Farm Heroes Saga-->
  <item package="com.fingersoft.hcr2" rateId="3-1-2-3"  disableViewOverride="false" />  <!--Hill Climb Racing 2-->
  <item package="com.supercell.hayday" rateId="3-1-2-3" />  <!--Hay Day-->
  <item package="com.brokenreality.planemerger.android" rateId="3-1-2-3" />  <!--Merge Plane - Click & Idle Tycoon-->
  <item package="com.herocraft.game.free.gibbets3" rateId="3-1-2-3" />  <!--Gibbets: Bow Master-->
  <item package="com.billiards.city.pool.nation.club" rateId="3-1-2-3" />  <!--Pooking - Billiards City-->
  <item package="com.halfbrick.fruitninjafree" rateId="3-1-2-3" />  <!--Fruit Ninja®-->
  <item package="com.octro.rummy" rateId="3-1-2-3" />  <!--Indian Rummy (13 & 21 Cards) by Octro-->
  <item package="slither.io" rateId="3-1-2-3" />  <!--slither.io-->
  <item package="com.rovio.angrybirds" rateId="3-1-2-3" />  <!--Angry Birds Classic-->
  <item package="com.chess" rateId="3-1-2-3" />  <!--Chess · Play & Learn-->
  <item package="com.quizup.core" rateId="3-1-2-3" />  <!--QuizUp-->
  <item package="com.skgames.trafficracer" rateId="3-1-2-3" />  <!--Traffic Racer-->
  <item package="com.fungames.flightpilot" rateId="3-1-2-3" />  <!--Flight Pilot Simulator 3D Free-->
  <item package="com.gameloft.android.ANMP.GloftNOHM" rateId="3-1-2-3" />  <!--N.O.V.A. Legacy-->
  <item package="com.generagames.resistance" rateId="3-1-2-3" />  <!--Cover Fire: Shooting Games PRO-->
  <item package="com.mobile.legends" rateId="3-1-2-3" />  <!--Mobile Legends: Bang Bang-->
  <item package="com.miniclip.footballstrike" rateId="3-1-2-3" />  <!--Football Strike - Multiplayer Soccer-->
  <item package="com.rioo.runnersubway" rateId="3-1-2-3" />  <!--Subway Princess Runner-->
  <item package="wood.puzzle.game.blockpuzzle" rateId="3-1-2-3" />  <!--Wood Block Puzzle-->
  <item package="com.picsart.studio" rateId="3-1-2-3" />  <!--PicsArt Photo Editor: Pic, Video & Collage Maker-->
  <item package="vStudio.Android.Camera360" rateId="3-1-2-3" />  <!--Camera360: Selfie Photo Editor with Funny Sticker-->
  <item package="com.shinycore.picsayfree" rateId="3-1-2-3" />  <!--PicSay Pro - Photo Editor-->
  <item package="com.campmobile.snow" rateId="3-1-2-3" />  <!--SNOW-->
  <item package="com.touchbyte.photosync" rateId="3-1-2-3" />  <!--abPhoto (photo backup)-->
  <item package="camera360.lite.beauty.selfie.camera" rateId="3-1-2-3" />  <!--Camera360 Lite - Selfie Camera-->
  <item package="com.moonlab.unfold" rateId="3-1-2-3" />  <!--Unfold — Create Stories-->
  <item package="dstudio.tool.instasave" rateId="3-1-2-3" />  <!--QuickSave for Instagram - Downloader and Repost-->
  <item package="com.cyworld.camera" rateId="3-1-2-3" />  <!--Cymera Camera - Collage, Selfie Camera, Pic Editor-->
  <item package="com.ginnypix.kujicam" rateId="3-1-2-3" />  <!--Kuji Cam-->
  <item package="com.youthhr.phonto" rateId="3-1-2-3" />  <!--Phonto - Text on Photos-->
  <item package="com.linecorp.foodcam.android" rateId="3-1-2-3" />  <!--Foodie - Camera for life-->
  <item package="org.adesanyaaa.appmoviecreator" rateId="3-1-2-3" />  <!--Movie Creator-->
  <item package="jp.naver.linecamera.android" rateId="3-1-2-3" />  <!--LINE Camera - Photo editor-->
  <item package="com.flavionet.android.camera.lite" rateId="3-1-2-3" />  <!--Camera FV-5 Lite-->
  <item package="com.sony.playmemories.mobile" rateId="3-1-2-3" />  <!--Imaging Edge Mobile-->
  <item package="com.sonymobile.androidapp.cameraaddon.areffect" rateId="3-1-2-3" />  <!--AR effect-->
  <item package="com.fujifilm_dsc.app.remoteshooter" rateId="3-1-2-3" />  <!--FUJIFILM Camera Remote-->
  <item package="sweet.selfie.lite" rateId="3-1-2-3" />  <!--Sweet Selfie Camera:Beauty cam,photo&selfie editor-->
  <item package="com.xiaomi.xy.sportscamera" rateId="3-1-2-3" />  <!--YI Action - YI Action Camera-->
  <item package="com.sonymobile.android.addoncamera.styleportrait" rateId="3-1-2-3" />  <!--Style portrait-->
  <item package="com.snowcorp.soda.android" rateId="3-1-2-3" />  <!--SODA - Natural Beauty Camera-->
  <item package="com.meepo.instasave" rateId="3-1-2-3" />  <!--InstaSave - Instagram photo and video downloader-->
  <item package="com.flayvr.flayvr" rateId="3-1-2-3" />  <!--Gallery-->
  <item package="com.ffffstudio.kojicam" rateId="3-1-2-3" />  <!--1998 Cam - Vintage Camera-->
  <item package="com.hefe.pro.editor" rateId="3-1-2-3" />  <!--Photo Editor Pro-->
  <item package="com.gorgeous.liteinternational" rateId="3-1-2-3" />  <!--Ulike - Define your selfie in trendy style-->
  <item package="com.simplemobiletools.gallery" rateId="3-1-2-3" />  <!--Simple Gallery Pro: Photo Manager & Editor-->
  <item package="instagramstory.maker.unfold" rateId="3-1-2-3" />  <!--StoryChic:IG Story Art Maker,Instagramstory editor-->
  <item package="com.ryzenrise.storyart" rateId="3-1-2-3" />  <!--StoryArt - Insta story editor for Instagram-->
  <item package="com.photogrid.lite" rateId="3-1-2-3" />  <!--PhotoGrid Lite: Photo Collage Maker & Photo Editor-->
  <item package="com.hodanny.instagrid" rateId="3-1-2-3" />  <!--9square for Instagram-->
  <item package="com.camera.one.s10.camera" rateId="3-1-2-3" />  <!--One S10 Camera - Galaxy S10 camera style-->
  <item package="instagram.story.art.collage" rateId="3-1-2-3" />  <!--Mojito - Story Art Maker, Instagram story editor-->
  <item package="com.fueled.afterlight" rateId="3-1-2-3" />  <!--Afterlight-->
  <item package="com.jeyluta.timestampcamerafree" rateId="3-1-2-3" />  <!--Timestamp Camera Free-->
  <item package="com.handycloset.android.stickers" rateId="3-1-2-3" />  <!--Personal Stickers-->
  <item package="com.gilangfaisal.thestream" rateId="3-1-2-3" />  <!--Vidio - Nonton Video, TV & Live Streaming Gratis-->
  <item package="com.rocks.music.videoplayer" rateId="3-1-2-3" />  <!--Video Player All Format - XPlayer-->
  <item package="com.music.video.player.hdxo" rateId="3-1-2-3" />  <!--SHビデオプレーヤー-->
  <item package="com.besthdvideo.editor.cutter.converter.pstr" rateId="3-1-2-3" />  <!--VivaVideo PRO Video Editor HD-->
  <item package="com.znstudio.instadownload" rateId="3-1-2-3" />  <!--Downloader for Instagram: Photo & Video Saver-->
  <item package="facebookvideodownloader.videodownloaderforfacebook" rateId="3-1-2-3" />  <!--Video Downloader for Facebook Video Downloader-->
  <item package="com.ants360.yicamera" rateId="3-1-2-3" />  <!--YI Home-->
  <item package="com.kmplayer" rateId="3-1-2-3" />  <!--Video Player HD All formats & codecs - kmplayer-->
  <item package="com.yoosee" rateId="3-1-2-3" />  <!--Yoosee-->
  <item package="com.gretech.gomplayerko" rateId="3-1-2-3" />  <!--GOM Player-->
  <item package="com.nbs.useetv" rateId="3-1-2-3" />  <!--UseeTV GO - Watch Live TV and On Demand TV/Video-->
  <item package="storysaverforinstagram.storydownloader.instastorysaver" rateId="3-1-2-3" />  <!--Story Saver for Instagram - Story Downloader-->
  <item package="com.mobivio.android.cutecut" rateId="3-1-2-3" />  <!--Cute CUT - Video Editor & Movie Maker-->
  <item package="com.soludens.movieview" rateId="3-1-2-3" />  <!--Soul Movie-->
  <item package="com.media.digital" rateId="3-1-2-3" />  <!--TV Indonesia - Semua Saluran TV Online Indonesia-->
  <item package="com.tencent.qqlivei18n" rateId="3-1-2-3" />  <!--WeTV - Dramas, Films & More-->
  <item package="com.playtube.videotube.tubevideo" rateId="3-1-2-3" />  <!--Play Tube & Video Tube-->
  <item package="com.downloadvideo.freevideodownloader.downloadall" rateId="3-1-2-3" />  <!--Free Video Downloader-->
  <item package="videocutter.mp3cutter.videotomp3converter.powertrimmer" rateId="3-1-2-3" />  <!--Video to MP3 Converter - mp3 cutter and merger-->
  <item package="videoeditor.videorecorder.screenrecorder" rateId="3-1-2-3" />  <!--Screen Recorder & Video Recorder - XRecorder-->
  <item package="com.player.zaltv" rateId="3-1-2-3" />  <!--ZalTV Player-->
  <item package="com.television.burma" rateId="3-1-2-3" />  <!--Burma TV-->
  <item package="com.garena.game.kgid" rateId="3-1-2-3" />  <!--Garena AOV - Arena of Valor: Action MOBA-->
  <item package="vha.cds" rateId="3-1-2-3" />  <!--Candy Crush Saga-->
  <item package="me.pou.app" rateId="3-1-2-3" />  <!--Pou-->
  <item package="com.firsttouchgames.dlsa" rateId="3-1-2-3" />  <!--Dream League Soccer-->
  <item package="com.shy.badminton.simulator.game.swipe.court.smash.pass.field.stage.cue" rateId="3-1-2-3" />  <!--Badminton League-->
  <item package="com.rtsoft.growtopia" rateId="3-1-2-3" />  <!--Growtopia-->
  <item package="org.ppsspp.ppsspp" rateId="3-1-2-3" />  <!--PPSSPP - PSP emulator-->
  <item package="com.gue.pesanyar" rateId="3-1-2-3" />  <!--PES 2019 PRO EVOLUTION SOCCER-->
  <item package="net.mobigame.zombietsunami" rateId="3-1-2-3" />  <!--Zombie Tsunami-->
  <item package="com.ea.watchface.pvzzombie" rateId="3-1-2-3" />  <!--Plants vs. Zombies FREE-->
  <item package="com.linecorp.LGGRTHN" rateId="3-1-2-3" />  <!--LINE Let's Get Rich-->
  <item package="com.maleo.bussimulatorid" rateId="3-1-2-3" />  <!--Bus Simulator Indonesia-->
  <item package="joykeratif.tts" rateId="3-1-2-3" />  <!--Teka-teki Silang TTS Update Terbaru Februari 2019-->
  <item package="com.DoniAndroid.TTSTekaTekiSilangOffline2019" rateId="3-1-2-3" />  <!--Teka Teki Silang - TTS 2018-->
  <item package="com.playrix.homescapes" rateId="3-1-2-3" />  <!--Homescapes-->
  <item package="com.ea.game.simcitymobile_row" rateId="3-1-2-3" />  <!--SimCity BuildIt-->
  <item package="com.epsxe.ePSXe" rateId="3-1-2-3" />  <!--ePSXe for Android-->
  <item package="com.touchtao.soccerkinggoogle" rateId="3-1-2-3" />  <!--World Soccer League-->
  <item package="com.bunbogames.racingxtreme" rateId="3-1-2-3" />  <!--Asphalt 9: Legends - 2019's Action Car Racing Game-->
  <item package="com.roblox.client" rateId="3-1-2-3" />  <!--Roblox-->
  <item package="com.paragisoft.gaple" rateId="3-1-2-3" />  <!--Gaple-->
  <item package="com.tebakgambar" rateId="3-1-2-3" />  <!--Tebak Gambar-->
  <item package="com.jellyblast.cmcm" rateId="3-1-2-3" />  <!--Jellipop Match: Open your dream shop！-->
  <item package="pawapp.games.onetdeluxe" rateId="3-1-2-3" />  <!--Onet Deluxe-->
  <item package="com.gamegou.football" rateId="3-1-2-3" />  <!--Top Eleven 2019 -  Be a soccer manager-->
  <item package="com.miHoYo.bh3oversea" rateId="3-1-2-3" />  <!--Honkai Impact 3-->
  <item package="com.MangoSoft.Susun" rateId="3-1-2-3" />  <!--Mango Capsa Susun-->
  <item package="com.vectorunit.purple.googleplay" rateId="3-1-2-3" />  <!--Beach Buggy Racing-->
  <item package="com.netease.idv.googleplay" rateId="3-1-2-3" />  <!--Identity V-->
  <item package="com.constructmonkey.rr3guide" rateId="3-1-2-3" />  <!--Real Racing  3-->
  <item package="com.mobirix.fishinghook" rateId="3-1-2-3" />  <!--Fishing Hook-->
  <item package="agame.onet.classic" rateId="3-1-2-3" />  <!--Onet Classic-->
  <item package="jpark.AOS5" rateId="3-1-2-3" />  <!--Anger of stick 5 : zombie-->
  <item package="com.ForgeGames.SpecialForcesGroup2" rateId="3-1-2-3" />  <!--Special Forces Group 2-->
  <item package="com.asobimo.toramonline" rateId="3-1-2-3" />  <!--RPG Toram Online-->
  <item package="com.netmarble.mherosgb" rateId="3-1-2-3" />  <!--MARVEL Future Fight-->
  <item package="balls.arcademaker.bricks.breaker.brounce.ballz" rateId="3-1-2-3" />  <!--Balls Bricks Breaker-->
  <item package="com.cooking.mama.kitchen.dinner" rateId="3-1-2-3" />  <!--Cooking Mama: Let's cook!-->
  <item package="com.YoStarEN.AzurLane" rateId="3-1-2-3" />  <!--Azur Lane-->
  <item package="com.netmarble.sknightsgb" rateId="3-1-2-3" />  <!--Seven Knights-->
  <item package="com.fgol.HungrySharkEvolution" rateId="3-1-2-3" />  <!--Hungry Shark Evolution-->
  <item package="com.chillingo.robberybobfree.android.row" rateId="3-1-2-3" />  <!--Robbery Bob-->
  <item package="com.youmusic.magictiles" rateId="3-1-2-3" />  <!--Magic Tiles 3-->
  <item package="com.ea.gp.nbamobile" rateId="3-1-2-3" />  <!--NBA LIVE Mobile Basketball-->
  <item package="com.shootinggames.sniper3d.assassin" rateId="3-1-2-3" />  <!--Sniper 3D Gun Shooter: Free Elite Shooting Games-->
  <item package="com.bubadu.bubbu" rateId="3-1-2-3" />  <!--Bubbu – My Virtual Pet-->
  <item package="com.forthblue.pool" rateId="3-1-2-3" />  <!--Pool Billiards Pro-->
  <item package="com.gta.grandtheftauto.sanandreas.codes" rateId="3-1-2-3" />  <!--Grand Theft Auto: San Andreas-->
  <item package="com.ChillyRoom.DungeonShooter" rateId="3-1-2-3" />  <!--Soul Knight-->
  <item package="com.fungames.blockcraft" rateId="3-1-2-3" />  <!--Block Craft 3D: Building Simulator Games For Free-->
  <item package="com.pixonic.wwr" rateId="3-1-2-3" />  <!--War Robots-->
  <item package="com.kit.durangoguides" rateId="3-1-2-3" />  <!--Durango: Wild Lands-->
  <item package="jp.konami.duellinks" rateId="3-1-2-3" />  <!--Yu-Gi-Oh! Duel Links-->
  <item package="com.nordcurrent.canteenhd" rateId="3-1-2-3" />  <!--Cooking Fever-->
  <item package="com.sweetmatch3gamesmania.fruitsbomb" rateId="3-1-2-3" />  <!--Fruits Bomb-->
  <item package="com.wikia.singlewikia.fategrandorder" rateId="3-1-2-3" />  <!--Fate/Grand Order (English)-->
  <item package="jp.konami.pesclubmanager" rateId="3-1-2-3" />  <!--PES CLUB MANAGER-->
  <item package="com.rovio.baba" rateId="3-1-2-3" />  <!--Angry Birds 2-->
  <item package="com.unionpay" rateId="3-1-2-3" />  <!--银联-->
  <item package="com.amazon.avod.thirdpartyclient" rateId="3-1-2-3" />  <!--亚马逊-->
<!-- override surfaceview,textureview,app run on user select rate-->
 <item package="com.miHoYo.Yuanshen" rateId="3-1-2-3" disableViewOverride="false" adfr="true" appreqfirst="true" enableFodHighRate="true" enableRateOverride="false" />  <!--原神国内-->
  <item package="com.tencent.lolm" rateId="3-1-2-3" disableViewOverride="false" adfr="true"/>  <!--英雄联盟国内-->
  <item package="com.riotgames.league.wildrift" rateId="3-1-2-3" disableViewOverride="false" adfr="true"/>  <!--英雄联盟海外-->
  <item package="com.riotgames.league.wildrifttw" rateId="3-1-2-3" disableViewOverride="false" adfr="true"/>  <!--英雄联盟海外-->
  <item package="com.riotgames.league.wildriftvn" rateId="3-1-2-3" disableViewOverride="false" adfr="true"/>  <!--英雄联盟海外-->
  <item package="com.riotgames.internal.wildrift.trunk" rateId="3-1-2-3" disableViewOverride="false" adfr="true"/>  <!--英雄联盟海外-->
  <item package="com.tencent.tmgp.cod" rateId="3-1-2-3" disableViewOverride="false" adfr="true" />  <!--使命召唤_国内-->
  <item package="com.activision.callofduty.shooter" rateId="3-1-2-3" disableViewOverride="false" adfr="true" />  <!--使命召唤_海外-->
  <item package="com.garena.game.codm" rateId="3-1-2-3" disableViewOverride="false" />  <!-- codm -->
  <item package="com.tencent.tmgp.kr.codm" rateId="3-1-2-3" disableViewOverride="false" />  <!-- codm -->
  <item package="com.activision.callofduty.codpbt" rateId="3-1-2-3" disableViewOverride="false" />  <!-- codm -->
  <item package="com.tencent.tmgp.speedmobile" rateId="3-1-2-3" disableViewOverride="false" adfr="true" />  <!--QQ飞车-->
  <item package="com.tencent.tmgp.pubgmhd" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false"  adfr="true" />  <!--和平精英-->
  <item package="com.tencent.ig" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false"  adfr="true" />  <!--全球版 和平精英-->
  <item package="com.pubg.krmobile" rateId="3-1-2-3" disableViewOverride="false"  adfr="true" />  <!--日韩版 和平精英-->
  <item package="com.vng.pubgmobile" rateId="3-1-2-3" disableViewOverride="false"  adfr="true" />  <!--越南版 和平精英-->
  <item package="com.rekoo.pubgm" rateId="3-1-2-3" disableViewOverride="false"  adfr="true" />  <!--台湾版 和平精英-->
  <item package="com.tencent.tmgp.projectg" rateId="3-1-2-3" disableViewOverride="false"  adfr="true" />  <!--体验服 和平精英-->
  <item package="com.tencent.igce" rateId="3-1-2-3" disableViewOverride="false"  adfr="true" />  <!--先游版 和平精英-->
  <item package="com.tencent.tmgp.cf" rateId="3-1-2-3" adfr="true"/>  <!--穿越火线 -->
  <item package="com.tencent.tmgp.sgamece" rateId="3-1-2-3" disableViewOverride="false"  />  <!--王者荣耀体验服-->
  <item package="com.tencent.tmgp.sgame" rateId="3-1-2-3" disableViewOverride="false" adfr="true" appreqfirst="true" enableRateOverride="false" />   <!--王者荣耀-->
  <item package="com.tencent.af" rateId="3-1-2-3" disableViewOverride="false" />  <!--王牌战士-->
  <item package="com.tencent.YiRen" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 一人之下 -->
  <item package="com.tencent.KiHan" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 火影忍者 -->
  <item package="com.tencent.tmgp.KiHan" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 火影忍者 -->
  <item package="com.netease.koh" rateId="3-1-2-3" />  <!--猎手之王 -->
  <item package="com.netease.koh.nearme.gamecenter" rateId="3-1-2-3"/>  <!--猎手之王 商店-->
  <item package="com.netease.jddsaef" rateId="3-1-2-3" disableViewOverride="false" /> <!--机动都市阿尔法-->
  <item package="com.netease.jddsaef.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--机动都市阿尔法 商店-->
  <item package="com.tencent.tmgp.jddsaef" rateId="3-1-2-3" disableViewOverride="false" />  <!--机动都市阿尔法 应用宝-->
  <item package="com.netease.yokaikoya" rateId="3-1-2-3" disableViewOverride="false" /> <!--阴阳师 妖怪屋-->
  <item package="com.netease.yokaikoya.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--阴阳师 妖怪屋 商店-->
  <item package="com.tencent.tmgp.eyou.ygwu" rateId="3-1-2-3" disableViewOverride="false" />  <!--阴阳师 妖怪屋 应用宝-->
  <item package="com.netease.lztg.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--量子特工  -->
  <item package="com.netease.lztg" rateId="3-1-2-3" disableViewOverride="false" />  <!--量子特工 官网-->
  <item package="com.tencent.tmgp.yongyong.lztg" rateId="3-1-2-3" disableViewOverride="false" />  <!--量子特工 应用宝版 -->
  <item package="com.netease.blqx" rateId="3-1-2-3" disableViewOverride="false" />  <!--堡垒前线 官网版 -->
  <item package="com.netease.blqx.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--堡垒前线 -->
  <item package="com.tencent.tmgp.eyou.blqx" rateId="3-1-2-3" disableViewOverride="false" />  <!--堡垒前线 -->
  <item package="com.netease.moba.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--决战！平安京-->
  <item package="com.tencent.tmgp.kaopu.jzpaj" rateId="3-1-2-3" disableViewOverride="false" /> <!--决战！平安京-->
  <item package="com.netease.moba" rateId="3-1-2-3" disableViewOverride="false" />  <!--决战！平安京-->
  <item package="ccom.tencent.tmgp.kaopu.jzpaj" rateId="3-1-2-3" disableViewOverride="false" />  <!--决战平安京 应用宝-->
  <item package="com.miHoYo.enterprise.NGHSoD" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false" /> <!--崩坏3 官网版-->
  <item package="com.miHoYo.bh3.nearme.gamecenter" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false" />  <!--崩坏3-->
  <item package="com.pwrd.xxajh.laohu" rateId="3-1-2-3" /> <!--新笑傲江湖 官网-->
  <item package="com.pwrd.xxajh.nearme.gamecenter" rateId="3-1-2-3" />  <!--新笑傲江湖 -->
  <item package="com.tencent.tmgp.xxajh" rateId="3-1-2-3" />  <!--新笑傲江湖 应用宝版本 -->
  <item package="com.xsmdl.nearme.gamecenter" rateId="3-1-2-3" />  <!--应用商店 新神魔大陆-->
  <item package="com.tencent.tmgp.xsmdl" rateId="3-1-2-3" />  <!--应用宝 新神魔大陆-->
  <item package="com.pwrd.xsmdl.laohu" rateId="3-1-2-3" />  <!--官网 新神魔大陆-->
  <item package="com.youzu.bs" rateId="3-1-2-3" disableViewOverride="false" />  <!--荒野乱斗 官网-->
  <item package="com.youzu.bs.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--应用商店 荒野乱斗-->
  <item package="com.tencent.tmgp.supercell.brawlstars" rateId="3-1-2-3" disableViewOverride="false" adfr="true" />  <!--荒野乱斗 应用宝-->
  <item package="com.yingxiong.dftk.nearme.gamecenter" rateId="3-1-2-3"/>  <!--巅峰坦克-->
  <item package="com.yingxiong.dftk.yx" rateId="3-1-2-3" />  <!--巅峰坦克-->
  <item package="com.tencent.tmgp.dftkzjzg" rateId="3-1-2-3" />  <!--巅峰坦克-->
  <item package="com.Lilith.Abi.nearme.gamecenter" rateId="3-1-2-3" />  <!--艾彼-->
  <item package="com.yunbu.rehtona.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--幻境双生 -->
  <item package="com.denachina.g13002010.denacn" rateId="3-1-2-3" /> <!--灌篮高手 官网 -->
  <item package="com.denachina.g13002010.nearme.gamecenter" rateId="3-1-2-3" />  <!--灌篮高手 商店 -->
  <item package="com.tencent.tmgp.g13002010" rateId="3-1-2-3" />  <!--灌篮高手 -->
  <item package="com.volvapps.ef5.x.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--空战争锋-->
  <item package="com.tencent.tmgp.ef5" rateId="3-1-2-3" disableViewOverride="false" /> <!--空战争锋 应用宝版-->
  <item package="com.palmpi.hcollege.feiyu" rateId="3-1-2-3" disableViewOverride="false" /> <!--魂器学院 官网-->
  <item package="com.palmpi.hcollege.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" />  <!--魂器学院 商店-->
  <item package="com.tencent.tmgp.hqxy" rateId="3-1-2-3" disableViewOverride="false" /> <!--魂器学院 应用宝-->
  <item package="com.ztgame.bob" rateId="3-1-2-3" disableViewOverride="false" />  <!--球球大作战-->
  <item package="com.netease.x19" rateId="3-1-2-3" enableFodHighRate="true" enableRateOverride="false" /> <!--我的世界 官网-->
  <item package="com.netease.mc.nearme.gamecenter" rateId="3-1-2-3" disableViewOverride="false" /> <!--我的世界 -->
  <item package="com.tencent.tmgp.wdsj666" rateId="3-1-2-3" disableViewOverride="false" /> <!--我的世界 应用宝-->
  <item package="com.tencent.game.rhythmmaster" rateId="3-1-2-3" disableViewOverride="false" /> <!--腾讯节奏大师-->
  <item package="com.coloros.video" activity="com.coloros.video/com.oppo.video.mycenter.MoviePlayerActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 120hz 视频播放需要-->
  <item package="com.coloros.gallery3d" rateId="3-1-2-3" disableViewOverride="false" appreqfirst="true" />  <!--相册 BugID 2882523 -->
  <item package="com.coloros.weather2" activity="com.coloros.weather2/com.coloros.weather.main.view.WeatherMainActivity" rateId="3-1-2-3" disableViewOverride="false" />  <!-- 天气 BugID 2889194 -->
  <item package="com.qiyi.video"  rateId="3-1-2-3" disableViewOverride="false" />   <!--爱奇艺 视频低刷新率-->
  <item package="tv.danmaku.bili"  rateId="3-1-2-3" disableViewOverride="false" adfr="true" appreqfirst="true" />   <!--哔哩哔哩-->
  <item package="com.tencent.qqsports"  rateId="3-1-2-3" disableViewOverride="false" />   <!--腾讯体育 视频低刷新率名单-->
  <item package="com.hunantv.imgo.activity"  rateId="3-1-2-3" lowfreq="true" />   <!--芒果TV 视频低刷新率名单-->
<!--video app preferredRefreshRate =120hz, done 120hz  -->
  <item package="com.example.myapplication" rateId="3-1-2-3" appreqfirst="true" /> <!--test-->
  <item package="com.tencent.qqlive"  rateId="3-1-2-3" appreqfirst="true"  lowfreq="false" />   <!--腾讯视频-->
<!-- 录屏降低帧率到 60hz -->
  <record package="com.heytap.cast" />  <!--投屏时候保持系统帧率在60hz-->
  <record package="com.oplus.cast" />  <!--投屏时候保持系统帧率在60hz-->
<!--inputMethodLowRate 为true输入法降帧，默认为false
  enableRateOverride 默认为true,为false表示surfaceview，texture场景不降
  enableFodHighRate true表示可以支持指纹高刷新请求，默认false，部分项目指纹闪屏需要配置
  M.Team.MOD 酷安ID:肥鹏鹏 -->
  <config inputMethodLowRate="false" enableFodHighRate="true" enableRateOverride="false"/>
</refresh_rate_config>
