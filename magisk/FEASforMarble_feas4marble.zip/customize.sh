$BOOTMODE || abort "Installing this module in recovery mode is not supported!"

[ "$(getprop ro.product.device)" == "marble" ] || [ "$(getprop ro.product.device)" == "marblein" ] || abort "This mod is only for marble/marblein!"

[ "$(getprop ro.miui.ui.version.code)" -ge "14" ] || abort "The FEAS feature is only available on MIUI 14+!"

if [ "$(getprop ro.product.locale.language)" == "zh" ] || [ "$(getprop persist.sys.locale)" == "zh-CN" ]; then
    echo "description=通过安装 diting 的 perfmgr 模块并\"伪装\"机型为 diting 以启用 FEAS 支持. 由于小米的云控限制, 请搭配 Feashelper 模块使用. 来自 Pandora kernel 的主意." >> ${MODPATH}/module.prop
else
    echo "description=Enable FEAS support by installing diting's perfmgr.ko and \"masquerading\" the model as diting. Due to the limitation of Xiaomi's cloud control, please use it with the Feashelper module. Idea from Pandora kernel." >> ${MODPATH}/module.prop
fi
