#/system/bin/sh

pross=$(pgrep -f 'com.huawei.hwid' | wc -l )

if test "$pross" -lt 1 ;then
am start -n com.huawei.hwid/com.huawei.hms.core.activity.JumpActivity 2>/dev/null
sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，为您保活HMS 服务一次，杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
fi
