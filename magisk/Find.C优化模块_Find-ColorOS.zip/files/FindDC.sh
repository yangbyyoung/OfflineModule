#############################################################################################################
#  对小白说的话别几把瞎调，傻逼东西后果自负
#酷安：官宣吖   QQ交流群：938499734
while  
do 
su -c echo 1 > /sys/kernel/oppo_display/dimlayer_hbm
su -c echo 1 > /sys/kernel/oplus_display/dimlayer_hbm
sleep 0
done