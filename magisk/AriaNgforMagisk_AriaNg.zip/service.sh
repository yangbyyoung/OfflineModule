# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此防跳和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}

#检测安装状态
[ -d /data/Aria2 ] || cp -af ${0%/*}/Aria2 /data/Aria2
aria2="/data/Aria2/bin/aria2c"
lighttpd="/data/Aria2/bin/lighttpd"
aria2conf="/data/Aria2/etc/aria2.conf"
lighttpdconf="/data/Aria2/etc/lighttpd.conf"
#启动程序
$lighttpd -f $lighttpdconf
$aria2 --conf-path=$aria2conf -D
