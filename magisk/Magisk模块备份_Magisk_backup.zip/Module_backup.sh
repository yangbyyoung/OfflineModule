source $MODPATH/keymod/path.sh
test ! -e $Backup_path && mkdir -p $(dirname $Backup_path)
test ! -e $Backup_path2 && mkdir -p $(dirname $Backup_path2)



function backupmagiskmod(){
	echo ""
	echo "∞————————————————————————∞"
	echo ""
	echo "－ ♥开始备份，请耐心等待♥……"
	cd /data/adb
	tar -cf $Backup_path * --exclude=magisk --exclude=modules_update --exclude=lite_modules_update
	echo "备份完成 文件在 $Backup_path"
	echo ""
	echo "∞————————————————————————∞"
}

for i in $(find /data/media/0/Android/Magisk备份 -name "*.sh" -type f);do rm -rf $i ;done
cp -rf $MODPATH/脚本/* $(dirname $(dirname $Backup_path))
chmod -R 777 $(dirname $(dirname $Backup_path))
sh $(dirname $Backup_path)/log.sh 2> /dev/null

test ! -e $Backup_path && backupmagiskmod

timetablefile="$MODPATH/timetable/root"

writemodulesinfo(){
	local file=$MODPATH/module.prop
	timesleep=`cat $timetablefile |tr -cd "[0-9]"`
	test $timesleep == 10  && timesleep='10分钟'
	test $timesleep == 30  && timesleep='30分钟'
	test $timesleep == 01  && timesleep='1个小时'
	test $timesleep == 001  && timesleep='1天'
	test $timesleep == 03  && timesleep='3个小时'
	test $timesleep == 06  && timesleep='6个小时'
	sed -i "/^description=/c description=备份文件在 "$(dirname $(dirname $Backup_path))"。模拟终端输入magiskbackup，可以选择恢复或者备份模块，您也可以在备份目录恢复或者备份模块。备份时间间隔为: "$timesleep" " $file
}
writemodulesinfo

