/vendor/bin/hw/vendor.semc.hardware.charger@1.0-service
