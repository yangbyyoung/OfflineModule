warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo 40000000 > /sys/class/power_supply/battery/fast_charge_current
  echo 40000000 > /sys/class/power_supply/battery/thermal_input_current
  echo 40000000 > /sys/class/power_supply/usb/current_max
sleep 2s
data=`[[ -f $warm ]] && cat $warm`
if [[ $data -le 450 ]]; then
  echo '40000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "460" ]&&[ "$data" -lt "463" ];then
  echo '39000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "463" ]&&[ "$data" -lt "466" ];then
  echo '37000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "466" ]&&[ "$data" -lt "469" ];then
  echo '30000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "469" ]&&[ "$data" -lt "471" ];then
  echo '20000000' > "/sys/class/power_supply/battery/constant_charge_current_max" 
  elif [ "$data" -ge "471" ]&&[ "$data" -lt "473" ];then
  echo '10000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "473" ]&&[ "$data" -lt "475" ];then
  echo '8000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "475" ]&&[ "$data" -lt "477" ];then
  echo '7000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "477" ]&&[ "$data" -lt "479" ];then
  echo '3000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "479" ]&&[ "$data" -lt "481" ];then
  echo '100000' > "/sys/class/power_supply/battery/constant_charge_current_max"
fi
done
