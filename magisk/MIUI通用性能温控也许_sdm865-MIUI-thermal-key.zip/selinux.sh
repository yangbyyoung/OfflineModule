#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

id="$id"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"

function get_log(){
local name="$1"
local file="$2"
if test -f "$file" ;then
	if test -z "$name" ;then
		cat "$file" | grep -oi "avc.*permissive" | sort | uniq
	else
		cat "$file" | grep -w -i "$name" | grep -oi "avc.*permissive" | sort | uniq
	fi
else
	if test -z "$name" ;then
		dmesg | grep -oi "avc.*permissive" | sort | uniq
	else
		dmesg | grep -w -i "$name" | grep -oi "avc.*permissive" | sort | uniq
	fi
fi
}

function get_scontext(){
local text="$1"
echo "$text" | grep -Eo "scontext=.*s0" | cut -d':' -f3 | sed 's/[[:space:]]//g'
}

function get_tcontext(){
local text="$1"
echo "$text" | grep -Eo "tcontext=.*s0" | cut -d':' -f3 | sed 's/[[:space:]]//g'
}


function get_tclass(){
local text="$1"
echo "$text" | grep -Eo "tclass=.*permissive" | cut -d'=' -f2 | sed 's|permissive.*||g'
}

function get_denied(){
local text="$1"
echo "$text" | grep -Eo "denied.*}" | sed 's|denied||g'
}

function running_main(){
local IFS=$'\n'
local selinux_rules="$1.Verbose"
local name="$2"
local file="$3" 
for i in $(get_log "$name" "$file")
do
cat <<key >> "$selinux_rules"
#log `date '+%F %T'` [ $i ]
allow $(get_scontext "$i") $(get_tcontext "$i") $(get_tclass "$i") $(get_denied "$i")
key
done
test -f "$selinux_rules" && {
cat <<key >>"${selinux_rules%/*}/sepolicy.rule"
#`date '+%F %T'`
`cat "$selinux_rules" | sed '/^#/d;/^[[:space:]]*$/d;s|   | |g;s|  | |g' | sort | uniq`
key
	}
}

function mk_new_file(){
local file=$1
if test -f $file ;then
local new="$( cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' | sort | uniq )"
	echo "${new}" > "${file}"
fi
}

function mk_mod_rules_script(){
local IFS=$'\n'
local file="${1}"
local target_file="${2}"
echo -e "#!/system/bin/sh\n" > "${target_file}"
for i in $(cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d')
do
cat << key >> "${target_file}"
magiskpolicy --live "${i}"
key
done
mk_new_file "${MODPATH}/magiskpolicy.sh"
sed -i "1i #!/system/bin/sh\n" "${target_file}"
}

function echo_selinux_rules_info(){
local file="${1}"
local script_file="${2}"
echo -e "\n∞————————————————————————∞\n※规则和脚本预览中……"
if test -f "${file}" ;then
cat << key

`cat "${file}"`

∞————————————————————————∞
key
fi
if test -f "${script_file}" ;then
cat << key
`cat "${script_file}"`

∞————————————————————————∞

key
fi
}

function echo_file_without_binary_file(){
local file="${1}"
if test -e /proc/kmsg ;then
	echo -e "\n※抓取kmsg内核日志中……"
	echo "※请耐心等待30s……"
	timeout 30s cat /proc/kmsg > "${file}"
	return 0
else
	echo "不存在/proc/kmsg！"
fi

if test "$(which -a logcat)" != "" ;then
	echo -e "\n※抓取kmsg内核日志中……"
	echo "※请耐心等待30s……"
	timeout 30s logcat -b all > "${file}"
	return 0
else
	echo "不存在logcat！"
fi
}




function Running_mod_rules(){
local file="${1}"
local log_file="${2}"
if test "$(which -a dmesg)" != "" ;then
	echo -e "\n∞————————————————————————∞\n※开始运行……"
		for selinux_key in $( cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' )
			do
				echo "※抓取关键词 ${selinux_key} ……"
		running_main "$MODPATH/sepolicy.rule" "${selinux_key}"
	done
else
echo_file_without_binary_file "${log_file}"
if test -f "${log_file}" ;then
	echo -e "\n∞————————————————————————∞\n※开始运行……"
		for selinux_key in $( cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' )
			do
				echo "※抓取关键词 ${selinux_key} ……"
			running_main "$MODPATH/sepolicy.rule" "${selinux_key}" "${log_file}"
		done
	fi
fi
}



#运行抓取并生成selinux规则
Running_mod_rules "$MODPATH/需要抓取的selinux规则.prop" "${MODPATH}/selinux_log.json"

#复制上次的规则
test -f "$local_MODPATH/sepolicy.rule" && {
echo "$(cat $local_MODPATH/sepolicy.rule)" >> "$MODPATH/sepolicy.rule"
mk_new_file "$MODPATH/sepolicy.rule" 
}

test -f "${MODPATH}/自定义selinux规则.prop" && echo "$(cat "${MODPATH}/自定义selinux规则.prop" | sed '/^#/d;/^[[:space:]]*$/d' )" >> "$MODPATH/sepolicy.rule"

#生成magiskpolicy脚本
mk_mod_rules_script "$MODPATH/sepolicy.rule" "${MODPATH}/magiskpolicy.sh"

#复制上次的脚本文件
test -f "$local_MODPATH/magiskpolicy.sh" && {
echo "$(cat $local_MODPATH/magiskpolicy.sh)" >> "$MODPATH/magiskpolicy.sh"
mk_new_file "$MODPATH/magiskpolicy.sh"
sed -i "1i #!/system/bin/sh\n" "${MODPATH}/magiskpolicy.sh"
}

#输出selinux规则预览
echo_selinux_rules_info "$MODPATH/sepolicy.rule" "${MODPATH}/magiskpolicy.sh"

#test ! -f "$MODPATH/sepolicy.rule" && abort "※未生成任何selinux规则！"

#整理selinux规则文件
mk_new_file "$MODPATH/sepolicy.rule" 

#删除配置文件
rm -rf "${MODPATH}/需要抓取的selinux规则.prop"
