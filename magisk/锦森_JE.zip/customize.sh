  ui_print "*******************************"
  ui_print "刷入中"
  ui_print "你下一个云控何必是云控"
  ui_print "刷入成功后请你重启手机"
  ui_print "*******************************"
  
  pm clear com.xiaomi.joyose
  pm clear com.xiaomi.powerchecker
  pm uninstall -k --user 0 com.miui.analytics
  pm install-existing --user 0 com.miui.daemon
  rm -f /data/system/package_cache/*
  rm -f /cache/miui-thermal/*
  pm enable com.miui.powerkeeper/feedbackcontrol.abnormallog.ThermalLogService
    ui_print "*******************************"
    ui_print "如果出现上边出现字母之类的属于正常现象"
    ui_print "如果只要不是刷入失败都无需把log反馈给作者"
    ui_print "*******************************"
    