#!/system/bin/sh
#更新module.prop信息
function Update_information(){
#获取当前时间
KillLog_time=`date +"%H:%M:%S"`
Mod_information=/data/adb/modules/Mi12_TemperatureControl/module.prop
#安装时间
Install_time=`cat $Config_add/Install_time`
#现在时间 年月日/时
NowTime_Ymd=`date +"%Y%m%d"`
NowTime_H=`date +"%H"`
Time_Ymd=`cat $Config_add/Time_Ymd`
Time_H=`cat $Config_add/Time_H`
#计算使用时长
Time_Day=`expr $NowTime_Ymd - $Time_Ymd`
Time_Hr=`expr $NowTime_H - $Time_H`
#判断凌晨0点以后是否有过使用，做出相应信息更改
if [ "$Earliest2" -gt "0000" ]; then
  sed -i "/^description=/c description=淦掉云控：[ ⏰<$Latest11,$Latest22>,<$Earliest11,$Earliest22> 🔪| $KillLog_time | ] 不跳电淦温控，满血快充(会阶梯式充电，也会受机身48℃温度墙影响)，游戏不掉帧，兼容A12/A13，MIUI13/MIUI14。安装日期：[ $Install_time ] | 使用时长：[ ${Time_Day}天 ${Time_Hr}小时 ]" "$Mod_information"
else
  sed -i "/^description=/c description=淦掉云控：[ ⏰<$Latest11,$Latest22> 🔪| $KillLog_time | ] 不跳电淦温控，满血快充(会阶梯式充电，也会受机身48℃温度墙影响)，游戏不掉帧，兼容A12/A13，MIUI13/MIUI14。安装日期：[ $Install_time ] | 使用时长：[ ${Time_Day}天 ${Time_Hr}小时 ]" "$Mod_information" "$Mod_information"
fi
}

Cache=/storage/emulated/0/Android/Mi12_TemperatureControl/Cache
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
#获取手机锁屏状态，false：已解锁 true：锁屏
Lock_screen_state=`dumpsys window policy | grep mIsShowing | cut -d"=" -f2`
H_time=`date +"%H%M"`
#判断解锁状态，记录使用的时间集合
if [ $Lock_screen_state == "false" ]; then
  echo "$H_time">>${Cache}/Caches
  if [ "$H_time" -ge "0000" ] && [ "$H_time" -le "0700" ]; then
    echo "$H_time">>${Cache}/Earliest
    echo "0000">${Cache}/Earliest1
    cat ${Cache}/Earliest | sort -u -n | sed -n '$p' >${Cache}/Earliest2
    cat ${Cache}/Caches | sort -u -n | sed -n '$p' >${Cache}/Latest2
  else
    echo "$H_time">>${Cache}/Latest
    cat ${Cache}/Latest | sort -u -n | sed -n '1p' >${Cache}/Latest1
    cat ${Cache}/Caches | sort -u -n | sed -n '$p' >${Cache}/Latest2
  fi
fi

#Earliest1凌晨0点固定0000，Earliest2凌晨8点之前最晚使用时间，Latest1早上8点之后最早的时间点，Latest2是使用时间0点之前最迟的时候
Earliest1=`cat ${Cache}/Earliest1`
Earliest2=`cat ${Cache}/Earliest2`
Latest1=`cat ${Cache}/Latest1`
Latest2=`cat ${Cache}/Latest2`
#做一个除运算，把时间"时分"换算成"时"，+1是为了准确时间集合范围
hundred=100
Earliest11=`expr $Earliest1 / $hundred`
Earliest22=`expr $(expr $Earliest2 / $hundred) + 1`
Latest11=`expr $Latest1 / $hundred`
if [ "$Latest2" -ge "2300" ]; then
  Latest22="0"
else
  Latest22=`expr $(expr $Latest2 / $hundred) + 1`
fi

#在常用时间&&亮屏才运行。判断当前时候解锁设备。
#解锁：再判断当前时间是否是0-7点/7-使用最晚时间之间。在：执行淦云控脚本。不在：打开淦云控的所有禁止。
#未解锁：判断是否在白天常用时间点。在：执行淦云控脚本。不在：打开淦云控的所有禁止。
if [ $Lock_screen_state == "false" ]; then
  if [ "$H_time" -ge "0000" ] && [ "$H_time" -le "0700" ]; then
    if [ "$H_time" -ge "Earliest1" ] && [ "$H_time" -le "Earliest2" ]; then
      sh $ModuleAdd/Disable_cloud.sh
    elif [ "$H_time" -ge "0700" ] && [ "$H_time" -le "Latest2" ]; then
      sh $ModuleAdd/Disable_cloud.sh
    else
      sh $ModuleAdd/Enable_the_cloud.sh
    fi
  else
    if [ "$H_time" -ge "Latest1" ] && [ "$H_time" -le "Latest2" ]; then
      sh $ModuleAdd/Disable_cloud.sh
    else
      sh $ModuleAdd/Enable_the_cloud.sh
    fi
  fi
fi
#调用函数更新模块信息
Update_information