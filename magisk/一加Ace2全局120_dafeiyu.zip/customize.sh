ui_print "




—— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')


—— 面具版本$MAGISK_VER_CODE


—— 面具代号$MAGISK_VER




"
echo "

id=dafeiyu


name=一加Ace2全局120


version=全局120屏幕刷新率，录屏不锁60


versionCode=25210


author=大肥鱼


description=一加Ace2全局120 [刷入时间：$(date '+%g-%m-%d %H:%M:%S')] [等候您的重启…]
" > $MODPATH/module.prop
echo "$(date '+%g-%m-%d %H:%M:%S')" > $MODPATH/time