#!/system/bin/sh

JB=/data/adb/modules/mubei/mb/mb.sh
JB1=/data/adb/modules/mubei/mb/mb1.sh
JB2=/data/adb/modules/mubei/mb/mb2.sh

ps -ef|grep $JB|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  echo "进程$pid已杀……" 
  done
ps -ef|grep $JB1|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  echo "进程$pid已杀……"
  done    
ps -ef|grep $JB2|awk '{print $2}'|while read pid;
  do
  kill -9 $pid >/dev/null 2>&1
  echo "进程$pid已杀……"
  done  
  
mb_id="$(pgrep 'mb.sh' | wc -l)"
mb1_id="$(pgrep 'mb1.sh' | wc -l)"
mb2_id="$(pgrep 'mb2.sh' | wc -l)"

if [ "$mb_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mKill墓碑\e[0m正在运行！"
elif [ "$mb1_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v1墓碑\e[0m正在运行！"
elif [ "$mb2_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v2墓碑\e[0m正在运行！"
else
    echo "\n\e[31m墓碑已经关闭……！\e[0m"   
fi
