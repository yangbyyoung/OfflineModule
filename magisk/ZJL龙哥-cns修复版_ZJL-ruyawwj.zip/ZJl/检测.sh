zjlPath="${0%/*}/*/ZJL"
${zjlPath} -d