#!/sbin/sh

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}


print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 - MIUI版本: $MIUI  $Version
 ****************************
 "
}


on_install() {
path="/system/media/bootanimation.zip"
    if [ -e $path ];then
        unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
        echo "动画位置 ${path}"
        echo "修改成功"
        
        
		echo "- 是否安装彩蛋？(请选择)"
        echo "- 按音量键＋: “我要”"
        echo "- 按音量键－: “不要”"
        if [[ $(get_choose) == 0 ]];then
			echo "- 注意享受彩蛋"
		else 
		    echo "- 你错过了好东西"
		    rm -f "${MODPATH}/system/media/bootaudio.mp3"
		fi
 

    else
        echo "动画位置不在路径 ${path} 取消安装"
    fi
}

set_permissions() {
    set_perm_recursive  $MODPATH  0  0  0755  0644
}
