#!/system/bin/sh
MODDIR=${0%/*}
rm -rf /data/vendor/wlan_logs
