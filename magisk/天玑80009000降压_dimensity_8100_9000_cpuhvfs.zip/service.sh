MODDIR=${0%/*}
# MODDIR=/data/adb/modules/dimensity_8100_9000_hvfs

threshold=1300000
cpudvfs=/proc/cpudvfs/cpufreq_debug

# set_min_freq [0|1|2] [min_freq]
set_min_freq() {
  if [ "$1" == 0 ]; then
    cpu=0
  elif [ "$1" == 1 ]; then
    cpu=4
  elif [ "$1" == 2 ]; then
    cpu=7
  else
    return
  fi
  max_freq=$(awk -F ' ' '{print $1}' < /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_available_frequencies)
  if [[ "$2" -gt $threshold ]]; then
    echo "$cpu" $threshold "$max_freq" > $cpudvfs
    echo "$cpu" $threshold "$max_freq"
  else
    echo "$cpu" "$2" "$max_freq" > $cpudvfs
    echo "$cpu" "$2" "$max_freq"
  fi
}

sleep 90

# Get ready for the fun to begin
set_min_freq 0 1800000
set_min_freq 1 2400000
set_min_freq 2 2400000
sleep 0.5

insmod $MODDIR/cpuhvfs.ko
conf=/data/eem_offset.conf
# Write the CPU voltage offset value
if [[ -f $conf ]]; then
  grep '=' $conf | while read row
  do
    prop=$(echo $row | cut -f1 -d '=')
    value=$(echo $row | cut -f2 -d '=')
    if [ "$value" != '' ]; then
      case "$prop" in
        "little")
          echo 0 $value > /proc/eem/eem_offset
        ;;
        "middle")
          echo 1 $value > /proc/eem/eem_offset
        ;;
        "big")
          echo 2 $value > /proc/eem/eem_offset
        ;;
        "cci")
          echo 3 $value > /proc/eem/eem_offset
        ;;
      esac
    fi
  done
fi

# Apply the best minimum frequency
while read row
do
  case "$row" in
    "id:"*)
      i=$(echo $row | tr -cd '0-9')
      [[ $i == '0' ]] && continue
      # volt=$(echo "obase=16;$((num=10#$min_volt))" | bc)
      echo $((i-1)) ${min_freq}000
      set_min_freq $((i-1)) ${min_freq}000

      min_volt=''
      min_freq=''
    ;;
    *"[0]"*)
      continue
    ;;
    "["*)
      echo -n $row '  '
      voltage=$(echo "$row" | awk '{print substr($0,length-2,2)}')
      voltage=$(echo "obase=10;$((16#$voltage))" | bc)
      if [ "$min_volt" == '' ] || [ "$voltage" -lt "$min_volt" ]; then
        min_volt="$voltage"
        min_freq=$(echo $row | tr -cd '0-9 ' | awk -F ' ' '{print $2}')
      fi
    ;;
  esac
done < /proc/eem/eem_cur_volt
