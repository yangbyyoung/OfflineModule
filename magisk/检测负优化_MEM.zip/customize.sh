SKIPMOUNT=false
miui_version="`grep_prop ro.miui.ui.version.name`"
var_soc="`getprop ro.board.platform`"
model="`getprop ro.product.system.model`"
var_device="`getprop ro.product.device`"
var_version="`grep_prop ro.build.version.release`"
author="`grep_prop author $TMPDIR/module.prop`"
name="`grep_prop name $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
id="`grep_prop id $TMPDIR/module.prop`"
echo  "- *******************************"
[[ ! -n $model ]] && echo  "- 您的设备名称: $model"
[[ ! -n $var_device ]] && echo  "- 您的设备: $var_device"
[[ ! -n $var_version ]] && echo  "- 系统版本: $var_version"
[[ ! -n $miui_version ]] && echo  "- miui版本: $miui_version"
[[ ! -n $var_soc ]] && echo  "- 您的处理器: $var_soc"
[[ ! -n $name ]] && echo  "- $name    "
[[ ! -n $author ]] && echo  "- 作者：$author"
[[ ! -n $description ]] && echo  "- $description    "
echo  "- *******************************"
. $MODPATH/MEM_1.sh
. $MODPATH/MEM_2.sh
. $MODPATH/MEM_3.sh
. $MODPATH/IQ.sh
. $MODPATH/MEM_4.sh
. $MODPATH/MEM_5.sh
. $MODPATH/MEM_6.sh
abort "－模块不需要安装，后期我会考虑着制作一个禁用模块的模块？"

set_perm_recursive  $MODPATH  0  0  0755  0644

