#!/system/bin/sh
#酷安@主张
MODDIR=${0%/*}
BUSYBOXDIR=/data/adb/magisk/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
touch /storage/emulated/0/Android/powersave.txt
test -e $MODDIR/zhuzhang && {
	chmod -R 777 $MODDIR/zhuzhang
	until $(dumpsys deviceidle get screen) ;do
		sleep 4
	done
	for i in $MODDIR/zhuzhang/*.sh ;do
		$i 2> /dev/null
	done
}

crond -c $MODDIR/zhuzhang
