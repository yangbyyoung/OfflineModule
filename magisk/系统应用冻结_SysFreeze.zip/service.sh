#!/system/bin/sh
MODDIR=${0%/*}
#获取冻结包名
local packagename=`sed -e '/#/d' $MODDIR/冻结包名.prop`
#冻结应用
sleep 10
for i in $packagename
do
  pm disable $i 2>/dev/null
done
#写个日志
touch $MODDIR/freeze.log
echo "已冻结以下应用（如果手机里有的话）" > $MODDIR/freeze.log
echo "$packagename" >> $MODDIR/freeze.log
