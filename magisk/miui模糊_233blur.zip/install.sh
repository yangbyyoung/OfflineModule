
SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=false

REPLACE="
"
rm -rf /data/system/package_cache/*
