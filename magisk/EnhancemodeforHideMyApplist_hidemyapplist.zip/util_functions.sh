check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 23000 ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk v23+"
    abort    "*********************************************************"
  fi
}

enforce_install_from_magisk_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Some recovery has broken implementations, install with such recovery will finally cause module not working"
    ui_print "! Please install from Magisk app"
    abort "*********************************************************"
  fi
}