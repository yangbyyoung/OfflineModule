#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。

source "${0%/*}/util_functions.sh"

#zram块路径和配置路径
ZRAM="/sys/block/zram0"
ZRAM_DEV="/dev/block/zram0"

#swap大小
zram_size="$(show_value "ZRAM大小")"
#算法
algorithm="$(show_value "ZRAM算法")"
#内存限制大小
zram_limit_mem="$(show_value "ZRAM内存限制")"

function echo_zram_algorithm() {
local value="$algorithm"
	if test -f "$ZRAM/comp_algorithm" ;then
		echo "$(cat $ZRAM/comp_algorithm | sed 's/\[//g' | sed 's/\]//g' | tr '[:space:]' '\n' | grep "$value" )"
	else
		echo "lzo"
	fi
}

function mem_has_zram_mod() {
	if test -b "$ZRAM_DEV" ;then
		echo "true"
	else
		echo "false"
	fi
}

function mem_stop_zram() {
local just="$(cat /proc/swaps | grep "^/" | awk '{print $1}')"
test "$(mem_has_zram_mod)" = "false"  && return

if test "$just" != "" ;then
	for dev in $just
	do
		swapoff "$dev" 2>/dev/null
	done
else
	for dev in /dev/block/zram*
	do
		swapoff "$dev" 2>/dev/null
	done
fi
}

function mem_start_zram() {
	test "$(mem_has_zram_mod)" = "false" && return
	mem_stop_zram  2>/dev/null
	echo "1" > $ZRAM/reset
	test ! -z "$3" && echo "$3" > $ZRAM/comp_algorithm
	test ! -z "$1" && echo "$1" > $ZRAM/disksize
	test "$2" != "NO" && echo "$2" > $ZRAM/mem_limit
	mkswap $ZRAM_DEV
	swapon $ZRAM_DEV
	set_value "0" $ZRAM/queue/read_ahead_kb
}

function zram_get_size() {
local MemTotalStr=$(cat /proc/meminfo | grep MemTotal)
local MemTotalKB=${MemTotalStr:16:8}
if test $MemTotalKB -gt 10240000 ; then
	zram_size="2"
	algorithm="deflate"
elif test $MemTotalKB -gt 8388608 ; then
	zram_size="2"
elif test $MemTotalKB -gt 6291456 ; then
	zram_size="4"
elif test $MemTotalKB -gt 4194304 ; then
	zram_size="4"
elif test $MemTotalKB -gt 3145728 ; then
	zram_size="2"
elif test $MemTotalKB -gt 2097152 ; then
	zram_size="1"
else
	zram_size="2"
fi
}


function zram_set_level_auto() {
	zram_get_size
if test "$zram_size" = "0" ;then
	mem_stop_zram
elif test "$zram_size" = "0.5" ;then
	mem_start_zram 512M 160M "$(echo_zram_algorithm)"
elif test "$zram_size" = "1" ;then 
	mem_start_zram 1024M 360M "$(echo_zram_algorithm)"
elif test "$zram_size" = "2" ;then
	mem_start_zram 2560M 900M "$(echo_zram_algorithm)"
elif test "$zram_size" = "4" ;then
	mem_start_zram 4048M 1440M "$(echo_zram_algorithm)"
elif test "$zram_size" = "6" ;then
	mem_start_zram 6144M 2160M "$(echo_zram_algorithm)"
fi
}


if test "$zram_size" = "自动" ;then
	zram_set_level_auto
elif test "$zram_size" = "0" ;then
	mem_stop_zram
elif test "$zram_size" = "默认" ;then
	exit 0
else
	if test "$zram_limit_mem" != "默认" ;then
		mem_start_zram ""$zram_size"M" ""$zram_limit_mem"M" "$(echo_zram_algorithm)"
	else
		mem_start_zram ""$zram_size"M" "NO" "$(echo_zram_algorithm)"
	fi
fi


