MODDIR=${0%/*}
MODSDIR=$(dirname "$MODDIR")
if [ -d "$MODSDIR/riru_jshook" ] && [ -d "$MODSDIR/zygisk_jshook" ]; then
  if [ -f "$MODSDIR/riru_jshook/remove" ] && [ -f "$MODSDIR/zygisk_jshook/remove" ]; then
    rm -rf /data/adb/jshook
  fi
else
  rm -rf /data/adb/jshook
fi

rm -rf /data/adb/riru/modules/jshook
