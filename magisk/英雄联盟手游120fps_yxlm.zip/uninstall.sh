#!/sbin/sh

find /data/media/0/Android/data/com.tencent.lolm/files/SaveData/Local -name "Setting*" -exec rm -rf {} \;
rm -rf /data/media/0/Android/德玛西亚