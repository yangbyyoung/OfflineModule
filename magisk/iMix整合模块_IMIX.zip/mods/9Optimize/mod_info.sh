# 安装时显示的模块名称
mod_name="负优化：夕阳醉歌"
# 模块介绍
mod_install_desc="✨可以提升一定性能，使设备更为流畅，可能会导致音视频app些许bug"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"


# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
mkdir -p $MOD_FILES_DIR/system
cp -rf $MOD_FILES_DIR/system/* $MOD_FILES_DIR/system
    # 从文件附加值到 system.prop
    add_sysprop_file $MOD_FILES_DIR/system1.prop
    # 添加service.sh
    add_service_sh $MOD_FILES_DIR/service.sh
    # 添加post-fs-data.sh
    add_postfsdata_sh $MOD_FILES_DIR/post-fs-data.sh
    #添加key.sh
    add_key_sh $MOD_FILES_DIR/key.sh
    #添加WCNSS_qcom_cfg.sh
    add_wcnssqcomcfg_sh $MOD_FILES_DIR/WCNSS_qcom_cfg.sh
    #添加cp.sh
     #add_cp_sh $MOD_FILES_DIR/cp.sh
    #添加miui_thermal_set.sh
     add_miuithermalset_sh $MOD_FILES_DIR/miui_thermal_set.sh
    
    set_perm_recursive  $MOD_FILES_DIR  0  0  0755  0644
    
    return 0
}

mod_install_no()
{
    return 0
}