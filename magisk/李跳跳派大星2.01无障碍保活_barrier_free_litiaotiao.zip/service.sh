MODDIR=${0%/*}
chmod -R 777 $MODDIR/mod
crond -c $MODDIR/mod

sleep 5s
/system/bin/sh $MODDIR/permissions.sh
/system/bin/sh $MODDIR/barrier_free_litiaotiao.sh