# 𝘣𝘺 𝘤𝘤𝘢𝘦𝘰@ᴛɢ
ui_print "- by Han | $MODAUTH"
hosts=$(ls /data/adb/modules/*/system/etc/hosts | grep -v "$MODID")
if [ -n "$hosts" ]; then
	ui_print "退出安装，请卸载其他挂载hosts的模块"
	abort "$hosts"
else
	ui_print "继续安装：$MODNAME"
	ui_print "求大家点个赞"
	ui_print "闲聊/反馈：539544651"
fi
set_perm_recursive $MODPATH 0 0 0755 0755
