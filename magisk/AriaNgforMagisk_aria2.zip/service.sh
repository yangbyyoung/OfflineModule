#!/system/bin/sh

#程序路径
aria2="${0%/*}/core/bin/aria2c"
lighttpd="${0%/*}/core/bin/lighttpd"
aria2conf="${0%/*}/core/etc/aria2.conf"
lighttpdconf="${0%/*}/core/etc/lighttpd.conf"

#更新bt-tracker
busybox sed -i '/bt-tracker=/d' $aria2conf
while [ -z $(grep 'bt-tracker' $aria2conf|cut -d '=' -f 2) ];
do
busybox sed -i '/bt-tracker=/d' $aria2conf | echo "bt-tracker=`busybox wget --no-check-certificate -qO- https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_all.txt | busybox awk NF | busybox sed ":a;N;s/\n/,/g;ta"`" >>$aria2conf
done

#启动程序
$lighttpd -f $lighttpdconf
$aria2 --conf-path=$aria2conf -D
