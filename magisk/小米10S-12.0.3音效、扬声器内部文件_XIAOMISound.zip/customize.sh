##########################################################################################
#
# Magisk 模块配置脚本示例
# by topjohnwu
# 翻译: cjybyjk
#
##########################################################################################
##########################################################################################
#
# 说明:
#
# 1. 将你的文件放入 system 文件夹 (删除 placeholder 文件)
# 2. 将模块信息写入 module.prop
# 3. 在这个文件中进行设置 (config.sh)
# 4. 如果你需要在启动时执行命令, 请把它们加入 common/post-fs-data.sh 或 common/service.sh
# 5. 如果需要修改系统属性(build.prop), 请把它加入 common/system.prop
#
##########################################################################################

##########################################################################################
# 配置
##########################################################################################

# 如果你需要启用 Magic Mount, 请把它设置为 true
# 大多数模块都需要启用它
AUTOMOUNT=true

# 如果你需要加载 system.prop, 请把它设置为 true
PROPFILE=true

# 如果你需要执行 post-fs-data 脚本, 请把它设置为 true
POSTFSDATA=true

# 如果你需要执行 service 脚本, 请把它设置为 true
LATESTARTSERVICE=true
SKIPMOUNT=false
##########################################################################################
# 安装信息
##########################################################################################

# 在这里设置你想要在模块安装过程中显示的信息

print_modname() {
  ui_print "***********************"
  ui_print "MiSoundBOOST!!!!"
  ui_print "Design By Huber_HaYu And Big-chair"
  ui_print "***********************"
}

##########################################################################################
# 替换列表
##########################################################################################

# 列出你想在系统中直接替换的所有目录
# 查看文档，了解更多关于Magic Mount如何工作的信息，以及你为什么需要它

# 这是个示例
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里构建你自己的列表，它将覆盖上面的示例
# 如果你不需要替换任何东西，!千万不要! 删除它，让它保持现在的状态
REPLACE="
/system/bin/audioserver
/system/bin/audioshell_system
/system/etc/audio_diag.cfg
/system/etc/audio_effects.conf
/system/etc/init/audioserver.rc
/system/lib/android.hardware.audio.common@2.0.so
/system/lib/android.hardware.audio.common@2.0-util.so
/system/lib/android.hardware.audio.common@4.0.so
/system/lib/android.hardware.audio.common@4.0-util.so
/system/lib/android.hardware.audio.common@5.0.so
/system/lib/android.hardware.audio.common@5.0-util.so
/system/lib/android.hardware.audio.common@6.0.so
/system/lib/android.hardware.audio.common@6.0-util.so
/system/lib/android.hardware.audio.common-util.so
/system/lib/android.hardware.audio.effect@2.0.so
/system/lib/android.hardware.audio.effect@4.0.so
/system/lib/android.hardware.audio.effect@5.0.so
/system/lib/android.hardware.audio.effect@6.0.so
/system/lib/android.hardware.audio@2.0.so
/system/lib/android.hardware.audio@4.0.so
/system/lib/android.hardware.audio@5.0.so
/system/lib/android.hardware.audio@6.0.so
/system/lib/hw/audio.a2dp.default.so
/system/lib64/android.hardware.audio.common@2.0.so
/system/lib64/android.hardware.audio.common@2.0-util.so
/system/lib64/android.hardware.audio.common@4.0.so
/system/lib64/android.hardware.audio.common@4.0-util.so
/system/lib64/android.hardware.audio.common@5.0.so
/system/lib64/android.hardware.audio.common@5.0-util.so
/system/lib64/android.hardware.audio.common@6.0.so
/system/lib64/android.hardware.audio.common@6.0-util.so
/system/lib64/android.hardware.audio.common-util.so
/system/lib64/android.hardware.audio.effect@2.0.so
/system/lib64/android.hardware.audio.effect@4.0.so
/system/lib64/android.hardware.audio.effect@5.0.so
/system/lib64/android.hardware.audio.effect@6.0.so
/system/lib64/android.hardware.audio@2.0.so
/system/lib64/android.hardware.audio@4.0.so
/system/lib64/android.hardware.audio@5.0.so
/system/lib64/android.hardware.audio@6.0.so
/system/lib64/libnexralbody_audio.so
/system/lib64/hw/audio.a2dp.default.so
/system/vendor/bin/android.hardware.audio.service
/system/vendor/bin/audio-factory-test
/system/vendor/bin/audioflacapp
/system/vendor/bin/audioshell_service
/system/vendor/etc/a2dp_audio_policy_configuration.xml
/system/vendor/etc/android.hardware.audio.low_latency.xml
/system/vendor/etc/android.hardware.audio.pro.xml
/system/vendor/etc/audio_configs.xml
/system/vendor/etc/audio_configs_stock.xml
/system/vendor/etc/audio_effects.xml
/system/vendor/etc/audio_karaoke_list.xml
/system/vendor/etc/audio_platform_info.xml
/system/vendor/etc/audio_platform_info_intcodec.xml
/system/vendor/etc/audio_platform_info_qrd.xml
/system/vendor/etc/audio_policy_configuration.xml
/system/vendor/etc/audio_policy_engine_configuration.xml
/system/vendor/etc/audio_policy_engine_configuration_mi.xml
/system/vendor/etc/audio_policy_engine_default_stream_volumes.xml
/system/vendor/etc/audio_policy_engine_default_stream_volumes_mi.xml
/system/vendor/etc/audio_policy_engine_product_strategies.xml
/system/vendor/etc/audio_policy_engine_product_strategies_mi.xml
/system/vendor/etc/audio_policy_engine_stream_volumes.xml
/system/vendor/etc/audio_policy_engine_stream_volumes_mi.xml
/system/vendor/etc/audio_policy_volumes.xml
/system/vendor/etc/audio_tuning_mixer.txt
/system/vendor/etc/media_codecs_google_audio.xml
/system/vendor/etc/media_codecs_google_c2_audio.xml
/system/vendor/etc/media_codecs_vendor_audio.xml
/system/vendor/etc/r_submix_audio_policy_configuration.xml
/system/vendor/etc/audio/audio_policy_configuration.xml
/system/vendor/etc/init/android.hardware.audio.service.rc
/system/vendor/etc/permissions/android.hardware.audio.low_latency.xml
/system/vendor/etc/permissions/android.hardware.audio.pro.xml
/system/vendor/lib/android.hardware.audio.common@2.0-util.so
/system/vendor/lib/android.hardware.audio.common@4.0-util.so
/system/vendor/lib/android.hardware.audio.common@5.0-util.so
/system/vendor/lib/android.hardware.audio.common@6.0-util.so
/system/vendor/lib/android.hardware.audio.common-util.so
/system/vendor/lib/libbluetooth_audio_session.so
/system/vendor/lib/libbluetooth_audio_session_qti.so
/system/vendor/lib/libwebrtc_audio_preprocessing.so
/system/vendor/lib/vendor.qti.hardware.audiohalext@1.0.so
/system/vendor/lib/hw/android.hardware.audio.effect@2.0-impl.so
/system/vendor/lib/hw/android.hardware.audio.effect@4.0-impl.so
/system/vendor/lib/hw/android.hardware.audio.effect@5.0-impl.so
/system/vendor/lib/hw/android.hardware.audio.effect@6.0-impl.so
/system/vendor/lib/hw/android.hardware.audio@2.0-impl.so
/system/vendor/lib/hw/android.hardware.audio@4.0-impl.so
/system/vendor/lib/hw/android.hardware.audio@5.0-impl.so
/system/vendor/lib/hw/android.hardware.audio@6.0-impl.so
/system/vendor/lib/hw/audio.primary.default.so
/system/vendor/lib/hw/audio.primary.kona.so
/system/vendor/lib/hw/audio.r_submix.default.so
/system/vendor/lib/hw/vendor.qti.hardware.audiohalext@1.0-impl.so
/system/vendor/lib/hw/vendor.qti.hardware.bluetooth_audio@2.0-impl.so
/system/vendor/lib/modules/audio_adsp_loader.ko
/system/vendor/lib/modules/audio_apr.ko
/system/vendor/lib/modules/audio_bolero_cdc.ko
/system/vendor/lib/modules/audio_cs35l41.ko
/system/vendor/lib/modules/audio_hdmi.ko
/system/vendor/lib/modules/audio_machine_kona.ko
/system/vendor/lib/modules/audio_mbhc.ko
/system/vendor/lib/modules/audio_native.ko
/system/vendor/lib/modules/audio_pinctrl_lpi.ko
/system/vendor/lib/modules/audio_pinctrl_wcd.ko
/system/vendor/lib/modules/audio_platform.ko
/system/vendor/lib/modules/audio_q6.ko
/system/vendor/lib/modules/audio_q6_notifier.ko
/system/vendor/lib/modules/audio_q6_pdr.ko
/system/vendor/lib/modules/audio_rx_macro.ko
/system/vendor/lib/modules/audio_snd_event.ko
/system/vendor/lib/modules/audio_stub.ko
/system/vendor/lib/modules/audio_swr.ko
/system/vendor/lib/modules/audio_swr_ctrl.ko
/system/vendor/lib/modules/audio_tx_macro.ko
/system/vendor/lib/modules/audio_usf.ko
/system/vendor/lib/modules/audio_va_macro.ko
/system/vendor/lib/modules/audio_wcd_core.ko
/system/vendor/lib/modules/audio_wcd9xxx.ko
/system/vendor/lib/modules/audio_wcd938x.ko
/system/vendor/lib/modules/audio_wcd938x_slave.ko
/system/vendor/lib/modules/audio_wsa_macro.ko
/system/vendor/lib/modules/audio_wsa881x.ko
/system/vendor/lib/rfsa/adsp/capi_v2_aptX_CLHDAD_Speech_Decoder.so
/system/vendor/lib/rfsa/adsp/capi_v2_aptX_CLHDADV_Encoder.so
/system/vendor/lib/rfsa/adsp/capi_v2_cirrus_sp.so
/system/vendor/lib/rfsa/adsp/libapps_mem_heap.so
/system/vendor/lib/rfsa/adsp/libarcsoft_hdrplus_hvx_skel.so
/system/vendor/lib/rfsa/adsp/libbitml_nsp_skel.so
/system/vendor/lib/rfsa/adsp/libcalculator_domains_skel.so
/system/vendor/lib/rfsa/adsp/libcalculator_skel.so
/system/vendor/lib/rfsa/adsp/libcamera_nn_skel.so
/system/vendor/lib/rfsa/adsp/libcvpdsp_skel.so
/system/vendor/lib/rfsa/adsp/libdsp_streamer_binning.so
/system/vendor/lib/rfsa/adsp/libdspCV_skel.so
/system/vendor/lib/rfsa/adsp/libfastcvadsp.so
/system/vendor/lib/rfsa/adsp/libfastcvdsp_skel.so
/system/vendor/lib/rfsa/adsp/libfrc_mobilenet.so
/system/vendor/lib/rfsa/adsp/libhexagon_nn_skel.so
/system/vendor/lib/rfsa/adsp/libMIAIHDR_skel.so
/system/vendor/lib/rfsa/adsp/libmialgo_rfs_cdsp_skel.so
/system/vendor/lib/rfsa/adsp/libmobilenet_dsp.so
/system/vendor/lib/rfsa/adsp/libQ6MSFR_manager_skel.so
/system/vendor/lib/rfsa/adsp/libremosaichvx_skel.so
/system/vendor/lib/rfsa/adsp/libscveObjectSegmentation_skel.so
/system/vendor/lib/rfsa/adsp/libscveT2T_skel.so
/system/vendor/lib/rfsa/adsp/libsnpe_dsp_domains_skel.so
/system/vendor/lib/rfsa/adsp/libsnpe_dsp_skel.so
/system/vendor/lib/rfsa/adsp/libsnpe_dsp_v65_domains_v2_skel.so
/system/vendor/lib/rfsa/adsp/libsnpe_dsp_v66_domains_v2_skel.so
/system/vendor/lib/rfsa/adsp/libsns_device_mode_skel.so
/system/vendor/lib/rfsa/adsp/libsns_low_lat_stream_skel.so
/system/vendor/lib/rfsa/adsp/libSuperSensor_skel.so
/system/vendor/lib/rfsa/adsp/misound_karaoke_res.bin
/system/vendor/lib/rfsa/adsp/misound_karaokemix_res.bin
/system/vendor/lib/rfsa/adsp/misound_res.bin
/system/vendor/lib/rfsa/adsp/misound_res_headphone.bin
/system/vendor/lib/rfsa/adsp/misound_res_spk.bin
/system/vendor/lib64/hw/android.hardware.audio.effect@2.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio.effect@4.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio.effect@5.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio.effect@6.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio@2.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio@4.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio@5.0-impl.so
/system/vendor/lib64/hw/android.hardware.audio@6.0-impl.so
/system/vendor/lib64/hw/android.hardware.bluetooth.audio@2.0-impl.so
/system/vendor/lib64/hw/audio.primary.default.so
/system/vendor/lib64/hw/audio.primary.kona.so
/system/vendor/lib64/hw/audio.r_submix.default.so
/system/vendor/lib64/hw/audio.usb.default.so
/system/vendor/lib64/hw/vendor.qti.hardware.audiohalext@1.0-impl.so
/system/vendor/lib64/rfsa/adsp/libsns_device_mode_skel.so
/system/vendor/lib64/rfsa/adsp/libsns_low_lat_stream_skel.so
/system/vendor/lib64/android.hardware.audio.common@2.0-util.so
/system/vendor/lib64/android.hardware.audio.common@4.0-util.so
/system/vendor/lib64/android.hardware.audio.common@5.0-util.so
/system/vendor/lib64/android.hardware.audio.common@6.0-util.so
/system/vendor/lib64/android.hardware.audio.common-util.so
/system/vendor/lib64/libbluetooth_audio_session.so
/system/vendor/lib64/libbluetooth_audio_session_qti.so
/system/vendor/lib64/libwebrtc_audio_preprocessing.so
/system/vendor/lib64/vendor.qti.hardware.audiohalext@1.0.so
"

##########################################################################################
# 权限设置
##########################################################################################

set_permissions() {
  # 只有一些特殊文件需要特定的权限
  # 默认的权限应该适用于大多数情况

  # 下面是 set_perm 函数的一些示例:

  # set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755        0644

  # set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000      0755       u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000      0755       u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0         0644

  # 以下是默认权限，请勿删除
  set_perm  $MODPATH/system/priv-app/MusicFX/MusicFX.apk  0  0  0644
}

##########################################################################################
# 自定义函数
##########################################################################################

# 这个文件 (config.sh) 将被安装脚本在 util_functions.sh 之后 source 化(设置为环境变量)
# 如果你需要自定义操作, 请在这里以函数方式定义它们, 然后在 update-binary 里调用这些函数
# 不要直接向 update-binary 添加代码，因为这会让你很难将模块迁移到新的模板版本
# 尽量不要对 update-binary 文件做其他修改，尽量只在其中执行函数调用

