## box4magisk 更新日志

### v1.0.0
- 支持 tailscaled.state 更新时保存，防止丢失登录状态
- 支持 tailscale 命令，用于查看状态，连接和断开连接
