#!/system/bin/sh


#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

#今日步数
function show_steps(){
today="$(date -d "$(date +%Y-%m-%d)" +%s)000"
local number=0
local count="$(content query --uri content://com.miui.providers.steps/item --projection _steps --where "_end_time>"$today"" 2>/dev/null | cut -d'=' -f2 )"
test "$(echo "$count" | sed '/^#/d;/^[[:space:]]*$/d' | grep -w '^[[:digit:]]*$')" = "" && count="0"
for i in $count
do
	((number+=i))
done
echo "$number"
}

#修复描述消失
function check_description() {
local description_file="${MODPATH}/module.prop"
local count="$(cat $description_file | grep "^description=" | wc -l)"
local count_all="$(cat $description_file | wc -l)"
if test $count -lt 1 ;then 
	sed -i "/^description=/d" "$description_file"
	sed -i ""$count_all"i description=[已修复]因意外关闭导致的模块描述消失😂！" "$description_file"
	sed -i '/^[[:space:]]*$/d' "$description_file"
fi
}


function mod_steps(){
#间隔时间
interval_time="$(show_value "假装时间")"
time_last="$(($(date +%s) - $interval_time + $(echo $RANDOM%10 )))"

#增加的步数
step="$(show_value "步数")"
steps="$(($step + $(echo $RANDOM%50 )))"

#获取最新id
old_id=`content query --uri content://com.miui.providers.steps/item --projection _id --sort "_id DESC"  | cut -d'=' -f2 | sort -n | tail -n 1 `
target_id="$(($old_id+1))"

#运行步数修改
content insert --uri content://com.miui.providers.steps/item --bind _begin_time:s:"$time_last"000 --bind _id:i:$target_id --bind _end_time:s:`date +%s`999 --bind _mode:i:2 --bind _steps:i:$steps
}

#写入模块信息和运行步数增加
function write_module_info_main(){
local target_file="$MODPATH/module.prop"
	check_description
if test "$(echo $(show_value "步数限制") | grep -w '^[[:digit:]]*$')" = "";then
#运行增加步数
	mod_steps
	sed -i "/^description=/c description=今日步数 [ $(show_steps) ]，$(date +%T) 随机增加步数 [ $steps ]。" "${target_file}"
	return 0
else
	if test "$(show_steps)" -ge "$(show_value "步数限制")" ;then
			sed -i "/^description=/c description=今日步数 [ $(show_steps) ]，已经到最大步数限制 [ $(show_value "步数限制") ]，已停止增加！" "${target_file}"
		exit 0
	else
			mod_steps
		sed -i "/^description=/c description=今日步数 [ $(show_steps) ]，$(date +%T) 随机增加步数 [ $steps ]，最大步数限制在 [ $(show_value "步数限制") ]步。" "${target_file}"
	fi
fi
}

if test -e $MODPATH/disable -o -e $MODPATH/remove -o -e "${MODPATH%/*}/steps_MIUI_key_add/disable" -o -e "${MODPATH%/*}/steps_MIUI_key_add/remove" ; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，今日步数 [ $(show_steps) ]，您已选择手动停止模块！" "${MODPATH%/*}/steps_MIUI_key_add/module.prop"
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

if test ! -e "${MODPATH%/*}/steps_MIUI_key_add/disable" -a ! -e "${MODPATH%/*}/steps_MIUI_key_add/remove" ; then
	sed -i "/^description=/c description=手动停用该模块，可以暂停步数模块运行！" "${MODPATH%/*}/steps_MIUI_key_add/module.prop"
fi

#写入模块信息
write_module_info_main
