#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。

source "${0%/*}/util_functions.sh"

# kernel reclaim threads run on more power-efficient cores
change_task_nice "kswapd" "-2"
change_task_nice "oom_reaper" "-2"
change_task_affinity "kswapd" "7f"
change_task_affinity "oom_reaper" "7f"
change_task_cgroup "kswapd" "foreground" "cpuset"
change_task_cgroup "oom_reaper" "foreground" "cpuset"

# treat crtc_commit as background, avoid display preemption on big
change_task_cgroup "crtc_commit" "background" "cpuset"

# fix laggy bilibili feed scrolling
change_task_cgroup "servicemanager" "top-app" "cpuset"
change_task_cgroup "servicemanager" "foreground" "stune"
change_task_cgroup "android.phone" "top-app" "cpuset"
change_task_cgroup "android.phone" "foreground" "stune"

# treat surfaceflinger as top-app, foreground is restricted by uperf
change_task_cgroup "surfaceflinger" "top-app" "cpuset"
change_task_cgroup "surfaceflinger" "foreground" "stune"

# fix system_server in /dev/stune/top-app/cgroup.procs
change_proc_cgroup "system_server" "top-app" "cpuset"
change_proc_cgroup "system_server" "foreground" "stune"

# ...but exclude UI related
change_thread_cgroup "system_server" "android.anim" "top-app" "stune"
change_thread_cgroup "system_server" "android.anim.lf" "top-app" "stune"
change_thread_cgroup "system_server" "android.ui" "top-app" "stune"
# ...and pin HeapTaskDaemon on LITTLE
change_thread_cgroup "system_server" "HeapTaskDaemon" "background" "cpuset"

# reduce big cluster wakeup, eg. android.hardware.sensors@1.0-service
change_task_cgroup ".hardware." "background" "cpuset"
change_task_affinity ".hardware." "0f"

# ...but exclude fingerprint&camera&display service for speed
change_task_cgroup ".hardware.biometrics.fingerprint" "" "cpuset"
change_task_cgroup ".hardware.camera.provider" "" "cpuset"
change_task_cgroup ".hardware.display" "" "cpuset"
change_task_affinity ".hardware.biometrics.fingerprint" "ff"
change_task_affinity ".hardware.camera.provider" "ff"
change_task_affinity ".hardware.display" "ff"

# provide best performance for fingerprint service
change_task_cgroup ".hardware.biometrics.fingerprint" "rt" "stune"
change_task_nice ".hardware.biometrics.fingerprint" "-20"

