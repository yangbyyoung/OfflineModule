#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。

source "${0%/*}/util_functions.sh"

#指定交换分区的积极性
function set_swappiness () {
	local swappiness="$1"
	set_value $swappiness /proc/sys/vm/swappiness
	set_value $swappiness /dev/memcg/memory.swappiness
	set_value $swappiness /dev/memcg/apps/memory.swappiness
	set_value $swappiness /sys/fs/cgroup/memory/apps/memory.swappiness
	set_value $swappiness /sys/fs/cgroup/memory/memory.swappiness
}

#设置lmk参数
function set_lmk_params() {
	local lowmemorykiller='/sys/module/lowmemorykiller/parameters'
	local sdk=$(getprop ro.system.build.version.sdk)
	local MemTotalStr=$(cat /proc/meminfo | grep MemTotal)
	local MemTotalKB=${MemTotalStr:16:8}
	local adj1="$1"
	local adj2="$2"
	local adj3="$3"
	local adj4="$4"
	local adj5="$5"
	local adj6="$6"
	test -z "$1" && echo "你™倒是修改啊！"

#lmk杀后台阈值，单位是bytes(字节)，最少的整数是4，0则代表用尽内存。
#当输入disable时，则禁用杀后台
#以4096:0,5120:128,8192:256,32768:512,56320:800,71680:1001为例
# ":" 的前面是剩余内存值(level)，":"后面是系统分配(计算)的运行先后等级(adj)
# "," 则是分隔符
#杀后台的逻辑
#以 "4096:0" 为例 
#当level，也就是当剩余内存等于"4096"时，就会杀死adj大于"0"的应用
#以此类推，"5120:128" 则代表 
#当level，也就是当剩余内存等于"5120"时，就会杀死adj大于"128"的应用
#adj越小，越不会被杀死，数值可以为负数，"0"则代表当前页面的应用(顶层)
#而最大值为1000，所以 "71680:1001" 则代表
#当剩余内存等于"71680"，系统也不会杀后台，因为不存在1001这个进程。
#这些都是理论上的，具体还得看内核和系统有没有魔改
if test "$7" = "disable" -o "$1" = "disable" ;then
	local level1="0"
	local level2="0"
	local level3="0"
	local level4="0"
	local level5="0"
	local level6="0"
		local adj1="1001"
		local adj2="1001"
		local adj3="1001"
		local adj4="1001"
		local adj5="1001"
		local adj6="1001"
else
		if test $MemTotalKB -gt 8388608 ; then
			local level1="4096"
			local level2="5120"
			local level3="32768"
			local level4="96000"
			local level5="131072"
			local level6="204800"
			local efk="204800"
		elif test $MemTotalKB -gt 6291456 ; then
			local level1="4096"
			local level2="5120"
			local level3="8192"
			local level4="32768"
			local level5="96000"
			local level6="131072"
			local efk="128000"
		elif test $MemTotalKB -gt 4194304 ; then
			local level1="4096"
			local level2="5120"
			local level3="8192"
			local level4="32768"
			local level5="56320"
			local level6="71680"
			local efk="102400"
		elif test $MemTotalKB -gt 3145728 ; then
			local level1="4096"
			local level2="5120"
			local level3="8192"
			local level4="24576"
			local level5="32768"
			local level6="47360"
			local efk="76800"
		elif test $MemTotalKB -gt 2097152 ; then
			local level1="4096"
			local level2="5120"
			local level3="8192"
			local level4="16384"
			local level5="24576"
			local level6="39936"
			local efk="51200"
		else
			local level1="4096"
			local level2="5120"
			local level3="8192"
			local level4="10240"
			local level5="16384"
			local level6="24576"
			local efk="25600"
	fi
fi

	set_value "$level1,$level2,$level3,$level4,$level5,$level6" "$lowmemorykiller/minfree"
	set_value "53059" "$lowmemorykiller/vmpressure_file_min"
	set_value "0" "$lowmemorykiller/enable_adaptive_lmk"
	set_value "1" "$lowmemorykiller/oom_reaper"
	set_value "$adj1,$adj2,$adj3,$adj4,$adj5,$adj6" "$lowmemorykiller/adj"
	set_value "4096" "$lowmemorykiller/cost"
	#set_value "0" "/proc/sys/vm/extra_free_kbytes"
	set_value "$efk" "/proc/sys/vm/extra_free_kbytes"
	set_value "0" "/sys/module/process_reclaim/parameters/enable_process_reclaim"

		local minfree_levels="$level1:$adj1,$level2:$adj2,$level3:$adj3,$level4:$adj4,$level5:$adj5,$level6:$adj6"
		resetprop sys.lmk.minfree_levels "$minfree_levels"
		setprop sys.lmk.minfree_levels "$minfree_levels" 
		if test "$(getprop sys.lmk.minfree_levels)" != "$minfree_levels" ;then
			resetprop sys.lmk.minfree_levels "$minfree_levels"
			setprop sys.lmk.minfree_levels "$minfree_levels"
				sleep 3m
			resetprop sys.lmk.minfree_levels "$minfree_levels"
			setprop sys.lmk.minfree_levels "$minfree_levels"
		fi
}


#开始运行

if test "$(echo $(show_value "交换分区数值") | grep -w '^[[:digit:]]*$')" != "" ;then
	set_swappiness "$(show_value "交换分区数值")"
fi

if test $(show_value "lmk阈值") == 自动 ;then
	( set_lmk_params "0" "128" "256" "512" "800" "1001" ) &
elif test $(show_value "lmk阈值") == 关闭 ;then
	( set_lmk_params "disable" ) &
elif test $(show_value "lmk阈值") == 手动 ;then
	( set_lmk_params ) &
else
	return 0
fi



