#!/system/bin/sh
MODDIR=${0%/*}

LIBFEAS_64="${MODDIR}/lib/libfeas_64.so"
LIBFEAS_32="${MODDIR}/lib/libfeas_32.so"
LIB_TARGET_NAME="libperf_ctl.so"

copyTo() {
    local FILE_PATH=$1
    local FILE_PART_PATH=$2
    local LIB_TARGET_DIR="${MODDIR}/${FILE_PART_PATH}"
    local LIB_TARGET_FILE="${LIB_TARGET_DIR}/${LIB_TARGET_NAME}"
    #local MODULES_TARGET_PART=""
    [ ! -d "${LIB_TARGET_DIR}" ] && mkdir -p "${LIB_TARGET_DIR}"
    cp -af "${FILE_PATH}" "${LIB_TARGET_FILE}"
    touch -c -d "2009-01-01 08:00:00" "${LIB_TARGET_FILE}"
}

copyModuleFileTo() {
    local MODULE_PART=$1
    if [ -n "${MODULE_PART}" ]; then
        copyTo "${LIBFEAS_64}" "${MODULE_PART}/lib64"
        copyTo "${LIBFEAS_32}" "${MODULE_PART}/lib"
    fi
}

copyModule() {
    local moduleCopySuccess="false"
    [ -f "/product/lib64/${LIB_TARGET_NAME}" ] && copyModuleFileTo "/system/product" && moduleCopySuccess="true"
    [ -f "/system/lib64/${LIB_TARGET_NAME}" ] && copyModuleFileTo "/system" && moduleCopySuccess="true"
    [ -f "/system_ext/lib64/${LIB_TARGET_NAME}" ] && copyModuleFileTo "/system/system_ext" && moduleCopySuccess="true"
    [ -f "/vendor/lib64/${LIB_TARGET_NAME}" ] && copyModuleFileTo "/system/vendor" && moduleCopySuccess="true"
    [ -f "/odm/lib64/${LIB_TARGET_NAME}" ] && copyModuleFileTo "/system/odm" && moduleCopySuccess="true"
    if [ "${moduleCopySuccess}" != "true" ]; then
        copyModuleFileTo "/system"
        resetprop ro.feas.special true
    fi
}

fixSelinuxLabel() {
    local policyBin="${MODDIR}/bin/magiskpolicy --live "
    local sepolicyFile="${MODDIR}/sepolicy.txt"

    #${policyBin} "allow zygote properties_serial file { open read write getattr }"
    #${policyBin} "allow zygote default_prop file { open read write getattr }"

    ${policyBin} "allow zygote init unix_stream_socket connectto"
    ${policyBin} "allow zygote property_socket sock_file write"
    ${policyBin} "allow zygote default_prop property_service set"

    if [ -f "${sepolicyFile}" ] && [ -d "/proc/perfmgr" ] && [ -d "/sys/module/perfmgr" ]; then
        local selabel="$(ls -Z /proc/perfmgr/perf_ioctl)"
        if [ "${selabel}" != "u:object_r:proc_perfmgr:s0 /proc/perfmgr/perf_ioctl" ]; then
            while read line
            do
                ${policyBin} "${line}"
            done < $sepolicyFile
        fi
    fi
}

copyModule
fixSelinuxLabel
