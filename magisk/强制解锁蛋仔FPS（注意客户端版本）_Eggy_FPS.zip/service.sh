#!/bin/bash

if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi

script_content='
sync
#!/system/bin/sh

#自定义函数
function notification_simulation(){
#标题
local title="${2}"
#内容
local text="${1}"

#也许会限制字数
	test -z "${title}" && title='\''蛋仔'\''  # 使用 '\'' 来转义单引号
	test -z "${text}" && text='\''您未给出任何信息'\''  # 使用 '\'' 来转义单引号
#运行
#其他合适在终端输入 su -c cmd notification post help查看。
su -lp 2000 -c "cmd notification post -S messaging --conversation '\''${title}'\'' --message '\''${title}':'${text}'\'' '\''Tag'\'' '\''$(echo $RANDOM)'\'' " >/dev/null 2>&1

#su -lp $(dumpsys package "com.coolapk.market" | grep userId | uniq | tr -cd '\''[0-9]'\'' | head -n 1) -c "cmd notification post -S messaging --conversation '\''${title}'\'' --message '\''${title}':'${text}'\'' '\''Tag'\'' '\''$(echo $RANDOM)'\'' " >/dev/null 2>&1
}


#notification_simulation '\''你好'\''  # 使用 '\'' 来转义单引号

result=$(dumpsys window | grep mCurrentFocus)

if [[ $result == *"com.netease.party"* ]]; then

    # Check the output of the command
    output=$(/data/dan | grep value)

    if [[ $output == *"value = 30"* || $output == *"value = 60"* ]]; then
    
        notification_simulation '\''修改成功'\''  # 使用 '\'' 来转义单引号
        
    elif [[ $output == *"value = 9999"* ]]; then
        # No action needed
        :
    else
        notification_simulation '\''蛋仔修改失败，请检查'\''  # 使用 '\'' 来转义单引号
    fi
fi'

# 当前目录
current_dir="$(dirname "$0")"

# 创建目录
mkdir 777 /data/dancron.d

# 复制文件到目标目录
cp "$current_dir/dan" "/data/"

# 创建定时任务文件
echo "* * * * * /data/dancron.sh" > /data/dancron.d/root

# 设置文件权限
chmod 777 -R /data/dancron.d/root

# 创建并写入定时执行脚本
echo "$script_content" > "/data/dancron.sh"

# 设置脚本权限
chmod 777 -R /data/dancron.sh

# 启动crond定时进程
crond -c /data/dancron.d


