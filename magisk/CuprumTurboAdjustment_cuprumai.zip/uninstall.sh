#!/sbin/sh
rm -rf /data/CuprumTurbo_Lib/ #Before V3.0.4 beta
rm -rf /data/Cuprum_Custom/
rm -rf /data/Cuprum_Log.txt
rm -rf /data/taskclassify_log.txt
pm uninstall com.chenzyadb.cuplus
exit 0