sh /data/adb/modules/power_saving_die/uninstall.sh
rm -rf /data/adb/modules/power_saving_die
touch $MODPATH/SakikoPower.conf
echo "- 以下是选择功能安装，请按音量+或音量-选择 "

echo "- 是否禁用谷歌服务？ "
echo "- 音量+：禁用 "
echo "- 音量-：不禁用 "
volume=1
action=1
sleep 0.5
echo "  请根据提示按音量键进行选择！ "
while [ $volume == 1 ]; do
    action=`getevent -lqc 1`
    if [[ "${action}" == "*KEY_VOLUMEUP*" ]]; then
        volume=0
        echo "- 禁用 "
        echo "禁用谷歌服务=true" >> $MODPATH/SakikoPower.conf
    elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]]; then
        volume=0
        echo "- 不禁用 "
        echo "禁用谷歌服务=false" >> $MODPATH/SakikoPower.conf
    fi
done

echo "- 是否开启电池优化？ "
echo "- 音量+：开启 "
echo "- 音量-：不开启 "
volume=1
action=1
sleep 0.5
echo "  请根据提示按音量键进行选择！ "
while [ $volume == 1 ]; do
    action=`getevent -lqc 1`
    if [[ "${action}" == "*KEY_VOLUMEUP*" ]]; then
        volume=0
        echo "- 开启 "
        echo "开启电池优化=true" >> $MODPATH/SakikoPower.conf
        echo "- 已开启电池优化，配置目录: /data/battery_optimization.conf "
    elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]]; then
        volume=0
        echo "- 不开启 "
        echo "开启电池优化=false" >> $MODPATH/SakikoPower.conf
    fi
done

echo "- 是否关闭模块日志？ "
echo "- 音量+：关闭 "
echo "- 音量-：不关闭 "
volume=1
action=1
sleep 0.5
echo "  请根据提示按音量键进行选择！ "
while [ $volume == 1 ]; do
    action=`getevent -lqc 1`
    if [[ "${action}" == "*KEY_VOLUMEUP*" ]]; then
        volume=0
        echo "- 关闭 "
        echo "关闭模块日志=true" >> $MODPATH/SakikoPower.conf
    elif [[ "${action}" == "*KEY_VOLUMEDOWN*" ]]; then
        volume=0
        echo "- 不关闭 "
        echo "关闭模块日志=false" >> $MODPATH/SakikoPower.conf
        echo "- 已开启模块日志，目录: /cache/SakikoPower.log "
    fi
done

echo "关闭两颗核心=true" >> $MODPATH/SakikoPower.conf
echo "使用省电调度=false" >> $MODPATH/SakikoPower.conf

echo "- 配置可更改，目录: /data/SakikoPower.conf "
echo "- 安装完成 "
