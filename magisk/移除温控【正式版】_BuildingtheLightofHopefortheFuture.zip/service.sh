#开机10秒后执行命令
sleep 10
#GPU温控墙 115度 极限120 到120会过热保护 
echo "115000" > /sys/class/thermal/thermal_zone32/trip_point_0_temp

#CPU温控墙 修改为99度 
echo "99000" >/sys/class/thermal/thermal_zone36/trip_point_0_temp

