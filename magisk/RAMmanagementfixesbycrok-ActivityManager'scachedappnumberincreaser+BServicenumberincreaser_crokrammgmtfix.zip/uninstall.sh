#!/system/bin/sh

# Delete Activity Manager's max. cached app number variable and system will use the Activity Manager's default
settings delete global activity_manager_constants

