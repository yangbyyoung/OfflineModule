# QuickSwitch Terminal Edition - Quickstep enabler for any supported launcher
QuickSwitch is a Magisk module which systemlessly enables Pie recents (Quickstep) in any supported launcher

## Donations:
- If you wish to donate to [Skittles9823](https://github.com/skittles9823) for making the module and handling support you can do so [here](https://paypal.me/Skittles2398).

## Disclaimer
- A full list of compatible launchers will not be provided as the module autodetects which launchers are compatible.
- Nova will likely never support QuickSwitch unless they decide to add support for the Razer Phone naitivly.

## Requirements:
- Magisk 18+
- Android 9.0 Pie +

## Installation
1. Flash this module.
2. Reboot.
3. Open a terminal app and execute the command `su -c quickswitch`
4. Select a different launcher as your recents provider.
5. Reboot.
6. Verify your new recents provider is correct.
7. Set the new recents provider as the default launcher.
8. Profit.

## Debugging
- The `quickswitch` command has a built in logging function which will save all logs to /sdcard/Documents/quickswitch-terminal/
- All logs begin with **quickswitch-terminal**
- If you have any issues, please join the [Telegram group](https://t.me/QuickstepSwitcherSupport) and send the logs along with what your issue is.

## Sources and used/needed tools:
- [Module Source](https://github.com/skittles9823/QuickSwitch-Terminal)
- [Magisk](https://github.com/topjohnwu/Magisk) by [topjohnwu](https://forum.xda-developers.com/member.php?u=4470081)
- [Magisk Module Template](https://github.com/topjohnwu/magisk-module-template) by [topjohnwu](https://forum.xda-developers.com/member.php?u=4470081)
- [mod-util](https://github.com/veez21/mod-util) by [veez21@XDA-Developers](https://forum.xda-developers.com/member.php?u=7296895)

## Thanks to
- [Paphonb](https://github.com/paphonb), for being the main brains behind the module, and much more.
- [The Lawnchair team](https://t.me/lawnchairci), for testing QuickSwitch.
- [The Hyperion team](https://play.google.com/store/apps/details?id=projekt.launcher), for helping test QuickSwitch.
- [veez21@XDA-Developers](https://forum.xda-developers.com/member.php?u=7296895), for certain snippets of code which I couldn't figure out. 

## Support
You can get support for the module in either the [Telegram group](https://t.me/QuickstepSwitcherSupport) or the [XDA Thread](https://forum.xda-developers.com/apps/magisk/module-quickswitch-universal-quickstep-t3884797/).

## Changelog:
### v1.0.0
- initial release