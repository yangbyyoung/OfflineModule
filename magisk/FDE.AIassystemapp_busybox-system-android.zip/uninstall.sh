#!/system/bin/sh

on_remove() {
    pm clear com.feravolt.fdeai >/dev/null 2>&1
	sleep 2;
    rm -Rf /data/data/com.feravolt.fdeai
}

(on_remove &)
