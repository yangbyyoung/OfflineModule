settings put global settings_system_harman_kardon_enable 1

mkdir -p $MODPATH/system/product/etc/device_features
cp -rf /system/product/etc/device_features/* $MODPATH/system/product/etc/device_features

sed -i '/<\/features>/i\
    <bool name="support_dc_backlight">true<\/bool>\
    <bool name="support_secret_dc_backlight">false<\/bool>\
    <bool name="support_smart_fps">true</bool>\
    <integer name="smart_fps_value">120</integer>\
    <integer-array name="fpsList">\
        <item>144<\/item>\
        <item>120<\/item>\
        <item>90<\/item>\
        <item>60<\/item>\
    <\/integer-array>' \
$MODPATH/system/product/etc/device_features/*
