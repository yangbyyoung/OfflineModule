busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
kernelbusybox=`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1`
if test -f "${magiskbusybox}" ;then
chmod 0777 "${magiskbusybox}"
	mkdir -p "${busyboxdir}"
	echo "－ 安装Magisk的busybox 中……"
${magiskbusybox} --install -s ${busyboxdir} && echo "－ 完成！" || abort "－ 错误！"
elif test -f "${kernelbusybox}" ;then
chmod 0777 "${kernelbusybox}"
	mkdir -p "${busyboxdir}"
	echo "－ 安装Magisk的busybox 中……"
${kernelbusybox} --install -s ${busyboxdir} && echo "－ 完成！" || abort "－ 错误！"
else
	abort "－ 您的magisk busybox 怎么不见了？"
fi

CROND_FILE=$MODPATH/crond/setupcrond.sh
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
test "${Magisk_mod}" != "" && sed -i "1i MODPATH=\/data\/adb\/$Magisk_mod\/$id" "${CROND_FILE}"

