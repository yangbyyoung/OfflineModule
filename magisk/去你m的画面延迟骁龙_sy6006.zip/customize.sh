SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
D="`grep_prop description $TMPDIR/module.prop`"
ui_print "- *******************************"
ui_print "- $C    "
ui_print "- 作者：$B"
ui_print "- $D    "
ui_print "- 安装好了呢"
ui_print "- *******************************"

set_perm_recursive  $MODPATH  0  0  0755  0777



