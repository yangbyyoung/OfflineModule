MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    [ ! -f "$2" ] && return
    umount "$2"

    chown root:root "$2"
    chmod 0666 "$2"
    echo "$1" >"$2"
    chmod 0444 "$2"

    local TIME=$(date +"%s%N")
    echo "$1"  > /dev/mount_mask_$TIME
    mount --bind /dev/mount_mask_$TIME "$2"
    rm /dev/mount_mask_$TIME
}

disable_userspace_boost() {
    lock_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
    lock_val "0" /sys/module/mtk_fpsgo/parameters/boost_affinity
    lock_val "0" /sys/module/fbt_cpu/parameters/boost_affinity
    lock_val "0" /sys/kernel/fpsgo/minitop/enable

    for i in $(seq 0 7); do
        lock_val "0" /sys/devices/system/cpu/cpu$i/core_ctl/enable
    done
}

while [ ! -d "/sdcard/Android" ]; do
    sleep 1
done

disable_userspace_boost
killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
