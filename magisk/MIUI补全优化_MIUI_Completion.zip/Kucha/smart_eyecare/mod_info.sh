# 安装时显示的模块名称
mod_name="纸质护眼+调节色温+真彩显示"
mod_install_desc="✨$mod_name"
# 安装时显示的提示
mod_install_info="是否安装$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
#纸质护眼+色温调节
source $TMPDIR/features.sh
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*

#纸质护眼数据
sed -i 's/<bool name=\"paper_eyecare_default_value\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_value\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_default_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_min_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_min_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_max_texture\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"paper_eyecare_max_texture\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_value\">91.0<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_value\">91.0<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_texture\">18<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_default_texture\">18<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_min_texture\">0<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_min_texture\">0<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_max_texture\">35<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"paper_eyecare_max_texture\">35<\/bool>' $MODPATH/system/etc/device_features/*


#真彩显示
sed -i 's/<bool name=\"support_truetone\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_truetone\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_truetone\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_truetone\">true<\/bool>' $MODPATH/system/etc/device_features/*

    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}
