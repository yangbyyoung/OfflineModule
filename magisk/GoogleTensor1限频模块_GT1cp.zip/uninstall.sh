#!/system/bin/sh
rm -rf /data/cron.d
rm -rf /data/crn.sh
rm -rf /data/adb/modules/GT1cp