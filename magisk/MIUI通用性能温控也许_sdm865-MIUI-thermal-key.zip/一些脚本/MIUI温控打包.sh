#!/system/bin/sh

test "$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit

function correctpath(){
case `echo "$1" ` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}


TMPDIR="/data/local/tmp/thermal"
test -d "${TMPDIR}" && rm -rf "$TMPDIR"
mkdir -p "$TMPDIR"
echo -e "\n 查找温控中……"

for folder in `ls -d $(magisk --path)/.magisk/mirror/* | grep -v '/data'`
do
	find $folder -iname '*thermal*' -type f  2> /dev/null | while read file ;do
		before_file=` echo "${file}" | sed "s|$(magisk --path)/.magisk/mirror||g"`
		mod_file="$( correctpath "${before_file}" )"
		echo -e "\e[36m${mod_file}\e[0m"
			mkdir -p "$TMPDIR/${mod_file%/*}"
		cp -rf "$file" "$TMPDIR/${mod_file}"
	done
done

cd "$TMPDIR"
target_file="/sdcard/MIUI$(getprop ro.board.platform)温控.tar.gz"
mkdir -p "${target_file%/*}"
tar -czpf "$target_file" * && rm -rf "$TMPDIR" && echo -e "\n\e[32;40m温控文件已经输出到\e[0m \e[33;40m"$target_file"\e[0m \n"

