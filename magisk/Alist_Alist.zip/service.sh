#!/system/bin/sh
MODDIR=${0%/*}
chmod 777 $MODDIR/alist
$MODDIR/alist server --data $MODDIR/data&
sleep 25s
echo "PowerManagerService.noSuspend" > /sys/power/wake_lock
kill $(pgrep alist) &&
$MODDIR/alist server --data $MODDIR/data&