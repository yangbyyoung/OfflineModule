#!/system/bin/sh
MODDIR=${0%/*}
rm -rf /data/system/storage.xml