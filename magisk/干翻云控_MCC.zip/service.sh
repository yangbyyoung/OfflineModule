#!/system/bin/sh
MODPATH=/data/adb/modules/MCC/
#开机休眠
until [ $(getprop sys.boot_completed) == 1 ]; do
sleep 1
done

lock_val() {
    if [ -f "$2" ]; then
        chown root:root "$2"
        chmod 0666 "$2"
        echo "$1" >"$2"
        chmod 0444 "$2"

        touch /data/local/tmp/mount_mask_$1
        echo "$1" > /data/local/tmp/mount_mask_$1
        umount "$2"
        mount --bind /data/local/tmp/mount_mask_$1 "$2"
    fi
}
#电量和性能
pm disable com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
pm disable com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
#手机管家
pm disable com.miui.securitycenter/com.miui.permcenter.root.RootUpdateReceiver
pm disable com.miui.securitycenter/com.miui.antivirus.receiver.UpdaterReceiver
#耗电检测
pm disable com.xiaomi.powerchecker/com.xiaomi.powerchecker.cloudcontrol.CloudUpdateJobService
pm disable com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
#MIUI质量服务
pm disable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm disable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
#joyose
pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
pm disable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm disable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm disable com.miui.securitycenter/com.miui.apppredict.service.AppPredictService
pm disable com.miui.securitycenter/com.miui.apppredict.service.AiService
pm disable com.miui.powercenter/powersaver.PerformanceModeTileService
pm disable com.miui.gamebooster/beauty.BeautyService
pm disable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm disable com.miui.powercenter/powersaver.PerformanceModeTileService
pm disable com.miui.hybrid.settings/platform.PerformanceOptimizationActivity
pm uninstall -k --user 0 com.xiaomi.NetworkBoost
pm uninstall -k --user 0 com.miui.analytics
pm uninstall -k --user 0 com.miui.daemon

lock_val "0" "/sys/kernel/gbe/gbe_enable1"
lock_val "0" "/sys/kernel/gbe/gbe_enable2"
lock_val "0" "/sys/module/ged/parameters/boost_gpu_enable"
lock_val "0" "/sys/module/migt/parameters/boost_policy"
lock_val "0" "/proc/sys/walt/input_boost/*"
lock_val "0" "/sys/devices/system/cpu/cpu_boost/*"
lock_val "0" "/sys/devices/system/cpu/cpu_boost/parameters/*"
lock_val "0" "/sys/module/cpu_boost/parameters/*"
lock_val "0" "/sys/module/fbt_cpu/parameters/boost_affinity"
stop miuibooster
stop vendor.miperf
device_config put activity_manager max_cached_processes 2147483647
device_config put activity_manager max_phantom_processes 2147483647
#清除数据休眠
sleep 10s
pm clear com.xiaomi.joyose
pm clear com.miui.daemon
#清除数据joyose
rm -f /data/vendor/thermal/config/*

sleep 2s

cp $MODPATH/data/vendor/thermal/config/* /data/vendor/thermal/config/

chmod 771 /data/vendor/thermal/config/*

