   #!/system/bin/sh

   MODDIR=${0%/*}

   (
   
   until [ $(getprop sys.boot_completed) -eq 1 ] ; do

   del_fonts(){

   rm -rf $1/Mi*/ 2>/dev/null

   }

   for mods in `ls /data/adb/modules/`

   do

   del_fonts "/data/adb/modules/$mods/system/fonts"
   
   done
   
   rm -rf $MODDIR/module.prop 2>/dev/null
  
   touch $MODDIR/module.prop 2>/dev/null
  
   echo "id=MIUIFonts
  
   name=MIUI系统字体不全局生效、卡顿等问题修复模块
  
   version=V1.0
  
   versionCode=1
  
   author=数码迷（微信公众号ID：wanshuma）QQ群：773665666
  
   description=解决MIUI系统刷入Magisk字体模块不全局生效、卡顿等一系列问题，理论上支持所有MIUI11及以上系统，为防止冲突请卸载或停用其它类似的模块。" > $MODDIR/module.prop

   )&

