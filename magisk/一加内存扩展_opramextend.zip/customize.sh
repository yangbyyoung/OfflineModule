# This is customize the module installation process if you need

echo - 正在安装一加内存扩展模块，修复Root后没有内存扩展的问题
echo 
echo - 模块安装后需要重启，重启后即可到系统设置中启用内存扩展，启用后重启手机，内存扩展才能生效
resetprop persist.sys.oplus.nandswap.condition true
echo 1 >/sys/block/zram0/hybridswap_dev_life
sleep 3
resetprop persist.sys.oplus.nandswap.condition true
echo 1 >/sys/block/zram0/hybridswap_dev_life
