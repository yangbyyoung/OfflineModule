function mount_file(){
set_perm_recursive $MODPATH  0  0  0755  0644
for i in $bootpath;do
mount --bind $MODPATH$i $i
done
for i in $bootpath_dark;do
mount --bind $MODPATH$i $i
done
}

function uount_file(){
for i in $bootpath;do
umount $i
done
for i in $bootpath_dark;do
umount $i
done
}

function boot_view(){
setprop service.bootanim.exit 0
setprop ctl.start bootanim
sleep 10
setprop ctl.stop bootanim
setprop service.bootanim.exit 1
}

echo  ""
echo  "∞————————————————————————∞"
echo  "- 3后开始预览开机动画，请不要惊慌失措"
echo  "- 动画也就莫约10秒时间"
sleep 3
mount_file 2>/dev/null 
boot_view 2>/dev/null
uount_file 2>/dev/null
echo  ""
echo "∞————————————————————————∞"