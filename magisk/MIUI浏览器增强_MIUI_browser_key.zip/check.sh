
check_lite=$( pm list package | grep -w "com.android.browser" | wc -l)

if test "$check_lite" -lt "1" ;then
	abort "－ 未找到MIUI 浏览器！"
fi

if test "$(getprop ro.miui.ui.version.name )" = "" ;then 
	abort "- 非MIUI系统！"
fi
