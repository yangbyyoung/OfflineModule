

for task in system_server vendor.qti.hardware.display.composer-service surfaceflinger
do
	pgrep -f $task | while read pid; do
	echo $pid > /dev/cpuset/top-app/tasks
	echo $pid > /dev/stune/top-app/tasks
done
done
