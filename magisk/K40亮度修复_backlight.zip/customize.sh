# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0
function remove_thermal() {
 echo "exit 0" > $1
 chmod 7777 $1
}
chmod -R 7777 $MODPATH/ 
if [ -d /data/vendor/thermal/ ] ; then
   ui_print "- Remove MIUI Cloud Thermal."
   chmod -R 7777 /data/vendor/thermal/
   rm -rf /data/vendor/thermal/config
   mkdir -rf /data/vendor/thermal/config
   remove_thermal /data/vendor/thermal/config
   chmod 0000 /data/vendor/thermal/config
  fi