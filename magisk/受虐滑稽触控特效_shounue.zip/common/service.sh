#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动
echo 25 > /proc/sys/vm/dirty_background_ratio
chmod: chmod '/proc/sys/vm/dirty_background_ratio' to 100644
echo 25 > /proc/sys/vm/dirty_ratio
chmod: chmod '/proc/sys/vm/dirty_ratio' to 100644
echo 500 > /proc/sys/vm/dirty_expire_centisecs
chmod: chmod '/proc/sys/vm/dirty_expire_centisecs' to 100644
echo 500 > /proc/sys/vm/dirty_writeback_centisecs
chmod: chmod '/proc/sys/vm/dirty_writeback_centisecs' to 100644

