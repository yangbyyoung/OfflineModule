MODDIR=${0%/*}

rm -f "/data/local/tmp/daemon.apk"
cd "$MODDIR"

unshare -m sh -c "$MODDIR/daemon $@&"
