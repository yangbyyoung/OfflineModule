#!/bin/sh

Module_Path="/data/adb/modules"
Magisk_Path='$(magisk --path)/.magisk'
KernelSu_Path="/data/adb/ksu/bin"

KernelSu() {
	[ -f "/data/adb/ksud" ] && {
		S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')
		[ "$S" = "v0.3" ] && Module_Path="/data/adb/ksu/modules"
	}

}
KernelSu
# 设置Manjusaka_thermal路径
Thermal_Path="$Module_Path/Manjusaka_thermal"

# 更改文件夹及其子文件夹权限为755
find "$Thermal_Path" -type d -exec chmod -R 755 {} + >/dev/null 2>&1

{
	while true; do
		[ "$(getprop sys.boot_completed)" = 1 ] && break
		sleep 1s
	done
	alias MK="mkdir -p"
	alias TC="touch"
	alias DV="2>/dev/null"
	alias CM="chmod 000"
	[ ! -f "/bin/mount" ] && [ -f "/data/adb/ksud" ] && {
		alias MT="$KernelSu_Path/busybox mount"
	} || {
		[ ! -f "/bin/mount" ] && alias MT="$Magisk_Path/busybox/mount" || alias MT="mount"
	}

}

ManjusakaThermal() {

	File="$Thermal_Path/Qiu/Manjusaka"
	MK "$Thermal_Path/Qiu"
	TC "$File"
	CM "$File"
	for Manjusaka in $(DV find -L /system -iname "*thermal*" -type f | grep -v 'hardware' | grep -v '@' | grep -v '.so'); do
		{
			MJK=$(echo "${Manjusaka##*/}")
			[ "${MJK##*.}" = "xml" ] || [ "${MJK##*.}" = "conf" ] || [ "${MJK##*.}" = "rc" ] && {
				MT --make-slave --rbind --size "$File" "$Manjusaka"
			}
		}
	done

}


ManjusakaThermal
