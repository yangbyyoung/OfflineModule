. ./config.ini
./核心文件勿动/"$exec".bin check
./核心文件勿动/"sohigh".bin start
./"联网检测".sh