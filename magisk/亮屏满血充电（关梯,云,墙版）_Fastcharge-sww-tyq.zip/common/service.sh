#!/system/bin/sh
until [[ $supercharge == true ]]; do
chmod 777 /sys/class/power_supply/battery/fast_charge_current
chmod 777 /sys/class/power_supply/battery/thermal_input_current
chmod 777 /sys/class/power_supply/battery/input_suspend
chmod 777 /sys/class/power_supply/battery/battery_charging_enabled
echo 0 > /sys/class/power_supply/battery/input_suspend
echo 1 > /sys/class/power_supply/battery/battery_charging_enabled
echo 6000000 > /sys/class/power_supply/battery/fast_charge_current
echo 6000000 > /sys/class/power_supply/battery/thermal_input_current
sleep 10
chmod 777 /sys/class/power_supply/battery/step_charging_enabled
echo '0' > /sys/class/power_supply/battery/step_charging_enabled
MODDIR=${0%/*}
sleep 10
echo 120000 > /sys/class/thermal/thermal_zone46/trip_point_1_temp
echo 120000 > /sys/class/thermal/thermal_zone46/trip_point_3_temp
echo 120000 > /sys/class/thermal/thermal_zone47/trip_point_1_temp
echo 120000 > /sys/class/thermal/thermal_zone47/trip_point_3_temp
rm -rf /data/vendor/thermal/config/*
sleep 1
done