#!/system/bin/sh
### FeraVolt. 2021 ###

pm uninstall com.feravolt.fdeai >/dev/null 2>&1
rm -Rf /data/app/com.feravolt.fdeai-*
rm -Rf /data/data/com.feravolt.fdeai
chmod -R 644 $MODPATH/system/app/*/*


