#!/system/bin/sh
MODDIR=${0%/*}

#清理文件
rm -rf /data/adb/Dex2oatBOOT/重启手机.sh
echo "" > /data/adb/Dex2oatBOOT/dex2oat日志.log

#创建定时任务
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c $MODDIR/cron.d
