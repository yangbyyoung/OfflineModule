

export PATH=/system/bin:/data/adb/modules/Magisk_help_charge/busybox:$PATH


function battery_status() {
	dumpsys battery | grep 'status' | grep -Eo "[0-9]"
}

function key_echo(){
test -f "${2}" && {
	chmod 0644 "${2}" 
	echo "${1}" > "${2}"
	}
}

limit_current="12000000"

while :; do
	if test "$(battery_status)" = "2" ;then
			key_echo "$limit_current" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/dc/current_max
			key_echo "$limit_current" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/battery/constant_charge_current_max
			key_echo "$limit_current" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/main/constant_charge_current_max
			key_echo "$limit_current" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/usb/pd_current_max
			key_echo "1" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/main/input_current_settled
			key_echo "1" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/usb/input_current_settled
			key_echo "0" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/battery/step_charging_enabled
			key_echo "0" /sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-02/c440000.qcom,spmi:qcom,pm8150b@2:qcom,qpnp-smb5/power_supply/battery/input_current_limited
		sleep 1s
	else
		sleep 2m
	fi
done
