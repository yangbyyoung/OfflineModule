#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

sleep 10
chmod 755 /sys/class/power_supply/*/*
echo '4000000' > /sys/class/power_supply/main/current_max
sleep 1
