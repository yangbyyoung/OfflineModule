ui_print "
刷入时间$(date '+%g-%m-%d %H:%M:%S')

面具版本$MAGISK_VER_CODE

面具代号$MAGISK_VER

"
sleep 1
ui_print " 进行本模块前，请您了解：
1.本模块仅供学习使用，24小时内自行删除，否则后果自负！
2.进行模块安装前，请您确保以及安装防砖模块，不排除有变砖可能性！
3.本模块仅支持MIUI14！
4.作者：酷安@安稳wen94，请勿倒卖，觉得不错请到酷安评论区评论点赞！"
       
sleep 0.5

ui_print "
本模块即将为您修改开机动画为：败家之眼开机动画
本模块已经通过作者测试（MIUI14 V14.0.70，Redmi Note13 pro+，Android 13），测试无异常！"




set_perm_recursive $MODPATH 0 0 0755 0644
