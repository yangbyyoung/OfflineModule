

if test "$(getprop ro.miui.ui.version.name )" = "" ;then 
	rm -rf "$MODPATH/sqlite"
fi

function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

if test "$(show_value "自动内存回收")" != "开启" ;then
	rm -rf "$MODPATH/crond/mem_compact.sh"
fi

if test "$(show_value "清理应用附加进程")" != "开启" ;then
	rm -rf "$MODPATH/crond/kill_other_pross.sh"
fi

if test "$(show_value "应用内存限制")" != "开启" ;then
	rm -rf "$MODPATH/crond/limitmem.sh"
fi

if test "$(show_value "发送低内存信号")" != "开启" ;then
	rm -rf "$MODPATH/crond/mem_control.sh"
fi

Crond_script=`find $MODPATH/crond -iname '*.sh' 2>/dev/null `
test "${Crond_script}" = "" && rm -rf $MODPATH/crond $MODPATH/setupcrond.sh
