# Google Face Unlock
Standalone Google Face unlock for Android 8.1 

# Changelog
<br>v1.1 Fix misspelling
<br>v1.0 Initial commit

# Credits
- DennySPb for FaceUnlock flashable zip
- Mi5 Arsenal admins for magisk module
- rlshukhov for submit to Magisk Repo