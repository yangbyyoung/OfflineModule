scripts=/data/media/0/Android/QQ微信小模块
file="$MODPATH/scripts"
[ ! -e $scripts ] && mkdir -p $scripts
cp -rf $file/* $scripts
set_perm_recursive  $scripts  9997  9997  0777  0777

