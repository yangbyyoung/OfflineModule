#!/system/bin/sh


source "${0%/*}/util_functions.sh"

if test "$(show_value '温控文件目录')" = "默认" ;then
	thermal_confing_folder="${MODPATH}/自定义温控"
else
	if test -d "$(show_value '温控文件目录')" ;then
		thermal_confing_folder="$(show_value '温控文件目录')"
	else
		echo "不存在该目录！"
		echo "使用模块默认目录！"
		thermal_confing_folder="${MODPATH}/自定义温控"
	fi
fi

function mod_description(){
local file="$MODPATH/module.prop"
local text="${1}"
test ! -f "$file" && return 0
sed -i "/^description=/c description=自定义MIUI温控，工具来源于@coolapk 嘟嘟Ski。${text}" "$file"
}

mod_description "自定义温控文件配置目录放在[ ${thermal_confing_folder} ]"