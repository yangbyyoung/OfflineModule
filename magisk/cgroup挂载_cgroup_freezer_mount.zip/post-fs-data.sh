detection() {
  frozen=/sys/fs/cgroup/frozen/cgroup.procs
  unfrozen=/sys/fs/cgroup/unfrozen/cgroup.procs

  frozen2=/sys/fs/cgroup/freezer/perf/frozen/cgroup.procs
  unfrozen2=/sys/fs/cgroup/freezer/perf/thawed/cgroup.procs

  frozen3=/dev/freezer/frozen/cgroup.procs
  unfrozen3=/dev/freezer/unfrozen/cgroup.procs

  if [[ -f $frozen ]] || [[ -f $unfrozen ]]; then
    return 1
  elif [[ -f $frozen2 ]] && [[ -f $unfrozen2 ]]; then
    return 1
  elif [[ -f $frozen3 ]] && [[ -f $unfrozen3 ]]; then
    # 该路径用法不太官方，不做适配
    return 0
  fi

  return 0
}

# cgroup常用的挂载方式，这很官方
mount_cgroup_sys(){
  mkdir /sys/fs/cgroup/freezer
  if [[ !-f /sys/fs/cgroup/freezer ]]; then
    mount -t cgroup -ofreezer freezer /sys/fs/cgroup/freezer
  fi

  mkdir -p /sys/fs/cgroup/freezer/perf/frozen
  echo FROZEN > /sys/fs/cgroup/freezer/perf/frozen/freezer.state

  mkdir /sys/fs/cgroup/freezer/perf/thawed
  echo THAWED > /sys/fs/cgroup/freezer/perf/thawed/freezer.state

  set_cgroup2_permission
}
set_cgroup2_permission(){
  chown -R system:system /sys/fs/cgroup/freezer
  chcon -R u:object_r:cgroup:s0 /sys/fs/cgroup/freezer
}

# 有些厂家也会往这里挂，但似乎没啥优点
mount_cgroup_dev() {
  if [[ -d /dev/freezer ]]; then
    mkdir /dev/freezer/frozen
    echo FROZEN >  /dev/freezer/unfrozen/freezer.state

    mkdir /dev/freezer/unfrozen
    echo THAWED >  /dev/freezer/unfrozen/freezer.state
  fi
}

# cgroup2的常用挂载方式，这很官方
mount_cgroup2_sys(){
  mkdir /sys/fs/cgroup/frozen
  echo 1 > /sys/fs/cgroup/frozen/cgroup.freeze

  mkdir /sys/fs/cgroup/unfrozen
  echo 0 > /sys/fs/cgroup/unfrozen/cgroup.freeze

  set_cgroup2_permission
}

# 设置cgroup2目录的权限
# 因为/sys/fs/cgroup/frozen 和 /sys/fs/cgroup/unfrozen 所有者通常是root，以system身份无法写入
set_cgroup2_permission(){
  chown -R system:system /sys/fs/cgroup/frozen
  chcon -R u:object_r:cgroup_v2:s0 /sys/fs/cgroup/frozen

  chown -R system:system /sys/fs/cgroup/unfrozen
  chcon -R u:object_r:cgroup_v2:s0 /sys/fs/cgroup/unfrozen
}

# 自动挂载或创建缺失的目录
auto_mount() {
  if [[ -f /sys/fs/cgroup/cgroup.controllers ]]; then
    mount_cgroup2_sys
    echo '看起来可以用cgroup(v2)'
  else
    # grep cgroup /proc/filesystems
    # Result Example:
    # nodev   cgroup
    # nodev   cgroup2
    versions=$(grep cgroup /proc/filesystems)
    case "$versions" in
      *"cgroup")
        mount_cgroup_sys
        # mount_cgroup_dev
        echo '看起来可以用cgroup(v1)'
      ;;
    esac
  fi
}

echo '>> 尝试自动挂载cgroup'
auto_mount

echo '>> 检测cgroup目录'
detection

if [[ "$?" == "0" ]]; then
  echo '该模块不适用于你的系统，因为内核未启用相关特性'
  exit 2
fi
