#!/system/bin/sh
MODDIR=${0%/*}
#可选参数
#白名单
#-w "com.tencent.mm|com.tencent.monileqq"

#黑名单
#-b ""

#黑名单优先级最高
if [[ ! -f $MODDIR/白名单 ]]
then
touch $MODDIR/白名单
fi
if [[ ! -f $MODDIR/黑名单 ]]
then
touch $MODDIR/黑名单
fi
until [[ $(getprop sys.boot_completed) -eq 1 ]]; do
  sleep 1
done
path="$MODDIR/core"
export CLASSPATH=$path
killall AppProcess

wl=`cat $MODDIR/白名单`
bl=`cat $MODDIR/黑名单`

exec app_process /system/bin --nice-name=AppProcess com.moe.processmanager.Main -w "$wl" -b "$bl" >> /cache/magisk.log &

#exec app_process /system/bin --nice-name=AppProcess com.moe.processmanager.Main >> /cache/magisk.log &
