#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

###启用sdcardfs，禁用fuse
setprop persist.fuse_sdcard false
setprop persist.sys.fuse.default_fuse_enabled false
setprop persist.sys.fflag.override.settings_fuse false
setprop persist.device_config.storage_native_boot.fuse_enabled false
setprop ro.sys.sdcardfs true
setprop persist.sys.fuse false 

# 2021  by YaoDao
