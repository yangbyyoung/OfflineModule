# 安装时显示的模块名称
mod_name="[安卓tcp参数优化]"
# 模块介绍
mod_install_desc="安卓tcp参数优化，提高网络稳定性和负载能力，相关参数来源于网络，经本人微调，不懂的不要乱改"
# 安装时显示的提示
mod_install_info="是否安装$mod_name？"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="安装$mod_name"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""

mod_install_yes()
{
add_service_sh $MOD_FILES_DIR/service.sh
		return 0
}

mod_install_no()
{
		return 0
}