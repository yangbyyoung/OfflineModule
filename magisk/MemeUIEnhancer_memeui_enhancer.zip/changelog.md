# Changelog

## v0.3 

- Enhanced MIUI processes optimization
- Tweaked MIUI services optimization logic
- Removed useless MIUI props (Causes some features to break)
- Added Misc. MIUI Tweaks
- Miscellaneous changes & enhancements

## v0.2

- Added various improvements
- Disabled more useless MIUI services
- Improved system processes optimization logic
- Refactored some MIUI props
- Now, you can see MemeUI Enhancer log in Internal storage / Android / mienhancer.txt
- Misc. changes and bug fixes

## v0.1

- Initial release