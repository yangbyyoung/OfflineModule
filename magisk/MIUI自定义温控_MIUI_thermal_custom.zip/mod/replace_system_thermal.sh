#!/system/bin/sh


source "${0%/*}/util_functions.sh"

unlock_MIUI_thermal_folder


if test "$(show_value '温控文件目录')" = "默认" ;then
	thermal_confing_folder="${MODPATH}/自定义温控"
else
	if test -d "$(show_value '温控文件目录')" ;then
		thermal_confing_folder="$(show_value '温控文件目录')"
	else
		echo "不存在该目录！"
		echo "使用模块默认目录！"
		thermal_confing_folder="${MODPATH}/自定义温控"
	fi
fi

ecrypt_mi_thermal "${thermal_confing_folder}" "${MODPATH}/加密后的温控"
ecrypt_mi_thermal "${thermal_confing_folder}" "${MODPATH}/system/vendor/etc"

set_perm "/data/vendor/thermal" 'root' 'system' '0771' 'u:object_r:vendor_data_file:s0'

if test "$(show_value '云温控目录加锁')" = "是" ;then
	chattr -R +i /data/vendor/thermal/config
fi

