
if [ -f /odm/firmware/28_*.bin ] || [ -f /odm/firmware/38_*.bin ]; then
   A="odm"
elif [ -f /vendor/firmware/28_*.bin ] || [ -f /vendor/firmware/38_*.bin ]; then
   A="vendor"
fi
M="$MODPATH"
F="$M/File/core"
C="/$A/firmware"
D="$M/system/$A/firmware"
filename=$C/88_*.bin
filesize=`ls -l $filename | awk '{ print $5 }'`
maxsize=$((366))
if [ "$API" -lt 30 ]; then
   abort " 安卓版本低于11.0"
fi
if [ $filesize -ne $maxsize ]; then
   ui_print "不适配非0809马达!效果差/异常/破音别反馈!"
   ui_print "非要安装,建议降到90/80%强度,减少破音概率"
   sleep 2
fi
   ui_print "　　　　　 !风险提示!"
   ui_print "个别机型可能有玄学问题(功耗/振动异常/无振动等)"
   ui_print "建议搜索专版模块,或单独MiuiExtra映射震动"
   ui_print "模块非万能,玄学问题概不负责.是否继续?"
   sleep 1
   ui_print "　　音量↑:安装│音量↓:取消"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
     ;;
     *)
     abort "　　　　　　　　　　✓✓"
   esac
if [ -f $C/162_Gesture*.bin ] || [ -f $C/163_Gesture*.bin ]; then
   mkdir -p $D
   NAME="`grep_prop name $M/module.prop`"
   AUT="`grep_prop author $M/module.prop`"
   VER="`grep_prop version $M/module.prop`"
   VC="`grep_prop versionCode $M/module.prop`"
   ui_print "*************************"
   ui_print " 模块名: $NAME"
   ui_print " 作者: $AUT"
   ui_print " 版本: $VER　│版本代号: $VC"
   ui_print "*************************"
   sleep 0.5
   if [ -f $C/28_*_P_RTP.bin ] || [ -f $C/38_*_P_RTP.bin ]; then
     ui_print "驱动目录:$C/(_P_RTP)"
   else
     ui_print "驱动目录:$C/(_RTP)"
   fi
   if [ "$A" = "odm" ]; then
     ui_print "此目录需Delta面具,否则振动异常"
   else
     ui_print "　　　此目录不限面具版本"
   fi
   sleep 0.5
   ui_print "********个性化选项*********"
   ui_print "　　　　　［版本选择］"
   ui_print "映射作业：压缩包/File目录.独立版可忽略"
   ui_print "不会映射请选独立版,没精力一对一指导.谢谢!"
   sleep 0.5
   ui_print "　　音量↑:独立│音量↓:映射"
   key_click=""
   while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
   done
   case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　✓✓"
   sleep 0.5
   ui_print "　　　　［请选择清脆样式］"
   ui_print "　　　音量↑:咚│音量↓:结实"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
     File="$C/70_*.bin"
     cp -rf $F/70_*.bin $D/$(basename ${File})
     File="$C/71_*.bin"
     cp -rf $F/71_*.bin $D/$(basename ${File})
     File="$C/72_*.bin"
     cp -rf $F/72_*.bin $D/$(basename ${File})
     File="$C/162_*.bin"
     cp -rf $F/70_*.bin $D/$(basename ${File})
     File="$C/163_*.bin"
     cp -rf $F/70_*.bin $D/$(basename ${File})
     File="$C/169_*.bin"
     cp -rf $F/71_*.bin $D/$(basename ${File})
     File="$C/92_*.bin"
     cp -rf $F/s/70_*.bin $D/$(basename ${File})
     File="$C/91_*.bin"
     cp -rf $F/s/71_*.bin $D/$(basename ${File})
     File="$C/84_*.bin"
     cp -rf $F/s/72_*.bin $D/$(basename ${File})
     ;;
     *)
     ui_print "　　　　　　　　　✓✓"
     cp -rf $M/File/solid/* $M
     File="$C/70_*.bin"
     cp -rf $F/s/70_*.bin $D/$(basename ${File})
     File="$C/71_*.bin"
     cp -rf $F/s/71_*.bin $D/$(basename ${File})
     File="$C/72_*.bin"
     cp -rf $F/s/72_*.bin $D/$(basename ${File})
     File="$C/162_*.bin"
     cp -rf $F/s/70_*.bin $D/$(basename ${File})
     File="$C/163_*.bin"
     cp -rf $F/s/70_*.bin $D/$(basename ${File})
     File="$C/169_*.bin"
     cp -rf $F/s/71_*.bin $D/$(basename ${File})
     File="$C/92_*.bin"
     cp -rf $F/70_*.bin $D/$(basename ${File})
     File="$C/91_*.bin"
     cp -rf $F/71_*.bin $D/$(basename ${File})
     File="$C/84_*.bin"
     cp -rf $F/72_*.bin $D/$(basename ${File})
   esac
   ui_print "　　　　［选择清理样式］"
   ui_print "　　音量↑:四段│音量↓:转子"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
     ;;
     *)
     ui_print "　　　　　　　　　✓✓"
       ui_print "　　　　［选择转子样式］"
       ui_print "　　　音量↑:长│音量↓:短"
       key_click=""
     while [ "$key_click" = "" ]; do
       key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
       sleep 0.2
     done
     case "$key_click" in
       "KEY_VOLUMEUP")
       ui_print "　　　✓✓"
       File="$F/93_*.bin"
       cp -rf $F/43_*.bin $F/$(basename ${File})
       ;;
       *)
       ui_print "　　　　　　　　　✓✓"
       File="$F/93_*.bin"
       cp -rf $F/76_*.bin $F/$(basename ${File})
     esac
   esac
   ui_print "　　［默认100%强度 是否降低］"
   ui_print "　　　音量↑:是│音量↓:否"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
       filename=$F/93_*.bin
       filesize=`ls -l $filename | awk '{ print $5 }'`
       maxsize=$((5538))
       if [ $filesize -gt $maxsize ]; then
         File="$F/93_*.bin"
         cp -rf $C/153_*.bin $F/$(basename ${File})
       elif [ $filesize -lt $maxsize ]; then
         File="$F/93_*.bin"
         cp -rf $C/113_*.bin $F/$(basename ${File})
       else
         File="$F/93_*.bin"
         cp -rf $C/55_*.bin $F/$(basename ${File})
       fi
       File="$F/43_*.bin"
       cp -rf $C/153_*.bin $F/$(basename ${File})
       File="$F/76_*.bin"
       cp -rf $C/113_*.bin $F/$(basename ${File})
       File="$F/87_*.bin"
       cp -rf $C/165_*.bin $F/$(basename ${File})
       cp -rf $M/File/low/* $M
       rm -rf $MODPATH/File/core/85_*bin
       rm -rf $MODPATH/File/core/86_*bin
       rm -rf $MODPATH/File/core/171_*bin
       ui_print "　　　　　［选择强度］"
       ui_print "　　音量↑:90%│音量↓:80%"
       key_click=""
     while [ "$key_click" = "" ]; do
         key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
       sleep 0.2
     done
     case "$key_click" in
       "KEY_VOLUMEUP")
       ui_print "　　　✓✓"
       File="$C/162_*.bin"
       cp -rf $D/71_*.bin $D/$(basename ${File})
       File="$C/163_*.bin"
       cp -rf $D/71_*.bin $D/$(basename ${File})
       File="$C/169_*.bin"
       cp -rf $D/72_*.bin $D/$(basename ${File})
       File="$C/70_*.bin"
       mv -f $D/71_*.bin $D/$(basename ${File})
       ;;
       *)
       ui_print "　　　　　　　　　✓✓"
       File="$C/162_*.bin"
       cp -rf $D/72_*.bin $D/$(basename ${File})
       File="$C/163_*.bin"
       cp -rf $D/72_*.bin $D/$(basename ${File})
       File="$C/169_*.bin"
       cp -rf $D/72_*.bin $D/$(basename ${File})
       File="$C/70_*.bin"
       mv -f $D/72_*.bin $D/$(basename ${File})
     esac
     ;;
     *)
     ui_print "　　　　　　　　　✓✓"
   esac
   File="$C/90_*.bin"
   cp -rf $F/93_*.bin $D/$(basename ${File})
   File="$C/43_*.bin"
   cp -rf $F/43_*.bin $D/$(basename ${File})
   File="$C/74_*.bin"
   cp -rf $F/76_*.bin $D/$(basename ${File})
   File="$C/76_*.bin"
   cp -rf $F/76_*.bin $D/$(basename ${File})
   File="$C/85_*.bin"
   cp -rf $F/85_*.bin $D/$(basename ${File})
   File="$C/86_*.bin"
   cp -rf $F/86_*.bin $D/$(basename ${File})
   File="$C/87_*.bin"
   cp -rf $F/87_*.bin $D/$(basename ${File})
   File="$C/93_*.bin"
   cp -rf $F/93_*.bin $D/$(basename ${File})
   File="$C/171_*.bin"
   cp -rf $F/171_*.bin $D/$(basename ${File})
   ui_print "　　［仅键盘+光标+手势振动］"
   ui_print "　　　音量↑:是│音量↓:否"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
     cp -rf $M/File/*Input/* $M
     File="$C/169_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     File="$C/87_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     File="$C/90_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     File="$C/93_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     ;;
     *)
     ui_print "　　　　　　　　　✓✓"
   esac
   ui_print "　　　［是否禁用手势振动］"
   ui_print "　　　音量↑:是│音量↓:否"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　✓✓"
     filename=$D/93_*.bin
     filesize=`ls -l $filename | awk '{ print $5 }'`
     maxsize=$((0))
     if [ $filesize -eq $maxsize ]; then
       cp -rf $M/File/*OFF/1/* $M
     else
       cp -rf $M/File/*OFF/2/* $M
     fi
     File="$C/70_*.bin"
     cp -rf $D/162_*.bin $D/$(basename ${File})
     File="$C/162_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     File="$C/163_*.bin"
     cp -rf $F/00*.bin $D/$(basename ${File})
     ;;
     *)
     ui_print "　　　　　　　　　✓✓"
   esac
   ;;
   *)
   ui_print "　　　　　　　　　　✓✓"
   cp -rf $M/File/ID*/* $M
   File="$C/70_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/71_*.bin"
   cp -rf $F/71_*.bin $D/$(basename ${File})
   File="$C/72_*.bin"
   cp -rf $F/72_*.bin $D/$(basename ${File})
   File="$C/162_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/163_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/169_*.bin"
   cp -rf $F/71_*.bin $D/$(basename ${File})
   File="$C/92_*.bin"
   cp -rf $F/s/70_*.bin $D/$(basename ${File})
   File="$C/91_*.bin"
   cp -rf $F/s/71_*.bin $D/$(basename ${File})
   File="$C/84_*.bin"
   cp -rf $F/s/72_*.bin $D/$(basename ${File})
   File="$C/90_*.bin"
   cp -rf $F/93_*.bin $D/$(basename ${File})
   File="$C/43_*.bin"
   cp -rf $F/43_*.bin $D/$(basename ${File})
   File="$C/74_*.bin"
   cp -rf $F/76_*.bin $D/$(basename ${File})
   File="$C/76_*.bin"
   cp -rf $F/76_*.bin $D/$(basename ${File})
   File="$C/85_*.bin"
   cp -rf $F/85_*.bin $D/$(basename ${File})
   File="$C/86_*.bin"
   cp -rf $F/86_*.bin $D/$(basename ${File})
   File="$C/87_*.bin"
   cp -rf $F/87_*.bin $D/$(basename ${File})
   File="$C/93_*.bin"
   cp -rf $F/93_*.bin $D/$(basename ${File})
   File="$C/171_*.bin"
   cp -rf $F/171_*.bin $D/$(basename ${File})
   esac
   if [ ! -f $F/171_*.bin ] || [ ! -f $F/85_*.bin ]; then
     rm -rf $MODPATH/system/$A/firmware/71_*.bin
     rm -rf $MODPATH/system/$A/firmware/72_*.bin
     rm -rf $MODPATH/system/$A/firmware/74_*.bin
     rm -rf $MODPATH/system/$A/firmware/92_*.bin
     rm -rf $MODPATH/system/$A/firmware/91_*.bin
     rm -rf $MODPATH/system/$A/firmware/84_*.bin
   fi
   if [ -f $C/MiRemix_*.bin ]; then
     File="$C/MiRemix_*.bin"
     cp -rf $D/43_*.bin $D/$(basename ${File})
     File="$C/Spring_*.bin"
     cp -rf $D/70_*.bin $D/$(basename ${File})
     File="$C/Swoosh_*.bin"
     cp -rf $D/71_*.bin $D/$(basename ${File})
     File="$C/Gesture_UpSlide_*.bin"
     cp -rf $D/72_*.bin $D/$(basename ${File})
     File="$C/Charge_Wire_*.bin"
     cp -rf $D/74_*.bin $D/$(basename ${File})
     File="$C/Unlock_Failed_*.bin"
     cp -rf $D/76_*.bin $D/$(basename ${File})
     File="$C/uninstall_dialog_*.bin"
     cp -rf $D/84_*.bin $D/$(basename ${File})
     File="$C/screenshot_*.bin"
     cp -rf $D/85_*.bin $D/$(basename ${File})
     File="$C/lockscreen_camera_*.bin"
     cp -rf $D/86_*.bin $D/$(basename ${File})
     File="$C/launcher_edit_*.bin"
     cp -rf $D/87_*.bin $D/$(basename ${File})
     File="$C/task_cleanall_*.bin"
     cp -rf $D/90_*.bin $D/$(basename ${File})
     File="$C/new_iconfolder_*.bin"
     cp -rf $D/91_*.bin $D/$(basename ${File})
     File="$C/notification_remove_*.bin"
     cp -rf $D/92_*.bin $D/$(basename ${File})
     File="$C/notification_cleanall_*.bin"
     cp -rf $D/93_*.bin $D/$(basename ${File})
     File="$C/Gesture_Back_Pull_*.bin"
     cp -rf $D/162_*.bin $D/$(basename ${File})
     File="$C/Gesture_Back_Release_*.bin"
     cp -rf $D/163_*.bin $D/$(basename ${File})
     File="$C/lockdown_*.bin"
     cp -rf $D/169_*.bin $D/$(basename ${File})
     File="$C/todo_alldone_*.bin"
     cp -rf $D/171_*.bin $D/$(basename ${File})
   fi
   if [ -f $C/aw8697_haptic.bin ] && [ -f $F/aw8697*.bin ]; then
     ui_print "　　　［是否增强通知振动］"
     ui_print "　　　音量↑:是│音量↓:否"
     key_click=""
     while [ "$key_click" = "" ]; do
       key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
       sleep 0.2
     done
     case "$key_click" in
       "KEY_VOLUMEUP")
       ui_print "　　　✓✓"
       cp -rf $F/aw8697*.bin $D
       ;;
       *)
       ui_print "　　　　　　　　　✓✓"
     esac
   fi
   rm -rf $MODPATH/File
   ui_print "***************************"
   ui_print " 更改选项请重刷模块,个别8G2机型禁用手势可能无效."
   ui_print " 模块安装/卸载目录:data/adb/modules/$MODID"
   ui_print " ID映射参数/效果修改: ↑↑/system.prop"
   ui_print " 仅适配官方MIUI-0809马达机型.官改/移植包兼容性未知!"
   ui_print " 部分魔改桌面/插件可能会修改返回振动.自行解决."
   ui_print " 模块并非万能,个别机型可能不兼容/振动异常,请删除本模块."
else
   ui_print " 匹配不到关键ID文件. 安装失败!"
   ui_print " 删除所有涉及振动的模块-重启."
   ui_print " 查看vendor(odm)/firmware目录:"
   ui_print " 若162_Gesture*.bin与163_Gesture*.bin文件缺失/重复."
   abort " 把上述文件补全或删除重复,再安装模块."
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644
