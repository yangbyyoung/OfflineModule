MODPATH=${0%/*}
n=60
cd $MODPATH
./1.sh $n
exit 0
