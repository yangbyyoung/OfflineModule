#CPU在线
cd /sys/devices/system/cpu/
chmod 0755 ./cpu0/online
chmod 0755 ./cpu1/online
chmod 0755 ./cpu2/online
chmod 0755 ./cpu3/online
chmod 0755 ./cpu4/online
chmod 0755 ./cpu5/online
chmod 0755 ./cpu6/online
chmod 0755 ./cpu7/online
echo 1 > ./cpu0/online
echo 1 > ./cpu1/online
echo 1 > ./cpu2/online
echo 1 > ./cpu3/online
echo 1 > ./cpu4/online
echo 1 > ./cpu5/online
echo 1 > ./cpu6/online
echo 1 > ./cpu7/online
chmod 0755 -R /dev/cpuset
echo 0-7 > /dev/cpuset/cpus
#在有前台任务的时候的boost
echo '' > /dev/cpuset/foreground/boost/cpus
#CPU核心数：前台 上层 后台 系统后台 相机预留
echo 0-7 > /dev/cpuset/foreground/cpus
echo 0-7 > /dev/cpuset/top-app/cpus
echo 0-3 > /dev/cpuset/background/cpus
echo 0-3 > /dev/cpuset/system-background/cpus
echo 0-3 > /dev/cpuset/camera-daemon/cpus
#设置可读写
chmod 0755 -R /sys/devices/system/cpu/cpufreq
chmod 0755 -R $(realpath /sys/class/kgsl/kgsl-3d0)
#小核集群：最大频率 最小频率 调度模式
#小核集群频率表：/sys/devices/system/cpu/cpufreq/policy0/scaling_available_frequencies
#小核集群调度器：/sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors
echo 1612800 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo 691200 > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
echo schedutil > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
#大核集群：最大频率 最小频率 调度模式
#大核集群频率表：/sys/devices/system/cpu/cpufreq/policy4/scaling_available_frequencies
#大核集群调度器：/sys/devices/system/cpu/cpufreq/policy4/scaling_available_governors
echo 1670400 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
echo 0 > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
echo schedutil > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
#性能集群：最大频率 最小频率 调度模式
#性能集群频率表：/sys/devices/system/cpu/cpufreq/policy7/scaling_available_frequencies
#性能集群调度器：/sys/devices/system/cpu/cpufreq/policy7/scaling_available_governors
echo 1862400 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq
echo 0 > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq
echo schedutil > /sys/devices/system/cpu/cpufreq/policy7/scaling_governor
#获取GPU最高频率
getfreqG=$(awk '{print $1}' /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/available_frequencies)
#GPU最大频率
#GPU频率表：/sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/available_frequencies
echo $getfreqG > /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/max_freq
#GPU最小频率
echo 0 > /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/min_freq
#对应最大功耗级别 两种方式修改
#echo 670 > /sys/kernel/gpu/gpu_max_clock
echo 0 > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
#获取GPU最小功耗级别
getpur=$(($(cat /sys/class/kgsl/kgsl-3d0/num_pwrlevels) - 1))
#对应最小功耗级别 两种方式修改
#echo 305 > /sys/kernel/gpu/gpu_min_clock
echo $getpur > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
#默认功耗级别 影响频率
#参考/sys/class/kgsl/kgsl-3d0/gpu_available_frequencies第一个GPU频率对应功耗级别0 第二个对应是1 第三个对应是2 依次类推
echo $getpur > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
#GPU调度模式（ondemand快升快降的按需升频，比adreno-tz更激进）
#GPU调度器：/sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/available_governors
echo simple_ondemand > /sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/devfreq/3d00000.qcom,kgsl-3d0/governor
#微调可写
cpu1=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)
cpu2=$(cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor)
cpu3=$(cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor)
chmod 0755 -R /sys/devices/system/cpu/cpu0/cpufreq/${cpu1/}
chmod 0755 -R /sys/devices/system/cpu/cpu4/cpufreq/${cpu2/}
chmod 0755 -R /sys/devices/system/cpu/cpu7/cpufreq/${cpu3/}
#切换目录 小核集群微调
cd /sys/devices/system/cpu/cpufreq/policy0/${cpu1/}
#小核集群微调
echo 500 > ./up_rate_limit_us #升频最短间隔
echo 20000 > ./down_rate_limit_us #降频最短间隔
echo 83 > ./target_loads #升频所需负载
echo 90 > ./hispeed_load #紧急升频负载 WALT调优相关
echo 1248000 > ./hispeed_freq #紧急升频频率 WALT调优相关
echo 1000000 > ./rtg_boost_freq #某种频率加速 文档太长不想看
echo 0 > ./iowait_boost_enable #遭遇I/O事件的加速
echo 1 > ./pl #貌似是判断器 WALT调优相关
#切换目录 大核集群微调
cd /sys/devices/system/cpu/cpufreq/policy4/${cpu2/}
#大核集群微调
echo 1400 > ./up_rate_limit_us #同上，看小核微调
echo 8000 > ./down_rate_limit_us
echo 80 > ./target_loads
echo 88 > ./hispeed_load
echo 1478400 > ./hispeed_freq
echo 0 > ./rtg_boost_freq
echo 1 > ./iowait_boost_enable
echo 1 > ./pl
#切换目录 性能集群微调
cd /sys/devices/system/cpu/cpufreq/policy7/${cpu3/}
#性能集群微调
echo 500 > ./up_rate_limit_us #同上
echo 12000 > ./down_rate_limit_us
echo 80 > ./target_loads
echo 81 > ./hispeed_load
echo 1516800 > ./hispeed_freq
echo 0 > ./rtg_boost_freq
echo 0 > ./iowait_boost_enable
echo 1 > ./pl
##触摸升频
echo 0 > /sys/module/msm_performance/parameters/touchboost
#带宽
cd /sys/class/devfreq/
#拉满
echo $(awk '{print $NF}' ./soc:qcom,cpu-cpu-llcc-bw/available_frequencies) > ./soc:qcom,cpu-cpu-llcc-bw/max_freq
echo $(awk '{print $NF}' ./soc:qcom,npu-npu-llcc-bw/available_frequencies) > ./soc:qcom,npu-npu-llcc-bw/max_freq
echo $(awk '{print $NF}' ./soc:qcom,cpu-llcc-ddr-bw/available_frequencies) > ./soc:qcom,cpu-llcc-ddr-bw/max_freq
echo $(awk '{print $NF}' ./soc:qcom,gpubw/available_frequencies) > ./soc:qcom,gpubw/max_freq
echo $(awk '{print $NF}' ./soc:qcom,npudsp-npu-ddr-bw/available_frequencies) > ./soc:qcom,npudsp-npu-ddr-bw/max_freq
echo $(awk '{print $NF}' ./soc:qcom,npu-llcc-ddr-bw/available_frequencies) > ./soc:qcom,npu-llcc-ddr-bw/max_freq
#soc:qcom,cpu-cpu-llcc-bw频率表：/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/available_frequencies
#soc:qcom,cpu-cpu-llcc-bw调度器：/sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/available_governors
#bw_hwmon
echo 2288 > ./soc:qcom,cpu-cpu-llcc-bw/min_freq
echo bw_hwmon > ./soc:qcom,cpu-cpu-llcc-bw/governor
echo 10 > ./soc:qcom,cpu-cpu-llcc-bw/bw_hwmon/up_thres
echo 30 > ./soc:qcom,cpu-cpu-llcc-bw/bw_hwmon/down_thres
#soc:qcom,npu-npu-llcc-bw频率表：/sys/class/devfreq/soc:qcom,npu-npu-llcc-bw/available_frequencies
#soc:qcom,npu-npu-llcc-bw调度器：/sys/class/devfreq/soc:qcom,npu-npu-llcc-bw/available_governors
#bw_hwmon
echo 0 > ./soc:qcom,npu-npu-llcc-bw/min_freq
echo bw_hwmon > ./soc:qcom,npu-npu-llcc-bw/governor
#soc:qcom,cpu-llcc-ddr-bw频率表：/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/available_frequencies
#soc:qcom,cpu-llcc-ddr-bw调度器：/sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/available_governors
#bw_hwmon
echo 762 > ./soc:qcom,cpu-llcc-ddr-bw/min_freq
echo bw_hwmon > ./soc:qcom,cpu-llcc-ddr-bw/governor
echo 10 > ./soc:qcom,cpu-llcc-ddr-bw/bw_hwmon/up_thres
echo 30 > ./soc:qcom,cpu-llcc-ddr-bw/bw_hwmon/down_thres
#soc:qcom,gpubw频率表：/sys/class/devfreq/soc:qcom,gpubw/available_frequencies
#soc:qcom,gpubw调度器：/sys/class/devfreq/soc:qcom,gpubw/available_governors
#soc:qcom,npudsp-npu-ddr-bw频率表：/sys/class/devfreq/soc:qcom,npudsp-npu-ddr-bw/available_frequencies
#soc:qcom,npudsp-npu-ddr-bw调度器：/sys/class/devfreq/soc:qcom,npudsp-npu-ddr-bw/available_governors
#soc:qcom,npu-llcc-ddr-bw频率表：/sys/class/devfreq/soc:qcom,npu-llcc-ddr-bw/available_frequencies
#soc:qcom,npu-llcc-ddr-bw调度器：/sys/class/devfreq/soc:qcom,npu-llcc-ddr-bw/available_governors
echo 0 > ./soc:qcom,gpubw/min_freq
#bw_hwmon
echo 0 > ./soc:qcom,npudsp-npu-ddr-bw/min_freq
echo bw_hwmon > ./soc:qcom,npudsp-npu-ddr-bw/governor
echo 0 > ./soc:qcom,npu-llcc-ddr-bw/min_freq
echo bw_hwmon > ./soc:qcom,npu-llcc-ddr-bw/governor
##预读取kb数
echo 192 > /sys/block/sda/queue/read_ahead_kb
##设置I/O
echo deadline > /sys/block/sda/queue/scheduler
##I/O微调
chmod 0755 /sys/block/sda/queue/iosched/*
echo 8 > /sys/block/sda/queue/iosched/writes_starved #读request超过这个值必须提交写
echo 1600 > /sys/block/sda/queue/iosched/read_expire #读取转写入的时间
echo 2800 > /sys/block/sda/queue/iosched/write_expire #写入转读取的时间
echo 24 > /sys/block/sda/queue/iosched/fifo_batch #单批发出的读写数
echo 1 > /sys/block/sda/queue/iosched/front_merges #合并处理，性能优化
#三集群L3 升频
#小核集群L3频率表：/sys/class/devfreq/*qcom,cpu0-cpu-l3-lat/available_frequencies
#小核集群L3调度器：/sys/class/devfreq/*qcom,cpu0-cpu-l3-lat/available_governors
#大核集群L3频率表：/sys/class/devfreq/*qcom,cpu4-cpu-l3-lat/available_frequencies
#大核集群L3调度器：/sys/class/devfreq/*qcom,cpu4-cpu-l3-lat/available_governors
#性能集群L3频率表：/sys/class/devfreq/*qcom,cpu7-cpu-l3-lat/available_frequencies
#性能集群L3调度器：/sys/class/devfreq/*qcom,cpu7-cpu-l3-lat/available_governors
cd /sys/class/devfreq/*qcom,cpu0-cpu-l3-lat/
echo 300000000 > ./min_freq
echo mem_latency > ./governor
echo 800 > ./mem_latency/ratio_ceil
cd /sys/class/devfreq/*qcom,cpu4-cpu-l3-lat/
echo 300000000 > ./min_freq
echo mem_latency > ./governor
echo 6000 > ./mem_latency/ratio_ceil
cd /sys/class/devfreq/*qcom,cpu7-cpu-l3-lat/
echo 300000000 > ./min_freq
echo mem_latency > ./governor
echo 12000 > ./mem_latency/ratio_ceil
#DDR升频
#小核ddr频率表：/sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/available_frequencies
#小核ddr调度器：/sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/available_governors
#大核ddr频率表：/sys/class/devfreq/soc:qcom,cpu4-llcc-ddr-lat/available_frequencies
#大核ddr调度器：/sys/class/devfreq/soc:qcom,cpu4-llcc-ddr-lat/available_governors
echo 762 > /sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/min_freq
echo mem_latency > /sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/governor
echo 4000 > /sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/mem_latency/ratio_ceil
echo 762 > /sys/class/devfreq/soc:qcom,cpu4-llcc-ddr-lat/min_freq
echo mem_latency > /sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/governor
echo 4000 > /sys/class/devfreq/soc:qcom,cpu4-llcc-ddr-lat/mem_latency/ratio_ceil
#小核大核lat升频
#小核lat频率表：/sys/class/devfreq/soc:qcom,cpu0-cpu-llcc-lat/available_frequencies
#小核lat调度器：/sys/class/devfreq/soc:qcom,cpu0-cpu-llcc-lat/available_governors
#大核lat频率表：/sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/available_frequencies
#大核lat调度器：/sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/available_governors
echo 2288 > /sys/class/devfreq/soc:qcom,cpu0-cpu-llcc-lat/min_freq
echo mem_latency > /sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/governor
echo 4000 > /sys/class/devfreq/soc:qcom,cpu0-cpu-llcc-lat/mem_latency/ratio_ceil
echo 2288 > /sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/min_freq
echo mem_latency > /sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/governor
echo 4000 > /sys/class/devfreq/soc:qcom,cpu4-cpu-llcc-lat/mem_latency/ratio_ceil
#不计能耗的调度加速
echo 5 > /dev/stune/top-app/schedtune.boost
echo 10 > /dev/stune/rt/schedtune.boost
echo 5 > /dev/stune/foreground/schedtune.boost
echo 1 > /dev/stune/foreground/schedtune.prefer_idle
#GPU加速
echo 0 > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo 1 > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo 0 > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo 2147483647 > /sys/class/kgsl/kgsl-3d0/idle_timer
#任务所需负载：小核到大核 大核到小核
echo 85 99 > /proc/sys/kernel/sched_upmigrate
echo 55 65 > /proc/sys/kernel/sched_downmigrate
#负载迁移阈值：小核到大核 大核到小核
echo 125 > /proc/sys/kernel/sched_group_upmigrate
echo 95 > /proc/sys/kernel/sched_group_downmigrate
#加速
echo 2 > /proc/sys/kernel/sched_boost