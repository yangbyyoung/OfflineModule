##########################################################################################
#
# Magisk 模块配置脚本示例
# by topjohnwu
# 翻译: cjybyjk
#
##########################################################################################
##########################################################################################
#
# 说明:
#
# 1. 将你的文件放入 system 文件夹 (删除 placeholder 文件)
# 2. 将模块信息写入 module.prop
# 3. 在这个文件中进行设置 (config.sh)
# 4. 如果你需要在启动时执行命令, 请把它们加入 common/post-fs-data.sh 或 common/service.sh
# 5. 如果需要修改系统属性(build.prop), 请把它加入 common/system.prop
#
##########################################################################################

##########################################################################################
# 配置
##########################################################################################

# 如果你需要启用 Magic Mount, 请把它设置为 true
# 大多数模块都需要启用它
AUTOMOUNT=true

# 如果你需要加载 system.prop, 请把它设置为 true
PROPFILE=true

# 如果你需要执行 post-fs-data 脚本, 请把它设置为 true
POSTFSDATA=true

# 如果你需要执行 service 脚本, 请把它设置为 true
LATESTARTSERVICE=true
SKIPMOUNT=false
##########################################################################################
# 安装信息
##########################################################################################

# 在这里设置你想要在模块安装过程中显示的信息

print_modname() {
  ui_print "***********************"
  ui_print "MiSoundBOOST!!!!"
  ui_print "Design By Huber_HaYu"
  ui_print "***********************"
}

##########################################################################################
# 替换列表
##########################################################################################

# 列出你想在系统中直接替换的所有目录
# 查看文档，了解更多关于Magic Mount如何工作的信息，以及你为什么需要它

# 这是个示例
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里构建你自己的列表，它将覆盖上面的示例
# 如果你不需要替换任何东西，!千万不要! 删除它，让它保持现在的状态
REPLACE="
"

##########################################################################################
# 权限设置
##########################################################################################

set_permissions() {
  # 只有一些特殊文件需要特定的权限
  # 默认的权限应该适用于大多数情况

  # 下面是 set_perm 函数的一些示例:

  # set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755        0644

  # set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000      0755       u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000      0755       u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0         0644

  # 以下是默认权限，请勿删除
  set_perm  $MODPATH/system/app/MiSound/MiSound.apk  0  0  0644
  set_perm  $MODPATH/system/priv-app/MusicFX/MusicFX.apk  0  0  0644
}

##########################################################################################
# 自定义函数
##########################################################################################

# 这个文件 (config.sh) 将被安装脚本在 util_functions.sh 之后 source 化(设置为环境变量)
# 如果你需要自定义操作, 请在这里以函数方式定义它们, 然后在 update-binary 里调用这些函数
# 不要直接向 update-binary 添加代码，因为这会让你很难将模块迁移到新的模板版本
# 尽量不要对 update-binary 文件做其他修改，尽量只在其中执行函数调用

ui_print " 一切尽在掌握当中.."
ui_print " "
sleep 2s

# Magisk
if [ -d /sbin/.magisk ]; then
  MAGISKTMP=/sbin/.magisk
else
  MAGISKTMP=`find /dev -mindepth 2 -maxdepth 2 -type d -name .magisk`
fi

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
ui_print " "

# bit
if [ "$IS64BIT" == true ]; then
  ui_print "- 64 bit system"
  ui_print " "
  if ! getprop | grep -Eq "misound.dolby\]: \[0"; then
    ui_print "- 注册杜比全景声Dolby Atmos.."
	DOLBY=true
	MODNAME2='小米10S 杜比全景声v1.1.30'
	sed -i "s/$MODNAME/$MODNAME2/g" $MODPATH/module.prop
	MODNAME=$MODNAME2
	ui_print " "
	else
	 DOLBY=false
	fi
else
  ui_print "- 32 bit system"
  rm rf `find $MODPATH/system -type d -name *64`
  DOLBY=false
  if ! getprop | grep -Eq "misound.dolby\]: \[0"; then
    ui_print "  设备不支持杜比全景声！"
  fi
  ui_print " "
fi

# sdk
NUM=26
if [ "$API" -lt $NUM ]; then
  ui_print " 不支持的SDK版本"
  ui_print " 你需要升级安卓版本"
  ui_print " 本模块最低支持的SDK版本为 API $NUM"
  abort
else
  ui_print "- SDK $API"
  if [ $DOLBY == true ] && [ "$API" -lt 28 ]; then
    ui_print "  设备不支持杜比全景声！"
	DOLBY=false
  fi
  ui_print " "
fi

# socket
FILE=$MODPATH/service.sh
if [ ! -e /dev/socket/audio_hw_socket ]; then
  ui_print " 不支持audio_hw_socket"
  ui_print " 音质音效在此设备上无法工作"
  ui_print " 但你仍然可以使用杜比全景声"
  ui_print " "
fi

# sepolicy.rule
if [ "$BOOTMODE" != true ]; then
  mount -o rw -t auto /dev/block/bootdevice/by-name/persist /persist
  mount -o rw -t auto /dev/block/bootdevice/by-name/metadata /metadata
fi
FILE=$MODPATH/sepolicy.sh
DES=$MODPATH/sepolicy.rule
if [ -f $FILE ] && ! getprop | grep -Eq "sepolicy.sh\]: \[1"; then
  mv -f $FILE $DES
  sed -i 's/magiskpolicy --live "//g' $DES
  sed -i 's/"//g' $DES
fi

# .aml.sh
mv -f $MODPATH/aml.sh $MODPATH/.aml.sh

# mod ui
if getprop | grep -Eq "mod.ui\]: \[1"; then
  APP=MiSound
  FILE=/sdcard/$APP.apk
  DIR=`find $MODPATH/system -type d -name $APP`
  ui_print "- 调入apk文件..."
  if [ -f $FILE ]; then
    cp -f $FILE $DIR
    chmod 0644 $DIR/$APP.apk
    ui_print "  完成"
  else
    ui_print "  文件丢失 $FILE"
    ui_print "    请把apk文件放到存储目录，然后重新刷入"
  fi
  ui_print " "
fi

# function
extract_lib() {
for APPS in $APP; do
  ui_print "- 发射文件(ง •_•)ง"
  FILE=`find $MODPATH/system -type f -name $APPS.apk`
  DIR=`find $MODPATH/system -type d -name $APPS`/lib/$ARCH
  mkdir -p $DIR
  rm -rf $TMPDIR/*
  unzip -d $TMPDIR -o $FILE $DES
  cp -f $TMPDIR/$DES $DIR
  ui_print " "
done
}

# extract
APP=MiSound
PROP=`getprop ro.product.cpu.abi`
DES=lib/$PROP/*
extract_lib

# cleaning
ui_print "- 清扫垃圾（￣▽￣）"
PKG=com.miui.misound
if [ "$BOOTMODE" == true ]; then
  for PKGS in $PKG; do
    RES=`pm uninstall $PKGS`
  done
fi
rm -rf $MODPATH/unused
rm -rf /metadata/magisk/$MODID
rm -rf /mnt/vendor/persist/magisk/$MODID
rm -rf /persist/magisk/$MODID
rm -rf /data/unencrypted/magisk/$MODID
rm -rf /cache/magisk/$MODID
ui_print " "

# function
conflict() {
for NAMES in $NAME; do
  DIR=/data/adb/modules_update/$NAMES
  if [ -f $DIR/uninstall.sh ]; then
    sh $DIR/uninstall.sh
  fi
  rm -rf $DIR
  DIR=/data/adb/modules/$NAMES
  rm -f $DIR/update
  touch $DIR/remove
  FILE=/data/adb/modules/$NAMES/uninstall.sh
  if [ -f $FILE ]; then
    sh $FILE
    rm -f $FILE
  fi
  rm -rf /metadata/magisk/$NAMES
  rm -rf /mnt/vendor/persist/magisk/$NAMES
  rm -rf /persist/magisk/$NAMES
  rm -rf /data/unencrypted/magisk/$NAMES
  rm -rf /cache/magisk/$NAMES
done
}

# conflict
if [ $DOLBY == true ]; then
  NAME="dolbyatmos
        DolbyAudio
        DolbyAtmos
        MotoDolby
        dsplus
        Dolby"
  conflict
  NAME=SoundEnhancement
  FILE=/data/adb/modules/$NAME/module.prop
  if grep -Eq 'Dolby Atmos Xperia' $FILE; then
    conflict
  fi
fi

# function
cleanup() {
if [ -f $DIR/uninstall.sh ]; then
  sh $DIR/uninstall.sh
fi
DIR=/data/adb/modules_update/$MODID
if [ -f $DIR/uninstall.sh ]; then
  sh $DIR/uninstall.sh
fi
}

# cleanup
DIR=/data/adb/modules/$MODID
FILE=$DIR/module.prop
if getprop | grep -Eq "misound.cleanup\]: \[1"; then
  ui_print "- Cleaning-up $MODID data..."
  cleanup
  ui_print " "
elif [ -d $DIR ] && ! grep -Eq "$MODNAME" $FILE; then
  ui_print "- Different version detected"
  ui_print "  Cleaning-up $MODID data..."
  cleanup
  ui_print " "
fi

# check
NAME=_ZN7android23sp_report_stack_pointerEv
if [ "$BOOTMODE" == true ]; then
  DIR=`realpath $MAGISKTMP/mirror/vendor`
else
  DIR=`realpath /vendor`
fi
ui_print "- 正在检查"
ui_print "$NAME"
ui_print "  工作中"
ui_print "  请稍等o_o ...."
if ! grep -Eq $NAME `find $DIR/lib*/hw -type f -name *audio*.so`\
|| getprop | grep -Eq "dolby.10\]: \[1"; then
  ui_print "  准备legacy libraries"
  cp -rf $MODPATH/system_10/* $MODPATH/system
  rm -f $MODPATH/system/vendor/lib64/soundfx/libmisoundfx.so
  if [ $DOLBY == true ]; then
    cp -rf $MODPATH/system_dolby_10/* $MODPATH/system_dolby
    sed -i 's/#10//g' $MODPATH/service.sh
  fi
else
  if [ $DOLBY == true ]; then
    sed -i 's/#11//g' $MODPATH/service.sh
  fi
fi
rm -rf $MODPATH/system_10
rm -rf $MODPATH/system_dolby_10
ui_print " "
NAME=_ZN7android8hardware23getOrCreateCachedBinderEPNS_4hidl4base4V1_05IBaseE
if [ "$BOOTMODE" == true ]; then
  DIR=`realpath $MAGISKTMP/mirror/system`
else
  DIR=`realpath /system`
fi
if [ $DOLBY == true ]; then
  ui_print "- 正在检查"
  ui_print "$NAME"
  ui_print "  工作中"
  ui_print "  请稍等o_o..."
  if ! grep -Eq $NAME `find $DIR/lib64 -type f -name *audio*.so`; then
    ui_print "  未知函数"
    ui_print "  不支持此ROM"
    DOLBY=false
  fi
  ui_print " "
fi

# dolby
if [ $DOLBY == true ]; then
  sed -i 's/#d//g' $MODPATH/.aml.sh
  sed -i 's/#d//g' $MODPATH/*.sh
  cp -rf $MODPATH/system_dolby/* $MODPATH/system
  PKG=com.dolby.daxservice
  if [ "$BOOTMODE" == true ]; then
    for PKGS in $PKG; do
      RES=`pm uninstall $PKGS`
    done
  fi
  rm -f /data/vendor/dolby/dax_sqlite3.db
else
  MODNAME2='音质音效 Redmi M2012K11AC'
  sed -i "s/$MODNAME/$MODNAME2/g" $MODPATH/module.prop
fi
rm -rf $MODPATH/system_dolby

# cleaning
APP="`ls $MODPATH/system/priv-app` `ls $MODPATH/system/app`"
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/resource-cache -type f -name *$APPS*.apk`
done

# function
permissive() {
SELINUX=`getenforce`
if [ "$SELINUX" == Enforcing ]; then
  setenforce 0
  SELINUX=`getenforce`
  if [ "$SELINUX" == Enforcing ]; then
    abort "  ! Your device can't be turned to Permissive state"
  fi
  setenforce 1
fi
sed -i '1i\
SELINUX=`getenforce`\
if [ "$SELINUX" == Enforcing ]; then\
  setenforce 0\
fi\' $MODPATH/post-fs-data.sh
}
set_read_write() {
for NAMES in $NAME; do
  blockdev --setrw $DIR$NAMES
done
}
find_file() {
for NAMES in $NAME; do
  if [ "$SYSTEM_ROOT" == true ]; then
    if [ "$BOOTMODE" == true ]; then
      FILE=`find $MAGISKTMP/mirror/system_root\
                 $MAGISKTMP/mirror/system_ext\
                 $MAGISKTMP/mirror/vendor -type f -name $NAMES`
    else
      FILE=`find /system_root\
                 /system_ext\
                 /vendor -type f -name $NAMES`
    fi
  else
    if [ "$BOOTMODE" == true ]; then
      FILE=`find $MAGISKTMP/mirror/system\
                 $MAGISKTMP/mirror/system_ext\
                 $MAGISKTMP/mirror/vendor -type f -name $NAMES`
    else
      FILE=`find /system\
                 /system_ext\
                 /vendor -type f -name $NAMES`
    fi
  fi
  if [ ! "$FILE" ]; then
    PROP=`getprop install.hwlib`
    if [ "$PROP" == 1 ]; then
      ui_print "- Installing $NAMES directly to /system and /vendor..."
      magiskpolicy --live "type same_process_hal_file"
      magiskpolicy --live "type system_lib_file"
      magiskpolicy --live "dontaudit { same_process_hal_file system_lib_file } labeledfs filesystem associate"
      magiskpolicy --live "allow     { same_process_hal_file system_lib_file } labeledfs filesystem associate"
      magiskpolicy --live "dontaudit init { same_process_hal_file system_lib_file } file relabelfrom"
      magiskpolicy --live "allow     init { same_process_hal_file system_lib_file } file relabelfrom"
      if [ "$BOOTMODE" == true ]; then
        cp $MODPATH/system_support/lib/$NAMES $MAGISKTMP/mirror/system/lib
        cp $MODPATH/system_support/lib64/$NAMES $MAGISKTMP/mirror/system/lib64
        cp $MODPATH/system_support/vendor/lib/$NAMES $MAGISKTMP/mirror/vendor/lib
        cp $MODPATH/system_support/vendor/lib64/$NAMES $MAGISKTMP/mirror/vendor/lib64
        chcon u:object_r:system_lib_file:s0 $MAGISKTMP/mirror/system/lib*/$NAMES
        chcon u:object_r:same_process_hal_file:s0 $MAGISKTMP/mirror/vendor/lib*/$NAMES
      else
        cp $MODPATH/system_support/lib/$NAMES /system/lib
        cp $MODPATH/system_support/lib64/$NAMES /system/lib64
        cp $MODPATH/system_support/vendor/lib/$NAMES /vendor/lib
        cp $MODPATH/system_support/vendor/lib64/$NAMES /vendor/lib64
        chcon u:object_r:system_lib_file:s0 /system/lib*/$NAMES
        chcon u:object_r:same_process_hal_file:s0 /vendor/lib*/$NAMES
      fi
      ui_print " "
    else
      ui_print "! $NAMES not found."
      ui_print "  This module will not be working without $NAMES."
      ui_print "  You can type terminal:"
      ui_print " "
      ui_print "  su"
      ui_print "  setprop install.hwlib 1"
      ui_print " "
      ui_print "  and reinstalling this module"
      ui_print "  to install $NAMES directly to this ROM."
      ui_print " "
    fi
  fi
done
}
backup() {
if [ ! -f $FILE.orig ] && [ ! -f $FILE.bak ]; then
  cp -f $FILE $FILE.orig
fi
}
patch_manifest() {
if [ -f $FILE ]; then
  backup
  if [ -f $FILE.orig ] || [ -f $FILE.bak ]; then
    ui_print "- Created"
    ui_print "$FILE.orig"
    ui_print " "
    ui_print "- Patching"
    ui_print "$FILE"
    ui_print "  directly..."
    sed -i '/<manifest/a\
    <hal format="hidl">\
        <name>vendor.dolby.hardware.dms</name>\
        <transport>hwbinder</transport>\
        <version>2.0</version>\
        <interface>\
            <name>IDms</name>\
            <instance>default</instance>\
        </interface>\
        <fqname>@2.0::IDms/default</fqname>\
    </hal>' $FILE
    ui_print " "
  else
    ui_print "! Failed to create"
    ui_print "$FILE.orig"
    ui_print " "
  fi
fi
}
patch_hwservice() {
if [ -f $FILE ]; then
  backup
  if [ -f $FILE.orig ] || [ -f $FILE.bak ]; then
    ui_print "- Created"
    ui_print "$FILE.orig"
    ui_print " "
    ui_print "- Patching"
    ui_print "$FILE"
    ui_print "  directly..."
    sed -i '1i\
vendor.dolby.hardware.dms::IDms u:object_r:hal_dms_hwservice:s0' $FILE
    ui_print " "
  else
    ui_print "! Failed to create"
    ui_print "$FILE.orig"
    ui_print " "
  fi
fi
}
restore() {
for FILES in $FILE; do
  if [ -f $FILES.orig ]; then
    mv -f $FILES.orig $FILES
  fi
  if [ -f $FILES.bak ]; then
    mv -f $FILES.bak $FILES
  fi
done
}

# permissive
if getprop | grep -Eq "permissive.mode\]: \[1"; then
  ui_print "- Using permissive method"
  rm -f $MODPATH/sepolicy.rule
  permissive
  ui_print " "
elif getprop | grep -Eq "permissive.mode\]: \[2"; then
  ui_print "- Using both permissive and SE policy patch"
  permissive
  ui_print " "
fi

# remount
if [ $DOLBY == true ]; then
  DIR=/dev/block/bootdevice/by-name
  NAME="/vendor$SLOT /cust$SLOT /system$SLOT /system_ext$SLOT"
  set_read_write
  DIR=/dev/block/mapper
  set_read_write
  DIR=$MAGISKTMP/block
  NAME="/vendor /system_root /system /system_ext"
  set_read_write
  mount -o rw,remount $MAGISKTMP/mirror/system
  mount -o rw,remount $MAGISKTMP/mirror/system_root
  mount -o rw,remount $MAGISKTMP/mirror/system_ext
  mount -o rw,remount $MAGISKTMP/mirror/vendor
  mount -o rw,remount /system
  mount -o rw,remount /
  mount -o rw,remount /system_root
  mount -o rw,remount /system_ext
  mount -o rw,remount /vendor
fi

# find
NAME=`ls $MODPATH/system_support/vendor/lib`
if [ $DOLBY == true ]; then
  find_file
fi
rm -rf $MODPATH/system_support

# patch manifest.xml
if [ $DOLBY == true ]; then
  FILE=`find $MAGISKTMP/mirror/*/etc/vintf\
             $MAGISKTMP/mirror/*/*/etc/vintf\
             /*/etc/vintf /*/*/etc/vintf -type f -name *.xml`
  if ! getprop | grep -Eq "dolby.skip.vendor\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=$MAGISKTMP/mirror/vendor/etc/vintf/manifest.xml
    patch_manifest
  fi
  if ! getprop | grep -Eq "dolby.skip.system\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=$MAGISKTMP/mirror/system/etc/vintf/manifest.xml
    patch_manifest
  fi
  if ! getprop | grep -Eq "dolby.skip.system_ext\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=$MAGISKTMP/mirror/system_ext/etc/vintf/manifest.xml
   patch_manifest
  fi
  if ! getprop | grep -Eq "dolby.skip.vendor\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=/vendor/etc/vintf/manifest.xml
    patch_manifest
  fi
  if ! getprop | grep -Eq "dolby.skip.system\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=/system/etc/vintf/manifest.xml
    patch_manifest
  fi
  if ! getprop | grep -Eq "dolby.skip.system_ext\]: \[1"\
  && ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=/system/system_ext/etc/vintf/manifest.xml
    patch_manifest
  fi
  if ! grep -A2 vendor.dolby.hardware.dms $FILE | grep -Eq 2.0; then
    FILE=`find $MAGISKTMP/mirror/system\
               $MAGISKTMP/mirror/system_ext\
               $MAGISKTMP/mirror/vendor\
               $MAGISKTMP/mirror/system_root/system\
               $MAGISKTMP/mirror/system_root/system_ext\
               $MAGISKTMP/mirror/system_root/vendor\
               /system\
               /system_ext\
               /vendor\
               /system_root/system\
               /system_root/system_ext\
               /system_root/vendor -type f -name manifest.xml`
    restore
    ui_print "- Using systemless manifest.xml patch."
    ui_print "  On some ROMs, it's buggy or even makes bootloop"
    ui_print "  because not allowed to restart hwservicemanager."
    ui_print " "
  fi
fi

# patch hwservice contexts
if [ $DOLBY == true ]; then
  FILE="$MAGISKTMP/mirror/*/etc/selinux/*_hwservice_contexts
        $MAGISKTMP/mirror/*/*/etc/selinux/*_hwservice_contexts
        /*/etc/selinux/*_hwservice_contexts
        /*/*/etc/selinux/*_hwservice_contexts"
  if ! getprop | grep -Eq "dolby.skip.vendor\]: \[1"\
  && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=$MAGISKTMP/mirror/vendor/etc/selinux/vendor_hwservice_contexts
    patch_hwservice
  fi
 if ! getprop | grep -Eq "dolby.skip.system\]: \[1"\
 && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=$MAGISKTMP/mirror/system/etc/selinux/plat_hwservice_contexts
    patch_hwservice
  fi
  if ! getprop | grep -Eq "dolby.skip.system_ext\]: \[1"\
  && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=$MAGISKTMP/mirror/system_ext/etc/selinux/system_ext_hwservice_contexts
    patch_hwservice
  fi
  if ! getprop | grep -Eq "dolby.skip.vendor\]: \[1"\
  && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=/vendor/etc/selinux/vendor_hwservice_contexts
    patch_hwservice
  fi
  if ! getprop | grep -Eq "dolby.skip.system\]: \[1"\
  && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=/system/etc/selinux/plat_hwservice_contexts
    patch_hwservice
  fi
  if ! getprop | grep -Eq "dolby.skip.system_ext\]: \[1"\
  && ! grep -Eq 'u:object_r:hal_dms_hwservice:s0|u:object_r:default_android_hwservice:s0' $FILE; then
    FILE=/system/system_ext/etc/selinux/system_ext_hwservice_contexts
    patch_hwservice
  fi
fi

# remount
if [ "$BOOTMODE" == true ] && [ $DOLBY == true ]; then
  mount -o ro,remount $MAGISKTMP/mirror/system
  mount -o ro,remount $MAGISKTMP/mirror/system_root
  mount -o ro,remount $MAGISKTMP/mirror/system_ext
  mount -o ro,remount $MAGISKTMP/mirror/vendor
  mount -o ro,remount /system
  mount -o ro,remount /
  mount -o ro,remount /system_root
  mount -o ro,remount /system_ext
  mount -o ro,remount /vendor
fi

# function
hide_oat() {
for APPS in $APP; do
  mkdir -p `find $MODPATH/system -type d -name $APPS`/oat
  touch `find $MODPATH/system -type d -name $APPS`/oat/.replace
done
}
replace_dir() {
if [ -d $DIR ]; then
  mkdir -p $MODDIR
  touch $MODDIR/.replace
fi
}
hide_app() {
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/system/app/$APPS
else
  DIR=/system/app/$APPS
fi
MODDIR=$MODPATH/system/app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/system/priv-app/$APPS
else
  DIR=/system/priv-app/$APPS
fi
MODDIR=$MODPATH/system/priv-app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/product/app/$APPS
else
  DIR=/product/app/$APPS
fi
MODDIR=$MODPATH/system/product/app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/product/priv-app/$APPS
else
  DIR=/product/priv-app/$APPS
fi
MODDIR=$MODPATH/system/product/priv-app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/product/preinstall/$APPS
else
  DIR=/product/preinstall/$APPS
fi
MODDIR=$MODPATH/system/product/preinstall/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/system_ext/app/$APPS
else
  DIR=/system/system_ext/app/$APPS
fi
MODDIR=$MODPATH/system/system_ext/app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/system_ext/priv-app/$APPS
else
  DIR=/system/system_ext/priv-app/$APPS
fi
MODDIR=$MODPATH/system/system_ext/priv-app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/vendor/app/$APPS
else
  DIR=/vendor/app/$APPS
fi
MODDIR=$MODPATH/system/vendor/app/$APPS
replace_dir
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/vendor/euclid/product/app/$APPS
else
  DIR=/vendor/euclid/product/app/$APPS
fi
MODDIR=$MODPATH/system/vendor/euclid/product/app/$APPS
replace_dir
}
check_app() {
if [ "$BOOTMODE" == true ]; then
  for APPS in $APP; do
    FILE=`find $MAGISKTMP/mirror/system_root/system\
               $MAGISKTMP/mirror/system_root/product\
               $MAGISKTMP/mirror/system_root/system_ext\
               $MAGISKTMP/mirror/system\
               $MAGISKTMP/mirror/product\
               $MAGISKTMP/mirror/system_ext\
               $MAGISKTMP/mirror/vendor -type f -name $APPS.apk`
    if [ "$FILE" ]; then
      ui_print "  Checking $APPS.apk"
      ui_print "  Please wait..."
      if grep -Eq $UUID $FILE; then
        ui_print "  Your $APPS.apk will be hidden"
        hide_app
      fi
    fi
  done
fi
}
detect_soundfx() {
if [ "$BOOTMODE" == true ]\
&& dumpsys media.audio_flinger | grep -Eq $UUID; then
  ui_print "- $NAME is detected."
  ui_print "  It may be conflicting with this module."
  ui_print "  You can run terminal:"
  ui_print " "
  ui_print "  su"
  ui_print "  setprop disable.dirac 1"
  ui_print " "
  ui_print "  and reinstall this module if you want to disable it."
  ui_print " "
fi
}

# hide
hide_oat
APP="MusicFX Dirac"
for APPS in $APP; do
  hide_app
done
if [ $DOLBY == true ]; then
  APP="DaxUI MotoDolbyDax3 MotoDolbyV3 OPSoundTuner
       DolbyAtmos AudioEffectCenter"
  for APPS in $APP; do
    hide_app
  done
fi

# dirac & misoundfx
APP="XiaomiParts
     ZenfoneParts
     ZenParts
     GalaxyParts
     KharaMeParts
     DeviceParts"
FILE=$MODPATH/.aml.sh
NAME=misoundfx
UUID=5b8e36a5-144a-4c38-b1d7-0002a5d5c51b
ui_print "- Checking $NAME..."
check_app
ui_print " "
FILE=$MODPATH/.aml.sh
NAME='dirac soundfx'
UUID=e069d9e0-8329-11df-9168-0002a5d5c51b
ui_print "- Checking $NAME..."
check_app
ui_print " "

# stream mode
FILE=$MODPATH/.aml.sh
PROP=`getprop stream.mode`
if echo "$PROP" | grep -Eq m; then
  ui_print "- Activating music stream..."
  sed -i 's/#m//g' $FILE
  ui_print " "
else
  APP=AudioFX
  for APPS in $APP; do
    hide_app
  done
fi
if echo "$PROP" | grep -Eq r; then
  ui_print "- Activating ring stream..."
  sed -i 's/#r//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq a; then
  ui_print "- Activating alarm stream..."
  sed -i 's/#a//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq v; then
  ui_print "- Activating voice_call stream..."
  sed -i 's/#v//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq n; then
  ui_print "- Activating notification stream..."
  sed -i 's/#n//g' $FILE
  ui_print " "
fi
if ! getprop | grep -Eq "ozo.audio\]: \[0"; then
  ui_print "- Activating Nokia OZO Audio Capture for camcorder, mic,"
  ui_print "  and voice recognition stream..."
  sed -i 's/#c//g' $FILE
  ui_print " "
fi

# settings
if [ $DOLBY == true ]; then
  FILE=$MODPATH/system/vendor/etc/dolby/dax-default.xml
  PROP=`getprop dolby.bass`
  if [ "$PROP" == default ]; then
    ui_print "- Using default settings for bass enhancer"
  elif [ "$PROP" == true ]; then
    ui_print "- Enable bass enhancer for all profiles..."
    sed -i 's/bass-enhancer-enable value="false"/bass-enhancer-enable value="true"/g' $FILE
  elif [ "$PROP" ] && [ "$PROP" != false ] && [ "$PROP" -gt 0 ]; then
    ui_print "- Enable bass enhancer for all profiles..."
    sed -i 's/bass-enhancer-enable value="false"/bass-enhancer-enable value="true"/g' $FILE
    ui_print "- Changing bass enhancer boost values to $PROP for all profiles..."
    ROW=`grep bass-enhancer-boost $FILE | sed 's/<bass-enhancer-boost value="0"\/>//p'`
    echo $ROW > $TMPDIR/test
    sed -i 's/<bass-enhancer-boost value="//g' $TMPDIR/test
    sed -i 's/"\/>//g' $TMPDIR/test
    ROW=`cat $TMPDIR/test`
    ui_print "  (Default values: $ROW)"
    for ROWS in $ROW; do
      sed -i "s/bass-enhancer-boost value=\"$ROWS\"/bass-enhancer-boost value=\"$PROP\"/g" $FILE
    done
  else
    ui_print "- Disable bass enhancer for all profiles..."
    sed -i 's/bass-enhancer-enable value="true"/bass-enhancer-enable value="false"/g' $FILE
  fi
  if getprop | grep -Eq "dolby.virtualizer\]: \[1"; then
    ui_print "- Enable virtualizer for all profiles..."
    sed -i 's/virtualizer-enable value="false"/virtualizer-enable value="true"/g' $FILE
  elif getprop | grep -Eq "dolby.virtualizer\]: \[0"; then
    ui_print "- Disable virtualizer for all profiles..."
    sed -i 's/virtualizer-enable value="true"/virtualizer-enable value="false"/g' $FILE
  fi
  if getprop | grep -Eq "dolby.volumeleveler\]: \[1"; then
    ui_print "- Using default volume leveler settings"
  elif getprop | grep -Eq "dolby.volumeleveler\]: \[2"; then
    ui_print "- Enable volume leveler for all profiles..."
    sed -i 's/volume-leveler-enable value="false"/volume-leveler-enable value="true"/g' $FILE
  else
    ui_print "- Disable volume leveler for all profiles..."
    sed -i 's/volume-leveler-enable value="true"/volume-leveler-enable value="false"/g' $FILE
  fi
  ui_print "- Using deeper bass GEQ frequency"
  sed -i 's/frequency="47"/frequency="0"/g' $FILE
  sed -i 's/frequency="141"/frequency="47"/g' $FILE
  sed -i 's/frequency="234"/frequency="141"/g' $FILE
  sed -i 's/frequency="328"/frequency="234"/g' $FILE
  sed -i 's/frequency="469"/frequency="328"/g' $FILE
  sed -i 's/frequency="656"/frequency="469"/g' $FILE
  sed -i 's/frequency="844"/frequency="656"/g' $FILE
  sed -i 's/frequency="1031"/frequency="844"/g' $FILE
  sed -i 's/frequency="1313"/frequency="1031"/g' $FILE
  sed -i 's/frequency="1688"/frequency="1313"/g' $FILE
  ui_print " "
fi

# audio rotation
FILE=$MODPATH/service.sh
if getprop | grep -Eq "audio.rotation\]: \[1"; then
  ui_print "- Activating ro.audio.monitorRotation=true"
  sed -i '1i\
resetprop ro.audio.monitorRotation true' $FILE
  ui_print " "
fi

# raw
FILE=$MODPATH/.aml.sh
if getprop | grep -Eq "disable.raw\]: \[0"; then
  ui_print "- Not disabling Ultra Low Latency playback (RAW)"
  ui_print " "
else
  sed -i 's/#u//g' $FILE
fi

# other
FILE=$MODPATH/service.sh
if getprop | grep -Eq "other.etc\]: \[1"; then
  ui_print "- Activating other etc files bind mount..."
  sed -i 's/#p//g' $FILE
  ui_print " "
fi

# function
file_check_vendor() {
for NAMES in $NAME; do
  if [ "$BOOTMODE" == true ]; then
    FILE64=$MAGISKTMP/mirror/vendor/lib64/$NAMES
    FILE=$MAGISKTMP/mirror/vendor/lib/$NAMES
  else
    FILE64=/vendor/lib64/$NAMES
    FILE=/vendor/lib/$NAMES
  fi
  if [ -f $FILE64 ]; then
    ui_print "- Detected"
    ui_print "$FILE64"
    rm -f $MODPATH/system/vendor/lib64/$NAMES
    ui_print " "
  fi
  if [ -f $FILE ]; then
    ui_print "- Detected"
    ui_print "$FILE"
    rm -f $MODPATH/system/vendor/lib/$NAMES
    ui_print " "
  fi
done
}

# check
NAME="libqtigef.so libstagefrightdolby.so
      libstagefright_soft_ddpdec.so
      libstagefright_soft_ac4dec.so"
if [ $DOLBY == true ]; then
  file_check_vendor
fi

# check
if [ "$BOOTMODE" == true ]; then
  FILE=$MAGISKTMP/mirror/vendor/lib/soundfx/libmisoundfx.so
else
  FILE=/vendor/lib/soundfx/libmisoundfx.so
fi
if [ -f $FILE ]; then
  ui_print "- Built-in misoundfx is detected."
  rm -f `find $MODPATH/system/vendor -type f -name *misound*`
  ui_print " "
fi

# permission
ui_print "- Setting permission..."
FILE=`find $MODPATH/system/vendor/bin -type f`
for FILES in $FILE; do
  chmod 0755 $FILES
  chown 0.2000 $FILES
done
chmod 0751 $MODPATH/system/vendor/bin
chmod 0751 $MODPATH/system/vendor/bin/hw
DIR=`find $MODPATH/system/vendor -type d`
for DIRS in $DIR; do
  chown 0.2000 $DIRS
done
magiskpolicy --live "type system_lib_file"
magiskpolicy --live "type vendor_file"
magiskpolicy --live "type vendor_configs_file"
magiskpolicy --live "dontaudit { system_lib_file vendor_file vendor_configs_file } labeledfs filesystem associate"
magiskpolicy --live "allow     { system_lib_file vendor_file vendor_configs_file } labeledfs filesystem associate"
magiskpolicy --live "dontaudit init { system_lib_file vendor_file vendor_configs_file } dir relabelfrom"
magiskpolicy --live "allow     init { system_lib_file vendor_file vendor_configs_file } dir relabelfrom"
magiskpolicy --live "dontaudit init { system_lib_file vendor_file vendor_configs_file } file relabelfrom"
magiskpolicy --live "allow     init { system_lib_file vendor_file vendor_configs_file } file relabelfrom"
chcon -R u:object_r:system_lib_file:s0 $MODPATH/system/lib*
chcon -R u:object_r:vendor_file:s0 $MODPATH/system/vendor
chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/etc
chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/odm/etc
ui_print " "

# vendor_overlay
if [ $DOLBY == true ]; then
  DIR=/product/vendor_overlay
  if [ -d $DIR ]; then
    ui_print "- Fixing $DIR mount..."
    cp -rf $DIR/*/* $MODPATH/system/vendor
    ui_print " "
  fi
fi

# uninstaller
NAME=DolbyUninstaller.zip
if [ $DOLBY == true ]; then
  ui_print "- Flash /sdcard/$NAME"
  ui_print "  via recovery if you got bootloop"
  cp -f $MODPATH/$NAME /sdcard
  ui_print " "
fi
rm -f $MODPATH/$NAME







