
ui_print "　　　　［请选择清脆样式］"
ui_print "　　　 音量↑:咚　音量↓:结实"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   File="$C/70_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/71_*.bin"
   cp -rf $F/71_*.bin $D/$(basename ${File})
   File="$C/72_*.bin"
   cp -rf $F/72_*.bin $D/$(basename ${File})
   File="$C/162_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/163_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/169_*.bin"
   cp -rf $F/71_*.bin $D/$(basename ${File})
   File="$C/92_*.bin"
   cp -rf $F/s/70_*.bin $D/$(basename ${File})
   File="$C/91_*.bin"
   cp -rf $F/s/71_*.bin $D/$(basename ${File})
   File="$C/84_*.bin"
   cp -rf $F/s/72_*.bin $D/$(basename ${File})
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
   cp -rf $F/s/*.prop $M
   File="$C/70_*.bin"
   cp -rf $F/s/70_*.bin $D/$(basename ${File})
   File="$C/71_*.bin"
   cp -rf $F/s/71_*.bin $D/$(basename ${File})
   File="$C/72_*.bin"
   cp -rf $F/s/72_*.bin $D/$(basename ${File})
   File="$C/162_*.bin"
   cp -rf $F/s/70_*.bin $D/$(basename ${File})
   File="$C/163_*.bin"
   cp -rf $F/s/70_*.bin $D/$(basename ${File})
   File="$C/169_*.bin"
   cp -rf $F/s/71_*.bin $D/$(basename ${File})
   File="$C/92_*.bin"
   cp -rf $F/70_*.bin $D/$(basename ${File})
   File="$C/91_*.bin"
   cp -rf $F/71_*.bin $D/$(basename ${File})
   File="$C/84_*.bin"
   cp -rf $F/72_*.bin $D/$(basename ${File})
esac
ui_print "　　　　 ［选择清理样式］"
ui_print "　　 音量↑:四段　音量↓:转子"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
   ui_print "　　　　 ［选择转子时长］"
   ui_print "　　　 音量↑:长　音量↓:短"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　 ✓✓"
     File="$F/93_*.bin"
     cp -rf $F/43_*.bin $F/$(basename ${File})
     ;;
     *)
     ui_print "　　　　　　　　　　 ✓✓"
     File="$F/93_*.bin"
     cp -rf $F/76_*.bin $F/$(basename ${File})
   esac
esac
ui_print "　　［默认100%强度,是否降低］"
ui_print "　　　 音量↑:是　音量↓:否"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   filename=$F/93_*.bin
   filesize=`ls -l $filename | awk '{ print $5 }'`
   maxsize=$((5538))
   if [ $filesize -gt $maxsize ]; then
     File="$F/93_*.bin"
     cp -rf $C/153_*.bin $F/$(basename ${File})
   elif [ $filesize -lt $maxsize ]; then
     File="$F/93_*.bin"
     cp -rf $C/113_*.bin $F/$(basename ${File})
   else
     File="$F/93_*.bin"
     cp -rf $C/55_*.bin $F/$(basename ${File})
   fi
   File="$F/43_*.bin"
   cp -rf $C/153_*.bin $F/$(basename ${File})
   File="$F/76_*.bin"
   cp -rf $C/113_*.bin $F/$(basename ${File})
   File="$F/87_*.bin"
   cp -rf $C/165_*.bin $F/$(basename ${File})
   rm -rf $MODPATH/File/85_*bin
   rm -rf $MODPATH/File/86_*bin
   rm -rf $MODPATH/File/171_*bin
   ui_print "　　　　　 ［选择强度%］"
   ui_print "　　　 音量↑:90　音量↓:80"
   key_click=""
   while [ "$key_click" = "" ]; do
     key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
     sleep 0.2
   done
   case "$key_click" in
     "KEY_VOLUMEUP")
     ui_print "　　　 ✓✓"
     cp -rf $F/low/90/* $M
     File="$C/162_*.bin"
     cp -rf $D/71_*.bin $D/$(basename ${File})
     File="$C/163_*.bin"
     cp -rf $D/71_*.bin $D/$(basename ${File})
     File="$C/169_*.bin"
     cp -rf $D/72_*.bin $D/$(basename ${File})
     File="$C/70_*.bin"
     mv -f $D/71_*.bin $D/$(basename ${File})
     ;;
     *)
     ui_print "　　　　　　　　　　 ✓✓"
     cp -rf $F/low/80/* $M
     File="$C/162_*.bin"
     cp -rf $D/72_*.bin $D/$(basename ${File})
     File="$C/163_*.bin"
     cp -rf $D/72_*.bin $D/$(basename ${File})
     File="$C/169_*.bin"
     cp -rf $D/72_*.bin $D/$(basename ${File})
     File="$C/70_*.bin"
     mv -f $D/72_*.bin $D/$(basename ${File})
   esac
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
esac
File="$C/90_*.bin"
cp -rf $F/93_*.bin $D/$(basename ${File})
File="$C/43_*.bin"
cp -rf $F/43_*.bin $D/$(basename ${File})
File="$C/74_*.bin"
cp -rf $F/76_*.bin $D/$(basename ${File})
File="$C/76_*.bin"
cp -rf $F/76_*.bin $D/$(basename ${File})
File="$C/85_*.bin"
cp -rf $F/85_*.bin $D/$(basename ${File})
File="$C/86_*.bin"
cp -rf $F/86_*.bin $D/$(basename ${File})
File="$C/87_*.bin"
cp -rf $F/87_*.bin $D/$(basename ${File})
File="$C/93_*.bin"
cp -rf $F/93_*.bin $D/$(basename ${File})
File="$C/171_*.bin"
cp -rf $F/171_*.bin $D/$(basename ${File})
File="$C/209_*.bin"
cp -rf $D/169*.bin $D/$(basename ${File})
File="$C/210_*.bin"
cp -rf $D/162*.bin $D/$(basename ${File})
File="$C/212_*.bin"
cp -rf $D/93*.bin $D/$(basename ${File})
File="$C/213_*.bin"
cp -rf $D/93*.bin $D/$(basename ${File})
File="$C/216_*.bin"
cp -rf $D/87*.bin $D/$(basename ${File})
ui_print "　 　［仅键盘+光标+手势振动］"
ui_print "　　　 音量↑:是　音量↓:否"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   cp -rf $F/*Input/* $M
   File="$C/169_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/87_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/90_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/93_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/209_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/210_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/212_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/213_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
esac
ui_print "　　　 ［是否禁用手势振动］"
ui_print "　　　 音量↑:是　音量↓:否"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   filename=$D/93_*.bin
   filesize=`ls -l $filename | awk '{ print $5 }'`
   maxsize=$((0))
   if [ $filesize -eq $maxsize ]; then
     cp -rf $F/*OFF/1/* $M
   else
     cp -rf $F/*OFF/2/* $M
   fi
   File="$C/70_*.bin"
   cp -rf $D/162_*.bin $D/$(basename ${File})
   File="$C/162_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   File="$C/163_*.bin"
   cp -rf $F/00*.bin $D/$(basename ${File})
   ;;
   *)
   ui_print "　　　　　　　　　　 ✓✓"
esac