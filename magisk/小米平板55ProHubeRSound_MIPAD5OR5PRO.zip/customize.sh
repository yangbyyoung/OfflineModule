SKIPUNZIP=0
MODDIR=${0%/*}
alias sh='/system/bin/sh'
a=$(getprop ro.system.build.version.release)

print_modname() {
  ui_print "***********************"
  ui_print "Designed By Huber_HaYu 以及团队的支持"
  ui_print "***********************"
  #sleep 2
}

dax_dolby() {
    MIUI_VER=$(grep "ro\.system\.build\.version\.incremental=" /system/build.prop | cut -d '=' -f 2)

    if [ ! -f "$MODPATH/Dax_Dolby/Bass/dax-default.xml" ];then
        echo "未找到主调音文件 或 主调音文件被第三方删除！"
        echo "- -"
        echo "模块效果会 -微乎其微-"
        sleep 1
        echo "已终止模块安装进程.."
        exit 1
    fi

    if [[ $MIUI_VER == *"DEV"* ]]; then
        #sleep 2
        DAX_DOLBY="$MODPATH/Dax_Dolby/Bass/dax-default.xml"
        DAX_T="$MODPATH/Dax_Dolby/Bass/dax.t"
        EQUALIZER="$MODPATH/Dax_Dolby/Bass/EQ/normal.xml"
        
        echo "当前设备系统处于开发版本（B包）"
        cp -f $DAX_DOLBY $MODPATH/system/vendor/etc/dolby
        cp -f $DAX_T $MODPATH/system/vendor/etc/dolby
        cp -f $EQUALIZER $MODPATH/config
        else
            DAX_DOLBY="$MODPATH/Dax_Dolby/Bass/dax-default.xml"
            DAX_T="$MODPATH/Dax_Dolby/Bass/dax.t"
            EQUALIZER="$MODPATH/Dax_Dolby/Bass/EQ/normal.xml"
            
            #sleep 2
            echo "当前设备系统处于稳定版（B包）"
            cp -f $DAX_DOLBY $MODPATH/system/vendor/etc/dolby
            cp -f $DAX_T $MODPATH/system/vendor/etc/dolby
            cp -f $EQUALIZER $MODPATH/config
    fi
}

boot_first_load(){
    update_path="/data/adb/modules_update/MIPAD5OR5PRO"
    conf="/data/data/com.miui.misound/shared_prefs/mi_sound_preference.xml"
    pm disable com.miui.misound
    #pm clear com.miui.misound
    mkdir -p /data/data/com.miui.misound/shared_prefs
    cp -f $update_path/config/normal.xml $conf
    pm enable com.miui.misound
    am start --windowingMode 5 -n com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
    sleep 2.5
    am force-stop com.miui.misound
    am force-stop com.android.settings
    cp -f $update_path/system/app/MiSound/MiSound.apk $update_path/system/product/app/MiSound/MiSound.apk
    sleep 3
    cp -f $MODPATH/config/com.miui.misound_preferences.xml /data/data/com.miui.misound/shared_prefs
    sleep 1
    ui_print "Done."
}


set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
    chmod a+x "$MODPATH/Mly"
    chmod a+x "$MODPATH/Shadow3"
}

mly_auto() {
    
    sleep 0.5
    rm -rf $MODPATH/Mly
    rm -rf /data/adb/modules/MIPAD5OR5PRO/Mly

}

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
#sleep 1.5
ui_print " ————————————————————————————————————————————————————"
ui_print " 本模块内的扬声器振幅、Virtual Bass，压限参数来自"
ui_print "       ---------酷安@Huber_HaYu---------"
ui_print " ————————————————————————————————————————————————————"
#sleep 1
ui_print "请稍后..."
#sleep 3
ui_print "------------------------------"
ui_print "【团队感谢：SetoSkins(代码:service.sh) shadow3(代码:Mly) 灵聚、神生(代码)"
ui_print "mly墨临渊(调音、调试) 中二的番茄（辅助调音） big_chair(辅助调音) bug_casc(辅助调音) 是Ray酱呀(底层硬件调音)】"
ui_print "------------------------------"


dax_dolby
print_modname
boot_first_load
set_permissions
mly_auto