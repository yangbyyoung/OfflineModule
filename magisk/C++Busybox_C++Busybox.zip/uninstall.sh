#!/bin/sh
MODDIR=${0%/*}

pm uninstall com.android

# 这个脚本会在删除模块的时候执行