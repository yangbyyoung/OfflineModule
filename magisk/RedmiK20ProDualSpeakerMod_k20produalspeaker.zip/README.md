Changelog:

v1 - Initial Release
v2 - Added new earsp path
v3 - Removed earsp path, Minimized delay between both the speakers
v4 - Optimized earpiece and mainspeaker gains, Eliminate delay between both the speakers
v5 - Add dualspeaker path for audio-ull, new magisk template