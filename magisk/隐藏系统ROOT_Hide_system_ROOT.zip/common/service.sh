#!/system/bin/sh


MODDIR=${0%/*}
mount --bind $MODDIR/mirror/system/xbin /system/xbin
