#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread


mount -o rw,remount /product
mount -o rw,remount /odm

ln -s $MODDIR/odm/lib64/libmegface.so /odm/lib64/libmegface.so
ln -s $MODDIR/odm/lib64/libmeglive.so /odm/lib64/libmeglive.so
ln -s $MODDIR/odm/lib64/libMegviiUnlock.so /odm/lib64/libMegviiUnlock.so
ln -s $MODDIR/odm/lib64/libunlockmegcv.so /odm/lib64/libunlockmegcv.so
ln -s $MODDIR/product/etc/facerecognize /product/etc/

mount -o ro,remount /product
mount -o ro,remount /odm
