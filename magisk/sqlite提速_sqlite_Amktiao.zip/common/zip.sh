unzip -oq "$ZIPFILE" 'common/*' -d $TMPDIR >&2
zip=$TMPDIR/common/zip
chmod 755 $zip
set_perm $zip 0 2000 0755 u:object_r:clatd_exec:s

cd $MODPATH/system/media/theme/default/framework-res
$zip -r $MODPATH/system/media/theme/default/framework-res.zip ./* >/dev/null
rm -r $MODPATH/system/media/theme/default/framework-res
cat $MODPATH/system/media/theme/default/framework-res.zip > $MODPATH/system/media/theme/default/framework-res
rm -f $MODPATH/system/media/theme/default/framework-res.zip