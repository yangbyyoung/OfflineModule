sleep 10
echo 105000 > /sys/class/thermal/thermal_zone24/trip_point_1_temp
echo 105000 > /sys/class/thermal/thermal_zone25/trip_point_0_temp