#!/system/bin/sh
MODDIR=${0%/*}
while true ;do
/sbin/magisk su -c "sh /data/adb/modules/clear/system/clear.sh "
/dev/*/magisk su -c "sh /data/adb/modules/clear/system/clear.sh "
sleep 1d
done