# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
if [ -f "/data/system/refresh_rate_config.bak" ];then
  mv -f /data/system/refresh_rate_config.bak /data/system/refresh_rate_config.xml
fi