sleep 2s
#整合包作者:爽歪歪
#优化cpu分配
echo "0-2" > /dev/cpuset/background/cpus
echo "3-5" > /dev/cpuset/system-background/cpus
echo "0-2" > /dev/cpuset/audio-app/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
echo "1-3" > /dev/cpuset/restricted/cpus
#调节cpu激进度
echo "100" > /dev/stune/foreground/schedtune.boost
echo "100" > /dev/stune/top-app/schedtune.boost
echo "0" > /dev/stune/background/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.boost
#大小核心分配优化
echo "49" > /proc/sys/kernel/sched_downmigrate
echo "50" > /proc/sys/kernel/sched_upmigrate
echo "0" > /proc/sys/kernel/sched_boost
#io优化
echo "2" > /sys/block/mmcblk0/queue/rq_affinity

echo schedutil > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo schedutil > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor

function white_list()
{
  echo -n "  + $1 "
  pgrep -o $1 | while read pid; do
  renice -n 5 -p $pid
  done
}

#surfaceflinger
white_list surfaceflinger
#系统服务
white_list system_server

#修改dns为腾讯服务器

setprop net.eth0.dns1 223.5.5.5
setprop net.eth0.dns2 223.6.6.6

setprop net.dns1 223.5.5.5
setprop net.dns2 223.6.6.6

setprop net.ppp0.dns1 223.5.5.5
setprop net.ppp0.dns2 223.6.6.6

setprop net.rmnet0.dns1 223.5.5.5
setprop net.rmnet0.dns2 223.6.6.6

setprop net.rmnet1.dns1 223.5.5.5
setprop net.rmnet1.dns2 223.6.6.6

setprop net.pdpbr1.dns1 223.5.5.5
setprop net.pdpbr1.dns2 223.6.6.6

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 223.6.6.6:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 223.5.5.5:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 223.6.6.6:53
#利用chrt命令，把和渲染、触控相关的进程优先级设置为实时调度（rt)，进而增加流畅度，注意：不可随意增加进程，因为实时调度是给核心进程使用的

#另外模块附带了一些其他优化
chmod 777 /data/adb/modules/boost7/server.sh

function boost()
{
  pgrep -o $1 | while read pid; do
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  chrt -f -p $pid 70
  done
}

boost composer
boost touchpan
boost pq
boost sensors
boost system_server
boost surfaceflinger

#系统界面UI优化
sleep 2s

function white_list()
{
  pgrep -o $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white_list surfaceflinger
white_list webview_zygote

function white()
{
  pgrep -f $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white android.hardware.graphics.composer@2.2-service
white zygote
white zygote64
white com.android.systemui

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 1 > /dev/stune/rt/schedtune.prefer_idle
echo 20 > /dev/stune/rt/schedtune.boost
echo 20 > /dev/stune/top-app/schedtune.boost
echo 1 > /dev/stune/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 50 > /dev/memcg/memory.swappiness

#开机等待
sleep 35s

#禁用lsposed日志
rm -rf /data/adb/lspd/log
touch /data/adb/lspd/log
chmod 000 /data/adb/lspd/log

#关闭HW叠加层
while :
do
if [ $sf -eq 1 ]
then
service call SurfaceFlinger 1008 i32 1
break
else
sf=$(service list | grep -c "SurfaceFlinger")
sleep 2
fi
done

#开启maliGPU游戏模式
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
echo 1 >/sys/module/ged/parameters/gx_game_mode

#修复ROOT后F2FS性能下降的问题(如不生效请手动将sdc59改成你自己手机机型下的目录)
while [[ "$(cat /sys/fs/f2fs/sdc59/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/sdc59/cp_interval
done

while [[ "$(cat /sys/fs/f2fs/sdc59/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/sdc59/gc_urgent_sleep_time
done

while [[ "$(cat /sys/fs/f2fs/sdc59/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/sdc59/iostat_enable
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
done

#删除无用垃圾(来自酷安@风雪如花剑如霜)
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /storage/emulated/0/.com.android.providers.downloads
rm -rf /storage/emulated/0/.com.android.providers.downloads.ui
rm -rf /data/user/0/com.douban.frodo/app_rexxar-douban
rm -rf /data/user/0/com.douban.frodo/cache
rm -rf /data/vendor/wlan_logs
rm -rf /data/user/0/com.picsart.studio/files/bitmap_cache/editor/view
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#内核优化
echo “8″ > /proc/sys/vm/page-cluster
echo “64000″ > /proc/sys/kernel/msgmni
echo “64000″ > /proc/sys/kernel/msgmax
echo “10″ > /proc/sys/fs/lease-break-time
echo “500,512000,64,2048″ > /proc/sys/kernel/sem

#来自爽歪歪
if
rm -rf /cache/magisk.log
touch   /cache/magisk.log
chmod 000  /cache/magisk.log
/sbin/.magisk/busybox/chattr +i  /cache/magisk.log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 


then
echo "清理成功"
fi

#开启F2FS加速回收
# 启用f2fs_gc_booster
echo "1" > /sys/fs/f2fs/sdc59/gc_booster

#存储io激进程度
echo "2" > /sys/block/mmcblk0/queue/rq_affinity
echo "2" > /sys/block/sda/queue/rq_affinity
echo "2" > /sys/block/sdb/queue/rq_affinity
echo "2" > /sys/block/sdc/queue/rq_affinity

#提升IO速度与网络速度
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo noop > /sys/block/sda/queue/scheduler
echo noop > /sys/block/sdc/queue/scheduler
echo noop > /sys/block/sdb/queue/scheduler
echo noop > /sys/block/mmcblk0/queue/scheduler

#安卓tcp优化（调整initcwnd和initrwnd，减少数据包的传递次数，提高传输速度）
ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 40;
done

#进程可打开文件数优化
echo 2390251 > /proc/sys/fs/file-max

#主动整理内存碎片，提升系统性能
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

alias free=$(magisk --path)/.magisk/busybox/free
test -e /sbin/.magisk/busybox/ && alias free=/sbin/.magisk/busybox/free

function M(){
all=`free -m|grep "Mem"|awk '{print $2}'`
use=`free -m|grep "Mem"|awk '{print $3}'`
echo $(($use*100/$all))
}

if [ $(M) -ge 60 ];then
sync 
echo 3 > /proc/sys/vm/drop_caches  
echo 1 > /proc/sys/vm/compact_memory
sync
fi

#关闭LMK调试提升性能
echo 0 > /sys/module/lowmemorykiller/parameters/debug_level

#ZRAM线程增加到8线程，提升压缩效率和流畅度
echo 8 > /sys/block/zram0/max_comp_streams

sleep 2s

#通过对sched_relax_domain_level值的修改，扩大cpu负载均衡时查找的范围，防止因为某个范围内的核心因为负载过大而降低性能。

echo 1 > /dev/cpuset/sched_relax_domain_level
echo 1 > /dev/cpuset/system-background/sched_relax_domain_level
echo 1 > /dev/cpuset/background/sched_relax_domain_level
echo 1 > /dev/cpuset/foreground/sched_relax_domain_level
echo 1 > /dev/cpuset/top-app/sched_relax_domain_level

# 清理内存
killall -9 com.xiaomi.market
killall -9 com.miui.screenrecorder
killall -9 com.miui.bugreport
killall -9 com.miui.analytics

#索要777权限进行tcp网络优化
chmod 777 /data/adb/modules/tcpboost/server.sh

echo "
net.ipv4.conf.all.route_localnet=1
net.ipv4.ip_forward = 1
net.ipv4.conf.all.forwarding = 1
net.ipv4.conf.default.forwarding = 1
net.ipv6.conf.all.forwarding = 1
net.ipv6.conf.default.forwarding = 1
net.ipv6.conf.lo.forwarding = 1
net.ipv6.conf.all.accept_ra = 2
net.ipv6.conf.default.accept_ra = 2
net.core.netdev_max_backlog = 100000
net.core.netdev_budget = 50000
net.core.netdev_budget_usecs = 5000
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 67108864
net.core.wmem_default = 67108864
net.core.optmem_max = 65536
net.core.somaxconn = 10000
net.ipv4.icmp_echo_ignore_all = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.icmp_ignore_bogus_error_responses = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.default.rp_filter = 0
net.ipv4.conf.all.rp_filter = 0
net.ipv4.tcp_keepalive_time = 8
net.ipv4.tcp_keepalive_intvl = 8
net.ipv4.tcp_keepalive_probes = 1
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syncookies = 0
net.ipv4.tcp_rfc1337 = 0
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 8
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_max_tw_buckets = 2000000
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.udp_rmem_min = 8192
net.ipv4.udp_wmem_min = 8192
net.ipv4.tcp_mtu_probing = 0
net.ipv4.tcp_autocorking = 0
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_max_syn_backlog = 30000
net.ipv4.tcp_notsent_lowat = 16384
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.tcp_frto = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv4.neigh.default.gc_thresh3=8192
net.ipv4.neigh.default.gc_thresh2=4096
net.ipv4.neigh.default.gc_thresh1=2048
net.ipv6.neigh.default.gc_thresh3=8192
net.ipv6.neigh.default.gc_thresh2=4096
net.ipv6.neigh.default.gc_thresh1=2048
net.ipv4.tcp_max_syn_backlog = 262144
net.netfilter.nf_conntrack_max = 262144
net.nf_conntrack_max = 262144
" > /data/sysctl.conf

chmod 777 /data/sysctl.conf

sysctl -p /data/sysctl.conf

ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 20;



am kill logd
killall -9 logd
am kill logd.rc
killall -9 logd.rc
stop logd 2> /dev/null
killall -9 logd 2> /dev/null
stop logd.rc 2> /dev/null
killall -9 logd.rc 2> /dev/null

#开启maliGPU游戏模式
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
echo 1 >/sys/module/ged/parameters/gx_game_mode

#开启联发科GPU无限缓存
echo Y > /sys/kernel/debug/mali0/ctx/defaults/infinite_cache

#禁用lsposed日志
rm -rf /data/adb/lspd/log
touch /data/adb/lspd/log
chmod 000 /data/adb/lspd/log

#---耗电无用进程优化---
am kill cnss_diag
killall -9 cnss_diag
stop cnss_diag
#禁用tcpdump
am kill tcpdump
killall -9 tcpdump
stop tcpdump

#开机释放缓存（尝试清理）
sleep 10
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory

#干掉iorap.cmd.compiler
am kill iorap.cmd.compiler
killall -9 iorap.cmd.compiler
stop iorap.cmd.compiler

#清理wifi 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs

#关闭HW叠加层
while :
do
if [ $sf -eq 1 ]
then
service call SurfaceFlinger 1008 i32 1
break
else
sf=$(service list | grep -c "SurfaceFlinger")
sleep 2
fi
done

#利用fstrim对设备读写进行优化（来自酷安@温亮平）
mkdir 777 /data/cron.d
echo "*/20 * * * * /data/cron.sh" > /data/cron.d/root
echo "
fstrim /data
fstrim /cache
fstrim /system
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
" > /data/cron.sh
crond -c /data/cron.d

#修复ROOT后F2FS性能下降的问题(如不生效请手动将sdc59改成你自己手机机型下的目录)
while [[ "$(cat /sys/fs/f2fs/sdc59/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/sdc59/cp_interval
done

while [[ "$(cat /sys/fs/f2fs/sdc59/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/sdc59/gc_urgent_sleep_time
done

while [[ "$(cat /sys/fs/f2fs/sdc59/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/sdc59/iostat_enable
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
done

#app清理＋去广告来(自酷安@风雪如花剑如霜)
C=/sbin/.magisk/busybox/rm
#清理内容
D=/data/media/0
$C -rf $D/360
$C -rf $D/tad
$C -rf $D/mivideo
$C -rf $D/MT2/.temp/*
$C -rf $D/MiMarket
$C -rf $D/OSSLog
$C -rf $D/QQBrowser
$C -rf $D/bytedance
$C -rf $D/cache
$C -rf $D/dctp
$C -rf $D/did
$C -rf $D/duilite
$C -rf $D/tbs
$C -rf $D/tga
$C -rf $D/ttscache
$C -rf $D/txrtmp
$C -rf $D/.cc
$C -rf $D/.com.taobao.dp
$C -rf $D/.DataStorage
$C -rf $D/.gs_file
$C -rf $D/.OAIDSystemConfigh
$C -rf $D/.OAIDSystemConfig
$C -rf $D/.tbs
$C -rf $D/.turingdebug
$C -rf $D/.UTSystemConfig
$C -rf $D/.vivo
$C -rf $D/umeng_cache
$C -rf $D/.gs_fs0
$C -rf $D/.gs_fs3
$C -rf $D/.gs_fs6
$C -rf $D/mipush
$C -rf $D/.turing.dat
$C -rf $D/.zzz
$C -rf $D/.um
$C -rf $D/.a.dat
$C -rf $D/.a.dat
$C -rf $D/.uxx
$C -rf $D/.*Trash*
$C -rf $D/.Android
$C -rf $D/.BD_SAPI_CACHE
$C -rf $D/.ColombiaMedia
$C -rf $D/.volley.cache
$C -rf $D/at
$C -rf $D/baidu
$C -rf $D/libs
$C -rf $D/setup
$C -rf $D/sitemp
$C -rf $D/Subtitles
$C -rf $D/GX_Download
$C -rf $D/1
$C -rf $D/.UTSystemConfig
$C -rf $D/.turingdebug
$C -rf $D/.Trusfort
$C -rf $D/.pzir
$C -rf $D/.protected_image
$C -rf $D/.mm_sdk_source
$C -rf $D/.lm_device
$C -rf $D/.INSTALLATION
$C -rf $D/.Download
$C -rf $D/.dlprovider
$C -rf $D/.andro
$C -rf $D/miad
$C -rf $D/sina/weibo/imageMapper_cache
$C -rf $D/logs
$C -rf $D/logger
$C -rf $D/eg.a
$C -rf $D/Download/.cu
$C -rf /proc/sys/debug/*
$C -rf /sys/kernel/debug/*
$C -rf /data/system/dropbox/*
$C -rf /dev/fscklogs/*
$C -rf /data/system/package_cache/*
$C -rf /data/tombstones/*
$C -rf /data/local/*
$C -rf /data/system/nativedebug/*
$C - rf  /data/media/0/.com.android.providers.downloads.ui/*
$C - rf  /data/media/0/.com.android.providers.downloads/*
find $D/ -name '.td-3' -type f -print -exec rm -rf {} \;
find $D/ -name '.tdck' -type f -print -exec rm -rf {} \;
find $D/ -name '*.log' -type f -print -exec rm -rf {} \;
find $D/ -name '*.tmp' -type f -print -exec rm -rf {} \;
find $D/ -name '*.log.*' -type f -print -exec rm -rf {} \;
find $D/ -name '*._log.*' -type f -print -exec rm -rf {} \;
K=/sbin/.magisk/busybox/chattr
#禁用广告
touch $D/sina/weibo/imageMapper_cache
touch $D/tad
touch $D/GX_Download
touch $D/miad
touch $D/umeng_cache
$K +i $D/tad
$K +i $D/GX_Download
$K +i $D/miad
$K +i $D/umeng_cache
$K +i $D/sina/weibo/imageMapper_cache

#UFS(来自酷安@风雪如花剑如霜)
#禁用I/O统计
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sdb/queue/iostats
echo 0 > /sys/block/sdc/queue/iostats
echo 0 > /sys/block/sdd/queue/iostats
echo 0 > /sys/block/sde/queue/iostats
echo 0 > /sys/block/sdf/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/sda/queue/nomerges
echo 0 > /sys/block/sdb/queue/nomerges
echo 0 > /sys/block/sdc/queue/nomerges
echo 0 > /sys/block/sdd/queue/nomerges
echo 0 > /sys/block/sde/queue/nomerges
echo 0 > /sys/block/sdf/queue/nomerges

#EMMC
#禁用I/O 统计(EMMC)
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/mmcblk0/queue/nomerges
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats


#禁用I/O调试，UFS 和EMMC皆可用
echo 0 > /sys/block/loop0/queue/iostats
echo 0 > /sys/block/loop1/queue/iostats
echo 0 > /sys/block/loop2/queue/iostats
echo 0 > /sys/block/loop3/queue/iostats
echo 0 > /sys/block/loop4/queue/iostats
echo 0 > /sys/block/loop5/queue/iostats
echo 0 > /sys/block/loop6/queue/iostats
echo 0 > /sys/block/loop7/queue/iostats
echo 0 > /sys/block/loop8/queue/iostats
echo 0 > /sys/block/loop9/queue/iostats
echo 0 > /sys/block/loop10/queue/iostats
echo 0 > /sys/block/loop11/queue/iostats
echo 0 > /sys/block/loop12/queue/iostats
echo 0 > /sys/block/loop13/queue/iostats
echo 0 > /sys/block/loop14/queue/iostats
echo 0 > /sys/block/loop15/queue/iostats

#关闭RAMDUMP
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps

# 禁用驱动程序调试(和i/o无关)
echo 0 > /sys/module/binder/parameters/debug_mask
echo 0 > /sys/module/binder_alloc/parameters/debug_mask
echo 0 > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo 0 > /sys/module/millet_core/parameters/millet_debug
echo 0 > /proc/sys/migt/migt_sched_debug
echo N > /sys/kernel/debug/debug_enabled

#禁用binder活页夹日志
echo 0 > /sys/module/binder/parameters/debug_mask

# 禁用用户空间向dmesg写入日志
echo off > /proc/sys/kernel/printk_devkmsg

# 禁用调度统计
echo 0 > /proc/sys/kernel/sched_schedstats

#更改磁盘I/O预读大小
echo 128 > /sys/block/sda/queue/read_ahead_kb
echo 128 > /sys/block/sdb/queue/read_ahead_kb
echo 128 > /sys/block/sdc/queue/read_ahead_kb
echo 128 > /sys/block/sde/queue/read_ahead_kb
#* eMMC设备使用命令:
echo 128 > /sys/block/mmcblk0/queue/read_ahead_kb

#调整虚拟内存更新/刷新间隔
echo 20 > /proc/sys/vm/stat_interval

#6. 调整page页面集群大小
echo 0 > /proc/sys/vm/page-cluster

# 调整脏页写回策略时间
echo 3000 > /proc/sys/vm/dirty_expire_centisecs

# ZRAM分区参数调整
echo 128 > /sys/block/zram0/queue/read_ahead_kb
echo 36 > /sys/block/zram0/queue/nr_requests

#开机40秒清理电池优化名单(来自酷安@大铁 早起刷刷机)
sleep 40
#优化白名单，（添加应用包名后，将保留应用不被移出电池优化）
#示例：+com.tencent.mm +后面是微信包名
noDozes="
+com.tencent.mm 
+com.tencent.mobileqq
"
#执行移出电池优化名单
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes

#安卓UI流畅度优化，提高ui相关进程优先级
sleep 2s

function white_list()
{
  pgrep -o $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white_list surfaceflinger
white_list webview_zygote

function white()
{
  pgrep -f $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white android.hardware.graphics.composer@2.2-service
white zygote
white zygote64
white com.android.systemui

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 1 > /dev/stune/rt/schedtune.prefer_idle
echo 20 > /dev/stune/rt/schedtune.boost
echo 20 > /dev/stune/top-app/schedtune.boost
echo 1 > /dev/stune/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 50 > /dev/memcg/memory.swappiness

#开启F2FS加速回收
# 启用f2fs_gc_booster
echo "1" > /sys/fs/f2fs/sdc59/gc_booster

#存储io激进程度
echo "2" > /sys/block/mmcblk0/queue/rq_affinity
echo "2" > /sys/block/sda/queue/rq_affinity
echo "2" > /sys/block/sdb/queue/rq_affinity
echo "2" > /sys/block/sdc/queue/rq_affinity

#提升IO速度与网络速度
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
echo noop > /sys/block/sda/queue/scheduler
echo noop > /sys/block/sdc/queue/scheduler
echo noop > /sys/block/sdb/queue/scheduler
echo noop > /sys/block/mmcblk0/queue/scheduler

#安卓tcp优化（调整initcwnd和initrwnd，减少数据包的传递次数，提高传输速度）
ip route | while read r; do
ip route change $r initcwnd 20;
done

ip route | while read r; do
ip route change $r initrwnd 40;
done

#进程可打开文件数优化
echo 2390251 > /proc/sys/fs/file-max

#主动整理内存碎片，提升系统性能
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

alias free=$(magisk --path)/.magisk/busybox/free
test -e /sbin/.magisk/busybox/ && alias free=/sbin/.magisk/busybox/free

function M(){
all=`free -m|grep "Mem"|awk '{print $2}'`
use=`free -m|grep "Mem"|awk '{print $3}'`
echo $(($use*100/$all))
}

if [ $(M) -ge 60 ];then
sync 
echo 3 > /proc/sys/vm/drop_caches  
echo 1 > /proc/sys/vm/compact_memory
sync
fi

#关闭LMK调试提升性能
echo 0 > /sys/module/lowmemorykiller/parameters/debug_level

#ZRAM线程增加到8线程，提升压缩效率和流畅度
echo 8 > /sys/block/zram0/max_comp_streams

#指定包名
com="
com.miui.analytics
com.xiaomi.joyose
"

#强力卸载
for i in $com
do
pm uninstall -k --user 0 $i

rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService