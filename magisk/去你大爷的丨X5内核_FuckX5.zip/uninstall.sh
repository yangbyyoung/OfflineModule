# Don't modify anything after this
function kx5()
{
rm -rf $1
mkdir -p $1
chmod -R 777 $1
}

A=`find /data/data -iname '*app_tbs*' -type d -print`
B=`find /data/data -iname '*app_tbs_64*' -type d -print`
C=`find /data/media -name '*.tbs.*' -print -type f`
D=`find /data/data -iname '*app_xwalk*' -print -type d`
E=`find /data/data -iname '*app_x5webview*' -print -type d`

for i in $A;do
kx5 $i 2>/dev/null
done

for i in $B;do
kx5 $i 2>/dev/null
done

for i in $C;do
kx5 $i 2>/dev/null
done

for i in $D;do
kx5 $i 2>/dev/null
done

for i in $E;do
kx5 $i 2>/dev/null
done
