SKIPUNZIP=1
unzip -o "$ZIPFILE" -x 'META-INF/*' '请将开机动画放置在这里' -d $MODPATH >&2
source $MODPATH/sh/info.sh
source $MODPATH/sh/bootanimation.sh
source $MODPATH/sh/check_boot_m.sh
source $MODPATH/sh/check_bootanimation.sh
source $MODPATH/sh/boot_view.sh
rm -rf $MODPATH/sh
set_perm_recursive  $MODPATH  0  0  0755  0644
