#!/system/bin/sh

function kmsg_logcat(){
if test -e /proc/kmsg ;then
	echo -e "\n抓取kmsg内核日志中……"
	echo "在后台运行20s……"
	echo "可退出终端界面……"
	timeout 20s cat /proc/kmsg | grep -Ei 'thermal|thermald|temp' > "${0%/*}/kmsg_thermal.json"
else
	echo "不存在/proc/kmsg！"
fi
}

function Running_logcat(){
if test "$(which -a logcat)" != "" ;then
	echo -e "\n抓取logcat日志中……"
	echo "在后台运行20s……"
	echo -e "\n可退出终端界面……\n"
	timeout 20s logcat -b all -v color | grep -Ei 'thermal|thermald|temp' > "${0%/*}/logcat_thermal.json"
else
	echo "不存在logcat！"
fi
}

function Running_dmesg(){
if test "$(which -a dmesg)" != "" ;then
	echo -e "\n抓取dmesg日志中……"
	dmesg | grep -Ei 'thermal|thermald|temp' > "${0%/*}/dmesg_thermal.json"
	echo "可退出终端界面……"
else
	echo "不存在dmesg！"
fi
}


(kmsg_logcat &)
(Running_logcat &)
(Running_dmesg &)
