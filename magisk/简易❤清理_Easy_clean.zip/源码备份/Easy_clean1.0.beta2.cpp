//核心源码头文件
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <dirent.h>
#include <pthread.h>
//#include <glob.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
//清理源码头文件
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <sys/stat.h>
#include <dirent.h>
#include <stdbool.h>
//#include <time.h>
//#include <unistd.h>
//清理源码数据及函数声明
struct DirList {
    char** dirs;
    int count;
};
char update_clean_info_cmd[1024];
const char log_clean[] = "/sdcard/Android/EasyClean/clean.log";
const char rules_clean[]="/sdcard/Android/EasyClean/Rules/CleanFile.conf";
const char rules_clean_w[]="/sdcard/Android/EasyClean/Rules/清理白名单.conf";
int count_dir;//用于记录清理目录数
int count_file;//用于记录清理文件数
struct DirList clean_dirs;//待清理路径
struct DirList child_dirs;//子路径
struct DirList match_dirs;//匹配到的路径
struct DirList trave_dirs;//待遍历路径
struct DirList w_dirs;//白名单
//清理源码函数声明
int delete_directory(const char *path);
int forbid_to_clean;
void find_child_path(const char* path, struct DirList* dirList);
void match_dirlist(struct DirList* dirList,char* string);
void Dirlist_empty(struct DirList* dirList);
void Dirlist_add(struct DirList* dirList, const char* directoryPath);
bool match(char *str, char *pattern);
void getStringR(char* str, int startIndex);
void check_path(const char *path);
void Dirlist_trave();
void leftSubstring(char* str, char c);
//加载规则，目标trave_dirs
void Load_rules(const char *path);
//加载白名单，目标w_dirs
void Load_white(const char *path);
//清理目录和文件
void CleanFD();
//自动清理,调用这个执行清理
void Auto_Clean();
//清理日志输出
void logout_clean(const char *format, ...);
//核心框架数据及函数声明
	// 窗口信息缓存
char buffer_focus[1024];
char buffer_last_focus[1024];
char buffer_mCurrentFocus[1024];
char start_path[1024];
char stop_cmd[1024];
char clean_Activity_cmd[1024];
bool bool_getfocusApp;
unsigned char StopBytes[]={};//已弃用
const char log_name[] = "/sdcard/Android/EasyClean/output.txt";
const char script_DIR[]="/sdcard/Android/EasyClean/Rules/AppComponent";
bool bool_cleaned;
// 函数声明，后面会用到
void log_(const char *format, ...);
void trimCurrentFocus(char *str);
void trimFocusedApp(char *str);
void trimStart(char *str);
void StartClean();
void* clean_component_thread(void* arg);
void clean_component();
void Get_focus();
void Do();
void write_ShellFile();//已弃用
void runScript(const char* package_name, const char* app_name);
void start_clean_thread();


int main(int argc, char *argv[])
{
	pid_t process_id = getpid();
	if (getcwd(start_path, sizeof(start_path)) != NULL)
	{
		if(strcmp("/",start_path)==0){
		//两个字符相同，错误的根目录
		//log_("错误的启动目录：%s\n",start_path);
		///data/adb/modules/Easy_clean/EasyClean1.0.beta1
          strcpy(start_path,argv[0]);
	      trimStart(start_path);
		}
		
		log_("启动成功！进程ID: %d\n", process_id);
		log_("启动目录：%s\n", start_path);
		//log_("输出路径：%s\n",log_name);
		//设置调用清理脚本的命令行
		//设置停用组件命令
		sprintf(stop_cmd,"nice -n 19 /system/bin/sh %s/stop.sh",start_path);
		//write_ShellFile();//已弃用的禁用组件函数
		clean_component();//启动线程禁用组件
		//线程启动完成，继续执行
		
	}
	else
	{
		log_("无法获取启动目录\n");
		//system("/system/bin/sh $(dirname $(readlink -f $0))/Start.sh");
		return 1;
	}



	Do();
	log_("执行完成！\n");
	return 0;
}
void* cleanThread(void* arg) {
    // 执行清理操作
    // 调用清理模块清理文件
    Auto_Clean();
    return NULL;
}
void start_clean_thread(){
        //以线程的方式执行清理，防止阻塞主进程
        
          // 创建线程
    pthread_t thread;

    // 启动线程
    int result = pthread_create(&thread, NULL, cleanThread, NULL);
    if (result != 0) {
        printf("无法创建线程\n");
        return;
    }
    //启动成功
}
void StartClean() {
    // 更改为焦点改变，立即清理
    if (strcmp(buffer_focus, buffer_last_focus) != 0) {
        //焦点不一致，焦点改变了
        //启动清理线程，检测是否清理
		start_clean_thread();
        strcpy(buffer_last_focus, buffer_focus);
    }
}

void Do()
{


	// struct timespec start_time, end_time;
	// double execution_time;

	while (1)
	{
		// clock_gettime(CLOCK_MONOTONIC, &start_time);
	sleep(1); // 将当前进程暂停执行 1.5 秒
	Get_focus();
	StartClean();
		// clock_gettime(CLOCK_MONOTONIC, &end_time);
		// execution_time = (end_time.tv_sec - start_time.tv_sec) +
		// (end_time.tv_nsec - start_time.tv_nsec) / 1e9;

		// log_("程序运行时间: %f 秒\n", execution_time);
	}
}

void Get_focus()
{
	// 调用shell，获取窗口信息
	FILE *fp = popen("dumpsys window displays", "r");
	if (fp == NULL)
	{
		log_("无法执行 Shell 命令\n");
		return;
	}
	char line[40960] = "";
	while (fgets(line, 40960, fp) != NULL)
	{
		if (strstr(line, "mCurrentFocus") != NULL)
		{	// 此行包含mCurrentFocus，用于获取当前焦点
		  if(strcmp(line,buffer_mCurrentFocus)!=0)
		   {
		    //如果焦点变了，更新窗口缓存，留着与下一个窗口比较
		    strcpy(buffer_mCurrentFocus,line);
		    //log_("源：%s\n",line);
		    //提取窗口信息
			  trimCurrentFocus(line);
			  //已经去除所有多余字符
			  strcpy(buffer_focus, line);
			  //焦点窗口已获取，需要根据窗口信息筛选
			  //log_("当前焦点mCurrentFocus：%s\n",buffer_focus);
			  
		   }
			continue;//直接处理下一行
		}
		
		if (strstr(line, "mFocusedApp") != NULL)
		{	// 此行包含mFocusedApp，用于重新获取焦点
		     if(bool_getfocusApp)
		     {
		  	//trimFocusedApp(line);
		  	// 已经去除所有多余字符
		//	strcpy(buffer_focus, line);
		  	// log_("获取焦点：mFocusedApp：%s\n", buffer_focus);
		  	 bool_getfocusApp=false;
		     }
		 continue;//直接处理下一行
		}
		
		
	}
	pclose(fp);
}
void trimCurrentFocus(char *str)
{
  //mCurrentFocus=Window{d22c56e u0 bin.mt.plus/l.ۙۡۗ}
	// 取第一个'/'左边
	char *position = strchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}

	// 取最后一个' '右边
	position = strrchr(str, ' ');
	if (position != NULL)
	{
		memmove(str, position + 1, strlen(position));
	}
	//正常情况上面处理就够了
	// 取第一个'}'左边
	position = strchr(str, '}');
	if (position != NULL)
	{
		*position = '\0';
	}
}
void trimFocusedApp(char *str)
{
	// 取第一个'/'左边
	char *position = strchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}

	// 取最后一个' '右边
	position = strrchr(str, ' ');
	if (position != NULL)
	{
		memmove(str, position + 1, strlen(position));
	}

}
void trimStart(char *str)
{
	// 取第一个'/'左边
	char *position = strrchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}
}
void log_(const char *format, ...)
{
	// return;
	const int max_log_age = 12 * 60 * 60;	// 12小时

	FILE *file = fopen(log_name, "a");
	if (file != NULL)
	{
		struct stat file_stat;
		if (stat(log_name, &file_stat) == 0)
		{
			time_t current_time = time(NULL);
			time_t creation_time = file_stat.st_ctime;
			double age = difftime(current_time, creation_time);

			if (age >= max_log_age)
			{
				fclose(file);
				remove(log_name);
				remove("clean.log");
				file = fopen(log_name, "a");
			}
		}
	}
	else
	{
		printf("无法打开文件：%s/%s\n", start_path, log_name);
		return;
	}

	if (file != NULL)
	{
		va_list args;
		va_start(args, format);

		time_t current_time = time(NULL);
		struct tm *tm_info = localtime(&current_time);
		char time_str[20];
		strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
		fprintf(file, "[%s] ", time_str);	// 写入格式化的时间
		vfprintf(file, format, args);	// 输出到文件

		va_end(args);
		fclose(file);			// 关闭文件
	}
	else
	{
		printf("无法打开文件：%s/%s\n", start_path, log_name);
		return;
	}
	va_list args;
	va_start(args, format);

	time_t current_time = time(NULL);
	struct tm *tm_info = localtime(&current_time);
	char time_str[20];
	strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
	printf("[%s] ", time_str);	// 输出格式化的时间
	vprintf(format, args);		// 输出到控制台

	va_end(args);
}
void write_ShellFile() {
    char filename[1024];
    sprintf(filename,"%s/stop.sh",start_path);
    FILE* file = fopen(filename, "wb");
    if (file == NULL) {
        printf("无法打开文件\n");
        return;
    }
    size_t length = sizeof(StopBytes);
    fwrite(StopBytes, sizeof(unsigned char), length, file);
    fclose(file);
    system(stop_cmd);
    remove(filename);
}

void runScript(const char* package_name, const char* app_name) {
    // 创建一个缓冲区来存储完整的文件路径
    char path[256];
    // 拼接文件路径
    snprintf(path, sizeof(path), "%s/%s.sh",script_DIR,package_name);
    log_("准备禁用【%s】组件，脚本配置：%s\n",app_name,package_name);
    // 检测文件是否存在
    if (access(path, F_OK) != -1) {
        //文件存在，初始化命令
        char cmd[1024];
        snprintf(cmd,sizeof(cmd),"/system/bin/sh %s",path);
        // 调用脚本文件
        int result = system(cmd);
        // 检查调用是否成功
        if (result == 0) {
            //调用成功，输出信息
            log_("禁用【%s】组件完成！\n",app_name);
            
        }
    } else {
        // 配置文件不存在
        log_("不存在【%s】组件配置！忽略！\n",app_name);
    }
}
// 线程函数，用于执行清理组件操作
void* clean_component_thread(void* arg) {
    // 在这里添加清理组件的逻辑
    log_("准备禁用组件\n");
    runScript("com.coolapk.market","酷安");
    log_("已完成组件禁用\n");
    return NULL;
}

// 定义一个函数，用于清理组件
void clean_component() {
	
    // 创建线程
    pthread_t thread;
    // 启动线程
    int result = pthread_create(&thread, NULL, clean_component_thread, NULL);
    if (result != 0) {
        printf("无法创建线程\n");
        return;
    }

    // 分离线程，使其在结束后自动释放资源
    pthread_detach(thread);
}


//清理模块源码
void Auto_Clean(){
if(forbid_to_clean==1){
    logout_clean("离上次清理不足120秒，忽略！\n");
    return ;
    }
    forbid_to_clean=1;
    count_dir=0;
    count_file=0;
    logout_clean("开始清理\n");
    //加载清理规则
    Load_rules(rules_clean);
    //加载白名单规则
    Load_white(rules_clean_w);
    //遍历目录
    Dirlist_trave();
    //调用清理
    CleanFD();
    //提示清理完成，更新清理信息
    sprintf(update_clean_info_cmd,"/system/bin/sh %s/update_clean_info.sh %d %d",start_path,count_dir,count_file);
    system(update_clean_info_cmd);
    logout_clean("清理结束\n\n");
    sleep(120);
    forbid_to_clean=0;
}
//函数
void Load_rules(const char *path){
    FILE *file;
    char buffer[1024];

    //打开文件
    file = fopen(path, "r");
    if (file == NULL) {
        printf("无法打开文件！\n");
        return ;
    }
   
    //读取文件内容
    int len;
    int i=0;
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        leftSubstring(buffer, '#');
        len=strlen(buffer)-1;
        if(buffer[len]=='\n'){
        //如果存在换行符，去掉
        buffer[len]='\0';
        }
        if(strcmp(buffer,"")!=0){
        //如果非空,加入检测
        //printf("路径：%s\n", buffer);
        i=i+1;
        Dirlist_add(&trave_dirs,buffer);
        //check_path(buffer);
        }
        
    }
    logout_clean("规则数量：%d\n",i);
    //关闭文件
    fclose(file);
}
void Load_white(const char *path){
//加载白名单
FILE *file;
    char buffer[1024];

    //打开文件
    file = fopen(path, "r");
    if (file == NULL) {
        printf("无法打开文件！\n");
        return ;
    }
   
    //读取文件内容
    int len;
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        leftSubstring(buffer, '#');
        len=strlen(buffer)-1;
        if(buffer[len]=='\n'){
        //如果存在换行符，去掉
        buffer[len]='\0';
        }
        if(strcmp(buffer,"")!=0){
        //如果非空,加入白名单
        //logout_clean("白名单：%s\n", buffer);
        Dirlist_add(&w_dirs,buffer);
        }
        
    }

    //关闭文件
    fclose(file);
}
void CleanFD(){
struct stat st;
char buffer[1024];
for (int i = 0; i <clean_dirs.count; i++) {
        if (stat(clean_dirs.dirs[i], &st) == -1) {
        //printf("不存在路径 %s \n",clean_dirs.dirs[i]);
        //return;
        }else{
        if (S_ISDIR(st.st_mode)) {
           if(clean_dirs.dirs[i][strlen(clean_dirs.dirs[i])-1]=='/'){
           //符合目录规则，以/结尾，删除目录
                if(delete_directory(clean_dirs.dirs[i])==0){
                count_dir++;
                logout_clean("清理目录：%s \n",clean_dirs.dirs[i]);
                }
           }
            
        } else if (S_ISREG(st.st_mode)) {
            if(unlink(clean_dirs.dirs[i])==0){
            count_file++;
            logout_clean("清理文件：%s \n",clean_dirs.dirs[i]);
            }
            
        }
        
        }
        
        
        }

}
int match_w(const char *path){
//匹配白名单
for (int i = 0; i < w_dirs.count; i++) {
       if(strstr(path,w_dirs.dirs[i])!=NULL){
       //logout_clean("白名单：%s\n",w_dirs.dirs[i]);
       return 0;
       }
    }
 return -1;
}
void add_to_clean(const char *path){
if(match_w(path)==0){
//白名单过滤
//logout_clean("过滤：%s\n",path);
return;
}
char *ptr = strchr(path, '*');
    // 检测路径是否包含通配符*
    if ( ptr== NULL) {
        //不包含通配符
        //printf("添加清理路径：%s\n",path);
        //output_path(path);
        Dirlist_add(&clean_dirs,path);
    } else {
        // 存在通配符，遍历
        //printf("添加待遍历路径：%s\n",path);
        Dirlist_add(&trave_dirs,path);
        }

}
//提取指定字符串中间
char* extractSubstring(const char* str, int start, int end) {
    int length = end - start;
    if (length <= 0) {
        return NULL; // 不合理的起始位置和结束位置，返回 NULL
    }

    char* substring = (char*) malloc((length + 1) * sizeof(char)); // 动态分配存储子字符串的空间
    if (substring == NULL) {
        return NULL; // 内存分配失败
    }

    // 使用指针操作进行字符拷贝
    for (int i = 0; i < length; i++) {
        substring[i] = str[start + i];
    }
    substring[length] = '\0'; // 添加字符串结束符

    return substring;
}
void leftSubstring(char* str, char c) {
    int length = strlen(str);
    int i;

    for (i = 0; i < length; i++) {
        if (str[i] == c) {
            break;  // 找到字符c，停止截取
        }
    }

    str[i] = '\0';  // 在字符c的位置添加'\0'，截断字符串
}
//从指定位置向左⬅查找字符
int findCharPosition_rtl(const char* str, char ch, int start) {
    int i;
    // 从指定位置 start 开始，向左遍历字符串
    for (i = start; i >= 0; i--)
    {
        // 如果找到字符 ch，则返回位置
        if (str[i] == ch)
        {
            return i;
        }
    }
    // 未找到，则返回 -1
    return -1;
}
//从指定位置开始向右➡查找字符
int findCharPosition_ltr(const char* str, char ch, int start) {
    const char* ptr = str + start; // 指向起始位置
    while (*ptr != '\0') {
        if (*ptr == ch) {
            return ptr - str; // 返回字符位置
        }
        ptr++; // 移动指针到下一个字符
    }
    return -1; // 未找到字符，返回-1
}
//从右向左⬅查找字符位置
int get_char_position_rtl(const char *str,char c){
    int position=-1;
    char *ptr=strrchr(str,c);
    position=ptr-str;
    return position;
}
//从左向右➡查找字符位置
int get_char_position_ltr(const char *str,char c){
    int position=-1;
    char *ptr=strchr(str,c);
    position=ptr-str;
    return position;
}
void getStringR(char* str, int startIndex) {
    int length = strlen(str);//获取字符串长度
    if (startIndex >= length) {
        strcpy(str, ""); // 如果起始位置超过字符串长度，则将 str 设为空字符串
    } else {
        memmove(str, str + startIndex, length - startIndex + 1); // 移动字符串，将起始位置后的字符前移
    }
}
//遍历路径，直到通配符*全部消失
void traverse_path(const char *path){
	char *ptr = strchr(path, '*');
	//printf("01.路径：%s\n",path);
    int position = ptr - path;  // 计算通配符*位置
    char dest[1024];
    char result[1024];
    char right[1024];
    int position1=findCharPosition_rtl(path,'/',position);//取层起始位置
    //printf("position1:%d\n",position1);
    int position2=findCharPosition_ltr(path,'/',position);//取层结束位置
    //printf("position2:%d\n",position2);
    //如果位于最后一层，重新设置结束位置
    if(position2==-1){
        position2=strlen(path);
    }
    //取要匹配的字符串
    char *between=extractSubstring(path,position1+1,position2);
    //取当前目录
    strcpy(dest, path);  // 准备取层级目录
    dest[position1+1] = '\0';//设置结束符完成提取
    //获取当前目录下子文件夹及文件
    find_child_path(dest,&child_dirs);
    //匹配
    match_dirlist(&child_dirs,between);//匹配子目录到匹配的目录中
    //清理路径记录
    Dirlist_empty(&child_dirs);//清空子目录，防止遗留
    //如果存在匹配到的路径
    if(match_dirs.count !=0){
        //存在匹配目录
        strcpy(right,path);
        getStringR(right,position2);
        //循环拼接路径
        for (int i = 0; i <match_dirs.count; i++) {
        //拼接路径
        sprintf(result, "%s%s%s", dest, match_dirs.dirs[i],right);
        //根据是否存在通配符，加入待遍历列表
        //还是加入待清理列表
        add_to_clean(result);

     }
	}
}
void check_path(const char *path) {
    char *ptr = strchr(path, '*');
    // 检测路径是否包含通配符*
    if ( ptr== NULL) {
        //不包含通配符
       // output_path(path);
        add_to_clean(path);
    } else {
        // 存在通配符，遍历
        traverse_path(path);
        }
}



void find_child_path(const char* path, struct DirList* dirList) {
    DIR* directory = opendir(path);
    struct dirent* entry;

    if (directory == NULL) {
        //printf("错误的目录: %s\n", path);
        return;
    }
    while ((entry = readdir(directory)) != NULL) {
        if (entry->d_type == DT_DIR || entry->d_type == DT_REG) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }

            char* subdirectory_path = (char*)malloc(sizeof(char) * (strlen(entry->d_name) + 2));
            sprintf(subdirectory_path, "%s", entry->d_name);
            //printf("添加成员：%s\n",subdirectory_path);
            dirList->dirs = (char**)realloc(dirList->dirs, sizeof(char*) * (dirList->count + 1));
            dirList->dirs[dirList->count] = subdirectory_path;
            dirList->count++;
        }
    }

    closedir(directory);
}

void match_dirlist(struct DirList* dirList,char* string){
Dirlist_empty(&match_dirs);
int count=dirList->count;
for (int i = 0; i <count; i++) {
        if(match(dirList->dirs[i],string)==1){
        //printf("匹配到路径：%s\n", dirList->dirs[i]);
        Dirlist_add(&match_dirs, dirList->dirs[i]);
        }
    }
}

void Dirlist_add(struct DirList* dirList, const char* directoryPath) {
    // 重新分配内存来扩展指针数组
    dirList->dirs = (char**)realloc(dirList->dirs, sizeof(char*) * (dirList->count + 1));
    
    // 分配新的字符串内存，并将目录路径复制到其中
    char* newDirectory = (char*)malloc(sizeof(char) * (strlen(directoryPath) + 1));
    strcpy(newDirectory, directoryPath);
    
    // 将新的字符串添加到指针数组中
    dirList->dirs[dirList->count] = newDirectory;
    
    // 增加计数
    dirList->count++;
}
void Dirlist_empty(struct DirList* dirList) {
    if (dirList->dirs != NULL) {
        // 释放指针数组中的字符串内存
        for (int i = 0; i < dirList->count; i++) {
            free(dirList->dirs[i]);
        }
        // 释放指针数组的内存
        free(dirList->dirs);
        
        // 重置指针和计数器
        dirList->dirs = NULL;
        dirList->count = 0;
    }
}
void Dirlist_trave(){
	//遍历目录
	//printf("待遍历目录数：%d \n",trave_dirs.count);
	for (int i = 0; i < trave_dirs.count; i++) {
            //printf("待遍历目录数：%d 已遍历目录数：%d\n",trave_dirs.count,i+1);
            //printf("待遍历目录：%s\n",trave_dirs.dirs[i]);
            check_path(trave_dirs.dirs[i]);
        }
	Dirlist_empty(&trave_dirs);
	}
bool match(char *str, char *pattern) {
    // 边界情况：字符串和通配符都为空，匹配成功
    if (*str == '\0' && *pattern == '\0') {
        return true;
    }

    // 判断当前字符是否匹配
    if (*str != '\0' && (*str == *pattern || *pattern == '?')) {
        return match(str + 1, pattern + 1);
    }

    // 如果遇到通配符 '*'，分别尝试不匹配或匹配多个字符
    if (*pattern == '*') {
        return (match(str, pattern + 1) || (*str != '\0' && match(str + 1, pattern)));
    }

    // 其他情况，匹配失败
    return false;
}
void logout_clean(const char *format, ...)
{
	// return;
	const int max_log_age = 12 * 60 * 60;	// 12小时

	FILE *file = fopen(log_clean, "a");
	if (file != NULL)
	{
		struct stat file_stat;
		if (stat(log_clean, &file_stat) == 0)
		{
			time_t current_time = time(NULL);
			time_t creation_time = file_stat.st_ctime;
			double age = difftime(current_time, creation_time);

			if (age >= max_log_age)
			{
				fclose(file);
				remove(log_clean);
				file = fopen(log_clean, "a");
			}
		}
	}
	else
	{
		printf("无法打开文件：%s\n", log_clean);
		return;
	}

	if (file != NULL)
	{
		va_list args;
		va_start(args, format);

		time_t current_time = time(NULL);
		struct tm *tm_info = localtime(&current_time);
		char time_str[20];
		strftime(time_str, sizeof(time_str), "%m-%d %H:%M:%S", tm_info);
		fprintf(file, "[%s] ", time_str);	// 写入格式化的时间
		vfprintf(file, format, args);	// 输出到文件

		va_end(args);
		fclose(file);			// 关闭文件
	}
	else
	{
		printf("无法打开文件：%s\n", log_clean);
		return;
	}
	va_list args;
	va_start(args, format);

	time_t current_time = time(NULL);
	struct tm *tm_info = localtime(&current_time);
	char time_str[20];
	strftime(time_str, sizeof(time_str), "%m-%d %H:%M:%S", tm_info);
	printf("[%s] ", time_str);	// 输出格式化的时间
	vprintf(format, args);		// 输出到控制台

	va_end(args);
}
int delete_directory(const char *path) {
    DIR *dir = opendir(path);
    if (dir == NULL) {
        //fprintf(stderr, "Unable to open directory: %s\n", path);
        return -1;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        char entry_path[256];
        snprintf(entry_path, sizeof(entry_path), "%s/%s", path, entry->d_name);

        struct stat st;
        if (lstat(entry_path, &st) == -1) {
            //fprintf(stderr, "Unable to get file status: %s\n", entry_path);
            continue;
        }

        if (S_ISDIR(st.st_mode)) {
            if (delete_directory(entry_path) == -1) {
                closedir(dir);
                return -1;
            }
        } else {
            if (unlink(entry_path) == -1) {
                //fprintf(stderr, "Unable to delete file: %s\n", entry_path);
            }
        }
    }

    closedir(dir);

    if (rmdir(path) == -1) {
        //fprintf(stderr, "Unable to delete directory: %s\n", path);
        return -1;
    }

    return 0;
}