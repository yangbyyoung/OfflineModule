#/system/bin/sh

#如果不存在模块目录则退出
mkdir -p "$MODPATH/log"
test "$MODPATH" = "" && exit

#计算储存空间大小
oldsize=$(du -sm /data | tr -cd '[0-9]')

#模块所需要的函数支持
function limitlog() {
	local logfile=${1}
	local maxsize=$((1024 * 1000))
	filesize=$(ls -l ${logfile} | awk '{ print $5 }')
	if test ${filesize} -gt ${maxsize}; then
		echo "[I]`date '+%F %T'` 日志达到上限，已经清空！" > "${logfile}"
	fi
}

function whitelist() {
	local file="$MODPATH/notclear.conf"
	cat ${file} | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function clear_emptydir() {
	find /data/media -type d -empty 2>/dev/null | while read emptydir; do
		if test "$(echo "${emptydir}" | grep -E "$(whitelist)")" != ""; then
			echo "[I]`date '+%F %T'` 跳过清理$emptydir"
			continue
		else
			rm -rf "${emptydir}"
			echo "[I]`date '+%F %T'` 删除空文件夹 ${emptydir}" >> "$MODPATH/log/emptydir.log"
		fi
	done
}

function clear_cachedir() {
	find /data/user* /data/media/*[0-9]*/Android -iname "*cache*" -type d 2>/dev/null | while read cachedir; do
		if test "$(echo "${cachedir}" | grep -E "$(whitelist)")" != ""; then
			echo "[I]`date '+%F %T'` 跳过清理$cachedir"
			continue
		else
			rm -rf "${cachedir}"
			echo "[I]`date '+%F %T'` 删除缓存文件夹 ${cachedir}" >> "$MODPATH/log/cachedir.log"
		fi
	done
}

function sort_uniq_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		echo "$(sort $i | uniq)" > "${i}"
	done
}

function clear_mod_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		limitlog "${i}"
	done
}

#运行主要脚本

clear_emptydir 2>/dev/null
clear_cachedir 2>/dev/null
#sort_uniq_log 2>/dev/null
clear_mod_log 2>/dev/null

a=$(cat $MODPATH/log/emptydir.log 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)
b=$(cat $MODPATH/log/clean.log 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)
c=$(cat $MODPATH/log/cachedir.log 2>/dev/null | sed '/^[[:space:]]*$/d' | wc -l)

newsize=$(du -sm /data | tr -cd '[0-9]')
data_size="$(($oldsize - $newsize))"

check_data_size=$(echo "$data_size" | grep -q '-' && echo "true")

if test "$check_data_size" = "true" ;then
	data_size=$(echo $data_size | tr -cd '[0-9]')
	echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共累积清理空文件夹"$a"个，"$c"个应用缓存文件夹，"${b}"个垃圾文件，本次运行储存空间增加了 "$data_size" MB。" >>$MODPATH/log/total.log
	sed -i '/description/d;/^[[:space:]]*$/d' "$MODPATH/module.prop"
	echo "description=从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共累积清理空文件夹"$a"个，"$c"个应用缓存文件夹，"${b}"个垃圾文件，本次运行储存空间增加了 "$data_size" MB。日志在${MODPATH}/log文件夹下，跳过清理的配置文件在${MODPATH}/notclear.conf里边" >> "$MODPATH/module.prop"
	exit 0
else
	echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共累积清理空文件夹"$a"个，"$c"个应用缓存文件夹，"${b}"个垃圾文件，本次运行储存空间释放了 "$data_size" MB。" >>$MODPATH/log/total.log
	sed -i '/description/d;/^[[:space:]]*$/d' "$MODPATH/module.prop"
	echo "description=从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共累积清理空文件夹"$a"个，"$c"个应用缓存文件夹，"${b}"个垃圾文件，本次运行储存空间释放了 "$data_size" MB。日志在${MODPATH}/log文件夹下，跳过清理的配置文件在${MODPATH}/notclear.conf里边" >> "$MODPATH/module.prop"
fi

