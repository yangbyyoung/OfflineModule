MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

	pose="
	com.tencent.mm:sandbox*
	com.tencent.mm:exdevice*
	com.tencent.mobileqq:tool*
	com.tencent.mobileqq:qzone*
	com.tencent.mm:tools*
	com.tencent.mm:appbrand*
	com.tencent.mobileqq:picture*
	com.tencent.mobileqq:mini*
	com.tencent.mobileqq:video*
	com.tencent.mobileqq:TMAssistantDownloadSDKService*
	com.tencent.mobileqq:Peak*
	com.tencent.mobileqq:mini_internal*
	com.tencent.mm:hotpot*
	com.tencent.mobileqq:hotpot*
	"
	sate=`dumpsys window policy | grep -w 'mInputRestricted' | cut -d= -f2`
	if test $sate == true ;then
		for i in $pose;do
			pgrep -f "$i" | while read PID;do
			kill -9 "$PID"
		done
	done
fi