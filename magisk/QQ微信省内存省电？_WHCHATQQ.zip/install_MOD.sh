Magisk_mod=$( grep 'MODDIRNAME=' /data/adb/magisk/util_functions.sh | head -n 1 |cut -d= -f2 | sed 's/_update.*//g;s/[[:space:]]//g' )
test "$Magisk_mod" = "" && {
Magisk_mod=modules
}


files="
$MODPATH/system/bin/qw
$MODPATH/scripts/qw.sh
$MODPATH/scripts/useinfo.sh
$MODPATH/scripts/cleartrash.sh
$MODPATH/scripts/cleartrash/ad.sh
$MODPATH/scripts/cleartrash/clearinfo.sh
$MODPATH/scripts/cleartrash/findQMtrash.sh
$MODPATH/keymod/A/QQWEA.sh
$MODPATH/keymod/B/QQWEB.sh
$MODPATH/keymod/C/REMEM.sh

"

test -e /data/adb/$Magisk_mod/WHCHATQQ2 && touch /data/adb/$Magisk_mod/WHCHATQQ2/disable



for file in $files ;do
	if test "$Magisk_mod" = "lite_modules" ;then
		sed -i "/^MODPATH=/c MODPATH=/data/adb/$Magisk_mod/$id " $file
	elif test "$Magisk_mod" = "modules" ;then
		sed -i "/^MODPATH=/c MODPATH=/data/adb/$Magisk_mod/$id " $file
	else
		echo "－ 出现了一些问题！终止安装！请您点击Magisk Manager上方的保存按钮，把日志发给开发者！"
		echo "－Æ——————————————————Æ"
		echo "－ 当前模块目录为: /data/adb/$Magisk_mod/$id "
		echo "－Æ——————————————————Æ"
		abort
	fi
done

for i in `find $MODPATH -name "root" -type f 2>/dev/null `;do
sed -i "s/\/data\/adb\/[A-Za-z]*.\//\/data\/adb\/$Magisk_mod\//g" $i
done

deletefile='
/data/system/ifw/com.miui.securitycenter$.xml
/data/system/ifw/com.miui.securitycenter.xml
'
for i in $deletefile ;do
test -e $i && rm -rf $i && echo "已删除手机管家ifw规则！"
done

