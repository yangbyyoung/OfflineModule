MODDIR=${0%/*}
#rm rubbish
rm -rf "/data/feas.txt"
rm -rf "/data/feas.txt.bak"
