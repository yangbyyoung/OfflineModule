  sys_path=/data/system
  MODDIR=${0%/*}
  if [ -f /my_product/etc/refresh_rate_config.xml ]&& [ ! -f $sys_path/refresh_rate_config.xml ];then
  cp -rf /my_product/etc/refresh_rate_config.xml /data/system/refresh_rate_config.xml
  fi

  if [ ! -f $sys_path/refresh_rate_config.bak ];then
  cp -rf $sys_path/refresh_rate_config.xml $sys_path/refresh_rate_config.bak
  ratemagic=`cat $sys_path/refresh_rate_config.bak|grep 'ratemagic'|awk -F "\"" '{print $4}'`
  datenow=$(date "+%Y%m%d")
  Line=`grep -rn "<refresh_rate_config" $sys_path"/refresh_rate_config.xml" |awk -F ':' '{print $1}'`
  sed -i $Line"d"  $sys_path/refresh_rate_config.xml

  if [ -n "$ratemagic" ]; then
  sed -i $Line"i<refresh_rate_config\ version=\"$datenow\" ratemagic=\"$ratemagic\">"  $sys_path/refresh_rate_config.xml
  else
  sed -i $Line"i<refresh_rate_config\ version=\"$datenow\">"  $sys_path/refresh_rate_config.xml
  fi
  #####这句话是激进版开关，删除这句话会将模块变成保守版#######
  sed -i '/item/d'  $sys_path/refresh_rate_config.xml
  #########################################################
  sed -i '/inputMethodLowRate=/d'  $sys_path/refresh_rate_config.xml
  Line=`grep -rn "</refresh_rate_config>" $sys_path"/refresh_rate_config.xml" |awk -F ':' '{print $1}'`
  sed -i $Line"i\ \ <config\ inputMethodLowRate=\"false\"\ enableFodHighRate=\"true\"\ enableRateOverride=\"false\"/>"  $sys_path/refresh_rate_config.xml
  # sed -i $Line"i\ \ enableFodHighRate\ true表示可以支持指纹高刷新请求，默认false，部分项目指纹闪屏需要配置\ -->"  $sys_path/refresh_rate_config.xml
  # sed -i $Line"i\ \ \ 默认为true,为false表示surfaceview，texture场景不降"  $sys_path/refresh_rate_config.xml
  # sed -i $Line"i<!--inputMethodLowRate\ 为true输入法降帧，默认为false"  $sys_path/refresh_rate_config.xml
  else
  echo "系统已经应用了该模块"
  fi
