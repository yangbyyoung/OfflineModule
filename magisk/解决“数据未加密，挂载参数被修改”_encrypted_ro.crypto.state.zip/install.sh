SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print " 解决 ‘数据未加密，挂载参数被修改’ "
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}