#!/system/bin/sh
su -c chmod 700 /mnt/vendor/persist/data