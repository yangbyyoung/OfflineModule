#清除模块卸载残留
rm -rf /cache/dex2oat.log
rm -rf /data/dex2oat.prop
rm -rf /data/optionalapp.prop
