## 内存管理优化
### 描述：调整lmk，vm参数，优化后台管理能力。

- v2
 > 添加对 `mi_reclaim` 的控制，可以在模块的mod目录，自己启用。
- v3
 > 在模块的mod目录下的lmk.sh，修改 `set_lmk_params "0" "128" "256" "512" "800" "1001"` 为 `set_lmk_params "0" "128" "256" "512" "800" "1001" "disable"` 或者 `set_lmk_params "disable" ` 即可禁用内存回收(用尽内存)。
- v4
 > 添加高通骁龙设备检测，避免非高通设备出现异常。
- v5
 > 添加配置文件
- v6
 > 限制日志大小
- v7
 > 更改prop值
- v8
 > 更改selinux 规则，允许修改lmkd
- v9
 > 自动识别selinux 规则
 > 添加 **ZRAM** 控制
- v10
 > 修复一些bug
- v11
 > ①添加开机强制回收内存
 > ②**取消`critical`控制**
 > ③12G运存的`ZRAM`调为2G
- v12
 > 添加 `sqlite3` 数据库修改，尝试修改**MIUI云控**数据，防止杀后台。
 > 添加定时内存回收，默认阈值为内存使用超过`80%`。
- v13
 > 修改 `activity manager`,将`gc_timeout`以及`gc_min_interval`，改为`2147483647`，也就是永不回收？也许吧。
- v14
 > 修正 高安卓版本`sys.lmk.minfree_levels`不正确的问题。
- v15
 > 添加修改prop参数(高通)至`128`
 > 减少selinux的修改项目
 > 修正模块的一些逻辑bug
- v16
 > 修复ZRAM无法修改的bug
- v17
 > 取消修改`ifw`文件，防止某些系统无限重启。
 > 调整vm参数，lmk参数，prop参数。
- v19
 > 修复交换分区不积极的bug。
 