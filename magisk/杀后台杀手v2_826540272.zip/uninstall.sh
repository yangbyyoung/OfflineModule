# 这个脚本会在删除模块的时候执行
rm -rf /data/system/ifw/*
cmd package install-existing com.coloros.securepay
cmd package install-existing com.heytap.browser
cmd package install-existing com.nearme.instant.platform
cmd package install-existing com.nearme.statistics.rom
cmd package install-existing com.nearme.atlas
cmd package install-existing com.coloros.athena
cmd package install-existing com.coloros.remoteguardservice
cmd package install-existing com.oplus.crashbox
cmd package install-existing com.oppo.atlas
cmd package install-existing com.coloros.securityguard
cmd package install-existing com.oplus.onetrace
cmd package install-existing com.coloros.healthcheck
cmd package install-existing com.oppo.oppopowermonitor
cmd package install-existing com.opos.ads
cmd package install-existing com.coloros.deepthinker
cmd package install-existing com.coloros.wifisecuredetect
cmd package install-existing com.coloros.familyguard
cmd package install-existing com.miui.powerkeeper