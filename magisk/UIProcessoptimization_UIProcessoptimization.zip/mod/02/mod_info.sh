mod_name="UIProcessoptimization"
mod_install_desc="开机编译systemUI"
mod_install_info="是否安装"
mod_select_yes_text="安装"
mod_select_yes_desc="[$mod_name]"
mod_select_no_text="不安装"
MODDIR=${0%/*}
mod_install_yes() {
    add_service_sh $MOD_FILES_DIR/post-fs-data.sh
    return 0
}

mod_install_no() {
    return 0
}
