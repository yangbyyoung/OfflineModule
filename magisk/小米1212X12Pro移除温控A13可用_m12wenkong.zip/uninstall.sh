# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
chmod 777 /data/vendor/thermal/config
chmod 777 /data/vendor/thermal/config/*
chattr -i /data/vendor/thermal/config/*
cp -f $MODPATH/backup/* /data/vendor/thermal/config/