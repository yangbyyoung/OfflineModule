SKIPUNZIP=0
var_device="`getprop ro.product.board`"
echo "当前手机型号为: $var_device "
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."

