#!/system/bin/sh

id="unlock_test_key"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
keyMODPATH="/data/adb/$Magisk_mod/$id"


magisk --unlock-blocks > /dev/null 2>&1

function mount_system() {
	a=0
	until test $a -gt 3
	do
		mount -o rw,remount /system
		mount -o rw,remount /
		mount -o rw,remount $(magisk --path)/.magisk/mirror/system_root
		mount -o rw,remount $(magisk --path)/.magisk/mirror/system
		mount -o rw,remount $(magisk --path)/.magisk/mirror/system_root/system
		a=$(($a + 1))
	done
}

function write_info(){
local info="${1}"
	echo "${info}"
	sed -i "/description\=/d" "$MODPATH/module.prop"
	echo '\n' >> "$MODPATH/module.prop"
	sed -i "\$a description=[${info}]" "$MODPATH/module.prop"
	sed -i '/^[[:space:]]*$/d' "$MODPATH/module.prop"
}


function mk_MODPATH() {
mkdir -p "$keyMODPATH"
chmod -R 0755 "$keyMODPATH"
cat <<key > "$keyMODPATH/module.prop"
id=unlock_test_key
name=挂载system测试
version=0.1
versionCode=1
author=key
description=这只是个测试模块。
key
}

mount_system > /dev/null 2>&1
touch /system/etc/hosts.bak > /dev/null 2>&1
test $? == 0 && {
rm -rf /system/etc/hosts.bak
test ! -d "$MODPATH" && mk_MODPATH
write_info " 😋解锁※/system成功※！ " 2>/dev/null
} || {
test ! -d "$MODPATH" && mk_MODPATH
write_info " 😂解锁※/system失败※！试着重启看看🤔？ " 2>/dev/null
}