rm -f /data/powercfg.sh
rm -f /data/powercfg.json
rm -f /dev/.NL_Snapdragon888