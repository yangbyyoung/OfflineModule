rm -rf /data/swapfile*
rm -rf /data/swap_recreate
rm -rf /data/swap_config.conf
rm -rf /data/writeback