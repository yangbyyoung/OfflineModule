 Explanation:
 就是个PIxel 机型 无限原画储存
