ShellVersion="Q-1.6"
mkdir -p /sdcard/Android/DM/log/
LogDir="/sdcard/Android/DM/log/QVClean.log"
if [ ! -f "$LogDir" ];then
  touch $LogDir
fi
datename=$(date +%Y-%m-%d-%H:%M:%S) 
echo "QQ清理完成！ Shell版本："$ShellVersion" \nQQ清理执行时间: "$datename"" >> $LogDir

echo "-----------------------"
echo "QQ清理脚本版本： "$ShellVersion""
echo "推荐适配系统:Android 11"
echo "不保证所有人可用，清理效果因设备而异"
echo "作者不对脚本稳定性和效果作任何保证，且用户需要自己对本脚本来源负责，原作者不负任何法律责任。"
echo "-----------------------"
echo ""
echo "-开始处理公共部分-"
am force-stop com.tencent.mobileqq

rm -rf /sdcard/Tencent/cache
rm -rf /sdcard/Tencent/MobileQQ/diskcache/
rm -rf /sdcard/Tencent/MobileQQ/Scribble/
rm -rf /sdcard/Tencent/MobileQQ/ScribbleCache/

echo "缓存..."
#其他
rm -rf /sdcard/Tencent/MobileQQ/qav/
rm -rf /sdcard/Tencent/MobileQQ/qqmusic/
rm -rf /sdcard/Tencent/MobileQQ/pddata/
rm -rf /storage/emulated/0/tencent/QQGallery/log/
#图片缓存
rm -rf /sdcard/Tencent/MobileQQ/photo/
rm -rf /sdcard/Tencent/MobileQQ/chatpic/
rm -rf /sdcard/Tencent/MobileQQ/thumb/
rm -rf /sdcard/Tencent/MobileQQ/QQ_Images/
rm -rf /sdcard/Tencent/MobileQQ/QQEditPic/
rm -rf /sdcard/Tencent/MobileQQ/hotpic/
echo "图片缓存...."
#短视频
rm -rf /sdcard/Tencent/MobileQQ/shortvideo/
echo "短视频缓存..."
#广告
rm -rf /sdcard/Tencent/MobileQQ/qbosssplahAD/
rm -rf /sdcard/Tencent/MobileQQ/pddata/
echo "广告缓存..."
#diy名片
rm -rf /sdcard/Tencent/MobileQQ/.apollo/
rm -rf /sdcard/Tencent/MobileQQ/vas
rm -rf /sdcard/Tencent/MobileQQ/lottie/
echo "个性名片清理..."
#Tencent目录下
#小程序
rm -rf /sdcard/Tencent/mini
rm -rf /sdcard/Tencent/TMAssistantSDK
echo "小程序缓存..."
#字体
rm -rf /sdcard/Tencent/.font_info
rm -rf /sdcard/Tencent/.hiboom_font
echo "字体缓存...."
#礼物
rm -rf /sdcard/Tencent/.gift
echo "礼物缓存..."
#进场特效
rm -rf /sdcard/Tencent/.trooprm/enter_effects
echo "进场特效...."
#头像
rm -rf /sdcard/Tencent/tbs
echo "tbs插件..."
#挂件

rm -rf /sdcard/Tencent/.pendant
echo "挂件和背景...."
#背景
rm -rf /sdcard/Tencent/.profilecard
#表情推荐
echo "表情推荐缓存..."
rm -rf /sdcard/Tencent/.sticker_recommended_pics
rm -rf /sdcard/Tencent/pe
#聊天表情缓存
rm -rf /sdcard/Tencent/.emotionsm
rm -rf /sdcard/Tencent/msflogs/
echo "聊天缓存..."
#戳一戳
rm -rf /sdcard/Tencent/.vaspoke
rm -rf /sdcard/Tencent/newpoke
rm -rf /sdcard/Tencent/poke
echo "其它缓存...(斗图、视频通话背景、图标)"
#vip图标
rm -rf /sdcard/Tencent/.vipicon
#斗图
rm -rf /sdcard/Tencent/DoutuRes
#视频通话背景
rm -rf /sdcard/Tencent/funcall
#接收的文件缓存
echo "接受的文件缓存...(非文件本身)"
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/diskcache
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/Scribble
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/ScribbleCache
echo "其它垃圾文件清理....(主要日志)."
rm -rf /storage/emulated/0/tencent/QQSecure/Athena/
rm -rf /storage/emulated/0/tencent/tmp/*.log
rm -rf /storage/emulated/0/tencent/MobileQQ/log/
#其他
echo "-----------------------"
echo "公共部分清理完毕！"
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/qav
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/qqmusic
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/pddata
echo "-----------------------"
echo "开始深度清理私有目录(Android11极其以上系统无root将无法处理)"
echo "处理/Android/data/目录...."
#缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/cache
#图片缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/photo
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/chatpic
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/thumb
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/QQ_Images
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/QQEditPic
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/hotpic
#QQ空间相关
echo "QQ空间缓存清理...."
#压缩文件缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/qzone/zip_cache/
#空间视频缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/qzone/video_cache/
#空间垃圾图片
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/qzone/imageV2/
#空间直播
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/qzlive/
#短视频
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/shortvideo
#广告
echo "日志广告小视频..."
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/qbosssplahAD
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/pddata
#diy名片
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.apollo
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/vasrm
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/lottie
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQ_Images/QQEditPic/
echo "编辑缓存和日志"
#Tencent目录下
#小程序
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/mini
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/TMAssistantSDK
#字体
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.font_info
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.hiboom_font
#礼物
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.gift
#进场特效
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.trooprm/enter_effects
#头像
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/head
#挂件
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.pendant
#背景
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.profilecard
#表情推荐
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.sticker_recommended_pics
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/pe
#tab日志 
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/files/tbslog/
#聊天表情缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.emotionsm
#戳一戳
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.vaspoke
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/newpoke
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/poke
#vip图标
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/.vipicon
#斗图
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/DoutuRes
#视频通话背景
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/funcall
#接收的文件缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.trooptmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.tmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.thumbnails
#未知垃圾下载
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/qcircle/
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/files/.info/
#日志
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/files/onelog/
#厘米秀
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/files/ae/playshow/
#msf日志
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/files/tencent/msflogs/
rm -rf /storage/emulated/0/tencent/msflogs/
rm -rf /storage/emulated/0/tencent/wns/Logs/
echo "小米合作有关广告日志"
rm -rf /storage/emulated/0/tencent/wtlogin/
echo "邮箱日志"
rm -rf /storage/emulated/0/tencent/QQmail/log/
rm -rf /storage/emulated/0/tencent/QQmail/qmlog/
echo "PT日志"
rm -rf /storage/emulated/0/tencent/qqimsecure/pt/
echo "OCR识别缓存"
rm -rf /storage/emulated/0/tencent/MobileQQ/ocr/cache/
rm -rf /sdcard/Android/data/com.tencent.mobileqq/files/.info/
rm -rf /sdcard/Android/data/com.tencent.mobileqq/files/ae/camera/capture/
echo "QQ相机捕获的照片"
rm -rf /sdcard/Android/data/com.tencent.mobileqq/files/tbslog/*txt
echo "tabLog"
rm -rf /sdcard/Android/data/com.tencent.mobileqq/files/tencent/tbs_live_log/
echo "tab_log"
rm -rf /sdcard/Android/data/com.tencent.mobileqq/files/tencent/tbs_common_log/
echo "tab_命令日志"
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.tmp/edit_video/
echo "在QQ编辑的临时图"
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/TMAssistantSDK/Download/com.tencent.mobileqq/
echo "TM助理SDK"
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/mini/files/
rm -rf /storage/emulated/0/Tencent/blob/mqq/
echo "ams缓存"
rm -rf /storage/emulated/0/Tencent/ams/cache/
echo "eup日志文件"
rm -rf /storage/emulated/0/Tencent/com.tencent.weread/euplog.txt
echo "IMSDK缓存"
rm -rf /storage/emulated/0/Tencent/imsdkvideocache/
echo "Midas迈达斯有限元分析日志"
rm -rf /storage/emulated/0/Tencent/Midas/Log/
echo "节日祝福相关资源缓存"
rm -rf /storage/emulated/0/Tencent/MobileQQ/bless/
#/dada目录下
echo "群组标记临时文件"
rm -rf /data/data/com.tencent.mobileqq/files/group_catalog_temp/
echo "hippy框架代码缓存(QQ浏览器相关)"
rm -rf /data/data/com.tencent.mobileqq/files/hippy/codecache/
echo "hippy框架(包含QQ游戏中心相关)"
rm -rf /data/data/com.tencent.mobileqq/files/hippy/bundle/
echo "小程序相关资源"
rm -rf /data/data/com.tencent.mobileqq/files/mini/
am start com.tencent.mobileqq/.activity.SplashActivity
input keyevent BACK

echo "清理完毕！重新启动QQ完毕"
echo "-----------------------"
echo "大美制作 酷安@孤Lrkc 2021/01/29"
echo "2021/09/12  更新"
echo "转发请保留原作者信息！"

EndTime=$(date +%Y-%m-%d-%H:%M:%S) 
echo "QQ清理完成时间: "$EndTime"\n_-_-_-_-_-_-_-_-_-_-_-_-_-_-_" >> $LogDir
