### Häufig gestellte Fragen

- _Ist eine BusyBox erforderlich?_

> Nein. Die App hat eine eigene BusyBox eingebaut. Aber wenn eine zusätzliche BusyBox-App/ein
> zusätzliches BusyBox-Modul installiert ist wird keine Konflikte verursachen.

- _Warum sind einige Einstellungen inaktiv (nicht umschaltbar)?_

> FDE.AI prüft, ob Ihr Gerät eine der aufgeführten Einstellungen unterstützt. Wenn eine Einstellung
> nicht unterstützt wird, wird sie deaktiviert. Dies kann auch vom gewählten AI-Modus abhängen und
> davon, ob die Echtzeit-System Optimierung aktiviert ist oder nicht.

- _Warum setzt die KI mein Gerät in den Leistungsmodus, während ich es auf Energiesparen stelle?_

> Die KI stellt die VM auf Leistung ein, wenn das Gerät geladen wird. Sobald Sie das Gerät aus dem
> Ladegerät trennen, schaltet die KI in den vorherigen Modus zurück. Diese Option ist sicher und
> führt nicht dazu dass Ihr Gerät überhitzt, da nur die VM-Parameter eingestellt werden
> (keine Frequenz-/Temperaturänderungen).

- _Die App funktioniert einwandfrei, aber das Protokoll wird seit langem nicht mehr aktualisiert.
  Ist das in Ordnung?_

> Ja, denn FDE.AI führt verschiedene Hintergrundaktivitäten nur dann aus, wenn dies wirklich
> notwendig ist, basierend auf
> Nutzungsszenario Ihres Geräts notwendig ist. Wenn Sie jedoch glauben, dass die App tatsächlich
> feststeckt, versuchen Sie FDE.AI über die Einstellungen neu zu starten.

- _Funktioniert FDE.AI mit der Tweaker-App X, Y oder Z?_

> Wahrscheinlich ja, aber es wird dringend NICHT empfohlen. Unerwartete Probleme/Konflikte
> können auftreten. Wenn Sie jedoch wissen, was Sie tun, und wissen, ob eine Einstellung
> zu Konflikten führt oder nicht, können Sie andere Tweaker neben FDE.AI verwenden.
> Wie bereits erwähnt, ist dies jedoch NICHT EMPFOHLEN und sollte sein AUF EIGENE GEFAHR ZU TUN.

- _Warum wird der CPU- und/oder GPU-Turbo nicht Unterstützt?_

> Weil der von Ihnen verwendete Kernel keinen erforderlichen Info-Knoten für FDE.AI bereitstellt. Es
> könnte jedoch auch sein, dass der Chipsatz/Treiber Ihres Geräts dies einfach nicht
> unterstützt. Außerdem stellen einige CPUs nicht die erforderlichen Parameter zur Verfügung
> um damit zu arbeiten. 'ondemand'/'interactive'/' schedutil' oder basierend auf diesen Reglern
> sollten von CPU Turbo unterstützt werden. Was Sie auf jeden Fall versuchen können, ist,
> den Gouverneur zu ändern, Kernel zu ändern oder einfach die Daten der Anwendungen zu löschen,
> um sicherzustellen, dass es sich nicht nur um eine zufällige Störung handelt. Zusätzlich,
> gibt es Unterstützung für bestimmte Mali- und Vivante-GPUs, die diese Funktion sonst
> nicht unterstützen. Sie erfordert die Aktivierung der Option "Constant Game Boost" und
> funktioniert bei unterstützten Spielen automatisch, oder kann immer aktiviert werden,
> wenn der AI-Modus auf Leistung eingestellt ist.

- _Wie ändere ich meinen CPU/GPU-Governor?_

> Laden Sie einen Kernel-Manager herunter (wir empfehlen "SmartPack", aber eigentlich ist jeder
> geeignet) und ändern Sie ihn von dort.

- _Kann ich die App sicher schließen, indem ich sie aus den Favoriten wegwische?_

> Ja. Es gibt einen Hintergrunddienst, der sich um alle Prozesse kümmert. Die App agiert wie ein
> Wrapper des dieses Hintergrunddienstes.

- _Wenn Sie von einem Hintergrunddienst sprechen, bedeutet das, dass die App meinen Akku
  verbraucht?_

> Nein. Einfach nein.

- _Wie deinstalliere ich FDE.AI richtig?_

> Deinstallieren Sie die Anwendung wie gewohnt und starten Sie Ihr Gerät neu. Alle angewendeten
> Einstellungen werden auf ihre Standardeinstellungen zurückgesetzt. Aber bitte denken Sie daran,
> Ihre Gründe für die Deinstallation in der Support-Gruppe zu melden.
> Vor allem, wenn es sich um Fehler handelte oder die App sich nicht so verhielt, wie Sie es
> erwartet hatten.

- _Welche Root-Methoden werden von der App unterstützt?_

> Buchstäblich alle, aber Magisk wird empfohlen.

- _Was bedeutet der Zähler für die KI-Lebensdauer auf der Hauptseite der App?_

> Es ist nur ein einfacher Indikator, der anzeigt, wie lange die KI bereits aktiv ist. Zum Beispiel
> wird er auf zurückgesetzt, wenn Sie auf "FDE.AI neu starten" klicken oder wenn Ihr Gerät
> neu gestartet wird.

- _Warum meldet die KI manchmal ihren Modus falsch?_

> Sie meldet nichts Falsches, sie aktualisiert nur langsam (nicht in Echtzeit) ihren Zustand, was
> normalerweise ~40 Sekunden benötigt.

- _Was ist die Schaltfläche "PC-Optimierung" auf der Infoseite und warum ist sie dort?_

> Es handelt sich um einen Link zu einer partnerschaftlichen (kostenlosen) Optimierungsanwendung für
> Windows OS. Die App wird entwickelt und von anderen Entwicklern (nicht dem FDE.AI Team)
> entwickelt und gepflegt.

- _Mein System beginnt nach der Ausführung von FDE.AI zu hinken. Warum?_

> Das sollte nicht passieren. Aber Sie können versuchen, alle build.prop Tweaks in den
> Einstellungen zu deaktivieren, das Gerät neu starten und nachsehen.

- _Ich habe eine Frage, die in dieser FAQ nicht behandelt wird. Wo kann ich eine Antwort finden?_

> Schauen Sie im Abschnitt "Info über AI" nach. Du kannst auch gerne
> unserer [Telegram-Supportgruppe](https://t.me/feralab_eng) be (https://t.me/feralab_eng) - wir
> helfen Ihnen gern weiter.

- _Ich habe einen Fehler gefunden/ habe Vorschläge, wo kann ich sie melden?_

> Wie oben - in unserer Telegram-Supportgruppe.