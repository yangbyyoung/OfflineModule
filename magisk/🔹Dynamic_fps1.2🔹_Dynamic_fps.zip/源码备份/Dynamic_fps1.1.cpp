//核心源码头文件

#include <stdbool.h>
#include <sched.h>//调用调度
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>

//【日志输出】
int age;//用于计数，清理日志文件
void log_(const char *format, ...);//主日志
void logout_info(const char *format, ...);//
void init_path();//创建不存在的目录
const char fps_file_info[] = "/sdcard/Android/动态刷新率/刷新率.conf";
//核心框架数据及函数声明
void Get_focus();
	// 窗口信息缓存
char app_focus[1024];//真实焦点应用
char app_last_focus[1024];//上一个焦点应用
char app_mCurrentFocus[1024];
char start_path[1024];
bool bool_getfocusApp;//用于判断是否重新获取焦点
bool bool_focus_changed;//用于判断焦点应用是否改变

// 函数声明，后面会用到
void trimCurrentFocus(char *str);//格式化焦点窗口
void trimFocusedApp(char *str);//格式化焦点应用
void trimWindow(char *str);//格式化窗口
void trimFloatApp(char *str);//格式化悬浮窗
void trimStart(char *str);//格式化启动目录
void Do();
//刷新率函数及变量
void Get_allow_fps();//获取支持的fps
void trim_fps(char *str,int now);
void get_fps_conf(const char *path);//获取配置信息
void Get_toch();
void set_touch_up_fps();
void w_();
void change_fps(int id);
int largest_fps=0;
int largest_fps_id=0;
int second_fps=0;
int second_fps_id=0;
int min_fps=0;
int min_fps_id=0;
int default_fps_id=-1;//默认刷新率，-1不管，-2最大
int touch_fps_on=0;//开启触摸刷新率，0关闭，1开启
int touch_down=-1;//触摸屏幕刷新率，默认最大
int touch_up=-1;//非触摸屏幕刷新率，默认最小
int touch_up_wait=5;//设置非触摸屏幕刷新率等待时间，默认5秒
int touch_up_need_wait=0;//非触摸后需要等待多久，单位0.3秒
int touch_fps_waited=0;//储存非触摸后等待了多久，单位0.3秒
int touch_mode=0;//默认将自定义刷新率作为屏幕刷新率
int fps_conf_exist=0;//默认不存在配置信息
int usleep_time=50000;//默认0.05秒，即每秒20次
int default_usleep_time=50000;//设置默认0.05秒检测一次
int touch_up_usleep_time=1000000;//设置非触摸后1秒检测一次
char app_fps[1024][1024];//支持1024条自定义APP刷新率规则
int app_fps_num=0;//自定义APP刷新率数量
void set_app_fps(char *app_name);//设置自定义APP刷新率

int main(int argc, char *argv[])
{
	pid_t process_id = getpid();//获取自身pid
	if (getcwd(start_path, sizeof(start_path)) != NULL)
	{
		if(strcmp("/",start_path)==0){
		//两个字符相同，错误的根目录
		//log_("错误的启动目录：%s\n",start_path);
		///data/adb/modules/Easy_clean/EasyClean1.0.beta1
          strcpy(start_path,argv[0]);
	      trimStart(start_path);
		}
		if(strcmp("/dev/tmp",start_path)==0){
		//临时启动，需更正启动目录
		//log_("错误的启动目录：%s\n",start_path);
		///data/adb/modules/Easy_clean/EasyClean1.0.beta1
		log_("检测到为临时启动\n");
          strcpy(start_path,argv[0]);
	      trimStart(start_path);
		}
		log_("启动成功！进程ID: %d\n", process_id);
		log_("启动目录：%s\n", start_path);
	}
	else
	{
		log_("已退出，无法获取启动目录\n");
		return 1;
	}
	init_path();//初始化配置目录
	get_fps_conf(fps_file_info);
    w_();
	log_("exit!");
	return 0;
	Do();

	//
	log_("执行完成！\n");
	return 0;
}

void w_(){
    struct timespec start_time, end_time;
	double execution_time;
while (1){
if(touch_fps_on==1){
//开启了触摸屏幕刷新率
// 记录开始时间
clock_gettime(CLOCK_MONOTONIC, &start_time);
usleep(usleep_time);//0.3秒
Get_toch();
set_touch_up_fps();

		clock_gettime(CLOCK_MONOTONIC, &end_time);
	    execution_time += (end_time.tv_sec - start_time.tv_sec) +
		(end_time.tv_nsec - start_time.tv_nsec) / 1e9;
if(execution_time>1.5){
//log_("程序运行时间: %f 秒\n", execution_time);
execution_time=0;
Get_focus();//获取焦点APP
if (bool_focus_changed) {
    //焦点已改变
    if(strcmp("NotificationShade",app_focus)==0){
	    //如果是下拉通知或息屏
	    //刷新配置信息
	    log_("--------刷新配置信息！-------\n\n");
	    get_fps_conf(fps_file_info);
	    }else{
	    //非下拉通知，即切换了应用
	        if(app_last_focus[0]=='\0'){
            //防止为空，更新上一个焦点APP
            strcpy(app_last_focus,app_focus);
            }
            strcpy(app_last_focus,app_focus);//保存新的焦点信息
            if(touch_mode==0){
            //要求设置为APP自定义|屏幕刷新率
                int id=largest_fps_id;
                int changeed=0;//标识是否遍历到
                char *pos;//位置
                // 遍历字符串数组
                for (int i = 0; i < app_fps_num; i++) {
                    //printf("%s\n", app_fps[i]); // 输出每个字符串
                    if(strstr(app_fps[i],app_focus)!=NULL){
                    //匹配的APP
                    //log_("匹配APP：%s\n",app_fps[i]);
                    pos = strstr(app_fps[i], " ");//刷新率索引位置
                    sscanf(pos, " %d", &id);//获取索引
                    //log_("索引：%d\n",id);
                    change_fps(id);
                    touch_fps_waited=0;
        	        usleep_time=touch_up_usleep_time;
        	        changeed=1;
                    break;
                    }
                }
                //没有遍历到
                if(changeed==0){
                //没有遍历到
                    if(touch_down==-1){
                    //设置最大刷新率
                    change_fps(largest_fps_id);
                    }else{
                    change_fps(touch_down);//自定义id
                    }
                }
            }else{
            //非自定义APP屏幕刷新率
                if(touch_down==-1){
                //设置最大刷新率
                change_fps(largest_fps_id);
                }else{
                change_fps(touch_down);//自定义id
                }
            }
	        touch_fps_waited=0;
	        usleep_time=touch_up_usleep_time;
	    }
	
    }
    }
		
}else{
//没有开启触摸屏幕刷新率
usleep(940000);//0.94秒
	Get_focus();//获取焦点APP
    if (bool_focus_changed) {
    //焦点已改变
	    if(strcmp("NotificationShade",app_focus)==0){
	    //如果是下拉通知或息屏
	    //刷新配置信息
	    log_("刷新配置信息！\n\n");
	    get_fps_conf(fps_file_info);
	    }else{
	    //非下拉通知，即切换了应用
	        if(app_last_focus[0]=='\0'){
            //防止为空，更新上一个焦点APP
            strcpy(app_last_focus,app_focus);
            }
            strcpy(app_last_focus,app_focus);//保存新的焦点信息
        //焦点应用改变，设置焦点APP屏幕刷新率
	        set_app_fps(app_focus);
	    }
	
    }
}

}
}

void Get_focus()
{
	// 调用shell，获取窗口信息
	FILE *fp = popen("dumpsys window displays", "r");
	if (fp == NULL)
	{
		log_("无法执行 Shell 命令\n");
		return;
	}
    char line[1024];//缓存40k
	while (fgets(line, 1024, fp) != NULL)
	{
		if (strstr(line, "mCurrentFocus") != NULL)
		{	// 此行包含mCurrentFocus，用于获取当前焦点
		  if(strcmp(line,app_mCurrentFocus)!=0)
		   {//一级检测到焦点信息有变化
		    //更新窗口缓存，以便与下一个窗口比较
		    strcpy(app_mCurrentFocus,line);
		    //提取窗口信息
			  trimCurrentFocus(line);
			  //已经去除所有多余字符
			  if(strcmp(app_focus,line)==0){
			  //信息有变化，但焦点没有改变
			  bool_focus_changed=false;
			  continue;//什么都别做
			  }
			  
			  //一级检测到焦点已改变，但却是特殊窗口
			  //mCurrentFocus=null PopupWindow:f60c54d TemporaryFocusWindow
			  if(strstr(line,"=null")!=NULL||strstr(line,"Win")!=NULL){
			  //无法准确判断焦点应用是否真实改变
			  bool_focus_changed=true;//设置标识，放行到二次判断
			  //设置标识，告知mFocusedApp判断，继二次判断
			  bool_getfocusApp=true;//设置需要重新获取焦点
			  continue;//进入下一条信息
			  }
			  //非特殊窗口，且焦点应用已改变
			  strcpy(app_focus, line);//更新焦点应用
			  bool_focus_changed=true;//放行
			  continue;//直接处理下一行
		   }else{
		   //一级检测，焦点信息没有改变
		   bool_focus_changed=false;
           continue;//直接处理下一行
		   }
			
		}
		//焦点信息没有变化，直接忽略后面的信息
		if(bool_focus_changed == false){
			//无需更新窗口信息
			continue;
			}
			
	
		if (strstr(line, "mFocusedApp") != NULL)
		{	// 此行包含mFocusedApp，用于重新获取焦点
		  if(bool_getfocusApp){
		   	//被要求重新获取焦点
		  	trimFocusedApp(line);
		  	// 已经去除所有多余字符
		  	//重新获取焦点，表明前面判断焦点改变失败
		  	  if(strcmp(app_focus,line)==0){
			  //焦点没有真正改变
			  bool_focus_changed=false;
			  //设置二次判断完成
			  bool_getfocusApp=false;
			  continue;//焦点未真实改变，不用更新其他信息
			  }
			 //保存重新获取的焦点信息
		   	 strcpy(app_focus, line);
		  	 //log_("获取焦点：mFocusedApp：%s\n", app_focus);
		  	 bool_getfocusApp=false;
		     }
		 //焦点真实改变
		 continue;//直接处理下一行
		}
		//continue;
	}
	pclose(fp);
}

void trimWindow(char *str)
{

//  * Task{4a5a843 #91 type=standard A=10247:bin.mt.plus U=0 visible=true mode=100 translucent=false sz=1}

  //mCurrentFocus=Window{d22c56e u0 bin.mt.plus/l.ۙۡۗ}
  
  // 取最后一个':'右边
	char *position = strrchr(str, ':');
	if (position != NULL)
	{   
		memmove(str, position + 1, strlen(position));
		// 取第一个' '左边
    	position = strchr(str, ' ');
    	if (position != NULL)
    	{
    		*position = '\0';
    	}
	}else{
    	position = strchr(str, '/');
    	if (position != NULL)
    	{
    		*position = '\0';
    	}
    	position = strrchr(str, '=');
    	if (position != NULL)
    	{   
    		memmove(str, position + 1, strlen(position));
    	}
	
	}
	
}
void trimCurrentFocus(char *str)
{
  //mCurrentFocus=Window{d22c56e u0 bin.mt.plus/l.ۙۡۗ}
	// 取第一个'/'左边
	char *position = strchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}

	// 取最后一个' '右边
	position = strrchr(str, ' ');
	if (position != NULL)
	{
		memmove(str, position + 1, strlen(position));
	}
	//正常情况上面处理就够了
	// 取第一个'}'左边
	position = strchr(str, '}');
	if (position != NULL)
	{
		*position = '\0';
	}
}
void trimFocusedApp(char *str)
{
	// 取第一个'/'左边
	char *position = strchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}

	// 取最后一个' '右边
	position = strrchr(str, ' ');
	if (position != NULL)
	{
		memmove(str, position + 1, strlen(position));
	}

}
void trimStart(char *str)
{
	// 取第一个'/'左边
	char *position = strrchr(str, '/');
	if (position != NULL)
	{
		*position = '\0';
	}
}

//FPS刷新率
void set_app_fps(char *app_name){
int id=min_fps_id;
char *pos;//位置
// 遍历字符串数组
    for (int i = 0; i < app_fps_num; i++) {
        //printf("%s\n", app_fps[i]); // 输出每个字符串
        if(strstr(app_fps[i],app_name)!=NULL){
        //匹配的APP
        //log_("匹配APP：%s\n",app_fps[i]);
        pos = strstr(app_fps[i], " ");//刷新率索引位置
        sscanf(pos, " %d", &id);//获取索引
        //log_("索引：%d\n",id);
        change_fps(id);
        return;
        }
    }
//不是自定义刷新率APP
if(default_fps_id==-2){
//锁定最大或第二
change_fps(largest_fps_id);
//change_fps(second_fps_id);
}else{
change_fps(default_fps_id);
}


}
void Get_toch(){
	FILE *fp = popen("dumpsys input | grep TouchStatesByDisplay", "r");
	if (fp == NULL)
	{
		log_("无法执行 Shell 命令\n");
		return;
	}
	char line[1024];
	int bl=0;
	while(fgets(line, 1024, fp) != NULL){
	//存在内容，继触摸屏幕
	bl=1;
	}
	if(bl==1){
	//处于触摸屏幕状态
    	if(touch_mode==0){
        //要求将自定义刷新率设置为屏幕刷新率
                //需要设置为自定义
                int id=largest_fps_id;
                char *pos;//位置
                // 遍历字符串数组
                for (int i = 0; i < app_fps_num; i++) {
                    //printf("%s\n", app_fps[i]); // 输出每个字符串
                    if(strstr(app_fps[i],app_focus)!=NULL){
                    //匹配的APP
                    //log_("匹配APP：%s\n",app_fps[i]);
                    pos = strstr(app_fps[i], " ");//刷新率索引位置
                    sscanf(pos, " %d", &id);//获取索引
                    //log_("索引：%d\n",id);
                    change_fps(id);
                    touch_fps_waited=0;
        	        usleep_time=touch_up_usleep_time;
                    return;
                    }
                }
                //没有遍历到，应用默认配置
            	if(touch_down==-1){
                //设置最大刷新率
                change_fps(largest_fps_id);
                }else{
                change_fps(touch_down);//自定义id
                }
            	touch_fps_waited=0;
            	usleep_time=touch_up_usleep_time;
                return;
        }else{
        	//log_("触摸屏幕！\n");
        	if(touch_down==-1){
            //设置最大刷新率
            change_fps(largest_fps_id);
            }else{
            change_fps(touch_down);//自定义id
            }
        	touch_fps_waited=0;
        	usleep_time=touch_up_usleep_time;
        
        }
    
	}else{
	//没有触摸屏幕
	//log_("没有触摸屏幕\n");
	touch_fps_waited++;
	}
	pclose(fp);

}
//获取配置信息
void get_fps_conf(const char *path){
    FILE *file;
    char buffer[1024];
    //打开文件
    file = fopen(path, "r");
    if (file == NULL) {
        log_("配置文件不存在！\n");
        fps_conf_exist=0;//配置文件不存在
        init_path();//初始化配置目录
        return ;
    }
   
    //读取文件内容
    int i=0;//用于记录APP自定义刷新率数量
    char *id_pos;
    int fps_value;
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
    if(strstr(buffer,"#")!=NULL){
    //属于注释，什么都别做
    }else{
        id_pos = strstr(buffer, "default=");
        if(id_pos==NULL){
        //不是默认索引，属于自定义刷新率或触摸时屏幕刷新率
            id_pos = strstr(buffer, "touch_fps_on=");
            if(id_pos==NULL){
            //不是触摸屏幕刷新率开关
                id_pos = strstr(buffer,"touch_down=");
                if(id_pos==NULL){
                //不是触摸屏幕刷新率
                    id_pos = strstr(buffer,"touch_up=");
                    if(id_pos==NULL){
                    //不是停止触摸屏幕刷新率
                        id_pos = strstr(buffer,"touch_up_wait=");
                        if(id_pos==NULL){
                        //不是停止触摸屏幕刷新率设置延时
                            id_pos = strstr(buffer,"touch_mode=");
                                if(id_pos==NULL){
                                //是自定义APP屏幕刷新率
                                if(strcmp(buffer,"\n")!=0){
                                strcpy(app_fps[i],buffer);
                                 i++;
                                log_("自定义APP刷新率：%s\n",buffer);
                                }
                            
                                }else{
                                //是触摸刷新率模式
                                //log_("id_pos：%d\n",id_pos);
                                sscanf(id_pos, "touch_mode=%d", &touch_mode);
                                log_("触摸刷新率模式：%d\n",touch_mode);
                        
                            }
                        
                        }else{
                        //是停止触摸屏幕刷新率设置延时
                        sscanf(id_pos, "touch_up_wait=%d", &touch_up_wait);
                        log_("停止触摸屏幕刷新率设置延时：%d秒\n",touch_up_wait);
                        touch_up_need_wait=touch_up_wait;
                        }
                    }else{
                    //停止触摸屏幕刷新率
                    sscanf(id_pos, "touch_up=%d", &touch_up);
                    log_("停止触摸屏幕刷新率索引：%d\n",touch_up);
                    }
                }else{
                //触摸屏幕刷新率
                sscanf(id_pos, "touch_down=%d", &touch_down);
                log_("屏幕触摸刷新率索引：%d\n",touch_down);
                }
            }else{
            //触摸屏幕刷新率开关
            sscanf(id_pos, "touch_fps_on=%d", &touch_fps_on);
            log_("屏幕触摸刷新率开启状态：%d\n",touch_fps_on);
            }
        }else{
        //属于默认索引
        sscanf(id_pos, "default=%d", &default_fps_id);
        //显示默认索引：
        log_("默认索引值：%d\n",default_fps_id);
        }
        
    
    }
    
    
        
        
    }
    //关闭文件
    fclose(file);
    //更新自定义APP刷新率数量
    app_fps_num=i;
    log_("自定义APP刷新率数：%d\n",app_fps_num);
}
void set_touch_up_fps(){
//设置非触摸时屏幕刷新率fps

    if(touch_fps_on==1){
    //开启触摸屏幕刷新率时
       // log_("waited：%d  need_wait：%d\n",touch_fps_waited,touch_up_need_wait);
        if(touch_fps_waited==touch_up_need_wait){
            //设置非触摸屏幕刷新率
            //log_("设置非触摸时屏幕刷新率！\n");
            if(touch_mode==0||touch_mode==1){
            //要求将自定义刷新率设置为屏幕刷新率
                    //需要设置为自定义
                    int id=min_fps_id;
                    char *pos;//位置
                    // 遍历字符串数组
                    for (int i = 0; i < app_fps_num; i++) {
                        //printf("%s\n", app_fps[i]); // 输出每个字符串
                        if(strstr(app_fps[i],app_focus)!=NULL){
                        //匹配的APP
                        //log_("匹配APP：%s\n",app_fps[i]);
                        pos = strstr(app_fps[i], " ");//刷新率索引位置
                        sscanf(pos, " %d", &id);//获取索引
                        //log_("索引：%d\n",id);
                        change_fps(id);
                        usleep_time=default_usleep_time;
                        return;
                        }
                    }
                    //没有遍历到
                    //log_("没有遍历到：%s\n",app_focus);
                    if(touch_up==-1){
                    //需要设置为最小
                    change_fps(min_fps_id);
                    }else{
                    //设置为自定义默认
                    change_fps(touch_up);
                    }
                    usleep_time=default_usleep_time;
                    return;
            }else{
            //touch_mode==2
            //要求忽略非触摸时，自定义APP屏幕刷新率
                //log_("要求忽略自定义APP屏幕刷新率：%s\n",app_focus);
                if(touch_up==-1){
                //需要设置为最小
                change_fps(min_fps_id);
                }else{
                //需要设置为自定义
                change_fps(touch_up);
                }
                usleep_time=default_usleep_time;
                return;
            }
        
        
            
        }
    }
    
}

void change_fps(int id){
    char command[100];
    snprintf(command, sizeof(command), "service call SurfaceFlinger 1035 i32 %d", id);
    
    FILE *fp = popen(command, "r");
    if (fp == NULL)
    {
        log_("无法执行 Shell 命令\n");
        return;
    }
    pclose(fp);
    //log_("切换刷新率索引：%d\n",id);
}
void Get_allow_fps()
{   
    if(fps_conf_exist==0){
    //配置信息不存在，写入
    logout_info("#【编辑完成后，息屏或下拉通知2-5秒触发配置更新】\n");
	logout_info("#【0.支持的刷新率】\n");
	}
	// 调用shell，获取显示信息
	FILE *fp = popen("dumpsys display", "r");
	if (fp == NULL)
	{
		log_("无法执行 Shell 命令\n");
		return;
	}
    char line[1024];//缓存40k
	while (fgets(line, 1024, fp) != NULL)
	{
		if (strstr(line, "DisplayMode") != NULL)
		{	// 此行包含DisplayMode，用于获取fps模式
		    //DisplayModeRecord{mMode={id=1, width=1240, height=2772, fps=120.00001, alternativeRefreshRates=[60.000004, 90.0, 144.00002], supportedHdrTypes=[2, 3, 4]}}
		  if(strstr(line,"mActiveSf")!=NULL)
		   {//此行包含激活的显示模式
		   //mActiveSfDisplayMode=DisplayMode{id=2, width=1240, height=2772, xDpi=449.942, yDpi=451.338, refreshRate=90.0, appVsyncOffsetNanos=1000000, presentationDeadlineNanos=16111111, supportedHdrTypes=[2, 3, 4], group=0}
		    trim_fps(line,1);
			  }else{
			  //属于支持的刷新率
			    if(strstr(line,"xDpi")!=NULL){
			    trim_fps(line,0);
			    }
			  
			  }
		    
		}
		//log_(line);
		continue;//直接处理下一行
	}
	pclose(fp);
log_("最大刷新率：%d 索引：%d\n",largest_fps,largest_fps_id);
log_("第二刷新率：%d 索引：%d\n",second_fps,second_fps_id);
log_("最小刷新率：%d 索引：%d\n",min_fps,min_fps_id);
if(fps_conf_exist==0){
//配置信息不存在，写入
logout_info("\n#【1.设置默认刷新率】\n");
logout_info("#填索引，另外：\n");
logout_info("#-2表示锁定最大刷新率\n");
logout_info("#-1表示自动\n");
logout_info("#指定其他刷新率，请填对应索引：\n");
logout_info("default=-2\n\n");
logout_info("#【2.设置触摸时屏幕刷新率】\n");
logout_info("#设置触摸屏幕幕时的刷新率，此功能开启后将禁用锁定默认刷新率\n");
logout_info("#touch_fps_on设置是否开启，1开启，0关闭\n");
logout_info("#touch_down设置触摸时，屏幕刷新率，填索引id，-1表示最大刷新率\n");
logout_info("#touch_up设置非触摸时，屏幕刷新率，填索引id，-1表示最小刷新率\n");
logout_info("#touch_up_wait不触摸时，设置屏幕刷新率延时，单位秒\n");
logout_info("#touch_mode=0;以自定义刷新率为屏幕刷新率\n");
logout_info("#touch_mode=1;以自定义刷新率为非触摸时屏幕刷新率\n");
logout_info("#touch_mode=2;忽略自定义APP屏幕刷新率\n");
logout_info("touch_fps_on=0\n");
logout_info("touch_down=-1\n");
logout_info("touch_up=-1\n");
logout_info("touch_up_wait=3\n");
logout_info("touch_mode=0\n\n");
logout_info("#【3.自定义刷新率】\n");
logout_info("#格式：APP包名 索引\n");
logout_info("#实例：com.coolapk.market %d\n",second_fps_id);
logout_info("#表示将应用【酷安】的刷新率锁定在 %d FPS\n",second_fps);
logout_info("#加'#'符号可注释掉规则，快来添加你的规则吧！\n");
//写入完成，配置信息已存在
fps_conf_exist=1;
}

}
void trim_fps(char *str,int now)
{
  //DisplayModeRecord{mMode={id=1, width=1240, height=2772, fps=120.00001, alternativeRefreshRates=[60.000004, 90.0, 144.00002], supportedHdrTypes=[2, 3, 4]}}
    char *id_pos = strstr(str, "id=");
    char *fps_pos = strstr(str, "refreshRate=");
    if (id_pos != NULL) {
        int id_value;
        int fps_value;
        sscanf(id_pos, "id=%d", &id_value);
        sscanf(fps_pos, "refreshRate=%d", &fps_value);
        //更新最大刷新率、第二刷新率和索引
        if(fps_value>largest_fps){
        second_fps=largest_fps;
        second_fps_id=largest_fps_id;
        largest_fps=fps_value;
        largest_fps_id=id_value;
        }else{
        //更新最小刷新率
        if(min_fps!=0){
        //最小刷新率存在
            if(fps_value<min_fps){
            min_fps=fps_value;
            min_fps_id=id_value;
            }
        }else{
        //最小刷新率不存在，设置最小刷新率
        min_fps=fps_value;
        min_fps_id=id_value;
        }
        
        }
        //判断是当前刷新率还是允许的刷新率
        if (now == 1 ){
        //当前fps
        //printf("当前索引: %d 刷新率：%d\n", id_value,fps_value);
        }else{
            if(fps_conf_exist==0){
            //配置信息不存在，写入
             logout_info("#索引: %d 刷新率：%d FPS\n", id_value,fps_value);
             }
        }
    }
}
//日志输出
void log_(const char *format, ...)
{
	va_list args;
	va_start(args, format);

	time_t current_time = time(NULL);
	struct tm *tm_info = localtime(&current_time);
	char time_str[20];
	strftime(time_str, sizeof(time_str), "%m-%d %H:%M:%S", tm_info);
	printf("[%s] ", time_str);	// 输出格式化的时间
	vprintf(format, args);		// 输出到控制台
	va_end(args);
	return;
}
void logout_info(const char *format, ...)
{
	FILE *file = fopen(fps_file_info, "a");
	va_list args;
	va_start(args, format);

	time_t current_time = time(NULL);
	struct tm *tm_info = localtime(&current_time);
	char time_str[20];
	strftime(time_str, sizeof(time_str), "%m-%d %H:%M:%S", tm_info);
	printf("[%s] ", time_str);	// 输出格式化的时间
	vprintf(format, args);		// 输出到控制台
	if (file != NULL){
	//如果日志文件打开成功！
		if (age >= 43200)
			{
			    age=0;
				fclose(file);//关闭文件
				remove(fps_file_info);//删除文件
				file = fopen(fps_file_info, "a");//创建，重新打开文件
				if(file == NULL){
				//创建，重新打开文件失败
				va_end(args);
            	return;
				}
			}
	//fprintf(file, "[%s] ", time_str);	// 写入时间
	vfprintf(file, format, args);	// 写入具体内容
    va_end(args);
    fclose(file);			// 关闭文件
	}else{
	//日志文件打开失败！
	va_end(args);
	return;
	}
}
void init_path(){
char path[256]="/sdcard/Android/动态刷新率/刷新率.conf";
if(access(path, F_OK) != -1) {
        printf("File exists: %s\n", path);
        fps_conf_exist=1;//配置文件存在
        Get_allow_fps();//刷新fps信息
    } else {
        printf("File does not exist: %s\n", path);
        char dir[256]="/sdcard/Android/动态刷新率/";
        //初始化路径
        if(mkdir(dir, 0666) == 0) {
        printf("Directory created: %s\n", dir);
        //目录创建成功！
        Get_allow_fps();//刷新fps信息
        } else {
        printf("Failed to create directory: %s\n", dir);
        //目录已存在
        Get_allow_fps();//刷新fps信息
        }

    }

}