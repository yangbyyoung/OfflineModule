SKIPMOUNT=false
#安装后开关
PROPFILE=true
#system.prop文件
POSTFSDATA=false
#post-fs-data脚本
LATESTARTSERVICE=false
#service.sh中脚本
print_modname() {
  ui_print "*******************************"
  ui_print "开发版MIUI14音效（体验版)"
  ui_print "酷安:大风吹破英雄梦"
  ui_print "新篇章！"
  ui_print "MIUI14音效的凯旋声！"
  ui_print "*******************************"
}
on_install() {
ui_print "- 经检测该文件版本为 试用版！马上开始生成 定制版MIUI14音效的固件反馈文件"
"

/system/priv-app/MusicFX
/system/etc/sysconfig
/system/vendor/lib/soundfx
/system/vendor/lib64/soundfx
/vendor/lib/soundfx
/vendor/lib64/soundfx
/vendor/lib/rfsa/adsp
/vendor/lib64/rfsa/adsp
/vendor/lib/soundfx
/vendor/lib64/soundfx
/vendor/lib/rfsa/adsp
/vendor/lib64/rfsa/adsp
/system/vendor/etc/dolby/dax-default.xml
/system/etc/mixer_paths.xml
/system/etc/mixer_paths_cdp.xml
/system/vendor/lib/rfsa/adsp/misound_karaoke_res.bin
/system/vendor/lib/rfsa/adsp/misound_karaokemix_res.bin
/system/vendor/lib/rfsa/adsp/misound_res.bin
/system/vendor/lib/rfsa/adsp/misound_res_headphone.bin
/system/vendor/lib/rfsa/adsp/misound_res_spk.bin
"
if [ -d /storage/emulated/0/.音效固件打包专用  ];then
        echo 检测到之前MIUI13音效模块的文件
          rm -rf /storage/emulated/0/.音效固件打包专用
else
        echo 开始安装MIUI14内置固件
fi
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/firmware
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib64
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/etc
mkdir -p /storage/emulated/0/.音效固件打包专用/system/app
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib
cp -r /system/vendor/lib/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib/
cp -r /system/vendor/etc/audio /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/app/MiSound /storage/emulated/0/.音效固件打包专用/system/app/
cp -r /system/vendor/etc/acdbdata /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/vendor/lib64/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib64/
cp -r /system/vendor/firmware/aw8697_rtp_1.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/
cp -r /system/vendor/firmware/aw8697_haptic.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/

tar -cvzf 音效固件打包.tar.gz /storage/emulated/0/.音效固件打包专用/ 
cp -r ./音效固件打包.tar.gz /storage/emulated/0/
rm -rf ./音效固件打包.tar.gz
rm -rf /storage/emulated/0/.音效固件打包专用
rename /storage/emulated/0/音效固件打包.tar.gz /storage/emulated/0/音效固件打包.zip
  ui_print "- 内置固件完毕，保存在根目录，正在安装"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 内置固件安装完毕，开始迅速清理残留"
    /dev/*/.magisk/busybox/fstrim -v /cache 
    rm -rf /data/system/package_cache/*
  ui_print "-内置固件完成！尽情沉浸在牛逼的MIUI14（试用版)的世界吧！"
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}