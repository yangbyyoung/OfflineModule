# Magisk Module Template

This `README.md` will be shown in Magisk Manager. Place any information / changelog / notes you like.

**Please update `README.md` if you want to submit your module to the online repo!**

Github has its own online markdown editor with a preview feature, you can use it to update your `README.md`! If you need more advanced syntax, check the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

For more information about modules and repos, please check the [official documentations](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)

---

# **半玄不玄能正能负之优化**

---

## Description
**个人打包整合调教私用**，*半玄不玄能正能负*，适于MIUI12.5，~~优化~~模块

---

## Changelog
- Version 0.0  
    > date 21.07.24  
    > 新建项目，并复习了Markdown语法，新写了README，然后饿傻了，~~明天再继续努力吧~~  
- Version 1.0  
    > date 21.07.25  
    > 在负优化(V997)模块(来自夕阳醉歌)基础上，整合部分玄学优化(均采自酷安)功能，重写注释并再打包；
- Version 1.1  
    > date 21.07.25  
    > 保留温控，删除部分不必要玄学代码，避免与其余模块冲突，例如NLsound和阿巴酱系
- Version 1.14514
    > date 21.07.25  
    > 无聊刷个版本号
- Version 1.2  
    > date 21.07.26  
    > 整合智能DNS(V3.0)模块(来自9527)，整合触控延时模块(来自旧梦)，整合取消指纹特效模块(来自Ծ‸Ծ)，整合PCmode模块(来自OLX team)，整合开机动画简化模块(来自我自己)
- Version 1.27183  
    > date 21.07.26  
    > 无聊刷个版本号
- Version 1.3  
    > date 21.07.26  
    > 修正路径(SBTFBOYS_KEY->bxbxnznf)，以修复部分运行不正常的脚本，重构取消指纹特效部分，删去脚本，采用直替以避免可能的冲突和引入额外的二进制文件，但是会让默认主题状态栏显示异常，所以建议使用第三方主题  
- Version 1.31416  
    > date 21.07.26  
    > 无聊刷个版本号
- Version 2.0 
    > date 21.08.24  
    > 简化智能DNS的print部分(它print的东西实在是太多了，有点麻，不好看，反正我这段时间网络使用都比较稳定)
- Version 2.1 
    > date 21.08.24  
    > 添加MIUI12.5水龙自用优化(来自Amktiao&夕阳醉歌)，又删掉了，我觉得没啥必要，也不是说一定怎样怎样冲突，只是改过来比较费事
- Version 2.2 
    > date 21.08.24  
    > 添加小米妙播(暂时mi9等刷版本号机型等待进版，来自Bugme7) 
- Version 2.3 
    > date 21.08.24  
    > 添加了Hchai触控3.4(60hz)(来自火柴ANKs)
- Version 2.4 
    > date 21.08.24  
    > 状态栏全屏与网速指示标右移(来自嘟嘟斯基&鲸落雨)；并修改状态栏高度为28dp
- Version 2.5 
    > date 21.08.24  
    > 取消跳转至我酷安主页(每回刷入测试都跳转一次，简直烦得要死)
- Version 2.6 
    > date 21.08.24  
    > 替换侧滑动画(原来那个侧滑锯齿就离谱)
- Version 2.7 
    > date 21.08.24  
    > 移植第三方主题状态栏电池图标(覆盖掉上面提及的因取消指纹特效而引入的显示异常，覆盖了就可以说没有bug，现在它是feature)
- Version 2.71828  
    > date 21.08.26  
    > 无聊刷个版本号
- Version 3.0
    > date 21.08.26
    > 替换触控优化为忘心酱版本(一玄到底算了，但这个效果确实更好一点，回头具体测一下耗电情况)
- Version 3.1
    > date 21.08.29
    > 取消原有的状态栏高度修改，重新反编译Overlay部分app，更好地适配MI9的水滴屏也防止状态栏显示冲突(这部分的bug排查了很久，结果是Overlay部分的问题，因为原来的Overlay是适配X10的，移植之后，没有仔细测试，我的我的，纯纯偷懒了,现在状态栏高度为原生的27.269993dp)
- Version 3.2
    > date 21.08.30
    > 添加一堆有的没的UI开关，仅从个人使用意向角度考虑，包括纸质护眼，真彩显示，屏幕高级调节，AI大师画质引擎，内存扩展，补全视频工具箱，听感调节，声纹降噪，通知聚合，HIFI&DOLBY，(具体生没生效大概对半开，也有很多因为冲突删掉了,因为大部分我也不用，视频工具箱部分可能引入视频工具箱中应用音频播放问题，切出后台或切到其他应用时，播放卡顿，二次切出会中断并伴有电流滋滋声的底噪，尽管我排查了并处理了，但不保证完全没有)
- Version 3.3  
    > date 21.08.30  
    > 去除负优化中自带的`fuckcoolapk`部分，忘了为什么要去除了，同时去除了高级电源菜单，12.5反正不生效，不知道该在哪个路径
- Version 3.4  
    > date 21.08.30  
    > 尽量修复由视频工具箱和其他涉及音频的玄学代码引起的音频输出异常(说实话这个问题给我整麻了，太离谱了，难受得一批)
- Version 3.5  
    > date 21.08.31  
    > 补全修正温控修改在mod路径下的部分，一直没看到，刚看见
- Version 3.6  
    > date 21.09.01  
    > 添加水龙优化中的`binder`，`page`，`read_ahead_kb`，三个部分，以及cpu负载均衡优化(`sched_relax_domain_level`,来自温亮平)(加完这个就没啥可以加了)
- Version 3.7    
    > date 21.09.01  
    > 取消`智能DNS`(输出一堆，又看不出来生没生效，给我调试烦了)  
- Version 3.8    
    > date 21.09.01  
    > 重新梳理`mod`路径下脚本内容，重写部分`set_value`，修复全部脚本，并注释测试情况(截至3.8版本，还有快充级别的温控问题，和不知道啥东西引入的人脸识别丢失问题)
- Version 3.9  
    > date 21.09.02  
    > 修复人脸识别问题(位置在`sed.sh`里的游戏工具箱部分，所以注释掉了，后续的类似游戏高级设置，准星辅助，复活倒计时的游戏相关添加计划，也取消了，反正我没需求)  
- Version 4.0  
    > date 21.09.02  
    > 添加一定程度的快充(来自白话)，纠正温控中的硬编码路径(今天疯狂星期四，太寄吧好了，刷个大版本，预计下个小版本合并代码发包)  
- Version 4.0.4
    > date 21.09.02  
    > 无聊刷个版本号  
- Version 4.1
    > date 21.09.06  
    > 去除`QQWEA.sh`，去除`ad.sh`，去除小米妙播，简化了快充部分，移除了原有的温控部分，~~挪用了来自温亮平的温控模块~~，开摆了，直接空替换所有的本地温控，当然由于天气转凉，充电和温控都较之原版更为激进和不拘，另外小小地纠正一下`dex2oat`编译的配置，缓解一下设备启动后的高压力  
- Version 4.1.4   
    > date 21.09.07  
    > 无聊刷个版本号  
- Version 4.2  
    > date 21.09.13  
    > 添加桌面布局解锁至16\*16，主要是`chimi`和`miuihome`没支持这么多，所以自己添加了，之前用5\*8，现在6\*11
- Version 4.3   
    > date 21.09.14   
    > 删改了一下沍澤的二改快充，拿来用了，小小地调整了一下温控，又温和了一点点  
- Version 4.4   
    > date 21.09.14  
    > 补习了一下`crontab`，调整了`mod`路径底下`root`脚本执行周期，顺便修正上次发包时合并代码错误引入的问题，顺便修正一些注释上的错误，顺便修改了部分脚本，添加简略日志便于`debug`，顺便删除了`test`记录注释  
- Version 4.4.4   
    > date 21.09.15  
    > 无聊刷个版本号    
- Version 5.0.0   
    > date 21.09.19   
    > 添加一部分原本适用于小米10_安卓R系列优化(来自水龙&阿巴酱，我的超人！)；去除所有触控与屏幕有关的优化(玄不玄不好说，但耗电确实有点离谱，虽然还没测试，但测了再说)；快充也全砍了(仅发布版本，自用的保留了)  
- Version 5.1.0_lite   
    > date 21.09.19   
    > 切分出Lite版本，适用于其他机型，就是看起来完全没有机型限制，尽可能普适；

---

## Requirements
- 测试机型
    > `MI 9(cepheus)`
- 参考环境
    > `Android 11/Magisk 22.1/MIUI12.5`

---

## Instructions
这里简要描述本模块所涉及各组件功能：  
| **组件** | **描述** |
| :---: | :---: |
|`module.prop` | 模块相关 |
|`system.prop` | 同于/system/build.prop |
|`customize.sh` | 模块刷入时执行 |
|`post-fs-data.sh` | 以阻塞方式，进程加载后模块安装前执行相关脚本(一级目录下) |
|`servise.sh` | 以非阻塞方式，设备启动后data加载后执行相关脚本(/mod路径下) |
|`key.sh` | 读取模块与设备信息 |
|`thermal.sh` | 温控相关 |
|`WCNSS_qcom_cfg.sh` | wifi_bonding，高通WiFi增强 |
|`ylg.sh` | 显然是添加的引流部分 |
|`ylg_again.sh` | 同上 |
|`sed.sh` | sed一部分玄学变量到device_features |
|`features.sh` | 同上 |
|`META-INF/*` | 模块需要，兼容与验证 |
|`asset/*` | 资源路径，包含README.md涉及图片 |
|`README.md` | readme |
|`system/*` | 挂载/system，替换路径下相应文件夹或文件,详细描述附于表后 |
|`mod/*` | 开机后执行，受service.sh调起，详细描述附于表后 |

---
- ***`system`***
    - `etc/`
    - `media/`
        - `theme/`
            - `default/`
                - `com.android.settings` 
                    > 触控延时在这里  
                - `com.miui.home`  
                    > 桌面布局解锁在这里  
                - `framework-res`  
                    > 这个也是触控延时  
    - `system_ext/`
        - `app/` 
            - `PcLauncher.apk`
                > 这是PC模式  
    - `vender/`
        - `bin/`
            - `cnss_diag`
                > 就是cnss_diag  
            - `tcpdump`
                > 就是tcpdump  
        - `etc/`
            - `init/`
    > *`thermal`*，全是温控相关，纯纯空替换，开摆了，脚本不修了
---

- ***`mod/*`***
    > *kuan、不想写了，自己看脚本名字得了*  

---

## Thanks
> *在此致谢以上提及的所有作者，包括模块作者与代码提供者，红豆泥阿里嘎多*  

---

## Author
> ***Andempathy.bx***  

> 公众号 @截河的推送小站  

![@截河的推送小站](./assets/img/jiehe_tuisong.png "jiehe_tuisong")  

> 酷安 @截河wanduan

 [![@截河wanduan](./assets/img/coolapk_qrcode.png "coolapk_qrcode")](http://www.coolapk.com/u/3839671)  