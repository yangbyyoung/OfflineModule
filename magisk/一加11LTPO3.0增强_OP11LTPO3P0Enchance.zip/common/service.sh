#!/system/bin/sh


BASEDIR="$(dirname $(readlink -f "$0"))"

function boot(){
while true;
do
btcplt=$(getprop vendor.oplus.boot_complete)
if [ "$btcplt" -eq "1" ];then
	return 0
fi
sleep 1
done
}

settings put system peak_refresh_rate 122
settings put system min_refresh_rate 122

boot

settings put system peak_refresh_rate 122
settings put system min_refresh_rate 122

echo 4095 >/sys/kernel/oplus_display/max_brightness
#sleep 5
#sh $BASEDIR/sceen_on_shell.rc

#添加其他通用shell 命令
