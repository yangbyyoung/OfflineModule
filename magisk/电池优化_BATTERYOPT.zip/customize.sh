WHITELIST=/data/adb/BATTERYOPT/电池优化白名单.prop

mkdir /data/adb/BATTERYOPT
touch "$WHITELIST"
echo "#+后面填不想被优化的应用包名
+cn.litiaotiao.app
+com.tencent.mm
+com.omarea.vtools
+com.miui.screenrecorder
+com.miui.home
+com.miui.cloudbackup
+com.miui.cloudservice
+com.miui.micloudsync
+com.tencent.mobileqq
+com.android.camera
+com.xiaomi.xmsf
+hello.litiaotiao.app
" >"$WHITELIST"
