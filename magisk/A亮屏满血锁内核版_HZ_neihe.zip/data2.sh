warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo Good > /sys/class/power_supply/battery/die_health
  echo Good > /sys/class/power_supply/battery/health
  echo Good > /sys/class/power_supply/usb/connector_health
sleep 1s
done
