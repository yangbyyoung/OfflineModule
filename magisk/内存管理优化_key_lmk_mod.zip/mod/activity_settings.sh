#!/system/bin/sh
#由@coolapk 10007编写
#模块数据来源网络和本人修改。


source "${0%/*}/util_functions.sh"


#设置更多的缓存和进程
function more_cached_apps(){
	local number="$1"
	test "$(echo $number | grep [0-9])" = "" && number="128"
	cmd device_config put activity_manager max_cached_processes "$number"
		cmd settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_cached_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
			cmd device_config put activity_manager max_empty_processes "$number"
				cmd settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_empty_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
			device_config put activity_manager max_cached_processes "$number"
				settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_cached_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
		device_config put activity_manager max_empty_processes "$number"
	settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_empty_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
	if test "$(getprop ro.system.build.version.sdk)" -gt "30" ;then 
		cmd device_config set_sync_disabled_for_tests persistent
			cmd device_config put activity_manager max_phantom_processes 2147483647
				device_config set_sync_disabled_for_tests persistent
				device_config put activity_manager max_phantom_processes 2147483647
			cmd settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_cached_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
		settings put global activity_manager_constants trim_empty_processes=0,trim_cached_processes=0,max_cached_processes="$number",max_phantom_processes=2147483647,gc_timeout=8192,gc_min_interval=131072
	fi
}

if test "$(show_value "后台活动管理")" = "修改" ;then
	more_cached_apps "2147483647"
fi
