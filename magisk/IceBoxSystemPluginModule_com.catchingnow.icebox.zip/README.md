# Ice Box System Plugin Magisk Module

# 冰箱 Ice Box 系统提权插件

Speed up Ice Box's freezing and defrosting.

<https://play.google.com/store/apps/details?id=com.catchingnow.icebox>

This is a plugin of Ice Box app. Please do not install it without Ice Box app.

The plugin will speed up Ice Box's freezing and defrosting for rooted devices. There is no necessary to install it when using device owner mode or simple ADB mode.

此插件可以提高冰箱 Ice Box 的冻结解冻速度。仅对 root 模式有效，对免 root 模式无效。
