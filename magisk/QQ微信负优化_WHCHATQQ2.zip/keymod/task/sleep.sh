#!/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

function stopapps() {
	#安卓墓碑
	pgrep -f "$1" | while read pid; do
		kill -19 $pid 2>/dev/null
	done
}

function show_value() {
	local value=$1
	local file=/data/media/0/Android/QQ微信负优化/QQ微信负优化.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

if test $(show_value "QQ，微信休眠应用") == QQ; then
	stopapps "com.tencent.mobileqq"
elif test $(show_value "QQ，微信休眠应用") == 微信; then
	stopapps "com.tencent.mm"
else
	stopapps "com.tencent.mobileqq"
	stopapps "com.tencent.mm"
fi
