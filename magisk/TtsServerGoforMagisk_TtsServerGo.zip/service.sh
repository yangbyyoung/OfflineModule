# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此防跳和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
until [ $(getprop sys.boot_completed) = "1" ] ; do
  sleep 5
done

MODDIR=${0%/*}

chmod 777 "$MODDIR/tts-server-go"
"$MODDIR/tts-server-go" > /dev/null 2>&1