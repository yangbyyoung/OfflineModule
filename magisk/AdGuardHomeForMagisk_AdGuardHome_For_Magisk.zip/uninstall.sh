#!/system/bin/sh

rm -f /data/adb/service.d/AdGuardHome_For_Magisk_service.sh