PKG="com.miui.gallery com.xiaomi.micloud.sdk"
for PKGS in $PKG; do
  rm -rf /data/user/*/$PKGS/cache
done


