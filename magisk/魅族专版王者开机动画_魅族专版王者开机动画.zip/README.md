# Magisk Module Template

This `README.md` will be shown in Magisk Manager. Place any information / changelog / notes you like.

**Please update `README.md` if you want to submit your module to the online repo!**

Github has its own online markdown editor with a preview feature, you can use it to update your `README.md`! If you need more advanced syntax, check the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

For more information about modules and repos, please check the [official documentations](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)

---
# **魅族专版王者开机动画**

## Description
修改默认开机动画/system/media/bootanimation.zip
替换为魅族专版王者开机动画

## Changelog
- Version 1.00 更新素材，重切分片以修复跳变，并且整合版本号
- Date 23.11.07
- Version 1.0 再次修改desc结构以修复动画循环问题
- Date 23.11.07
- Version 1.0 修改desc结构以缩短末尾帧过长的驻留时间
- Date 23.11.07
- Version 1.0 适配大小1080×2340以修正畸变
- Date 23.11.07
- Version 1.0 原结构素材套用未做改动
- Date 23.11.07

## Requirements
- 只适用于魅族默认开机动画
- 如有第三方主题或使用其他开机动画magisk模块请勿刷入

## Instructions
- 测试机型为魅族18X
- 参考环境为Android 13/Magisk-delta 26101
- 仅在测试机型刷入成功且使用正常
- 刷入机型和版本未做限制，请自行甄别慎重刷入