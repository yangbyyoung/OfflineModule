MODDIR=${0%/*}

while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 2
done

sleep 1
sh /data/data/me.piebridge.brevent/brevent.sh