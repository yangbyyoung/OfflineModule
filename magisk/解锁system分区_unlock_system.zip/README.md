

在 Android 10+ 上，系统分区可能无法再以读写方式重新挂载。 对于使用动态分区的设备，几乎不可能修改系统分区，因为没有剩余空间。 该模块通过使用OverlayFS解决了这些问题。 那么什么是OverlayFS？ 在[维基百科](https://en.m.wikipedia.org/wiki/OverlayFS)上：

> OverlayFS 是 Linux 的联合挂载文件系统实现。 它将多个不同的底层安装点合并为一个，从而形成一个包含所有源的底层文件和子目录的目录结构。 常见应用程序将读/写分区覆盖在只读分区上，例如闪存写入周期有限的 LiveCD 和 IoT 设备。

使用overlayfs进行系统分区的好处：

- 使系统分区的大部分部分（`/system`、`/vendor`、`/product`、`/system_ext`、`/odm`、`/odm_dlkm`、`/vendor_dlkm`、...）变为可读- 写。
- `/data` 存储用于 OverlayFS 挂载的 `upperdir`。 但在某些内核上，OverlayFS 不支持 f2fs，无法直接使用。 解决方法是创建一个 ext4 循环映像然后安装它。
- 对overlayfs分区的所有修改都不会直接进行，而是会存储在upperdir中，因此很容易恢复。 只需删除/禁用模块，您的系统就会返回到未受影响的阶段。
- 支持 Magisk 版本 23.0+ 和最新版本的 KernelSU

> 如果您对 OverlayFS 感兴趣，可以阅读文档 <https://docs.kernel.org/filesystems/overlayfs.html>

＃＃ 建造

有两种方法：

### GitHub 操作
- 分叉此存储库并运行 github 操作

### Linux/WSL

1. 将此存储库克隆到您的设备
````
git 克隆 http://github.com/HuskyDG/Magisk_OverlayFS && cd Magisk_OverlayFS
````
2. 在存储库目录中设置Android NDK
````
wget https://dl.google.com/android/repository/android-ndk-r23b-linux.zip
解压 android-ndk-r23b-linux.zip
````
3.运行`bash build.sh`

## KernelSU问题

- KernelSU模块与Magisk类似，它允许用户修改系统分区，同时保持系统完整性。 它通过 Overlayfs 的实现来实现这一点。 然而，需要注意的是，KernelSU 通过使用只读的overlayfs 对系统分区进行更改，它也挂载在magic_overlayfs 之上，并防止系统以读写方式重新挂载。 如果您想将系统分区重新挂载为可读写，您只需首先使用以下命令卸载 KernelSU Overlayfs：

````bash
nsenter -t 1 -m sh
overlayfs_system --unmount-ksu
````

或在`/data/adb/modules(_update)/magisk_overlayfs/mode.sh`中设置`DO_UNMOUNT_KSU=true`

- 之后您将能够以读写方式重新安装系统

## 更改 OverlayFS 模式

- OverlayFS 默认安装为只读

- 在`/data/adb/modules(_update)/magisk_overlayfs/mode.sh`中配置overlayfs模式以更改OverlayFS的模式

> Overlayfs的读写模式会导致部分设备上的基带停止工作

````
# 0 - 只读，但仍可以重新挂载为读写
# 1 - 默认读写
# 2 - 只读锁定（无法重新挂载为读写）

导出 OVERLAY_MODE=2
````

- OverlayFS 上层循环设备将设置在 `/dev/block/overlayfs_loop`
- 在 Magisk 上，OverlayFS 上层循环安装在 `$(magisk --path)/overlayfs_mnt` 处。 您可以通过此路径进行修改，以对系统中挂载的overlayfs进行更改。

## 使用OverlayFS修改系统文件

- 如果你懒得重新挂载，请修改`mode.sh`并将其设置为`OVERLAY_MODE=1`，这样overlayfs每次启动都会始终是读写的。

- 您可以在终端中通过此命令快速重新挂载所有overlayfs以进行读写：
````bash
su -mm -c magic_remount_rw
````

- 之后，您可以在终端中通过此命令将所有系统分区恢复为只读模式：
````bash
su -mm -c magic_remount_ro
````


