MODDIR=${0%/*}
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "lsgo"
set_perm_recursive $MODPATH 0 0 0755 0777
chmod -R 777 $MODDIR
