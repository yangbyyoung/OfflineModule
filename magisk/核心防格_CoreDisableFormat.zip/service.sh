#!/system/bin/sh
MODDIR=${0%/*}
ASH_STANDALONE=1

#允许手动调用sh文件
if [ -f "/data/adb/magisk/busybox" ] ; then
   busybox="/data/adb/magisk/busybox"
elif [ -f "/data/adb/ksu/bin/busybox" ] ; then
   busybox="/data/adb/ksu/bin/busybox"
else
   exit 127
fi
#初始化模块运行环境
if [ ! -d "$MODDIR/bin" ]; then
   mkdir "$MODDIR/bin"
fi
if [ ! -f "$MODDIR/bin/awk" ] || [ ! -f "$MODDIR/bin/sed" ]; then
   $busybox --install -s $MODDIR/bin
fi
PATH=$MODDIR/bin:/system/bin

if [ ! -f "$MODDIR/onlyrm" ]; then
   if [ ! -d "$MODDIR/blocks" ]; then
      mkdir -p "$MODDIR/blocks"
   else
      if [ "$(ls $MODDIR/blocks | wc -l)" != "0" ]; then
         if [ "$(getprop sys.boot_completed)" == "0" ]; then
            find "$MODDIR/blocks/" -delete
         fi
          . $MODDIR/stop.sh
      fi
   fi
fi

touch $MODDIR/disable
#筛选分区名
cat $MODDIR/partition.ini | grep -v "#" | while read partition
do
   partname=$(ls /dev/block/by-name/ | grep $partition)
   #转储需要保护的分区名
   echo "$partname" | sed '/^[[:space:]]*$/d' >> $MODDIR/TMP
done

#读取转储的分区名，并逐个解析分区挂载点
setenforce 0
cat $MODDIR/TMP | while read line
do
   if [[ $line != "" ]];then
      partnum=$(ls -l /dev/block/by-name/$line 2>/dev/null | awk -F ' -> ' '{print $2}')
      #这一步主要针对mtk设备的preloader/pl分区解析
      if [[ "$partnum" == *mapper* ]]; then
         partnum=$(ls -l $partnum 2>/dev/null | awk -F ' -> ' '{print $2}')
      fi
      #判断设备selinux规则是否允许转移dev块，并确定保护方案
      if [ ! -f "$MODDIR/onlyrm" ]; then
         mv -f "$partnum" "$MODDIR/blocks/"
         if [ "$(find "$MODDIR/blocks/" -type b | wc -l)" == "0" ]; then
            rm -f "$partnum" "$MODDIR/blocks/*"
            touch "$MODDIR/onlyrm"
         fi
      else
         rm -f "$partnum"
      fi
      #判断保护结果
      if [ "$(ls "$partnum" 2>/dev/null | wc -l)" == "0" ]; then
         echo "$line" >> $MODDIR/TMP2
         echo "已保护 $line 分区"
      else
         echo "保护 $line 分区失败"
      fi
   fi
done

if [ ! -f "$MODDIR/onlyrm" ]; then
   alias defend="mv"
   description="[保护中😊] 已保护分区: ($(sed ':a;N;$!ba;s/\n/, /g' "$MODDIR/TMP2")); 本设备支持运行stop.sh临时关闭保护!"
   sed -i "s/description=.*/description=$description/" $MODDIR/module.prop
   echo -e "setenforce 0\nfind $MODDIR/blocks/ -type b -exec $busybox mv {} /dev/block/ \;\nsetenforce 1\nsed -i 's/description=.*/description=[停止保护👿] 可以手动运行service.sh文件或者重启手机恢复分区保护/' $MODDIR/module.prop\necho -n '' > $MODDIR/stop.sh" > $MODDIR/stop.sh
    chmod +x $MODDIR/stop.sh
else
   alias defend="rm"
   description="[保护中😊] 已保护分区: ($(sed ':a;N;$!ba;s/\n/, /g' "$MODDIR/TMP2"))"
   sed -i "s/description=.*/description=$description/" $MODDIR/module.prop
fi


#移出整个设备块，以上分区都在这几个设备块里可以找到，删除这几个总设备块会使sgdisk之类的命令不可用
defend -f /dev/block/mmcblk0 /dev/block/mmcblk1 /dev/block/mmcblk2 /dev/block/sda /dev/block/sdb /dev/block/sdc /dev/block/sde /dev/block/sdf "$MODDIR/blocks/" 2>/dev/null
setenforce 1



while true; do
   if [ "$(getprop sys.boot_completed)" == "1" ]; then
      break
   fi
   sleep 30
done
rm "$MODDIR/disable" "$MODDIR/TMP" "$MODDIR/TMP2"

exit 0