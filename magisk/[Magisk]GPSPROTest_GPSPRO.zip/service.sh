#!/system/bin/sh
#setprop 
#settings put global 
#settings put secure 
#settings put system 
sleep 10
while true ;do
if
setprop persist.backup.ntpServer ntp1.aliyun.com
settings put global persist.backup.ntpServer ntp1.aliyun.com
settings put secure persist.backup.ntpServer ntp1.aliyun.com
settings put system persist.backup.ntpServer ntp1.aliyun.com
settings put global ntp_server ntp1.aliyun.com
settings put secure ntp_server ntp1.aliyun.com
settings put system ntp_server ntp1.aliyun.com
settings put global auto_time_zone 1
settings put secure auto_time_zone 1
settings put system auto_time_zone 1
# 开启GPS 高精确度定位
settings put global location_providers_allowed +gps
settings put secure location_providers_allowed +gps
settings put system location_providers_allowed +gps
settings put global location_providers_allowed +network
settings put secure location_providers_allowed +network
settings put system location_providers_allowed +network
# 开启辅助GPS
settings put global assisted_gps_enabled 1
settings put secure assisted_gps_enabled 1
settings put system assisted_gps_enabled 1
# 查看注册网络类型
# settings get global assisted_gps_network
# 修改注册网络类型为ALL Network
# 默认为:HOME
settings put global assisted_gps_network ALL
settings put secure assisted_gps_network ALL
settings put system assisted_gps_network ALL
# GPS定位模式
# MSA为基站单次定位:适用于GPS信号差时
# MSB是始终使用网络定位
settings put global assisted_gps_position_mode MSB
settings put secure assisted_gps_position_mode MSB
settings put system assisted_gps_position_mode MSB
# GPS服务器地址
settings put global assisted_gps_supl_host
settings put secure assisted_gps_supl_host
settings put system assisted_gps_supl_host
# GPS服务器端口
settings put global assisted_gps_supl_port 7275
settings put secure assisted_gps_supl_port 7275
settings put system assisted_gps_supl_port 7275
fi
sleep 1
done