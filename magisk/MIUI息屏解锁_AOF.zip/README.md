  REQUIREMENTS:
- Magisk 14+
- Any device


  DESCRIPTION:
  I know, pressing the home button to unlock your phone it's very annoying. This module allows you to unlock your device without pressing the home button. The fingerprint scanner will remain always-on to allow that. This module it's now universal! Tested and perfectly working.