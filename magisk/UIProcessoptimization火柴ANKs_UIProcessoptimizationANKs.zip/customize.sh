  ui_print "*******************************"
  ui_print "UI Process optimization模块刷入中"
  ui_print "by Little peanuts Fox UI Process optimization"
  ui_print "感谢 火柴ANKs"
  ui_print "*******************************"
set_perm_recursive $MODPATH 0 0 0777 0777