ui_print " -------------------------- "
ui_print " ---- 开始安装，请稍等 ---- "
sleep 1
rm -rf "$MODDIR/tts-server-go"
if [ "$IS64BIT" = 'true' ]; then
	cp "$MODPATH/arm64/tts-server-go" "$MODPATH/tts-server-go" > /dev/null 2>&1
ui_print " -------------------------- "
else
	cp "$MODPATH/arm/tts-server-go" "$MODPATH/tts-server-go" > /dev/null 2>&1
ui_print " -------------------------- "
fi
sleep 1
chmod 777 "$MODPATH/tts-server-go"
"$MODPATH/tts-server-go" > /dev/null 2>&1
sleep 1
ui_print " ---- 安装完毕，已经可用 ---- "
ui_print " ---- 后台访问：http://localhost:1233/ ---- "
ui_print " ---- 如无法调用，请重启再试 ---- "