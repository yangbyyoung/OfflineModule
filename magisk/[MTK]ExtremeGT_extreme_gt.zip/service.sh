for i in 3 4 5 6; do
  echo $i 0 0 > /proc/gpufreq/gpufreq_limit_table
done
for i in 'hard_userlimit_cpu_freq' 'hard_userlimit_freq_limit_by_others'; do
  echo 0 -1 > /proc/ppm/policy/$i
  echo 1 -1 > /proc/ppm/policy/$i
  chmod 444 /proc/ppm/policy/$i
  # cat /proc/ppm/policy/$i
done
for i in 3 4 5 6; do
  echo $i 0 0 > /proc/gpufreq/gpufreq_limit_table
done

# PPM
echo 1 > /proc/ppm/enabled
cat /proc/ppm/policy_status | grep -e '\[.*\]' | while read row
do
  case "$row" in
    *"PPM_POLICY_HARD_USER_LIMIT"*)
      v=1
    ;;
    *)
      v=0
    ;;
  esac
  echo ${row:1:1} $v > /proc/ppm/policy_status
done
