#!/system/bin/sh
MODDIR=${0%/*}
rm -rf /data/user/0/com.miui.powerkeeper
rm -rf /data/system/package_cache
rm -rf /data/app/com.miui.powerkeeper

chmod 777 $MODDIR/sh
chmod 777 $MODDIR/init
chmod 777 $MODDIR/init/init.sh
/system/bin/sh $MODDIR/init/init.sh