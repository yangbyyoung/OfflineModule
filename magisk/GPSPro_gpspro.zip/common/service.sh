#!/system/bin/sh
# 开启GPS 高精确度定位
settings put secure location_providers_allowed +gps
settings put secure location_providers_allowed +network