#!/system/bin/sh
MODDIR=${0%/*}
sd=/data/media/0/Android/墓碑日志.log

# 该脚本将在设备开机后作为延迟服务启动
wait_boot_completed() {
  i=5
  while true; do
    sleep $i
    completed=$(getprop sys.boot_completed)
    if [[ "$completed" == "1" ]];then
      return
    fi
    i=$((i+1))  # 增加循环变量
  done
}

wait_boot_completed
sleep 20


mkdir /dev/freezer
mount -t cgroup -ofreezer freezer /dev/freezer

mkdir /dev/freezer/thaw
mkdir /dev/freezer/frozen
echo FROZEN > /dev/freezer/frozen/freezer.state
echo THAWED > /dev/freezer/thaw/freezer.state

umount /sys/fs/cgroup/freezer
umount /sys/fs/cgroup
mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup/

mkdir /sys/fs/cgroup/frozen/
mkdir /sys/fs/cgroup/frozenNo/
echo 1 > /sys/fs/cgroup/frozen/cgroup.freeze
echo 0 > /sys/fs/cgroup/frozenNo/cgroup.freeze

chmod a+x "$MODDIR/mb/*.sh"
chmod 777 -R /data/adb/modules/mubei
wait_start() {
echo "开机启动，已删除旧日志！" > $sd
sh /data/adb/modules/mubei/mb/墓碑v2启动.sh
}
wait_start
#pgrep -f mb.sh|while read pid;do echo $pid > /dev/cpuset/audio-app/tasks;done
sleep 5

mb_id="$(pgrep 'mb.sh' | wc -l)"
mb_id2="$(pgrep 'mb2.sh' | wc -l)"

if [ "$mb_id" != "0" ]; then
    echo "$(date '+%T') ️当前模式：Kill墓碑运行成功！" >> $sd
elif [ "$mb_id2" != "0" ]; then
    echo "$(date '+%T') ️当前模式：Freeze v2墓碑运行成功！" >> $sd
else
    echo "$(date '+%T') ️开机启动：失败……！正在尝试2次启动……" >> $sd
    sleep 5
    wait_start
fi



