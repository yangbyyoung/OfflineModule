ui_print "
—— 刷入时间$(date '+%g-%m-%d %H:%M:%S')

—— 面具版本$MAGISK_VER_CODE

—— 面具代号$MAGISK_VER

"
sleep 1
ui_print "请先删除v3.5及以前版本，再刷入本模块"
ui_print "请先删除v3.5及以前版本，再刷入本模块"
ui_print "请先删除v3.5及以前版本，再刷入本模块"
ui_print "
     请确保有 救砖模块
     请确保有 救砖模块
     请确保有 救砖模块
     请确保有 救砖模块
       变砖概不负责
       "
       
sleep 0.5
ui_print ''  ''
ui_print "
     v3.7[全极致]更新
    1.替换 小米13Pro 震动马达驱动
    2.完美解决 通知和来电震动弱问题
    3.此次工程量还是巨大，Friend1y要累死力 ::>_<::
    4.可能为2022年最后一个版本了
       "
ui_print ''   ''
ui_print "
                  
      Friend1y要面临中考了，老哥们有缘再见🎉"
ui_print ''   ''
sleep 1.0
ui_print "
     提示：
     1.觉得[全极致]太强而[日用]又太小 可以在设置--声音与触感--触感--调节，拉低一点
     2.如果找到更好的震动模块可以跟Friend1y说声，会尽可能把二者的优点结合
     3.震动最大的限制依旧是硬件，硬件烂再好的软件也救不起来🌚
     4.Friend1y是谁？鉿这么明显都看不出来？
     5.Lazy是谁？.........
       "
     
        ''
ui_print ''   ''

sleep 1
ui_print "
     目前版本：k50极致震动v3.7[全极致]
   制作时间：2022.12.17.14:01
       "
    
sleep 0.5
ui_print "
     彩蛋：《Citrus Love》
     网易云直链：https://y.music.163.com/m/song?id=1979135725
      "
sleep 0.5
ui_print "
   试试一起唱吧~
   Don't keep me waiting
   别让我久等哦
   Oh~
   Don't you want a taste of me？
   你不想尝尝我的味道嘛
   I'm still wide awake but I wanna dream
   我仍然清醒，但我想做梦
   Summer heat's got me in a daze
   炎炎夏日让我发呆
   Only you got me feeling this way
   只是你让我有这种感觉
   Yeah ,I'm soaking in the sunrays
   我沉浸在阳光之中
   While I'm riding on ya sound waves
   沉醉于你的声音
   I think I found my paradise
   我想我找到了我的天堂
   Kissing you's just like lemonade
   吻你就像喝柠檬茶
   Got this bittersweet aftertaste
   这苦乐参半的回味
   Yeah ,I'm falling head over heel
   我头朝地地倒了
   Hoping that this summer fling's real
   希望这个夏天的放纵是真实的
   I think I found my paradise
   我想我找到了我的天堂"


ui_print "
                  
      陌生人你好呀~，能不能祝我中考加油啊~，谢谢啦~🥰"



set_perm_recursive $MODPATH 0 0 0755 0644
