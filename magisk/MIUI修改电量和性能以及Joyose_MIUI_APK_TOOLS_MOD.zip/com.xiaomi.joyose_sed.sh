#!/system/bin/sh

function recovery_app_path() {
	local package=$1
	dumpsys package $package | grep -w "codePath=" | sed "/\/data/d;s|.*codePath=||g"
}

function unpack_miui_Joyose(){
echo "- 反编译Joyose文件中……"
MIUIpower=$(pm path com.xiaomi.joyose | cut -d ':' -f2 )
MIUIsyspower="/system/app/Joyose/Joyose.apk"
MIUIsyspowerdir="$MODPATH${MIUIsyspower%/*}"
mkdir -p $MIUIsyspowerdir $MODPATH/apk
cp -rf $MIUIpower $MODPATH/apk/base.apk
cd $MODPATH/apk
$apktool d -q -r -f -m $MODPATH/apk/base.apk
echo "- 修改文件中……"
}


function mod_cloud_control(){
echo "- 修改Joyose云控……"
find $MODPATH -type f -name "*.smali" 2>/dev/null | xargs grep -rl '" allow connect: "' | sort | uniq | while read file ;do
sed -i '/^\.method public run()V/,/^\.end method/d' $file
cat <<"key" >>$file
.method public run()V
    .locals 1
    return-void
.end method
key
done
}


unpack_miui_Joyose && {
mod_cloud_control
echo "- 完成！"
echo "- 输出修改文件中……"
cd $MODPATH/apk
$apktool b -q -f -c $MODPATH/apk/base -o Joyose.apk
echo "- 对apk文件zip对齐优化中……"
$zipalign -f 4 $MODPATH/apk/Joyose.apk $MODPATH$MIUIsyspower
echo "- 修改完成！" 
echo ""
test "$(echo "${MIUIpower}" | grep '^/data' )" != "" && rm -rf "${MIUIpower%/*}"
}
