#!/system/bin/sh
path=/data/media/0/Android/
inform="ASGuard v2.2(20210128) by 沍澤"
running=1
dfrn=0
tip=0

add_whitelist() {
  if [[ $tip = 0 ]];then
    echo "["$(date "+%H:%M:%S")"] [Whitelist]:Adding Whitelist" >> $path"log_ASG.txt"
  fi
  OLD_IFS=$IFS
IFS="
"
  array=($AS)
  IFS="$OLD_IFS"
  for var in ${array[@]}
  do
    dumpsys deviceidle whitelist +$var
  done
}

if_access() {
  if [ -f $path"log_ASG.txt" ];then
    echo "Exist document"
    file=1
    until ((file == 0))
    do
      rm $path"log_ASG.txt"
      if [ -f $path"log_ASG.txt" ];then
        echo "Can't remove log_ASG.txt"
        sleep 4
      else
        echo "Removal succeeded"
        file=0
      fi
    done
    echo $inform > $path"log_ASG.txt"
  else
    echo "No such document."
    file=0
    echo $file
    until ((file == 1))
    do
      echo $inform > $path"log_ASG.txt"
      if [ -f $path"log_ASG.txt" ];then
        echo "Generate document"
        file=1
      else
        echo "Generation failed"
        sleep 4
      fi
    done
  fi
}

read_AS() {
  if [ ! -f $path"ASGuard.txt" ];then
    running=0
    echo 0
  else
    AS=$(sed -n p $path"ASGuard.txt")
    if [[ "$AS" != "" ]];then
      running=1
      echo 1
    else
      running=0
      echo 2
    fi
  fi
}

read_EAS() {
if [ ! -f $path"EAS.txt" ];then
    echo 0
  else
    EAS=$(sed -n p $path"EAS.txt")
    if [[ "$EAS" != "" ]];then
      echo 1
    else
      echo 2
    fi
  fi
}

write_EAS() {
  EAS=$EAS$1
  echo $EAS > $path"EAS.txt"
  echo "["$(date "+%H:%M:%S")"]:Saving enable accessible services" >> $path"log_ASG.txt"
}

read_EAST() {
EAST=$(settings get secure enabled_accessibility_services)
}

write_EAST() {
EAST=$EAST$1
settings put secure enabled_accessibility_services $EAST
}


compare_all() {
  read_AS
  EAST=$(settings get secure enabled_accessibility_services)
  read_EAS
  tmpEAST=""
  tmpEAS=""
  tmpAS=""
  tmp=""
  ####
  OLD_IFS=$IFS
IFS="
"
  array=($AS)
  dp1=("${array[@]}")
  IFS=":"
  array=($EAST)
  dp2=("${array[@]}")
  IFS="$OLD_IFS"
  for var1 in ${dp1[@]}
  do
    for var2 in ${dp2[@]}
    do
      result=$(echo $var2 | grep "${var1}")
      if [[ "$result" != "" ]];then
        tmp=$tmp":"$var2
      fi
    done
    if [[ $tmp = "" ]];then
      tmpAS=$tmpAS":"$var1
    else
      tmpEAST=$tmpEAST""$tmp
      tmp=""
    fi
  done
  ######
  if [[ $(read_EAS) != 1 ]];then
    echo $tmpEAST > $path"EAS.txt"
  elif [[ $tmpAS != "" ]];then
    add_whitelist
    tip=1
    
      OLD_IFS=$IFS
  IFS=":"
  array=($tmpAS)
  dp1=("${array[@]}")
  IFS=":"
  array=($EAS)
  dp2=("${array[@]}")
  IFS="$OLD_IFS"
  for var1 in ${dp1[@]}
  do
    for var2 in ${dp2[@]}
    do
      result=$(echo $var2 | grep "${var1}")
      if [[ "$result" != "" ]];then
        tmp=$tmp":"$var2
      fi
    done
    if [[ $tmp = "" ]];then
    dfrn=1
      ###@#####
    OLD_IFS=$IFS
  IFS=":"
  array=($EAST)
  dp3=("${array[@]}")
  IFS="$OLD_IFS"
  for var3 in ${dp3[@]}
  do
    result=$(echo $var3 | grep "$var1")
    if [[ "$result" != "" ]];then
      tmp=$tmp":"$var3
    fi
  done
  if [[ $tmp != "" ]];then
    tmpEAS=$EAS$tmp
    write_EAS $tmpEAS
  else
  #????????
        IFS=":"
  array=($tmpEAS)
  dp1=("${array[@]}")

  IFS="$OLD_IFS"
    
    for var1 in ${dp1[@]}
    do
      result=$(echo $EAS | grep "${var1}")
      if [[ "$result" = "" ]];then
        tmp=$tmp":"$var
      fi
    done
    if [[ $tmp != "" ]];then
    echo $EAS$tmp > $path"EAS.txt"
      tmp=""
    fi
    #????????
  fi
    ###@######
      
    else
      write_EAST $tmp
    fi
  done
    #####
  elif [[ $dfrn = 1 ]];then
  #%%%%%
    dfrn=0
    IFS=":"
  array=($tmpEAST)
  dp1=("${array[@]}")

  IFS="$OLD_IFS"
    
    for var1 in ${dp1[@]}
    do
      result=$(echo $EAS | grep "${var1}")
      if [[ "$result" = "" ]];then
        tmp=$tmp":"$var1
      fi
    done
    if [[ $tmp != "" ]];then
    echo $EAS$tmp > $path"EAS.txt"
      tmp=""
    fi
  
    #%%%%
    
  fi
  unset dp1
  unset dp2
  unset dp3
}

echo "[Running]"
if_access
echo "Running Date "$(date "+%y.%m.%d") >> $path"log_ASG.txt"
echo "["$(date "+%H:%M:%S")"]:ASGuard Running" >> $path"log_ASG.txt"
settings put secure accessibility_enabled 1
if [[ $(read_AS) = 1 ]];then
  read_AS
  add_whitelist
else
  echo "["$(date "+%H:%M:%S")"] [ASGuard.txt]:No pacakge to add whitelist" >> $path"log_ASG.txt"
fi
until ((running > 3))
do
  read_AS
  if [[ $running = 1 ]];then
    echo "["$(date "+%H:%M:%S")"] [ASGuard]:Service running" >> $path"log_ASG.txt"
  fi
  until ((running == 0))
  do
    if [[ $(read_AS) = 1 ]];then
      compare_all
    else
      running=0
    fi
    if [[ $running = 0 ]];then
      echo "["$(date "+%H:%M:%S")"] [ASGuard]:Service stop" >> $path"log_ASG.txt"
    fi
    sleep 2
  done
  sleep 4
done
exit 0
