
#fix 系统后台0-3 bug
echo 0-7 > /dev/cpuset/system-background/cpus
echo 0-7 > /dev/cpuset/background/cpus
#Google
echo 0-7 > /dev/cpuset/oiface_bg/cpus
echo 0-7 > /dev/cpuset/oiface_fg/cpus
echo 0-7 > /dev/cpuset/oiface_fg+/cpus
#显示在上层的应用
echo 0-7 > /dev/cpuset/top-app/cpus
#受限制进程
echo 0-7 > /dev/cpuset/restricted/cpus

