##############################################################

SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

##############################################################

ID="`grep_prop id $TMPDIR/module.prop`"
B="`grep_prop author $TMPDIR/module.prop`"
model="`grep_prop ro.product.system.model`"
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
MIUI="`getprop ro.miui.ui.version.name`"
   ui_print "###############################"
   ui_print "- 模块名称: $MODNAME "
   ui_print "- 模块ID: $ID "
   ui_print "- 模块作者: $B"
   ui_print "- 设备机型: $model"
   ui_print "- 设备代号: $var_device"
   ui_print "- 系统版本: Android $var_version"
   ui_print "- MIUI版本: $MIUI"
   ui_print "- 功能介绍：$MODDES "
   ui_print "###############################"
   
##############################################################

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework"


REPLACE=""

##############################################################

on_install()
{
ui_print "- 正在释放文件"
#准星辅助
DEVICE=`getprop ro.product.device`
if [ -f "/system/etc/device_features/$DEVICE.xml" ];then
mkdir -p $MODPATH/system/etc/device_features/
cp /system/etc/device_features/$DEVICE.xml $MODPATH/system/etc/device_features/
sed -i '3i\\t<bool name="support_game_gunsight">true</bool>' $MODPATH/system/etc/device_features/$DEVICE.xml
sed -i '/<\/features>/i\    <bool name=\"support_game_gunsight\">true<\/bool>' $MODPATH/system/etc/device_features/$DEVICE.xml
fi
if [ -f "/system/vendor/etc/device_features/$DEVICE.xml" ];then
mkdir -p $MODPATH/system/vendor/etc/device_features/
cp /system/vendor/etc/device_features/$DEVICE.xml $MODPATH/system/vendor/etc/device_features/
sed -i '3i\\t<bool name="support_game_gunsight">true</bool>' $MODPATH/system/vendor/etc/device_features/$DEVICE.xml
sed -i '/<\/features>/i\    <bool name=\"support_game_gunsight\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/$DEVICE.xml
fi
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
echo "
#卸载模块自动清理缓存
dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
rm -f $dda/system@*@"$i"*
done
rm -r /data/system/package_cache/*" >> $TMPDIR/uninstall.sh
ui_print "- 全部安装成功"
}

##############################################################

set_permissions()
{
    set_perm_recursive  $MODPATH  0  0  0755  0644
}

##############################################################