MODDIR=${0%/*}

# shellcheck disable=SC2164
cd "$MODDIR"

# shellcheck disable=SC2145
unshare -m sh -c "$MODDIR/daemon --from-service $@&"
