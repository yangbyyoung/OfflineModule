#!/system/bin/sh

JB="mb.sh"
JB1="mb1.sh"
JB2="mb2.sh"
JB_ID=$(pgrep -f "$JB")
JB1_ID=$(pgrep -f "$JB1")
JB2_ID=$(pgrep -f "$JB2")

if [ "$JB_ID" != "" ]; then
    echo "查杀 $JB_ID"
    kill -KILL $JB_ID
fi
  
if [ "$JB1_ID" != "" ]; then
    echo "查杀 $JB1_ID"
    kill -KILL $JB1_ID
fi
if [ "$JB2_ID" != "" ]; then
    echo "查杀 $JB2_ID"
    kill -KILL $JB2_ID
fi
  
mb_id="$(pgrep 'mb.sh' | wc -l)"
mb1_id="$(pgrep 'mb1.sh' | wc -l)"
mb2_id="$(pgrep 'mb2.sh' | wc -l)"

if [ "$mb_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mKill墓碑\e[0m正在运行！"
elif [ "$mb1_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v1墓碑\e[0m正在运行！"
elif [ "$mb2_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v2墓碑\e[0m正在运行！"
else
    echo "\n\e[31m墓碑已经关闭……！\e[0m"   
fi
