ui_print "- by Han | $MODAUTH"
hosts=$(find /data/adb/modules/*/system/etc/hosts -type f -not -path "*/$MODID/*")

if [ -n "$hosts" ]; then
   original_path=$hosts
   new_path="${original_path/\/system\/etc\/hosts/\/module.prop}"
   ui_print  "请直接删除这个模块或卸载:"
   grep -o 'name=[^ ]*' $new_path | cut -d'=' -f2
   abort "如有问题请进群反馈：539544651"   
else
    ui_print "继续安装：$MODNAME"
    ui_print "重启完成后下载hosts并生效"
    ui_print "模块目录下的还有些功能性脚本哦可以去看看"
    ui_print "闲聊/反馈：539544651"
fi

set_perm_recursive "$MODPATH" 0 0 0777 0777
