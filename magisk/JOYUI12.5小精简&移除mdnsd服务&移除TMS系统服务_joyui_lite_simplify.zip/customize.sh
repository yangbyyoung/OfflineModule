SKIPMOUNT=false PROPFILE=false POSTFSDATA=false LATESTARTSERVICE=true
#####################################################################################
 device="`getprop ro.product.device`"
 joyui="`getprop ro.miui.ui.version.name`"
 version="`getprop ro.system.build.id`"
 android="`getprop ro.build.version.release`"
 sdk="`getprop ro.build.version.sdk`"
 name="`getprop ro.blackshark.sdkshare`"
 model="`getprop ro.product.model`"

print_modname() {
 ui_print " "
 ui_print "#########################################"
 ui_print "- 设备型号: $name - $model - $device "
 ui_print "- 安卓版本: Android $android - R - SDK $sdk "
 ui_print "- 系统版本: JOYUI $joyui $version "
 ui_print "#########################################"
 ui_print " "
}
on_install() {
    if [ $joyui = "V125" ] ; then :
    ui_print " "
    ui_print "- 你的系统版本符合"
    else
    echo "- 抱歉，当前 JOYUI 版本不支持（已支持的版本：JOYUI 12.5）" 
    rm -rf $MODPATH
    rm -rf $TMPDIR
    exit 1;
    fi
#####################################################################################
#不要修改到上面的内容，否则刷入失败！

#  MagicFox:
#  ● 以下精简如果有你需要用到的功能，删除对应内容即可，看下面的注释。

ui_print " "
ui_print " • 停用部分系统应用..."
REPLACE="
/system/app/AiAsstVision
/system/app/AntHalService
/system/app/baiduime
/system/app/BasicDreams
/system/app/BuiltInPrintService
/system/app/CarrierDefaultApp
/system/app/gf_display_g5_test
/system/app/mab
/system/app/MaintenanceMode
/system/app/mi_connect_service
/system/app/MiLinkService2
/system/app/MiPlayClient
/system/app/MiuiAccessibility
/system/app/MiuiDaemon
/system/app/MiWallpaperEarth
/system/app/MiWallpaperMars
/system/app/ModemTestBox
/system/app/MSA
/system/app/PaymentService
/system/app/PrintSpooler
/system/app/SharkMonitor
/system/app/SimAppDialog
/system/app/SimContact
/system/app/Stk
/system/app/tencenttrs
/system/app/Traceur
/system/app/UmeBrowser
/system/app/WAPPushManager
/system/app/WMService
/system/priv-app/BlockedNumberProvider
/system/priv-app/BsSearch
/system/priv-app/BuiltInPrintService
/system/priv-app/FactoryTest
/system/priv-app/HardwareTest
/system/priv-app/MiuiVideo
/system/priv-app/Music
/system/priv-app/OTA
/system/priv-app/tencentappstore
/system/priv-app/tencenttms
/system/priv-app/WfdService
/system/product/app/PhotoTable
/system/product/app/talkback
/system/system_ext/priv-app/EmergencyInfo
"

ui_print " "
ui_print " • 卸载部分系统预装应用（除第三方应用）："
ui_print " - 卸载黑鲨服务..."
pm uninstall --user 0 com.blackshark.aftersaleservice
ui_print " - 卸载黑鲨社区..."
pm uninstall --user 0 com.blackshark.forum
ui_print " - 卸载黑鲨支付..."
pm uninstall --user 0 com.blackshark.payment
ui_print " - 卸载黑鲨商城..."
pm uninstall --user 0 com.blackshark.store
ui_print " - 卸载玩家手册..."
pm uninstall --user 0 com.blackshark.userguide
ui_print " - 卸载万能遥控..."
pm uninstall --user 0 com.duokan.phone.remotecontroller
ui_print " - 卸载小米画报..."
pm uninstall --user 0 com.mfashiongallery.emag
ui_print " - 卸载小米健康..."
pm uninstall --user 0 com.mi.health
ui_print " - 卸载指南针..."
pm uninstall --user 0 com.miui.compass
ui_print " - 卸载小米换机..."
pm uninstall --user 0 com.miui.huanji
ui_print " - 卸载小米商城..."
pm uninstall --user 0 com.xiaomi.shop
ui_print " - 卸载小米文档查看器（WPS定制）..."
pm uninstall --user 0 cn.wps.moffice_eng.xiaomi.lite
ui_print " - 卸载黑鲨浏览器（腾讯）..."
pm uninstall --user 0 com.tencent.southpole.browser
ui_print " "
ui_print " ! 以上应用可到系统可卸载应用找回（设置菜单里）..."

# ● 注释：
# AI虚拟助手/system/app/AiAsstVision
# 天线服务/system/app/AntHalService
# 百度输入法黑鲨版/system/app/baiduime
# 基本互动屏保/system/app/BasicDreams
# 系统打印服务/system/app/BuiltInPrintService
# 运营商默认应用/system/app/CarrierDefaultApp
# Goodix指纹/system/app/gf_display_g5_test
# 小米商城系统组件/system/app/mab
# 维修模式/system/app/MaintenanceMode
# 小米互联通信服务/system/app/mi_connect_service
# 投屏/system/app/MiLinkService2
# 投屏服务/system/app/MiPlayClient
# 小米闻声/system/app/MiuiAccessibility
# 用户信息收集/system/app/MiuiDaemon
# 地球超级壁纸/system/app/MiWallpaperEarth
# 火星超级壁纸/system/app/MiWallpaperMars
# 智能服务/system/app/MSA
# MODEM测试工具/system/app/ModemTestBox
# 打印处理服务/system/app/PrintSpooler
# 黑鲨监控浮窗/system/app/SharkMonitor
# SIM日志/system/app/SimAppDialog
# SIM联系人/system/app/SimContact
# USIM卡应用/system/app/Stk
# 腾讯TRS系统服务/system/app/tencenttrs
# 系统跟踪/system/app/Traceur
# 黑鲨浏览器/system/app/UmeBrowser
# 推送服务/system/app/WAPPushManager
# 推送服务/system/app/WMService
# 存储已屏蔽的号码/system/priv-app/BlockedNumberProvider
# 黑鲨搜索/system/priv-app/BsSearch
# 系统打印服务/system/priv-app/BuiltInPrintService
# 工程模式/system/priv-app/FactoryTest
# 售后检测工具/system/priv-app/HardwareTest
# 小米视频/system/priv-app/MiuiVideo
# 小米音乐/system/priv-app/Music
# 系统更新/system/priv-app/OTA
# 腾讯应用市场/system/priv-app/tencentappstore
# 腾讯TMS系统服务/system/priv-app/tencenttms
# 照片屏幕保护程序/system/product/app/PhotoTable
# 无障碍服务/system/product/app/talkback
# 急救信息/system/system_ext/priv-app/EmergencyInfo

# 黑鲨服务 --user 0 com.blackshark.aftersaleservice
# 黑鲨高能时刻 --user 0 com.blackshark.discovery
# 黑鲨社区 --user 0 com.blackshark.forum
# 黑鲨支付 --user 0 com.blackshark.payment
# 黑鲨商城 --user 0 com.blackshark.store
# 玩家手册 --user 0 com.blackshark.userguide
# 万能遥控 --user 0 com.duokan.phone.remotecontroller
# 小米画报 --user 0 com.mfashiongallery.emag
# 小米健康 --user 0 com.mi.health
# 指南针 --user 0 com.miui.compass
# 小米换机 --user 0 com.miui.huanji
# 小米商城 --user 0 com.xiaomi.shop
# 小米文档查看器（WPS定制） --user 0 cn.wps.moffice_eng.xiaomi.lite
# 黑鲨浏览器（腾讯） --user 0 com.tencent.southpole.browser
}

—————————————————————————————————————————————

# ●温馨提醒：注意以下列出的千万不要精简!!否则可能卡开机!!!
# SecurityCoreAdd 安全核心组件
# XiaomiServiceFramework 小米服务框架
# MiSettings 设置
# MiuiSystemUI 系统UI
# miui 系统核心组件

set_permissions() {
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  set_perm_recursive  $MODPATH  0  0  0755  0644
  ui_print " "
  sleep 0.5
  MagicFox=$MODPATH/module.prop
  time0=$(date "+%Y-%m-%d %H:%M")
  echo "- 当前时间: $time0"
  echo "$time0" >> $MagicFox
  sleep 2
}