#!/system/bin/sh


function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g' | head -n 1
}

function unlock_thermal(){
local target="${1}"
chattr -R -i "${target}" >/dev/null 2>&1
chattr -R -i "${target%/*}" >/dev/null 2>&1
echo "@coolapk10007" > "${target}/thermal.txt" 2>/dev/null || {
rm -rf "${target%/*}"
mkdir -p "${target}"
} && rm -rf "${target}"/* "${target}/thermal.txt"
chmod -R 0771 '/data/vendor/thermal'
	chown -R root:system '/data/vendor/thermal'
chcon -R 'u:object_r:vendor_data_file:s0' '/data/vendor/thermal'
}


unlock_thermal "/data/thermal/config"
unlock_thermal "/data/vendor/thermal/config"

function Running_thermal_lib_file_remove(){
echo -e "- 查找其他温控文件！\n"
find /system /system_ext /vendor /product -iname '*thermal*' -type f  2> /dev/null | sed '/.*android.*/d;/.*libthermalclient.*/d;/.*thermal-engine.*/d;/.*thermal.*conf/d;/.*hardware.*/d;/.*mi_thermald.*/d' | while read file ;do
file=$(correctpath $file  )
test "${file##*/}" = "mi_thermald" && continue
test "${file##*/}" = "thermal_manager" && continue
test "${file##*/}" = "thermal-engine" && continue
if test -n $file ;then
	mkdir -p $MODPATH${file%/*}
	touch $MODPATH$file && echo "成功替换: $file"
fi
done
echo -e "\n∞————————————————————————∞\n"
}

if test "$(show_value '替换系统温控文件')" = "是" ;then
	Running_thermal_lib_file_remove
fi

function cp_MTK_thermal_conf_find(){
local MTK_MODPATH_config_DIR="${MODPATH}/mod/MTK_thermal"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	mkdir -p "${MODPATH}/system/vendor/etc/thermal" "${MODPATH}/system/vendor/etc/.tp"
		touch "${MODPATH}/system/vendor/etc/thermal/.replace"
	touch "${MODPATH}/system/vendor/etc/.tp/.replace"
	find $(magisk --path)/.magisk/mirror/vendor/etc/thermal $(magisk --path)/.magisk/mirror/vendor/.tp -iname "*.conf" -type f -o -iname "*.mtc" -type f 2>/dev/null | while read file ;do
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/thermal/${file##*/}"
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/.tp/${file##*/}"
	done
		cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/thermal"
	cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/.tp" 
fi
}

cp_MTK_thermal_conf_find


