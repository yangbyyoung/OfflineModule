#!/system/bin/sh
MODDIR="$(dirname "$0")"
$MODDIR/B.sh &>/dev/null &