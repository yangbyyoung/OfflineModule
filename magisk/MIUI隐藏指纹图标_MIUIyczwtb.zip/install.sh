
SKIPMOUNT=false            #安装后自关闭
PROPFILE=false              #system.prop
POSTFSDATA=false          #post-fs-data
LATESTARTSERVICE=false    #service.sh

# 安装      
  unzip -o "$ZIPFILE" "Yunc/*" -d $MODPATH >&2
  cp -rf $MODPATH/Yunc/zip /sbin/.magisk/busybox/
  chmod 777 /sbin/.magisk/busybox/zip
  mkdir -p $MODPATH/system/media/theme/default
  route="$MODPATH/system/media/theme/default"
  
  # 兼容
  Detect1="/system/media/theme/default/com.android.systemui"
  Detect2="/data/system/theme/com.android.systemui"  
  
  if [ -e $Detect1 ] ; then
  mkdir -p $MODPATH/Detect
  unzip -o $Detect1 -d $MODPATH/Detect >&2
  find $MODPATH/Detect -name "finger_image_grey.*" -exec rm -rf {} \;
  find $MODPATH/Detect -name "finger_image_light.*" -exec rm -rf {} \;
  find $MODPATH/Detect -name "finger_image_normal.*" -exec rm -rf {} \;
  cp -rf $MODPATH/Yunc/Material/* $MODPATH/Detect
  cd $MODPATH/Detect && zip -q -r0 "com.android.systemui" *
  cp -rf $MODPATH/Detect/com.android.systemui $route
  rm -rf $MODPATH/Detect
  rm -rf $MODPATH/Yunc
    
    else
    cd $MODPATH/Yunc/Material && zip -q -r0 "com.android.systemui" *
    cp -rf $MODPATH/Yunc/Material/com.android.systemui $route  
    rm -rf $MODPATH/Yunc
      fi
      
      if [ -e $Detect2 ] ; then
      mkdir -p $MODPATH/Detect
      unzip -o $Detect2 -d $MODPATH/Detect >&2
      find $MODPATH/Detect -name "finger_image_grey.*" -exec rm -rf {} \;
      find $MODPATH/Detect -name "finger_image_light.*" -exec rm -rf {} \;
      find $MODPATH/Detect -name "finger_image_normal.*" -exec rm -rf {} \;
      cd $MODPATH/Detect && zip -q -r0 "com.android.systemui" *
      cp -rf $MODPATH/Detect/com.android.systemui $Detect2
      chmod 755 $Detect2
      rm -rf $MODPATH/Detect
    fi
  
# 权限  
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
}