#!/system/bin/sh
if [ -e /system/xbin/olx.wlan ] 
then
echo "挂载分区"
mount -o remount -rw  /system
busybox mount -o remount -rw  /system
chmod 0755 /system/xbin/*
busybox chmod 0755 /system/xbin/*
# wlan配置文件位置
# find /vendor/etc/wifi/* -name "WCNSS_qcom_cfg.ini" > /data/media/0/Rulong/Wlan配置文件位置.log
# 启动
olx.wlan
else
echo "请更新模块后重启再执行"
echo "否则你的data将被格式化"
fi