#定义相关路径和文件
DEX2OAT_CONFIG=/data/adb/Dex2oatBOOT/dex2oat基础配置.prop
OPTIONALAPP_CONFIG=/data/adb/Dex2oatBOOT/dex2oat自选应用配置.prop

#创建配置文件
mkdir /data/adb/Dex2oatBOOT
if [ ! -d $DEX2OAT_CONFIG ]; then
	touch $DEX2OAT_CONFIG
fi
if [ ! -d $OPTIONALAPP_CONFIG ]; then
	touch $OPTIONALAPP_CONFIG
fi
touch /data/adb/Dex2oatBOOT/重启手机.sh

#读取旧配置
dex2oat_mode=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^模式=" | cut -f2 -d '=')
dex2oat_select=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^应用=" | cut -f2 -d '=')
optional_app=$(sed '/^#/d' $DEX2OAT_CONFIG | grep "^自选应用=" | cut -f2 -d '=')
Optionalapp=$(cat $OPTIONALAPP_CONFIG | grep -v '^#')

#写入配置
echo "#dex2oat基础配置文件
#使用模式，可选：
#speed-profile 性能较差，所占空间小
#speed 性能一般，所占空间适中
#everything 性能最好，所占空间大
模式=$dex2oat_mode
#应用选择，可选：
#系统应用，三方应用，全部应用
应用=$dex2oat_select
#自选应用，填：
#是，否
自选应用=$optional_app
#注意！当 应用不填，自选应用=是 时，只编译自选应用
#注意！当 应用=系统应用/三方应用，自选应用=是 时，编译系统应用/三方应用和自选应用
" > $DEX2OAT_CONFIG
echo "#dex2oat自选应用配置文件（填包名，一行一个）
$Optionalapp" > $OPTIONALAPP_CONFIG
echo "reboot" > /data/adb/Dex2oatBOOT/重启手机.sh
