#!/system/bin/sh
file=${0%/*}/卸载包名.conf
cat "${file}" | grep -v "^#" | while read packagename ;do
pm install-existing --user 0 $packagename
done