	 ui_print "
open the hide power mod
/
/
/
open the hide CPU GPU mod
/
/
/
/
over

	 "
 		
  