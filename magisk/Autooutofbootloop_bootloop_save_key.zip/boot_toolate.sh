#!/system/bin/sh

source "${0%/*}/util_functions.sh"

sleep $(show_value "自动禁用时间")

if test "$(getprop service.bootanim.exit)" != "1" ;then
	if test "$(getprop sys.boot_completed)" != "1" ;then
		run_main && change_description "[E] zygote 启动异常！" "[E] zygote start error！" "false" "true"
		reboot
	fi
fi



