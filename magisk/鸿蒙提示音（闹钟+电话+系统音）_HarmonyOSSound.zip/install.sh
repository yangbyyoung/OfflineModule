SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/charging.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/camera_click.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/camera_focus.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Dock.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Effect_Tick.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/InCallNotification.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/IncomingMessage.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/KeypressDelete.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/KeypressInvalid.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/KeypressReturn.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/KeypressSpacebar.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/KeypressStandard.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Lock.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/LowBattery.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/MessageSent.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/PowerConnected.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Trusted.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Undock.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Unlock.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/VideoPause.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/VideoRecord.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/VideoRecordEnd.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/VideoStop.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDrop_preview.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterWarning.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WirelessPowerConnected.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Water_Notification_Day.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Water_Notification_Evening.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Water_Notification_Midday.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/Water_Notification_Night.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationDay1.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationDay2.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationMidday3.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationMidday1.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationMidday2.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationDay3.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationEvening1.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationEvening2.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationEvening3.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationNight1.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationNight2.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationNight3.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ui/WaterDropNotificationSeqAllDay1.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/alarms/Daydream.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ringtones/Mi.ogg' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/media/audio/ringtones/MiRemix.ogg' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}