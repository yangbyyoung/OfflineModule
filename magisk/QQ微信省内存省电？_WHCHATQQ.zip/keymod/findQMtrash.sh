
MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

#通用日志清理
function tencentlog(){
	find /data/data/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/data/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent/ -type d -iname "*crash*" -exec rm -rf {} \;
	find /data/data/com.tencent.mobileqq /data/media/*/Android/data/com.tencent.mobileqq /data/data/com.tencent.mm /data/media/*/Android/data/com.tencent.mm /data/media/*/Tencent/ -type d -iname "*log*" -exec rm -rf {} \;
}

QQ="
#QQ空间缓存
/data/media/*/Android/data/com.tencent.mobileqq/qzone
#腾讯热更新补丁
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/TMAssistantSDK
#QQ网页缓存
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/pddata
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.apollo
#QQ礼物缓存
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.gift
#QQ聊天时发送的图片缓存(可选)
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/photo
#QQ缩略图缓存
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/thumb
#QQ热门表情包
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/hotpic
#DIY名片
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/vas
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/lottie
#空间直播
/data/media/*/Android/data/com.tencent.mobileqq/qzlive
#通用缓存清理
/data/data/com.tencent.mobileqq/cache
/data/data/com.tencent.mobileqq/files/ArkApp/Cache
/data/data/com.tencent.mobileqq/app_webview_tool*
/data/data/com.tencent.mobileqq/app_webview_com.tencent.mobileqq:mini_internal*
/data/media/*/Android/data/com.tencent.mobileqq/cache
/data/media/*/Android/data/com.tencent.mobileqq/cache/file/download_cache
"

MM="
#微信公众号图片
/data/media/*/Android/data/com.tencent.mm/MicroMsg/*/image
/data/media/*/Android/data/com.tencent.mm/MicroMsg/*/bizimg
#微信检查更新文件
/data/media/*/Android/data/com.tencent.mm/MicroMsg/CheckResUpdate
#微信小程序图片
/data/media/*/Android/data/com.tencent.mm/MicroMsg/Download/appbrand
#微信崩溃日志
/data/media/*/Android/data/com.tencent.mm/MicroMsg/crash
#通用缓存清理
/data/data/com.tencent.mm/cache
/data/data/com.tencent.mm/app_webview_com_tencent_mm_appbrand*
/data/data/com.tencent.mm/app_webview_com_tencent_mm_tools*
/data/media/*/Android/data/com.tencent.mm/cache
#每天都在下载，又不知道有什么用的文件，从来都不会清理
/data/data/com.tencent.mm/MicroMsg/webview_tmpl
"

TIM="
#TIM短视频
/data/media/*/Tencent/Tim/shortvideo
"

echo "－ 清理无伤大雅的文件中……"
for i in $QQ $MM;do
	file=`find "$i" 2> /dev/null`
	rm -rf $file 2> /dev/null
done
tencentlog 2> /dev/null
echo "－ 清理完成！"
