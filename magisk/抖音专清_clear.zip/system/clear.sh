#抖音专清 V1
#酷安@给风说晚安
#转载文件 需注明来源

rm -rf /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/awemeSplashCache
touch /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/awemeSplashCache
chmod -R 000 /data/media/0/Android/data/com.ss.android.ugc.aweme/awemeSplashCache
rm -rf /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/cache
touch /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/cache
chmod -R 000 /data/media/0/Android/data/com.ss.android.ugc.aweme/cache
rm -rf /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/splashCache
touch /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/splashCache
chmod -R 000 /data/media/0/Android/data/com.ss.android.ugc.aweme/splashCache
rm -rf /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/files
touch /storage/emulated/0/Android/data/com.ss.android.ugc.aweme/files
chmod -R 000 /data/media/0/Android/data/com.ss.android.ugc.aweme/files
rm -rf /data/data/com.ss.android.ugc.aweme/databases/apm_monitor_t1.db
mkdir /data/data/com.ss.android.ugc.aweme/databases/apm_monitor_t1.db
rm -rf /data/data/com.ss.android.ugc.aweme/cache
touch /data/data/com.ss.android.ugc.aweme/cache
chmod -R 000 /data/data/com.ss.android.ugc.aweme/cache


rm -rf /data/data/com.ss.android.ugc.aweme/small_emoji_res
touch /data/data/com.ss.android.ugc.aweme/small_emoji_res

rm -rf /data/data/com.ss.android.ugc.aweme/app_assets
touch /data/data/com.ss.android.ugc.aweme/app_assets


rm -rf /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:push
touch /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:push
chmod -R 000 /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:push
rm -rf /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:pushservice
touch /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:pushservice
chmod -R 000 /data/data/com.ss.android.ugc.aweme/app_webview_com.ss.android.ugc.aweme:pushservice


rm -rf /data/data/com.ss.android.ugc.aweme/files/ALOG
rm -rf /data/data/com.ss.android.ugc.aweme/files/mvtheme
rm -rf /data/data/com.ss.android.ugc.aweme/files/alogCrash
rm -rf /data/data/com.ss.android.ugc.aweme/files/apks
rm -rf /data/data/com.ss.android.ugc.aweme/files/keva
rm -rf /data/data/com.ss.android.ugc.aweme/files/libso
rm -rf /data/data/com.ss.android.ugc.aweme/files/logs
touch /data/data/com.ss.android.ugc.aweme/files/logs
rm -rf /data/data/com.ss.android.ugc.aweme/files/music
rm -rf /data/data/com.ss.android.ugc.aweme/files/CrashCommonLog
rm -rf /data/data/com.ss.android.ugc.aweme/files/filters
rm -rf /data/data/com.ss.android.ugc.aweme/files/filter
rm -rf /data/data/com.ss.android.ugc.aweme/files/effect
rm -rf /data/data/com.ss.android.ugc.aweme/files/offline
touch /data/data/com.ss.android.ugc.aweme/files/offline
rm -rf /data/data/com.ss.android.ugc.aweme/files/offlineX
touch /data/data/com.ss.android.ugc.aweme/files/offlineX
rm -rf /data/data/com.ss.android.ugc.aweme/files/plugins
touch /data/data/com.ss.android.ugc.aweme/files/plugins
rm -rf /data/data/com.ss.android.ugc.aweme/files/live_sdk_gecko
touch /data/data/com.ss.android.ugc.aweme/files/live_sdk_gecko




