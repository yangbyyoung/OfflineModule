#!/system/bin/sh

function echo_new_conf_content(){
echo '['
cmd package list package -3 | cut -d':' -f2 | while read package ;do
cat << key
{"defaultEnable":false,"overrideEnableValue":0,"packageName":"$package","showInSettings":true},
key
done
echo '{}]'
}

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

function over_write_dark_settings(){
find /system /system_ext /vendor /product -iname "ForceDarkAppSettings.json" 2>/dev/null | while read file ;do
	file=`correctpath "$file"`
	target_file="$MODPATH$file"
	mkdir -p "${target_file%/*}"
cat << key > "$target_file"
$(echo_new_conf_content)
key
done
}

over_write_dark_settings



