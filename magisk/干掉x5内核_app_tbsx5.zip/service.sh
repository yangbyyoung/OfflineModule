#!/system/bin/sh
MODDIR=${0%/*}
chmod -R 777 $MODDIR/mod/killx5.sh
sleep 15
nohup $MODDIR/mod/killx5.sh &
