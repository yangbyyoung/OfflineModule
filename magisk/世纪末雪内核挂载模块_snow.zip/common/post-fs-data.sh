#! /vendor/bin/sh
MODDIR=${0%/*}
# 删除log日志
find /data -name "*.log" -exec rm -rf {} \;
{
dmesg
} >>/cache/dmesg.log
{
su -c "dmesg | grep volt="
} >>/cache/CPU.log
{
dmesg | grep gfx3d_clk_src
} >>/cache/GPU.log
{
lsmod
} >>/cache/modules.log