MODID=MiuiSecurityCenter
APP="SecurityCenter
     com.miui.securitycenter
     RtMiCloudSDK
     com.xiaomi.micloud.sdk
     CleanMaster
     com.miui.cleanmaster
     securityadd
     Permissions
     com.lbe.security.miui
     PowerKeeper
     com.miui.powerkeeper
     GuardProvider
     com.miui.guardprovider"
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/system/package_cache -type f -name *$APPS*`
done
rm -rf /metadata/magisk/$MODID
rm -rf /mnt/vendor/persist/magisk/$MODID
rm -rf /persist/magisk/$MODID
rm -rf /data/unencrypted/magisk/$MODID
rm -rf /cache/magisk/$MODID


