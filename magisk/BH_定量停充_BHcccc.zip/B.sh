#!/system/bin/sh
sleep 60
MODDIR=${0%/*}
module="$MODDIR/module.prop"
conf="/data/media/0/Android/BHcharging/files.conf"
Stop_charging=$(sed '/^Stop_charging=/!d;s/.*=//' "$conf")
USBpath=$(sed '/^USBpath=/!d;s/.*=//' "$conf")
if [ ! -f "$USBpath" ];then
	sed -i "s/状态：.*/状态：失败设备不支持]/g" "$module"
	touch "$MODDIR/disable"
	exit 1
elif [ "$Stop_charging" = "" ];then
	sed -i "s/状态：.*/状态：未运行，请修改配置文件]/g" "$module"
	touch "$MODDIR/disable"
	exit 1
fi
sed -i "s/状态：.*/状态：运行中]/g" "$module"
echo "BH定量停充 酷安@不太会起网名" > /sdcard/Android/BHcharging/out.log
nohup "$MODDIR/BH"  &>/dev/null &