DIR=$(dirname $(readlink -f $0))
scriptfile=Dynamic_fps1.0
kill_mod(){
lastID=$(ps -eo pid,args | grep "$scriptfile" | grep -v 'grep' | grep -v "customize")
if [ "$lastID" != "" ]
then
            echo "$lastID" | while read pid name; do
            
            if [ "$$" != "$pid" ]; then
            echo "关闭 $pid $name"
            kill -KILL $pid
            fi
            done
fi
}
infinite_loop() {
while true
   do
        lastID=$(ps -eo pid,args | grep "$scriptfile" | grep -v 'grep' )
        if [ "$lastID" == "" ];then
        #异常退出
        echo 启动：$scriptfile！
        $DIR/$scriptfile &
        fi
        sleep 60
        let a++
        #echo $a
        if [ $a -gt 10080 ];then
        kill_mod
        fi
    done
}
infinite_loop

