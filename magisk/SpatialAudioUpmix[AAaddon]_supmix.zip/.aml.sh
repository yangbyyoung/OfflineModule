#!/system/bin/sh
patch_cfgs -pl gaudiosolmusicone 6475483e-c7ed-44f0-8a15-1530c42039aa gaudio_sw e13f2d8d-f7be-4142-a1e9-c7024f5d1996 <LIBDIR>/lib/soundfx/libgaudiosolmusicone_sw.so gaudio_hw c75e44ec-e3e9-4212-8ef2-25b61d8feba6 <LIBDIR>/lib/soundfx/libgaudiosolmusicone_hw.so
patch_cfgs -o music gaudiosolmusicone
