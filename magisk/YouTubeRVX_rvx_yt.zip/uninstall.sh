#!/system/bin/sh

