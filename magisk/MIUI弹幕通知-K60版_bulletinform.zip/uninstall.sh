#此脚本在卸载时进行
settings put secure gb_bullet_chat 0
settings put secure gb_boosting 0
tmp_list="barrage"

dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"*
done
rm -rf /data/system/package_cache/*
