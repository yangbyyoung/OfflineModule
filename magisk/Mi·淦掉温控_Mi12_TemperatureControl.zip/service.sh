#!/system/bin/sh
MODDIR=${0%/*}
until [ $(getprop sys.boot_completed) == 1 ]; do
  sleep 1
done
chmod 777 $MODDIR/*.sh
Install_time=`cat $MODDIR/Install_time`
Time=30
while [ $Time -ge 0 ]; do
  sed -i "/^description=/c description=等待重启：[ -⏰${Time}s- ] ，Mi·淦掉温控：不跳电淦温控，淦掉云控，满血快充(会阶梯式充电，也会受机身48℃温度墙影响)，游戏不掉帧，兼容A12/A13，MIUI13/MIUI14。" $MODDIR/module.prop
  sleep 1
  Time=$((Time-1))
done

function Initialization_file(){
thermals=`ls /system/bin/*thermal* /system/etc/init/*thermal* /system/etc/perf/*thermal* /system/vendor/bin/*thermal* /system/vendor/etc/*thermal* /system/vendor/etc/powerhint* /system/vendor/etc/init/*_thermal* /system/vendor/etc/perf/*thermal* /system/vendor/lib/hw/thermal* /system/vendor/lib64/hw/thermal* 2>/dev/null | grep -v mi_thermald | grep -v thermal-engine.conf | grep -v thermal-normal.conf | grep -v thermal-map.conf | grep -v thermal-engine | grep -v thermalserviced | grep -v "*.so"`

for thermal in $thermals; do
  [[ ! -d $ModuleAdd/thermals/${thermal%/*} ]] && mkdir -p $ModuleAdd/thermals/${thermal%/*}
  touch $ModuleAdd/thermals/$thermal
done

systems="/system/bin /system/etc/init /system/etc/perf /system/vendor/bin /system/vendor/etc /system/vendor/etc /system/vendor/etc/init /system/vendor/etc/perf /system/vendor/lib/hw /system/vendor/lib64/hw"
for system in $systems; do
  if [ -d "$system" ];then
    mkdir -p $ModuleAdd/$system
  fi
done

cp -rf $ModuleAdd/thermals/system/ $ModuleAdd
rm -rf $ModuleAdd/thermals/
}
Initialization_file
if [ -f "$MODDIR/Repair_jump.sh" ];then
  /system/bin/sh $MODDIR/Repair_jump.sh
fi
/system/bin/sh $MODDIR/Dynamic_cloud_control.sh >/dev/null 2>&1 &