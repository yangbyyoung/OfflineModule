#查杀之前遗留的进程
echo 准备重启：
echo ----------------------------
script_name="EasyClean"
lastID=$(ps -eo pid,args | grep "$script_name" | grep -v 'grep' | grep -v "一键启动重启后台压制")
if [ "$lastID" != "" ]
then
            echo "$lastID" | while read pid name; do
            
            if [ "$$" != "$pid" ]; then
            echo "关闭 $pid $name"
            kill -KILL $pid
            fi
            done
echo -----------已关闭-----------
else
echo -----没有正在运行的实例-----
fi
echo ----------------------------
DIR=$(dirname $(readlink -f $0))
logpath=/storage/emulated/0/Android/EasyClean
rm -rf $logpath/output.txt
rm -rf $logpath/clean.log
scriptfile=EasyClean1.0.beta2
#启动程序
$DIR/$scriptfile &