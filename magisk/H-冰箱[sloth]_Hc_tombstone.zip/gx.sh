if [ "$(id -u)" != "0" ]; then
   echo "不给root执行什么？"
   exit 1
fi
rm -rf /data/media/0/Android/Hc_tombstone/日志.log
kill -9 $(hcpid HC_freezer)
echo "更新配置成功，无需重启手机"