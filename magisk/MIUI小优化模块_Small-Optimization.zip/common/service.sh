#!/system/bin/sh
MODDIR=${0%/*}
SDCARD="/data/media/0/Android"
[[ ! -d $SDCARD ]] && SDCARD="/sdcard/Android"
wait_start=0
until [[ $(getprop sys.boot_completed) -eq 1 ]] && [[ -d $SDCARD ]]; do
	sleep 2
	wait_start=$((${wait_start} + 1))
	[[ ${wait_start} -ge 180 ]] && break
done
Permission_setting() {
  rm -rf $1
  touch $1
  chmod 000 $1
}
Read() {
  [[ -f $1 ]] && cat $1
}
function settings() {
  Read $PZ | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
MOD_Information="$MODDIR/module.prop"
SCRIPTPATH="$MODDIR/Script"
REMOVE="$MODDIR/remove"
PZFOLDER="$SDCARD/MIUI小优化配置"
LOG="$PZFOLDER/日志.log"
PZ="$PZFOLDER/Small-Optimization.conf"
SOPATH="/data/adb/modules/Small-Optimization"
Execution_Waiting=0
Sign_out=0
until [[ $Execution_Waiting -gt 0 ]]; do
	sleep 2
	$MODDIR/Script/StartUp
	if [ $? -eq 0 ]; then
		Execution_Waiting=$((${Execution_Waiting} + 1))
	else
		Sign_out=$((${Sign_out} + 1))
		if [[ $Sign_out -ge 60 ]]; then
		sed -i "/^description=/c description=“模块去世提醒：你的设备环境不适合运行此模块，请进行卸载。" "$MOD_Information"
		exit 0
		fi
	fi
done
{
while :;do
	SLEEP=$(settings sleep)
	sleep $SLEEP
	$MODDIR/configurations
	$MODDIR/Script/Discharge
	[[ -e $PZFOLDER/*.*.bak ]] && rm -rf $PZFOLDER/*.*.bak
	if [[ -e $REMOVE ]]; then
		sleep 3
		rm -rf $PZFOLDER
		sh $MODDIR/uninstall.sh
		rm -rf $SOPATH
		exit 0
	fi
done
} &