#!/system/bin/sh
MODDIR=${0%/*}
#!/system/bin/sh

BASEDIR="$(dirname $(readlink -f "$0"))"
chmod 777 -R /data/adb/modules/ram

sh $BASEDIR/运存防线启动.sh