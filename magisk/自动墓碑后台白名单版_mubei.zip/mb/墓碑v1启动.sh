#!/system/bin/sh
MODDIR=${0%/*}

    sd=/data/media/0/Android/墓碑日志.log
JB="mb.sh"
JB1="mb1.sh"
JB2="mb2.sh"
JB_ID=$(pgrep -f "$JB")
JB1_ID=$(pgrep -f "$JB1")
JB2_ID=$(pgrep -f "$JB2")

if [ "$JB_ID" != "" ]; then
    kill -KILL $JB_ID
fi
  
if [ "$JB1_ID" != "" ]; then
    kill -KILL $JB1_ID
fi
if [ "$JB2_ID" != "" ]; then
    kill -KILL $JB2_ID
fi
  
  

	nohup $MODDIR/mb1.sh > /dev/null 2>&1 & 
	
    mb_id="$(pgrep 'mb.sh' | wc -l)"
    mb1_id="$(pgrep 'mb1.sh' | wc -l)"
    mb2_id="$(pgrep 'mb2.sh' | wc -l)"	
    
	if [ "$mb1.sh_id" != "0" ]; then
	sed -i 's/\[.*\]/\[ 模式：Feerze v1 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	sed -i 's/墓碑.*启动.sh/墓碑v1启动.sh/g' "/data/adb/modules/mubei/service.sh" >/dev/null 2>&1
    echo "$(date '+%T') 已经切换到Feerze v1模式" >>$sd 
	else
	sed -i 's/\[.*\]/\[ Feerze v1 启动失败 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
    fi