echo ''
echo ''
echo ''

if [[ -f /sys/fs/cgroup/cgroup.controllers ]]; then
  mount_cgroup2_sys
  echo '看起来可以用cgroup(v2)'
else
  # grep cgroup /proc/filesystems
  # Result Example:
  # nodev   cgroup
  # nodev   cgroup2
  versions=$(grep -E 'cgroup$' /proc/filesystems)
  if [[ $(grep -E 'cgroup$' /proc/filesystems) == '' ]]; then
    echo '该模块不适用于你的系统，因为内核未启用相关特性'
    exit 2
  else
    mount_cgroup_sys
    # mount_cgroup_dev
    echo '看起来可以用cgroup(v1)'
  fi
fi

echo ''
echo ''
echo ''

echo 'Q: 这个模块干嘛的呀？'
echo 'A: 本模块仅做自动挂载cgroup, 不提供墓碑/冻结功能'
echo ''
echo 'Q: 什么时候下需要？'
echo 'A: 在你正准备使用基于XPosed实现的墓碑后台实现, 却被判定为不支持v2/v1的时候'
echo ''
echo 'Q: 有什么要求？'
echo 'A: 你能看到这些提示，基本就可以认为是受支持的'
echo ''

echo '如果内核支持cgroup2, 模块会优先挂载至:'
echo '/sys/fs/cgroup/frozen 和 /sys/fs/cgroup/unfrozen'
echo '所有者设为system'
echo ''

echo '如果仅支持cgroup(v1), 则会挂载至:'
echo '/sys/fs/cgroup/freezer/perf/frozen 和'
echo '/sys/fs/cgroup/freezer/perf/thawed'
echo '所有者设为system'
echo ''


