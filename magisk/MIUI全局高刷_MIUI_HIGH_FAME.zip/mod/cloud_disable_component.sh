#!/system/bin/sh
#sqlite3下载地址
#脚本编写@coolapk 10007
#https://keytoolazy.coding.net/p/hms-core/d/HMS-CORE/git/raw/master/Sqlite3/Sqlite1.zip

export PATH="${0%/*}:/system/bin":$PATH

test "$(which -a sqlite3)" = "" && echo "请安装sqlite3！" && exit 1

function disable_joyose(){
sqlite3 "/data/data/com.xiaomi.joyose/databases/SmartP.db" << EOF
#update cloud_config set enable='0' where config_name='common_config';
#update cloud_config set enable='0' where config_name='booster_config';
update cloud_config set enable='0';
update cloud_config set version='2999122801';
#update cloud_config set params='';
EOF
pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver >/dev/null 2>&1
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService >/dev/null 2>&1
pm disable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService >/dev/null 2>&1
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver >/dev/null 2>&1
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver >/dev/null 2>&1
#resetprop persist.sys.sc_allow_conn false
}


function disable_power(){
sqlite3 "/data/data/com.miui.powerkeeper/databases/user_configure.db" << EOF
update misc set value='{"game":""}' where name='thermal_group';
EOF
pm disable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver >/dev/null 2>&1
pm disable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService >/dev/null 2>&1
#云控界面
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity >/dev/null 2>&1
#如果还锁帧的话，尝试禁用以下项
#来自酷安@果冻拌饭
#这个项会设置夜间睡眠杀后台打盹以及性能管理
#如果不需要你可以禁用
#pm disable com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService >/dev/null 2>&1
}

disable_joyose
disable_power

