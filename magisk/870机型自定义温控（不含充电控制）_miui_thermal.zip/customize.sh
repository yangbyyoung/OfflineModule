SKIPUNZIP=0
var_device="`getprop ro.board.platform`"
echo "当前平台型号为: $var_device "
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print "正在验证环境配置..."
 sleep 1s
  ui_print "正在安装.."
   ui_print "安装完成..."

