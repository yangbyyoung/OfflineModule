#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

install_magisk_busybox 2>/dev/null

id="$(echo "${0%/*}" | cut -d'/' -f5)"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}


function mod_table(){
target_file="$2"
target_script="$1"
cat << key > "$target_file"
*/$(show_value "间隔时间") $(show_value "开始时间")-$(show_value "结束时间") * * * $target_script
key
}

if test $(show_value "手动修改") == 否 ;then
	mod_table "$MODPATH/crond/steps.sh" "$MODPATH/crond/root"
else 
	echo "已选择手动修改！"
	exit 0
fi
