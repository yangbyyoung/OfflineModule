ui_print " "

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
ui_print " "

# sdk
NUM=23
if [ "$API" -lt $NUM ]; then
  ui_print "! Unsupported SDK $API."
  ui_print "  You have to upgrade your Android version"
  ui_print "  at least SDK API $NUM to use this module."
  abort
else
  ui_print "- SDK $API"
  ui_print " "
fi

# cleaning
ui_print "- Cleaning..."
APP="MiuiMusicGlobal com.miui.player"
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/system/package_cache -type f -name *$APPS*`
done
rm -f $MODPATH/LICENSE
ui_print " "

# library
LIB=miui-stat.jar
if ! pm list libraries | grep -Eq $LIB; then
  echo 'rm -rf /data/user/*/com.android.vending' > $MODPATH/cleaner.sh
  ui_print "- Play Store data will be cleared automatically on"
  ui_print "  next reboot for app updates."
  ui_print " "
fi




