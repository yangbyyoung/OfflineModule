#!/system/bin/sh
# 酷安@阿巴酱 (Petit-Abba)
# This file detects the version of the cloud file.
# If there is a discrepancy, the update will be downloaded and executed.
# It has been open source and can be safely used.It has been open source and can be safely used.
# Cloud Warehouse: https://gitee.com/Petit-Abba/wake-up/
CloudSh="202104121815"

MODDIR="$(dirname $(readlink -f "$0"))"

. $MODDIR/files/Variable.sh

Screen() { echo "$(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2)" ; }

PROCESS_a() { ps -ef | grep "Run_Wake_up.sh" | grep -v grep | wc -l ; }

Network_Connection() {
	if [[ $(ping -c 1 1.2.4.8) ]] >/dev/null 2>&1; then
		echo 0
	elif [[ $(ping -c 1 8.8.8.8) ]] >/dev/null 2>&1; then
		echo 0
	elif [[ $(ping -c 1 114.114.114.114) ]] >/dev/null 2>&1; then
		echo 0
	else
		echo 1
	fi
}

until [[ $(Screen) == false ]]; do
	sleep 3
done

until [[ $(Network_Connection) == 0 ]]; do
	sleep 5
done

cd $MODDIR

if [[ ! -z $(which curl) ]]; then
	curlwget="curl"
	until [[ -f $MODDIR/Wake-up.prop ]]; do
		curl -O 'https://gitee.com/Petit-Abba/wake-up/raw/master/Wake-up.prop' >/dev/null 2>&1
		sleep 2
	done
elif [[ ! -z $(which wget) ]]; then
	curlwget="wget"
	until [[ -f $MODDIR/Wake-up.prop ]]; do
		wget 'https://gitee.com/Petit-Abba/wake-up/raw/master/Wake-up.prop' >/dev/null 2>&1
		sleep 2
	done
fi

A=`cat $MODDIR/module.prop | grep 'VersionNumber=' | awk -F '=' '{print $2}'`
B=`. $MODDIR/Wake-up.prop && echo $VersionNumber`
C=`. $MODDIR/Wake-up.prop && echo $version`
D=`. $MODDIR/Wake-up.prop && echo $description`

if [[ "$A" -lt "$B" ]]; then
	[[ -f $MODDIR/Run_Wake_up.sh ]] && rm -rf $MODDIR/Run_Wake_up.sh

	until [[ -f $MODDIR/Run_Wake_up.sh ]]; do
		if [[ $curlwget == "curl" ]]; then
			curl -O 'https://gitee.com/Petit-Abba/wake-up/raw/master/Run_Wake_up.sh' >/dev/null 2>&1
		elif [[ $curlwget == "wget" ]]; then
			wget 'https://gitee.com/Petit-Abba/wake-up/raw/master/Run_Wake_up.sh' >/dev/null 2>&1
		fi
		sleep 3
	done

	chmod 0777 $MODDIR/Run_Wake_up.sh

	sed -i "/^version=/c version=$C" "$MODDIR/module.prop"
	sed -i "/^description=/c description=$D" "$MODDIR/module.prop"
	sed -i "/^VersionNumber=/c VersionNumber=$B" "$MODDIR/module.prop"
fi

[[ -f $MODDIR/Wake-up.prop ]] && rm -rf $MODDIR/Wake-up.prop

while :
do

	until [[ $(PROCESS_a) -ne 0 ]]; do
		nohup sh $MODDIR/Run_Wake_up.sh &
		sleep 1
	done

	[[ $(Screen) == false ]] && S="570" || S="240"

	sleep $S

done