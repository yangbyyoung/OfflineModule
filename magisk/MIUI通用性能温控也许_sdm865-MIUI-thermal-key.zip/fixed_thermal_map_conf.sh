#!/system/bin/sh

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

install_magisk_busybox 2>/dev/null

find $(magisk --path)/.magisk/mirror/vendor/etc -iname "thermal*map*.conf" -type f -o -iname "thermald*devices*.conf" -type f | while read file ;do
	cp -rf "${file}" "$MODPATH/system/vendor/etc/${file##*/}" && echo "已修复温控配置文件 [ ${file##*/} ]"
done
echo -e "\n∞————————————————————————∞\n"






