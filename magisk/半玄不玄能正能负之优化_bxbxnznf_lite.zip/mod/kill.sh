#!/system/bin/sh
MODDIR=${0%/*}
test ! -e $MODDIR/log && mkdir -p $MODDIR/log
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

sleep 5

am kill mdnsd
killall -9 mdnsd

am kill mdnsd.rc
killall -9 mdnsd.rc

cd $MODDIR/log
echo "$(date +%y年%m月%d日%H点%M分): 杀死进程mdnsd " >>kill.log
