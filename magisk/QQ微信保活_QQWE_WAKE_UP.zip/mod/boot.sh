QQservice="
com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService
com.tencent.mobileqq/com.tencent.mobileqq.app.CoreService
"
MMservice="
com.tencent.mm/com.tencent.mm.booter.CoreService
"
for i in $QQservice $MMservice;do
	am startservice -n $i
done


for i in com.tencent.mobileqq com.tencent.mm ;do
	pgrep -f "$i" | while read pid ;do
	echo -17 > /proc/$pid/oom_adj
done
dumpsys deviceidle whitelist +$i
done

