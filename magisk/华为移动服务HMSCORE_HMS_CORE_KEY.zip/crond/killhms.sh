#!/system/bin/sh
function topapp() {
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
	echo "$app"
}

function whitelist() {
	local file=$MODPATH/crond/游戏白名单.conf
	cat $file | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function qq_av() {
	possess="$(pgrep -f "com.tencent.mobileqq:video" | wc -l)"
	if test $possess -ge 1; then
		sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，QQ通话中，暂停所有活动。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
		exit 0
	fi
}

qq_av

function killall_hms_wakeup_pross() {
	test "$(topapp)" = "$1" && exit 0
	pgrep -f "$1" | while read pid; do
		test "$(cat /proc/$pid/cpuset)" = "/background" && {
			sleep $cleartime
			qq_av
			if test "$(echo "$(topapp)" | grep -E "$(whitelist)")" != "" -o "$(topapp)" = "$1"; then
				sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，进入白名单应用，暂停杀死应用"$1"。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
				exit 0
			fi
			kill -9 $pid && cleartime='1s'
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，杀死"$1"后台。杀死HMS 推送唤醒后台的应用名单在模块目录/crond/华为推送应用.conf，白名单(打游戏时暂停杀死)在模块目录/crond/游戏白名单.conf。" $MODPATH/module.prop
		} || continue
	done
}


if test -e $MODPATH/disable -o -e $MODPATH/remove; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

cat $MODPATH/crond/华为推送应用.conf | sed '/^#/d;/^[[:space:]]*$/d' | while read package; do
	killall_hms_wakeup_pross "$package"
done
