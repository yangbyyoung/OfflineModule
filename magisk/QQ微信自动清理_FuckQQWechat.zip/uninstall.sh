#!system/bin/sh
# 清理缓存
rm -rf /data/system/package_cache/*
