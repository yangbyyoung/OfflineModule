if [[ "$bootanimation_check" = "1" ]];then
for i in $MODPATH$bootpath;do
rm -rf $MODPATH/*.zip
[[ ! -e $i ]] && abort "- 动画文件丢失，请点击magisk manager 上面的保存按钮，查看出错日志。"
done
fi

if [[ "$bootanimation_check" = "2" ]];then
for i in $MODPATH$bootpath_dark;do
rm -rf $MODPATH/*.zip
[[ ! -e $i ]] && abort "- 动画文件丢失，请点击magisk manager 上面的保存按钮，查看出错日志。"
done
fi

[[  -e $MODPATH/*.zip ]] && abort "- !!! 我淦！您的开机动画不支持。" 