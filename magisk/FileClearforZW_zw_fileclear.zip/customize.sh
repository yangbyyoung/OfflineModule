##########################################################################################
#
# Magisk模块安装脚本
#
##########################################################################################
# 如果您需要更多的自定义，并且希望自己做所有事情
# 请在custom.sh中标注SKIPUNZIP=1
# 以跳过提取操作并应用默认权限/上下文上下文步骤。
# 请注意，这样做后，您的custom.sh将负责自行安装所有内容。
SKIPUNZIP=1
# 如果您需要调用Magisk内部的busybox，请在custom.sh中标注ASH_STANDALONE=1
ASH_STANDALONE=0
# 用户自设变量
# MIUI版本号
MIUI_VER=$(getprop ro.miui.ui.version.name)
sd0="/data/media/0"
test "$(echo /data/media/[0-9]*)" != "/data/media/0" && sd="/data/media/[0-9]*" || sd="/data/media/0"

# 用户(作者)自设可用变量(须待模块解压后执行):
user_variable() {
# 已安装模块路径
MODDIR=$(echo $MODPATH | sed "s/modules_update/modules/")
# 已安装模块版本号，整数型变量形式(一般用于比较新旧版本)
MODULE_OLD_VER_CODE=$(grep_prop versionCode $MODDIR/module.prop)
# 拟安装模块版本号(正在安装的模块)，整数型变量形式(一般用于比较新旧版本)
MODULE_NEW_VER_CODE=$(grep_prop versionCode $MODPATH/module.prop)
# 自定义find、xargs等命令
command_list='
find
xargs
'
for command_temp_1 in $command_list;do
  command_temp_2=$(find $MODPATH -type f -iname "$command_temp_1" 2>/dev/null)
  if [[ -f $command_temp_2 ]];then
    chmod 775 $command_temp_2 2>/dev/null
    alias $command_temp_1="$command_temp_2"
  fi
done
}

####################################
# 安装
####################################
ui_print "

    #######################################
                FileClear for ZW
                    乐阿兰那
    #######################################
       一个基于MIUI的面具模块。旨在通过执行Shell脚
    本(Linux命令)清理微信、微博、QQ等APP缓存和垃圾
    文件，并屏蔽ad、.um、.uuid、MiPush、log等毒瘤
    和腾讯X5内核。与其他同类软件相比，具有不安装App、
    清理范围大、清理类型多、清理更彻底且自动化的优点
            **************************
    不是安装后立即生效，不是每次重启就清理垃圾！！！
    每隔N天，在特定时间点(比如凌晨5点)自动执行清理
    操作，并自动重起手机，动调用MIUI官方清理APP！！
    需要用户自己手动点击“清理选中垃圾”按钮！！！！
    日志文件保存于SD卡根目录“FileClear_zw_*.txt”。
            **************************
    这是免费模块，用爱发电的！遇到Bug，请自己排查、
    修复！如自愿协助作者修复Bug，请说清楚ROM情况，
    出问题的APP情况，问题怀疑对象等，不要只说现象！
            **************************
     这是我小米手机官方ROM自用脚本，不适配第三方！
     使用前务必认真根据自己实情修改脚本！！！！！
            **************************
    【提醒】模块安装过程中将检测手机是否已经进行了破
    解卡米操作，需要耗时1~3分钟！！！未破解卡米的手
    机不适合使用本模块，强制使用可能导致变砖！
    #######################################

"
# 安装(解压)前准备工作
stop_install() {
test $BOOTMODE && { touch disable $MODDIR;ui_print "-   【提醒】检测到安装有旧版模块，已禁用！";}
abort "-   模块安装程序终止"
}
# 搜索删除非本模块的startclear.sh、startclear_service.sh文件
find /data/adb -type f -iname "j2.sh" -exec rm -f {} \; &>/dev/null
find /data/adb -type f -iname "startclear*.sh" -exec rm -f {} \; &>/dev/null

# 解压模块；将 $ZIPFILE 提取到 $MODPATH
ui_print "-   开始解压模块文件"
unzip -qo "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
# 执行用户(作者)自设可用变量、命令
user_variable

# 检测是否已破解卡米
ui_print "-   开始检测手机是否已经进行了破解卡米操作，耗时1~3分钟！"
test -z "$(which dexdump)" &&  { ui_print "-   没有dexdump命令，无法解包classes*.dex文件";stop_install;}
services_path=$(find / -type f -iname "services.jar" 2>/dev/null)
test -z "$services_path" && { ui_print "-   没有services.jar文件，无法检测是否已经破解卡米";stop_install;}
services_size=$(/system/bin/ls -l /system/framework/services.jar | cut -f5 -d ' ')
test "$services_size" -le "4000000" && { ui_print "-   services.jar小于4MB，未合并odex";stop_install;}
unzip -qo "$services_path" classes.dex classes2.dex -d $TMPDIR >&2
jckm_1=$(dexdump -d $TMPDIR/classes*.dex | grep -f $MODPATH/jckm.txt | wc -l)
test "$jckm_1" -ge "1" &&  { ui_print "-   没有事先破解卡米，模块不适用！！！";stop_install;} ||
ui_print "-   恭喜！！已实现破解卡米，模块适用！"

# 编辑相关文件
[[ $? == "0" ]] && ui_print "-   开始编辑j11.sh文件"
sed -i '/^# / d' $MODPATH/j11.sh
sed -i '3i\magisk_path=\$(magisk --path)\/.magisk\/busybox' $MODPATH/j11.sh
sed -i '4i\export PATH=\/system\/bin:\$magisk_path:$PATH' $MODPATH/j11.sh
# 对SD卡中旧日志文件进行处理
nowtime=$(date +"%m-%d_%T")
endtime=$(date +%s)
unset FileClear_logname
find $sd -iname "FileClear_zw_*.txt" \( -atime +2 -o -mtime +2 \) -delete &>/dev/null
FileClear_logname=FileClear_zw_$nowtime.txt
sed -i "s/^FileClear_logname.*/FileClear_logname=$FileClear_logname/g" $MODPATH/service.sh && ui_print "-   修改service.sh中日志文件名称变量成功！"
sed -i "s/^Runj11time.*/Runj11time=$endtime/g" $MODPATH/service.sh && ui_print "-   修改service.sh中上次执行时间变量成功！"

# 修复旧版本中Bug
if [[ $BOOTMODE && $MODULE_OLD_VER -le "20211209" ]];then
# 删除所有0字节文件
find /data/data /data/media /data/user_de -type f -size 0 -perm 000 2>/dev/null|xargs -I find_file_2 sh -c "chattr -i \"find_file_2\" 2>/dev/null;rm -f \"find_file_2\" 2>/dev/null"
# 修复旧版本错误创建的*号文件夹
rm -rf '/data/media/*' 2>/dev/null
fi

#################################
# 权限设置
#################################
# 对于目录(包括文件):
# set_perm_recursive  <目录>    <所有者> <用户组> <目录权限> <文件权限>
# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system 0 0 0775 0755
set_perm_recursive $MODPATH/system/bin 0 0 0775 0755
# 对于文件(不包括文件所在目录)
# set_perm  <文件名>            <所有者> <用户组> <文件权限>
chmod -R 775 $MODPATH
[[ ! -x $MODPATH/system/bin/xargs ]] && ui_print "-   system/bin文件夹授权失败"

#################################
# 删除多余文件
#################################
rm -rf $MODPATH/customize.sh $MODPATH/*.md $MODPATH/jckm.txt 2>/dev/null