#!/system/bin/sh

# Wait till device boot process complets
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done
sleep 3

# mount YouTube ReVanced with official YouTube
PK_Path=$(pm path com.google.android.youtube | cut -d ":" -f2- | grep "base.apk")
BASE_Path="/data/adb/modules/Revanced_Extended/revanced/base.apk"

chcon u:object_r:apk_data_file:s0 $BASE_Path
MAGISKTMP="$(magisk --path)"
[ -z "$MAGISKTMP" ] && MAGISKTMP=/sbin
mount -o bind $MAGISKTMP/.magisk/mirror$BASE_Path $PK_Path
