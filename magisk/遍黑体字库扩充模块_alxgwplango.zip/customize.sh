#模块内容全部进magisk系统=0
#更多自定义=1
SKIPUNZIP=0
