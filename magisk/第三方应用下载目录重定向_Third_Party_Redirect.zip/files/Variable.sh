#!/system/bin/sh
#202104010
#Petit-Abba
#Environment Variables

# The system's busybox is more comfortable.
PATH="/system/bin"
# Executable Binary File Location.
