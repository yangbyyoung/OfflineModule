#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

TARGET_PATH=""
TARGET_PATH_LIST="
/vendor/etc
/product/etc
"

for path in $TARGET_PATH_LIST; do

  if [[ -d $path/device_features/ ]]; then
    TARGET_PATH=$path
  fi

done

if [ "$TARGET_PATH" == "" ]; then
  ui_print "- Error This device does not support"
  exit
fi

MOD_DF_PATH=$MODDIR/system/$TARGET_PATH/device_features

mkdir -p $MOD_DF_PATH

rm $MOD_DF_PATH/*

cp -f $TARGET_PATH/device_features/* $MOD_DF_PATH/

sed -i 's/<bool name="support_ota_validate">true<\/bool>/<bool name="support_ota_validate">false<\/bool>/g' $MOD_DF_PATH/*
ui_print "- Replace key support_ota_validate true to falsse"

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
