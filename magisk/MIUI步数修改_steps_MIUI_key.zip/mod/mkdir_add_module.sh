#!/system/bin/sh
id="steps_MIUI_key_add"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

mkdir -p "$MODPATH"

cat << key > "$MODPATH/module.prop"
id=steps_MIUI_key
name=MIUI步数修改附加模块
version=v1
versionCode=1
author=@coolapk 10007
description=手动停用该模块，可以暂停步数模块运行！
key

cat << "key" > "$MODPATH/service.sh"
#!/system/bin/sh
id="steps_MIUI_key_add"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
test ! -d "${MODPATH%/*}/steps_MIUI_key" && rm -rf "$MODPATH"
key

chmod -R 0777 "$MODPATH"

