#!/system/bin/bash
# 将此脚本放到/data/adb/modules/*

# 0、初始变量、命令别名设置
export MODDIR=$(cd "$(dirname "${BASH_SOURCE-$0}")";pwd)
export sd0="/data/media/0"
test "$(echo /data/media/[0-9]*)" != "/data/media/0" && export sd="/data/media/[0-9]*" || export sd="$sd0"
test -x /system/bin/am && alias am='/system/bin/am'
test -x /system/bin/pm && alias pm='/system/bin/pm'

# 1、crond相关设置
crondfileclear_path="/data/adb/modules/zw_fileclear"
#crondservicecomb_path="/data/adb/modules/zw_crondservicecomb"
# 设置命令别名
test_crond=$($(magisk --path)/.magisk/busybox/crond --help &>/dev/null;echo $?)
if [[ $test_crond != "0" ]];then
  for crond_command in $(find / -type f -name "crond" 2>/dev/null);do
    $crond_command --help &>/dev/null
    [[ $? == "0" ]] && { alias crond="$crond_command";break;}
  done
  unset crond_command
else
  alias crond="$(magisk --path)/.magisk/busybox/crond"
fi

# 清理腾讯系垃圾文件夹
clear_tencent_dir() {
sd_tencent=([Tt]encent/.emotionsm\
 [Tt]encent/.font_info\
 [Tt]encent/.gift\
 [Tt]encent/.hiboom_font\
 [Tt]encent/.pendant\
 [Tt]encent/.profilecard\
 [Tt]encent/.sticker_recommended_pics\
 [Tt]encent/.trooprm/enter_effects\
 [Tt]encent/.vaspoke\
 [Tt]encent/.vipicon\
 [Tt]encent/[Qq][Qq]_cameraemo\
 [Tt]encent/[Qq][Qq]_collection/pic\
 [Tt]encent/[Qq][Qq]_favorite\
 [Tt]encent/[Qq][Qq]_Images/qqeditpic\
 [Tt]encent/[Qq][Qq]file_recv\
 [Tt]encent/[Tt]im/shortvideo\
 [Tt]encent/beacon\
 [Tt]encent/blob\
 [Tt]encent/com\
 [Tt]encent/DoutuRes\
 [Tt]encent/funcall\
 [Tt]encent/MicroMsg/*/bizimg\
 [Tt]encent/MicroMsg/*/favoffline\
 [Tt]encent/MicroMsg/*/favorite\
 [Tt]encent/MicroMsg/*/image\
 [Tt]encent/MicroMsg/*/image[0-9]\
 [Tt]encent/MicroMsg/*/oneday\
 [Tt]encent/MicroMsg/*/recbiz\
 [Tt]encent/MicroMsg/bigfile\
 [Tt]encent/MicroMsg/browser\
 [Tt]encent/MicroMsg/CheckResUpdate\
 [Tt]encent/MicroMsg/sns_ad_landingpages\
 [Tt]encent/MicroMsg/vusericon\
 [Tt]encent/MicroMsg/wallet_images\
 [Tt]encent/MicroMsg/wxafiles/[a-z][a-z]*\
 [Tt]encent/mini\
 [Tt]encent/MobileQQ\
 [Tt]encent/MobileQQ/.apollo\
 [Tt]encent/MobileQQ/.corlornick\
 [Tt]encent/MobileQQ/.emotionsm\
 [Tt]encent/MobileQQ/.font_effect\
 [Tt]encent/MobileQQ/.font_info\
 [Tt]encent/MobileQQ/.fontbubble\
 [Tt]encent/MobileQQ/.gift\
 [Tt]encent/MobileQQ/.hiboom_font\
 [Tt]encent/MobileQQ/.now_video\
 [Tt]encent/MobileQQ/.pendant\
 [Tt]encent/MobileQQ/.readInjoy\
 [Tt]encent/MobileQQ/.signaturetemplate\
 [Tt]encent/MobileQQ/.troop\
 [Tt]encent/MobileQQ/.vipicon\
 [Tt]encent/MobileQQ/[Qq]_Images\
 [Tt]encent/MobileQQ/[Qq]EditPic\
 [Tt]encent/MobileQQ/[Tt]encent/Mobileqq/webso\
 [Tt]encent/MobileQQ/aio_long_shot\
 [Tt]encent/MobileQQ/appicon\
 [Tt]encent/MobileQQ/ar_feature\
 [Tt]encent/MobileQQ/ar_model\
 [Tt]encent/MobileQQ/artfilter\
 [Tt]encent/MobileQQ/avatarpendantdefaulthead\
 [Tt]encent/MobileQQ/avatarpendanticons\
 [Tt]encent/MobileQQ/bless\
 [Tt]encent/MobileQQ/bubble_info\
 [Tt]encent/MobileQQ/capture_ptv_template\
 [Tt]encent/MobileQQ/capture_qsvf\
 [Tt]encent/MobileQQ/card\
 [Tt]encent/MobileQQ/chatpic\
 [Tt]encent/MobileQQ/doodle_template\
 [Tt]encent/MobileQQ/doutures\
 [Tt]encent/MobileQQ/dov_doodle_music\
 [Tt]encent/MobileQQ/dov_doodle_sticker\
 [Tt]encent/MobileQQ/dov_doodle_template\
 [Tt]encent/MobileQQ/dov_ptv_template_dov\
 [Tt]encent/MobileQQ/dynamic_text\
 [Tt]encent/MobileQQ/flashchat\
 [Tt]encent/MobileQQ/foward_urldrawable\
 [Tt]encent/MobileQQ/funcall\
 [Tt]encent/MobileQQ/head/_dynamic\
 [Tt]encent/MobileQQ/head/_hd\
 [Tt]encent/MobileQQ/head/_SSOhd\
 [Tt]encent/MobileQQ/head/_st\
 [Tt]encent/MobileQQ/head/_stranger\
 [Tt]encent/MobileQQ/hotimage\
 [Tt]encent/MobileQQ/hotpic\
 [Tt]encent/MobileQQ/iar\
 [Tt]encent/MobileQQ/information_paster\
 [Tt]encent/MobileQQ/keyword_emotion\
 [Tt]encent/MobileQQ/listentogether\
 [Tt]encent/MobileQQ/lottie\
 [Tt]encent/MobileQQ/ocr\
 [Tt]encent/MobileQQ/pddata\
 [Tt]encent/MobileQQ/photo\
 [Tt]encent/MobileQQ/play_show_apng\
 [Tt]encent/MobileQQ/portrait\
 [Tt]encent/MobileQQ/ppt\
 [Tt]encent/MobileQQ/pubaccount\
 [Tt]encent/MobileQQ/qav\
 [Tt]encent/MobileQQ/qbiz\
 [Tt]encent/MobileQQ/qbosssplahad\
 [Tt]encent/MobileQQ/qqcomic\
 [Tt]encent/MobileQQ/qqconnect\
 [Tt]encent/MobileQQ/qqmusic\
 [Tt]encent/MobileQQ/qqstory\
 [Tt]encent/MobileQQ/rijmmkv\
 [Tt]encent/MobileQQ/scribble\
 [Tt]encent/MobileQQ/shortvideo\
 [Tt]encent/MobileQQ/status_ic\
 [Tt]encent/MobileQQ/sticker_recommended_pics\
 [Tt]encent/MobileQQ/subscribe_draft\
 [Tt]encent/MobileQQ/subscribe_draft_simple\
 [Tt]encent/MobileQQ/sv_config_resource\
 [Tt]encent/MobileQQ/thumb\
 [Tt]encent/MobileQQ/thumb[0-9]\
 [Tt]encent/MobileQQ/vas\
 [Tt]encent/MobileQQ/video_story\
 [Tt]encent/MobileQQ/viola\
 [Tt]encent/MobileQQ/voicechange\
 [Tt]encent/MobileQQ/webviewcheck\
 [Tt]encent/MobileQQ/zhitu\
 [Tt]encent/mta\
 [Tt]encent/newpoke\
 [Tt]encent/poke\
 [Tt]encent/qqhomework_attach\
 [Tt]encent/qqhomework_recv\
 [Tt]encent/QQLite/.emotionsm\
 [Tt]encent/QQLite/ArkApp\
 [Tt]encent/QQLite/data\
 [Tt]encent/QQLite/early\
 [Tt]encent/qzone\
 [Tt]encent/readerzone\
 [Tt]encent/TMAssistantSDK\
 [Tt]encent/vs\
 [Tt]encent/WeiXin/*/image[0-9]\
 [Tt]encent/WeiXin/bigfile\
 [Tt]encent/WeiXin/sns_ad_landingpages\
 [Tt]encent/wtlogin\
 [Tt]encentmapsdk)
sd_data_tencent=(com.taobao.idlefish/image\
 com.taobao.taobao/files/acds\
 com.taobao.taobao/files/amapcn\
 com.taobao.taobao/files/AsyncPublishDraft\
 com.taobao.taobao/files/downloads\
 com.taobao.taobao/files/persistent_store\
 com.tencent.mm/beacon\
 com.tencent.mm/blob\
 com.tencent.mm/cache\
 com.tencent.mm/com\
 com.tencent.mm/files\
 com.tencent.mm/MicroMsg/*/attachment\
 com.tencent.mm/MicroMsg/*/bizimg\
 com.tencent.mm/MicroMsg/*/emoji\
 com.tencent.mm/MicroMsg/*/favoffline\
 com.tencent.mm/MicroMsg/*/favorite\
 com.tencent.mm/MicroMsg/*/finder\
 com.tencent.mm/MicroMsg/*/image\
 com.tencent.mm/MicroMsg/*/image[0-9]\
 com.tencent.mm/MicroMsg/*/mailapp\
 com.tencent.mm/MicroMsg/*/music/cover/mv_default_video\
 com.tencent.mm/MicroMsg/*/oneday/coming\
 com.tencent.mm/MicroMsg/*/oneday/pic\
 com.tencent.mm/MicroMsg/*/oneday/temp\
 com.tencent.mm/MicroMsg/*/oneday/video\
 com.tencent.mm/MicroMsg/*/openapi\
 com.tencent.mm/MicroMsg/*/openim\
 com.tencent.mm/MicroMsg/*/recbiz\
 com.tencent.mm/MicroMsg/*/record\
 com.tencent.mm/MicroMsg/*/taskbar\
 com.tencent.mm/MicroMsg/*/textstatus\
 com.tencent.mm/MicroMsg/.tmp\
 com.tencent.mm/MicroMsg/[Dd]ownload/appbrand\
 com.tencent.mm/MicroMsg/bigfile\
 com.tencent.mm/MicroMsg/browser\
 com.tencent.mm/MicroMsg/card/video\
 com.tencent.mm/MicroMsg/CDNTemp\
 com.tencent.mm/MicroMsg/CheckResUpdate\
 com.tencent.mm/MicroMsg/crash\
 com.tencent.mm/MicroMsg/Download/temp_share_img[0-9]\
 com.tencent.mm/MicroMsg/facedir\
 com.tencent.mm/MicroMsg/fts\
 com.tencent.mm/MicroMsg/Game\
 com.tencent.mm/MicroMsg/mapsdk\
 com.tencent.mm/MicroMsg/mapsdk/[Tt]encentmapsdk/com.tencent.mm/data/v[0-9]/render/events/icons/\
 com.tencent.mm/MicroMsg/recovery/version.info\
 com.tencent.mm/MicroMsg/sns_ad_landingpages\
 com.tencent.mm/MicroMsg/vusericon\
 com.tencent.mm/MicroMsg/wallet\
 com.tencent.mm/MicroMsg/wallet_images\
 com.tencent.mm/MicroMsg/wxacache\
 com.tencent.mm/MicroMsg/wxafiles\
 com.tencent.mm/MicroMsg/wxanewfiles\
 com.tencent.mm/MobileQQ/doutures\
 com.tencent.mm/MobileQQ/subscribe_draft\
 com.tencent.mm/MobileQQ/subscribe_draft_simple\
 com.tencent.mm/mta\
 com.tencent.mm/QQfile_recv\
 com.tencent.mm/vs\
 com.tencent.mobileqq/[Tt]encent/beacon\
 com.tencent.mobileqq/[Tt]encent/blob\
 com.tencent.mobileqq/[Tt]encent/com\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/bizimg\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/favoffline\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/favorite\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/image\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/image[0-9]\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/oneday\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/*/recbiz\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/bigfile\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/CheckResUpdate\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/sns_ad_landingpages\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/vusericon\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/wallet_images\
 com.tencent.mobileqq/[Tt]encent/MicroMsg/wxafiles/[a-z][a-z]*\
 com.tencent.mobileqq/[Tt]encent/mini\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.apollo/rsc_jsonconfig\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.corlornick\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.emotionsm\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.font_effect\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.font_info\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.fontbubble\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.gift\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.hiboom_font\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.now_video\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.pendant\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.readInjoy\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.signaturetemplate\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.troop\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/.vipicon\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/aio_long_shot\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/appicon\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/ar_feature\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/ar_model\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/artfilter\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/avatarpendantdefaulthead\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/avatarpendanticons\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/bless\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/bubble_info\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/capture_ptv_template\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/capture_qsvf\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/card\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/chatpic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/com.tencent.mobileqq/[Tt]encent/Mobileqq/webso\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/doodle_template\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/doutures\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/dov_doodle_music\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/dov_doodle_sticker\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/dov_doodle_template\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/dov_ptv_template_dov\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/dynamic_text\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/flashchat\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/foward_urldrawable\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/funcall\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/head/_dynamic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/head/_hd\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/head/_SSOhd\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/head/_st\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/head/_stranger\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/hotimage\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/hotpic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/iar\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/information_paster\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/keyword_emotion\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/listentogether\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/lottie\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/ocr\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/pddata\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/photo\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/play_show_apng\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/portrait\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/ppt\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/pubaccount\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qav\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qbiz\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qbosssplahad\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/QQ_Images\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qqcomic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qqconnect\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/QQEditPic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qqmusic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/qqstory\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/rijmmkv\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/scribble\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/shortvideo\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/status_ic\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/sticker_recommended_pics\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/subscribe_draft\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/subscribe_draft_simple\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/sv_config_resource\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/thumb\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/thumb2\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/vas\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/video_story\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/viola\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/voicechange\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/webviewcheck\
 com.tencent.mobileqq/[Tt]encent/MobileQQ/zhitu\
 com.tencent.mobileqq/[Tt]encent/mta\
 com.tencent.mobileqq/[Tt]encent/QQ_cameraemo\
 com.tencent.mobileqq/[Tt]encent/QQ_collection/pic\
 com.tencent.mobileqq/[Tt]encent/QQ_favorite\
 com.tencent.mobileqq/[Tt]encent/QQ_Images/qqeditpic\
 com.tencent.mobileqq/[Tt]encent/qqhomework_attach\
 com.tencent.mobileqq/[Tt]encent/qqhomework_recv\
 com.tencent.mobileqq/[Tt]encent/QQLite/.emotionsm\
 com.tencent.mobileqq/[Tt]encent/QQLite/ArkApp\
 com.tencent.mobileqq/[Tt]encent/qzone\
 com.tencent.mobileqq/[Tt]encent/readerzone\
 com.tencent.mobileqq/[Tt]encent/vs\
 com.tencent.mobileqq/[Tt]encent/WeiXin/*/image[0-9]\
 com.tencent.mobileqq/[Tt]encent/WeiXin/bigfile\
 com.tencent.mobileqq/[Tt]encent/WeiXin/sns_ad_landingpages\
 com.tencent.mobileqq/[Tt]encent/wtlogin\
 com.tencent.mobileqq/files/ae\
 com.tencent.mobileqq/files/qwallet/.preloaduni\
 com.tencent.mobileqq/qzlive\
 com.tencent.mobileqq/qzone/imageV[0-9]\
 com.tencent.qqmusic/files/qqmusic/.assist\
 com.tencent.qqmusic/files/qqmusic/eup\
 com.tencent.qqmusic/files/qqmusic/firstpiece\
 com.tencent.qqmusic/files/qqmusic/gift_anim_zip\
 com.tencent.qqmusic/files/qqmusic/landscape\
 com.tencent.qqmusic/files/qqmusic/machine-learning-download\
 com.tencent.qqmusic/files/qqmusic/moments\
 com.tencent.qqmusic/files/qqmusic/network\
 com.tencent.qqmusic/files/qqmusic/qrc\
 com.tencent.qqmusic/files/qqmusic/rsconfig_res\
 com.tencent.qqmusic/files/qqmusic/splash\
 com.tencent.qqmusic/files/qqmusic/supersound/effects/resae\
 com.tencent.qqmusic/files/qqmusic/ubc\
 com.tencent.qqmusic/files/qqmusic/vip_center\
 com.tencent.xriver/files/tencent\
 com.tencent.xriver/sdcard)
data_tencent=(com.taobao.idlefish/files/awcn_strategy\
 com.taobao.movie.android/files/pictures\
 com.taobao.movie.android/plugins\
 com.taobao.qianniu/files/carrierdata\
 com.taobao.qianniu/files/download\
 com.taobao.qianniu/files/emoticon\
 com.taobao.taobao/app_ucmsdk/decompresses[0-9]/*\
 com.taobao.taobao/chatphoto\
 com.taobao.taobao/com.taobao.taobao/.fg\
 com.taobao.taobao/com.taobao.taobao/update_cache\
 com.taobao.taobao/com.taobao.taobao/webview\
 com.taobao.taobao/downloadsdk\
 com.taobao.taobao/files/acds\
 com.taobao.taobao/files/atlas-debug\
 com.taobao.taobao/files/awcn_strategy\
 com.taobao.taobao/files/carrierdata\
 com.taobao.taobao/files/chatphoto\
 com.taobao.taobao/files/download\
 com.taobao.taobao/files/downloads\
 com.taobao.taobao/files/expression\
 com.taobao.taobao/files/festival\
 com.taobao.taobao/files/ju\
 com.taobao.taobao/files/magic_mirror\
 com.taobao.taobao/files/orange_config_content\
 com.taobao.taobao/files/persistent_store\
 com.taobao.taobao/files/photo\
 com.taobao.taobao/files/pictures\
 com.taobao.taobao/files/pigeon\
 com.taobao.taobao/files/puti\
 com.taobao.taobao/files/ranger\
 com.taobao.taobao/files/tnetlogs\
 com.taobao.taobao/files/图片\
 com.taobao.taobao/files/下载\
 com.taobao.taobao/hybridwebview\
 com.taobao.taobao/orange_config\
 com.taobao.taobao/persistent_store\
 com.taobao.taobao/plugins\
 com.taobao.taobao/taobao\
 com.taobao.taobao/taoupdate\
 com.taobao.taobao/viewdata\
 com.taobao.taobao/wwresourcecache\
 com.taobao.trip/.back\
 com.taobao.trip/files/carrierdata\
 com.taobao.trip/files/cv[0-9]\
 com.taobao.trip/files/download/tmp_extract\
 com.taobao.trip/files/update_needed_dir/cv[0-9]\
 com.taobao.trip/files/upgrade_app\
 com.tencent.game.ssgame/assets/crashscreenshoot\
 com.tencent.game.ssgame/assets/imagecache\
 com.tencent.game.ssgame/assets/pic\
 com.tencent.game.vxdgame/files/documents\
 com.tencent.game.vxdgame/files/download\
 com.tencent.game.vxdgame/files/library/documents\
 com.tencent.game.vxdgame/files/library/iipsfiledir\
 com.tencent.game.vxdgame/files/library/versionlist\
 com.tencent.game.vxdgame/files/res\
 com.tencent.gamejoy/files/download\
 com.tencent.karaoke/files/chorus\
 com.tencent.karaoke/files/chorus_config\
 com.tencent.karaoke/files/chorus_scene\
 com.tencent.karaoke/files/downloadapk\
 com.tencent.karaoke/files/hash\
 com.tencent.karaoke/files/hum\
 com.tencent.karaoke/files/info\
 com.tencent.karaoke/files/localsong\
 com.tencent.karaoke/files/mipushlog\
 com.tencent.karaoke/files/mv\
 com.tencent.karaoke/files/mvcover\
 com.tencent.karaoke/files/note\
 com.tencent.karaoke/files/obbligato\
 com.tencent.karaoke/files/pcm\
 com.tencent.karaoke/files/practice\
 com.tencent.karaoke/files/qrc\
 com.tencent.karaoke/files/speedmeasure\
 com.tencent.karaoke/files/splash\
 com.tencent.karaoke/files/uploader\
 com.tencent.karaoke/files/videocache\
 com.tencent.map/files/sosomap/data/bus\
 com.tencent.map/files/sosomap/data/cfg\
 com.tencent.map/files/sosomap/data/download/citydata\
 com.tencent.map/files/sosomap/data/file_download\
 com.tencent.map/files/sosomap/data/plugin_dl\
 com.tencent.map/files/sosomap/data/radio\
 com.tencent.map/files/sosomap/data/route\
 com.tencent.map/files/sosomap/data/route_download\
 com.tencent.map/files/sosomap/data/v[0-9]\
 com.tencent.map/files/sosomap/data/worldmapdownload\
 com.tencent.map/files/sosomap/nav\
 com.tencent.map/files/sosomap/nav/zip\
 com.tencent.minihd.qq/ache/http\
 com.tencent.minihd.qq/ache/thumbnails\
 com.tencent.minihd.qq/bg/custom\
 com.tencent.minihd.qq/image\
 com.tencent.minihd.qq/imagetemp\
 com.tencent.minihd.qq/qq\
 com.tencent.minihd.qq/qzone\
 com.tencent.minihd.qq/wblog_head\
 com.tencent.mm/app_appcache\
 com.tencent.mm/app_databases\
 com.tencent.mm/app_font\
 com.tencent.mm/app_geolocation\
 com.tencent.mm/app_recovery_lib\
 com.tencent.mm/app_ringtone\
 com.tencent.mm/app_textures\
 com.tencent.mm/app_webview_com_tencent_mm\
 com.tencent.mm/app_webview_com_tencent_mm_appbrand*\
 com.tencent.mm/app_webview_com_tencent_mm_support\
 com.tencent.mm/app_webview_com_tencent_mm_tools*\
 com.tencent.mm/app_wv_reserved_space_shinker\
 com.tencent.mm/app_xwalkconfig\
 com.tencent.mm/face_detect\
 com.tencent.mm/files/anr\
 com.tencent.mm/files/crash\
 com.tencent.mm/files/dexopt_service\
 com.tencent.mm/files/host\
 com.tencent.mm/files/kvcomm\
 com.tencent.mm/files/liteapp\
 com.tencent.mm/files/mrs\
 com.tencent.mm/files/public/box\
 com.tencent.mm/files/public/CheckResUpdate\
 com.tencent.mm/files/public/cityService\
 com.tencent.mm/files/public/emoji/res\
 com.tencent.mm/files/public/fts\
 com.tencent.mm/files/public/live\
 com.tencent.mm/files/public/ocr\
 com.tencent.mm/files/public/tagsearch\
 com.tencent.mm/files/public/websearch\
 com.tencent.mm/files/TencentLocation_sapp\
 com.tencent.mm/files/tencentMapSdk\
 com.tencent.mm/files/webnet\
 com.tencent.mm/files/word_detect\
 com.tencent.mm/files/wx[0-9]*/*.apk\
 com.tencent.mm/files/WxAudioLib\
 com.tencent.mm/files/wxofflinevoicenew\
 com.tencent.mm/MicroMsg/*/appbrand\
 com.tencent.mm/MicroMsg/*/avatar\
 com.tencent.mm/MicroMsg/*/cdn\
 com.tencent.mm/MicroMsg/*/cdndnsinfo\
 com.tencent.mm/MicroMsg/*/favorite/music\
 com.tencent.mm/MicroMsg/*/favorite/voice\
 com.tencent.mm/MicroMsg/*/favorite/web\
 com.tencent.mm/MicroMsg/*/finderposting/media_tmp\
 com.tencent.mm/MicroMsg/*/finderposting/posting\
 com.tencent.mm/MicroMsg/*/game\
 com.tencent.mm/MicroMsg/*/normsg\
 com.tencent.mm/MicroMsg/*/patmsg\
 com.tencent.mm/MicroMsg/*/pushSyncResp\
 com.tencent.mm/MicroMsg/*/secdata\
 com.tencent.mm/MicroMsg/*/talkroom\
 com.tencent.mm/MicroMsg/*/trackroom\
 com.tencent.mm/MicroMsg/CheckResUpdate\
 com.tencent.mm/MicroMsg/ClickFlow\
 com.tencent.mm/MicroMsg/CronetCache\
 com.tencent.mm/MicroMsg/luckymoney\
 com.tencent.mm/MicroMsg/mmslot/webcached\
 com.tencent.mm/MicroMsg/ProcessDetector\
 com.tencent.mm/MicroMsg/recovery\
 com.tencent.mm/MicroMsg/regioncode\
 com.tencent.mm/MicroMsg/tmp\
 com.tencent.mm/MicroMsg/webcompt\
 com.tencent.mm/MicroMsg/webservice\
 com.tencent.mm/MicroMsg/webview_tmpl/tmpls\
 com.tencent.mm/no_backup\
 com.tencent.mm/oat/arm/*\
 com.tencent.mm/oat/arm64/*\
 com.tencent.mm/scan_goods\
 com.tencent.mm/smcert\
 com.tencent.mobileqq/[Tt]encent/qqfile_recv\
 com.tencent.mobileqq/app_theme_[0-9][0-9]*\
 com.tencent.mobileqq/app_webview_com.tencent.mobileqq:mini_internal*\
 com.tencent.mobileqq/app_webview_tool*\
 com.tencent.mobileqq/baodownload\
 com.tencent.mobileqq/files/ArkApp\
 com.tencent.mobileqq/files/crashinfo\
 com.tencent.mobileqq/files/maxvideo\
 com.tencent.mobileqq/files/mini\
 com.tencent.mobileqq/files/minigame\
 com.tencent.mobileqq/files/newComeCard\
 com.tencent.mobileqq/files/Shadowplugin_channel\
 com.tencent.mobileqq/files/Shadowplugin_core\
 com.tencent.mobileqq/files/Shadowplugin_misc\
 com.tencent.mobileqq/files/ShadowPluginManager\
 com.tencent.mobileqq/files/uploader\
 com.tencent.mobileqq/files/videocache\
 com.tencent.mobileqq/qq/video\
 com.tencent.mobileqq/qzone/avatar\
 com.tencent.mobileqq/qzone/message_board\
 com.tencent.mobileqq/qzone/mnt\
 com.tencent.mobileqq/qzone/sdcard\
 com.tencent.mobileqq/qzone/storage\
 com.tencent.mobileqq/qzone/video\
 com.tencent.mobileqq/shadowplugin_av\
 com.tencent.mobileqq/shadowplugin_base\
 com.tencent.mobileqq/shadowplugin_channel\
 com.tencent.mobileqq/shadowplugin_core\
 com.tencent.mobileqq/shadowplugin_misc\
 com.tencent.mobileqq/shadowplugin_odroom\
 com.tencent.mobileqq/shadowplugin_roombiz\
 com.tencent.mobileqq/shadowplugin_roomimport\
 com.tencent.mobileqq/shadowplugin_usercenter\
 com.tencent.mtt/serial\
 com.tencent.news/files/.omgid/dirs\
 com.tencent.news/files/cell\
 com.tencent.news/files/data\
 com.tencent.news/files/dolf\
 com.tencent.news/files/extended\
 com.tencent.news/files/favor/detail\
 com.tencent.news/files/market\
 com.tencent.news/files/newslog\
 com.tencent.news/files/onlinelog\
 com.tencent.news/files/onlinelog4ad\
 com.tencent.news/files/onlinelog4video\
 com.tencent.news/files/reader/.offline\
 com.tencent.news/files/reader/[0-9]\
 com.tencent.news/files/reader/adv\
 com.tencent.news/files/reader/cover\
 com.tencent.news/files/reader/default\
 com.tencent.news/files/reader/download\
 com.tencent.news/files/reader/epub\
 com.tencent.news/files/reader/feeddata\
 com.tencent.news/files/reader/nativecover\
 com.tencent.news/files/reader/nativedata\
 com.tencent.news/files/reader/stat\
 com.tencent.news/files/so\
 com.tencent.news/files/stat\
 com.tencent.news/files/sync\
 com.tencent.news/iles/reader/plugin\
 com.tencent.pao/files/breezegame\
 com.tencent.peng/files/documents\
 com.tencent.peng/files/library/application support/upgrade\
 com.tencent.qgame/files/freso\
 com.tencent.qlauncher.lite/files/debug\
 com.tencent.qlauncher.lite/files/optdefthemeicon\
 com.tencent.qlauncher.lite/files/opticon\
 com.tencent.qlauncher.lite/files/optrecommremind\
 com.tencent.qlauncher.lite/files/recommendicons\
 com.tencent.qlauncher.lite/files/search\
 com.tencent.qlauncher.lite/files/theme\
 com.tencent.qlauncher.lite/files/themes\
 com.tencent.qlauncher.lite/files/wallpaper/cropped\
 com.tencent.qlauncher.lite/files/wallpaper/other\
 com.tencent.qlauncher.lite/files/wallpaper/preview\
 com.tencent.qlauncher.lite/files/wallpaper/proto\
 com.tencent.qlauncher.lite/files/wallpaper/thumbnail\
 com.tencent.qlauncher.lite/wallpaper/cropped\
 com.tencent.qqcamera/cache/local_db\
 com.tencent.qqcamera/files/opad\
 com.tencent.qqgame/cache/file/image\
 com.tencent.qqlite/app_installed_plugin\
 com.tencent.qqlite/app_plugin_download\
 com.tencent.qqlite/app_tombs\
 com.tencent.qqlite/files/arkapp/install\
 com.tencent.qqlite/files/mini/*\
 com.tencent.qqlive/[Tt]encent/qqlive/.webapp\
 com.tencent.qqlive/[Tt]encent/qqlive/imagecache\
 com.tencent.qqlive/files/.omgid/dirs\
 com.tencent.qqlive/files/.startheme\
 com.tencent.qqlive/files/.webapp\
 com.tencent.qqlive/files/ad/video\
 com.tencent.qqlive/files/apk\
 com.tencent.qqlive/files/image\
 com.tencent.qqlive/files/qqlive\
 com.tencent.qqlive/files/videodetail\
 com.tencent.qqlive/files/videos\
 com.tencent.qqlive/ickeck\
 com.tencent.qqlive/playcache\
 com.tencent.qqmusic/files/download\
 com.tencent.qqmusic/files/mipushlog\
 com.tencent.qqmusic/files/qqmusic/album\
 com.tencent.qqmusic/files/qqmusic/apk\
 com.tencent.qqmusic/files/qqmusic/config\
 com.tencent.qqmusic/files/qqmusic/downloadalbum\
 com.tencent.qqmusic/files/qqmusic/dts/assets\
 com.tencent.qqmusic/files/qqmusic/dts/meta-inf\
 com.tencent.qqmusic/files/qqmusic/dts/res\
 com.tencent.qqmusic/files/qqmusic/dts_aduto\
 com.tencent.qqmusic/files/qqmusic/dts_auto\
 com.tencent.qqmusic/files/qqmusic/encrypt\
 com.tencent.qqmusic/files/qqmusic/eup\
 com.tencent.qqmusic/files/qqmusic/fingerprint\
 com.tencent.qqmusic/files/qqmusic/firstpiece\
 com.tencent.qqmusic/files/qqmusic/fonts\
 com.tencent.qqmusic/files/qqmusic/head\
 com.tencent.qqmusic/files/qqmusic/icon\
 com.tencent.qqmusic/files/qqmusic/imageex\
 com.tencent.qqmusic/files/qqmusic/images\
 com.tencent.qqmusic/files/qqmusic/import\
 com.tencent.qqmusic/files/qqmusic/lyric\
 com.tencent.qqmusic/files/qqmusic/lyricposter\
 com.tencent.qqmusic/files/qqmusic/minialbum\
 com.tencent.qqmusic/files/qqmusic/minisinger\
 com.tencent.qqmusic/files/qqmusic/mv\
 com.tencent.qqmusic/files/qqmusic/offline\
 com.tencent.qqmusic/files/qqmusic/oltmp\
 com.tencent.qqmusic/files/qqmusic/qbiz\
 com.tencent.qqmusic/files/qqmusic/qrc\
 com.tencent.qqmusic/files/qqmusic/recognize\
 com.tencent.qqmusic/files/qqmusic/report\
 com.tencent.qqmusic/files/qqmusic/ringtones\
 com.tencent.qqmusic/files/qqmusic/screenshot\
 com.tencent.qqmusic/files/qqmusic/simple-skin\
 com.tencent.qqmusic/files/qqmusic/singer\
 com.tencent.qqmusic/files/qqmusic/skin\
 com.tencent.qqmusic/files/qqmusic/song\
 com.tencent.qqmusic/files/qqmusic/speedtest\
 com.tencent.qqmusic/files/qqmusic/splash\
 com.tencent.qqmusic/files/qqmusic/upgrade\
 com.tencent.qqmusic/files/qqmusic/welcome\
 com.tencent.qqmusic/files/recommend\
 com.tencent.qqmusic/files/tencentvideo.apk\
 com.tencent.qqmusic/qqmusic/offline\
 com.tencent.qt.qtl/files/download\
 com.tencent.reading/files/.omgid/dirs\
 com.tencent.reading/files/cell\
 com.tencent.reading/files/data\
 com.tencent.reading/files/extended\
 com.tencent.reading/files/favor\
 com.tencent.reading/files/market\
 com.tencent.reading/files/news_splash\
 com.tencent.reading/files/sync\
 com.tencent.tim/files/arkapp\
 com.tencent.tmgp.gods/files/downloads\
 com.tencent.tmgp.gods/files/icon\
 com.tencent.token/files/log\
 com.tencent.ttpic/files/cosmetic_mask\
 com.tencent.ttpic/files/download\
 com.tencent.ttpic/files/olm/camera\
 com.tencent.ttpic/files/olm/doodle\
 com.tencent.ttpic/files/op_fastival_files\
 com.tencent.ttpic/files/op_lib_files\
 com.tencent.ttpic/files/op_propagate_files\
 com.tencent.ttpic/files/op_splash_files\
 com.tencent.ttpic/files/op_xgirl_files\
 com.tencent.ttpic/files/opad\
 com.tencent.ttx5/files/head_image\
 com.tencent.wblog/http\
 com.tencent.wehome.lock/crash\
 com.tencent.zebra/files/download\
 com.tencent.zebra/files/opad)
for temp_sd_tencent in ${sd_tencent[*]};do
  rm -rf ${sd}/$temp_sd_tencent &>/dev/null;
done;
for temp_sd_data_tencent in ${sd_data_tencent[*]};do
  rm -rf ${sd}/Android/data/$temp_sd_data_tencent &>/dev/null;
done;
for temp_data_tencent in ${data_tencent[*]};do
  rm -rf /data/data/$temp_data_tencent &>/dev/null;
done;
}

# 清理垃圾文件夹
clear_dir() {
# 搜索、清理/data中的垃圾文件夹
find /data -type d \( -iname "*_cache" -o\
 -iname "*_cache_*" -o\
 -iname "*_log" -o\
 -iname "*_logs" -o\
 -iname "*-log" -o\
 -iname "*-logs" -o\
 -iname "*-temp" -o\
 -iname "*-tmp" -o\
 -iname "*-tmps" -o\
 -iname "*_temp" -o\
 -iname "*_tmp" -o\
 -iname "*_tmps" -o\
 -iname "*splash" -o\
 -iname ".*cache" -o\
 -iname ".temp" -o\
 -iname ".thumbnail" -o\
 -iname ".thumbnails" -o\
 -iname ".tmfs" -o\
 -iname ".tmp" -o\
 -iname "cache" -o\
 -iname "debug" -o\
 -iname "debug_log" -o\
 -iname "dump" -o\
 -iname "MiPushLog" -o\
 -iname "log" -o\
 -iname "logs" -o\
 -iname "spla*ad" -o\
 -iname "spla*cache" -o\
 -iname "temp" -o\
 -iname "tmp" -o\
 -iname "tmps" -o\
 -iname "xlog" \) 2>/dev/null | sed -e '/.auth_cache/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.so/ d' -e '/app_clock_bak/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/yttrium_code_cache/ d' -e '/dalvik_cache/ d' -e '/\/lib\// d' -e '/\/lib64\// d' | $(magisk --path)/.magisk/busybox/xargs -P 80 -n 20 rm -rf &>/dev/null;

# 搜索、清理SD卡中的垃圾文件夹
find /data/media -type d \( -iname "*cache*" -o\
 -iname "*login" -o\
 -iname "*story" -o\
 -iname ".escheck.tmp" -o\
 -iname ".trashBin" -o\
 -iname ".wx" -o\
 -iname ".yz" -o\
 -iname "applogic" -o\
 -iname "backup" -o\
 -iname "backups" -o\
 -iname "cmsVideo" -o\
 -iname "com_tencent_mm:toolsmp" -o\
 -iname "mta*" -o\
 -iname "pcdn" -o\
 -iname "Sandbox" -o\
 -iname "shadowplugin*" -o\
 -iname "tbs" -o\
 -iname "uploader" \) 2>/dev/null | $(magisk --path)/.magisk/busybox/xargs -P 80 -n 20 rm -rf &>/dev/null;
}

# 清理垃圾文件
clear_file() {
# App垃圾
rm -rf /data/data/com.sohu.inputmethod.sogou/databases/sogou_push &>/dev/null;
rm -rf ${sd}/Android/data/com.sohu.inputmethod.sogou/files/flx &>/dev/null;
rm -rf /data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_BINDumeng:*.xml &>/dev/null;
rm -rf /data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_SDK_CHANNEL.xml &>/dev/null;
rm -rf /data/data/com.ss.android.ugc.aweme/shared_prefs/ACCS_SDK.xml &>/dev/null;
rm -rf /data/data/com.ss.android.ugc.aweme/shared_prefs/umeng_general_config.xml &>/dev/null;
rm -rf /data/data/com.ss.android.ugc.aweme/shared_prefs/umeng_message_state.xml &>/dev/null;

# 清理SD卡根目录的垃圾文件(夹)
if [[ -f $MODDIR/clearlist-sd.txt && -s $MODDIR/clearlist-sd.txt ]];then
  cat $MODDIR/clearlist-sd.txt|$xargs_2 -P 80 -I adz0 sh -c "[[ -d ${sd}/adz0 ]] && rm -rf ${sd}/adz0/ &>/dev/null || rm -rf ${sd}/adz0 &>/dev/null" &>/dev/null;
fi;
unset adz0;

# 清理SD卡Android/data中的垃圾文件
if [[ -f $MODDIR/clearlist-sd_Android_data.txt && -s $MODDIR/clearlist-sd_Android_data.txt ]];then
  cat $MODDIR/clearlist-sd_Android_data.txt|$xargs_2 -P 80 -I adz0 sh -c "[[ -d ${sd}/Android/data/adz0 ]] && rm -rf ${sd}/Android/data/adz0/ &>/dev/null || rm -rf ${sd}/Android/data/adz0 &>/dev/null" &>/dev/null;
fi;
unset adz0;

# 搜索、清理/data中的垃圾文件
find /data -type f \( -iname "*.[0-9]" -o\
 -iname "*.alipaypng" -o\
 -iname "*.backup" -o\
 -iname "*.backups" -o\
 -iname "*.bak" -o\
 -iname "*.temp" -o\
 -iname "*.tmp" -o\
 -iname "*.tmps" -o\
 -iname "*.tlog" -o\
 -iname "*.tmfs" -o\
 -iname "*.tmp" -o\
 -iname "*_log" -o\
 -iname "*_logs" -o\
 -iname "*_log*.txt" -o\
 -iname "*error" -o\
 -iname "*log" -o\
 -iname "*log.lock" -o\
 -iname "*log.txt" -o\
 -iname "*log[0-9].txt" -o\
 -iname "*logs" -o\
 -iname "*logs*.txt" -o\
 -iname "._.Trashes" -o\
 -iname ".common" -o\
 -iname ".DS_Store" -o\
 -iname ".dump" -o\
 -iname ".fseventsd" -o\
 -iname ".sk_v.dat" -o\
 -iname ".spotlight*" -o\
 -iname ".tim" -o\
 -iname ".turing.dat" -o\
 -iname "awp_core.apk" -o\
 -iname "log_*.txt" -o\
 -iname "logs_*.txt" -o\
 -iname "Thumbs.db" -o\
 -iname "tlog_v[0-9]" -o\
 -iname "x5.backup*" -o\
 -iname "x5.tbs.org*" \) 2>/dev/null | sed -e '/.auth_cache/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.so/ d' -e '/app_clock_bak/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/yttrium_code_cache/ d' -e '/dalvik_cache/ d' -e '/\/lib\// d' -e '/\/lib64\// d' | $(magisk --path)/.magisk/busybox/xargs -P 80 -n 20 rm -rf &>/dev/null;
}

# 清理系统垃圾
clear_system() {
# 无响应日志
rm -rf /data/anr/* &>/dev/null
# 系统暂挂备份文件
rm -rf /data/backup/pending/* &>/dev/null
# 系统(应用)崩溃日志
rm -rf /data/crashdata/* &>/dev/null
rm -rf /data/tombstones/* &>/dev/null
rm -rf /dev/fscklogs/* &>/dev/null
rm -rf /idd/crashdata/* &>/dev/null
#rm -rf /data/dalvik-cache/* &>/dev/null
# 系统跟踪记录
rm -rf /data/local/* &>/dev/null
# DropBox的日志
rm -rf /data/system/dropbox/* &>/dev/null
# 安装缓存
rm -rf /data/system/package_cache/* &>/dev/null
# 进程统计
rm -rf /data/system/procstats/* &>/dev/null
# App启动统计信息
rm -rf /data/system/usagestats/* &>/dev/null
# 同步管理日志
rm -rf /data/system/syncmanager-log/* &>/dev/null
rm -rf /data/system_ce/0/recent_images/* &>/dev/null
# "最近任务"缓存
rm -rf /data/system_ce/0/recent_tasks/* &>/dev/null
rm -rf /data/system_ce/0/snapshots/* &>/dev/null
rm -rf /sys/kernel/debug/* &>/dev/null
rm -rf /proc/sys/debug/* &>/dev/null
# 电池用量统计
rm -rf /data/system/batterystats.bin &>/dev/null
rm -rf /data/system/batterystats-checkin.bin &>/dev/null
# MIUI Wifi日志
rm -rf /data/vendor/wlan_logs/* &>/dev/null
rm -rf /data/vendor/charge_logger/* &>/dev/null
}

# 清理App开机进程；来源酷安@key的'QQ微信省内存省电'；感谢！
kill_process(){
killprocess_1="
com.tencent.mm:sandbox*
com.tencent.mm:exdevice*
com.tencent.mobileqq:tool*
com.tencent.mobileqq:qzone*
com.tencent.mobileqq:mini*
com.tencent.mm:tools*
com.tencent.mm:appbrand*
com.tencent.mobileqq:picture*
com.tencent.mobileqq:TMAssistantDownloadSDKService*
com.tencent.mobileqq:video*
com.tencent.mm:hotpot*
com.tencent.mobileqq:hotpot*
:xg_vip_service
"
for killprocess_2 in $killprocess_1;do
  PID_temp=$(pgrep -f $killprocess_2);
  [[ $PID_temp ]] && kill -15 $PID_temp;
  [[ $PID_temp && $? != "0" ]] && kill -9 $PID_temp;
  unset PID_temp;
done
wait
}

# 降低App进程等级
lower_process(){
lower_process_num=995
lowerprocess_1="
com.android.providers.calendar
com.miui.personalassistant
com.tencent.mm
com.tencent.qqlite
com.tencent.mobileqq
com.miui.cloudbackup
com.android.camera
"
for lowerprocess_2 in $lowerprocess_1;do
  PID_temp=$(pidof -s $lowerprocess_2);
  [[ $PID_temp ]] && { echo "15" > /proc/$PID_temp/oom_adj;echo "$lower_process_num" > /proc/$PID_temp/oom_score_adj;let lower_process_num="lower_process_num - 5";};
  unset PID_temp;
done
unset lower_process_num;
}

# 禁用毒瘤app
pm_disable_app() {
dis_app=(com.miui.analytics com.miui.systemAdSolution)
for temp_dis_app_1 in ${dis_app[*]}
do
  temp_enable_app=$(pm list packages -e | cut -f2 -d ':' | grep ${temp_dis_app_1})
  temp_dis_app_2=$(pm list packages -d | cut -f2 -d ':' | grep ${temp_dis_app_1})
  if [[ -n "$temp_enable_app" ]];then
    echo "   正在pm disable禁用${temp_dis_app_1}，稍等..."
    pm disable ${temp_dis_app_1} &>/dev/null
    temp_dis_app_3=$(pm list packages -d | cut -f2 -d ':' | grep ${temp_dis_app_1})
# 检测毒瘤app是否disable失败，query_dis_app为“1”表示失败
    [[ -z "$temp_dis_app_3" ]] && query_dis_app=1 || { query_dis_app=0;echo "   ${temp_dis_app_1}禁用成功！";}
    [[ -n "$(pidof -s ${temp_dis_app_1})" || $query_dis_app == "1" ]] && { pm hide ${temp_dis_app_1} &>/dev/null;query_hide_app=$?;}
    [[ $query_hide_app == "0" ]] && echo "   采用pm hide禁用${temp_dis_app_1}成功！"
    [[ $query_dis_app != "0" && $query_hide_app != "0" ]] && echo "   ${temp_dis_app_1}禁用失败！"
    if [[ -f /data/adb/modules/zw_fileclear/uninstall.sh ]];then
       [[ $query_dis_app == "0" ]] && echo "/system/bin/pm enable ${temp_dis_app_1}" >>/data/adb/modules/zw_fileclear/uninstall.sh
       [[ $query_hide_app == "0" ]] && echo "/system/bin/pm unhide ${temp_dis_app_1}" >>/data/adb/modules/zw_fileclear/uninstall.sh
    fi
  elif [[ -n "$temp_dis_app_2" ]];then
    echo "   检测到${temp_dis_app_1}已备禁用"
  else
    echo "   没有检测到${temp_dis_app_1}，没安装该App?!"
  fi
done
rm -rf /data/system/package_cache/* &>/dev/null
}

# 卸载毒瘤app
uninstall_app() {
# 清理安装缓存
rm -rf /data/system/package_cache/* &>/dev/null
unin_app=(com.miui.analytics com.miui.systemAdSolution)
for temp_unin_app_1 in ${unin_app[*]};do
  if [[ -n "$(/system/bin/pm list packages | grep $temp_unin_app_1)" ]];then
    temp_unin_app_2=$(find / -type d -iname "${temp_unin_app_1}-*" 2>/dev/null | sed -e '/\/sbin\/.magisk/d')
    temp_unin_app_3=$(find / -type d -iname "${temp_unin_app_1}" 2>/dev/null | sed -e '/\/sbin\/.magisk/d')
    /system/bin/pm uninstall $temp_unin_app_1 &>/dev/null
    [[ -n "$temp_unin_app_2" ]] && for temp_unin_app_21 in $temp_unin_app_2;do
      rm -rf "$temp_unin_app_21" &>/dev/null
      touch $temp_unin_app_21
      [[ -f $temp_unin_app_21 ]] && { chmod 000 $temp_unin_app_21;chattr +i $temp_unin_app_21;}
    done
    [[ -n "$temp_unin_app_3" ]] && for temp_unin_app_31 in $temp_unin_app_3;do
      rm -rf "$temp_unin_app_31" &>/dev/null
    done
  fi
done
rm -rf /data/system/package_cache/* &>/dev/null
}

# 回收文件系统未使用的空间
recycling_space() {
fstrim_2="$(magisk --path)/.magisk/busybox/fstrim"
$fstrim_2 -v / &>/dev/null
for fstrim_temp in $(/system/bin/ls -l / |grep ^d|awk '{print $8}')
do
  $fstrim_2 -v "/""$fstrim_temp" &>/dev/null
done
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
sync
wait
}

# 安装crond服务配置文件
install_crond() {
if [[ ! -f ${MODDIR}/root ]];then
touch ${MODDIR}/root
cat>${MODDIR}/root<<eof
#!/system/bin/sh
SHELL=/system/bin/bash
MAILTO=root
HOME=/
magisk_path=\$(magisk --path)/.magisk/busybox
PATH=/sbin:/system/bin:\$magisk_path:\$PATH

# 定时执行任务，请自行修改脚本执行时间，重启后生效
# run-parts
0 */12 * * * su -c "/system/bin/bash $0"
0 */3 * * * su -c "/system/bin/bash $0 -kl"
eof
fi
}

# 检查并启动crond服务
check_crond() {
[[ -d ${crondfileclear_path} ]] && sleep 15s
if [[ -f ${crondfileclear_path}/root ]];then
  rerun_crond="0"
  crond_startclear=$(grep -i "startclear.sh\"$" ${crondfileclear_path}/root)
  crond_startclear_kl=$(grep -i "startclear.sh -kl\"$" ${crondfileclear_path}/root)
  [[ -z "$crond_startclear" ]] && { echo "0 */12 * * * su -c \"/system/bin/bash $0\"" >> ${crondfileclear_path}/root;rerun_crond="1";}
  [[ -z "$crond_startclear_kl" ]] && { echo "0 */3 * * * su -c \"/system/bin/bash $0 -kl\"" >> ${crondfileclear_path}/root;rerun_crond="1";}
  [[ -n "$(/system/bin/ps -ef | grep -v grep | grep "crond -c ${crondfileclear_path}")" ]] && crond_pid=$(/system/bin/ps -ef | grep -v grep | grep "crond -c ${crondfileclear_path}" | awk '{print $2}')
  [[ $rerun_crond == "1" && -n "$crond_pid" ]] && { kill -15 $crond_pid;kill -9 $crond_pid;crond -c ${crondfileclear_path};}
  [[ -z "$crond_pid" ]] && crond -c ${crondfileclear_path}
else
  if [[ -f ${MODDIR}/root ]];then
    rerun_crond="0"
    crond_startclear=$(grep -i "startclear.sh\"$" ${MODDIR}/root)
    crond_startclear_kl=$(grep -i "startclear.sh -kl\"$" ${MODDIR}/root)
    [[ -z "$crond_startclear" ]] && { echo "0 */12 * * * su -c \"/system/bin/bash $0\"" >> ${MODDIR}/root;rerun_crond="1";}
    [[ -z "$crond_startclear_kl" ]] && { echo "0 */3 * * * su -c \"/system/bin/bash $0 -kl\"" >> ${MODDIR}/root;rerun_crond="1";}
    [[ -n "$(/system/bin/ps -ef | grep -v grep | grep "crond -c ${MODDIR}")" ]] && crond_pid=$(/system/bin/ps -ef | grep -v grep | grep "crond -c ${MODDIR}" | awk '{print $2}')
    [[ $rerun_crond == "1" && -n "$crond_pid" ]] && { kill -15 $crond_pid;kill -9 $crond_pid;crond -c ${MODDIR};}
    [[ -z "$crond_pid" ]] && crond -c ${MODDIR}
  else
    install_crond
    crond -c ${MODDIR}
  fi
fi
}

sleep 10s
# 挂载分区为可写
magisk_path=$(magisk --path)/.magisk
mount|grep "ro,"|grep -v "$magisk_path/"|awk -F'[ ,]' '{print $1,$3}'|while read a b
do
mount -o rw,remount $a $b &>/dev/null
done

# 禁用高通的wlan_logs日志
stop cnss_diag
# 禁用tcpdump日志
stop tcpdump

if [[ $1 == "-td" || $1 == "td" ]];then
  clear_tencent_dir        # 清理腾讯系垃圾文件夹
elif [[ $1 == "-u" || $1 == "u" ]];then
  uninstall_app            # 卸载毒瘤app
elif [[ $1 == "-c" || $1 == "c" ]];then
  kill_process             # QQ微信省内存省电
  clear_tencent_dir &
  clear_dir &
  clear_file &
  clear_system &
  kill_process
  wait
  lower_process        # 降低App进程等级
  recycling_space      # 回收文件系统未使用的空间
elif [[ $1 == "-kl" || $1 == "kl" ]];then
  kill_process
  lower_process
  recycling_space
elif [[ $1 == "-klc" || $1 == "klc" ]];then
  kill_process
  check_crond           # 检查并启动crond服务
  lower_process
  recycling_space
elif [[ $1 == "-h" || $1 == "--help" ]];then
  echo -e "  参数-f或f，清理垃圾文件；\n  参数-c或c，清理垃圾文件(夹)；\n  参数-d或d，只清理垃圾文件夹；\n    参数-td或td，只清理腾讯系垃圾文件夹；\n  参数-u或u，卸载毒瘤APP；\n  无参数，执行整个脚本所有功能！"
elif [[ -z $1 ]];then
  kill_process
  clear_tencent_dir &
  clear_dir &
  clear_file &
  clear_system &
  pm_disable_app
  kill_process
  check_crond
  wait
  lower_process
  recycling_space
fi

# 取消命令别名
unalias am
unalias pm
unalias crond