dir=/sys/class/power_supply
warm="$dir/battery/temp"
chg_speed=$dir/battery/constant_charge_current
chg_cool=$dir2/cool_mode
capacity="$dir/battery/capacity"
current_now=$dir/battery/current_now
chmod 777 $dir/battery/*
chattr -i $dir/*
################
#低电量充电电量
#ultra_charge=29
#正常充电区间开始(不可修改）
normal_charge_start=29
#结束
normal_charge_end=86
#快满二阶段限速开始
step_charge_start=86
#结束
step_charge_end=94
#最终限速开始
low_speed_charge=94
#上一级结束和后面必须开始相同！#
#快充满限速能显著提高电池寿命
#################
until [[ $jslx == true ]]; do
sleep 7s
chg_lv=`[[ -f $capacity ]] && cat $capacity`
chg_st=`[[ -f $current_now ]] && cat $current_now`
data=`[[ -f $warm ]] && cat $warm`
if [[ $chg_st -gt 0 ]]; then
 sleep 30s
elif [[ $chg_st -lt 0 ]]; then
  if [[ $chg_lv -le 29 ]]; then
   if [[ "$data" -lt "439" ]];then
    echo  '13000000' > $chg_speed
   elif [[ "$data" -gt "439" ]];then
    echo  '1500000' > $chg_speed
   fi
  elif [ "$chg_lv" -ge "$normal_charge_start" ]&&[ "$chg_lv" -lt "$normal_charge_end" ];then
  if [[ $data -le 389 ]]; then
   echo  '-22' > $chg_speed
  elif [ "$data" -ge "389" ]&&[ "$data" -lt "399" ];then
   echo  '9900000' > $chg_speed
  elif [ "$data" -ge "399" ]&&[ "$data" -lt "409" ];then
   echo  '8700000' > $chg_speed
  elif [ "$data" -ge "409" ]&&[ "$data" -lt "419" ];then
   echo  '7100000' > $chg_speed
  elif [ "$data" -ge "419" ]&&[ "$data" -lt "429" ];then
   echo  '5500000' > $chg_speed
  elif [ "$data" -ge "429" ]&&[ "$data" -lt "439" ];then
   echo  '3200000' > $chg_speed
  elif [[ "$data" -ge "439" ]];then
   echo  '100000' > $chg_speed
    fi
 elif [ "$chg_lv" -ge "$step_charge_start" ]&&[ "$chg_lv" -lt "$step_charge_end" ];then
  if [[ "$data" -lt "429" ]];then
   echo  '1500000' > $chg_speed
  elif [[ "$data" -ge "430" ]];then
   echo  '100000' > $chg_speed
  fi
 elif [[ $chg_lv -ge "$low_speed_charge" ]]; then
  echo  '500000' > $chg_speed
 fi
fi
done
