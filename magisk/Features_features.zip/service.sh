#!/system/bin/sh
MODDIR=${0%/*}
#酷安@主张
rm -rf /data/adb/lspd/log
touch   /data/adb/lspd/log
chmod 000 /data/adb/lspd/log

rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
