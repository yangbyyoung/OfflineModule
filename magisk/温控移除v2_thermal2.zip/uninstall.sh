/sbin/.magisk/busybox/chattr -i  /data/vendor/thermal/config
/sbin/.magisk/busybox/chattr -i  /data/user/0/com.miui.powerkeeper/databases/cloud_configure.db-journal
/sbin/.magisk/busybox/chattr -i  /data/user/0/com.miui.powerkeeper/databases/cloud_configure.db
/sbin/.magisk/busybox/chattr -i  /data/thermal
/sbin/.magisk/busybox/chattr -i  /data/vendor/thermal/config