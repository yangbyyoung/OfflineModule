#!/system/bin/sh
MODDIR=${0%/*}
mktouch() {
	mkdir -p ${1%/*} 2>/dev/null
	[ -z $2 ] && touch $1 || echo $2 > $1
	chmod 644 $1
}
if [[ -e /system/vendor/bin/cnss_diag ]]; then
	if [[ ! -e $MODDIR/system/vendor/bin/cnss_diag ]]; then
	mktouch $MODDIR/system/vendor/bin/cnss_diag
	fi
else
	if [[ -e $MODDIR/system/vendor/bin/cnss_diag ]]; then
	rm -rf $MODDIR/system/vendor/bin/cnss_diag
	fi
fi