#!/system/bin/sh

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

function cp_MTK_thermal_conf_find(){
local MTK_MODPATH_config_DIR="${MODPATH}/thermal/MTK_thermal"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	mkdir -p "${MODPATH}/system/vendor/etc/thermal" "${MODPATH}/system/vendor/etc/.tp"
		touch "${MODPATH}/system/vendor/etc/thermal/.replace"
	touch "${MODPATH}/system/vendor/etc/.tp/.replace"
	find $(magisk --path)/.magisk/mirror/vendor/etc/thermal $(magisk --path)/.magisk/mirror/vendor/.tp -iname "*.conf" -type f -o -iname "*.mtc" -type f 2>/dev/null | while read file ;do
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/thermal/${file##*/}"
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/.tp/${file##*/}"
	done
		cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/thermal"
	cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/.tp" 
fi
}

function echo_check_result(){
local check_item=`find /system /system_ext /vendor /product -iname "*thermal*.conf" -type f 2>/dev/null | grep -Ei 'pubgmhd|sgame' | wc -l`
if test "${check_item}" -ge "2" ;then
	echo "true"
fi
}


find /system /system_ext /vendor /product -iname '*thermal*.conf' -type f 2>/dev/null | sed '/thermal.*map.*.conf/d' | while read file ;do
	echo "$( correctpath "$file" )" >> "$TMPDIR/thermal_list.txt"
done

echo "$(cat "$TMPDIR/thermal_list.txt" | sort | uniq )" > "$TMPDIR/thermal_list.txt"

for i in $(ls $MODPATH/system/vendor/etc)
do
	sed -i "/$i/d" "$TMPDIR/thermal_list.txt"
done

cat "$TMPDIR/thermal_list.txt" | while read file ;do
	if test "$(show_value '温控配置')" = "nolimit" ;then
		test "$(echo "${file}" | grep -E 'tgame|mgame' )" != "" && continue
	fi
			mkdir -p "${MODPATH}/${file%/*}"
		#test "${file##*/}" = "thermal-chg-only.conf" && continue
	cp -rf "${MODPATH}/system/vendor/etc/thermal-normal.conf" "$MODPATH${file}"
done

find /system /system_ext /vendor /product -iname '*thermal*map*.conf' -type f 2>/dev/null | while read file ;do
size="$(du -k $file | awk '{print $1}' | tr -cd '[0-9]'  )"
details="$(cat $file 2>/dev/null | sed 's/[[:space:]]//g;s|/n||g' )"
if test -f "$file" -a "$size" -ge "1" -a "$details" != "" ;then
	file="$( correctpath "$file" )"
		mkdir -p "${MODPATH}/${file%/*}"
	cp -rf "${file}" "${MODPATH}/${file}"
fi
done

find /system /system_ext /vendor /product -iname '*thermald*devices*.conf' -type f 2>/dev/null | while read file ;do
size="$(du -k $file | awk '{print $1}' | tr -cd '[0-9]'  )"
details="$(cat $file 2>/dev/null | sed 's/[[:space:]]//g;s|/n||g' )"
if test -f "$file" -a "$size" -ge "1" -a "$details" != "" ;then
	file="$( correctpath "$file" )"
		mkdir -p "${MODPATH}/${file%/*}"
	cp -rf "${file}" "${MODPATH}/${file}"
fi
done

if test "$(show_value '游戏温控配置')" = "是" ;then
	if test "$(echo_check_result)" = "true" ;then
		find /system /system_ext /vendor /product -iname "thermal*tgame.conf" -type f -o -iname "thermal*sgame.conf" -type f -o -iname "thermal*pubgmhd.conf" -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
		mkdir -p "$MODPATH/${truely_path%/*}"
		cp -rf ${MODPATH}/thermal/old_thermal/game.conf "$MODPATH/$truely_path"
	done
else
	find /system /system_ext /vendor /product -iname '*thermal*tgame*.conf' -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
			mkdir -p "$MODPATH/${truely_path%/*}"
	if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" = "" ;then
		cp -rf ${MODPATH}/thermal/thermal-tgame.conf "$MODPATH/$truely_path"
	else
		cp -rf ${MODPATH}/thermal/MTK/MTK_thermal-tgame.conf "$MODPATH/$truely_path"
	fi
	done
	find /system /system_ext /vendor /product -iname '*thermal*mgame*.conf' -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
			mkdir -p "$MODPATH/${truely_path%/*}"
	if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" = "" ;then
		cp -rf ${MODPATH}/thermal/thermal-mgame.conf "$MODPATH/$truely_path"
	else
		cp -rf ${MODPATH}/thermal/MTK/MTK_thermal-mgame.conf "$MODPATH/$truely_path"
	fi
		done
	fi
fi

cp_MTK_thermal_conf_find

echo "@coolapk10007" > /data/vendor/thermal/config/thermal.txt 2>/dev/null || {
rm -rf /data/vendor/thermal
mkdir -p /data/vendor/thermal/config
} && rm -rf /data/vendor/thermal/config/* /data/vendor/thermal/config/thermal.txt

#修复MIUI温控
key_source $MODPATH/fixed_thermal_map_conf.sh
cp -rf $MODPATH/system/vendor/etc/* /data/vendor/thermal/config

chmod -R 0771 '/data/vendor/thermal'
	chown -R root:system '/data/vendor/thermal'
chcon -R 'u:object_r:vendor_data_file:s0' '/data/vendor/thermal'
