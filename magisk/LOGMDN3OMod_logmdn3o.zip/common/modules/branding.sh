print_branding() {
    add_spacing 2
    ui_print "                _    ___   ___ __  __ ___   "
    ui_print "               | |  / _ \ / __|  \/  |   \  "
    ui_print "               | |_| (_) | (_ | |\/| | |) | "
    ui_print "               |____\___/ \___|_|  |_|___/  "
    ui_print "              "
    ui_print "              ------------ N3O -------------"
    ui_print "              -- No Nonsense Notch Overlay -"
    add_spacing 2
}
