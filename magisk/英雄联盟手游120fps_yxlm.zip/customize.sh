SKIPUNZIP=0

find /data/media/0/Android/data/com.tencent.lolm/files/SaveData/Local/* -name "Setting" -exec echo>$TMPDIR/配置文件 {} \;
Setting1=$(sed -n '1p' $TMPDIR/配置文件)
Setting2=$(sed -n '2p' $TMPDIR/配置文件)
Setting3=$(sed -n '3p' $TMPDIR/配置文件)
Setting4=$(sed -n '4p' $TMPDIR/配置文件)
Setting5=$(sed -n '5p' $TMPDIR/配置文件)

if [ -s $TMPDIR/配置文件 ];then
cp -rf $MODPATH/*fps $Setting1
cp -rf $MODPATH/*fps $Setting2
cp -rf $MODPATH/*fps $Setting3
cp -rf $MODPATH/*fps $Setting4
cp -rf $MODPATH/*fps $Setting5
chmod 440 $Setting1
chmod 440 $Setting2
chmod 440 $Setting3
chmod 440 $Setting4
chmod 440 $Setting5
else
abort "- 未找到配置文件，安装失败"
fi
mkdir /data/media/0/Android/德玛西亚
echo "sh /data/adb/modules/yxlm/手动执行.sh">/data/media/0/Android/德玛西亚/英雄联盟.sh


ui_print "- ------------------------------------------------------------
- 名称：$MODNAME
- 版本：`grep_prop version $TMPDIR/module.prop`(`grep_prop versionCode $TMPDIR/module.prop`)
- 作者：$MODAUTH
- 简介：`grep_prop description $TMPDIR/module.prop`
- ------------------------------------------------------------
- 如果卡开机 🙏🏻 请在
- rec→高级→文件管理→data→adb→modules
- 删除$MODID这个文件夹
- 成功刷入😁重启手机生效🙃"