#!/system/bin/sh

function unlock_thermal(){
local target="${1}" 
/data/adb/magisk/busybox chattr -R -i "${target}" >/dev/null 2>&1
/data/adb/magisk/busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
busybox chattr -R -i "${target}" >/dev/null 2>&1
busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
chattr -R -i "${target}" >/dev/null 2>&1
chattr -R -i "${target%/*}" >/dev/null 2>&1
rm -rf "${target%/*}"
}


unlock_thermal "/data/thermal/config"
unlock_thermal "/data/vendor/thermal/config"

pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver >/dev/null 2>&1
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService >/dev/null 2>&1
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver >/dev/null 2>&1
