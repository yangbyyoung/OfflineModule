am start -a 'android.intent.action.VIEW' -d 'https://setoskins.top/' >/dev/null 2>&1
