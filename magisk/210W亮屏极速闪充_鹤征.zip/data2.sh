warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo 90000000 > /sys/class/power_supply/battery/fast_charge_current
  echo 90000000 > /sys/class/power_supply/battery/thermal_input_current
  echo 90000000 > /sys/class/power_supply/usb/current_max
sleep 2s
data=`[[ -f $warm ]] && cat $warm`
if [[ $data -le 800 ]]; then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '99000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '99000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max" 
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "600" ]&&[ "$data" -lt "800" ];then
  echo '90000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
fi
done
