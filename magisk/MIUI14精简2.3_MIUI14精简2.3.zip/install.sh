##########################################################################################
#
# Magisk Module Template Config Script
# by Lingly
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=false
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用
# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false
##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "     	Magisk Module        "
  ui_print "For    By Lingly"
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now

#添加您要精简的APP/文件夹目录
#例如：精简状态栏，找到状态栏目录为  /system/priv-app/SystemUI/SystemUI.apk
#转化加入:/system/priv-app/SystemUI
#（可以搭配高级设置获取APP目录）

##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  #设置权限，基本不要去动
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.
REPLACE="
/system/product/app/AnalyticsCore
/system/app/EasterEgg
/system/product/app/talkback
/system/priv-app/Backup
/system/product/priv-app/MiuiExtraPhoto
/system/vendor/app/CACertService
/system/priv-app/CallLogBackup
/system/product/app/CarWith
/system/app/CatchLog
/system/priv-app/CellBroadcastServiceModulePlatform
/system/product/app/MiuiCit
/system/priv-app/CellBroadcastLegacyApp
/system/priv-app/ONS
/system/priv-app/SharedStorageBackup
/system/system_ext/app/WAPPushManager
/system/app/WallpaperBackup
/system/system_ext/priv-app/WallpaperCropper
/system/priv-app/MiuiWifiDialog
/system/app/com.miui.qr
/system/system_ext/app/KSICibaEngine
/system/system_ext/app/TranslationService
/system/product/overlay/VoiceAssistAndroidOverlay
/system/system_ext/priv-app/dpmserviceapp
/system/system_ext/app/datastatusnotification
/system/system_ext/app/colorservice
/system/system_ext/app/atfwd
/system/system_ext/app/embms
/system/system_ext/app/DeviceStatisticsService
/system/system_ext/app/DynamicDDSService
/system/product/app/uimlpaservice
/system/product/app/remoteSimLockAuthentication
/system/product/app/remotesimlockservice
/system/product/app/uimgbaservice
/system/system_ext/app/workloadclassifier
/system/system_ext/app/BluetoothDsDaService
/system/vendor/app/TimeService
/system/product/app/uimremoteclient
/system/product/app/uimremoteserver
/system/system_ext/priv-app/StorageManager
/system/priv-app/BlockedNumberProvider
/system/product/app/MIUIBarrage
/system/system_ext/priv-app/dcf
/system/product/app/MiDevAuthService
/system/vendor/app/EidService
/system/priv-app/ManagedProvisioning
/system/product/app/PowerOffAlarm
/system/product/app/MIUIgreenguard
/system/app/BasicDreams
/system/system_ext/priv-app/EmergencyInfo
/system/system_ext/priv-app/Provision
/system/product/app/HybridPlatform
/system/priv-app/LiveWallpapersPicker
/system/app/ModemTestBox
/system/app/MiuiAudioMonitor
/system/app/VsimCore
/system/product/priv-app/MIUIMiRcs
/system/product/app/PaymentService
/system/app/MiSightService
/system/product/app/MIUIPrivacyComputing
/system/product/app/MiuiBiometric3389
/system/product/app/MIUIVpnSdkManager
/system/app/KeyChain
/system/app/NQNfcNci
/system/product/overlay/FontNotoSerifSource
/system/product/app/OTrPBroker
/system/app/PacProcessor
/system/app/CompanionDeviceManager
/system/system_ext/priv-app/Polaris
/system/priv-app/ProxyHandler
/system/system_ext/app/QCC
/system/system_ext/app/QColor
/system/system_ext/app/QdcmFF
/system/product/app/MIpay
/system/system_ext/priv-app/QualcommVoiceActivation
/system/product/app/RideModeAudio
/system/priv-app/PackageInstaller
/system/vendor/app/SensorTestTool
/system/product/app/SecurityOnetrackService
/system/system_ext/app/DeviceInfo
/system/product/priv-app/SettingsIntelligence
/system/app/SimAppDialog
/system/product/priv-app/SystemHelper
/system/product/priv-app/MIUIQuickSearchBox
/system/priv-app/Tag
/system/app/MiuixEditor
/system/system_ext/app/uceShimService
/system/product/app/MIUIReporter
/system/system_ext/app/PowerSaveMode
/system/app/Stk
/system/system_ext/app/ImsRcsService
/system/vendor/app/IWlanService
/system/product/app/MetokNLP
/system/app/WapiCertManage
/system/product/app/MaintenanceMode
/system/system_ext/priv-app/WfdService
/system/product/app/WMService
/system/product/priv-app/VipServiceNew
/system/product/app/XiaoaiRecommendation
/system/product/app/VoiceAssistAndroidT
/system/product/app/MIUISecurityInputMethod
/system/product/priv-app/MIShare
/system/product/priv-app/MIUIVideo
/system/app/digitalkey
/system/product/app/SimActivateService
/system/product/app/MIUIAccessibility
/system/product/priv-app/DownloadProviderUi
/system/system_ext/app/PerformanceMode
/system/app/Traceur
/system/system_ext/priv-app/xrcbservice
/system/product/app/MIUITouchAssistant
/system/product/priv-app/MIUIMusicT
/system/product/app/UPTsmService
/system/priv-app/StatementService
/system/product/app/MiBugReport
/system/product/priv-app/MiGameCenterSDKService
/system/product/app/MiGameService
/system/app/AutoRegistration
/system/app/CarrierDefaultApp
/system/product/app/VoiceTrigger
/system/product/app/HybridAccessory
/system/product/app/MSA
/system/product/priv-app/MIUIPersonalAssistant
/system/system_ext/priv-app/beyondGnssService
/system/product/app/MIUIFrequentPhrase
/system/product/app/MiuiInputSettings
/system/product/app/ConferenceDialer
/system/priv-app/DMRegService
/system/priv-app/MediaProviderLegacy
/system/product/app/GoogleLocationHistory
/system/vendor/app/CneApp
"




#
##########################################################################################
#部分包名注释，供参考，不需要精简的就删掉上面的那行，需要精简的就自行复制添上

#/system/product/app/AnalyticsCore
#老毒瘤了,懂得都懂

#/system/product/app/talkback
#无障碍模式

#/system/priv-app/Backup
#备份

#/system/product/priv-app/MiuiExtraPhoto
#小米相机文档模式

#/system/priv-app/CallLogBackup
#原生通话记录备份

#/system/app/PlatformCaptivePortalLogin
#WiFi认证,连接公共WiFi需要这个
#（默认未精简）

#/system/product/app/CarWith
#小米车机互联

#/system/app/CatchLog
#抓日志的玩意

#/system/priv-app/CellBroadcastServiceModulePlatform
#广播

#/system/product/app/MiuiCit
#小米硬件测试工具,售后一般会用到

#/system/priv-app/CellBroadcastLegacyApp
#广播

#/system/priv-app/SharedStorageBackup
#共享备份存储,部分机型可能会卡米,大部分不会

#/system/system_ext/app/WAPPushManager
#wap推送服务

#/system/app/WallpaperBackup
#壁纸备份

#/system/app/com.miui.qr
#cit相关,要售后的话不建议禁用

#/system/system_ext/app/KSICibaEngine
#小米传送门翻译组件

#/system/system_ext/app/TranslationService
#翻译

#/system/priv-app/BlockedNumberProvider
#号码屏蔽

#/system/app/MiuiPrintSpoolerBeta
#打印处理服务
#（默认未精简）

#/system/vendor/app/IFAAService
#支付宝指纹支付模块,禁用后无法使用指纹支付
#（默认未精简）

#/system/product/app/MIUIgreenguard
#亲情守护,用来看你家人的手机位置

#/system/app/BasicDreams
#基本互动屏保,对MIUI没啥用

#/system/system_ext/priv-app/EmergencyInfo
#急救信息

#/system/product/app/HybridPlatform
#快应用服务框架（广告）

#/system/priv-app/LiveWallpapersPicker
#动态壁纸

#/system/app/ModemTestBox
#鲁班MTB

#/system/app/MiuiAudioMonitor
#应用通话录音

#/system/app/VsimCore
#虚拟SIM卡内核

#/system/product/priv-app/MIUIMiRcs
#免费网络短信

#/system/product/app/PaymentService
#米币支付,可能会影响购买主题

#/system/vendor/app/MipayService
#小米支付相关服务,这不是米币支付,不建议禁用
#（默认未精简）

#/system/product/app/MIUIVpnSdkManager
#小米游戏加速服务

#/system/system_ext/app/MiuiDaemon
#MIUI质量服务,影响闪存,非常不建议禁用
#（默认未精简）

#/system/app/KeyChain
#密钥链（国内无用,某些机型禁用后卸载应用会黑屏重启）

#/system/app/CompanionDeviceManager
#演示机应用

#/system/app/SecureElement
#与Mipay有关,不建议禁用
#（默认未精简）

#/system/app/SimAppDialog
#SIM日志记录

#/system/vendor/app/SoterService
#微信指纹支付模块,禁用后无法使用指纹支付
#（默认未精简）

#/system/product/priv-app/MIUIQuickSearchBox
#搜索

#/system/app/Stk
#SIM卡工具包

#/system/product/priv-app/MIUIAod
#万象息屏,可选禁用
#（默认未精简）


#/system/system_ext/priv-app/WfdService
#安卓原生投屏,不影响小米和第三方投屏

#/system/product/app/WMService
#与消息推送有关,不影响mipush

#/system/product/app/MIUISecurityInputMethod
#安全键盘

#/system/product/priv-app/MIUIVideo
#小米视频,可选禁用

#/system/product/app/SimActivateService
#小米的SIM激活服务,如果你买了小米的sim卡,这个可能是用来激活它的

#/system/product/app/MIUIAccessibility
#小米无障碍,删了貌似不影响无障碍（非绝对）

#/system/product/app/MITSMClient
#小米智能卡,与NFC相关,不建议禁用,折中方案请使用冰箱
#（默认未精简）

#/system/product/app/MINextpay
#小米智能卡网页组件,配套智能卡,与NFC相关不建议禁用，折中方案请使用冰箱
#（默认未精简）

#/system/product/app/MIUITouchAssistant
#悬浮球

#/system/product/app/MiBugReport
#用户反馈,日志抓取,禁用后无法抓取日志

#/system/product/priv-app/MiGameCenterSDKService
#小米游戏组件

#/system/product/app/MiGameService
#小米游戏高能时刻

#/system/app/AutoRegistration
#运营商服务,与网络自动注册有关

#/system/app/CarrierDefaultApp
#运营商默认应用

#/system/product/app/HybridAccessory
#快应用支持组件（广告）

#/system/priv-app/DMRegService
#日志相关

#/system/product/app/GoogleLocationHistory
#谷歌活动记录，位置记录

#/system/app/PrintRecommendationService
#打印服务相关
#（默认未精简）

#/system/priv-app/BuiltInPrintService
#初始打印服务相关
#（默认未精简）

#/system/product/app/MiuiBiometric3389
#部分移植包如遇人脸无法使用,请删除此项

#/system/product/app/VoiceTrigger
#小爱语音唤醒

#/system/product/overlay/VoiceAssistAndroidOverlay
#/system/system_ext/priv-app/QualcommVoiceActivation
#/system/product/app/VoiceAssistAndroidT
#可能是关于小爱语音的几项服务,目前尚未确定具体是哪个,所以小爱语音无法使用的可以尝试删除这几项,但也无法保证完全有用,因为原精简包中并没有精简小爱这项服务

#/system/product/app/MIUIFrequentPhrase
#全面屏键盘优化

#/system/app/NQNfcNci
#测试机型中删除后不影响NFC，部分机型可能存在掉NFC情况，如遇请删除这个

#/system/priv-app/MtpService
#媒体传输协议（电脑数据线传资料不要删）
#（默认未精简）

#/system/system_ext/app/BluetoothDsDaService
#蓝牙通话异常（耳机不出声）请删除此项

#/system/product/app/SimActivateService
#小米SIM激活服务，影响短信同步

#/system/product/app/MetokNLP
#小米相机自带的位置信息（照片位置信息）

#/system/product/app/XiaomiServiceFrameworkCN
#小米服务框架（默认未精简）

#
##########################################################################################