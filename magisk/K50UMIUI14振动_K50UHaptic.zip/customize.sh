ui_print "
—— 刷入时间$(date '+%g-%m-%d %H:%M:%S')

—— 面具版本$MAGISK_VER_CODE

—— 面具代号$MAGISK_VER

"
sleep 1
ui_print "  基于K50U制作振动，完美匹配 全局哒哒哒 "

set_perm_recursive $MODPATH 0 0 0755 0644
