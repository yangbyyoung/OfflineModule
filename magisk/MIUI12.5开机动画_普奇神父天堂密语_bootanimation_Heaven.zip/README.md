# Magisk Module Template

This `README.md` will be shown in Magisk Manager. Place any information / changelog / notes you like.

**Please update `README.md` if you want to submit your module to the online repo!**

Github has its own online markdown editor with a preview feature, you can use it to update your `README.md`! If you need more advanced syntax, check the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

For more information about modules and repos, please check the [official documentations](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)

---
# **MIUI12.5开机动画_普奇神父天堂密语**

## Description
修改默认开机动画/system/media/bootanimation.zip
替换为《JOJO的奇妙冒险》中普奇神父上天堂的密语：

『螺旋楼梯』
『独角仙』
『废墟街道』
『无花果塔』
『独角仙』
『德蕾莎之道』
『特异点』
『乔托』
『天使』
『绣花球』
『秘密皇帝』
『助我上天堂的…』
『正是乔斯达的血统啊！』

ps：可能有后续整合版本，十四句版本，还有添加Made in Heaven版本，不过得等我实验报告，推送，和期中考试过了再说，暂时厨不动了；

## Changelog
- Version 1.3 重切分片，剪短循环部分，减弱违和感
- Date 21.05.04

- Version 1.2 取消末尾帧长驻留，改为循环最后一句部分
- Date 21.05.04

- Version 1.1 抹去过多的黑屏，并保持末尾帧驻留
- Date 21.05.04

- Version 1.0 11句密语原始粗切版本
- Date 21.05.03


## Requirements
- 只适用于MIUI12.5默认开机动画
- 如有第三方主题或使用其他开机动画magisk模块请勿刷入

## Instructions
- 测试机型为小米9(cepheus)，
- 参考环境为Android 11/Magisk 22.1
- 仅在测试机型刷入成功且使用正常(没有其他机型
- 刷入机型和版本未做限制，请自行甄别慎重刷入

## Author
- andempathy.bx
- 酷安@截河wanduan
- http://www.coolapk.com/u/3839671
- 公众号@截河的推送小站
