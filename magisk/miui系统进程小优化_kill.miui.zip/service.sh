#!/system/bin/sh

sleep 5

#by longx
am kill mdnsd
killall -9 mdnsd
am kill mdnsd.rc
killall -9 mdnsd.rc

#am kill logd
#killall -9 logd
#am kill logd.rc
#killall -9 logd.rc

am kill mobile_log_d
killall -9 mobile_log_d
am kill mobile_log_d.rc
killall -9 mobile_log_d.rc

am kill dumpstate
killall -9 dumpstate
am kill dumpstate.rc
killall -9 dumpstate.rc


am kill emdlogger1
killall -9 emdlogger1
am kill emdlogger1.rc
killall -9 emdlogger1.rc

am kill emdlogger3
killall -9 emdlogger3
am kill emdlogger3.rc
killall -9 emdlogger3.rc

am kill mdlogger
killall -9 mdlogger
am kill mdlogger.rc
killall -9 mdlogger.rc

am kill aee.log-1-0
killall -9 aee.log-1-0
am kill aee.log-1-0.rc
killall -9 aee.log-1-0.rc
#echo 0 > /sys/block/loop0/queue/iostats