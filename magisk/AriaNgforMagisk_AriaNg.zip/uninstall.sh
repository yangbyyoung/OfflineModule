# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
killall -9 aria2c >/dev/null 2>&1
killall -9 lighttpd >/dev/null 2>&1
rm -rf /data/Aria2
