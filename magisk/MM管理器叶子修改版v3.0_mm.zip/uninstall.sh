# 这个脚本会在删除模块的时候执行

(until [ -f /data/media/0/mm ]; do sleep 20; done
rm /data/media/0/mm && rm /data/media/mm &) &
exit 0
