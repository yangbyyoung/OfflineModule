mn=`cat $MODPATH/MRNY`
chmod -R 0777 $MODPATH/*
ui_print "




—— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')


—— 面具版本$MAGISK_VER_CODE


—— 面具代号$MAGISK_VER




"
sleep 1.111
ui_print "依：指挥官，等一下，没有结束！"
sleep 1.111
ui_print "依：检测一下开机动画位置为了更好的兼容性！"
if [[ ! -f "/system/media/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到system目录的开机动画"
else
    sleep 1.111
    ui_print "——已检测到system目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "1080 2400 32
p 0 0 part0
p 0 0 part1" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 速度
    cp -rf part0 tmp/
    mv tmp/part0 tmp/part1
    #这里默认循环同一个画面，可以去掉复制部分变成直接移动
    mv part0 tmp/
    cd tmp
    $MODPATH/zip -0 Murong_Naiyi.zip part0/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip part1/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip *
    cd $MODPATH
    mv tmp/Murong_Naiyi.zip $MODPATH/
    echo "mount --bind $mn/Murong_Naiyi.zip /system/media/bootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp
    echo "依：文件配置完毕！可以享受新的开机动画啦！"
fi

if [[ ! -f "/product/media/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到product目录的开机动画"
else
    sleep 1.111
    ui_print "——已检测到product目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "1080 2400 32
p 0 0 part0
p 0 0 part1" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 速度
    cp -rf part0 tmp/
    mv tmp/part0 tmp/part1
    #这里默认循环同一个画面，可以去掉复制部分变成直接移动
    mv part0 tmp/
    cd tmp
    $MODPATH/zip -0 Murong_Naiyi.zip part0/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip part1/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip *
    cd $MODPATH
    mv tmp/Murong_Naiyi.zip $MODPATH/
    echo "mount --bind $mn/Murong_Naiyi.zip /product/media/bootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp
    echo "依：文件配置完毕！可以享受新的开机动画啦！"
fi

if [[ ! -f "/my_product/media/bootanimation/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到my_product目录的开机动画"
else
    sleep 1.111
    ui_print "——已检测到my_product目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "g 1080 2400 0 0 32
p 0 0 part0
p 0 0 part1" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 x/y坐标偏差 速度
    cp -rf part0 tmp/
    mv tmp/part0 tmp/part1
    #这里默认循环同一个画面，可以去掉复制部分变成直接移动
    mv part0 tmp/
    cd tmp
    $MODPATH/zip -0 Murong_Naiyi.zip part0/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip part1/*
    $MODPATH/zip -u -0 Murong_Naiyi.zip *
    cd $MODPATH
    mv tmp/Murong_Naiyi.zip $MODPATH/
    echo "mount --bind $mn/Murong_Naiyi.zip /my_product/media/bootanimation/bootanimation.zip
mount --bind $mn/Murong_Naiyi.zip /my_product/media/bootanimation/rbootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp
    echo "依：文件配置完毕！可以享受新的开机动画啦！"
fi

echo "id=慕容奈依_开机动画
name=[AWA] 开机动画
version=慕容奈依
versionCode=606
author=依Yi+666
description=【开机动画模板，内置骁龙888开机动画】，已适配system，product，my_product分区的开机动画  [刷入时间：$(date '+%g-%m-%d %H:%M:%S')]
#我的建议是将“【开机动画模板，内置鲨鲨酱开机动画】”替换成开机动画的描述，然后在作者的“依Yi”后面加上作者名字如“author=依Yi+隔壁老王”
#但是实际上你不这么干我也干不了什么，总不能顺着网线敲你家门
" > module.prop
#这里是module.prop显示内容，一定要记得改！