cd ${0%/*}
chmod -R 777 .
. ./config.ini
./核心/"$exec".bin stop

"${0%/*}"/核心/yyds1 -d

# ./核心/"sohigh".bin start