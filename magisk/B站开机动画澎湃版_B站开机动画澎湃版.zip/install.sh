SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=true
PROPFILE=false
print_modname() {
 ui_print "B站开机动画澎湃版"
 ui_print "by–Murong_Naiyi和已婚"
}
on_install() {
 ui_print "- 少女祈禱中"
 unzip -o "$ZIPFILE" 'MRNY' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'Murong_Naiyi.zip' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'zip' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}