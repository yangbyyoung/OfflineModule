function MEM_1(){
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
if [ -e "$module_id/system/vendor/overlay" ];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
if [ -e "$module_id/system/product/overlay" ];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
}
echo ""
echo "
————————————————————🍂🍃🍂🍃
"
echo "
●————————①overlay 类模块检测————————●
"
echo "－overlay 类的magisk 模块与magisk (特指hide)冲突(指加剧内存泄露概率)。"
echo "－如果使用这类模块过程中存在卡顿，请卸载它。"
echo "－因为这类模块可能给你带来的负优化比优化更多。"
echo "－如果检测到这类模块会自动显示出来。"
echo "－如果无则进入到下一项检测。"
cd /data/adb/modules
for module_id in $(ls);do
if [[ -e $module_id/system/product/overlay ]] || [[ -e $module_id/system/vendor/overlay ]];then
echo "－以下列出的模块，即为带有overlay 类的模块。"
echo "－不要一股脑直接听我的，无脑的卸载。"
echo "－因为不是所有的overlay 类模块都是带来卡顿的。"
MEM_1 2>/dev/null
fi
done
echo "
————————————————————🍂🍃🍂🍃
"
