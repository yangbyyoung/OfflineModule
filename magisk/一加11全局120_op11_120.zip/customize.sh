 AUTOMOUNT=true
 echo "* ♥️吟惋兮♥️"
 
 echo "* 我的地板下有一具尸体"
 echo "* 和我长得一模一样"
 echo "* 却多了一丝稚气与天真"
 echo "* 不知何时木板被人打开了"
 echo "* 我并不担心"
 echo "* 毕竟这是大家让我埋的"
 echo "* 她是我，我不是她"
 echo "* 扭头出门，又是繁忙的一天"
