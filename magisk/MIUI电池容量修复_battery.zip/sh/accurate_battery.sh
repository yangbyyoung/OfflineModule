#!/system/bin/sh
MODDIR=${0%/*}

if [[ -f /sys/class/power_supply/bms/real_capacity ]]; then
    echo ' - 检测到/sys/class/power_supply/bms/real_capacity文件存在'
    capacity_file=/sys/class/power_supply/bms/real_capacity
    nohup ${MODDIR}/accurate_battery ${capacity_file} &
elif [[ -f /sys/class/power_supply/bms/capacity_raw ]]; then
    echo ' - 检测到/sys/class/power_supply/bms/capacity_raw文件存在'
    capacity_file=/sys/class/power_supply/bms/capacity_raw
    nohup ${MODDIR}/accurate_battery ${capacity_file} &
else
    echo '未找到真实电量文件，不支持此手机，模块刷入失败！'
    exit 1
fi
