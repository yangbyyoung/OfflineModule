tencenttbs="
#腾讯X5内核
/data/media/*/Tencent/tbs
"

video="
#微信聊天视频
/data/media/*/Tencent/micromsg/*/video
/data/media/*/Android/data/com.tencent.mm/MicroMsg/*/video
#QQ短视频（缓存的聊天小视频）
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/shortvideo
"

mmliteapp="
#微信小程序安装包
/data/data/com.tencent.mm/MicroMsg/*/appbrand/pkg/
/data/data/com.tencent.mm/files/liteapp
"

x5="
#x5内核
/data/data/com.tencent.mobileqq/app_tbs*
/data/data/com.tencent.mobileqq/app_tbs*
/data/data/com.tencent.mm/app_xwalk*
"

qqchatpic="
/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/chatpic
"
mmchatpic="
#微信聊天图片缓存
/data/media/*/Tencent/micromsg/*/image2
"
mmpypic="
#微信朋友友圈图片和视频
/data/media/*/Tencent/micromsg/*/sns
"

qqliteapp="
#QQ小程序
/data/data/com.tencent.mobileqq/files/minigame
/data/data/com.tencent.mobileqq/files/mini
"
#x5清理函数支持
rmthch(){
	if test -e "$1" ;then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
	fi
}

#小程序清理
function liteappclear(){
	for i in $qqliteapp $mmliteapp;do
		file=`find "$i" 2> /dev/null`
		rm -rf $file 2> /dev/null
	done
}

#视频清理
function videoclear(){
	for i in $video;do
		file=`find "$i" 2> /dev/null`
		rm -rf $file 2> /dev/null
	done
}


#x5相关清理
function x5lear(){
	for i in $tencenttbs $x5;do
		file=`find "$i" 2> /dev/null`
		rmthch $file 2> /dev/null
	done
}


#QQ聊天图片清理
function qqchatpicclear(){
	for i in $qqchatpic ;do
		rm -rf "$i"
	done
}

#微信聊天图片清理
function mmchatpicclear(){
	for i in $mmchatpic;do
		file=`find "$i" 2> /dev/null`
		rm -rf $file 2> /dev/null
	done
}


#微信朋友圈图片清理
function mmpypicclear(){
	for i in $mmpypic;do
		file=`find "$i" 2> /dev/null`
		rm -rf $file 2> /dev/null
	done
}

