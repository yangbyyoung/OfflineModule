echo ----------------------------
script_name="mb.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
    echo " $lastID $script_name 正在运行中……"
else
    echo -----你都没启动呢-----
fi
echo ----------------------------