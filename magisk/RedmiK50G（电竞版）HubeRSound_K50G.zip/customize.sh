SKIPUNZIP=0
MODDIR=${0%/*}
alias sh='/system/bin/sh'
a=$(getprop ro.system.build.version.release)

print_modname() {
  ui_print "***********************"
  ui_print "首次开机进入桌面后静置等待自动操作完毕"
  ui_print "Designed By Huber_HaYu 以及团队的支持"
  ui_print "***********************"
  #sleep 2
}

optional_audio() {
    
    sleep 1.5
    # Frist Boost GO！(/≧▽≦)/~
    setprop dolby.bass default
    setprop dolby.virtualizer 1
    #sleep 0.7
    cp -f $MODPATH/Dax_Dolby/optionals.prop /storage/emulated/0
}

dax_dolby() {
    MIUI_VER=$(grep "ro\.system\.build\.version\.incremental=" /system/build.prop | cut -d '=' -f 2)

    if [[ $MIUI_VER == *"DEV"* ]]; then
        #sleep 2
        echo "当前设备系统处于开发版本（B包）"
        cp -f $MODPATH/Dax_Dolby/Dev/dax-default.xml $MODPATH/system/vendor/etc/dolby
        cp -f $MODPATH/Dax_Dolby/Dev/dax.t $MODPATH/system/vendor/etc/dolby
        cp -f $MODPATH/Dax_Dolby/Dev/EQ/normal.xml $MODPATH/config
        else
            #sleep 2
            echo "当前设备系统处于稳定版（B包）"
            cp -f $MODPATH/Dax_Dolby/Dev/dax-default.xml $MODPATH/system/vendor/etc/dolby
            cp -f $MODPATH/Dax_Dolby/Dev/dax.t $MODPATH/system/vendor/etc/dolby
            cp -f $MODPATH/Dax_Dolby/Dev/EQ/normal.xml $MODPATH/config
    fi
}

BIN_LOAD() {
    echo "请选择想要的低频处理BIN固件"
    echo "音量+ ：小米10S | 音量- ：无压缩Ray修改版（最高音量会破音）"
    
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
            sleep 0.4
            cp -f $MODPATH/BIN/J2S/misound_res.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/J2S/misound_res_spk.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/J2S/misound_res_headphone.bin $MODPATH/system/vendor/lib/rfsa/adsp
        ;;
        *)
            cp -f $MODPATH/BIN/Ray/misound_res.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/Ray/misound_res_spk.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/Ray/misound_res_headphone.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/Ray/misound_karaokemix_res.bin $MODPATH/system/vendor/lib/rfsa/adsp
            cp -f $MODPATH/BIN/Ray/misound_karaoke_res.bin $MODPATH/system/vendor/lib/rfsa/adsp
            sleep 0.4
    esac
}

volume_table(){
    #此音量增益遵循新国标规则
    cp -f $MODPATH/config/volume/audio_policy_engine_default_stream_volumes.xml $MODPATH/system/vendor/etc
    cp -f $MODPATH/config/volume/audio_policy_engine_stream_volumes.xml $MODPATH/system/vendor/etc
    cp -f $MODPATH/config/volume/default_volume_tables.xml $MODPATH/system/vendor/etc
    cp -f $MODPATH/config/volume/audio_policy_volumes.xml $MODPATH/system/vendor/etc
}

boot_first_load(){
    update_path="/data/adb/modules_update/K50G"
    conf="/data/data/com.miui.misound/shared_prefs/mi_sound_preference.xml"
    pm disable com.miui.misound
    #pm clear com.miui.misound
    mkdir -p /data/data/com.miui.misound/shared_prefs
    cp -f $update_path/config/normal.xml $conf
    pm enable com.miui.misound
    am start --windowingMode 5 -n com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
    sleep 2.5
    am force-stop com.miui.misound
    am force-stop com.android.settings
    cp -f $update_path/system/app/MiSound/MiSound.apk $update_path/system/product/app/MiSound/MiSound.apk
    sleep 3
    cp -f $MODPATH/config/com.miui.misound_preferences.xml /data/data/com.miui.misound/shared_prefs
    sleep 1
    cp -f $MODPATH/config/Huber_K50G_GameAudioTurbo_5.1.wav /storage/emulated/0/JamesDSP/Convolver
    cp -f $MODPATH/config/Huber_K50G_GameAudioTurbo.wav /storage/emulated/0/JamesDSP/Convolver
    rm -rf /storage/emulated/0/Android/Hubert/AutoTap
    ui_print "Done."
}


set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
    chmod a+x "$MODPATH/Mly"
    chmod a+x "$MODPATH/Shadow3"
}

nfc_fix() {
    if [ $a == "13" ]; then
        ui_print " - 您是否安装/升级了最新的Magisk 26？"
        ui_print "这至关重要！错误的选择可能会导致卡米或NFC/Joyose丢失！"
        ui_print "   "
        sleep 0.6
        ui_print "- 如果不是Magisk 26，请按音量上键"
        ui_print "  "
        sleep 1s
        ui_print "- 如果是Magisk 26，请务必按音量下键！"
        sleep 0.4
        ui_print "  "
        ui_print "- 关于Magisk26的问题："
        ui_print "   如果安装后NFC依旧丢失，请重装模块并在安装时按音量上键"
        key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
        "KEY_VOLUMEUP")
            sleep 0.8
            
            ui_print "Android Version:$a"
            sleep 1
            mkdir -p $MODPATH/system/product/
            cp -r /product/pangu/system/* $MODPATH/system/product/
            
            ;;
            *)
                echo "Magisk 26设备，此阶段准备完毕"
        esac
        
        else
            ui_print "无需修复NFC 已跳过"
    fi
}

misound_fx() {
    
    echo "-  请选择是否禁用音质音效功能"
    echo "   禁用后声音更自然，但低音会大幅度削减"
    sleep 0.6
    echo "-  音量上键 禁用"
    echo "-  音量下键 保持原来的状态"
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
            sleep 0.8
            
            cp -f $MODPATH/misound_del/sku_cape/audio_effects.xml $MODPATH/system/vendor/etc/audio/sku_cape
            cp -f $MODPATH/misound_del/sku_cape/audio_effects.conf $MODPATH/system/vendor/etc/audio/sku_cape
            
            cp -f $MODPATH/misound_del/sku_diwali/audio_effects.xml $MODPATH/system/vendor/etc/audio/sku_diwali
            cp -f $MODPATH/misound_del/sku_diwali/audio_effects.conf $MODPATH/system/vendor/etc/audio/sku_diwali
            
            cp -f $MODPATH/misound_del/sku_taro/audio_effects.xml $MODPATH/system/vendor/etc/audio/sku_taro
            cp -f $MODPATH/misound_del/sku_taro/audio_effects.conf $MODPATH/system/vendor/etc/audio/sku_taro
            echo "已禁用音质音效，将启动高清晰直通模式"
        ;;
        *)
            
            echo "已跳过"
    esac
}

mly_auto() {
    
    sleep 0.5
    rm -rf $MODPATH/Mly
    rm -rf /data/adb/modules/K50G/Mly

}

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
#sleep 1.5
ui_print " ————————————————————————————————————————————————————"
ui_print " 本模块内的扬声器振幅、Virtual Bass，压限参数来自"
ui_print "       ---------酷安@Huber_HaYu @是Ray酱呀---------"
ui_print " ————————————————————————————————————————————————————"
#sleep 1
ui_print "请稍后..."
#sleep 3
ui_print "------------------------------"
ui_print "【团队感谢：SetoSkins(代码:service.sh) shadow3(代码:Mly) 灵聚、神生(代码)"
ui_print "mly墨临渊(调音、调试) 中二的番茄（辅助调音） big_chair(辅助调音) bug_casc(辅助调音) 是Ray酱呀(底层硬件调音)】"
ui_print "------------------------------"


optional_audio
dax_dolby
print_modname
BIN_LOAD
volume_table
boot_first_load
set_permissions
nfc_fix
misound_fx
mly_auto