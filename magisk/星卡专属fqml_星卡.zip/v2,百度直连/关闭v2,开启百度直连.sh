cd /data/v2,百度直连/
. ./config.ini
./核心/"$exec".bin stop
/data/v2,百度直连/核心/ZJL -o -d