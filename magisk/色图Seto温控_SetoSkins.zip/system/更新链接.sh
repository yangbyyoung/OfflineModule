am start -a 'android.intent.action.VIEW' -d 'https://github.com/zjw2017/SetoSkins_Thermal/releases' >/dev/null 2>&1
