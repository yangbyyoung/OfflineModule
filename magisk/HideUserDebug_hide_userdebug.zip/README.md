# Userdebug Hider

Simple magisk boot script module to hide usb debugging and userdebug rom