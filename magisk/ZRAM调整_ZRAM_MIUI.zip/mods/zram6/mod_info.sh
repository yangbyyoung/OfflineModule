mod_name="zram(4G)"
mod_install_desc="$mod_name"
mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"

if [ "`check_mod_install`" = "yes" ]; then
MOD_SKIP_INSTALL=true
fi

mod_install_yes()
{
if [ "`echo $B | egrep $R_B`" = "" ];then
ui_print "- 非miui设备，已停止加入miui zram配置文件。"  
else
mkdir -p $MODPATH/system/etc && cp $MOD_FILES_DIR/system/etc/mcd_default.conf $MODPATH/system/etc
fi
# 从文件附加值到 system.prop
add_sysprop_file $MOD_FILES_DIR/system1.prop
# 添加service.sh
add_service_sh $MOD_FILES_DIR/service.sh
return 0
}

mod_install_no()
{
    return 0
}

