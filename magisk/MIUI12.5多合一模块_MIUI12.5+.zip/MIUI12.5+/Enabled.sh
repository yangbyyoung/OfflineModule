#!/system/bin/sh
#获取时间
Time() {
    date '+%F  %H:%M:%S'
}

#日志打印目录
log=/storage/emulated/0/Android/MIUI12.5+/Logbook.log

#开启Google全家桶
sleep 1s
pm enable com.google.android.gms
pm enable com.google.android.gsf
pm enable com.android.vending
pm enable com.google.android.syncadapters.contacts
pm enable com.google.android.onetimeinitializer
sleep 1s
pm enable --user 999 com.google.android.gms
pm enable --user 999 com.google.android.gsf
echo "`Time`，已临时开启Google服务，重启后再次关闭" >>$log
