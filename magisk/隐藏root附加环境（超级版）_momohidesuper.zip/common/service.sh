#!/system/bin/sh
#本脚本由搞机助手自动创建
#作者：by：Han | 情非得已c
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：v1.3(3)
#特别鸣谢Magisk提供服务支持：by topjohnwu


MODDIR=${0%/*}
setenforce 1
echo 1 >/sys/fs/selinux/enforce
settings delete global hidden_api_policy
settings delete global hidden_api_policy_p_apps
settings delete global hidden_api_policy_pre_p_apps
settings delete global hidden_api_blacklist_exemptions
resetprop --delete dalvik.vm.dex2oat-flags