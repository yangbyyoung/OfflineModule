MODDIR=${0%/*}

#检测屏幕状态
SCREEN_STATUS_OPEN=$(dumpsys power | grep "mHoldingDisplaySuspendBlocker=" | cut -f2 -d '=')

#判断并执行文件
if [ "$SCREEN_STATUS_OPEN" = "false" ]; then
	sh $MODDIR/common.sh
fi
