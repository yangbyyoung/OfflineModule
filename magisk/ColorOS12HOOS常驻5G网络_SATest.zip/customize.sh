# Magisk 模块脚本配置

# 说明：
# 1. 将你要替换的文件放入 system 文件夹 (删除 placeholder 文件)
# 2. 将模块信息写入 module.prop
# 3. 在这个文件中进行设置 (customize.sh)
# 4. 如果你需要在启动时执行命令, 请把它们加入 post-fs-data.sh 或 service.sh
# 5. 如果需要修改系统属性(build.prop), 请把它加入 system.prop

# 如果你需要启用 Magic Mount 请把它设置为 true 不启用则设置为 false
# 大多数模块都需要启用它
AUTOMOUNT=true
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
#函数们
PROP="`ls /odm/etc/*/build.default.prop`"
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.vendor.device`"
var_id="`getprop ro.build.display.id`"
var_type="`getprop ro.oplus.image.my_product.type`"
var_version="`getprop ro.build.version.release`"
name="`grep_prop name $TMPDIR/module.prop`"
author="`grep_prop author $TMPDIR/module.prop`"
inf_version="`grep_prop version $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"

_grep_prop() {
  local REGEX="s/$1=//p"
  shift
  local FILES=$@
  [[ -z $FILES ]] && FILES="/system/build.prop /vendor/build.prop /product/build.prop"
  sed -n $REGEX $FILES 2>/dev/null | head -n 1
}

Model=$(_grep_prop ro\.product\.model)
[[ -z $Model ]] && Model=$(_grep_prop ro\.product\.vendor\.model)
# Brand=$(_grep_prop ro\.product\.model)
# [[ -z $Brand ]] && Brand=$(_grep_prop ro\.product\.vendor\.brand)
Brand=$(getprop ro.product.vendor.brand)
Kernel=$(uname -r)
Rom=$(getprop ro.build.display.id)
Device=$(getprop ro.product.device)
SDK=$(getprop ro.build.version.sdk)
Hardware=$(getprop ro.boot.hardware)
#CPU_ABI=$(getprop ro.product.cpu.abi)
CPU_ABI=$(getprop ro.build.device_family)
Android=$(getprop ro.build.version.release)
Market_Name=$(getprop ro.product.marketname)
Version=$(getprop ro.build.version.incremental)
versionName=$(pm dump com.android.thememanager | grep -m 1 versionName | sed -n 's/.*=//p')
[[ -e /sys/block/sda/size ]] && ROM_TYPE="UFS" || ROM_TYPE="eMMC"
[[ -e /proc/scsi/scsi ]] && UFS_MODEL=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $2}') && Particles=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $4}') || UFS_MODEL="unknown"

function get_magisk_lite(){
local until_function=/data/adb/magisk/util_functions.sh
grep -q lite_modules $until_function && echo "－ 🌙当前为: Magisk Lite◎$MAGISK_VER_CODE" || echo "－ ☀当前为: Magisk Official◎$MAGISK_VER_CODE" 
}

function hello_master(){
if test -n "$(getprop persist.sys.device_name)" ;then
	echo ""
	echo "－ ●您好！"$(getprop persist.sys.device_name)"！●"
	echo "－ ●欢迎使用本模块！●"
	get_magisk_lite
	echo ""
elif test -n "$(pm list users | cut -d : -f2 )" ;then
	echo ""
	echo  - ●您好！ $(pm list users | cut -d : -f2 )！●
	echo "－ ●欢迎使用本模块！●"
	get_magisk_lite
	echo ""
fi
}

echo ""
echo "∞————————————————————————∞"
hello_master
echo "  ※ 系统详情 ※"
  sleep 0.05
  echo "- 厂商信息: $Brand"
  sleep 0.05
  echo "- 设备型号: $Device"
  sleep 0.05
  echo "- 设备代号: $var_type"
  sleep 0.05
  echo "- 芯片型号: $Hardware $(($(cat /sys/devices/system/cpu/kernel_max) + 1))核"
  sleep 0.05
  echo "- 芯片架构: $CPU_ABI"
  sleep 0.05
  echo "- 安卓版本: Android $Android"
  sleep 0.05
  echo "- 系统版本: $Rom"
  sleep 0.05
  echo "- 基线版本: $Version"
  sleep 0.05
  echo "- 内存大小: $(cat /proc/meminfo | head -n 1 | awk '{print $2/1000}')MB"
  sleep 0.05
  echo "- 闪存类型: $ROM_TYPE"
  sleep 0.05
  echo "- 闪存颗粒: $UFS_MODEL $Particles"
  sleep 0.05
  echo "- 内核版本: `uname -a `"
  sleep 0.05
  echo "- 运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
  sleep 0.05
  echo "- Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
  sleep 0.1
echo "∞————————————————————————∞"
echo ""
echo "∞————————————————————————∞"
echo "  ※ 模块信息 ※"
echo "- 名称：$name    "
echo "- 作者：$author"
echo "- $description    "
echo "∞————————————————————————∞"
echo ""
echo "  ※ 刷入成功 ※"
echo "¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
echo "- 请重启设备."

set_perm_recursive  $MODPATH  0  0  0755  0755

# 列出你想在系统中直接删除的所有路径 一行一个路径 只能文件夹 不能文件 并且只能system里面的文件夹
# 此命令会删除下列路径文件夹内的所有文件
# /system/SuiNian666/ 只是一个例子 如果你要删除其他路径 请删除那一行例子
REPLACE="
/system/app/OPTelephonyCollectionData
/system/priv-app/OPNetworkSetting
/system/system_ext/app/OPEngMode
/system/system_ext/priv-app/OPNetworkSetting
/system/system_ext/app/OplusEngineerNetwork
/system/system_ext/priv-app/OplusNrMode
"

# 这个文件 (customize.sh) 将被安装脚本在 util_functions.sh 之后 source 化（设置为环境变量）
# 如果你需要自定义操作, 请在这里以函数方式定义它们 然后在 update-binary 里调用这些函数
# 不要直接向 update-binary 添加代码 因为这会让你很难将模块迁移到新的模板版本
# 尽量不要对 update-binary 文件做其他修改 尽量只在其中执行函数调用