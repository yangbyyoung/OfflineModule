rm -rf /data/system/package_cache/*
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch /data/user_de/0/com.miui.home/cache/debug_log
chmod 644 /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 644 /data/vendor/wlan_logs
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 644 /data/media/0/JuphoonService
rm -rf /data/system/package_cache/*