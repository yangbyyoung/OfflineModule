#! /vendor/bin/sh

MODDIR=${0%/*}

chmod 777 /system/bin/scene_swap_module.sh
sh /system/bin/scene_swap_module.sh >> $MODDIR/swap/swap.log
echo "全部完成！" >> $MODDIR/swap/swap.log

# 开机后trim一下，有助于尽量保持写入速度
busybox=/data/adb/magisk/busybox
if [[ -f $busybox ]]; then
  sm fstrim 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  # $busybox fstrim /data 2>/dev/null
  # $busybox fstrim /cache 2>/dev/null
  # $busybox fstrim /system 2>/dev/null
  sm fstrim 2>/dev/null
fi
