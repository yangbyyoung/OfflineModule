MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

QQservice="
com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService
com.tencent.mobileqq/com.tencent.mobileqq.app.CoreService
"

MMservice="
com.tencent.mm/com.tencent.mm.booter.CoreService
"

for i in $QQservice $MMservice;do 
pm enable  $i 
am startservice -n $i
done

MODPATH="/data/adb/lite_modules/WHCHATQQ"

btask="$MODPATH/keymod/D/bkeep"
if [ -e $btask ];then
chmod -R 777 $MODPATH/keymod/*
crond -c $MODPATH/keymod/B
fi

atask="$MODPATH/keymod/D/akeep"
if [ -e $atask ];then
chmod -R 777 $MODPATH/keymod/*
crond -c $MODPATH/keymod/A
fi