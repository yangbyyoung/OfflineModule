SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

SKIPUNZIP=0
ASH_STANDALONE=1

print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 - MIUI版本: $MIUI  $Version
 - 状态检测文件在：/data/adb/modules/ram
 
 23年3月25更新内容：
 - 修复ram.sh的cpu占用高于0%的情况。
 ****************************
 "
}


set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0777  0777
}