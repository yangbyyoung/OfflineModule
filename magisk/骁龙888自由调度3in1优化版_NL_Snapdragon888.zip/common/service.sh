MODDIR=${0%/*}

while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
  sleep 5
done

wait_until_login

sleep 15

pm disable "com.miui.systemAdSolution"
pm disable "com.miui.analytics"
pm disable "com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver"
pm disable "com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"
pm disable "com.xiaomi.joyose/.smartop.gamebooster.receiver.BoostRequestReceiver"
pm disable "com.xiaomi.joyose/.smartop.SmartOpService" 
pm disable "com.xiaomi.joyose.sysbase.MetokClService" 
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity"
pm disable "com.miui.daemon/.performance.cloudcontrol.CloudControlSyncService" 
pm disable "com.miui.daemon/.performance.statistics.services.GraphicDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.AtraceDumpService"
pm disable "com.miui.daemon/.performance.SysoptService"
pm disable "com.miui.daemon/.performance.MiuiPerfService"
pm disable "com.miui.daemon/.performance.server.ExecutorService"
pm disable "com.miui.daemon/.mqsas.jobs.EventUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.FileUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.HeartBeatUploadService"
pm disable "com.miui.daemon/.mqsas.providers.MQSProvider"
pm disable "com.miui.daemon/.performance.provider.PerfTurboProvider"
pm disable "com.miui.daemon/.performance.system.am.SysoptjobService"
pm disable "com.miui.daemon/.performance.system.am.MemCompactService"
pm disable "com.miui.daemon/.performance.statistics.services.FreeFragDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.DefragService"
pm disable "com.miui.daemon/.performance.statistics.services.MeminfoService"
pm disable "com.miui.daemon/.performance.statistics.services.IonService"
pm disable "com.miui.daemon/.performance.statistics.services.GcBoosterService"
pm disable "com.miui.daemon/.mqsas.OmniTestReceiver"
pm disable "com.miui.daemon/.performance.MiuiPerfService"

SMOOTH