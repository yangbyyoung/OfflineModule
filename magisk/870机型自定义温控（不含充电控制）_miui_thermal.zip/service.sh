dir1=/sys/devices/system/cpu/cpufreq
dir2=/sys/devices/system/cpu
dir3=/sys/devices/platform/soc/3d00000.qcom,kgsl-3d0
dir4=/sys/devices/system/cpu
dir5=/sys/class/power_supply/battery
cpu0_min=$dir1/policy0/scaling_min_freq
cpu0_max=$dir1/policy0/scaling_max_freq
cpu4_min=$dir1/policy4/scaling_min_freq
cpu4_max=$dir1/policy4/scaling_max_freq
cpu7_min=$dir1/policy7/scaling_min_freq
cpu7_max=$dir1/policy7/scaling_max_freq
cpu4_pw=$dir4/cpu4/online
cpu7_pw=$dir4/cpu7/online
gpu_max_clk=$dir3/kgsl/kgsl-3d0/max_gpuclk
gpu_clock=$dir3/kgsl/kgsl-3d0/thermal_pwrlevel
gpu_clock_min=$dir3/devfreq/3d00000.qcom,kgsl-3d0/min_freq
gpu_clock_max=$dir3/devfreq/3d00000.qcom,kgsl-3d0/max_freq
thermal_mod1=$dir4/cpufreq/policy0/scaling_governor
thermal_mod2=$dir4/cpufreq/policy4/scaling_governor
thermal_mod3=$dir4/cpufreq/policy7/scaling_governor
gpu_mod=$dir3/devfreq/3d00000.qcom,kgsl-3d0/governor
platform_check=$dir3/kgsl/kgsl-3d0/gpu_model
#Adreno660v2#
capacity=$dir5/capacity
warm=$dir5/temp
chmod 777 $dir5/*
chmod 777 $dir1/policy0/*
chmod 777 $dir1/policy4/*
chmod 777 $dir1/policy7/*
chmod 777 $dir4/cpu4/online
chmod 777 $dir4/cpu7/online
chmod 777 $gpu_max_clk
chmod 777 $gpu_clock
chmod 777 $dir3/devfreq/3d00000.qcom,kgsl-3d0/*
chmod 777 $platform_check
#############
#默认高性能配置
#   echo  '300000' > $cpu0_min
#   echo  '1708800' > $cpu0_max
#   echo  '710400' > $cpu4_min
#   echo  '2227200' > $cpu4_max
#   echo  '844800' > $cpu7_min
#   echo  '2496000' > $cpu7_max
#   echo  '0' > $gpu_clock
#   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
#   echo  '1' > $cpu4_pw
#   echo  '1' > $cpu7_pw
#   echo  'schedutil' > $thermal_mod1
#   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
#本调度只支持小米SDM888平台使用！！！
#如果检测到其它平台会自我卸载，功能全部永久失灵，不要乱使用！
#############
until [[ $jslx == true ]]; do
sleep 10s
chg_lv=`[[ -f $capacity ]] && cat $capacity`
#dev=`[[ -f $platform_check ]] && cat $platform_check`
data=`[[ -f $warm ]] && cat $warm`
#if [[ $dev -ne 'Adreno660v2' ]]; then
# rm -rf /data/adb/modules/miui_thermal/*
# exit
#elif [[ $dev -eq 'Adreno660v2' ]]; then
 if [[ $chg_lv -ge 6 ]]; then
  if [[ $data -le 50 ]]; then
   echo  '300000' > $cpu0_min
   echo  '1612800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1056000' > $cpu4_max
   echo  '6' > $gpu_clock
   echo  '1' > $cpu4_pw
   echo  '0' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
   echo  'powersave' > $gpu_mod
  elif [ "$data" -ge "51" ]&&[ "$data" -lt "399" ];then
   echo  '518400' > $cpu0_min
   echo  '1708800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '2150400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '2457600' > $cpu7_max
   echo  '2' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
 #  echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
  elif [ "$data" -ge "399" ]&&[ "$data" -lt "409" ];then
   echo  '518400' > $cpu0_min
   echo  '1708800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '2054400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '2265600' > $cpu7_max
   echo  '3' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#    echo  'simple_ondemand' > $gpu_mod
  elif [ "$data" -ge "409" ]&&[ "$data" -lt "419" ];then
   echo  '403200' > $cpu0_min
   echo  '1708800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1958400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '1977600' > $cpu7_max
   echo  '3' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
  elif [ "$data" -ge "419" ]&&[ "$data" -lt "429" ];then
   echo  '403200' > $cpu0_min
   echo  '1612800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1766400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '1862400' > $cpu7_max
   echo  '4' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
  elif [ "$data" -ge "429" ]&&[ "$data" -lt "439" ];then
   echo  '300000' > $cpu0_min
   echo  '1612800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1670400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '1632000' > $cpu7_max
   echo  '5' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
   elif [ "$data" -ge "439" ]&&[ "$data" -lt "449" ];then
    echo  '300000' > $cpu0_min
    echo  '1401600' > $cpu0_max
    echo  '710400' > $cpu4_min
    echo  '1574400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '1401600' > $cpu7_max
    echo  '6' > $gpu_clock
    echo  '305000000' > $gpu_clock_min
#    echo  '840000000' > $gpu_clock_max
    echo  '1' > $cpu4_pw
    echo  '1' > $cpu7_pw
    echo  'schedutil' > $thermal_mod1
    echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#    echo  'simple_ondemand' > $gpu_mod
   elif [ "$data" -ge "449" ]&&[ "$data" -lt "459" ];then
   echo  '300000' > $cpu0_min
   echo  '1516800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1286400' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '1190400' > $cpu7_max
   echo  '6' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'msm-adreno-tz' > $gpu_mod
   elif [ "$data" -ge "459" ]&&[ "$data" -lt "469" ];then
   echo  '300000' > $cpu0_min
   echo  '1344000' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '940800' > $cpu4_max
   echo  '844800' > $cpu7_min
   echo  '844800' > $cpu7_max
   echo  '6' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '1' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
   echo  'schedutil' > $thermal_mod3
#   echo  'msm-adreno-tz' > $gpu_mod
   elif [ "$data" -ge "469" ]&&[ "$data" -lt "479" ];then
   echo  '1075200' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '710400' > $cpu4_max
#   echo  '844800' > $cpu7_min
#   echo  '1900800' > $cpu7_max
   echo  '6' > $gpu_clock
#   echo  '305000000' > $gpu_clock_min
#   echo  '840000000' > $gpu_clock_max
   echo  '1' > $cpu4_pw
   echo  '0' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
#   echo  'simple_ondemand' > $gpu_mod
  elif [[ "$data" -ge "479" ]];then
   echo  '300000' > $cpu0_min
   echo  '787200' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '710400' > $cpu4_max
#   echo  '844800' > $cpu7_min
#   echo  '1900800' > $cpu7_max
   echo  '6' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
#   echo  '305000000' > $gpu_clock_max
   echo  '0' > $cpu4_pw
   echo  '0' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
#   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
#   echo  'powersave' > $gpu_mod
  elif [[ "$data" -ge "489" ]];then
   echo  '300000' > $cpu0_min
   echo  '300000' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '710400' > $cpu4_max
#   echo  '844800' > $cpu7_min
#   echo  '1900800' > $cpu7_max
   echo  '6' > $gpu_clock
   echo  '305000000' > $gpu_clock_min
   echo  '305000000' > $gpu_clock_max
   echo  '0' > $cpu4_pw
   echo  '0' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
#   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
#   echo  'powersave' > $gpu_mod
    fi
elif [[ $chg_lv -lt 6 ]]; then
   echo  '300000' > $cpu0_min
   echo  '1612800' > $cpu0_max
   echo  '710400' > $cpu4_min
   echo  '1171200' > $cpu4_max
   echo  '6' > $gpu_clock
   echo  '1' > $cpu4_pw
   echo  '0' > $cpu7_pw
   echo  'schedutil' > $thermal_mod1
   echo  'schedutil' > $thermal_mod2
#   echo  'schedutil' > $thermal_mod3
#   echo  'powersave' > $gpu_mod
 fi
#fi
done
#未经许可，谢绝转载、二次打包！#
