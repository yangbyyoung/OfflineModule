#!/system/bin/sh
#定义相关路径和文件
MODDIR=${0%/*}
DEX2OAT_CONFIG="/data/adb/Dex2oatBOOT/dex2oat基础配置.prop"
DEX2OAT_LOG="/data/adb/Dex2oatBOOT/dex2oat日志.log"
OPTIONALAPP_CONFIG="/data/adb/Dex2oatBOOT/dex2oat自选应用列表.prop"

#创建日志文件
if [ ! -d "$DEX2OAT_LOG" ]; then
	touch "$DEX2OAT_LOG"
fi

#读取配置
system_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^系统应用=" | cut -f2 -d '=')
tripartite_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^三方应用=" | cut -f2 -d '=')
optional_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^自选应用=" | cut -f2 -d '=')

#输出配置信息日志
echo "$(date "+%Y-%m-%d %H:%M:%S") I : 当前配置信息：
系统应用=$system_app
三方应用=$tripartite_app
自选应用=$optional_app
" >>"$DEX2OAT_LOG"

#运行dex2oat
echo "$(date "+%Y-%m-%d %H:%M:%S") I : 开始编译" >>"$DEX2OAT_LOG"
if [ "$system_app" != "无" ]; then
	. $MODDIR/mode/sapp.sh
elif [ "$tripartite_app" != "无" ]; then
	. $MODDIR/mode/3app.sh
elif [ "$optional_app" != "无" ]; then
	. $MODDIR/mode/oapp.sh
else
	echo "$(date "+%Y-%m-%d %H:%M:%S") E : 未选择应用进行编译" >>"$DEX2OAT_LOG"
fi
echo "$(date "+%Y-%m-%d %H:%M:%S") I : 编译完成" >>"$DEX2OAT_LOG"

