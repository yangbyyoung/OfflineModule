MODDIR=${0%/*}
local packagename=`sed -e '/#/d' $MODDIR/冻结包名.prop`
for i in $packagename
do
  pm enable $i >/dev/null 2>&1
done
