#!/bin/bash
DIR=$(dirname $(readlink -f $0))
#echo 当前目录：$DIR
info_path="/sdcard/Android/EasyClean"
path_num_d=$info_path/files/num_d
path_num_f=$info_path/files/num_f
path_dir_cfg=$info_path/Rules/CleanDIR.conf
path_file_cfg=$info_path/Rules/CleanFile.conf
path_white=$info_path/Rules/清理白名单.conf
path_log=$info_path/clean.log
path_forbid_clean=$info_path/files/forbid
#清理备份文件
num_dir=$(cat $path_num_d)
num_file=$(cat $path_num_f)
forbid=$(cat $path_forbid_clean)
if [ "$forbid" == "1" ];then
return
fi
echo 1 >$path_forbid_clean
Log_()
{
#强制输出日志
mode_test=1
if [ "$mode_test" == "1" ];then
 str=$*
 str="$(date '+%m/%d %H:%M:%S') |$str"
 echo "$str" 
 echo "$str" >> $path_log
fi
}
# 输出进程信息
Log_ "开始清理，进程ID及优先级：$(ps -eo pid,ni|grep $$)"
Load_whitelist(){
whitelist=$(cat $path_white)
whitelist=${whitelist// /}    #去空格
templist=""
for i in $whitelist
do
#对读出的数据进行处理
#取符号'#'左边，'#'后面是注释
i=${i//#/!!}  #替换'#'符号为'!!'
i=${i%%*!!*} #取'!!'左边
case $i in
"") 
#echo 忽略的信息
#为空，什么都不做
;;
*) 
#要处理的规则
if [ "$templist" != "" ];then
templist="$i|$templist"
else
templist="$i"
fi
;;
esac
#条件操作结束
done
whitelist=$templist
}
CleanDIR(){
for i in $cld
do
if [ -d $i ];then
let num_dir++
rm -rf $i
Log_ 清理目录：$i
fi
done
}
CleanFile(){
for i in $clf
do
if [ -f $i ];then
let num_file++
rm -rf $i
Log_ 清理文件：$i
fi
done
}
CleanFileConfig(){
filelist=$(cat $path_file_cfg)
filelist=${filelist// /}    #去空格
for i in $filelist
do
#对读出的数据进行处理
#取符号'#'左边，'#'后面是注释
i=${i//#/!!}  #替换'#'符号为'!!'
i=${i%%*!!*} #取'!!'左边
case $i in
"") 
#echo 忽略的信息
#为空，什么都不做
;;
*) 
#要处理的规则
if [ -f $i ];then
let num_file++
rm -rf $i
Log_ 清理自定义文件：$i
fi
;;
esac
#条件操作结束
done
}
CleanDirConfig(){
dirlist=$(cat $path_dir_cfg)
dirlist=${dirlist// /}    #去空格
for i in $dirlist
do

#取符号'#'左边，'#'后面是注释
i=${i//#/!!}  #替换'#'符号为'!!'
i=${i%%*!!*} #取'!!'左边
case $i in
"") 
#echo 忽略的信息
#为空，什么都不做
;;
*) 
#要处理的规则
if [ -d $i ];then
let num_dir++
rm -rf $i
Log_ 清理自定义目录：$i
fi
;;
esac
#条件操作结束
done
}
CleanDF(){
#清理文件夹
cld=$(find $path -maxdepth 2 -type d \( -name ".*" -or -name "*log*" \)|grep -vE $whitelist)
CleanDIR
#清理文件
clf=$(find $path -maxdepth 3 -type f \( -name ".*" -or -name "*log*" -or -name "*.old"  -or -name "*.bak" \)|grep -vE $whitelist)
CleanFile
}
#加载白名单
Load_whitelist
#开始清理自定义目录
CleanDirConfig
#开始清理自定义文件
CleanFileConfig

#开始清理当前目录
path="$DIR/"
CleanDF
#开始清理通用目录
path="/data/media/0/"
CleanDF
#微信清理
path="/storage/emulated/0/Android/data/com.tencent.mm/MicroMsg/"
clf=$(find $path -maxdepth 7 -type f -name "*.zip")
CleanFile
path="/data/data/com.tencent.mm/MicroMsg/"
cld=$(find $path -maxdepth 2 -type d -name "attachment")
CleanDIR
#保存计数
echo $num_dir >$path_num_d
echo $num_file >$path_num_f

sed -i "/^description=/c description=自动清理文件(夹)，添加瘦鹏鹏版“A循环清理5.3.7”清理规则，配置位于：/sdcard/Android/EasyClean/Rules/ ✨累计清理: $num_dir个目录 | $num_file个文件 ✨" "$DIR/module.prop"
echo 0 >$path_forbid_clean
Log_ 清理结束！
