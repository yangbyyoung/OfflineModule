mod_name()
{
echo "
 ————————————————————————————————
 
 - 模块: $MODID
 - 作者: $MODAUTHOR
 - 您的设备: $model
 - 系统版本: $version
 - 您当前的MIUI版本: $miui_version

   注意事项 & 模块介绍↓↓↓
 ! 此模块仅对温控做修改，不删除任何温控
 ! 此模块仅对温控做修改，不删除任何温控
 ! 此模块仅对温控做修改，不删除任何温控
 - 模块基础功能: ￡解除锁帧 ￡释放性能 ￡解除发热降亮度
 - 可选添加功能: ￡满血快充 ￡全局高刷 ￡屏蔽Joy&Daemon
 - MiuiDaemon这个系统软件是MIUI优化系统用的，针对某些应用
 做特殊的'优化'处理，用于平衡功耗性能和发热。因为这个，才会
 出现即使你删掉了温控某些游戏依然会掉帧这样的情况，而屏蔽掉
 它能让某些游戏有更好更稳的帧率，如果你要屏蔽它那我建议连joy
 一起屏蔽掉比较好
 
 ————————————————————————————————
 "
 }

volume_keytest()
{
  echo "--- 音量键测试 ---"
  echo "  请按音量+或-键"
  (/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
  return 0
}

volume_choose()
{
  while (true); do
  	/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
  	if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
		break
  	fi
  done
  if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
		return 1
  else
		return 0
  fi
}

volume_key_test()
{
  if volume_keytest; then
    KEYTEST=volume_choose
	echo "- 音量键测试完成"
  else
	KEYTEST=false
	echo " ！错误：没有检测到音量键选择"
  fi
  sleep 0.5
}

charge()
{
  if [ $KEYTEST != false ];then
    echo " "
    echo " "
    echo "--- 请选择是否添加满血快充(默认使用官方快充) ---"
    echo "  音量+键 = NO"
    echo "  音量-键 = YES"
    echo " "
    if "$KEYTEST"; then
    	cp -a "$MODPATH/mods/$model/Charging-Fast/"*"" $thermal
    	echo -n "- 满血快充  " >> $module
    	echo "- 已添加满血快充功能"
    else
    	cp -a "$MODPATH/mods/$model/Charging-Default/"*"" $thermal
    	echo -n "- 默认官方快充  " >> $module
    	echo "- 使用默认快充"
    fi
  else
    cp -a "$MODPATH/mods/$model/Charging-Default/"*"" $thermal
    echo -n "- 默认官方快充  " >> $module
    echo " "
    echo "- 已默认使用官方快充方案"
  fi
  sleep 0.5
}

fps()
{
  if [ $KEYTEST != false ];then
    echo " "
    echo " "
    echo "--- 请选择是否添加用全局高刷 ---"
    echo "  音量+键 = NO"
    echo "  音量-键 = YES"
    echo " "
    if "$KEYTEST"; then
      mkdir -p $app/PowerKeeper
      cp -a "$MODPATH/mods/Max FPS/"*"" $app/PowerKeeper
      echo -n "- 全局高刷  " >> $module
      echo "- 已添加全局高刷"
    else
      echo "- 不添加全局高刷"
    fi
  else
    echo " "
    echo "- 默认不添加全局高刷"
  fi
  sleep 0.5
}

fuck_joyose()
{
  if [ $KEYTEST != false ];then
    echo " "
    echo " "
    echo "--- 请选择是否屏蔽Joyose---"
    echo "  音量+键 = NO"
    echo "  音量-键 = YES"
    echo " "
    if "$KEYTEST"; then
      chattr -i /data/user/0/com.xiaomi.joyose
      mkdir -p $app/Joyose
      touch $app/Joyose/Joyose.apk
      echo -n "- 屏蔽joyose  " >> $module
      echo "- 已屏蔽joyose"
    else
    	echo "- 不屏蔽joyose"
    fi
  else
    echo " "
    echo "- 默认不屏蔽joyose"
  fi
  sleep 0.5
}

fuck_MiuiDaemon()
{
  if [ $KEYTEST != false ];then
    echo " "
    echo " "
    echo "--- 请选择是否屏蔽MiuiDaemon---"
    echo "  音量+键 = NO"
    echo "  音量-键 = YES"
    echo " "
    if "$KEYTEST"; then
      mkdir -p $app/MiuiDaemon
      touch $app/MiuiDaemon/MiuiDaemon.apk
      if [ $device != matisse ];then
      cp -a "$MODPATH/mods/$model/power_app_cfg/"*"" $thermal
      fi
      echo -n "- 屏蔽MiuiDaemon  " >> $module
      echo "- 已屏蔽MiuiDaemon"
    else
    	echo "- 不屏蔽MiuiDaemon"
    fi
  else
    echo " "
    echo "- 默认不屏蔽MiuiDaemon"
  fi
}

on_install()
{
 mkdir -p $thermal
}