MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

pose="
com.tencent.mm:sandbox*
com.tencent.mm:exdevice*
com.tencent.mobileqq:tool*
com.tencent.mobileqq:qzone*
com.tencent.mm:tools*
com.tencent.mobileqq:TMAssistantDownloadSDKService*
com.tencent.mobileqq:mini*
com.tencent.mm:hotpot*
com.tencent.mobileqq:hotpot*
"

function topapp(){
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d/ -f1 )
	echo "$app"
}

function killapp(){
for i in $pose;do
		pgrep -f "$i" | while read PID;do
		test "$(topapp)" = "com.tencent.mm" && break
		test "$(topapp)" = "com.tencent.mobileqq" && break
		kill -9 "$PID"
	done
done
}
function calculate_mem (){
	local memWE=$(dumpsys meminfo com.tencent.mm | grep -w "TOTAL" | head -n 1 | sed 's/[[:space:]]/\n/g' | sed '/^[[:space:]]*$/d' | sed -n '2p' )
	local memQQ=$(dumpsys meminfo com.tencent.mobileqq | grep -w "TOTAL" | head -n 1 | sed 's/[[:space:]]/\n/g' | sed '/^[[:space:]]*$/d' | sed -n '2p')
	test -n "$memQQ" -o  -n "$memWE"  && {
		if test -n "$memQQ" -a -n "$memWE" ;then
			memQQ=$(($memQQ/1024))
			memWE=$(($memWE/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB，微信运行内存 "$memWE" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		elif test -n "$memQQ" ;then
			memQQ=$(($memQQ/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		elif test -n "$memWE" ;then
			memWE=$(($memWE/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，微信运行内存 "$memWE" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		fi
	}
}

if test -e $MODPATH/disable -o -e $MODPATH/remove ;then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi


if test "$(topapp)" != "com.tencent.mm" -a "$(topapp)" != "com.tencent.mobileqq" ;then
killapp
calculate_mem
fi

