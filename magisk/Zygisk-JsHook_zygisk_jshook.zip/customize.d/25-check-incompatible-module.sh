MODULEDIR="$(magisk --path)/.magisk/modules"
for id in "riru_dreamland" "riru_edxposed" "riru_edxposed_sandhook" "taichi"; do
  if [ -d "$MODULEDIR/$id" ] && [ ! -f "$MODULEDIR/$id/disable" ] && [ ! -f "$MODULEDIR/$id/remove" ]; then
    ui_print "! Please disable or uninstall incompatible frameworks:"
    abort "! $id"
    break
  fi
done
