#!/system/bin/sh
MODDIR=${0%/*}
function auto_game_mode_node () {
	while true ; do
	echo 1 > /sys/class/meizu/main_tp/game_mode_node
	sleep 1
	done
}
auto_game_mode_node &