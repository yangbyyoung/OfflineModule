#!/system/bin/sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Codename: LKT
# Author: korom42 @ XDA
# Device: Multi-device
# Version : 5.1
# Last Update: 01.JAN.2021
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Give proper credits when using this in your work
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

BASEDIR="$(dirname $(readlink -f "$0"))"
SCRIPT_DIR="$BASEDIR/script"

write() {
    echo -n $2 > $1
}
mutate() 
{
    if [ -f ${2} ]; then
        chmod 0666 ${2}
        echo ${1} > ${2}
    fi
}
copy() {
    if [ "$4" == "" ];then
	if [ -e "$1" ]; then
    cat $1 > $2
	fi
	else
	src1=$(cat $1 | tr -d '\n')
	src2=$(cat $2 | tr -d '\n')
	if [ -e "$1" ] && [ -e "$2" ]; then
	write "$3" "${src1} $4 ${src2}"
	fi
	fi
}
round() {
  printf "%.$2f" "$1"
}
min()
{
    local m="$1"
    for n in "$@"
    do
        [ "$n" -lt "$m" ] && m="$n"
    done
    echo "$m"
}
max()
{
    local m="$1"
    for n in "$@"
    do
        [ "$n" -gt "$m" ] && m="$n"
    done
    echo "$m"
}
lock_val() {
	if [ -f ${2} ]; then
		chmod 0666 ${2}
		echo ${1} > ${2}
		chmod 0444 ${2}
	fi
}

is_int() { return $(test "$@" -eq "$@" > /dev/null 2>&1); }
    cores=$(cat /proc/stat | grep cpu[0-9] | wc -l)
    #cores=$(awk '{ if ($0~/^physical id/) { p=$NF }; if ($0~/^core id/) { cores[p$NF]=p$NF }; if ($0~/processor/) { cpu++ } } END { for (key in cores) { n++ } } END { if (n) {print n} else {print cpu} }' /proc/cpuinfo)
    coresmax=$(cat /sys/devices/system/cpu/kernel_max) 2>/dev/null
	if [ -z ${cores} ];then
	cores=$(( ${coresmax} + 1 ))
	fi
	
backup_gpu() {
if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
GPU_DIR="/sys/class/kgsl/kgsl-3d0"
else
GPU_DIR="/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0"
fi

for i in ${GPU_DIR}/*
do
chmod 0666 $i
done

#copy "$GPU_DIR/deep_nap_timer" "/data/adb/deep_nap_timer.txt"
#copy "$GPU_DIR/idle_timer" "/data/adb/idle_timer.txt"
}



###############################
# Abbreviations
###############################

SCHED="/proc/sys/kernel"
CPU="/sys/devices/system/cpu"
CPU_BOOST="/sys/module/cpu_boost/parameters"
KSGL="/sys/class/kgsl/kgsl-3d0"
DEVFREQ="/sys/class/devfreq"
LPM="/sys/module/lpm_levels/parameters"
MSM_PERF="/sys/module/msm_performance/parameters"
ST_TOP="/dev/stune/top-app"
ST_FORE="/dev/stune/foreground"
ST_BACK="/dev/stune/background"
SDA_Q="/sys/block/sda/queue"

###############################
# Powermodes helper functions
###############################

# $1:keyword $2:nr_max_matched
get_package_name_by_keyword()
{
    echo "$(pm list package | grep "$1" | head -n "$2" | cut -d: -f2)"
}

HAS_BAK=0
LOG="/data/LKT.prop"
RETRY_INTERVAL=10 #in seconds
MAX_RETRY=30
retry=${MAX_RETRY}
#wait for boot completed
A=$(getprop sys.boot_completed | tr -d '\r')

if [ -e $LOG ]; then
  rm $LOG;
fi;

#Profile Mode in USE
PARAM_BAK_FILE="/data/adb/.lkt_param_bak"

#On boot : Cleaning old files from previous instances/old LKT versions
if [ "$1" == "" ];then
if [ -e "/data/adb/boost1.txt" ]; then
rm "/data/adb/boost1.txt"
fi;
if [ -e "/data/adb/boost2.txt" ]; then
rm "/data/adb/boost2.txt"
fi;
if [ -e "/data/adb/boost3.txt" ]; then
rm "/data/adb/boost3.txt"
fi;
if [ -e "/data/adb/background.txt" ]; then
rm "/data/adb/background.txt"
fi;
if [ -e "/data/adb/foreground.txt" ]; then
rm "/data/adb/foreground.txt"
fi;
if [ -e "/data/adb/top-app.txt" ]; then
rm "/data/adb/top-app.txt"
fi;
if [ -e "/data/adb/dynamic_stune_boost.txt" ]; then
rm "/data/adb/dynamic_stune_boost.txt"
fi;
if [ -e "/data/adb/go_hispeed.txt" ]; then
rm "/data/adb/go_hispeed.txt"
fi;
if [ -e "/data/adb/go_hispeed_l.txt" ]; then
rm "/data/adb/go_hispeed_l.txt"
fi;
if [ -e "/data/adb/go_hispeed_b.txt" ]; then
rm "/data/adb/go_hispeed_b.txt"
fi;
if [ -e "/data/adb/idle_timer.txt" ]; then
rm "/data/adb/idle_timer.txt"
fi;
if [ -e "/data/adb/deep_nap_timer.txt" ]; then
rm "/data/adb/deep_nap_timer.txt"
fi;
backup_gpu
fi;

    if [ "$2" == "" ];then
    PROFILE="<PROFILEMODE>"
    #if [ -e "/data/adb/.lkt_cur_level" ]; then
	#PROFILE=$(cat /data/adb/.lkt_cur_level | tr -d '\n')
	#else
	#echo $PROFILE > "/data/adb/.lkt_cur_level"
	#fi
	
	bootdelay=5
    # Initiate uperf only once at boot only
    sh $BASEDIR/initsvc_uperf.sh
	
	else
    PROFILE=$1
	#rm "/data/adb/.lkt_cur_level"
	#if [ ! -f "/data/adb/.lkt_cur_level" ]; then
	#echo $1 > "/data/adb/.lkt_cur_level"
    #fi
	bootdelay=$2
	fi

    sleep ${bootdelay}
    export TZ=$(getprop persist.sys.timezone);
    #MOD Variable
    V="<VER>"
    dt=$(date '+%d/%m/%Y %H:%M:%S');
    sbusybox=`busybox | awk 'NR==1{print $2}'` 2>/dev/null
    # RAM variables
    TOTAL_RAM=$(awk '/^MemTotal:/{print $2}' /proc/meminfo) 2>/dev/null
    if [ $TOTAL_RAM -ge 1000000 ] && [ $TOTAL_RAM -lt 1500000 ]; then
    memg=$(awk -v x=$TOTAL_RAM 'BEGIN{print x/1000000}')
    memg=$(round ${memg} 1)
	else
    memg=$(awk -v x=$TOTAL_RAM 'BEGIN{printf("%.f\n", (x/1000000)+0.5)}')
    memg=$(round ${memg} 0)
    fi
    if [ ${memg} -gt 32 ];then
    memg=$(awk -v x=$memg 'BEGIN{printf("%.f\n", (x/1000)+0.5)}')
    fi
    # CPU variables
    arch_type=`uname -m` 2>/dev/null
    # Device infos
    BATT_LEV=`cat /sys/class/power_supply/battery/capacity | tr -d '\n'` 2>/dev/null
    BATT_TECH=`cat /sys/class/power_supply/battery/technology | tr -d '\n'` 2>/dev/null
    BATT_HLTH=`cat /sys/class/power_supply/battery/health | tr -d '\n'` 2>/dev/null
    BATT_TEMP=`cat /sys/class/power_supply/battery/temp | tr -d '\n'` 2>/dev/null
    BATT_VOLT=`cat /sys/class/power_supply/battery/batt_vol | tr -d '\n'` 2>/dev/null
    if [ "$BATT_LEV" == "" ];then
    BATT_LEV=`dumpsys battery | grep level | awk '{print $2}'` 2>/dev/null
    elif [ "$BATT_LEV" == "" ];then
    BATT_LEV=$(awk -F ': |;' '$1=="Percentage(%)" {print $2}' /sys/class/power_supply/battery/batt_attr_text) 2>/dev/null
    fi
    if [ "$BATT_TECH" == "" ];then
    BATT_TECH=`dumpsys battery | grep technology | awk '{print $2}'` 2>/dev/null
    fi
    if [ "$BATT_VOLT" == "" ];then
    BATT_VOLT=`dumpsys battery | awk '/^ +voltage:/ && $NF!=0{print $NF}'` 2>/dev/null
    elif [ "$BATT_VOLT" == "" ];then
    BATT_VOLT=$(awk -F ': |;' '$1=="VBAT(mV)" {print $2}' /sys/class/power_supply/battery/batt_attr_text) 2>/dev/null
    fi
    if [ "$BATT_TEMP" == "" ];then
    BATT_TEMP=`dumpsys battery | grep temperature | awk '{print $2}'` 2>/dev/null
    elif [ "$BATT_TEMP" == "" ];then
    BATT_TEMP=$(awk -F ': |;' '$1=="BATT_TEMP" {print $2}' /sys/class/power_supply/battery/batt_attr_text) 2>/dev/null
    fi
    if [ "$BATT_HLTH" == "" ];then
    BATT_HLTH=`dumpsys battery | grep health | awk '{print $2}'` 2>/dev/null
    if [ $BATT_HLTH -eq "2" ];then
    BATT_HLTH="Very Good"
    elif [ $BATT_HLTH -eq "3" ];then
    BATT_HLTH="Good"
    elif [ $BATT_HLTH -eq "4" ];then
    BATT_HLTH="Poor"
    elif [ $BATT_HLTH -eq "5" ];then
    BATT_HLTH="Sh*t"
    else
    BATT_HLTH="Unknown"
    fi
    elif [ "$BATT_HLTH" == "" ];then
    BATT_HLTH=$(awk -F ': |;' '$1=="HEALTH" {print $2}' /sys/class/power_supply/battery/batt_attr_text) 2>/dev/null
    if [ $BATT_HLTH -eq "1" ];then
    BATT_HLTH="Very Good"
    else
    BATT_HLTH="Unknown"
    fi
    fi
    BATT_TEMP=$(awk -v x=$BATT_TEMP 'BEGIN{print x/10}')
    BATT_VOLT=$(awk -v x=$BATT_VOLT 'BEGIN{print x/1000}')
    BATT_VOLT=$(round ${BATT_VOLT} 1) 
    VENDOR=`getprop ro.product.brand | tr '[:lower:]' '[:upper:]'`
    KERNEL="$(uname -r)"
    OS=`getprop ro.build.version.release`
    APP=`getprop ro.product.model`
    SOC=$(awk '/^Hardware/{print tolower($NF)}' /proc/cpuinfo | tr -d '\n') 2>/dev/null
    SOC0=`cat /sys/devices/soc0/machine  | tr -d '\n' | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC1=`cat /sys/devices/soc0/soc_id  | tr -d '\n' | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC2=`getprop ro.product.board | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC3=`getprop ro.product.platform | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC4=`getprop ro.board.platform | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC5=`getprop ro.chipname | tr '[:upper:]' '[:lower:]'` 2>/dev/null
    SOC6=`getprop ro.hardware | tr '[:upper:]' '[:lower:]'` 2>/dev/null
	soc_id=$(cat /sys/devices/soc0/id) 2>/dev/null
	soc_revision=$(cat /sys/devices/soc0/revision) 2>/dev/null
	adreno=0
	if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
	GPU_DIR="/sys/class/kgsl/kgsl-3d0"
	adreno=1
	elif [ -d "/sys/devices/platform/kgsl-3d0.0/kgsl/kgsl-3d0" ]; then
	GPU_DIR="/sys/devices/platform/kgsl-3d0.0/kgsl/kgsl-3d0"
	adreno=1
	elif [ -d "/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0" ]; then
	GPU_DIR="/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0"
	adreno=1
	elif [ -d "/sys/devices/soc.0/*.qcom,kgsl-3d0/kgsl/kgsl-3d0" ]; then
	GPU_DIR="/sys/devices/soc.0/*.qcom,kgsl-3d0/kgsl/kgsl-3d0"
	adreno=1
	elif [ -d "/sys/devices/platform/*.gpu/devfreq/*.gpu" ]; then
	GPU_DIR="/sys/devices/platform/*.gpu/devfreq/*.gpu"	
	adreno=0
	elif [ -d "/sys/devices/platform/gpusysfs" ]; then
	GPU_DIR="/sys/devices/platform/gpusysfs"
	adreno=0
	elif [ -d "/sys/devices/*.mali" ]; then
	GPU_DIR="/sys/devices/*.mali"
	adreno=0
	elif [ -d "/sys/devices/*.gpu" ]; then
	GPU_DIR="/sys/devices/*.gpu"
	adreno=0
	elif [ -d "/sys/devices/platform/mali.0" ]; then
	GPU_DIR="/sys/devices/platform/mali.0"
	adreno=0
	elif [ -d "/sys/devices/platform/mali-*.0" ]; then
	GPU_DIR="/sys/devices/platform/mali-*.0"
	adreno=0
	elif [ -d "/sys/module/mali/parameters" ]; then
	GPU_DIR="/sys/module/mali/parameters"
	adreno=0
	elif [ -d "/sys/class/misc/mali0" ]; then
	GPU_DIR="/sys/class/misc/mali0"
	adreno=0
	elif [ -d "/sys/kernel/gpu" ]; then
	GPU_DIR="/sys/kernel/gpu"
	adreno=0
	fi
	if [ -e "$GPU_DIR/devfreq/available_frequencies" ]; then
	GPU_FREQS=$(cat $GPU_DIR/devfreq/available_frequencies) 2>/dev/null
	elif [ -d "$GPU_DIR/devfreq/*.mali/available_frequencies" ]; then
	GPU_FREQS=$(cat $GPU_DIR/devfreq/*.mali/available_frequencies) 2>/dev/null
	elif [ -d "$GPU_DIR/device/devfreq/*.gpu/available_frequencies" ]; then
	GPU_FREQS=$(cat $GPU_DIR/device/devfreq/*.gpu/available_frequencies) 2>/dev/null
	elif [ -d "$GPU_DIR/device/available_frequencies" ]; then
	GPU_FREQS=$(cat $GPU_DIR/device/available_frequencies) 2>/dev/null
	fi

	if [ -e "$GPU_DIR/devfreq/available_governors" ]; then
	GPU_GOV=$(cat $GPU_DIR/devfreq/available_governors) 2>/dev/null
	elif [ -d "$GPU_DIR/devfreq/*.mali/available_governors" ]; then
	GPU_GOV=$(cat $GPU_DIR/devfreq/*.mali/available_governors) 2>/dev/null
	elif [ -d "$GPU_DIR/device/devfreq/*.gpu/available_governors" ]; then
	GPU_GOV=$(cat $GPU_DIR/device/devfreq/*.gpu/available_governors) 2>/dev/null
	elif [ -d "$GPU_DIR/device/available_governors" ]; then
	GPU_GOV=$(cat $GPU_DIR/device/available_governors) 2>/dev/null
	fi

	if [ -e "$GPU_DIR/gpu_model" ]; then
	GPU_MODEL=$(cat $GPU_DIR/gpu_model) 2>/dev/null
	elif [ -d "$GPU_DIR/*.mali/gpu_model" ]; then
	GPU_MODEL=$(cat $GPU_DIR/*.mali/gpu_model) 2>/dev/null
	elif [ -d "$GPU_DIR/device/*.gpu/gpu_model" ]; then
	GPU_MODEL=$(cat $GPU_DIR/device/*.gpu/gpu_model) 2>/dev/null
	elif [ -d "$GPU_DIR/device/gpu_model" ]; then
	GPU_MODEL=$(cat $GPU_DIR/device/gpu_model) 2>/dev/null
	fi


    LOGDEBUG() {
        echo "[$(date +'%H:%M:%S')][I] ${1}" |  tee -a $LOG;
    }
   
    LOGDATA() {
        echo $1 |  tee -a $LOG;
    }
   
_get_nr_core()
{
    echo "$(cat /proc/stat | grep cpu[0-9] | wc -l)"
}

_is_aarch64()
{
    if [ "$(getprop ro.product.cpu.abi)" == "arm64-v8a" ]; then
        echo "true"
    else
        echo "false"
    fi
}

_is_eas()
{
    if [ "$(grep sched /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors)" != "" ]; then
        echo "true"
    else
        echo "false"
    fi
}

# $1:cpuid
_get_maxfreq()
{
    local fpath="/sys/devices/system/cpu/cpu$1/cpufreq/scaling_available_frequencies"
    local maxfreq="0"

    if [ ! -f "$fpath" ]; then
        echo ""
        return
    fi

    for f in $(cat $fpath); do
        [ "$f" -gt "$maxfreq" ] && maxfreq="$f"
    done
    echo "$maxfreq"
}

_get_socid()
{
    if [ -f /sys/devices/soc0/soc_id ]; then
        echo "$(cat /sys/devices/soc0/soc_id)"
    else
        echo "$(cat /sys/devices/system/soc/soc0/id)"
    fi
}

_get_sm6150_type()
{
    [ -f /sys/devices/soc0/soc_id ] && SOC_ID="$(cat /sys/devices/soc0/soc_id)"
    [ -f /sys/devices/system/soc/soc0/id ] && SOC_ID="$(cat /sys/devices/system/soc/soc0/id)"
    case "$SOC_ID" in
    365 | 366) echo "sdm730" ;;
    355 | 369) echo "sdm675" ;;
    esac
}

_get_sdm865_type()
{
    local ddr_type4="07"
	local ddr_type5="08"
    local ddr_type
    ddr_type="$(od -An -tx /proc/device-tree/memory/ddr_device_type)"
    if [ ${ddr_type:4:2} == $ddr_type5 ]; then
        echo "sdm865_lp5"
    elif [ ${ddr_type:4:2} == $ddr_type4 ]; then
        echo "sdm865_lp4x"
    else
        echo "sdm865_lp5"
    fi
}

_get_sdm76x_type()
{
    if [ "$(cat /sys/devices/soc0/revision)" == "2.0" ]; then
        echo "sdm768"
    else
        echo "sdm765"
    fi
}

_get_msm8916_type()
{
    case "$(_get_socid)" in
    "206"|"247"|"248"|"249"|"250") echo "msm8916" ;;
    "233"|"240"|"242") echo "sdm610" ;;
    "239"|"241"|"263"|"268"|"269"|"270"|"271") echo "sdm616" ;;
    *) echo "msm8916" ;;
    esac
}

_get_msm8952_type()
{
    case "$(_get_socid)" in
    "264"|"289")
        echo "msm8952"
    ;;
    *)
        if [ "$(_get_nr_core)" == "8" ]; then
            echo "sdm652"
        else
            echo "sdm650"
        fi
    ;;
    esac
}

_get_sdm636_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm636_eas"
    else
        echo "sdm636_hmp"
    fi
}

_get_sdm660_type()
{
    local b_max
    b_max="$(_get_maxfreq 4)"
    # sdm660 & sdm636 may share the same platform name
    if [ "$b_max" -gt 2000000 ]; then
        if [ "$(_is_eas)" == "true" ]; then
            echo "sdm660_eas"
        else
            echo "sdm660_hmp"
        fi
    else
        echo "$(_get_sdm636_type)"
    fi

}

_get_sdm626_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm626_eas"
    else
        echo "sdm626_hmp"
    fi
}

_get_sdm625_type()
{
    local b_max
    b_max="$(_get_maxfreq 4)"
    # sdm625 & sdm626 may share the same platform name
    if [ "$b_max" -lt 2100000 ]; then
        if [ "$(_is_eas)" == "true" ]; then
            echo "sdm625_eas"
        else
            echo "sdm625_hmp"
        fi
    else
        echo "$(_get_sdm626_type)"
    fi
}

_get_sdm835_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm835_eas"
    else
        echo "sdm835_hmp"
    fi
}

_get_sdm82x_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm82x_eas"
        return
    fi
    
    local l_max
    local b_max
    l_max="$(_get_maxfreq 0)"
    b_max="$(_get_maxfreq 2)"

    # sdm820 OC 1728/2150
    if [ "$l_max" -lt 1800000 ]; then
        if [ "$b_max" -gt 2100000 ]; then
            # 1593/2150
            echo "sdm820_hmp"
        elif [ "$b_max" -gt 1900000 ]; then
            # 1593/1996
            echo "sdm821_v1_hmp"
        else
            # 1363/1824
            echo "sdm820_hmp"
        fi
    else
        if [ "$b_max" -gt 2300000 ]; then
            # 2188/2342
            echo "sdm821_v3_hmp"
        else
            # 1996/2150
            echo "sdm821_v2_hmp"
        fi
    fi
}

_get_e8895_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "e8895_eas"
    else
        echo "e8895_hmp"
    fi
}



# $1:board_name
_get_cfgname()
{
    local ret
    case "$1" in
    "kona")          ret="$(_get_sdm865_type)" ;;
    "msmnile")       ret="sdm855" ;;
    "sdm845")        ret="sdm845" ;;
    "lito")          ret="$(_get_sdm76x_type)" ;;
    "sm6150")        ret="$(_get_sm6150_type)" ;;
    "sdm710")        ret="sdm710" ;;
    "msm8916")       ret="$(_get_msm8916_type)" ;;
    "msm8939")       ret="sdm616" ;;
    "msm8952")       ret="$(_get_msm8952_type)" ;;
    "msm8953")       ret="$(_get_sdm625_type)" ;;
    "msm8953pro")    ret="$(_get_sdm626_type)" ;;
    "sdm660")        ret="$(_get_sdm660_type)" ;;
    "sdm636")        ret="$(_get_sdm636_type)" ;;
    "trinket")       ret="sdm665" ;;
    "msm8976")       ret="sdm652" ;;
    "msm8956")       ret="sdm650" ;;
    "msm8998")       ret="$(_get_sdm835_type)" ;;
    "msm8996")       ret="$(_get_sdm82x_type)" ;;
    "msm8996pro")    ret="$(_get_sdm82x_type)" ;;
    "universal9825") ret="e9820";;
    "universal9820") ret="e9820";;
    "universal9810") ret="e9810" ;;
    "universal8895") ret="$(_get_e8895_type)" ;;
    "universal8890") ret="e8890" ;;
    "universal7420") ret="e7420" ;;
    *)               ret="unsupported" ;;
    esac
    echo "$ret"
}
    SOC="${SOC//[[:space:]]/}"
    SOC=`echo $SOC | tr -d -c '[:alnum:]'`

	GPU_MIN="$(min $GPU_FREQS)"
	GPU_MAX="$(max $GPU_FREQS)"
	
	if [ ! -e ${GPU_FREQS} ]; then
	GPU_MIN=$(cat "$GPU_DIR/devfreq/min_freq") 2>/dev/null	
	GPU_MAX=$(cat "$GPU_DIR/devfreq/max_freq") 2>/dev/null	
	fi

	if [ ! -e ${GPU_DIR}/devfreq/max_freq ] && [ ! -e ${GPU_DIR}/devfreq/max_freq ]; then
	GPU_MIN=$(cat "$GPU_DIR/gpuclk") 2>/dev/null	
	GPU_MAX=$(cat "$GPU_DIR/max_gpuclk") 2>/dev/null	
    fi


	if [ ${PROFILE} -eq 0 ];then
	PROFILE_M="powersave"
	elif [ ${PROFILE} -eq 1 ];then
	PROFILE_M="balanced"
	elif [ ${PROFILE} -eq 2 ];then
	PROFILE_M="performance"
	fi
	
		
	coresbig=$(( ${cores} / 2 ))

    maxfreq="$(_get_maxfreq $coresbig)"
    maxfreq=$(awk -v x=$maxfreq 'BEGIN{print x/1000000}')
    maxfreq=$(round ${maxfreq} 2)
	
	
    GPU_MAX_MHz=$(awk -v x=$GPU_MAX 'BEGIN{print x/1000000}')
    GPU_MAX_MHz=$(round ${GPU_MAX_MHz} 0)
	
    target=${SOC}
    cfgname="$(_get_cfgname $target)"
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC0}
        cfgname="$(_get_cfgname $target)"
    fi
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC1}
        cfgname="$(_get_cfgname $target)"
    fi
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC2}
        cfgname="$(_get_cfgname $target)"
    fi
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC3}
        cfgname="$(_get_cfgname $target)"
    fi
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC4}
        cfgname="$(_get_cfgname $target)"
    fi
    if [ "$cfgname" == "unsupported" ]; then
        target=${SOC5}
        cfgname="$(_get_cfgname $target)"
    fi
	if [ "$cfgname" == "unsupported" ]; then
        target=${SOC6}
        cfgname="$(_get_cfgname $target)"
    fi
	
	LOGDATA "#~~~~~ LKT™ $V" 
	LOGDATA "#~~~~~ PROFILE : ${PROFILE_M}"
    LOGDATA "#  LAST RUN : $(date +"%d-%m-%Y %r")" 
    LOGDATA "#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" 
    LOGDATA "#  VENDOR : $VENDOR" 
    LOGDATA "#  DEVICE : $APP" 
if [ ${GPU_MAX} -ne 0 ] || [ ! -z ${GPU_MODEL} ] ;then
    LOGDATA "#  GPU : $GPU_MODEL @ $GPU_MAX_MHz MHz"
fi
if [ ${maxfreq} -ne 0 ] || [ ! -z ${maxfreq} ] ;then
    LOGDATA "#  CPU : ${target} @ $maxfreq GHz ($(_get_nr_core) x cores)"
	else
    LOGDATA "#  CPU : ${target}"
fi
    LOGDATA "#  RAM : $memg GB"
    LOGDATA "#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" 
    LOGDATA "#  ANDROID : $OS" 
    LOGDATA "#  KERNEL : $KERNEL" 
    LOGDATA "#  BUSYBOX  : $sbusybox" 
    LOGDATA "# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	
# =========
# Battery Check
# =========
LOGDATA "#  BATTERY LEVEL: $BATT_LEV % "
LOGDATA "#  BATTERY TECHNOLOGY: $BATT_TECH"
LOGDATA "#  BATTERY HEALTH: $BATT_HLTH"
LOGDATA "#  BATTERY TEMP: $BATT_TEMP °C"
LOGDATA "#  BATTERY VOLTAGE: $BATT_VOLT VOLTS "
LOGDATA "# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" 
    if [ -z ${sbusybox} ]; then
	LOGDEBUG "#  [WARNING] busybox not found"
	fi

# =========
# MISC  Tweaks
# =========

# Disable KSM to save CPU cycles
if [ -e '/sys/kernel/mm/uksm/run' ]; then
LOGDEBUG "disabling  uKSM"
write '/sys/kernel/mm/uksm/run' 0;
setprop ro.config.uksm.support false;
elif [ -e '/sys/kernel/mm/ksm/run' ]; then
LOGDEBUG "disabling  KSM"
write '/sys/kernel/mm/ksm/run' 0;
setprop ro.config.ksm.support false;
fi;
if [ -e '/sys/kernel/fp_boost/enabled' ]; then
write '/sys/kernel/fp_boost/enabled' 1;
LOGDEBUG "enabling fingerprint boost"
fi;

# =========
# GPU Tweaks
# =========
if [ -e "/sys/module/adreno_idler" ]; then

	if [ ${PROFILE} -eq 0 ];then
	LOGDEBUG "enabling gpu adreno idler " 
	write /sys/module/adreno_idler/parameters/adreno_idler_active "Y"
	write /sys/module/adreno_idler/parameters/adreno_idler_idleworkload "10000"
	write /sys/module/adreno_idler/parameters/adreno_idler_downdifferential '40'
	write /sys/module/adreno_idler/parameters/adreno_idler_idlewait '24'
	else
	LOGDEBUG "enabling gpu adreno idler " 
	write /sys/module/adreno_idler/parameters/adreno_idler_active "Y"
	write /sys/module/adreno_idler/parameters/adreno_idler_idleworkload "6000"
	write /sys/module/adreno_idler/parameters/adreno_idler_downdifferential '15'
	write /sys/module/adreno_idler/parameters/adreno_idler_idlewait '15'
	fi
fi

# Various GPU enhancements
if [ ${GPU_MAX} -eq 0 ] || [ -z ${GPU_MODEL} ] ;then
GPU_PWR=$(cat $GPU_DIR/num_pwrlevels) 2>/dev/null
GPU_PWR=$(($GPU_PWR-1))
GPU_BATT=$(awk -v x=$GPU_PWR 'BEGIN{print((x/2)-0.5)}')
GPU_BATT=$(round ${GPU_BATT} 0)
GPU_TURBO=$(awk -v x=$GPU_PWR 'BEGIN{print((x/2)+0.5)}')
GPU_TURBO=$(round ${GPU_TURBO} 0)
gpu_idle=$(cat /data/adb/idle_timer.txt) 2>/dev/null
idle_batt=$(awk -v x=$gpu_idle 'BEGIN{print x*2}')
idle_balc=$(awk -v x=$gpu_idle 'BEGIN{print (x*3)/4}')
idle_perf=$(awk -v x=$gpu_idle 'BEGIN{print x/2}')
gpu_nap=$(cat /data/adb/deep_nap_timer.txt) 2>/dev/null
nap_batt=$(awk -v x=$gpu_nap 'BEGIN{print x*2}')
nap_balc=$(awk -v x=$gpu_nap 'BEGIN{print (x*3)/4}')
nap_perf=$(awk -v x=$gpu_nap 'BEGIN{print x/2}')
idle_batt=$(round ${idle_batt} 0)
idle_balc=$(round ${idle_balc} 0)
idle_perf=$(round ${idle_perf} 0)
nap_batt=$(round ${nap_batt} 0)
nap_balc=$(round ${nap_balc} 0)
nap_perf=$(round ${nap_perf} 0)
#if [[ "$GPU_GOV" == *"simple_ondemand"* ]]; then
#write "$GPU_DIR/devfreq/governor" "simple_ondemand"
#fi
lock_val $GPU_MAX "$GPU_DIR/max_gpuclk"
lock_val $GPU_MAX "$GPU_DIR/devfreq/max_freq" 
lock_val $GPU_MIN "$GPU_DIR/devfreq/min_freq" 
lock_val $GPU_MIN "$GPU_DIR/devfreq/target_freq" 

lock_val 0 "$GPU_DIR/throttling"
lock_val 0 "$GPU_DIR/force_no_nap"
lock_val 1 "$GPU_DIR/bus_split"
lock_val 0 "$GPU_DIR/force_bus_on"
lock_val 0 "$GPU_DIR/force_clk_on"
lock_val 0 "$GPU_DIR/force_rail_on"
write "/proc/gpufreq/gpufreq_limited_thermal_ignore" 1
write "/proc/mali/dvfs_enable" 1

	if [ ${PROFILE} -eq 0 ];then
lock_val $GPU_BATT "$GPU_DIR/max_pwrlevel"
lock_val $GPU_PWR "$GPU_DIR/min_pwrlevel"
lock_val 0 "$GPU_DIR/force_no_nap"
#lock_val $nap_batt "$GPU_DIR/deep_nap_timer"
#lock_val $idle_batt "$GPU_DIR/idle_timer"
#chmod 0644 "/sys/devices/14ac0000.mali/dvfs"
#chmod 0644 "/sys/devices/14ac0000.mali/dvfs_max_lock"
#chmod 0644 "/sys/devices/14ac0000.mali/dvfs_min_lock"
	elif [ ${PROFILE} -eq 1 ];then
lock_val 0 "$GPU_DIR/max_pwrlevel"
lock_val $GPU_PWR "$GPU_DIR/min_pwrlevel"
lock_val 0 "$GPU_DIR/force_no_nap"
#lock_val $idle_balc "$GPU_DIR/deep_nap_timer"
#lock_val $nap_balc "$GPU_DIR/idle_timer"
	elif [ ${PROFILE} -eq 2 ];then
lock_val 0 "$GPU_DIR/max_pwrlevel"
lock_val $GPU_TURBO "$GPU_DIR/min_pwrlevel"
lock_val 1 "$GPU_DIR/force_no_nap"
lock_val 0 "$GPU_DIR/bus_split"
lock_val 1 "$GPU_DIR/force_bus_on"
lock_val 1 "$GPU_DIR/force_clk_on"
lock_val 1 "$GPU_DIR/force_rail_on"
#lock_val $nap_perf "$GPU_DIR/deep_nap_timer"
#lock_val $idle_perf  "$GPU_DIR/idle_timer" 
	fi
	
for i in ${GPU_DIR}/devfreq/*
do
chmod 0644 $i
done
for i in ${GPU_DIR}/*
do
chmod 0644 $i
done
fi

# =========
# RAM TWEAKS
# =========
LOGDEBUG "applying memory optimizations.. be patient" 
#run once on boot only
if [[ -z $2 ]];then
sh $SCRIPT_DIR/mem_opt_main.sh
else
LOGDEBUG "memory is already running optimal configuration" 
fi

# =========
# I/O TWEAKS
# =========
LOGDEBUG "tuning storage i/o scheduler " 


# Cycle blocks to check current scheduler
for n in sda mmcblk0 mmcblk1 stl9 stl10 stl11 ;do
	# Pull raw scheduler info
	allSched=$(cat /sys/block/$n/queue/scheduler) 2>/dev/null

	# Parse only the active scheduler
	currSched=$(echo $allSched | cut -d "[" -f2 | cut -d "]" -f1) 2>/dev/null

if [[ "$allSched" == *"bfq"* ]];then
write /sys/block/$n/queue/scheduler "bfq"
elif [[ "$allSched" == *"maple"* ]]; then
write /sys/block/$n/queue/scheduler "maple"
sleep 1
	  write /sys/block/$n/queue/async_read_expire 666;
	  write /sys/block/$n/queue/async_write_expire 1666;
	  write /sys/block/$n/queue/fifo_batch 16;
	  write /sys/block/$n/queue/sleep_latency_multiple 5;
	  write /sys/block/$n/queue/sync_read_expire 333;
	  write /sys/block/$n/queue/sync_write_expire 1166;
	  write /sys/block/$n/queue/writes_starved 3;
elif [[ "$allSched" == *"kyber"* ]]; then
write /sys/block/$n/queue/scheduler "kyber"
fi;
sleep "0.01"
done;

if [ -e "/sys/block/sda/bdi/read_ahead_kb" ]; then
   if [ ${PROFILE} -eq 0 ];then
   write /sys/block/sda/bdi/read_ahead_kb 128
   else
   write /sys/block/sda/bdi/read_ahead_kb 512
   fi
fi

for i in /sys/block/*; do
	write $i/queue/add_random 0
	write $i/queue/iostats 0
   	write $i/queue/nomerges 2
   	write $i/queue/rotational 0
   	write $i/queue/rq_affinity 1
done;

# =========
# REDUCE DEBUGGING
# =========
LOGDEBUG "cutting excessive kernel debugging" 
#write "/sys/module/wakelock/parameters/debug_mask" 0
#write "/sys/module/userwakelock/parameters/debug_mask" 0
write "/sys/module/earlysuspend/parameters/debug_mask" 0
write "/sys/module/alarm/parameters/debug_mask" 0
write "/sys/module/alarm_dev/parameters/debug_mask" 0
write "/sys/module/binder/parameters/debug_mask" 0
write "/sys/devices/system/edac/cpu/log_ce" 0
write "/sys/devices/system/edac/cpu/log_ue" 0
write "/sys/module/binder/parameters/debug_mask" 0
write "/sys/module/bluetooth/parameters/disable_ertm" "Y"
write "/sys/module/bluetooth/parameters/disable_esco" "Y"
write "/sys/module/debug/parameters/enable_event_log" 0
write "/sys/module/dwc3/parameters/ep_addr_rxdbg_mask" 0 
write "/sys/module/dwc3/parameters/ep_addr_txdbg_mask" 0
write "/sys/module/edac_core/parameters/edac_mc_log_ce" 0
write "/sys/module/edac_core/parameters/edac_mc_log_ue" 0
write "/sys/module/glink/parameters/debug_mask" 0
write "/sys/module/hid_apple/parameters/fnmode" 0
write "/sys/module/hid_magicmouse/parameters/emulate_3button" "N"
write "/sys/module/hid_magicmouse/parameters/emulate_scroll_wheel" "N"
write "/sys/module/ip6_tunnel/parameters/log_ecn_error" "N"
write "/sys/module/lowmemorykiller/parameters/debug_level" 0
write "/sys/module/mdss_fb/parameters/backlight_dimmer" "N"
write "/sys/module/msm_show_resume_irq/parameters/debug_mask" 0
write "/sys/module/msm_smd/parameters/debug_mask" 0
write "/sys/module/msm_smem/parameters/debug_mask" 0 
write "/sys/module/otg_wakelock/parameters/enabled" "N" 
write "/sys/module/service_locator/parameters/enable" 0 
write "/sys/module/sit/parameters/log_ecn_error" "N"
write "/sys/module/smem_log/parameters/log_enable" 0
write "/sys/module/smp2p/parameters/debug_mask" 0
write "/sys/module/sync/parameters/fsync_enabled" "N"
write "/sys/module/touch_core_base/parameters/debug_mask" 0
write "/sys/module/usb_bam/parameters/enable_event_log" 0
write "/sys/module/printk/parameters/console_suspend" "Y"
write "/proc/sys/debug/exception-trace" 0
write "/proc/sys/kernel/printk" "0 0 0 0"
write "/proc/sys/kernel/compat-log" "0"
sysctl -e -w kernel.panic_on_oops=0
sysctl -e -w kernel.panic=0
if [ -e /sys/module/logger/parameters/log_mode ]; then
 write /sys/module/logger/parameters/log_mode 2
fi;
if [ -e /sys/module/printk/parameters/console_suspend ]; then
 write /sys/module/printk/parameters/console_suspend 'Y'
fi;
for i in $(find /sys/ -name debug_mask); do
 write $i 0;
done
for i in $(find /sys/ -name debug_level); do
 write $i 0;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
 write $i 0;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
 write $i 0;
done
for i in $(find /sys/ -name enable_event_log); do
 write $i 0;
done
for i in $(find /sys/ -name log_ecn_error); do
 write $i 0;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
 write $i 0;
done
# =========
# FIX DEEPSLEEP
# =========
for i in $(ls /sys/class/scsi_disk/); do
 lock_val 'temporary none' '/sys/class/scsi_disk/$i/cache_type';
done;
# =========
# TCP TWEAKS
# =========
algos=$(</proc/sys/net/ipv4/tcp_available_congestion_control);
if [[ $algos == *"westwood"* ]]
then
write /proc/sys/net/ipv4/tcp_congestion_control "westwood"
LOGDEBUG "enabling westwood tcp algorithm  " 
else
write /proc/sys/net/ipv4/tcp_congestion_control "cubic"
fi
# Increase WI-FI scan delay
# sqlite=/system/xbin/sqlite3 wifi_idle_wait=36000 
# =========
# Blocking Wakelocks
# =========
WK=0
if [ -e "/sys/module/bcmdhd/parameters/wlrx_divide" ]; then
write /sys/module/bcmdhd/parameters/wlrx_divide "8"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/bcmdhd/parameters/wlctrl_divide" ]; then
write /sys/module/bcmdhd/parameters/wlctrl_divide "8"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_bluetooth_timer" ]; then
write /sys/module/wakeup/parameters/enable_bluetooth_timer "Y"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_ipa_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_ipa_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_pno_wl_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_pno_wl_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wcnss_filter_lock_ws" ]; then
write /sys/module/wakeup/parameters/enable_wcnss_filter_lock_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/wlan_wake" ]; then
write /sys/module/wakeup/parameters/wlan_wake "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/wlan_ctrl_wake" ]; then
write /sys/module/wakeup/parameters/wlan_ctrl_wake "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/wlan_rx_wake" ]; then
write /sys/module/wakeup/parameters/wlan_rx_wake "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_msm_hsic_ws" ]; then
write /sys/module/wakeup/parameters/enable_msm_hsic_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_si_ws" ]; then
write /sys/module/wakeup/parameters/enable_si_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_si_ws" ]; then
write /sys/module/wakeup/parameters/enable_si_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_bluedroid_timer_ws" ]; then
write /sys/module/wakeup/parameters/enable_bluedroid_timer_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_ipa_ws" ]; then
write /sys/module/wakeup/parameters/enable_ipa_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_netlink_ws" ]; then
write /sys/module/wakeup/parameters/enable_netlink_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_netmgr_wl_ws" ]; then
write /sys/module/wakeup/parameters/enable_netmgr_wl_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_qcom_rx_wakelock_ws" ]; then
write /sys/module/wakeup/parameters/enable_qcom_rx_wakelock_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_timerfd_ws" ]; then
write /sys/module/wakeup/parameters/enable_timerfd_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_extscan_wl_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_extscan_wl_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_rx_wake_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_rx_wake_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_wake_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_wake_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_wow_wl_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_wow_wl_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_wlan_ctrl_wake_ws" ]; then
write /sys/module/wakeup/parameters/enable_wlan_ctrl_wake_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/smb135x_charger/parameters/use_wlock" ]; then
write /sys/module/smb135x_charger/parameters/use_wlock "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_smb135x_wake_ws" ]; then
write /sys/module/wakeup/parameters/enable_smb135x_wake_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_si_ws" ]; then
write /sys/module/wakeup/parameters/enable_si_wsk "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/wakeup/parameters/enable_bluesleep_ws" ]; then
write /sys/module/wakeup/parameters/enable_bluesleep_ws "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/bcmdhd/parameters/wlrx_divide" ]; then
write /sys/module/bcmdhd/parameters/wlrx_divide "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/bcmdhd/parameters/wlctrl_divide" ]; then
write /sys/module/bcmdhd/parameters/wlctrl_divide "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/xhci_hcd/parameters/wl_divide" ]; then
write /sys/module/xhci_hcd/parameters/wl_divide "N"
WK=$(( ${WK} + 1 ))
fi
if [ -e "/sys/module/smb135x_charger/parameters/use_wlock" ]; then
write /sys/module/smb135x_charger/parameters/use_wlock "N"
WK=$(( ${WK} + 1 ))
fi
if [ ${WK} -gt 0 ] ;then
LOGDEBUG "blocking ${WK} detected kernel wakelocks"
fi
if [ -e "/sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker" ]; then
LOGDEBUG "enabling boeffla wakelock blocker"
write /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker "wlan_pno_wl;wlan_ipa;wcnss_filter_lock;[timerfd];hal_bluetooth_lock;IPA_WS;sensor_ind;wlan;netmgr_wl;qcom_rx_wakelock;wlan_wow_wl;wlan_extscan_wl;NETLINK"
fi
# =========
# Google Services Drain fix by @Alcolawl @Oreganoian
# =========
LOGDEBUG "fixing SystemUpdateService drain"
su -c pm enable com.google.android.gms/.update.SystemUpdateActivity 
su -c pm enable com.google.android.gms/.update.SystemUpdateService
su -c pm enable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver 
su -c pm enable com.google.android.gms/.update.SystemUpdateService$Receiver 
su -c pm enable com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver 
su -c pm enable com.google.android.gsf/.update.SystemUpdateActivity 
su -c pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService$Receiver 
su -c pm enable com.google.android.gsf/.update.SystemUpdateService$SecretCodeReceiver

# =========
# CPU Tweaks
# =========
#Uperf
LOGDEBUG "Executing uperf powerhal"

	if [ ${PROFILE} -eq 0 ];then
	sh $SCRIPT_DIR/powercfg_main.sh "powersave"
	fi
	
	if [ ${PROFILE} -eq 1 ]; then
	sh $SCRIPT_DIR/powercfg_main.sh "balance"
	fi

	if [ ${PROFILE} -eq 2 ]; then
	sh $SCRIPT_DIR/powercfg_main.sh "performance"
	fi

uperf_log=$(cat sdcard/android/log_uperf.txt)
inject_log=$(cat cache/injector.log)

$(cat sdcard/android/log_uperf.txt >> $LOG)
LOGDEBUG "checking surfaceflinger SfAnalysis injection"
$(cat cache/injector.log >> $LOG)
sleep "0.01"

# FS-TRIM
LOGDEBUG "running fstrim "
fstrim -v /cache >> "/data/LKT.prop"
fstrim -v /data >> "/data/LKT.prop"
fstrim -v /system >> "/data/LKT.prop"
LOGDATA "#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" 
