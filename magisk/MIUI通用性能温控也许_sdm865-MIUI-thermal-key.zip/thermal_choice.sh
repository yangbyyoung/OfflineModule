#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g' | head -n 1
}

function echo_check_result(){
local check_item=`find /system /system_ext /vendor /product -iname "*thermal*.conf" -type f 2>/dev/null | grep -Ei 'pubgmhd|sgame' | wc -l`
if test "${check_item}" -ge "2" ;then
	echo "true"
fi
}

target_thermal="$(show_value '温控配置')"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	target_thermal="MTK_${target_thermal}"
	conf_file="${MODPATH}/thermal/MTK/$target_thermal.conf"
else
	conf_file="${MODPATH}/thermal/$target_thermal.conf"
fi

Game_thermal_choose="$(show_value '游戏温控配置')"


if test "$(echo_check_result)" = "true" ;then
	target_thermal="${target_thermal}"
	conf_file="${MODPATH}/thermal/old_thermal/$target_thermal.conf"
	echo "- 您已选择 [ $target_thermal ℃ ]！"
	echo "- 检测到您是旧机型……"
	echo "- 您已选择 [ 游戏温控配置=$Game_thermal_choose ]！"
	echo -e "\n∞————————————————————————∞\n"
	cp -rf "$conf_file" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
	return 0
fi

if test -f "$conf_file" ;then
	echo "- 您已选择 [ $target_thermal ℃ ]！"
	echo "- 您已选择 [ 游戏温控配置=$Game_thermal_choose ]！"
	echo -e "\n∞————————————————————————∞\n"
	cp -rf "$conf_file" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
else
	echo "- 不存在配置文件！"
	echo "- 自动选择46℃温控文件！"
	echo "- 您已选择 [ 游戏温控配置=$Game_thermal_choose ]！"
	echo -e "\n∞————————————————————————∞\n"
	cp -rf "${MODPATH}/thermal/46.conf" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
fi


sed -i '/description=/d' "$MODPATH/module.prop"
sed -i "/author=.*/a\description= 当前已选择[ $target_thermal ]。温度配置可以在[ 模块目录/配置.prop ]下选择，有[ 43℃，46℃，48℃，无限制 ]几种选择，更改完执行[ 模块目录/service.sh ]就行，无需重启。" "$MODPATH/module.prop"


