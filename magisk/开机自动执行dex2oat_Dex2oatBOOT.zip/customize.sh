#创建配置文件
touch /data/dex2oat.prop
touch /data/optionalapp.prop
echo "#dex2oat配置文件
#dex2oat=使用模式，可选：
#speed-profile  编译配置文件中列出的函数，性能较差，所需时间短,所占空间小
#speed  编译所有的函数，性能一般，所需时间适中,所占空间适中
#everything  编译一切可以编译的，性能最好，所需时间最长,所占空间大
dex2oat=speed
#select=应用选择，可选：
#系统应用，三方应用，全部应用，无
select=无
#optionalapp=自选应用，填：
#是，否
optionalapp=否
#注意！当select=无，optionalapp=是 时，只编译自选应用
#注意！当select=系统应用/三方应用，optionalapp=是 时，编译系统应用/三方应用和自选应用
#更换模式后第一次执行需要大量时间，甚至可能超过半小时
#后续执行时会跳过已编译的应用
" > /data/dex2oat.prop
echo "#自选应用配置文件（填包名，一行一个）" > /data/optionalapp.prop
