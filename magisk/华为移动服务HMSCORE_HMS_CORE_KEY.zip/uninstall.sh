#!/sbin/sh
app="HuaweiAppmarket HmsCore Hmsframework"
tmp_list="$app"
dda=/data/dalvik-cache/arm
test -d $dda"64" && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"* 2>/dev/null
done
rm -rf /data/system/package_cache/*
