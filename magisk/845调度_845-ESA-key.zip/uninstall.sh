#!/system/bin/sh

until $(dumpsys deviceidle get screen) ;do
	sleep 5
done
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH
dir1="/data/vendor/thermal/config"
dir2="/data/thermal/config"
chattr -i -a -A $dir1 2>/dev/null
chattr -i -a -A $dir2 2>/dev/null
rm -rf $dir1 $dir2 2>/dev/null

settings delete global activity_manager_constants

rm -rf /data/powercfg.sh

