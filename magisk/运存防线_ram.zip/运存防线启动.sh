#!/system/bin/sh
MODDIR=${0%/*}
script_name="ram.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
    kill -KILL $lastID
fi
nohup $MODDIR/ram.sh > /dev/null 2>&1 &