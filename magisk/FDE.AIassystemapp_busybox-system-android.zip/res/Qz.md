### Pertanyaan yang Sering Diajukan

- _Apakah BusyBox diperlukan?_

> **Tidak.** Aplikasi ini sudah memilikinya. Tetapi menginstal aplikasi/modul BusyBox tambahan
> tidak akan menimbulkan konflik.

- _Mengapa beberapa setelan tidak aktif (tidak dapat diubah)?_

> FDE.AI memeriksa apakah perangkat Anda mendukung dari pengaturan yang terdaftar. Jika pengaturan
> tidak didukung, itu akan dinonaktifkan. Ini mungkin juga tergantung pada mode AI yang
> dipilih & apakah pengoptimalan sistem real-time diaktifkan atau tidak.

- _Mengapa AI menyetel perangkat saya ke mode performa sementara saya menyetelnya ke mode hemat
  daya?_

> AI menyetel VM untuk performa jika perangkat sedang diisi. Setelah Anda mencabut perangkat dari
> pengisi daya, AI akan beralih kembali ke mode sebelumnya. Pilihan ini aman dan tidak akan membuat
> perangkat anda kepanasan karena menyetel parameter VM saja (tidak ada perubahan frekuensi/termal).

- _Aplikasi berfungsi dengan baik, tetapi log tidak diperbarui untuk waktu yang lama. Apakah itu
  baik-baik saja?_

> **Ya**, karena FDE.AI melakukan berbagai aktivitas latar belakang hanya jika itu benar-benar
> diperlukan pada skenario penggunaan perangkat Anda. Namun, jika menurut Anda aplikasi benar-benar
> macet, coba mulai ulang FDE.AI dari halaman pengaturan atau reboot perangkat Anda.

- _Akankah FDE.AI bekerja dengan aplikasi tweaker X, Y atau Z?_

> Mungkin iya, tetapi sangat **TIDAK direkomendasikan**. Masalah/konflik yang tidak terduga dapat
> terjadi. Namun, jika Anda tahu apa yang Anda lakukan, dan Anda tahu apakah akan bertentangan atau
> tidak, Anda dapat gunakan tweaker lain bersama FDE.AI. Namun, seperti yang dinyatakan sebelumnya,
> ini TIDAK DIREKOMENDASIKAN dan harus dilakukan ATAS RISIKO ANDA SENDIRI.

- _Mengapa CPU dan/atau GPU Turbo tidak didukung?_

> Karena kernel yang Anda gunakan tidak menyediakan info node yang diperlukan untuk digunakan
> FDE.AI. Namun, itu bisa juga karena chipset/driver perangkat Anda tidak mendukungnya. Selain itu,
> beberapa CPU tidak menyediakan hal yang diperlukan untuk dioperasikan.
> 'ondemand'/'interactive'/'schedutil' atau berdasarkan ini governors harus didukung oleh CPU Turbo.
> Bagaimanapun, yang bisa Anda coba adalah mengganti governors kernel atau cukup hapus data aplikasi
> untuk memastikan itu bukan kesalahan acak. Selain itu, ada dukungan GPU Turbo lama untuk GPU Mali
> dan Vivante tertentu yang tidak didukung fitur tersebut. Ini membutuhkan opsi peningkatan game
> konstan aktif dan bekerja dengan game yang didukung secara otomatis, atau dapat selalu diaktifkan
> jika mode AI diatur ke performa.

- _Bagaimana cara mengubah CPU/GPU governor saya?_

> Unduh kernel manager (kami merekomendasikan SmartPack tetapi secara harfiah apa saja tidak
> masalah) dan ubahlah dari sana.

- _Bisakah saya menutup aplikasi dengan aman dengan menggesernya keluar dari recents?_

> Ya. Ada layanan latar belakang yang menangani semua proses. Aplikasi ini bertindak seperti
> pembungkus layanan latar belakang itu.

- _Ketika Anda berbicara tentang layanan latar belakang, apakah itu berarti aplikasi akan menguras
  baterai saya?_

> **Tidak**. hanya tidak.

- _Bagaimana cara menghapus FDE.AI dengan benar?_

> uninstall aplikasi seperti biasa dan reboot perangkat Anda. Semua pengaturan yang diterapkan akan
> kembali ke default. Tapi tolong pertimbangkan untuk melaporkan alasan mengapa Anda menghapusnya
> ke grup support. Terutama jika itu karena bug atau aplikasi tidak berfungsi seperti yang
> Anda harapkan.

- _Metode root mana yang didukung oleh aplikasi?_

> Secara harfiah apa saja, tetapi direkomendasikan gunakan Magisk.

- _Apa itu AI lifetime counter di halaman utama aplikasi?_

> Itu hanya indikator sederhana yang menunjukkan berapa lama AI telah aktif. Misalnya, itu
> akan reset jika Anda menekan "Restart FDE.AI" atau saat perangkat Anda reboot.

- _Mengapa AI terkadang salah melaporkan modenya?_

> Ini bukan pelaporan palsu, hanya perlu waktu (tidak realtime) memperbarui statusnya biasanya
> membutuhkan ~40 detik.

- _Apa itu tombol "Pengoptimal PC" di halaman info dan mengapa ada di sana?_

> Ini adalah tautan ke aplikasi pengoptimal kemitraan (freeware) untuk OS Windows. Aplikasi
> dikembangkan dan dikelola oleh pengembang yang berbeda (bukan tim FDE.AI).

- _Sistem saya mulai tersendat setelah eksekusi FDE.AI. Mengapa?_

> Itu seharusnya tidak terjadi. Tetapi Anda dapat mencoba untuk menonaktifkan **semua** tweak
> build.prop di pengaturan, reboot perangkat & lihat.

- _Saya memiliki pertanyaan yang tidak dicakup oleh FAQ ini. Di mana saya dapat mendapatkan
  jawaban?_

> Periksa "Info tentang bagian AI". Jangan sungkan untuk bergabung
> [grup dukungan Telegram](https://t.me/feralab_eng) kami - kami akan dengan senang hati membantu :)

- _Saya menemukan bug/punya saran, kemana saya bisa melaporkannya?_

> Sama seperti di atas - di grup dukungan Telegram kami.
