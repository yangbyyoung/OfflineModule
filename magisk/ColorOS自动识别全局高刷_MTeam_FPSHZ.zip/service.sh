#!/bin/env sh
MODDIR=${0%/*}
BASH=/data/adb/modules/C++Busybox/Bash/bash

rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/FPS
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/Surface
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/MTeams
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/参数
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/Special_AidLux
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/Vulkan
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/SKIAGL
rm -rf /data/adb/modules/MTeam_FPSHZ/SurfaceFlinger/GPU_HW
chmod -R 777 $MODDIR/
/system/bin/sh "$MODDIR/Info.sh" &

{
sleep 15
exec "$BASH" --posix "$MODDIR/MTeam_SF.sh"
exit 0
}
