GG(){
case $(getprop ro.build.version.release ) in
11 )
for i in $B;do
$K2 -i `find $i -print` && rm -rf `find $i -print` 2>/dev/null
done
;;
*)
for i in $B;do
$K -i `find $i -print` && rm -rf `find $i -print` 2>/dev/null
done
;;
esac
}
GG