#!/system/bin/sh
export PATH=/data/adb/magisk/busybox:$PATH

function limitlog(){
	local logfile=$1
	local maxsize=$((1024*10))
	filesize=`ls -l $logfile | awk '{ print $5 }'`
	if test "$filesize" -gt "$maxsize" ;then
		echo " " > $logfile
	fi
}

function Log() {
	txt="/storage/emulated/0/Android/powersave.txt"
	echo -e "$(date '+%y %m.%d %T') 🔋: "$(dumpsys battery | awk '/level/{print $2}')" "$1" \n" >> $txt
	limitlog "$txt"
}

#识别屏幕状态
screen=`dumpsys deviceidle get screen`

dumpsys deviceidle | grep -q Enabled=true
check=$?

if test "$screen" = "false" ; then
	if test "$check" = "1" ; then
		dumpsys deviceidle enable deep
		dumpsys deviceidle force-idle deep
		#修改记得注释掉
		Log "😴 『主张』turn on the processor doze"
		#日志
	fi
else
	if test "$check" = "0" ; then
		dumpsys deviceidle disable all
		dumpsys deviceidle unforce
		Log "🥱 『主张』turn off the processor doze"
	fi
fi


