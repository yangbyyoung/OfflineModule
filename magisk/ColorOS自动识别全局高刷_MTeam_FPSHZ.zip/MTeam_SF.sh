#!/bin/bash
MODDIR=${0%/*}

cd $MODDIR/SurfaceFlinger/
rm -rf FPS
rm -rf Surface
rm -rf MTeams
rm -rf 参数
rm -rf Special_AidLux
rm -rf Vulkan
rm -rf SKIAGL
rm -rf GPU_HW
rm -rf GAME_THG
rm -rf GAME_WHG
#Run script program
awk 'BEGIN {
	i=0;
	do {
	cmd=system("test -f MTeams")
		if (cmd=="0")
		{
		} else {
		system("'$PWD/MTeam_SF.sh' ")
		}
		system("sleep 40")
		i = i + 1
	}
	while (i)
exit 0
}'