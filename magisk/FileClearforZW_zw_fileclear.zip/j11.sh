#!/system/bin/bash
:<<'eof'
***更新日志***
2022-03-21：再次尝试屏蔽友盟.umeng系毒瘤，将广告毒瘤屏蔽操作前移，取消对/data和SD卡清理时的chattr -R -i操作
2022-03-23：精简无用的命令行(即此前做的注释和#的命令行)
eof

# 0、初始变量、命令别名设置
export PATH=$PATH:$(magisk --path)/.magisk/busybox
export MODDIR=$(cd "$(dirname "${BASH_SOURCE-$0}")";pwd)
export sd0="/data/media/0"
test "$(echo /data/media/[0-9]*)" != "/data/media/0" && export sd="/data/media/[0-9]*" || export sd="$sd0"
rm -rf ${sd}/adzw*
test -x /system/bin/am && alias am='/system/bin/am'
test -x /system/bin/pm && alias pm='/system/bin/pm'
nowtime=$(date +"%m-%d_%T")

# 1、检查是否具备执行环境；为避免非bash环境，导致[[ ]]判断语句报错，先采用test命令
# 判断是否安装linux命令完整版(面具模块)；module_11=1表示安装了模块
test -x /data/adb/modules/linux_fullcommands/system/bin/find && module_11=1 || module_11=2
# 判断是否安装了Magisk-Module(面具模块)；module_11=3表示安装了模块
test -x /data/adb/modules/zw_fileclear/system/bin/find && module_11=3 || module_11=4
# 判断是否安装了Termux、MT终端模拟器APP；module_12=1表示安装了APP
test -x /data/data/com.termux/files/usr/bin/find -o -x /data/user/0/bin.mt.plus.canary/files/term/usr/bin/find && module_12=1 || module_12=2
# 判断当前脚本文件夹中是否有find、gawk、xargs命令；module_13=1表示有命令
test -f $MODDIR/find -a -f $MODDIR/gawk -a -f $MODDIR/xargs && module_13=1 || module_13=2
test "$module_11" != "1" -a "$module_11" != "3" -a "$module_12" != "1" -a "$module_13" != "1" && { echo -e "\033[31m   此运行环境缺少完整的find、gawk、xargs命令\n   3秒后退出... ... \033[0m \a";sleep 3s;exit 1;}
# 判断是否有bash；若有，则sh=bash
sh_1=$(type sh | rev | awk '{print $1}' | rev)
sh_2=$(type bash | rev | awk '{print $1}' | rev)
if test "${#sh_1}" -ge 8 -a -x "$sh_2"
then
  alias sh=bash
  module_31=1
fi
# 测试[[命令
[[ $sd0 ]] &>/dev/null
test "$?" != "0" && { echo -e "\033[31m   此运行环境无法执行 [[ 命令\n   3秒后退出... ... \033[0m \a";sleep 3s;exit 1;}

# 2、判断脚本执行状态
if [[ -z "$PREFIX" ]] || test -z "$PREFIX";then
# 判断是否为Magisk-Module(面具模块)状态执行；module_21=1表示是
  module_21=1
elif [[ "$PREFIX" == *"com.termux"* ]] || test "$PREFIX" = "/data/data/com.termux/files/usr";then
# 判断是否为Termux终端模拟器状态执行，module_22=1表示是
  module_21=2;module_22=1
elif [[ "$PREFIX" == *".mt."* ]] || test "$PREFIX" = "/data/user/0/bin.mt.plus.canary/files/term/usr";then
# 判断是否为MT管理器的终端模拟器执行，module_22=3表示是
  module_21=2;module_22=3
elif [[ "$PREFIX" == *"Han.GJZS"* ]] || test "$PREFIX" = "/data/user/0/Han.GJZS/files/usr";then
# 判断是否为搞机助手的终端模拟器执行，module_22=5表示是
  module_21=2;module_22=5
else
  module_21=2;module_22=2
fi

# 3、测试脚本文件所在处的find、gawk、xargs是否有执行权
test_find_gawk_xargs(){
# 当前脚本文件夹中的find、gawk、xargs是否有执行权
[[ -x ${MODDIR}/find ]] && { find_1=1;find_2=${MODDIR}/find;} || chmod 777 ${MODDIR}/find 2>/dev/null
[[ ! -x ${MODDIR}/find ]] && { find_1=2;find_2=`type find | awk '{print $3}'`;echo -e "   无法为${MODDIR}中的find命令赋执行权,采用本终端自带命令\n   脚本运行中可能大量报错，并导致脚本诸多功能无效！\a";sleep 3s;} || { find_1=1;find_2=${MODDIR}/find;}
[[ -x ${MODDIR}/gawk ]] && awk_2=${MODDIR}/gawk || chmod 777 ${MODDIR}/gawk 2>/dev/null
[[ ! -x ${MODDIR}/gawk ]] && { awk_2=`type gawk | awk '{print $3}'`;echo -e "   无法为${MODDIR}中的gawk命令赋执行权,采用本终端自带命令\n      脚本运行中可能大量报错，并导致脚本诸多功能无效！\a";sleep 3s;} || awk_2=${MODDIR}/gawk
[[ -x ${MODDIR}/xargs ]] && xargs_2=${MODDIR}/xargs || chmod 777 ${MODDIR}/xargs 2>/dev/null
[[ ! -x ${MODDIR}/xargs ]] && { xargs_2=`type xargs | awk '{print $3}'`;echo -e "   无法为${MODDIR}中的xargs命令赋执行权,采用本终端自带命令\n      脚本运行中可能大量报错，并导致脚本诸多功能无效！\a";sleep 3s;} || xargs_2=${MODDIR}/xargs
}

# 4、判断是否存在上次执行后未成功重启
# 判断是否为Magisk-Module(面具模块)状态执行
if test "$module_21" = "1"
then
  rm -rf $sd0/FileClear_zw_$nowtime.txt &>/dev/null
  echo -e "   ****** 检测到FileClear_for_ZW在Magisk面具中执行 ******" >$sd0/FileClear_zw_$nowtime.txt
  if test ! -e "/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh";then
    echo -e '#!/system/bin/bash \n rm -rf $0'>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
    test "$?" = "0" && { chmod -R 777 /data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh;echo "                   ($(date +"%Y-%m-%d %T"))" >>$sd0/FileClear_zw_$nowtime.txt;} || echo "         ！！！脚本执行标记文件创建失败！！！" >>$sd0/FileClear_zw_$nowtime.txt
  else
    echo "   检测到上次执行本模块后未能成功重启手机，本次执行中断;请手动重启手机！">>$sd0/FileClear_zw_$nowtime.txt
    sleep 3s
    exit 1
  fi
# 判断是否为Termux终端、MT管理器、搞机助手的终端模拟器执行
elif test -d "/data/adb/service.d"
then
  if test ! -e "/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh";then
  echo -e '#!/system/bin/bash \n rm -rf $0'>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  test "$?" = "0" && chmod -R 777 /data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh || echo -e "\033[31m   脚本执行标记文件创建失败！\033[0m"
  else
    echo -e "\033[31m   检测到上次执行本模块后未能成功重启手机，本次执行中断！\n   请先手动重启手机！\n   3秒后退出...\033[0m"
    sleep 3s
    exit 1
  fi
fi

# 5、按不同脚本执行环境，设置命令变量
# module_21=1表示是面具状态执行
if test "$module_21" = "1"
then
  find_1=1
  find_2="/system/bin/find"
  awk_2="/system/bin/gawk"
  xargs_2="/system/bin/xargs"
# module_22=1表示是Termux终端模拟器状态执行
elif test "$module_22" = "1"
then
# 获取原始sh命令路径，采用rev命令倒置获取最后一列
  find_1=1
  find_2="/data/data/com.termux/files/usr/bin/find"
  awk_2="/data/data/com.termux/files/usr/bin/gawk"
  xargs_2="/data/data/com.termux/files/usr/bin/xargs"
  echo "   检测到脚本正在Termux中执行，将采用Termux自带的find等命令！"
else
  if test "$module_22" = "3";then
    echo e "\033[36m   检测到脚本正在MT管理器中执行，MT中find等命令为阉割版；无法保证脚本全功能+无错运行！\n   将检测是否安装有ZW系列面具模块或脚本所在文件夹中是否有完整版命令！\033[0m"
  elif test "$module_22" = "5";then
    echo e "\033[36m   检测到脚本正在搞机助手APP中执行！将检测是否安装有\n   ZW系列面具模块或脚本所在文件夹中是否有完整版命令！\033[0m"
  else
    echo e "\033[31m   检测到脚本正在未知终端中执行；无法保证脚本全功能+无错运行！\n   将检测是否安装有ZW系列面具模块或脚本所在文件夹中是否有完整版命令！\033[0m"
  fi
  if test "$module_11" = "1" -o "$module_11" = "3";then
    find_1=1
    find_2="/system/bin/find"
    awk_2="/system/bin/gawk"
    xargs_2="/system/bin/xargs"
    echo -e "   检测到您有安装ZW相关模块，将采用模块自带的find等命令！\a"
  elif test "$module_13" = "1";then
    test_find_gawk_xargs
    echo -e "   检测到脚本所在文件夹有完整的find等命令，将采用这些命令！\a"
  else
    test "$module_12" = "1" && { echo -e "   检测到您有安装Termux终端模拟器APP\n   强烈建议Ctrl+C终止脚本运行，然后在Termux中运行！\a";find_2="find";awk_2="awk";xargs_2="xargs";sleep 10s;} || { echo -e "\033[31m   此运行环境缺少完整的find、xargs等命令\n   3秒后退出... ... \033[0m \a";sleep 3s;exit 1;}
  fi
fi

# 6、检查是否为root用户，临时关闭SELinux，根目录是否有写权限，并尝试挂载所有目录为可写;
[[ `id -u` != "0" ]] && echo -e "   非root用户，无法全面清理垃圾\a"
if [[ `getenforce` = "Enforcing" || `getenforce` = "enforcing" ]]
then
  SELinux_on=1
  setenforce 0
  if [[ `getenforce` = "Enforcing" || `getenforce` = "enforcing" ]];then
    SELinux_on=2   # 因无法临时关闭SELinux，故设置变量为假，避免执行脚本末尾的开启SELinux指令;
    echo -e "\033[31m   SELinux临时关闭失败，无法彻底清理垃圾 \033[0m \a"
  else
    echo "   SELinux已临时关闭，清理完毕后会重启开启"
  fi
else
  SELinux_on=2
  echo "   SELinux原始状态:Off"
fi
mount|grep "ro,"|grep -v "$(magisk --path)/.magisk/"|awk -F'[ ,]' '{print $1,$3}'|while read a b
do
mount -o rw,remount $a $b &>/dev/null
[[ $? == "0" ]] && echo -e "\033[32m   挂载$b为可写成功 \033[0m" || echo -e "\033[31m   挂载$b为可写失败 \033[0m"
[[ $? != "0" ]] && [[ $b == "/" || $b == "/system" || $b == "/data" ]] && { echo -e "\033[31m   $b目录无写权限，无法全面清理垃圾\n   3秒后退出 \033[0m \a";sleep 3;exit 1;}
done
echo ""

# 7、关闭部分系统App和所有第三方APP进程
echo "   开始关闭部分系统APP和所有第三方APP"
killapp_1=(com.android.calendar com.android.camera com.android.providers.calendar com.android.provision com.android.soundrecorder com.android.thememanager com.android.updater com.miui.backup com.miui.cloudbackup com.miui.gallery com.miui.hybrid com.miui.micloudsync com.miui.newhome com.miui.personalassistant com.miui.smarttravel com.miui.yellowpage com.xiaomi.account com.xiaomi.market);
killapp_2=`pm list package -3|$awk_2 -F ':' '{print $2}'|sed -e '/io.neoterm/ d' -e '/com.termux/ d' -e '/bin.mt.plus.canary/ d' -e '/Han.GJZS/ d' -e '/com.topjohnwu.magisk/ d'`;
for killapp_3 in ${killapp_1[*]} $killapp_2;
do
  { PID_temp=`pidof -s $killapp_3`;
  [[ $PID_temp ]] && kill -15 $PID_temp;
  [[ $PID_temp && $? != "0" ]] && kill -9 $PID_temp;
  unset PID_temp;
  am force-stop $killapp_3;} &
done;
am kill-all

# 8、回收文件系统未使用的空间；清理缓存和内存
fstrim_2="$(magisk --path)/.magisk/busybox/fstrim"
echo "   第1次回收文件系统未使用的空间ing..."
$fstrim_2 -v / &>/dev/null
/system/bin/ls -l / |grep ^d|$awk_2 '{print $8}'|$xargs_2 -I fstrim_temp $fstrim_2 -v /fstrim_temp &>/dev/null
wait
echo -e "   APP关闭完成！空间回收完毕！\n   开始缓存和内存清理ing..."
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
sync
echo "   缓存和内存清理完毕 ！"

# 9、获取清理前的整个系统、data、sd卡已使用空间大小
start_used_allsys=`df /apex /cache /cust /data /dev /metadata /mnt /sys /system /vendor 2>/dev/null|$awk_2 'NR!=1 {used+=$3}END{used=used/1024;print used}' 2>/dev/null`
start_used_data=`du -smL /data/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
start_used_sd=`du -smL ${sd}/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
start_used_sdandro=`du -smL ${sd}/Android/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
wait
starttime=`date +%s`

# 广告文件(夹)屏蔽，防写入
find ${sd} \( -iname ".adiu" -o\
 -iname ".BD_SAPI_CACHE" -o\
 -iname ".betadatastorage" -o\
 -iname ".betautsystemconfig" -o\
 -iname ".cc" -o\
 -iname ".com.taobao.dp" -o\
 -iname ".DataStorage" -o\
 -iname ".gd_file" -o\
 -iname ".gd_fs0" -o\
 -iname ".gd_fs3" -o\
 -iname ".gd_fs6" -o\
 -iname ".gs_file" -o\
 -iname ".gs_fs0" -o\
 -iname ".gs_fs3" -o\
 -iname ".gs_fs6" -o\
 -iname ".im" -o\
 -iname ".protected_image" -o\
 -iname ".Rcs" -o\
 -iname ".sys.log" -o\
 -iname ".SystemConfig" -o\
 -iname ".teemo" -o\
 -iname ".turingdebug" -o\
 -iname ".UTSystemConfig" -o\
 -iname ".vivo" -o\
 -iname ".vivo bytedance" -o\
 -iname ".xlDownload" -o\
 -iname "tempdata" -o\
 -iname "templates" -o\
 -iname ".SystemConfig" -o\
 -iname "Catfish" -o\
 -iname "cmcc_sso_south_log" -o\
 -iname "com.miui.guardprovider_TMF_TMS" -o\
 -iname "device_known" -o\
 -iname "JuphoonService" -o\
 -iname "MQ" -o\
 -iname "openamaplocationsdk" -o\
 -iname "OSSLog" -o\
 -iname "p2plog" -o\
 -iname "qmt" -o\
 -iname "QQBrowser" -o\
 -iname "ramdump" -o\
 -iname "setup" -o\
 -iname "SogouReader" -o\
 -iname "tbs" -o\
 -iname "ucgamesdk" -o\
 -iname "Ulike" -o\
 -iname "XHS" \) 2>/dev/null >>$sd0/adzw_ad.txt;
[[ -d /data/data/com.handsgo.jiakao.android/cache/GDTDOWNLOAD/image ]] && echo /data/data/com.handsgo.jiakao.android/cache/GDTDOWNLOAD/image >>$sd0/adzw_ad.txt
[[ -d /data/data/com.handsgo.jiakao.android/cache/image_manager_disk_cache ]] && echo /data/data/com.handsgo.jiakao.android/cache/image_manager_disk_cache >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/autonavi 2>/dev/null) ]] && echo ${sd}/autonavi >>$sd0/adzw_ad.txt;
[[ -d $(ls ${sd}/pansong291.xposed.quickenergy.qiufeng 2>/dev/null) ]] && echo ${sd}/pansong291.xposed.quickenergy.qiufeng >>$sd0/adzw_ad.txt;
[[ -d $(ls ${sd}/images 2>/dev/null) ]] && echo ${sd}/images >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/.weibo_ad_universal_cache 2>/dev/null) ]] && echo ${sd}/sina/weibo/.weibo_ad_universal_cache >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/.weibo_refreshad_cache 2>/dev/null) ]] && echo ${sd}/sina/weibo/.weibo_refreshad_cache >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/.weibo_video_cache_new 2>/dev/null) ]] && echo ${sd}/sina/weibo/.weibo_video_cache_new >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/.weiboadcache 2>/dev/null) ]] && echo ${sd}/sina/weibo/.weiboadcache >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/storage/biz_keep/.weibo_ad_universal_cache 2>/dev/null) ]] && echo ${sd}/sina/weibo/storage/biz_keep/.weibo_ad_universal_cache >>$sd0/adzw_ad.txt
[[ -d $(ls ${sd}/sina/weibo/storage/biz_keep/.weibo_refreshad_cache 2>/dev/null) ]] && echo ${sd}/sina/weibo/storage/biz_keep/.weibo_refreshad_cache >>$sd0/adzw_ad.txt
# data搜索ad、.um、.uxx文件(含SD卡)，在完成后续搜索清理之后再防写入
find /data \( -iname "ad" -o -iname "adcache" -o -iname "AdHub" -o -iname "ads" -o -iname "*_ad" -o -iname "*_ads" -o -iname "*_ad_*" -o -iname "ad_*" -o -iname "ads_*" -o -iname "afpSplash" -o -iname "app_ad" -o -iname "app_analytics" -o -iname "app_adnet" -o -iname "app_UApm" -o -iname "brandad" -o -iname "miad" -o -iname "MiPushLog" -o -iname "msflogs" -o -iname "startupsplash" -o -iname "splash" -o -iname "*SplashCache" -o -iname "splash_ad_cache" -o -iname "splash_image" -o -iname "spla*ad" -o -iname "spla*cache" -o -iname "tad_cache" -o -iname "tbslog" -o -iname ".u" -o -iname ".um" -o -iname ".umeng" -o -iname ".*uuid" -o -iname ".uxx" -o -iname ".vy" -o -iname ".yyy" -o -iname ".zzz" -o -iname "um" -o -iname "*_umeng_*" -o -iname "umeng_*" -o -iname "uuid" -o -iname "uxx" \) 2>/dev/null|sed -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/com.tencent.tmgp.sgame/ d' -e '/com.tencent.mm\/MicroMsg/ d' -e '/cn.ticktick.task/ d' -e '/com.ticktick.task/ d' >>$sd0/adzw_ad.txt
# 在/data和SD卡中对ad、.um、.uxx文件夹(含SD卡)广告毒瘤进行防写入操作
adzw_ad_num=0
if [[ -s $sd0/adzw_ad.txt ]]
then
  while read adz0;do
    if [[ -w $adz0 ]];then
      chmod -R 777 $adz0 &>/dev/null
      rm -rf $adz0 &>/dev/null
    fi
  mkdir -p ${adz0%/*} &>/dev/null
  touch $adz0 &>/dev/null
  chmod 000 $adz0 &>/dev/null
  chattr +i $adz0 &>/dev/null
  [[ ! -s $adz0 && ! -w $adz0 ]] && adzw_ad_num=$(($adzw_ad_num+1))
  done < $sd0/adzw_ad.txt
  unset adz0
else
  echo "-  没有搜索到广告毒瘤文件(夹)，adzw_ad.txt为空！" > $sd0/adzw_ad.txt
fi

# 清理SD卡根目录的垃圾文件(夹)
if [[ -f $MODDIR/clearlist-sd.txt && -s $MODDIR/clearlist-sd.txt ]];then
  cat $MODDIR/clearlist-sd.txt|$xargs_2 -P 80 -I adz0 sh -c "[[ -d ${sd}/adz0 ]] && rm -rfv ${sd}/adz0/ 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_3_err.txt || rm -rfv ${sd}/adz0 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_3_err.txt" &>/dev/null
  num_3_0=`wc -l $sd0/adzw_list.txt|$awk_2 '{print $1}'`
  cat $sd0/adzw_list.txt >>$sd0/adzw_0.txt
  wait
  rm -f ${sd}/adzw.txt ${sd}/adzw_list.txt && echo "   sd卡根目录特定文件(夹)清理完毕 ！"
  unset adz0
elif [[ -f $MODDIR/clearlist-sd.txt && ! -s $MODDIR/clearlist-sd.txt ]];then
  echo "   sd卡清理列表文件clearlist-sd.txt为空"
  echo "sd卡根清理列表文件clearlist-sd.txt为空" >>$sd0/adzw_3_err.txt
else
  echo "   没有sd卡清理列表文件clearlist-sd.txt"
  echo "没有sd卡清理列表文件clearlist-sd.txt" >>$sd0/adzw_3_err.txt
fi

# 清理SD卡Android/data中的垃圾文件
if [[ -f $MODDIR/clearlist-sd_Android_data.txt && -s $MODDIR/clearlist-sd_Android_data.txt ]];then
  cat $MODDIR/clearlist-sd_Android_data.txt|$xargs_2 -P 80 -I adz0 sh -c "[[ -d ${sd}/Android/data/adz0 ]] && rm -rfv ${sd}/Android/data/adz0/ 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_3_err.txt || rm -rfv ${sd}/Android/data/adz0 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_3_err.txt" &>/dev/null
  let num_3_0="num_3_0 + `wc -l $sd0/adzw_list.txt|$awk_2 '{print $1}'`"
  cat $sd0/adzw_list.txt >>$sd0/adzw_0.txt
  wait
  rm -f ${sd}/adzw.txt ${sd}/adzw_list.txt && echo "   sd卡Android特定文件夹清理完毕 ！"
  unset adz0
elif [[ -f $MODDIR/clearlist-sd_Android_data.txt && ! -s $MODDIR/clearlist-sd_Android_data.txt ]];then
  echo "   sd卡清理列表文件clearlist-sd_Android_data.txt为空"
  echo "sd卡清理列表文件clearlist-sd_Android_data.txt为空" >>$sd0/adzw_3_err.txt
else
  echo "   没有sd卡清理列表文件clearlist-sd_Android_data.txt"
  echo "没有sd卡清理列表文件clearlist-sd_Android_data.txt" >>$sd0/adzw_3_err.txt
fi

# 清理/data/data中的垃圾文件
if [[ -f $MODDIR/clearlist-data_data.txt && -s $MODDIR/clearlist-data_data.txt ]];then
  cat $MODDIR/clearlist-data_data.txt|$xargs_2 -P 80 -I adz0 sh -c "[[ -d /data/data/adz0 ]] && rm -rfv /data/data/adz0/ 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_2_err.txt || rm -rfv /data/data/adz0 1>>$sd0/adzw_list.txt 2>>$sd0/adzw_2_err.txt" &>/dev/null
  num_2_0=`wc -l $sd0/adzw_list.txt|$awk_2 '{print $1}'`
  cat $sd0/adzw_list.txt >>$sd0/adzw_0.txt
  wait
  rm -f ${sd}/adzw.txt ${sd}/adzw_list.txt && echo "   /data/data/*App*中特定文件夹清理完毕 ！"
  unset adz0
elif [[ -f $MODDIR/clearlist-data_data.txt && ! -s $MODDIR/clearlist-data_data.txt ]];then
  echo "   data/data清理列表文件clearlist-data_data.txt为空"
  echo "data/data清理列表文件clearlist-data_data.txt为空" >>$sd0/adzw_2_err.txt
else
  echo "   没有data/data清理列表文件clearlist-data_data.txt"
  echo "没有data/data清理列表文件clearlist-data_data.txt" >>$sd0/adzw_2_err.txt
fi

# 干掉QQ、微信的X5内核
x5tbs_num=0
for x5tbs_1 in `find /data -type d \( -iname "app_tbs" -o -iname "app_tbs_64" -o -iname "x5.backup*" -o -iname "x5.tbs.org*" -o -iname "app_x5webview*" \) 2>/dev/null|sed -e '/com.tencent.tmgp.sgame/ d'`;do
  if [[ -s $x5tbs_1 ]];then
    chattr -R -i "$x5tbs_1" 2>/dev/null
    chmod -R 777 "$x5tbs_1" 2>/dev/null
    rm -rf "$x5tbs_1"
    [[ $? == "0" ]] && { touch "$x5tbs_1";chmod 000 "$x5tbs_1";}
    [[ ! -s $x5tbs_1 && ! -w $x5tbs_1 ]] && x5tbs_num=$(($x5tbs_num+1))
  fi
done
echo "   已干掉QQ、微信的X5内核，共$x5tbs_num个文件 ！"
unset x5tbs_1
unset x5tbs_num
echo -e "\033[1m—————————————————————————————————————————\033[0m"

# 从根目录开始，搜索文件夹，进行清理
echo "   开始从根目录起搜索文件夹，稍等..."
{ find / \( -path /sys -o -path /proc \) -prune -o -type d \( -iname "*.test" -o\
 -iname "*_log" -o\
 -iname "*_logs" -o\
 -iname "*_report" -o\
 -iname "*_temp" -o\
 -iname "*_tmp" -o\
 -iname "*cache" -o\
 -iname "*crash" -o\
 -iname "*-log" -o\
 -iname "*-logs" -o\
 -iname "*microthumbnailfile" -o\
 -iname "*-temp" -o\
 -iname "*-tmp" -o\
 -iname ".*_thumbnail" -o\
 -iname ".log" -o\
 -iname ".td-3" -o\
 -iname ".tdck" -o\
 -iname ".temp" -o\
 -iname ".thumbnail" -o\
 -iname ".thumbnails" -o\
 -iname ".tmfs" -o\
 -iname ".tmp" -o\
 -iname "album*" -o\
 -iname "baidu" -o\
 -iname "bugreports" -o\
 -iname "code_cache" -o\
 -iname "crashdata" -o\
 -iname "dcsdk" -o\
 -iname "debug" -o\
 -iname "debug_log" -o\
 -iname "log" -o\
 -iname "logs" -o\
 -iname "MiPushLog" -o\
 -iname "onelog" -o\
 -iname "sqltrace" -o\
 -iname "temp" -o\
 -iname "thumb*" -o\
 -iname "tmp" -o\
 -iname "tombstones" -o\
 -iname "xlog" \) 2>/dev/null|sed -e '/\/sys/ d' -e '/\/proc/ d' -e '/.auth_cache/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.so/ d' -e '/app_clock_bak/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/yttrium_code_cache/ d' -e '/dalvik_cache/ d' -e '/\/lib\// d' -e '/\/lib64\// d' >>$sd0/adzw_1.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_1.txt|$xargs_2 -0 -P 80 -I deldir_1 sh -c "rm -rf \"deldir_1\" 2>>$sd0/adzw_1_err.txt";}
wait   # 避免同时与/data进行后台搜索清理

# 在/data分区(已含SD卡)中搜索文件夹，进行清理;
echo "   开始在data中搜索文件夹，稍等..."
{ find /data -type d \( -iname "*_bak" -o\
 -iname "*_debug" -o\
 -iname "*_info" -o\
 -iname "*cache*" -o\
 -iname "*log" -o\
 -iname "*log-*" -o\
 -iname "*log_*" -o\
 -iname "*logging_*" -o\
 -iname "*logic" -o\
 -iname "*logs" -o\
 -iname "*logs-*" -o\
 -iname "*logs_*" -o\
 -iname "*push" -o\
 -iname "*splash" -o\
 -iname "*temp" -o\
 -iname "*tmp" -o\
 -iname "*tmps" -o\
 -iname ".*info" -o\
 -iname ".*infos" -o\
 -iname ".acs" -o\
 -iname ".advertise" -o\
 -iname ".android" -o\
 -iname ".androidsystem" -o\
 -iname ".aoe" -o\
 -iname ".appcenter" -o\
 -iname ".appcenterwebbuffer*" -o\
 -iname ".application" -o\
 -iname ".ark_download" -o\
 -iname ".astable" -o\
 -iname ".attachments" -o\
 -iname ".avatar" -o\
 -iname ".awp" -o\
 -iname ".babylon" -o\
 -iname ".bimm" -o\
 -iname ".bmob" -o\
 -iname ".book" -o\
 -iname ".bottomtabs" -o\
 -iname ".cc" -o\
 -iname ".ccdid" -o\
 -iname ".ccvid" -o\
 -iname ".channelid" -o\
 -iname ".chap" -o\
 -iname ".chap_l" -o\
 -iname ".cloud" -o\
 -iname ".cm_restart_record" -o\
 -iname ".composer" -o\
 -iname ".debug" -o\
 -iname ".desc_icon" -o\
 -iname ".did" -o\
 -iname ".discovery" -o\
 -iname ".dlprovider" -o\
 -iname ".down_c" -o\
 -iname ".download" -o\
 -iname ".downloadconf" -o\
 -iname ".drm" -o\
 -iname ".dthumb" -o\
 -iname ".duid" -o\
 -iname ".dzh" -o\
 -iname ".effect" -o\
 -iname ".emoji" -o\
 -iname ".emoqface" -o\
 -iname ".emotionsm" -o\
 -iname ".estrongs" -o\
 -iname ".events" -o\
 -iname ".favorite" -o\
 -iname ".feedback" -o\
 -iname ".fg" -o\
 -iname ".freshword" -o\
 -iname ".fssingerres" -o\
 -iname ".gift" -o\
 -iname ".hcdnlivenet.ini" -o\
 -iname ".hiidosdk" -o\
 -iname ".icmweather" -o\
 -iname ".icon" -o\
 -iname ".iconbig" -o\
 -iname ".idm" -o\
 -iname ".im" -o\
 -iname ".image" -o\
 -iname ".images" -o\
 -iname ".interest" -o\
 -iname ".irsmonitorsdk" -o\
 -iname ".jars" -o\
 -iname ".jdd" -o\
 -iname ".jds" -o\
 -iname ".kspdf" -o\
 -iname ".kugouid" -o\
 -iname ".lm_device" -o\
 -iname ".locationicon" -o\
 -iname ".lockstyle_config" -o\
 -iname ".mcs" -o\
 -iname ".mergetheme" -o\
 -iname ".mn_" -o\
 -iname ".mtdfp" -o\
 -iname ".mtxx" -o\
 -iname ".MYXJ" -o\
 -iname ".n_a" -o\
 -iname ".n_b" -o\
 -iname ".n_c" -o\
 -iname ".n_d" -o\
 -iname ".ndfsc" -o\
 -iname ".nearby_flower" -o\
 -iname ".nvtts" -o\
 -iname ".o_a" -o\
 -iname ".o_b" -o\
 -iname ".o_c" -o\
 -iname ".o_d" -o\
 -iname ".oaidsystemconfig" -o\
 -iname ".op" -o\
 -iname ".openfail" -o\
 -iname ".pendant" -o\
 -iname ".plugin" -o\
 -iname ".poco" -o\
 -iname ".portrait" -o\
 -iname ".portraitnew" -o\
 -iname ".pre" -o\
 -iname ".prenew" -o\
 -iname ".profile" -o\
 -iname ".qiyi" -o\
 -iname ".qm_guid" -o\
 -iname ".qmt" -o\
 -iname ".qqchess" -o\
 -iname ".record" -o\
 -iname ".recordsample" -o\
 -iname ".sandbox" -o\
 -iname ".search" -o\
 -iname ".shared" -o\
 -iname ".shareTemp" -o\
 -iname ".shop" -o\
 -iname ".shop_assit" -o\
 -iname ".signaturetemplate" -o\
 -iname ".singerres" -o\
 -iname ".smartbiz" -o\
 -iname ".snggame" -o\
 -iname ".snggamemsg" -o\
 -iname ".ssjjsy" -o\
 -iname ".statistic" -o\
 -iname ".statuses" -o\
 -iname ".story" -o\
 -iname ".sym" -o\
 -iname ".sys" -o\
 -iname ".sys_prefer" -o\
 -iname ".systemconfig" -o\
 -iname ".tad" -o\
 -iname ".tbs" -o\
 -iname ".tcookieid" -o\
 -iname ".test" -o\
 -iname ".theme_net" -o\
 -iname ".thumbcache" -o\
 -iname ".thumbcache_idx_[0-9]*" -o\
 -iname ".timebox" -o\
 -iname ".tmfs" -o\
 -iname ".tmpdir" -o\
 -iname ".tmsdual" -o\
 -iname ".tomb" -o\
 -iname ".ttcryptofile" -o\
 -iname ".turing.dat" -o\
 -iname ".turingdebug" -o\
 -iname ".txlauncher" -o\
 -iname ".ufs" -o\
 -iname ".umeng" -o\
 -iname ".update" -o\
 -iname ".upgrade" -o\
 -iname ".userreturn" -o\
 -iname ".usex" -o\
 -iname ".uudid" -o\
 -iname ".vdevdir" -o\
 -iname ".vivo" -o\
 -iname ".webapp" -o\
 -iname ".weibo_chat" -o\
 -iname ".weibo_pic" -o\
 -iname ".weibo_pic_edit_new" -o\
 -iname ".weibo_pic_new" -o\
 -iname ".widget" -o\
 -iname ".yd_speech" -o\
 -iname ".zp" -o\
 -iname ".zycl" -o\
 -iname ".zzid.secure" -o\
 -iname ".zzqid.secure" -o\
 -iname ".zzz" -o\
 -iname "__macosx" -o\
 -iname "_chorus" -o\
 -iname "_hd" -o\
 -iname "_mel" -o\
 -iname "_music" -o\
 -iname "_ori_mp3" -o\
 -iname "_play_zrce" -o\
 -iname "_slt" -o\
 -iname "_ssohd" -o\
 -iname "_thd" -o\
 -iname "_zrce" -o\
 -iname "accompaniment" -o\
 -iname "acct_head" -o\
 -iname "achievement" -o\
 -iname "action" -o\
 -iname "activity" -o\
 -iname "activity_banner" -o\
 -iname "adcache" -o\
 -iname "addrmgr" -o\
 -iname "adesk_livewallaper" -o\
 -iname "adsapp" -o\
 -iname "adv.db" -o\
 -iname "aggregate" -o\
 -iname "album" -o\
 -iname "albumthumbs" -o\
 -iname "amimemoji" -o\
 -iname "anr" -o\
 -iname "anrsnap" -o\
 -iname "aoe" -o\
 -iname "app_accs" -o\
 -iname "app_blog_*" -o\
 -iname "app_dxad" -o\
 -iname "app_tbs" -o\
 -iname "app_tbs_64" -o\
 -iname "app_tbs_common_share" -o\
 -iname "app_webview" -o\
 -iname "app_x5webview" -o\
 -iname "app_xwalk_*" -o\
 -iname "app_xwalkconfig" -o\
 -iname "app_xwalkplugin" -o\
 -iname "appicon" -o\
 -iname "appsearch" -o\
 -iname "appseller" -o\
 -iname "AppTimer" -o\
 -iname "aps" -o\
 -iname "ar_feature" -o\
 -iname "ar_map" -o\
 -iname "ar_model" -o\
 -iname "aray" -o\
 -iname "ark_download" -o\
 -iname "arkapk" -o\
 -iname "arkapp" -o\
 -iname "artist" -o\
 -iname "ashe" -o\
 -iname "at" -o\
 -iname "atadspgresu.txt" -o\
 -iname "attachment" -o\
 -iname "attitude_pic" -o\
 -iname "autodownload" -o\
 -iname "autonavi" -o\
 -iname "aweme_monitor" -o\
 -iname "background" -o\
 -iname "backup" -o\
 -iname "backups" -o\
 -iname "baidu" -o\
 -iname "baidumapsdk" -o\
 -iname "baidupanosdk" -o\
 -iname "banner" -o\
 -iname "bcs" -o\
 -iname "bdbook" -o\
 -iname "bdmsa_gr" -o\
 -iname "bdmusic" -o\
 -iname "bdother" -o\
 -iname "bdpicture" -o\
 -iname "bdvideo" -o\
 -iname "beam" -o\
 -iname "behaviour_report" -o\
 -iname "betasdk" -o\
 -iname "bigattachment" -o\
 -iname "bigbanner" -o\
 -iname "bigpictrue" -o\
 -iname "bisheng.download" -o\
 -iname "bizimg" -o\
 -iname "bk" -o\
 -iname "bkd" -o\
 -iname "bless" -o\
 -iname "bookmark" -o\
 -iname "boss" -o\
 -iname "boutique" -o\
 -iname "breakpointinfo" -o\
 -iname "btm_adv" -o\
 -iname "bubble" -o\
 -iname "buckle" -o\
 -iname "bufferads" -o\
 -iname "businesscard" -o\
 -iname "bytedance" -o\
 -iname "ByteDownload" -o\
 -iname "cllamapsdk" -o\
 -iname "com_tencent_mm:*" -o\
 -iname "debug" -o\
 -iname "debug_*" -o\
 -iname "dump" -o\
 -iname "easou_book" -o\
 -iname "eup" -o\
 -iname "FTS_BizCacheObj" -o\
 -iname "handler" -o\
 -iname "jsmcc" -o\
 -iname "krsdk" -o\
 -iname "Local Storage" -o\
 -iname "logo*" -o\
 -iname "minidump" -o\
 -iname "newsimage" -o\
 -iname "online.*" -o\
 -iname "pending" -o\
 -iname "pushsdk" -o\
 -iname "rs-" -o\
 -iname "Session Storage" -o\
 -iname "sns" -o\
 -iname "spla*ad" -o\
 -iname "spla*cache" -o\
 -iname "ssjjsy" -o\
 -iname "statistic" -o\
 -iname "storage" -o\
 -iname "tad" -o\
 -iname "tbs" -o\
 -iname "ted" -o\
 -iname "templates" -o\
 -iname "test_writable" -o\
 -iname "tmassistantsdk" -o\
 -iname "tmfs" -o\
 -iname "trace" -o\
 -iname "turbonet" -o\
 -iname "turingdebug" -o\
 -iname "uapp" -o\
 -iname "ucwa" -o\
 -iname "upload" -o\
 -iname "vipshop" -o\
 -iname "watchdog" -o\
 -iname "webview_tmpl" -o\
 -iname "welcome" -o\
 -iname "wlan_logs" -o\
 -iname "wxafiles" -o\
 -iname "wxanewfiles" -o\
 -iname "xinhao" -o\
 -iname "xlogtest_writable" \) 2>/dev/null|sed -e '/.auth_cache/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.so/ d' -e '/app_clock_bak/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/yttrium_code_cache/ d' -e '/dalvik_cache/ d' -e '/\/lib\// d' -e '/\/lib64\// d' >>$sd0/adzw_2.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_2.txt|$xargs_2 -0 -P 80 -I deldir_21 sh -c "rm -rf \"deldir_21\" 2>>$sd0/adzw_2_err.txt";} &
sleep 2s;

# 在SD卡中搜索文件夹，并进行清理(只写规则比/data范围大的)
echo "   开始在sd卡中搜索文件夹，稍等..."
{ find /data/media -type d \( -iname "*login" -o\
 -iname "*story" -o\
 -iname ".escheck.tmp" -o\
 -iname ".trashBin" -o\
 -iname ".wx" -o\
 -iname ".yz" -o\
 -iname "applogic" -o\
 -iname "backup" -o\
 -iname "backups" -o\
 -iname "cmsVideo" -o\
 -iname "com_tencent_mm:toolsmp" -o\
 -iname "mta*" -o\
 -iname "pcdn" -o\
 -iname "Sandbox" -o\
 -iname "shadowplugin*" -o\
 -iname "tbs" -o\
 -iname "uploader" \) 2>/dev/null >>$sd0/adzw_3.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_3.txt|$xargs_2 -0 -P 80 -I deldir_3 sh -c "rm -rf \"deldir_3\" 2>>$sd0/adzw_3_err.txt";} &
sleep 2s

# 全盘搜索，清理tmp、log、error等文件
echo "   开始从根目录起搜索文件，稍等..."
{ find / \( -path /sys -o -path /proc \) -prune -o -type f \( -iname "*.old" -o\
 -iname "*.temp" -o\
 -iname "*.tmfs" -o\
 -iname "*.tmp" -o\
 -iname ".dump" -o\
 -iname "*_log" -o\
 -iname "*_log*.txt" -o\
 -iname "*error" -o\
 -iname "*log" -o\
 -iname "*log.lock" -o\
 -iname "*log.txt" -o\
 -iname "*log[0-9].txt" -o\
 -iname "*logs" -o\
 -iname "*logs*.txt" -o\
 -iname "log_*.txt" -o\
 -iname "logs_*.txt" -o\
 -iname "Thumbs.db" -o\
 -iname "x5.backup*" -o\
 -iname "x5.tbs.org*" \) 2>/dev/null|sed -e '/\/sys/ d' -e '/\/proc/ d' -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/lib\// d' -e '/\/lib64\// d' -e '/.so/ d' -e '/.db/ d' -e '/.xml/ d' >>$sd0/adzw_4.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_4.txt|$xargs_2 -0 -P 80 -I delfile_41 sh -c "rm -rf \"delfile_41\" 2>>$sd0/adzw_4_err.txt";} &
sleep 2s

# 在/data分区(已含SD卡)中搜索文件
echo "   开始在data中搜索文件，稍等..."
{ find /data -type f \( -iname "*.[0-9]" -o\
 -iname "*.backup" -o\
 -iname "*.backups" -o\
 -iname "*.bak" -o\
 -iname "*.tlog" -o\
 -iname "*.trace" -o\
 -iname "*_history" -o\
 -iname "*_list.txt" -o\
 -iname "*_ready.statistic" -o\
 -iname "*cache*" -o\
 -iname "*info.txt" -o\
 -iname "*test_writable" -o\
 -iname "._.Trashes" -o\
 -iname ".common" -o\
 -iname ".DS_Store" -o\
 -iname ".fseventsd" -o\
 -iname ".sk_v.dat" -o\
 -iname ".spotlight*" -o\
 -iname ".tim" -o\
 -iname ".turing.dat" -o\
 -iname "external.db-shm" -o\
 -iname "external.db-wal" -o\
 -iname "mistat.db-shm" -o\
 -iname "mistat.db-wal" -o\
 -iname "state-*.bin.bak" -o\
 -iname "tlog_v[0-9]" -o\
 -iname "variations_seed_new" \) 2>/dev/null|sed -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/\/Books\/Soushu/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/lib\// d' -e '/\/lib64\// d' -e '/.so/ d' -e '/.db/ d' -e '/.xml/ d' >>$sd0/adzw_5.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_5.txt|$xargs_2 -0 -P 80 -I delfile_51 sh -c "rm -rf \"delfile_51\" 2>>$sd0/adzw_5_err.txt";} &
# 因上一条命令屏蔽了对*.db文件的删除，故专门加入一条针对alsn.db文件的删除
find /data -type f -iname "alsn.db" |$xargs_2 -0 -P 80 -I delfile_52 sh -c "rm -rfv \"delfile_52\" 1>>$sd0/adzw_5.txt 2>>$sd0/adzw_5_err.txt";
sleep 2s;
# 在/data分区(已含SD卡)中搜索databases文件夹，进行特定清理！
{ for adzw_53 in $(find /data -type d \( -iname "*_databases" -o -iname "databases" -o -iname "files" -o -iname "shared_prefs" -o -iname "system" \) 2>/dev/null|sed -e '/com.android.deskclock/ d' -e '/com.tencent.androidqqmail/ d' -e '/com.ss.android.ugc.aweme/ d' -e '/com.coolapk.market/ d' -e '/\/FKZ_WX_/ d');
do
  find $adzw_53 -type f \( -iname "*-shm" -o -iname "*-wal" -o -iname "*-journal" \) 2>/dev/null|$xargs_2 -P 80 -I delfile_53 sh -c "chattr -R -i \"delfile_53\";rm -rfv \"delfile_53\" 1>>$sd0/adzw_5.txt 2>>$sd0/adzw_5_err.txt";
done;} &

# SD卡搜索并清理文件
echo "   开始在sd卡中搜索文件，稍等..."
{ find /data/media -type f \( -iname "*.[0-9a-z]" -o\
 -iname "*.alipaypng" -o\
 -iname "*.chunk.css" -o\
 -iname "*.chunk.js" -o\
 -iname "*.kpg" -o\
 -iname "._*" -o\
 -iname ".ptcs.db" -o\
 -iname ".DataId" -o\
 -iname ".DCIM_ID" -o\
 -iname "lcfp" -o\
 -iname "lcfp.lock" -o\
 -iname ".mid.txt" -o\
 -iname ".mn*" -o\
 -iname ".qqq" -o\
 -iname ".sss" -o\
 -iname "Screenshot_*_com.taobao.taobao_compv2" \) 2>/dev/null >>$sd0/adzw_6.txt;
$awk_2 -v FS='\n' -v ORS='\0' '{print $0}' $sd0/adzw_6.txt|$xargs_2 -0 -P 80 -I delfile_61 sh -c "rm -rf \"delfile_61\" 2>>$sd0/adzw_6_err.txt";} &
sleep 2s

# 查找/data和sd卡中小于350k且N天内没有被访问/修改过的文件
echo "   开始清理15天未使用的影音图片小文件，稍等..."
echo "   *****有可能会删除一些游戏资源文件******"
{ $find_2 ${sd} -type f \( -atime +15 -o -mtime +15 \) -size -350k \( -iname "*.3GP" -o -iname "*.AC3" -o -iname "*.ACC" -o -iname "*.AMR" -o -iname "*.APE" -o -iname "*.ASF" -o -iname "*.ASX" -o -iname "*.BMP" -o -iname "*.FLAC" -o -iname "*.FLV" -o -iname "*.GIF" -o -iname "*.ICO" -o -iname "*.JPEG" -o -iname "*.JPG" -o -iname "*.M4A" -o -iname "*.M4R" -o -iname "*.MKV" -o -iname "*.MMF" -o -iname "*.MP3" -o -iname "*.MP4" -o -iname "*.Ogg" -o -iname "*.PCX" -o -iname "*.PNG" -o -iname "*.SVG" -o -iname "*.SWF" -o -iname "*.TGA" -o -iname "*.TIF" -o -iname "*.WAV" -o -iname "*.WAV" -o -iname "*.WEBM" -o -iname "*.WEBP" -o -iname "*.WMA" -o -iname "*.WV" \) 2>/dev/null|sed -e '/.nomedia/ d' -e '/\/.*_emoji_.*/ d' -e '/\/emoji/ d' -e '/\/emojipackage/ d' -e '/\/icon/ d' -e '/\/Book/ d' -e '/\/Books/ d' -e '/\/DCIM/ d' -e '/\/Download/ d' -e '/\/Movies/ d' -e '/\/Music/ d' -e '/\/Pictures/ d' -e '/\/.*ringtone/ d' -e '/\/Ringtones/ d' -e '/\/WechatXposed/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/MIUI\/theme\/.data/ d'|$xargs_2 -I delfile sh -c "rm -fv delfile 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt";} &
# 采用数组方式定义搜索有扩展名的文件
datafile_list_1=(/data/data /data/system_ce /data/system_de /data/user /data/user_de)
for datafile_dir in ${datafile_list_1[*]}
do
  { $find_2 $datafile_dir -type f \( -atime +15 -o -mtime +15 \) -size -350k \( -iname "*.3GP" -o -iname "*.AC3" -o -iname "*.ACC" -o -iname "*.AMR" -o -iname "*.APE" -o -iname "*.ASF" -o -iname "*.ASX" -o -iname "*.BMP" -o -iname "*.FLAC" -o -iname "*.FLV" -o -iname "*.GIF" -o -iname "*.ICO" -o -iname "*.JPEG" -o -iname "*.JPG" -o -iname "*.M4A" -o -iname "*.M4R" -o -iname "*.MKV" -o -iname "*.MMF" -o -iname "*.MP3" -o -iname "*.MP4" -o -iname "*.Ogg" -o -iname "*.PCX" -o -iname "*.PNG" -o -iname "*.SVG" -o -iname "*.SWF" -o -iname "*.TGA" -o -iname "*.TIF" -o -iname "*.WAV" -o -iname "*.WAV" -o -iname "*.WEBM" -o -iname "*.WEBP" -o -iname "*.WMA" -o -iname "*.WV" \) 2>/dev/null|sed -e '/.nomedia/ d' -e '/\/.*_emoji_.*/ d' -e '/\/emoji/ d' -e '/\/emojipackage/ d' -e '/\/icon/ d'|$xargs_2 -I delfile sh -c "rm -fv delfile 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt";} &
done
# 采用数组方式搜索无扩展名的文件
datafile_list_2=(/data/data /data/system_ce /data/system_de /data/user /data/user_de /data/media)
for smallfile_1 in ${datafile_list_2[*]}
do
  { smallfile_2=$($find_2 $smallfile_1 -type f \( -atime +15 -o -mtime +15 \) -size -350k 2>/dev/null | sed -e '/.nomedia/ d' -e '/\/.*_emoji_.*/ d' -e '/\/emoji/ d' -e '/\/emojipackage/ d' -e '/\/icon/ d' -e '/\/Book/ d' -e '/\/Books/ d' -e '/\/DCIM/ d' -e '/\/Download/ d' -e '/\/Movies/ d' -e '/\/Music/ d' -e '/\/Pictures/ d' -e '/\/.*ringtone/ d' -e '/\/Ringtones/ d' -e '/\/WechatXposed/ d' -e '/\/com.tencent.tmgp.sgame/ d' -e '/\/MIUI\/theme\/.data/ d');
  for smallfile_3 in $smallfile_2;do
    { smallfile_4=${smallfile_3##*.};
    [[ ${#smallfile_4} != "3" && ${#smallfile_4} != "4" ]] && smallfile_5=$(file "$smallfile_3" 2>/dev/null | $awk_2 '{print $2}') || smallfile_5="";
    [[ ( $smallfile_5 != "" && $smallfile_5 != "data" && $smallfile_5 != "empty" ) && ( $smallfile_5 == "BMP" || $smallfile_5 == "JPEG" || $smallfile_5 == "AMR" || $smallfile_5 == "PNG" || $smallfile_5 == "GIF" || $smallfile_5 == "Ogg" || $smallfile_5 == "WAV" ) ]] && (rm -fv "$smallfile_3" 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt);} &
  done;} &
done

# QQ、微信、抖音通用日志清理
tencent_dirlist=$($find_2 /data/data /data/media -type d -iname "com.tencent.mm" -o -iname "com.tencent.mobileqq" -o -iname "com.tencent.qqlite" -o -iname "Tencent" -o -iname "com.ss.android.ugc.aweme" 2>/dev/null)
for tencent_dir in $tencent_dirlist
do
  $find_2 $tencent_dir -type d -iname "*crash*" -o -iname "*log*" 2>/dev/null|sed -e '/\/databases/ d' -e '/\/shared_prefs/ d' -e '/.so/ d' -e '/.db/ d' -e '/.xml/ d'|$xargs_2 -I delfile sh -c "rm -rfv delfile 1>>$sd0/adzw_5.txt 2>>$sd0/adzw_5_err.txt"
done
unset tencent_dir

# 对QQ进行垃圾清理；上面已搜索过一遍QQ影音垃圾了，本段主要搜索大于350k的文件
echo "   开始清理15天未使用的QQ图片、语音、小视频，稍等..."
temp_tencentqq_1=$($find_2 ${sd}/[Tt]encent/[Qq][Qq]Lite -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentqq_2=$($find_2 ${sd}/[Tt]encent/Mobile[Qq][Qq] -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentqq_3=$($find_2 ${sd}/Android/data/com.tencent.mobileqq -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentqq_4=$($find_2 ${sd}/Android/data/com.tencent.qqlite -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentqq_5=$($find_2 /data/data/com.tencent.mobileqq -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentqq_6=$($find_2 /data/data/com.tencent.qqlite -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
for temp_tencentqq_7 in $temp_tencentqq_1 $temp_tencentqq_2 $temp_tencentqq_3 $temp_tencentqq_4 $temp_tencentqq_5 $temp_tencentqq_6
do
  { temp_tencentqq_8=${temp_tencentqq_7##*.};
  if [[ ${#temp_tencentqq_8} != "3" && ${#temp_tencentqq_8} != "4" ]];then
    temp_tencentqq_9=$(file "$temp_tencentqq_7" 2>/dev/null | $awk_2 '{print $2}');
    [[ ( $temp_tencentqq_9 != "data" && $temp_tencentqq_9 != "empty" ) && ( $temp_tencentqq_9 == "BMP" || $temp_tencentqq_9 == "JPEG" || $temp_tencentqq_9 == "AMR" || $temp_tencentqq_9 == "PNG" || $temp_tencentqq_9 == "GIF" || $temp_tencentqq_9 == "Ogg" || $temp_tencentqq_9 == "WAV" ) ]] && (rm -fv "$temp_tencentqq_7" 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt);
  else
    [[ $temp_tencentqq_8 == "amr" || $temp_tencentqq_8 == "jpeg" || $temp_tencentqq_8 == "jpg" || $temp_tencentqq_8 == "png" || $temp_tencentqq_8 == "mp4" || $temp_tencentqq_8 == "bmp" || $temp_tencentqq_8 == "gif" || $temp_tencentqq_8 == "flac" || $temp_tencentqq_8 == "webm" || $temp_tencentqq_8 == "webp" || $temp_tencentqq_8 == "wav" || $temp_tencentqq_8 == "wma" || $temp_tencentqq_8 == "m4a" || $temp_tencentqq_8 == "m4r" || $temp_tencentqq_8 == "mkv" || $temp_tencentqq_8 == "tga" || $temp_tencentqq_8 == "aac" || $temp_tencentqq_8 == "ac3" ]] && (rm -fv "$temp_tencentqq_7" 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt);
  fi;} &
done

# 对微信进行垃圾清理；上面已搜索过一遍QQ影音垃圾了，本段主要搜索大于350k的文件
echo "   开始清理15天未使用的微信图片、语音、小视频，稍等..."
temp_tencentmm_1=$($find_2 ${sd}/[Tt]encent/MicroMsg -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentmm_2=$($find_2 ${sd}/Android/data/com.tencent.mm/MicroMsg -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d')
temp_tencentmm_3=$($find_2 /data/data/com.tencent.mm/MicroMsg -type f \( -atime +15 -o -mtime +15 \) 2>/dev/null | sed -e '/.nomedia/ d' -e '/.so/ d' -e '/.sh/ d' -e '/.db/ d' -e '/.xml/ d' -e '/.crc/ d' -e '/.info/ d' -e '/.cfg/ d' -e '/\/emoji\// d')
for temp_tencentmm_4 in $temp_tencentmm_1 $temp_tencentmm_2 $temp_tencentmm_3
do
  { temp_tencentmm_5=${temp_tencentmm_4##*.};
  if [[ ${#temp_tencentmm_5} != "3" && ${#temp_tencentmm_5} != "4" ]];then
    temp_tencentmm_6=$(file "$temp_tencentmm_4" 2>/dev/null | $awk_2 '{print $2}');
    [[ ( $temp_tencentmm_6 != "data" && $temp_tencentmm_6 != "empty" ) && ( $temp_tencentmm_6 == "BMP" || $temp_tencentmm_6 == "JPEG" || $temp_tencentmm_6 == "AMR" || $temp_tencentmm_6 == "PNG" || $temp_tencentmm_6 == "GIF" || $temp_tencentmm_6 == "Ogg" || $temp_tencentmm_6 == "WAV" ) ]] && (rm -fv "$temp_tencentmm_4" 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt);
  else
    [[ $temp_tencentmm_5 == "amr" || $temp_tencentmm_5 == "jpeg" || $temp_tencentmm_5 == "jpg" || $temp_tencentmm_5 == "png" || $temp_tencentmm_5 == "mp4" || $temp_tencentmm_5 == "bmp" || $temp_tencentmm_5 == "gif" || $temp_tencentmm_5 == "flac" || $temp_tencentmm_5 == "webm" || $temp_tencentmm_5 == "webp" || $temp_tencentmm_5 == "wav" || $temp_tencentmm_5 == "wma" || $temp_tencentmm_5 == "m4a" || $temp_tencentmm_5 == "m4r" || $temp_tencentmm_5 == "mkv" || $temp_tencentmm_5 == "tga" || $temp_tencentmm_5 == "aac" || $temp_tencentmm_5 == "ac3" ]] && (rm -fv "$temp_tencentmm_4" 1>>$sd0/adzw_7.txt 2>>$sd0/adzw_7_err.txt);
  fi;} &
done
$find_2 ${sd}/Android/data/com.tencent.mm/MicroMsg/*/video -type f \( -atime +15 -o -mtime +15 \) -print0 2>/dev/null | $xargs_2 -0 -P 80 rm -rf &>/dev/null &
$find_2 ${sd}/Android/data/com.tencent.mm/MicroMsg/*/video2 -type f \( -atime +15 -o -mtime +15 \) -print0 2>/dev/null | $xargs_2 -0 -P 80 rm -rf &>/dev/null &

# 对MIUI进行垃圾清理
echo "   开始进行MIUI的JPG、PNG清理，稍等..."
$find_2 ${sd}/MIUI -type f \( -atime +15 -o -mtime +15 \) \( -iname "*.png" -o -iname "*.jpg" \) 2>/dev/null |sed -e '/\/MIUI\/theme\/.data/ d' | $xargs_2 -P 80 rm -rf &>/dev/null &

# 清理/data中的APP残余
# 列出所有APP包名
echo "   开始清理已卸载APP的残余文件，稍等..."
pm list packages | $awk_2 -F ':' '{print $2}' >$sd0/adzw_allapp_1.txt
find /system -type d \( -iname "app" -o -iname "*-app" \) 2>/dev/null|$xargs_2 -L 1 ls -lA|grep "^d"|$awk_2 '{print $9}'>>$sd0/adzw_allapp_1.txt
find /vendor -type d \( -iname "app" -o -iname "*-app" \) 2>/dev/null|$xargs_2 -L 1 ls -lA|grep "^d"|$awk_2 '{print $9}'>>$sd0/adzw_allapp_1.txt
# 对adzw_allapp_1.txt文件(APP列表)进行排序，并删除重复行
sort -n $sd0/adzw_allapp_1.txt | uniq >$sd0/adzw_allapp_2.txt
# 采用数组方式定义搜索路径
find_chear_apppath=(/data/app /data/data /data/user_de/0 ${sd}/Android/data)
for chear_apppath in ${find_chear_apppath[*]}
do
  { ls -lA $chear_apppath |grep "^d"|$awk_2 '{print $9}'|$awk_2 -F '[ -]' '{print $1}'>$sd0/adzw${chear_apppath//\//_}.txt;
  for chear_appname in `cat $sd0/adzw${chear_apppath//\//_}.txt`;do
    [[ ! `grep -ix "$chear_appname" $sd0/adzw_allapp_2.txt` ]] && (pm uninstall $chear_appname &>/dev/null;sleep 0.5s;chattr -R -i $chear_apppath/$chear_appname &>/dev/null;rm -rfv "$chear_apppath/$chear_appname" 1>>$sd0/adzw_8.txt 2>>$sd0/adzw_8_err.txt);
  done;} &
done

# 禁用毒瘤app
dis_app=(com.miui.analytics com.miui.systemAdSolution)
for temp_dis_app_1 in ${dis_app[*]}
do
  temp_enable_app=$(pm list packages -e | cut -f2 -d ':' | grep ${temp_dis_app_1})
  temp_dis_app_2=$(pm list packages -d | cut -f2 -d ':' | grep ${temp_dis_app_1})
  if [[ -n "$temp_enable_app" ]];then
    echo "   正在pm disable禁用${temp_dis_app_1}，稍等..."
    pm disable ${temp_dis_app_1} &>/dev/null
    temp_dis_app_3=$(pm list packages -d | cut -f2 -d ':' | grep ${temp_dis_app_1})
# 检测毒瘤app是否disable失败，query_dis_app为“1”表示失败
    [[ -z "$temp_dis_app_3" ]] && query_dis_app=1 || { query_dis_app=0;echo "   ${temp_dis_app_1}禁用成功！";}
    [[ -n "$(pidof -s ${temp_dis_app_1})" || $query_dis_app == "1" ]] && { pm hide ${temp_dis_app_1} &>/dev/null;query_hide_app=$?;}
    [[ $query_hide_app == "0" ]] && echo "   采用pm hide禁用${temp_dis_app_1}成功！"
    [[ $query_dis_app != "0" && $query_hide_app != "0" ]] && echo "   ${temp_dis_app_1}禁用失败！"
    if [[ -f /data/adb/modules/zw_fileclear/uninstall.sh ]];then
       [[ $query_dis_app == "0" ]] && echo "/system/bin/pm enable ${temp_dis_app_1}" >>/data/adb/modules/zw_fileclear/uninstall.sh
       [[ $query_hide_app == "0" ]] && echo "/system/bin/pm unhide ${temp_dis_app_1}" >>/data/adb/modules/zw_fileclear/uninstall.sh
    fi
  elif [[ -n "$temp_dis_app_2" ]];then
    echo "   检测到${temp_dis_app_1}已备禁用"
  else
    echo "   没有检测到${temp_dis_app_1}，没安装该App?!"
  fi
done

# 一些系统特殊垃圾;因安卓系统特性，部分手机上删除文件夹只能用rm -r，不能有参数f
for num_temp in {1..2}
do
echo "   开始清理系统缓存、日志垃圾，第 $num_temp 遍"
# 无响应日志
  rm -rf /data/anr/* &>/dev/null
# 系统暂挂备份文件
  rm -rf /data/backup/pending/* &>/dev/null
# 系统(应用)崩溃日志
  rm -rf /data/crashdata/* &>/dev/null
  rm -rf /data/tombstones/* &>/dev/null
  rm -rf /dev/fscklogs/* &>/dev/null
  rm -rf /idd/crashdata/* &>/dev/null
  rm -rf /data/data/com.android.shell/files/bugreports &>/dev/null
#  rm -rf /data/dalvik-cache/* &>/dev/null
# 系统跟踪记录
  rm -rf /data/local/* &>/dev/null
# DropBox的日志
  rm -rf /data/system/dropbox/* &>/dev/null
# 安装缓存
  rm -rf /data/system/package_cache/* &>/dev/null
# 进程统计
  rm -rf /data/system/procstats/* &>/dev/null
# App启动统计信息
  rm -rf /data/system/usagestats/* &>/dev/null
# 同步管理日志
  rm -rf /data/system/syncmanager-log/* &>/dev/null
  rm -rf /data/system_ce/0/recent_images/* &>/dev/null
# "最近任务"缓存
  rm -rf /data/system_ce/0/recent_tasks/* &>/dev/null
  rm -rf /data/system_ce/0/snapshots/* &>/dev/null
  rm -rf /sys/kernel/debug/* &>/dev/null
  rm -rf /proc/sys/debug/* &>/dev/null
# 电池用量统计
  rm -rf /data/system/batterystats.bin &>/dev/null
  rm -rf /data/system/batterystats-checkin.bin &>/dev/null
# MIUI Wifi日志
  rm -rf /data/vendor/wlan_logs/* &>/dev/null
  rm -rf /data/vendor/charge_logger/* &>/dev/null
# 搜狗输入法垃圾
  rm -rf /data/data/com.sohu.inputmethod.sogou/databases/sogou_push &>/dev/null
  sleep 0.5s
done

# 删除App缓存信息，防止清理垃圾、重启后App崩溃和Bug;
$find_2 /data/misc/profiles -type f -iname "primary.prof" 2>/dev/null | $xargs_2 -P 80 -I delfile_81 sh -c "echo \"\">delfile_81"
# 再一次清理data分区中临时文件(夹)
$find_2 /data \( -iname "*cache*" -o -iname "*.log" -o -iname "*.logs" \) 2>/dev/null | sed -e '/.auth_cache/ d' -e '/yttrium_code_cache/ d' -e '/dalvik_cache/ d' -e '/\/lib\// d' -e '/\/lib64\// d' -e '/.so/ d' | $xargs_2 -P 80 -n 20 rm -rf &>/dev/null;

echo -e "\033[36m   各项清理任务还在紧张执行中，请等...\033[0m"
wait

# 对data/data和SD卡进行空目录、空文件夹清理;
echo "   开始进行进行最后的打扫：空文件和空文件夹清理，稍等..."
[[ $find_1 == "1" ]] && { start_ffile_num=`$find_2 ${sd} -type f -empty ! -iname ".nomedia" 2>/dev/null|wc -l`;start_fdir_num=`$find_2 /data -type d -empty 2>/dev/null|wc -l`;}
if [[ $find_1 == "1" ]]
then
  $find_2 ${sd} -type f -empty ! -iname ".nomedia" -delete &>/dev/null
else
  for ffile in `find ${sd} -type f -size 0c|sed -e '/.nomedia/ d'`;do
    if [[ ! -s "$ffile" ]];then
      rm -rf "$ffile" &>/dev/null
      [[ $? == "0" ]] && ffile_num=$(($ffile_num+1))
    fi
  done
fi
# 清理空文件夹;遍历3遍，清理镶套空文件夹；fidn -empty能够递归删除空目录
for z in {1..3}
do
  if [[ $find_1 == "1" ]];then
    $find_2 /data -type d -empty -delete &>/dev/null
  else
   { for fdir_1 in `find /data -type d`;do
      empty_dir_1=$(ls -A "$fdir_1" 2>/dev/null);
      if [[ -z "$empty_dir_1" ]];then
        rm -rf "$fdir_1" &>/dev/null;
        [[ $? == "0" ]] && fdir_num=$(($fdir_num+1));
        echo $fdir_num >>$sd0/adzw_emptydir.txt;
      fi;
    done;}
  fi
  sleep 1s;
done
[[ $find_1 == "1" ]] && { end_ffile_num=`$find_2 ${sd} -type f -empty ! -iname ".nomedia" 2>/dev/null|wc -l`;end_fdir_num=`$find_2 /data -type d -empty 2>/dev/null|wc -l`;let ffile_num="start_ffile_num - end_ffile_num";let fdir_num="start_fdir_num - end_fdir_num";}
[[ $find_1 == "2" ]] && fdir_num=`cat $sd0/adzw_emptydir.txt|$awk_2 '{sum +=$1};END {print sum}'`
for mk_sddir_1 in $sd
do
  mkdir -p $mk_sddir_1/DCIM $mk_sddir_1/Download  $mk_sddir_1/Pictures/WeiXin $mk_sddir_1/Android/data/com.tencent.mm/MicroMsg/Download &>/dev/null
done

echo -e "\033[1m—————————————————————————————————————————\033[0m"
wait

# 对日志文件进行排序、去重,通过wc和awk命令统计数量;
for sort_uniq in `ls $sd0/adzw_*.txt`
do
  sed -i -e '/No such/ d' -e '/command not found/ d' -e '/\/data\/user\/0/ d' -e '/\/.magisk\/mirror/ d' -e '/\/data_mirror\/data_ce\/null/ d' $sort_uniq
  sort -n $sort_uniq | uniq >$sd0/adzw_sort.txt
  mv -f $sd0/adzw_sort.txt $sort_uniq
done
[[ ! -f $sd0/adzw_1_err.txt ]] && num_1_err=0 || num_1_err=`wc -l $sd0/adzw_1_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_2_err.txt ]] && num_2_err=0 || num_2_err=`wc -l $sd0/adzw_2_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_3_err.txt ]] && num_3_err=0 || num_3_err=`wc -l $sd0/adzw_3_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_4_err.txt ]] && num_4_err=0 || num_4_err=`wc -l $sd0/adzw_4_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_5_err.txt ]] && num_5_err=0 || num_5_err=`wc -l $sd0/adzw_5_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_6_err.txt ]] && num_6_err=0 || num_6_err=`wc -l $sd0/adzw_6_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_7_err.txt ]] && num_7_err=0 || num_7_err=`wc -l $sd0/adzw_7_err.txt|$awk_2 '{print $1}'`
[[ ! -f $sd0/adzw_1.txt ]] && num_1=0 || let num_1="`wc -l $sd0/adzw_1.txt|$awk_2 '{print $1}'` - num_1_err / 2"
[[ ! -f $sd0/adzw_2.txt && $num_2_0 ]] && num_2=0 || let num_2="`wc -l $sd0/adzw_2.txt|$awk_2 '{print $1}'` - num_2_err / 2 + num_2_0"
[[ ! -f $sd0/adzw_3.txt && $num_3_0 ]] && num_3=0 || let num_3="`wc -l $sd0/adzw_3.txt|$awk_2 '{print $1}'` - num_3_err / 2 + num_3_0"
[[ ! -f $sd0/adzw_4.txt ]] && num_4=0 || let num_4="`wc -l $sd0/adzw_4.txt|$awk_2 '{print $1}'` - num_4_err"
[[ ! -f $sd0/adzw_5.txt ]] && num_5=0 || let num_5="`wc -l $sd0/adzw_5.txt|$awk_2 '{print $1}'` - num_5_err"
[[ ! -f $sd0/adzw_6.txt ]] && num_6=0 || let num_6="`wc -l $sd0/adzw_6.txt|$awk_2 '{print $1}'` - num_6_err"
[[ ! -f $sd0/adzw_7.txt ]] && num_7=0 || num_7="`wc -l $sd0/adzw_7.txt|$awk_2 '{print $1}'`"
[[ ! -f $sd0/adzw_8.txt ]] && num_8=0 || num_8="`wc -l $sd0/adzw_8.txt|$awk_2 '{print $1}'`"
# 回收文件系统未使用的空间
echo "   第2次回收文件系统未使用的空间ing..."
$fstrim_2 -v / &>/dev/null
/system/bin/ls -l / |grep ^d|$awk_2 '{print $8}'|$xargs_2 -I fstrim_temp $fstrim_2 -v /fstrim_temp &>/dev/null
wait
sm fstrim 2>/dev/null
# 获取清理后的data、sd卡已使用空间大小，并计算清理了多少MB的垃圾;用awk命令实现小数运算!
end_used_allsys=`df /apex /cache /cust /data /dev /metadata /mnt /sys /system /vendor 2>/dev/null|$awk_2 'NR!=1 {used+=$3}END{used=used/1024;print used}' 2>/dev/null`
end_used_data=`du -smL /data/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
end_used_sd=`du -smL ${sd}/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
end_used_sdandro=`du -smL ${sd}/Android/ 2>/dev/null|$awk_2 '{print $1}' 2>/dev/null`
used_allsys=`$awk_2 'BEGIN{print('$start_used_allsys' - '$end_used_allsys')}'`
used_data=`$awk_2 'BEGIN{print('$start_used_data' - '$end_used_data')}'`
used_sd=`$awk_2 'BEGIN{print('$start_used_sd' - '$end_used_sd')}'`
used_sdandro=`$awk_2 'BEGIN{print('$start_used_sdandro' - '$end_used_sdandro')}'`
# 耗时计算
wait
endtime=`date +%s`
sumtime_1=$(( endtime-starttime ))
sumtime_2=$(date -d"@$sumtime_1" | awk '{print $4}'| awk 'BEGIN{FS=":"}{$1=$1-8;if($1<=0 && $2<=0){print $3"秒"}else if($1<=0){print $2"分"$3"秒"}else{print $1"时"$2"分"$3"秒"}}')

yes_module(){
# 为面具模块状态运行时，结果输出至SD卡的日志文件
let num_module_dir="num_1 + num_2 + num_3"
let num_module_file="num_4 + num_5 + num_6"
echo -e "   ******        FileClear_for_ZW执行成功         ******\n " >>$sd0/FileClear_zw_$nowtime.txt
echo "       本次运行耗时:${sumtime_2}，共清理${used_allsys}MB；其中：" >>$sd0/FileClear_zw_$nowtime.txt
echo "       data分区清理了`$awk_2 'BEGIN{print('$used_data' - '$used_sd')}'`MB(不含sd卡)" >>$sd0/FileClear_zw_$nowtime.txt
echo "       sd卡清理了`$awk_2 'BEGIN{print('$used_sd' - '$used_sdandro')}'`MB(不含Android文件夹)" >>$sd0/FileClear_zw_$nowtime.txt
echo "       Android文件夹清理了${used_sdandro}MB" >>$sd0/FileClear_zw_$nowtime.txt
echo "    ***********************************" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$num_module_file个文件" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$num_module_dir个文件夹" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$ffile_num个空文件" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$fdir_num个空文件夹" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$num_8个APP残留文件夹" >>$sd0/FileClear_zw_$nowtime.txt
echo "       共删除$num_7个影音图片小文件" >>$sd0/FileClear_zw_$nowtime.txt
echo "       已对$adzw_ad_num个广告毒瘤屏蔽/禁写入" >>$sd0/FileClear_zw_$nowtime.txt
echo "    ***********************************" >>$sd0/FileClear_zw_$nowtime.txt
echo "" >>$sd0/FileClear_zw_$nowtime.txt
echo "" >>$sd0/FileClear_zw_$nowtime.txt
sed -i "s/^FileClear_logname.*/FileClear_logname=FileClear_zw_$nowtime.txt/g" /data/adb/modules/zw_fileclear/service.sh
sed -i "s/^Runj11time.*/Runj11time=$endtime/g" /data/adb/modules/zw_fileclear/service.sh
# 写入module.prop文件
sed -i "/^description=.*/ d" ${MODDIR}/module.prop
echo "description=【😊于$(date +"%Y-%m-%d %T")成功执行了深度清理；耗时${sumtime_2}；清理垃圾${used_allsys}MB】本次清理垃圾文件$num_module_file个，垃圾文件夹$num_module_dir个，<350k的冗余影音文件$num_7个！删除空文件$ffile_num个，空文件夹$fdir_num个，已卸载App残留的文件夹$num_8个；并对$adzw_ad_num个广告毒瘤文件(夹)进行了屏蔽和禁写入。具体日志请移步SD卡，查阅FileClear_zw_$nowtime.txt文件！！！" >> ${MODDIR}/module.prop
}

no_module(){
# 非面具模块状态运行时，结果输出至控制台
[[ $num_4 != "0" ]] && echo "   已全盘删除$num_4个文件"
[[ $num_1 != "0" ]] && echo "   已全盘删除$num_1个文件夹"
[[ $num_6 != "0" ]] && echo "   已在sd卡中删除$num_6个文件"
[[ $num_3 != "0" ]] && echo "   已在sd卡中删除$num_3个文件夹"
[[ $num_7 != "0" ]] && echo "   已在sd卡中删除$num_7个影音图片小文件"
[[ $num_5 != "0" ]] && echo "   已在data分区中删除$num_5个文件"
[[ $num_2 != "0" ]] && echo "   已在data分区中删除$num_2个文件夹"
[[ $num_8 != "0" ]] && echo "   已在data和sd卡中删除$num_8个APP残留文件夹"
[[ $ffile_num != "0" ]] && echo "   已在sd卡中删除$ffile_num个空文件"
[[ $fdir_num != "0" ]] && echo "   已在data和sd卡中删除$fdir_num个空文件夹"
echo "   已对data和sd卡中$adzw_ad_num个广告文件夹进行了加固"
echo -e "\033[32m \033[1m—————————————————————————————————————————\033[0m"
echo "   本次运行耗时:${sumtime_2}，共清理${used_allsys}MB；其中"
echo "   data分区清理了`$awk_2 'BEGIN{print('$used_data' - '$used_sd')}'`MB(不含sd卡)"
echo "   sd卡清理了`$awk_2 'BEGIN{print('$used_sd' - '$used_sdandro')}'`MB(不含Android文件夹)"
echo "   Android文件夹清理了${used_sdandro}MB"
echo ""
}

catch_log(){
# 归集日志至log
echo "*********** 清理列表如下 *******">>$sd0/FileClear_zw_$nowtime.txt
echo "">>$sd0/FileClear_zw_$nowtime.txt
$awk_2 'logtxt_1!=FILENAME{logtxt_1=FILENAME;print "****** "logtxt_1" ******"} {print "\t"$0}' $sd0/adzw_[0-15].txt >>$sd0/FileClear_zw_$nowtime.txt
echo "*********** 错误信息列表如下 ***********">>$sd0/FileClear_zw_$nowtime.txt
echo "">>$sd0/FileClear_zw_$nowtime.txt
$awk_2 'logtxt_2!=FILENAME{logtxt_2=FILENAME;print "****** "logtxt_2" ******"} {print "\t"$0}' $sd0/adzw_[0-15]_err.txt >>$sd0/FileClear_zw_$nowtime.txt
echo "*********** 广告文件夹加固列表如下 ***********">>$sd0/FileClear_zw_$nowtime.txt
echo "">>$sd0/FileClear_zw_$nowtime.txt
cat $sd0/adzw_ad.txt >>$sd0/FileClear_zw_$nowtime.txt
}

reboot_call_miuicleanmaster(){
if [[ `getprop ro.product.brand` = "Xiaomi" && -n `find /data/app -type d -iname "com.topjohnwu.magisk*"` ]]
then
  echo -e "\033[32m \033[1m  清理脚本运行完毕！！！30秒后自动重启手机 ！！\033[0m"
  echo -e "\033[32m \033[1m  重启后将调用MIUI官方清理APP，请手动清理  ！！\033[0m"
  echo ""
  [[ ! -d /data/adb/service.d ]] && mkdir -p /data/adb/service.d
  echo '#!/system/bin/sh'>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  echo '# 这是FileClear for ZW(APP和垃圾清理模块)创建的一次性Shell脚本文件，旨在重启后通过面具APP启动MIUI Cleanmaster'>>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  echo 'sleep 25s'>>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  echo 'su -c "am start -a miui.intent.action.GARBAGE_CLEANUP -p com.miui.cleanmaster"'>>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  echo 'rm -rf $0'>>/data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  chmod 777 /data/adb/service.d/call_miuicleanmaster-for-zw_fileclear.sh
  sleep 30s
  rm -rf ${sd}/adzw* &>/dev/null
  reboot
else
  echo -e "\033[32m \033[1m  清理脚本运行完毕！！！30秒后自动重启手机 ！！\033[0m"
  echo ""
  sleep 30s
  rm -rf ${sd}/adzw* &>/dev/null
  reboot
fi
}

[[ $SELinux_on == "1" ]] && setenforce 1
[[ $module_31 == "1" ]] && alias sh=$sh_1
unalias am
unalias pm
$find_2 ${sd} -iname "FileClear_zw_*.txt" \( -atime +3 -o -mtime +3 \) -delete &>/dev/null

if [[ $module_21 == "1" ]]
then
  yes_module
  catch_log
  wait
  reboot_call_miuicleanmaster
else
  no_module
  for input_key_1 in $*;do
    [[ $input_key_1 == "-l" || $input_key_1 == "l" || $input_key_1 == "log" ]] && (catch_log;sed -i "1i\  本次运行耗时:${sumtime_2}，共清理${used_allsys}MB" $sd0/FileClear_zw_$nowtime.txt)
  done
  wait
  reboot_call_miuicleanmaster
fi