#!/system/bin/sh

  ui_print "*******************************"
  ui_print "    Force High resolution!     "
  ui_print "*******************************"


DEVICE=`getprop ro.product.device`



ui_print "Installing... "
 ui_print "High resolution for "$DEVICE" ..."

