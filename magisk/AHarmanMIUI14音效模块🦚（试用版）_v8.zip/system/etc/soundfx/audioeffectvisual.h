#ifndef ANDROID_EFFECT_VISUALIZER_H_
#define ANDROID_EFFECT_VISUALIZER_H_

//------包含audio_effect.h，其中定义了音效库接口、音效控制接口
#include <hardware/audio_effect.h>

//------C/C++条件编译syetem/priv-app/MIUIMusic
#if __cplusplus
extern "C" {
#endif

//...省略...

//------参数常量，需要与Java中的定义保持同步（一致）
// to keep in sync with frameworks/base/media/java/android/media/audiofx/Visualizer.java
#define VISUALIZER_SCALING_MODE_NORMALIZED 0
#define VISUALIZER_SCALING_MODE_AS_PLAYED  1

//------音效参数枚举
//通过该参数进行对应控制，从Java层传进的参数序号正是与此对应
/* enumerated parameters for Visualizer effect */
typedef enum
{
    VISUALIZER_PARAM_CAPTURE_SIZE, // Sets the number PCM samples in the capture.
    VISUALIZER_PARAM_SCALING_MODE, // Sets the way the captured data is scaled
    VISUALIZER_PARAM_LATENCY,      // Informs the visualizer about the downstream latency
} t_visualizer_params;

//------音效控制命令
//audio_effect.h中已经预设了EFFECT_CMD_SET_PARAM等命令，此处是Visualizer自增的命令
/* commands */
typedef enum
{
    VISUALIZER_CMD_CAPTURE = EFFECT_CMD_FIRST_PROPRIETARY, // Gets the latest PCM capture.
}t_visualizer_cmds;

#if __cplusplus
}  // extern "C"
#endif

#endif /*ANDROID_EFFECT_VISUALIZER_H_*/read/system/priv_app/AudioEffect/AudioEffect_1.4.apk                ro.vendor.audio.sfx.harmankardon=1audio player; music player==turepublic Equalizer(int priority, int audioSession)
    throws IllegalStateException, IllegalArgumentException,
           UnsupportedOperationException, RuntimeException {
        super(EFFECT_TYPE_EQUALIZER, EFFECT_TYPE_NULL, priority, audioSession);LOCAL_PATH:= $(call my-dir)

# Visualizer library
include $(CLEAR_VARS)

LOCAL_SRC_FILES:= \
    EffectVisualizer.cpp #实现源码.cpp

LOCAL_CFLAGS+= -O2

LOCAL_SHARED_LIBRARIES := \
    libcutils \
    libdl 

LOCAL_MODULE_PATH := $(TARGET_OUT_SHARED_LIBRARIES)/soundfx #编译出so的输出位置，默认/system/lib/soundfx/
LOCAL_MODULE:= libvisualizer #so库名：libvisualizer.so

LOCAL_C_INCLUDES := \
    $(call include-path-for, graphics corecg) \
    $(call include-path-for, audio-effects) # 调用宏定义函数批量引入库，audio-effects的定义位于/build/core/pathmap.mk，其值为system/media/audio_effects/include ，该位置包含了effect_visualizer.h

include $(BUILD_SHARED_LIBRARY)