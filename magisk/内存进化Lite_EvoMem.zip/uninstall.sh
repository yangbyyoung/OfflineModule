rm -rf /cache/EvoMem.log
rm -rf /data/EvoMem.conf