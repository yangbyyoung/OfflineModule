#!/system/bin/sh
#负优化部分
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

MODDIR=${0%/*}

settings put global hide_error_dialogs 1

chmod -R 777 $MODDIR/mod

crond -c $MODDIR/mod

for i in $MODDIR/mod/*.sh ;do
	$i 2>/dev/null
done


