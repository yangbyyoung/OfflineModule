#!/system/bin/sh
#————————————————————————#
MODDIR="$(dirname "$0")"
[[ $(cat $MODDIR/module.prop | grep $(echo -en '\u0048\u0043\u0068\u0061\u0069')) == "" ]] && sed -i "s/author=.*/author=$(echo -en '\u0048\u0043\u0068\u0061\u0069')/g" $MODDIR/module.prop
rm -rf $MODDIR/refrigerator
#————————————————————————#
while [ -z "$boot" ]; do
	sleep 10
	boot=$(getprop ro.boot.bootreason)
done
ac=null
until [ $ac = "false" ]; do
	#rosan检测
	ac=$(/system/bin/app_process -Djava.class.path=$MODDIR/compilations.dex /system/bin com.rosan.shell.ActiviteJava)
	sleep 5
done
sleep 5
home=$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')
sed -i "s/home=.*/home=$(hcpid $home)/g" /data/media/0/Android/Hc_tombstone/配置.conf

echo 1 > /proc/sys/vm/overcommit_memory
freezer()
{
$MODDIR/HC_freezer
sleep 2
freezer
}
freezer
