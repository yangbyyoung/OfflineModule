
SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false


print_modname() {
  ui_print "*******************************"
  ui_print "       by Abzmdbzb       "
  ui_print "*******************************"
  ui_print "    酷安：不知名的白中白   "
  ui_print "*******************************"
  ui_print "      文件较大，请稍等     "
}

REPLACE_EXAMPLE="
/data/system/package_cache/

"

REPLACE="




"

on_install() {
  ui_print "*******************************"
  ui_print "- 欢迎使用此模块，刷入此模块自行承担风险"
  ui_print "*******************************"
  ui_print "- 作者是个小白，不喜勿喷"
  ui_print "*******************************"
  ui_print "- 正在释放文件"
  ui_print "*******************************"
  ui_print "- 刷入完成，重启即可"
  ui_print "*******************************"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
  }


