MODDIR=${0%/*}
SakikoPower_config=/data/SakikoPower.conf
log_file=/cache/SakikoPower.log

rm -rf $log_file

if [ ! -f "/data/SakikoPower.conf" ]; then
    cp -f $MODDIR/SakikoPower.conf /data/
fi

function get_prop() {
    cat $SakikoPower_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

function log() {
    if [[ "$disable_log" == 'false' ]]; then
        echo "[$(date | awk '{print $4}')] $@" >>"$log_file"
    fi
}

function cpuonline(){
    if [[ "$disable_online" == 'true' ]]; then
        echo 0 > /sys/devices/system/cpu/cpu4/online
        echo 0 > /sys/devices/system/cpu/cpu7/online
        log "已关闭CPU4和CPU7"
    fi
}

function cpuopt(){
    if [[ "$use_powersave" == 'true' ]]; then
        cpu=`ls /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor`
        for a in $cpu
        do
            chmod 644 $a
            echo powersave > $a
        done
        log "已使用省电调度"
    fi
}

function boostopt(){
    boost=`ls /dev/stune/*/schedtune.boost`
    for b in $boost
    do
        echo 0 > $b
    done
}

disable_googleservice=$(get_prop 禁用谷歌服务)
battery_optimization=$(get_prop 开启电池优化)
disable_online=$(get_prop 关闭两颗核心)
use_powersave=$(get_prop 使用省电调度)
disable_log=$(get_prop 关闭模块日志)

log "模块开始运行"

sleep 60
cpuonline
cpuopt
boostopt
public boolean setDynamicPowerSaveHint

source $MODDIR/SakikoPower
