#!/system/bin/sh
MODDIR=${0%/*}
install_config="$MODDIR/install_config.conf"
function get_prop() {
  cat $install_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

# set_value value path
function set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2
  fi
}

function wait_sys_boot_completed()
{
	while true
	do
		sleep 10
		boot_completed=$(getprop sys.boot_completed)
		if [[ "$boot_completed" == "1" ]];then
			return
		fi
	done
}
#wait_sys_boot_completed

if [ $(get_prop log) = "TRUE" ]; then
    rm -rf /data/vivono.log
    echo 等待运行 >> /data/vivono.log
fi
while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 1
done
/data/local/tmp/shizuku_starter
#dmode=$(get_prop mode)
gw=$(get_prop gwd)
fue=$(get_prop fued)
gcp=$(get_prop gcp)

if [ "$gw" = "true" ]; then
    cp $MODDIR/16.apk /data/local/tmp
    cp $MODDIR/30056.apk /data/local/tmp

    pm install -r -d /data/local/tmp/16.apk
    pm install -r -d /data/local/tmp/30056.apk
    
fi
    
if [ "$fue" = "true" ]; then
    pm install -r -d $MODDIR/FuntouchUIEngine_2.0.0.4.apk
    
fi
    
if [ "$gcp" = "true" ]; then
    pm install -r -d $MODDIR/gamecube_11.1.4.009.apk
    
fi