##########################################################################################
#
# Magisk模块安装脚本
#
##########################################################################################
##########################################################################################
#
# 说明:
#
# 1. 将文件放入系统文件夹（删除placeholder文件）
# 2. 将模块的信息填入module.prop
# 3. 在此文件中配置和实现调用
# 4. 如果需要启动脚本，请将它们添加到common/post-fs-data.sh或common/service.sh
# 5. 将附加或修改的系统属性添加到common/system.prop
#
##########################################################################################

##########################################################################################
# 配置开关
##########################################################################################

# system 关闭=true,启用=false
SKIPMOUNT=true

# system.prop 启用=true,关闭=false
PROPFILE=false

# post-fs-data 启用=true,关闭=false
POSTFSDATA=false

# service.sh 启用=true,关闭=false
LATESTARTSERVICE=true

##########################################################################################
# 替换列表
##########################################################################################

# 列出要在系统中直接替换的所有目录
# 查看官方文档以获取有关您需要的更多信息

# 按以下格式构建列表
# 这是一个例子
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里构建自定义列表
REPLACE="
"

##########################################################################################
#
# 函数调用
#
# 安装框架将调用以下函数。
# 您无法修改update-binary，这是您可以自定义的唯一方法
# 安装时通过实现这些功能。
#
# 在运行回调时，安装框架将确保Magisk
# 内部busybox的路径是*PREPENDED*到PATH,因此,所有常用命令应存在。
# 此外,它还将确保正确安装/data, /system和/vendor.
#
##########################################################################################
##########################################################################################
#
# 安装框架将导出一些变量和函数。
# 您应该使用这些变量和函数进行安装。
# 
# !不要使用任何Magisk内部路径，因为它们不是公共API。
# !请勿在util_functions.sh中使用其他函数，因为它们不是公共API。
# !不保证非公共API可以保持版本之间的兼容性。
#
# 可用变量:
#
# MAGISK_VER (string): 当前安装的Magisk的版本字符串
# MAGISK_VER_CODE (int): 当前安装的Magisk的版本代码
# BOOTMODE (bool): 如果模块当前正在Magisk Manager中安装,则为true
# MODPATH (path): 应安装模块文件的路径
# TMPDIR (path): 临时存储文件的地方
# ZIPFILE (path): 安装模块文件zip
# ARCH (string): 设备的架构.值为arm,arm64,x86或x64
# IS64BIT (bool): 如果$ ARCH是arm64或x64,则为true
# API (int): 设备的API级别(Android版本)
#
# 可用功能:
#
# ui_print <msg>
#     打印 <msg> 到安装界面
#     避免使用 'echo' 因为它不会显示在自定义安装界面
#
# 中止 <msg>
#     打印错误消息 <msg> 到安装界面和终止安装
#     避免使用 'exit' 因为它会跳过终止清理步骤
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# 如果需要启动脚本，请不要使用通用启动脚本 (post-fs-data.d/service.d)
# 只使用模块的脚本，因为它尊重模块状态 (remove/disable) and is
# 保证在未来的Magisk版本中保持相同的行为.
# 通过设置上面config部分中的标志启用引导脚本.
##########################################################################################
#〖电池电量〗
battery0=`cat /sys/class/power_supply/battery/capacity` >/dev/null 2>&1
#〖电池温度〗
battery1=`cat /sys/class/power_supply/battery/temp` >/dev/null 2>&1
battery1=$(awk -v x=$battery1 'BEGIN{print x/10}')
#〖电池类型〗
battery2=`cat /sys/class/power_supply/battery/technology` >/dev/null 2>&1
#〖电池容量〗
battery3=`cat /sys/class/power_supply/battery/charge_full_design` >/dev/null 2>&1
battery3=$(awk -v x=$battery3 'BEGIN{print x/1000}')
#〖最大电压〗
battery4=`cat /sys/class/power_supply/battery/voltage_max` >/dev/null 2>&1
battery4=$(awk -v x=$battery4 'BEGIN{print x/1000}')
#〖最大电流〗
battery5=`cat /sys/class/power_supply/battery/constant_charge_current_max` >/dev/null 2>&1
battery5=$(awk -v x=$battery5 'BEGIN{print x/10000}')
battery6=`cat /sys/module/phy_msm_usb/parameters/dcp_max_current` >/dev/null 2>&1
battery6=$(awk -v x=$battery6 'BEGIN{print x/1000}')

# 设置安装模块时要显示的内容

print_modname() {
  ui_print "====================================================="
  ui_print " "
  ui_print " "
  ui_print " "
  ui_print "     	               【充电控制】"
  ui_print " "
  ui_print " "
  ui_print " "
  ui_print "====================================================="
  ui_print " -------------------【乄代号9527】------------------"
  ui_print "====================================================="
  ui_print "                     🔋电池信息->>"
  ui_print "         电池余量 $battery0 %     |  电池温度 $battery1 ℃"
  ui_print "         最大电压 $battery4 V   |  最大电流 $battery5$battery6 mA"
  ui_print "         电池容量 $battery3 mAh |  电池类型 $battery2"
  ui_print "====================================================="
  ui_print "                     ‼️温馨提示->>"
  ui_print "                 使用快充模块有害手机健康"
  ui_print "                不使用快充模块有益手机健康"
  ui_print "----------------------------------------------------"
  ui_print "                📵快充对手机的六大危害->>"
  ui_print "1、现在手机采用的基本都是锂离子电池，对于锂电池来说，高温下工作除了正常的充放电，还会有一些副反应，比如电解液分解，电极上产生沉积物等，而这些物质自然会有电池产生影响，对电池造成损耗。"
  ui_print "2、快充会使电池温度升高，从而破坏电池的电解物质，导致电池容量慢慢变小。"
  ui_print "3、频繁充电，也会损坏电池，长时间下来，你就会发现电池待机越来越短，电池的使用寿命也会变短。"
  ui_print "4、边充电边打游戏，这样会让手机温度急剧上升，触发温控降频，影响游戏体验与队友的游戏体验，及严重加速电池老化。"
  ui_print "5、不论是快充还是普通充电其实都会对电池造成不可逆的损害，但快充的损害比普通充电更多。"
  ui_print "6、过大功率的充电还会对手机、充电器及充电线造成短路，对生命财产安全造成威胁。"
  ui_print "====================================================="
  ui_print "                      📄免责声明->>"
  ui_print "▪ 任何用户在使用「🔋充电控制」模块(以下简称本模块)之前，均应仔细阅读并透彻理解本声明，您可以选择不使用，但如果您使用本模块，您的使用行为将被视为对本声明全部内容的认可。"
  ui_print "▪ 鉴于本模块是对系统核心文件的修改，因使用本模块而可能遭致的意外、疏忽及其造成的损失（包括手机无法开机，因过大的电流对手机、充电器、充电线而导致短路无法充电），本模块对其概不负责，作者本人亦不承担任何法律责任。"
  ui_print "▪ 本模块根据个人兴趣及需求制作，不代表作者本人赞成使用本模块。"
  ui_print "▪ 您应该对使用本模块的结果自行承担风险。作者本人不做任何形式的保证：不保证充电效果满足您的要求，不保证本模块对系统的安全性、适用性、正确性。因任何原因而导致您不能正常使用手机，作者本人不承担任何法律责任。"
  ui_print "▪ 如您不认可本声明，请立即对本模块进行卸载删除。"
  ui_print " "
  ui_print "---乄代号9527"
  ui_print "====================================================="
}

# 在安装脚本中将模块文件复制/解压缩到 $MODPATH.

on_install() {
  # 以下是默认设置: 将 $ZIPFILE/system解压缩到 $MODPATH
  # 将逻辑扩展/更改为您想要的任何内容
  ui_print "- 提取文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# 只有一些特殊文件需要特定权限
# 安装完成后，此功能将被调用
# 对于大多数情况，默认权限应该已经足够

set_permissions() {
  # 以下是默认规则,请勿删除
  set_perm_recursive $MODPATH 0 0 0755 0644

  # 以下是一些例子:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# 您可以添加更多功能来协助您的自定义脚本代码