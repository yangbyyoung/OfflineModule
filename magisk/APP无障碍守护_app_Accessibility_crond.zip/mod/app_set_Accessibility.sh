#!/system/bin/sh

id="app_Accessibility_crond"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
file=$MODPATH/Conf/无障碍应用.conf

export PATH=/system/bin:$MODPATH/busybox:$PATH

if test -e $MODPATH/disable -o -e $MODPATH/remove; then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi

function app_get_Accessibility() {
	local package=$1
	local package_Accessibility_cont=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g" | sort | uniq | wc -l)
	local package_Accessibility_double=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g;s/[[:space:]]//g" | sed ':a;N;$!ba;s/\n/:/g')
	local package_Accessibility=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g;s/[[:space:]]//g" | sort | uniq)
	if test $package_Accessibility_cont -gt 1; then
		echo $package_Accessibility_double
	else
		echo $package_Accessibility
	fi
}

function set_apps_Accessibility() {
	local Accessibility_service=$1
	local all_Accessibility=$(settings get secure enabled_accessibility_services | sed 's/null//g;s/[[:space:]]//g' | wc -l)
	local all_Accessibility_service=$(settings get secure enabled_accessibility_services | sed 's/null//g;s/[[:space:]]//g')
	if test $all_Accessibility -lt 1; then
		settings put secure enabled_accessibility_services "$Accessibility_service"
	else
		settings put secure enabled_accessibility_services "$Accessibility_service:$all_Accessibility_service"
	fi
}

cat "${file}" | sed '/^#/d;/^[[:space:]]*$/d' | while read package; do
	if test "$(echo "$(settings get secure enabled_accessibility_services | sed 's/null//g;s/[[:space:]]//g')" | grep -w "$(app_get_Accessibility $package)")" != ""; then
		continue
	fi
	set_apps_Accessibility "$(app_get_Accessibility $package)" && sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，为您保活一次。配置文件在[ $file ]，可以自行更改。" $MODPATH/module.prop
done
