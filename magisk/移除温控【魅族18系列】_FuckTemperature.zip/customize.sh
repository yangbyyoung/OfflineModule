SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

print_modname() {
ui_print "
 ****************************
 - 模块: 移除温控【魅族18系列】
 - 模块ID: FuckTemperature
 - 作者: @wusixl @MatchaCc @inn破哦sorry@更渴望未来
 - 介绍: 彻底Fuck掉温控以及高通perf参数⚠️可能导致问题请自备救砖措施！
 - 模块版本: Dev1.0
 - 更新日志: 
 - ☞☞Dev1.0只增加了魅族18系列的温控移除
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 ****************************
 "
}


set_perm_recursive  $MODPATH  0  0  0755  0644


AUTOMOUNT=true

MOD_Version="`grep_prop version $TMPDIR/module.prop`"
MOD_Author="`grep_prop author $TMPDIR/module.prop`"
MOD_Description="`grep_prop description $TMPDIR/module.prop`"
MarketName="`getprop ro.product.marketname`"
Device="`getprop ro.product.device`"
Model="`getprop ro.product.model`"
MIUI="`getprop ro.miui.ui.version.name`"
Version="`getprop ro.build.version.incremental`"
Android="`getprop ro.build.version.release`"
za=$MODPATH/YuK/7za #$za a -tzip -mx=7 -mmt
