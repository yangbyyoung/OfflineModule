#我是羽辰，我为自己代言，别问我可读性，又不是给人当教材的
SKIPMOUNT=false
print_modname() {
echo "*******************************"
echo "     	Magisk Module        "
echo "For    By 小白杨"
echo "*******************************"
}
REPLACE="

"
on_install() {
echo "- 正在释放文件"
for target in $(find /system/vendor/etc/wifi -name 'WCNSS_qcom_cfg.ini')
do
magicpath="${MODPATH}${target%/*}"
mkdir -p ${magicpath}
unzip -o "$ZIPFILE" 'WCNSS_qcom_cfg.ini' -d ${magicpath} >&2
done
}
set_permissions() {
set_perm_recursive $MODPATH 0 0 0755 0644
}
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
