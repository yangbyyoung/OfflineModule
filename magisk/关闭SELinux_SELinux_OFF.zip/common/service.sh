#Magisk模块作者  by：by：Han | 情非得已c
#本模块由「搞机助手」创建
#特别鸣谢：by：topjohnwu & Magisk Manager提供服务支持

setenforce 0
