MODDIR=${0%/*}
test ! -e $MODDIR/log && mkdir -p $MODDIR/log
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

step=51
steps=`echo $((RANDOM %133+$step))`
content insert --uri content://com.miui.providers.steps/item --bind _begin_time:s:`date +%s`000 --bind _id:i:$(echo $RANDOM) --bind _end_time:s:`date +%s`999 --bind _mode:i:2 --bind _steps:i:$steps

cd $MODDIR/log
echo "$(date +%y年%m月%d日%H点%M分): 当前增加步数为：$steps " >>step.log
