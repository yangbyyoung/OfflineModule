#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future

while true
do
if [ `getprop sys.boot_completed` == "1" ];then
    sleep 10
    setprop ctl.stop tcpdump
    setprop ctl.stop cnss_diag
    setprop ctl.stop vendor.tcpdump
    setprop ctl.stop vendor.cnss_diag
    setprop ctl.stop vendor.tftp_server
    break
fi
sleep 1
done