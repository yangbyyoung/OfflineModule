#!/system/bin/sh
#--------------------------------------------------------------------------------
# CuprumTurbo Adjustment . Ver 3.x
# Author : Chenzyadb @ Coolapk,xda,gitee,github
# E-Mail : chenzyadb@qq.com
#--------------------------------------------------------------------------------
MODDIR=${0%/*}
# [Necessary Binary Chmod]
chmod -R 7777 ${MODDIR}/CuprumTurbo_Lib/
# [Start MainService]
${MODDIR}/CuprumTurbo_Lib/CuLoader 
exit 0






