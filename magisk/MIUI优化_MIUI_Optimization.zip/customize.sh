SKIPUNZIP=0
check_magisk_version()
{
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "*********************************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "*********************************************************"
	fi
}
remove_thermals()
{
	for THERMAL in `ls /system/vendor/etc/thermal-*.conf /system/vendor/etc/perf/*thermal*.conf`; do
		[[ ! -d $MODPATH${THERMAL%/*} ]] && mkdir -p $MODPATH${THERMAL%/*}
		touch $MODPATH$THERMAL
		rm -rf $MODPATH${THERMAL%/*}/thermal*region*.conf $MODPATH${THERMAL%/*}/thermal*fan*.conf
	done
	if [ "$(getprop ro.product.brand)" == "Xiaomi" ] && [ -n "$(getprop ro.miui.ui.version.code)" ]; then
		for THERMAL_MAP in `ls /system/vendor/etc/thermal-*map*.conf`; do
			cp -f $MODPATH/thermal-map.conf $MODPATH$THERMAL_MAP
		done
		for THERMAL_NORMAL in `ls /system/vendor/etc/thermal-*normal*.conf`; do
			cp -f $MODPATH/thermal-normal.conf $MODPATH$THERMAL_NORMAL
		done
		[[ -f /data/current ]] && rm -rf /data/current
		if [ -d /data/vendor/thermal ]; then
			chattr -i /data/vendor/thermal
			chattr -i /data/vendor/thermal/config
			rm -rf /data/vendor/thermal/config/*
			cp -f $MODPATH/thermal-*.conf /data/vendor/thermal/config
			chattr +i /data/vendor/thermal/config
		fi
	fi
	rm -rf $MODPATH/thermal-*ma*.conf
}
check_magisk_version
remove_thermals
set_perm_recursive "$MODPATH" 0 0 0755 0644
ui_print "*********************************************************"
ui_print "- $(grep_prop version "${TMPDIR}/module.prop")版本主要功能："
ui_print "- $(grep_prop description "${TMPDIR}/module.prop" | sed -n 's/。/。\n- /g;$p')"
ui_print "*********************************************************"
ui_print "- 部分功能可在模块的 system.prop 文件中开启或关闭！"
ui_print "*********************************************************"
chmod a+x ${MODPATH}/*.sh
