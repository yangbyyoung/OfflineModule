test -e $MODPATH/keymod/set_conf.sh && {
cp -rf $MODPATH/keymod/set_conf.sh $MODPATH/conf/修改配置表后执行这个脚本.sh
}

test -e $MODPATH/keymod/task/QQMM.sh && {
cp -rf $MODPATH/keymod/task/QQMM.sh $MODPATH/keymod
}

test -e $MODPATH/uninstall.sh && {
cp -rf $MODPATH/uninstall.sh $MODPATH/conf/卸载请用root执行这个卸载脚本.sh
}

mkdir -p /data/media/0/Android/QQ微信负优化 /data/media/0/Android/QQ微信负优化/配置文件备份

for file in /data/media/0/Android/QQ微信负优化/*.conf ;do
cp -rf "$file" "/data/media/0/Android/QQ微信负优化/配置文件备份/${file##*/}"
done
cp -rf $MODPATH/conf/* /data/media/0/Android/QQ微信负优化
