DUBUG_FLAG=false

PROPFILE=false

POSTFSDATA=false

LATESTARTSERVICE=false

dest=/system/priv-app/MiuiHome
[ ! -d $dest ] && dest=${dest/MIUI/Miui}
apk=$(ls $dest/M*.apk)
mkdir -p $MODPATH$dest
mv $MODPATH/MiuiHome.apk $MODPATH$apk

REPLACE_EXAMPLE="
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
$dest
"

# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644

rm -rf /data/system/package_cache/*

 ui_print "##################"
 ui_print "清理应用缓存"
 ui_print "##################"
 ui_print '    安装完成，重启后生效！'