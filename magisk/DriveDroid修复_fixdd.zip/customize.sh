install_apk() {
  if [ "$BOOTMODE" != 'true' ]; then
    ui_print '- 由于未通过 Magisk Manager 运行，因此跳过 APK 安装'
    return 0
  fi

 ui_print "*******************************"
 ui_print "  - 安装 Drive Droid APK 文件..."
 ui_print "*******************************"
 ui_print '模块会将DriveDroid安装为系统APP'
 ui_print "*******************************"
 ui_print '重启后记得给DriveDroid以root权限'
 ui_print "*******************************"
  pm install -r "$MODPATH/system/priv-app/com.softwarebakery.drivedroid/com.softwarebakery.drivedroid.apk" || true
}
  

if [ "$API" -lt '30' ]; then
  abort '该模块仅适用于 Android 11+'
fi

install_apk
