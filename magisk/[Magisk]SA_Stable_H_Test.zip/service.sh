#!/system/bin/sh
#
#setprop 
#settings put global 
#settings put secure 
#settings put system 
sleep 30
while true ;do
if
#
#不要问,这是关联5G命令行
settings put global persist.radio.testmode=false
settings put secure persist.radio.testmode=false
settings put system persist.radio.testmode=false
settings put global persist.vendor.radio.enable_temp_dds=0
settings put secure persist.vendor.radio.enable_temp_dds=0
settings put system persist.vendor.radio.enable_temp_dds=0
settings put global persist.vendor.radio.smart_sa_screen_off_min=false
settings put secure persist.vendor.radio.smart_sa_screen_off_min=false
settings put system persist.vendor.radio.smart_sa_screen_off_min=false
settings put global persist.vendor.radio.smart_sa_dereg_timer_min=false
settings put secure persist.vendor.radio.smart_sa_dereg_timer_min=false
settings put system persist.vendor.radio.smart_sa_dereg_timer_min=false
settings put global persist.vendor.radio.smart_sa_enable_timeout_min=false
settings put secure persist.vendor.radio.smart_sa_enable_timeout_min=false
settings put system persist.vendor.radio.smart_sa_enable_timeout_min=false
settings put global persist.vendor.radio.smart_sa_keep_disable_min=false
settings put secure persist.vendor.radio.smart_sa_keep_disable_min=false
settings put system persist.vendor.radio.smart_sa_keep_disable_min=false
# 这个开关=1.2.3.4
settings put global persist.vendor.radio.arfcn_test_mode=4
settings put secure persist.vendor.radio.arfcn_test_mode=4
settings put system persist.vendor.radio.arfcn_test_mode=4
#不要问,这是打开5G开关
setprop persist.vendor.radio.sa_enabled 1
settings put global persist.vendor.radio.sa_enabled 1
settings put secure persist.vendor.radio.sa_enabled 1
settings put system persist.vendor.radio.sa_enabled 1
#
setprop persist.radio.testmode false
settings put global persist.radio.testmode false
settings put secure persist.radio.testmode false
settings put system persist.radio.testmode false
#不要问,这是智能5G开关
setprop smart_fiveg 0
settings put global smart_fiveg 0
settings put secure smart_fiveg 0
settings put system smart_fiveg 0
setprop persist.radio.usersetting.smart5g false
settings put global persist.radio.usersetting.smart5g false
settings put secure persist.radio.usersetting.smart5g false
settings put system persist.radio.usersetting.smart5g false
setprop persist.radio.userchange.smart5g false
settings put global persist.radio.userchange.smart5g false
settings put secure persist.radio.userchange.smart5g false
settings put system persist.radio.userchange.smart5g false
#不要问,这是智能SA/NSA开关
setprop persist.vendor.radio.default_sa_enabled 1
settings put global persist.vendor.radio.default_sa_enabled 1
settings put secure persist.vendor.radio.default_sa_enabled 1
settings put system persist.vendor.radio.default_sa_enabled 1
setprop persist.vendor.radio.default_smart_sa_enabled 0
settings put global persist.vendor.radio.default_smart_sa_enabled 0
settings put secure persist.vendor.radio.default_smart_sa_enabled 0
settings put system persist.vendor.radio.default_smart_sa_enabled 0
fi
sleep 1m
done