#!/system/bin/sh

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

sleep 2
ui_print "***********************************"
ui_print " 𝗗𝗶𝘀𝗮𝗯𝗹𝗲 𝗨𝘀𝗲𝗹𝗲𝘀𝘀 𝗙𝗲𝗮𝘁𝘂𝗿𝗲"
sleep 1
ui_print " 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 @𝗶𝗱𝗻𝘇𝗺"
sleep 1
ui_print " 𝗖𝗵𝗮𝗻𝗻𝗲𝗹 @𝗸𝗻𝘁𝗱𝗿𝗲𝗹𝗲𝗮𝘀𝗲𝘀"
sleep 1
ui_print " 𝗧𝗵𝗶𝘀 𝗺𝗼𝗱𝘂𝗹𝗲 𝘄𝗶𝗹𝗹 𝗱𝗶𝘀𝗮𝗯𝗹𝗲 𝘂𝘀𝗲𝗹𝗲𝘀𝘀 𝗳𝗲𝗮𝘁𝘂𝗿𝗲 𝗼𝗻 𝘆𝗼𝘂𝗿 𝗮𝗻𝗱𝗿𝗼𝗶𝗱 𝗹𝗶𝗸𝗲 𝗹𝗼𝗴𝗴𝗶𝗻𝗴 𝗮𝗻𝗱 𝗸𝗲𝗿𝗻𝗲𝗹 𝗽𝗮𝗻𝗶𝗰 "
ui_print " 𝘁𝗼 𝗿𝗲𝗱𝘂𝗰𝗲 𝗰𝗽𝘂 𝗵𝗲𝗮𝘁, 𝘀𝗼𝗺𝗲 𝗿𝗮𝗻𝗱𝗼𝗺 𝗿𝗲𝗯𝗼𝗼𝘁 𝗮𝗻𝗱 𝗿𝗲𝗱𝘂𝗰𝗲"
ui_print " 𝗹𝗮𝗴 𝗮 𝗹𝗶𝘁𝘁𝗲"
ui_print "***********************************"
sleep 1,2
ui_print " 𝗜𝗻𝘀𝘁𝗮𝗹𝗹𝗶𝗻𝗴......................."
ui_print " "
sleep 1
echo " 𝟭𝟬%"
echo " "
sleep 1
echo " 𝟯𝟬%"
echo " "
sleep 2
echo " 𝟱𝟬%"
echo " "
sleep 2
echo " 𝟳𝟬%"
echo " "
sleep 2
echo " 𝟭𝟬𝟬%"
echo " "
sleep 0,5
ui_print "• 𝗥𝗲𝗯𝗼𝗼𝘁 𝗡𝗼𝘄 !"

