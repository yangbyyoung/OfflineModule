#!/sbin/sh

umask 022
Magisk_lite_Version=$(echo `magisk -v` | grep "lite")
if [[ "$Magisk_lite_Version" != "" ]];then
	abort "不支持Magisk Lite!"
fi
ui_print "- 开始清除应用缓存"
rm -rf /data/system/package_cache/*/*MiuiPackageInstaller*
if [ -d /data/data/com.miui.packageinstaller ]; then
	rm -rf /data/data/com.miui.packageinstaller/*
else
	mkdir /data/data/com.miui.packageinstaller
fi
# ui_print "- 禁用云控获取中"
# mkdir /data/data/com.miui.packageinstaller/shared_prefs
# chmod -R 000 /data/data/com.miui.packageinstaller/shared_prefs
ui_print "- 删除临时文件"
rm ${MODPATH/_update/}/customize.sh
rm $MODPATH/customize.sh
ui_print "- 模块安装完成"
exit 0
