rm -rf /data/system/package_cache/*/*MiuiPackageInstaller*
rm -rf $Modules_Dir/com.miui.packageinstaller
rm -rf /data/data/com.miui.packageinstaller/*
