warm="/sys/class/power_supply/bms/temp"
warm2="/sys/class/power_supply/battery/charger_temp"
chg_signal="/sys/class/power_supply/bms/signal"
stepcharge="/sys/class/power_supply/bms/constant_charge_current_max"
until [[ $jslx == true ]]; do
sleep 10s
capacity="/sys/class/power_supply/battery/capacity"
chg_lv=`[[ -f $capacity ]] && cat $capacity`
signal=`[[ -f $chg_signal ]] && cat $chg_signal`
#Charging_control=/sys/class/power_supply/battery/input_suspend
#Charging_control2=/sys/class/power_supply/battery/charging_enabled
##########
start=98
stop=99
#修改start和stop的值可以控制断电功能，默认98/99表示不生效，数值比实际显示要低1 ！
##########
data=`[[ -f $warm2 ]] && cat $warm2`
fastchargemode=`[[ -f $stepcharge ]] && cat $stepcharge`
if [[ $fastchargemode -ne 1 ]]; then
 echo '1' > $stepcharge
elif [[ $fastchargemode -eq 1 ]]; then
 if [[ $chg_lv -le $start ]]; then
  if [[ $data -le 430 ]]; then
  echo '12000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '2' > $signal
  echo '250' > $warm
  elif [ "$data" -ge "430" ]&&[ "$data" -lt "457" ];then
  echo '12000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '250' > $warm
  echo '2' > $signal
  elif [[ "$data" -ge "458" ]];then
  echo '12000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '250' > $warm
  echo '2' > $signal
    fi
elif [[ $chg_lv -gt $stop ]]; then
echo '12000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
echo '250' > $warm
echo '2' > $signal
sleep 1m
 fi
fi
done
