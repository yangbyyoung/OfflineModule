SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************
 "
ui_print "如果支付时指纹失效浅浅下拉状态栏一下即可刷新"
set_perm_recursive $MODPATH 0 0 0755 0777

#官宣粉丝交流群：938499734，搞机！外挂！文案！