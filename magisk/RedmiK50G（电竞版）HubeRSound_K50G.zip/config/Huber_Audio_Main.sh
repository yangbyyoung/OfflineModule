#!/system/bin/sh

chmod +x Huber_Audio_Main.sh

# Check File
if [ ! -f /data/adb/modules/K50G/system/product/app/MiSound/MiSound.apk ]; then
    echo "MiSound.apk not found."
    exit 1
fi

# install apk
pm install -r /data/adb/modules/K50G/system/product/app/MiSound/MiSound.apk

# Check install
if [ $? -eq 0 ]; then
    echo "MiSound.apk installed successfully."
else
    echo "Failed to install MiSound.apk."
fi


sleep 1s
if [ -n "$misound" ]; then
    kill "$misound"
    am start --windowingMode 5 -n com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
    sleep 2s
    input keyevent KEYCODE_BACK
fi

# Volume Change Start
if [ -n "$misound" ]; then
    sleep 7s
    cp -f /data/adb/modules/K50G/sound_shared_prefs/sound_transmit_loopback_mode.xml /data/data/com.miui.misound/shared_prefs
    sleep 0.7s
    cp -f /data/adb/modules/K50G/sound_shared_prefs/dirac.xml /data/data/com.miui.misound/shared_prefs
    kill "$misound"
    sleep 0.8s
    am start com.miui.misound/com.miui.misound.HeadsetSettingsActivity
    sleep 1.2s
    input keyevent KEYCODE_BACK
fi

# JamesDSP Settings
cp -f /data/adb/modules/K50G/prop/HarmanSettings/InGame/james.dsp.speaker.xml /data/data/james.dsp/shared_prefs/