#!/system/bin/sh
chmod -R 777 /data/adb/modules/fuckfiles
/data/adb/modules/fuckfiles/clear