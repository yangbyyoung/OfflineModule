#!/system/bin/sh
#酷安@10007

test "$(id -u)" != "0"  && echo "请您先授予root 权限并且先输入su，再输入magiskbackup" && exit 1

MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

test ! -f $timetablefile && echo "crontab文件丢失！"

source $MODPATH/keymod/path.sh
codeversion="2.3"


writemodulesinfo(){
local file=$MODPATH/module.prop
test ! -f $timetablefile && echo " XXX crontab文件丢失！"
timesleep=`cat $timetablefile |tr -cd "[0-9]" `
test $timesleep == 10  && timesleep='10分钟'
test $timesleep == 30  && timesleep='30分钟'
test $timesleep == 01  && timesleep='1个小时'
test $timesleep == 001  && timesleep='1天'
test $timesleep == 03  && timesleep='3个小时'
test $timesleep == 06  && timesleep='6个小时'
sed -i "/^description=/c description=备份文件在 "$(dirname $(dirname $Backup_path))"。模拟终端输入magiskbackup，可以选择恢复或者备份模块，您也可以在备份目录恢复或者备份模块。备份时间间隔为: "$timesleep" " $file
}

function sate(){
echo ""
echo "●——————当前状态————●"
writemodulesinfo 2>/dev/null
local Process=`ps -ef | grep -w "$MODPATH/timetable" |grep -v grep |awk '{print $2}'| wc -l`
if test $Process -ge 1 ;then
	echo -e "\n magisk备份任务: \e[0;42m 已启动 \e[0m  时间间隔为: $timesleep "
else
	echo -e "\n magisk备份任务: \e[0;41m 未启动 \e[0m "
	echo ""
fi

}


opts(){
	clear
	reset
	echo "☞=======================================☜"
	echo ""
	echo ""
	sate 
	echo ""
	echo ""
	echo "●————————————欢迎来到Magisk 备份($codeversion)————————————●"
	echo ""
	echo ""
	echo "1.查看备份的模块"
	echo ""
	echo "2.手动备份模块"
	echo ""
	echo "3.恢复模块"
	echo ""
	echo "4.导出指定模块"
	echo ""
	echo "5.magisk备份任务管理"
	echo ""
	echo "6.退出"
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	echo ""
	echo ""
	read choice
	if [ $choice == 1 ];then
		checkmod
	elif [ $choice == 2 ];then
		backupmod
	elif [ $choice == 3 ];then
		recoverymod
	elif [ $choice == 4 ];then
		source $MODPATH/keymod/zip.sh
	elif [ $choice == 5 ];then
		source $MODPATH/keymod/timetable.sh
	elif [ $choice == 6 ];then
		exit 
	elif [ "$choice" != "*[0-9]*" ];then
		opts 
	fi
	echo "☞=======================================☜"
}

backopt(){
		echo ""
		echo "●————————————————————————●"
		echo ""
		echo "1. 回到菜单"
		echo ""
		echo "2. 退出"
		echo ""
		echo "●————————————————————————●"
		echo ""
		read back
		if [ $back == 1 ];then
		opts
		elif [ $back == 2 ];then
		exit 
		elif [ "$back" != "*[0-9]*" ];then
		backopt
		fi
}

checkmod(){
	if test -e $Backup_path2 ;then
		echo ""
		echo "●————————————————————————●"
		echo ""
		echo "——发现有手动备份的模块"
		echo ""
		echo ""
		echo "——请选择需要查看的备份"
		echo ""
		echo ""
		echo "1.查看手动备份的模块"
		echo ""
		echo "2.查看自动备份的模块"
		echo ""
		echo "3.回到菜单"
		echo ""
		echo "- 请用键盘输入数字，进行选择"
		echo ""
		echo "●————————————————————————●"
		read choice1
		if [ $choice1 == 1 ] ;then
			Patch=$Backup_path2
		elif [ $choice1 == 2 ];then
			Patch=$Backup_path
		elif [ $choice1 == 3 ];then
			opts
		elif [ "$choice1" != "*[0-9]*" ];then
		checkmod 
		fi
	else
		Patch=$Backup_path
	fi
	L=$Patch
	MOD=`tar -tf $L|cut -f2 -d "/"|uniq|grep -v "[a-zA-Z].db"|grep -v "[a-zA-Z].sh"|sed '/^[:space:]*$/d'`
	grep_prop(){
		local REGEX="s/^$1=//p"
		shift
		local FILES=$@
		test -z "$FILES"  && FILES='/system/build.prop'
		cat $FILES 2> /dev/null | dos2unix | sed -n "$REGEX" | head -n 1
	}
	cd $(dirname $L)
	for i in $MOD;do
		Bak=`tar -xvf $L modules/$i/module.prop 2> /dev/null`
	done
N=1
	for o in $(ls $(dirname $L)/modules);do
		name=$(grep_prop 'name' $(dirname $L)/modules/$o/module.prop )
		version=$(grep_prop 'version' $(dirname $L)/modules/$o/module.prop )
		description=$(grep_prop 'description' $(dirname $L)/modules/$o/module.prop )
		author=$(grep_prop 'author' $(dirname $L)/modules/$o/module.prop )
		echo ""
		echo "∞———————————【 $N 】—————————————∞"
		echo "备份模块名称: $name "
		echo "作者: $author"
		echo "版本: $version"
		echo "描述: $description"
		echo "∞————————————————————————∞"
		echo ""
		N=$( expr $N + 1)
	done
	rm -rf $(dirname $L)/modules
		echo ""
		echo ""
		echo -e "\033[41m－已显示所有备份的模块\033[m"
		echo "●————————————————————————●"
		echo ""
		backopt
}

backupmod(){
	test ! -e $Backup_path2  && mkdir -p ${Backup_path2%/*}
	cd /data/adb
	tar -cf $Backup_path2 * --exclude=magisk --exclude=modules_update --exclude=lite_modules_update
	echo -e "\n－ 备份完成 文件在 $Backup_path2\n"
	backopt
}

recoverymod(){
	clear
	reset
	if test -e $Backup_path2 ;then
		echo ""
		echo "●————————————————————————●"
		echo ""
		echo "——请选择需要恢复的备份"
		echo ""
		echo "1.手动备份的模块"
		echo ""
		echo "2.自动备份的模块"
		echo ""
		echo "3.回到菜单"
		echo ""
		echo "- 请用键盘输入数字，进行选择"
		echo ""
		echo "●————————————————————————●"
		read choice2
		if [ $choice2 == 1 ];then
			patch2=$Backup_path2
		elif [ $choice2 == 2 ];then
			patch2=$Backup_path
		elif [ $choice2 == 3 ];then
			opts
		elif [ "$choice2" != "*[0-9]*" ];then
		recoverymod
		fi
	else
		patch2=$Backup_path
	fi
	echo ""
	echo "●————————————————————————●"
	if test -e "$patch2" ; then
		echo "- 正在进行还原…………"
		cd /data/adb
		# 对需要恢复的原来模块进行删除
		for mod2 in $( tar -tf $patch2; ); do
			if test -e "$mod2" ; then
				rm -rf $mod2
			fi
		done
		tar -xf $patch2
		echo "- 还原模块完成 ! "
	else
		echo "- 还原文件 $patch2 不存在 !"
	fi
	echo ""
	echo "●————————————————————————●"
	backopt
}
opts
