DUBUG_FLAG=false

PROPFILE=false

POSTFSDATA=false

LATESTARTSERVICE=true

var_device="`getprop ro.product.board`"
var_version="`grep_prop ro.*build.version.incremental`"

print_modname() {
  ui_print "******************************"
  ui_print " $MODNAME "
  ui_print "******************************"
  ui_print " 作者：$MODauthor "
  ui_print " 介绍：$MODdescription "
  ui_print "******************************"
}

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 正在授予必备权限"
  settings put secure gb_bullet_chat 1
  settings put secure gb_boosting 1
  tmp_list="barrage"

  dda=/data/dalvik-cache/arm
  [ -d $dda"64" ] && dda=$dda"64"
  for i in $tmp_list; do
  	rm -f $dda/system@*@"$i"*
  done
  rm -rf /data/system/package_cache/*
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}
