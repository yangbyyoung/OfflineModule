#!/system/bin/sh

function mem_control() {
#运存收缩等级
#HIDDEN、RUNNING_MODERATE、BACKGROUND、RUNNING_LOW、MODERATE、RUNNING_CRITICAL、COMPLETE
#COMPLETE：内存不足，并且该进程在后台进程列表最后一个，马上就要被清理
#MODERATE：内存不足，并且该进程在后台进程列表的中部。
#BACKGROUND：内存不足，并且该进程是后台进程。
#HIDDEN：内存不足，并且该进程的UI已经不可见了。
#RUNNING_CRITICAL：内存不足(后台进程不足3个)，并且该进程优先级比较高，需要清理内存
#RUNNING_LOW：内存不足(后台进程不足5个)，并且该进程优先级比较高，需要清理内存
#RUNNING_MODERATE：内存不足(后台进程超过5个)，并且该进程优先级比较高，需要清理内存
local level=COMPLETE
pgrep -f "$1" | while read pid; do
	am send-trim-memory "$pid" "$level"
done
}

app="
com.tencent.mm
com.tencent.mobileqq
"
for package in $app; do
	mem_control "$package"
done

#for package in $app ;do
#am send-trim-memory "$package" RUNNING_LOW
#done
