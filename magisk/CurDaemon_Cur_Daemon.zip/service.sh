#!/system/bin/sh
bin=/data/adb/modules/Cur_Daemon/bin/CurDaemon
wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # no need to start before the user unlocks the screen
    local test_file="/sdcard/Android/.CUR_PERMISSION_TEST"
    true >"$test_file"
    while [ ! -f "$test_file" ]; do
        true > "$test_file"
        sleep 1
    done
    rm "$test_file"
}
lib_CurDaemon(){
local comm;
chmod 0777 $1;
nohup $1 > /dev/null 2>&1 &
}
kill CurDaemon
wait_until_login
lib_CurDaemon "$bin"