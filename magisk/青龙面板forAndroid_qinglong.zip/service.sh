#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此防跳和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
export rootfs=/data/alpine

if [ ! -f "$rootfs/proc/cpuinfo" ]
then
${0%/*}/init "$rootfs"
fi

/data/adb/magisk/busybox start-stop-daemon -S -b chroot -- $rootfs /bin/bash -c "/usr/sbin/sshd -f /etc/ssh/sshd_config"
/data/adb/magisk/busybox start-stop-daemon -S -b chroot -- $rootfs /bin/bash -c "/usr/sbin/chronyd -f /etc/chrony/chrony.conf"
/data/adb/magisk/busybox start-stop-daemon -S -b chroot -- $rootfs /bin/bash -c "source /root/.bashrc && cd /ql && /ql/docker/docker-entrypoint.sh"

#酷友提供
echo "PowerManagerService.noSuspend" > /sys/power/wake_lock
dumpsys deviceidle disable
