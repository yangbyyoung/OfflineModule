
MODDIR=${0%/*}
