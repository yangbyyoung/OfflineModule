#脚本来自: ࢭ泠熙子ࢭ & 我无聊了修改
wowull=/data/adb/modules/bootanimation
chmod -R 0777 $MODPATH/*
ui_print "

—— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')

—— 面具版本$MAGISK_VER_CODE

—— 面具代号$MAGISK_VER

"
sleep 1.111
ui_print "正在检测当前开机动画文件路径…"
if [[ ! -f "/system/media/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到system目录的开机动画文件"
else
    sleep 1.111
    ui_print "——已检测到system目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "1080 2400 13
p 1 0 part1
p 0 0 part0" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 速度
    mv part0 tmp/
    mv part1 tmp/
    cd tmp
    $MODPATH/zip -0 bootanimation.zip part0/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip part1/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip * >/dev/null 2>&1
    cd $MODPATH
    mv tmp/bootanimation.zip $MODPATH/
    echo "mount --bind $wowull/bootanimation.zip /system/media/bootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp
    echo "文件配置完毕！可以享受新的开机动画啦！"
fi

if [[ ! -f "/product/media/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到product目录的开机动画文件"
else
    sleep 1.111
    ui_print "——已检测到product目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "1080 2400 13
p 1 0 part1
p 0 0 part0" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 速度
    mv part0 tmp/
    mv part1 tmp/
    cd tmp
    $MODPATH/zip -0 bootanimation.zip part0/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip part1/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip * >/dev/null 2>&1
    cd $MODPATH
    mv tmp/bootanimation.zip $MODPATH/
    echo "mount --bind $wowull/bootanimation.zip /product/media/bootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp
    echo "文件配置完毕！可以享受新的开机动画啦！"
fi

if [[ ! -f "/my_product/media/bootanimation/bootanimation.zip" ]]; then
    sleep 1.111
    ui_print "——没有检测到my_product目录的开机动画文件"
else
    sleep 1.111
    ui_print "——已检测到my_product目录下的开机动画文件"
    sleep 1.111
    ui_print "——正在写入配置文件…"
    cd $MODPATH
    mkdir tmp
    echo "g 1080 2400 0 0 13
p 1 0 part1
p 0 0 part0" > tmp/desc.txt
    #desc.txt的首行内容为横向长度 纵向长度 x/y坐标偏差 速度
    mv part0 tmp/
    mv part1 tmp/
    cd tmp
    $MODPATH/zip -0 bootanimation.zip part0/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip part1/* >/dev/null 2>&1
    $MODPATH/zip -u -0 bootanimation.zip * >/dev/null 2>&1
    cd $MODPATH
    mv tmp/bootanimation.zip $MODPATH/
    echo "mount --bind $wowull/bootanimation.zip /my_product/media/bootanimation/bootanimation.zip
mount --bind $wowull/bootanimation.zip /my_product/media/bootanimation/rbootanimation.zip" >> post-fs-data.sh
    rm -rf $MODPATH/tmp    
    echo "文件配置完毕！可以享受新的开机动画啦！"
fi
