SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false

print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make 酷安@Itos初号机"
 ui_print "*******************************"
}
on_install() {
 
packagebool=$(dumpsys package com.coderstory.toolkit
)
if [ "$packagebool" == "Unable to find package: com.coderstory.toolkit" ]; then
ui_print "未安装核心破解，请安装并开启前三个选项后再安装本模块"
exit 2
fi

 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'FuntouchUIEngine_2.0.0.4.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" '30056.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" '16.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'gamecube_11.1.4.009.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'isKeyguardLocked.dex' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'install_config.conf' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print ""
 ui_print "模块目录下install_config.conf内可配置降级APP"
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}