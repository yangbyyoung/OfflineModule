#!/system/bin/sh

CACHE_FILE=/data/system/package_cache

set_perm(){
rm -rf /data/app/com.android.thememanager*;rm -rf /data/user/0/com.android.thememanager
chown root.root /data/system/theme/rights;chmod 000 /data/system/theme/rights
chattr +i /data/system/theme/rights;chmod 731 /data/system/theme
}

(
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
rm -rf $CACHE_FILE
set_perm
done
sleep 5
rm -rf $CACHE_FILE
mkdir -m 775 $CACHE_FILE
)&