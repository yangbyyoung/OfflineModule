##########################################################################################
#
# Magisk Module Template Config Script
# by topjohnwu
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
AUTOMOUNT=true

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "  ╭─────────╮
  │落霞与孤鹜齐飞，　│
  │秋水共长天一色。　│
  │─王勃《滕王阁序》│
  ╰─────────╯
  ┳　┐┌┌┐┳　┳ Font
  ┇　 ╳ │┬┇┇┇ Magisk
  ╩┛┘└└┘┗┻┛ Module
  微信公众号：霞鹜(lxgwshare)
  微博：孤鹜先森
  酷安：落霞孤鹜lxgw    "
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
REPLACE="
/system/etc/fonts.xml
/system/fonts/AndroidClock.ttf
/system/fonts/CarroisGothicSC-Regular.ttf
/system/fonts/Clock2017L.ttf
/system/fonts/Clock2017R.ttf
/system/fonts/ComingSoon.ttf
/system/fonts/CutiveMono.ttf
/system/fonts/DancingScript-Bold.ttf
/system/fonts/DancingScript-Regular.ttf
/system/fonts/DroidSans-Bold.ttf
/system/fonts/DroidSans.ttf
/system/fonts/DroidSansMono.ttf
/system/fonts/GoogleSans-Bold.ttf
/system/fonts/GoogleSans-BoldItalic.ttf
/system/fonts/GoogleSans-Italic.ttf
/system/fonts/GoogleSans-Medium.ttf
/system/fonts/GoogleSans-MediumItalic.ttf
/system/fonts/GoogleSans-Regular.ttf
/system/fonts/LxgwBraille.otf
/system/fonts/NotoColorEmoji.ttf
/system/fonts/NotoNaskhArabic-Bold.ttf
/system/fonts/NotoNaskhArabic-Regular.ttf
/system/fonts/NotoNaskhArabicUI-Bold.ttf
/system/fonts/NotoNaskhArabicUI-Regular.ttf
/system/fonts/NotoSansAdlam-Regular.ttf
/system/fonts/NotoSansAhom-Regular.otf
/system/fonts/NotoSansAnatolianHieroglyphs-Regular.otf
/system/fonts/NotoSansArmenian-Bold.ttf
/system/fonts/NotoSansArmenian-Regular.ttf
/system/fonts/NotoSansAvestan-Regular.ttf
/system/fonts/NotoSansBalinese-Regular.ttf
/system/fonts/NotoSansBamum-Regular.ttf
/system/fonts/NotoSansBassaVah-Regular.otf
/system/fonts/NotoSansBatak-Regular.ttf
/system/fonts/NotoSansBengali-Bold.ttf
/system/fonts/NotoSansBengali-Regular.ttf
/system/fonts/NotoSansBengaliUI-Bold.ttf
/system/fonts/NotoSansBengaliUI-Regular.ttf
/system/fonts/NotoSansBhaiksuki-Regular.otf
/system/fonts/NotoSansBrahmi-Regular.ttf
/system/fonts/NotoSansBuginese-Regular.ttf
/system/fonts/NotoSansBuhid-Regular.ttf
/system/fonts/NotoSansCanadianAboriginal-Regular.ttf
/system/fonts/NotoSansCarian-Regular.ttf
/system/fonts/NotoSansChakma-Regular.ttf
/system/fonts/NotoSansCham-Bold.ttf
/system/fonts/NotoSansCham-Regular.ttf
/system/fonts/NotoSansCherokee-Regular.ttf
/system/fonts/NotoSansCoptic-Regular.ttf
/system/fonts/NotoSansCuneiform-Regular.ttf
/system/fonts/NotoSansCypriot-Regular.ttf
/system/fonts/NotoSansDeseret-Regular.ttf
/system/fonts/NotoSansDevanagari-Bold.ttf
/system/fonts/NotoSansDevanagari-Regular.ttf
/system/fonts/NotoSansDevanagariUI-Bold.ttf
/system/fonts/NotoSansDevanagariUI-Regular.ttf
/system/fonts/NotoSansEgyptianHieroglyphs-Regular.ttf
/system/fonts/NotoSansElbasan-Regular.otf
/system/fonts/NotoSansEthiopic-Bold.ttf
/system/fonts/NotoSansEthiopic-Regular.ttf
/system/fonts/NotoSansGeorgian-Bold.ttf
/system/fonts/NotoSansGeorgian-Regular.ttf
/system/fonts/NotoSansGlagolitic-Regular.ttf
/system/fonts/NotoSansGothic-Regular.ttf
/system/fonts/NotoSansGujarati-Bold.ttf
/system/fonts/NotoSansGujarati-Regular.ttf
/system/fonts/NotoSansGujaratiUI-Bold.ttf
/system/fonts/NotoSansGujaratiUI-Regular.ttf
/system/fonts/NotoSansGurmukhi-Bold.ttf
/system/fonts/NotoSansGurmukhi-Regular.ttf
/system/fonts/NotoSansGurmukhiUI-Bold.ttf
/system/fonts/NotoSansGurmukhiUI-Regular.ttf
/system/fonts/NotoSansHanunoo-Regular.ttf
/system/fonts/NotoSansHatran-Regular.otf
/system/fonts/NotoSansHebrew-Bold.ttf
/system/fonts/NotoSansHebrew-Regular.ttf
/system/fonts/NotoSansImperialAramaic-Regular.ttf
/system/fonts/NotoSansInscriptionalPahlavi-Regular.ttf
/system/fonts/NotoSansInscriptionalParthian-Regular.ttf
/system/fonts/NotoSansJavanese-Regular.ttf
/system/fonts/NotoSansKaithi-Regular.ttf
/system/fonts/NotoSansKannada-Bold.ttf
/system/fonts/NotoSansKannada-Regular.ttf
/system/fonts/NotoSansKannadaUI-Bold.ttf
/system/fonts/NotoSansKannadaUI-Regular.ttf
/system/fonts/NotoSansKayahLi-Regular.ttf
/system/fonts/NotoSansKharoshthi-Regular.ttf
/system/fonts/NotoSansKhmer-VF.ttf
/system/fonts/NotoSansKhmerUI-Bold.ttf
/system/fonts/NotoSansKhmerUI-Regular.ttf
/system/fonts/NotoSansLao-Bold.ttf
/system/fonts/NotoSansLao-Regular.ttf
/system/fonts/NotoSansLaoUI-Bold.ttf
/system/fonts/NotoSansLaoUI-Regular.ttf
/system/fonts/NotoSansLepcha-Regular.ttf
/system/fonts/NotoSansLimbu-Regular.ttf
/system/fonts/NotoSansLinearA-Regular.otf
/system/fonts/NotoSansLinearB-Regular.ttf
/system/fonts/NotoSansLisu-Regular.ttf
/system/fonts/NotoSansLycian-Regular.ttf
/system/fonts/NotoSansLydian-Regular.ttf
/system/fonts/NotoSansMalayalam-Bold.ttf
/system/fonts/NotoSansMalayalam-Regular.ttf
/system/fonts/NotoSansMalayalamUI-Bold.ttf
/system/fonts/NotoSansMalayalamUI-Regular.ttf
/system/fonts/NotoSansMandaic-Regular.ttf
/system/fonts/NotoSansManichaean-Regular.otf
/system/fonts/NotoSansMarchen-Regular.otf
/system/fonts/NotoSansMeeteiMayek-Regular.ttf
/system/fonts/NotoSansMeroitic-Regular.otf
/system/fonts/NotoSansMiao-Regular.otf
/system/fonts/NotoSansMongolian-Regular.ttf
/system/fonts/NotoSansMro-Regular.otf
/system/fonts/NotoSansMultani-Regular.otf
/system/fonts/NotoSansMyanmar-Bold.ttf
/system/fonts/NotoSansMyanmar-Regular.ttf
/system/fonts/NotoSansMyanmarUI-Bold.ttf
/system/fonts/NotoSansMyanmarUI-Regular.ttf
/system/fonts/NotoSansNabataean-Regular.otf
/system/fonts/NotoSansNewa-Regular.otf
/system/fonts/NotoSansNewTaiLue-Regular.ttf
/system/fonts/NotoSansNKo-Regular.ttf
/system/fonts/NotoSansOgham-Regular.ttf
/system/fonts/NotoSansOlChiki-Regular.ttf
/system/fonts/NotoSansOldItalic-Regular.ttf
/system/fonts/NotoSansOldNorthArabian-Regular.otf
/system/fonts/NotoSansOldPermic-Regular.otf
/system/fonts/NotoSansOldPersian-Regular.ttf
/system/fonts/NotoSansOldSouthArabian-Regular.ttf
/system/fonts/NotoSansOldTurkic-Regular.ttf
/system/fonts/NotoSansOriya-Bold.ttf
/system/fonts/NotoSansOriya-Regular.ttf
/system/fonts/NotoSansOriyaUI-Bold.ttf
/system/fonts/NotoSansOriyaUI-Regular.ttf
/system/fonts/NotoSansOsage-Regular.ttf
/system/fonts/NotoSansOsmanya-Regular.ttf
/system/fonts/NotoSansPahawhHmong-Regular.otf
/system/fonts/NotoSansPalmyrene-Regular.otf
/system/fonts/NotoSansPauCinHau-Regular.otf
/system/fonts/NotoSansPhagsPa-Regular.ttf
/system/fonts/NotoSansPhoenician-Regular.ttf
/system/fonts/NotoSansRejang-Regular.ttf
/system/fonts/NotoSansRunic-Regular.ttf
/system/fonts/NotoSansSamaritan-Regular.ttf
/system/fonts/NotoSansSaurashtra-Regular.ttf
/system/fonts/NotoSansSC-Bold.otf
/system/fonts/NotoSansSC-Light.otf
/system/fonts/NotoSansSC-Medium.otf
/system/fonts/NotoSansSC-Regular.otf
/system/fonts/NotoSansSC-Thin.otf
/system/fonts/NotoSansSharada-Regular.otf
/system/fonts/NotoSansShavian-Regular.ttf
/system/fonts/NotoSansSinhala-Bold.ttf
/system/fonts/NotoSansSinhala-Regular.ttf
/system/fonts/NotoSansSinhalaUI-Bold.otf
/system/fonts/NotoSansSinhalaUI-Regular.otf
/system/fonts/NotoSansSoraSompeng-Regular.otf
/system/fonts/NotoSansSundanese-Regular.ttf
/system/fonts/NotoSansSylotiNagri-Regular.ttf
/system/fonts/NotoSansSymbols-Regular-Subsetted.ttf
/system/fonts/NotoSansSymbols-Regular-Subsetted2.ttf
/system/fonts/NotoSansSyriacEastern-Regular.ttf
/system/fonts/NotoSansSyriacEstrangela-Regular.ttf
/system/fonts/NotoSansSyriacWestern-Regular.ttf
/system/fonts/NotoSansTagalog-Regular.ttf
/system/fonts/NotoSansTagbanwa-Regular.ttf
/system/fonts/NotoSansTaiLe-Regular.ttf
/system/fonts/NotoSansTaiTham-Regular.ttf
/system/fonts/NotoSansTaiViet-Regular.ttf
/system/fonts/NotoSansTamil-Bold.ttf
/system/fonts/NotoSansTamil-Regular.ttf
/system/fonts/NotoSansTamilUI-Bold.ttf
/system/fonts/NotoSansTamilUI-Regular.ttf
/system/fonts/NotoSansTelugu-Bold.ttf
/system/fonts/NotoSansTelugu-Regular.ttf
/system/fonts/NotoSansTeluguUI-Bold.ttf
/system/fonts/NotoSansTeluguUI-Regular.ttf
/system/fonts/NotoSansThaana-Bold.ttf
/system/fonts/NotoSansThaana-Regular.ttf
/system/fonts/NotoSansThai-Bold.ttf
/system/fonts/NotoSansThai-Regular.ttf
/system/fonts/NotoSansThaiUI-Bold.ttf
/system/fonts/NotoSansThaiUI-Regular.ttf
/system/fonts/NotoSansTibetan-Bold.ttf
/system/fonts/NotoSansTibetan-Regular.ttf
/system/fonts/NotoSansTifinagh-Regular.ttf
/system/fonts/NotoSansUgaritic-Regular.ttf
/system/fonts/NotoSansVai-Regular.ttf
/system/fonts/NotoSansYi-Regular.ttf
/system/fonts/Roboto-Black.ttf
/system/fonts/Roboto-BlackItalic.ttf
/system/fonts/Roboto-Bold.ttf
/system/fonts/Roboto-BoldItalic.ttf
/system/fonts/Roboto-Italic.ttf
/system/fonts/Roboto-Light.ttf
/system/fonts/Roboto-LightItalic.ttf
/system/fonts/Roboto-Medium.ttf
/system/fonts/Roboto-MediumItalic.ttf
/system/fonts/Roboto-Regular.ttf
/system/fonts/Roboto-Thin.ttf
/system/fonts/Roboto-ThinItalic.ttf
/system/fonts/RobotoCondensed-Bold.ttf
/system/fonts/RobotoCondensed-BoldItalic.ttf
/system/fonts/RobotoCondensed-Italic.ttf
/system/fonts/RobotoCondensed-Light.ttf
/system/fonts/RobotoCondensed-LightItalic.ttf
/system/fonts/RobotoCondensed-Medium.ttf
/system/fonts/RobotoCondensed-MediumItalic.ttf
/system/fonts/RobotoCondensed-Regular.ttf
/system/fonts/MiLanProVF.ttf
/system/fonts/MitypeClock.otf
/system/fonts/MitypeClockMono.otf
/system/fonts/MitypeMonoVF.ttf
/system/fonts/MitypeVF.ttf
/system/fonts/Miui-Bold.ttf
/system/fonts/Miui-Light.ttf
/system/fonts/Miui-Regular.ttf
/system/fonts/Miui-Thin.ttf
/system/fonts/MiuiEx-Bold.ttf
/system/fonts/MiuiEx-Light.ttf
/system/fonts/MiuiEx-Regular.ttf
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive  $MODPATH  0  0  0755  0644
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.

