SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.device`"
var_version="`grep_prop ro.build.version.release`"
B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
D="`grep_prop description $TMPDIR/module.prop`"
ui_print "- *******************************"
ui_print "- 您的设备: $var_device"
ui_print "- 系统版本: $var_version"
ui_print "- $C    "
ui_print "- 作者：$B"
ui_print "- $D    "
ui_print "- *******************************"
if
/sbin/.magisk/busybox/fstrim -v /data
/sbin/.magisk/busybox/fstrim -v /cache
/sbin/.magisk/busybox/fstrim -v /system
/sbin/.magisk/busybox/fstrim -v /vendor
then : 
elif
/dev/*/.magisk/busybox/fstrim -v /data
/dev/*/.magisk/busybox/fstrim -v /cache
/dev/*/.magisk/busybox/fstrim -v /system
/dev/*/.magisk/busybox/fstrim -v /vendor
then : 
else
echo "- fstrim失败"
fi
set_perm_recursive  $MODPATH  0  0  0755  0644