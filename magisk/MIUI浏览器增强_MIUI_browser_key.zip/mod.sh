id="MIUI_browser_key"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
key_MODPATH="/data/adb/$Magisk_mod/$id"
mkdir -p "$key_MODPATH/mod"

for i in $MODPATH/mod/*.json
do
	cp -rf "$i" "$key_MODPATH/mod/${i##/*}"
done

cp -rf "$MODPATH/mod/广告规则" "$key_MODPATH/mod"
cp -rf "$MODPATH/配置.prop" "$key_MODPATH/配置.prop"

for i in $MODPATH/mod/*.sh
do
	source "$i"
done

cat <<key
∞————————————————————————∞

- 修改完成！无需重启！(注，屏蔽MIUI 浏览器广告检测需要重启！)

∞————————————————————————∞
key


