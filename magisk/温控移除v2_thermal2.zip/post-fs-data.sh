#!/system/bin/sh
#禁止创建miui 云下发温控
/sbin/.magisk/busybox/chattr -i  /data/vendor/thermal/config
/sbin/.magisk/busybox/chattr -i  /data/user/0/com.miui.powerkeeper/databases/cloud_configure.db-journal
/sbin/.magisk/busybox/chattr -i  /data/user/0/com.miui.powerkeeper/databases/cloud_configure.db
/sbin/.magisk/busybox/chattr -i  /data/thermal
/sbin/.magisk/busybox/chattr -i  /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config
rm -rf /data/vendor/thermal/thermal.dump
rm -rf /data/vendor/thermal/thermal_history.dump
rm -rf /data/thermal
rm -rf /data/vendor/thermal
touch /data/thermal
touch  /data/vendor/thermal
/sbin/.magisk/busybox/chattr +i  /data/thermal
/sbin/.magisk/busybox/chattr +i  /data/vendor/thermal/config
