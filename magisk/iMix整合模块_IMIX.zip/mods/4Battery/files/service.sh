MODDIR="$1"
#清理电池优化名单部分
#开机30秒清理电池优化名单
sleep 30
#优化白名单，（添加应用包名后，将保留应用不被移出电池优化）
#示例：+com.tencent.mm +后面是微信包名
noDozes="
+com.tencent.mm 
+com.tencent.mobileqq
"
#执行移出电池优化名单
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes