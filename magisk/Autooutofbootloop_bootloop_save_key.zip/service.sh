#!/system/bin/sh
MODDIR=${0%/*}
sleep 5s
chmod -R 0777 "$MODDIR"
source "$MODDIR/update_system.sh"

