sleep 4
service call SurfaceFlinger 1008 i32 1