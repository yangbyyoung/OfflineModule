#UFS
#禁用I/O统计
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
echo 0 > /sys/block/sdb/queue/iostats
echo 0 > /sys/block/sdc/queue/iostats
echo 0 > /sys/block/sdd/queue/iostats
echo 0 > /sys/block/sde/queue/iostats
echo 0 > /sys/block/sdf/queue/iostats

#禁用(存储I/O)调试帮助
echo 0 > /sys/block/sda/queue/nomerges
echo 0 > /sys/block/sdb/queue/nomerges
echo 0 > /sys/block/sdc/queue/nomerges
echo 0 > /sys/block/sdd/queue/nomerges
echo 0 > /sys/block/sde/queue/nomerges
echo 0 > /sys/block/sdf/queue/nomerges

#RAMDUMP
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps

#禁用I/O调试，UFS 和EMMC皆可用
echo 0 > /sys/block/loop0/queue/iostats
echo 0 > /sys/block/loop1/queue/iostats
echo 0 > /sys/block/loop2/queue/iostats
echo 0 > /sys/block/loop3/queue/iostats
echo 0 > /sys/block/loop4/queue/iostats
echo 0 > /sys/block/loop5/queue/iostats
echo 0 > /sys/block/loop6/queue/iostats
echo 0 > /sys/block/loop7/queue/iostats
echo 0 > /sys/block/loop8/queue/iostats
echo 0 > /sys/block/loop9/queue/iostats
echo 0 > /sys/block/loop10/queue/iostats
echo 0 > /sys/block/loop11/queue/iostats
echo 0 > /sys/block/loop12/queue/iostats
echo 0 > /sys/block/loop13/queue/iostats
echo 0 > /sys/block/loop14/queue/iostats
echo 0 > /sys/block/loop15/queue/iostats

# 数据分区I/O控制器优化
echo "128" > /sys/block/sda/queue/read_ahead_kb
echo "36" > /sys/block/sda/queue/nr_requests
