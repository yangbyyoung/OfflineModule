#!/sbin/sh
# Magisk多合一模块
# 脚本底包: 来自酷安@cjybyjk
# 编写: 酷安@皮卡丶皮卡丘
rm -rf /data/system/package_cache/*/*miuisystemui*
rm -rf /data/system/package_cache/*/*MiuiSystemUI*
