#!/system/bin/sh
MODDIR=${0%/*}
a=$(getprop ro.system.build.version.release)
b=$(getprop ro.system.build.version.incremental)
if [ $a == "13" ]; then
    if [ $b =="V14.0.23.1.9.DEV" ]; then
	    mkdir -p $MODDIR/system/product/app/
	    cp -r "$MODDIR/system/product/app/MiSound" "$MODDIR/system/product/app/"
		pm install -r "$MODDIR/system/product/app/MiSound/MiSound.apk"
		sleep 0.5s
	    pm enable com.miui.misound
	    else
		    mkdir -p $MODDIR/system/app
	    cp -r "$MODDIR/system/product/app/MiSound" "$MODDIR/system/app/"
		pm install -r "$MODDIR/system/product/app/MiSound/MiSound.apk"
		sleep 0.5s
	    pm enable com.miui.misound
    fi
	else
	    mkdir -p $MODDIR/system/app
	cp -r "$MODDIR/system/product/app/MiSound" "$MODDIR/system/app/"
	pm install -r "$MODDIR/system/product/app/MiSound/MiSound.apk"
	sleep 0.5s
	pm enable com.miui.misound
fi