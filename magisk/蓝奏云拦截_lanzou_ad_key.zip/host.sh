
function correctpath(){
	case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	esac
}


find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2> /dev/null | while read hostfile ;do
mkdir -p $MODPATH${hostfile%/*}
cp -rf $hostfile $MODPATH${hostfile%/*}
cat <<key>> $MODPATH$hostfile
#蓝奏云
127.0.0.1 lupic.cdn.bcebos.com
127.0.0.1 sanme2.lanzoui.com
127.0.0.1 glores2.lanzoui.com
127.0.0.1 sanme2.lanzoux.com
127.0.0.1 glores2.lanzoux.com
127.0.0.1 sanme2.taisantech.com
127.0.0.1 glores2.taisantech.com
#END
key
done

grep_host (){
find /data/adb/modules -type f -iname "hosts" | cut -d/ -f5 | uniq
}

for o in $(grep_host) ;do
for i in $(ls /data/adb/modules) ;do
	name=$(cat /data/adb/modules/$i/module.prop | grep 'name'| cut -d = -f2 )
	author=$(cat /data/adb/modules/$i/module.prop | grep 'author'| cut -d = -f2 )
	description=$(cat /data/adb/modules/$i/module.prop | grep 'description'| cut -d = -f2 )
	size=` du -sh /data/adb/modules/$i |awk '{print $1}'`
	if test "$i" = "$o" -a "$i" != "$id" ;then
		echo " "
		echo "∞————————————————————————∞"
		echo ""
		echo "－名称：$name"
		echo "－作者：$author"
		echo "－简介：$description"
		echo " "
		echo "－大小：$size"
		echo " "
		echo "－ 该模块含有hosts！"
		echo ""
		echo "－ 正在合并模块中……"
		echo ""
		oldfile=`find "/data/adb/modules/$i" -type f -iname "hosts"`
		for i in $oldfile ;do
cat <<key>> $i
#蓝奏云
127.0.0.1 lupic.cdn.bcebos.com
127.0.0.1 sanme2.lanzoui.com
127.0.0.1 glores2.lanzoui.com
127.0.0.1 sanme2.lanzoux.com
127.0.0.1 glores2.lanzoux.com
127.0.0.1 sanme2.taisantech.com
127.0.0.1 glores2.taisantech.com
#END
key
		done && abort "－ 合并完成！"
		echo "∞————————————————————————∞"
		echo " "
	fi
done
done

