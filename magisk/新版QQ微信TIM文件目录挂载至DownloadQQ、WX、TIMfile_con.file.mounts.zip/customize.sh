
SKIPUNZIP=1

ui_print "- 正在提取文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

ui_print "- 正在设置权限"
set_perm_recursive $MODPATH 0 0 0755 0644

ab=1
. $MODPATH/service.sh

ui_print "- 已完成挂载"

ui_print "- 完成权限设置"
