### Preguntas frecuentes

- _¿Es necesario un BusyBox?_

> **No.** La aplicación tiene la suya propia incorporada. Pero tener una aplicación/módulo BusyBox
> adicional instalado no causará ningún conflicto.

- _¿Por qué algunos ajustes están inactivos (no se pueden cambiar)?_

> FDE.AI comprueba si tu dispositivo admite alguno de los ajustes de la lista. Si un ajuste no es
> compatible, se desactivará. Esto también puede depender del modo de IA seleccionado y de si
> la optimización del sistema en tiempo real está activada o no.

- _¿Por qué la IA pone mi dispositivo en modo rendimiento mientras que yo lo pongo en ahorro de
  energía?_

> La IA sintoniza VM para el rendimiento si el dispositivo se está cargando. Una vez que desenchufes
> el dispositivo del cargador, la IA volverá al modo anterior. Esta opción es segura y no hará
> que tu dispositivo se sobrecaliente porque sólo ajusta los parámetros de la VM
> (sin cambios de frecuencia/térmicos).

- _La aplicación funciona bien, pero el registro no se actualiza durante mucho tiempo. ¿Está bien?_

> **Sí**, porque FDE.AI realiza varias actividades en segundo plano sólo si es realmente necesario
> basándose en el escenario de uso de tu dispositivo. Sin embargo, si crees que la aplicación se
> ha quedado bloqueada, intenta reiniciar FDE.AI desde la página de configuración o reinicia
> el dispositivo.

- _¿Funcionará FDE.AI con la aplicación tweaker X, Y o Z?_

> Probablemente sí, pero es altamente **NO recomendable**. Pueden producirse problemas/conflictos
> inesperados. Sin embargo, si sabes lo que estás haciendo, y sabes si un ajuste entrará
> en conflicto o no, puedes utilizar otros tweakers junto con FDE.AI. Sin embargo, como se ha dicho
> anteriormente esto NO ES RECOMENDABLE y debe hacerse BAJO TU PROPIO RIESGO.

- _¿Por qué no se admite CPU y/o GPU Turbo?_

> Porque el kernel que utilizas no proporciona un nodo de información necesario para que FDE.AI lo
> utilice. Sin embargo también podría ser que el chipset/driver de tu dispositivo simplemente no
> lo soporta. Además, algunas CPUs no proporcionan los sintonizables requeridos para operar
> 'ondemand'/'interactive'/'schedutil' o basados en estos gobernadores deberían ser soportados
> por CPU Turbo. De todos modos, lo que puedes intentar es cambiar el gobernador, kernel
> o simplemente borrar los datos de las aplicaciones para asegurarte de que no es un fallo
> aleatorio. Además, hay soporte GPU Turbo heredado para ciertas GPUs Mali y Vivante que de otra
> manera no soportan esta característica. Requiere tener activa la opción de aceleración constante
> del juego y funciona con los juegos compatibles automáticamente, o puede activarse siempre
> si el modo IA está configurado como rendimiento.

- _¿Cómo cambio el gobernador de mi CPU/GPU?_

> Descarga un gestor de kernel (recomendamos SmartPack pero literalmente cualquiera es bueno) y
> cámbialo desde ahí.

- _¿Puedo cerrar la aplicación de forma segura deslizando el dedo fuera de "Recientes"?_

> Sí. Hay un servicio en segundo plano que gestiona todos los procesos. La aplicación actúa como una
> envoltura de ese servicio en segundo plano.

- _Cuando hablas de un servicio en segundo plano, ¿significa eso que la aplicación consumirá mi
  batería?_

> **No**. Simplemente no.

- _¿Cómo se desinstala correctamente FDE.AI?_

> Desinstala la aplicación como de costumbre y reinicia el dispositivo. Todos los ajustes aplicados
> volverán a sus valores predeterminados. Pero, por favor, considera informar de tus razones para
> desinstalar en el grupo de soporte. Especialmente si fue por errores o la aplicación no se
> comportaba como esperabas.

- _¿Qué métodos de root admite la aplicación?_

> Literalmente cualquiera, pero Magisk es el recomendado.

- _¿Qué es el tiempo de vida de la IA en la página principal de la aplicación?_

> Es sólo un simple indicador que muestra cuánto tiempo ha estado activa la IA. Por ejemplo,
> se reiniciará si pulsas "Reiniciar FDE.AI" o cuando se reinicie tu dispositivo.

- _¿Por qué a veces la IA informa falsamente de su modo?_

> No está informando falsamente, sólo actualiza lentamente (no en tiempo real) su estado lo que
> normalmente suele requerir ~40 segundos.

- _¿Qué es el botón "Optimizador de PC" de la página de información y por qué está ahí?_

> Es un enlace a la aplicación optimizadora de la asociación (freeware) para el sistema operativo
> Windows. La aplicación está desarrollada y mantenida por diferentes desarrolladores
> (no por el equipo de FDE.AI).

- _Mi sistema empieza a tener retraso después de la ejecución de FDE.AI. ¿Por qué?_

> Eso no debería ocurrir. Pero usted puede tratar de desactivar ** todos ** los retoques build.prop
> en la configuración, reiniciar el dispositivo y ver.

- _Tengo una pregunta que no figura en estas FAQ/Preguntas frecuentes. ¿Dónde puedo encontrar una
  respuesta?_

> Consulta la sección "Información sobre IA". También puedes unirte a nuestro
> [grupo de soporte de Telegram](https://t.me/feralab_eng) - estaremos encantados de ayudarte 😉

- _He encontrado un error/tengo sugerencias, ¿dónde puedo informar de ellas?_

> Lo mismo que arriba - en nuestro grupo de soporte de Telegram.
