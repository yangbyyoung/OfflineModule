until [[ `getprop init.svc.bootanim` = "stopped" ]]; do
  sleep 3
done
sleep 30
app='
com.tencent.mobileqq
com.tencent.mm
'
#清理白名单
for i in `dumpsys deviceidle whitelist|awk -F ',' '{print $2}'`;do dumpsys deviceidle whitelist -$i ;done
#加入白名单
for i in $app;do dumpsys deviceidle whitelist +$i ;done