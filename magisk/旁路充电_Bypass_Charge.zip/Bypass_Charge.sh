#!/system/bin/sh


# 旁路充电总开关(Y表示该功能启用)
bypass_charge=Y

# 旁路充电时启用CPU性能增强
Performance_enhancements=N




MODDIR=${0%/*}
performance_mode()
{
	if [ $Performance_enhancements == "Y" ]; then
		if cat '/sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors' | grep "performance" > /dev/null
		then
			scaling_governor=`ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor`
			for governors in $scaling_governor
			do
				echo performance >>$governors
			done
		fi
		if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
			echo 1 > /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled
		fi
		if [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
			echo Y > /sys/module/lpm_levels/parameters/sleep_disabled
		fi
	fi
}
balanced_mode()
{
	if [ $Performance_enhancements == "Y" ]; then
		cpu=`ls /sys/devices/system/cpu/cpu*/online`
		for cpus in $cpu
		do
			echo 1 >>$cpus
		done
		if cat '/sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors' | grep "walt" > /dev/null
		then
			scaling_governor=`ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor`
			for governors in $scaling_governor
			do
				echo walt >>$governors
			done
		else
  		  if cat '/sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors' | grep "schedutil" > /dev/null
			then
				scaling_governor=`ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor`
				for governors in $scaling_governor
				do
					echo schedutil >>$governors
				done
			fi
		fi
		if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
			echo 0 > /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled
		fi
		if [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
			echo N > /sys/module/lpm_levels/parameters/sleep_disabled
		fi
	fi
}
charge_stop()
{
	if [ $bypass_charge == "Y" ]; then
		system_charge_current_file_path=`cat $MODDIR/charge_current_file_path`
		for charge_current_dir in $system_charge_current_file_path
		do
			chmod a+rw $charge_current_dir
			system_charge_current=`cat $charge_current_dir`
			bypass_charge_current=`cat $MODDIR/bypass_charge_current`
			if [ $system_charge_current != "$bypass_charge_current" ]; then
				echo "$bypass_charge_current" >>$charge_current_dir
			fi
		done
	fi
}
charge_start()
{
	if [ $bypass_charge == "Y" ]; then
		system_charge_current_file_path=`cat $MODDIR/charge_current_file_path`
		for charge_current_dir in $system_charge_current_file_path
		do
			chmod a+rw $charge_current_dir
			system_charge_current=`cat $charge_current_dir`
			default_charge_current=`cat $MODDIR/default_charge_current`
			if [ $system_charge_current != "$default_charge_current" ]; then
				echo "$default_charge_current" >>$charge_current_dir
			fi
		done
	fi
}
bypass_charge()
{
	if [ $bypass_charge == "Y" ]; then
		gamelist=`cat $MODDIR/GameList.txt`
		for gamestart in $gamelist
		do
			gamepid=`pidof $gamestart`
			if [ "$gamepid" -gt "0" ]; then
					local i=$gamepid
					while [ "$i" -gt "0" ]
					do
						sleep 1
						gamepid=`pidof $gamestart`
						if [ "$gamepid" -gt "0" ]; then
							i=1
							charge_stop
							sleep 5
						else
							i=0
							charge_start
						fi
					done
			fi
		done
	fi
}
while true
do
	sleep 1
	dumpsys battery reset
	battery_status="$(echo "$(dumpsys battery)" | egrep 'status: ' | sed -n 's/.*status: //g;$p')"
	if [ $battery_status == "2" ] || [ $battery_status == "5" ]; then
		performance_mode
			local i=1
			while [ "$i" -gt "0" ]
			do
				sleep 2
				bypass_charge
				battery_status="$(echo "$(dumpsys battery)" | egrep 'status: ' | sed -n 's/.*status: //g;$p')"
				if [ $battery_status == "2" ] || [ $battery_status == "5" ]; then
					i=1
				else
					i=0
				fi
			done
	else
		balanced_mode
		charge_start
			local i=1
			while [ "$i" -gt "0" ]
			do
				sleep 10
				battery_status="$(echo "$(dumpsys battery)" | egrep 'status: ' | sed -n 's/.*status: //g;$p')"
				if [ $battery_status == "2" ] || [ $battery_status == "5" ]; then
					i=0
				else
					i=1
				fi
			done
	fi
done
