#!/system/bin/sh


function correctpath(){
	case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	esac
}

find /vendor/etc/perf -type f 2> /dev/null | while read file ;do
file=$( correctpath $file )
echo $file | grep -q -w 'perfconfigstore.xml' && continue
mktouch $MODPATH$file
done



