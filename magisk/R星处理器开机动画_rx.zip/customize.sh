MODDIR=${0%/*}

#自定义参数，为空时自动设置
Wide2=""
#宽
Gao2=""
#高
Frame=""
#帧

off="0"
#是否配置关机动画 0=配置 1=不配置

kuan="1"
#是否关注作者 0=关注 1=不关注

UID="19926645"
#酷安UID，分享主页可以获得






























start_time=$(date +%s)
#默认分辨率
Wide=`wm size | cut -d " " -f 3 | cut -d "x" -f 1`
Gao=`wm size | cut -d " " -f 3 | cut -d "x" -f 2`

ui_print() {
  echo -e "\n------------------------------------------------\n"
  echo -e "- $1"
  sleep 0.3
}
ui_print "品牌：`getprop ro.product.brand`
  型号：`getprop ro.product.model`
  安卓：`getprop ro.build.version.release`
  代号：`getprop ro.product.device`"
ui_print "安装时间：$(date '+%g-%m-%d %H:%M:%S')"
ui_print "检测一下开机动画位置为了更好的兼容性！"
test -z $Gao2 && Gao3=$Gao || Gao3=$Gao2
test -z $Wide2 && Wide3=$Wide || Wide3=$Wide2
if [[ -f "/system/product/media/bootanimation.zip" ]]; then
bbb=/system/product/media/bootanimation.zip
ccc=/system/product/media/rbootanimation.zip
elif [[ -f "/system/media/bootanimation.zip" ]]; then
bbb=/system/media/bootanimation.zip
ccc=/system/media/rbootanimation.zip
elif [[ -f "/vendor/media/bootanimation.zip" ]]; then
bbb=/vendor/media/bootanimation.zip
ccc=/vendor/media/rbootanimation.zip
elif [[ -f "/product/media/bootanimation.zip" ]]; then
bbb=/product/media/bootanimation.zip
ccc=/product/media/rbootanimation.zip
elif [[ -f "/my_product/media/bootanimation/bootanimation.zip" ]]; then
bbb=/my_product/media/bootanimation/bootanimation.zip
ccc=/my_product/media/bootanimation/rbootanimation.zip
col="g $Wide3 $Gao3 0 0 $Frame"
else
ui_print "未检测到开机动画位置！"
exit 1
fi
ui_print "检测到开机动画位置在$bbb！"
ui_print "正在配置文件"
kjdh(){
chmod -R 0777 $MODPATH/*
cd $MODPATH
for name in *; do
name="$name"
if [[ -d $MODPATH/$name ]];then
if [ -z "$(ls -A $MODPATH/$name)" ]; then
ui_print "文件夹 $name 为空，跳过制作"
rm -rf $MODPATH/$name
else
mkdir tmp
mkdir tmp/wowull
cp -f $MODPATH/99999.png $MODPATH/tmp/wowull
folder_path="$MODPATH/$name"
img_count=`find "${folder_path}" -type f -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" | wc -l`
img_count_divided=`printf "%.0f" $(echo "scale=1; $img_count/10" | bc)`
if [[ "$img_count_divided" -lt "1" ]]; then
    img_count_divided=1
fi
test -z $Frame && Frame=$img_count_divided || Frame=$Frame
echo "$Wide3 $Gao3 $Frame
p 1 0 wowull
p 0 0 $name" > $MODPATH/tmp/desc.txt
mv $name $MODPATH/tmp/$name
cd tmp
$MODPATH/zip -rq -0 $name.zip *
mv $name.zip $MODPATH
cd $MODPATH
ui_print "文件夹 $name 配置完毕！"
rm -rf $MODPATH/tmp
fi
fi
done
ls $MODPATH/*.zip 1> /dev/null 2>&1 
if [[ ! $? = 0 ]];then
ui_print "制作失败！"
rm -rf $MODPATH
exit 1
fi
echo 'MODDIR=${0%/*}
aaa=`find $MODDIR -name *.zip 2>/dev/null`' > post-fs-data.sh
echo "bbb=$bbb" >> post-fs-data.sh
echo 'mount --bind $aaa $bbb' >> post-fs-data.sh
[[ $off = 0 ]] && echo "ccc=$ccc" >> post-fs-data.sh && echo 'mount --bind $aaa $ccc' >> post-fs-data.sh
music=`ls -A $MODPATH/*.mp3`
if [[ -e "$music" ]]; then
ui_print "正在配置开机音乐"    
echo 'music=`find $MODDIR -name *.mp3 2>/dev/null`
mount --bind "$music" ${bbb%/*}/bootaudio.mp3' >> post-fs-data.sh
fi
}
colkjdh(){
chmod -R 0777 $MODPATH/*
cd $MODPATH
for name in *; do
name="$name"
if [[ -d $MODPATH/$name ]];then
if [ -z "$(ls -A $MODPATH/$name)" ]; then
ui_print "文件夹 $name 为空，跳过制作"
rm -rf $MODPATH/$name
else
mkdir tmp
mkdir tmp/wowull
cp -f $MODPATH/99999.png $MODPATH/tmp/wowull
folder_path="$MODPATH/$name"
img_count=`find "${folder_path}" -type f -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" | wc -l`
img_count_divided=`printf "%.0f" $(echo "scale=1; $img_count/10" | bc)`
if [[ "$img_count_divided" -lt "1" ]]; then
    img_count_divided=1
fi
test -z $Frame && Frame=$img_count_divided || Frame=$Frame
echo "g $Wide3 $Gao3 0 0 $Frame
p 1 0 wowull
p 0 0 $name" > $MODPATH/tmp/desc.txt
mv $name $MODPATH/tmp/$name
cd tmp
$MODPATH/zip -rq -0 $name.zip *
mv $name.zip $MODPATH
cd $MODPATH
ui_print "文件夹 $name 配置完毕！"
rm -rf $MODPATH/tmp
fi
fi
done
ls $MODPATH/*.zip 1> /dev/null 2>&1 
if [[ ! $? = 0 ]];then
ui_print "制作失败！"
rm -rf $MODPATH
exit 1
fi
mkdir $MODPATH/bootanimation
echo 'MODDIR=${0%/*}
aaa=$MODDIR/bootanimation' > post-fs-data.sh
echo "bbb=${bbb%/*}" >> post-fs-data.sh
echo 'mount --bind $aaa $bbb' >> post-fs-data.sh
zipfile=$(ls $MODPATH/*.zip 2>/dev/null | shuf -n 1)
cp -f $zipfile $MODPATH/bootanimation/bootanimation.zip
[[ $off = 0 ]] && cp -f $zipfile $MODPATH/bootanimation/rbootanimation.zip
music=`ls -A $MODPATH/*.ogg`
if [[ -e "$music" ]]; then
ui_print "正在配置关机音乐"        
mv "$music" $MODPATH/bootanimation/poweroff.ogg
fi
}

service(){
echo 'zipfiles=($(ls $MODDIR/*.zip 2>/dev/null))

# 检查是否有可用的zip文件
if [[ ${#zipfiles[@]} -eq 0 ]]; then 
    echo "" > disable
    exit
fi

# 从文件列表中随机获取一个文件名
index=$(($RANDOM % ${#zipfiles[@]}))
zipfile=${zipfiles[$index]}

# 根据文件名复制zip文件
if [[ -e $MODDIR/bootanimation/bootanimation.zip ]];then
    cp -f $MODDIR/bootanimation/bootanimation.zip $MODDIR/bootanimation/rbootanimation.zip
    cp -f $zipfile $MODDIR/bootanimation/bootanimation.zip
    else
    sed -i "/aaa=/caaa="$zipfile"" $MODDIR/post-fs-data.sh
    fi' >> post-fs-data.sh
}


go_to_coolapk() {
if [[ "$(pm list package | grep -w 'com.coolapk.market')" != "" ]];then
ui_print "你安装了酷安，火速给我点个关注"
sleep 2         
am start -d "coolmarket://u/19926645" >/dev/null 2>&1
else
ui_print "未安装酷安，关注不了QAQ"         
fi
}

test -z $col && kjdh || colkjdh
service
end_time=$(date +%s)
time_diff=$((end_time - start_time))
ui_print "用时为: $time_diff 秒"
ui_print "配置完成，可以享受新的开机动画啦！"
rm -f $MODPATH/zip
[[ $kuan = 0 ]] && go_to_coolapk
rm -rf $tmp
exit 0

