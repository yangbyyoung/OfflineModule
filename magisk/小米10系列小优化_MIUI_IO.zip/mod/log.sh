#清理miui内测桌面日志
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 

#杀掉WLAN
am kill tcpdump
killall -9 tcpdump

am kill cnss_diag
killall -9 tcpdump

#清理wifi 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
