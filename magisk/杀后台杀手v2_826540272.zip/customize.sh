#模块内容全部进magisk系统=0
#更多自定义=1
SKIPUNZIP=0
ui_print "********************************"
ui_print "	卸载和禁用一些系统垃圾 "
ui_print "********************************"
pm uninstall -k --user 0 com.coloros.securepay
pm uninstall -k --user 0 com.heytap.browser
pm uninstall -k --user 0 com.nearme.instant.platform
pm uninstall -k --user 0 com.nearme.statistics.rom
pm uninstall -k --user 0 com.nearme.atlas
pm uninstall -k --user 0 com.coloros.athena
pm uninstall -k --user 0 com.coloros.remoteguardservice
pm uninstall -k --user 0 com.oplus.crashbox
pm uninstall -k --user 0 com.oppo.atlas
pm uninstall -k --user 0 com.coloros.securityguard
pm uninstall -k --user 0 com.oplus.onetrace
pm uninstall -k --user 0 com.coloros.healthcheck
pm uninstall -k --user 0 com.miui.powerkeeper
pm uninstall -k --user 0 com.oppo.oppopowermonitor
pm uninstall -k --user 0 com.opos.ads
pm uninstall -k --user 0 com.coloros.deepthinker
pm uninstall -k --user 0 com.coloros.wifisecuredetect
pm uninstall -k --user 0 com.coloros.familyguard
chmod -R 0777 $MODPATH/ifw
cp -af $MODPATH/ifw /data/system/

  if [[ "$API" != "30" && "$API" != "29" ]]; then
    sed -i '/ro.lmk.use_psi/d' $MODPATH/system.prop
    sed -i '/ro.lmk.use_minfree_levels=false/d' $MODPATH/system.prop
    ui_print "检测到旧版安卓 $ARCH $API"
  else
    ui_print "验证设备版本，不是哄蒙 $ARCH $API"
  fi

ui_print "********************************"
ui_print "	安装完成	 反馈QQ群 759354917 "
ui_print "********************************"