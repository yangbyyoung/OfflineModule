MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    [ ! -f "$2" ] && return
    umount "$2"

    chmod +w "$2"
    echo "$1" | tee -a /dev/mount_mask "$2"
    mount --bind /dev/mount_mask "$2"
    rm /dev/mount_mask
}

lock_val "0-1" /dev/cpuset/background/cpus
lock_val "2-6" /dev/cpuset/system-background/cpus
lock_val "2-6" /dev/cpuset/foreground/cpus
lock_val "2-7" /dev/cpuset/top-app/cpus
lock_val "1" /sys/devices/system/cpu/cpu5/core_ctl/enable
lock_val "0" /sys/devices/system/cpu/cpu5/core_ctl/min_cpus
lock_val "0" /sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus
lock_val "0" /sys/devices/system/cpu/cpu5/core_ctl/offline_delay_ms

while [ -z `getprop sys.boot_completed` ]; do sleep 1; done
stop mimd-service; killall -15 cpu_closer
nohup $MODDIR/cpu_closer > /dev/null 2>&1 &
