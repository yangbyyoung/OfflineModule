MODDIR=${0%/*}

# 启用 SELinux
# echo 1 > /sys/fs/selinux/enforce



#GPU温度墙
echo 115000 > /sys/class/thermal/thermal_zone36/trip_point_3_temp
echo 115000 > /sys/class/thermal/thermal_zone37/trip_point_3_temp
echo 105000 > /sys/class/thermal/thermal_zone35/trip_point_2_temp

