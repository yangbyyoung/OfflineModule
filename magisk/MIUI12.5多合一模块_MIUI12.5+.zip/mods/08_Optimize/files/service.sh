#!/system/bin/sh
#获取时间
sleep 20s
Time() {
    date '+%F  %H:%M:%S'
}

#日志打印目录
log=/storage/emulated/0/Android/MIUI12.5+/Logbook.log
echo "当前模块版本：v20210620" >$log
echo "时间：`Time`" >>$log

# 禁用Google全家桶
sleep 5s
pm disable com.google.android.gms
pm disable com.google.android.gsf
pm disable com.android.vending
pm disable com.google.android.syncadapters.contacts
pm disable com.google.android.onetimeinitializer
echo "`Time`，已执行禁用Google全家桶" >>$log

#禁用双开的Google服务
sleep 5s
pm disable-user --user 999 com.google.android.gms
pm disable-user --user 999 com.google.android.gsf
echo "`Time`，已执行禁用双开的Google服务" >>$log

#执行移出电池优化名单
sleep 5s
if [ -f "/storage/emulated/0/Android/MIUI12.5+/Settings.conf" ]; then 

    source /storage/emulated/0/Android/MIUI12.5+/Settings.conf
    fi
    
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes deep
echo "`Time`，已执行电池优化" >>$log