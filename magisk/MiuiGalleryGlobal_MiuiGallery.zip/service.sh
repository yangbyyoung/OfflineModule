resetprop ro.miui.ui.version.code 11
resetprop ro.product.manufacturer Xiaomi
resetprop --delete ro.product.mod_device

sleep 15

allow_operation() {
  UID=`pm list packages -U | grep $PKG | sed -n -e "s/package:$PKG uid://p"`
  pm grant $PKG android.permission.READ_EXTERNAL_STORAGE
  pm grant $PKG android.permission.WRITE_EXTERNAL_STORAGE
  appops set --uid $UID LEGACY_STORAGE allow
  appops set $PKG READ_EXTERNAL_STORAGE allow
  appops set $PKG WRITE_EXTERNAL_STORAGE allow
  appops set $PKG ACCESS_MEDIA_LOCATION allow
  appops set $PKG READ_MEDIA_AUDIO allow
  appops set $PKG READ_MEDIA_VIDEO allow
  appops set $PKG READ_MEDIA_IMAGES allow
  appops set $PKG WRITE_MEDIA_AUDIO allow
  appops set $PKG WRITE_MEDIA_VIDEO allow
  appops set $PKG WRITE_MEDIA_IMAGES allow
  appops set $PKG MANAGE_EXTERNAL_STORAGE allow
  appops set $PKG NO_ISOLATED_STORAGE allow
}

PKG=com.miui.gallery
pm grant $PKG android.permission.ACCESS_MEDIA_LOCATION
allow_operation
appops set $PKG SYSTEM_ALERT_WINDOW allow

PKG=cn.wps.moffice_eng.xiaomi.lite
if pm list packages | grep -Eq $PKG; then
  allow_operation
fi



