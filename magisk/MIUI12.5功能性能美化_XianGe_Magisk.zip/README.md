#永远相信美好的事情即将发生！
#系统精简
/system/app/
#推送服务=AnalyticsCore
#基本互动屏=BasicDreams
#收集日志=CatchLog
＃CIT=Cit
#In-Display 指纹=goodix_sz
#用户信息收集=MiuiDaemon
#用户反馈=MiuiBugReport
#小米商城系统组件=mab
#智能服务=MSA
＃维修模式=MaintenanceMode
＃sim卡日志=SimAppDialog
#米币支付=PaymentService
#打印处理服务=PrintSpooler
#系统跟踪=Traceur
＃推送服务=WMService
＃安全守护服务=greenguard
＃谷歌浏览器收藏插件=BookmarkProvider
＃收集日志=CatcherPatch
＃CQR=com.miui.qr
#密钥链=KeyChain
#连接电脑的=PacProcessor

/system/priv-app/
#系统打印服务=BuiltInPrintService
#通话记录备份=CallLogBackup
＃MIUI免费短信=MiRcs
#用户字典=UserDictionaryProvider
#存储已屏蔽的号码=BlockedNumberProvider
#日志相关=DMRegService

/system/product/app/
#照片屏幕保护程序=PhotoTable

/system/system_ext/app/
＃收音机调频服务=FM

/system/system_ext/priv-app/
#急救信息=EmergencyInfo

/system/data-app/

/system/vendor/data-app/