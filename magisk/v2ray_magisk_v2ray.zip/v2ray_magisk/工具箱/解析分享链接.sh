#节点保存目录
nodeDir='../海外节点'

#节点分享链接(一行一个链接)
nodeLinks='
vless://270c9fcd-a8a5-4fab-a8c8-463e642d13c6@119.29.186.53:5263?security=xtls&encryption=none&headerType=none&type=kcp&flow=xtls-rprx-direct&allowInsecure=1#mkcp+xtls_119.29.186.53:5263
vless://270c9fcd-a8a5-4fab-a8c8-463e642d13c6@119.29.186.53:2635?path=/&security=tls&flow=xtls-rprx-origin&encryption=none&host=cutebi.taobao69.cn&type=ws&allowInsecure=1#ws+tls_119.29.186.53:2635
'
#mux开关(true开启)
mux='false'

#免流Host, 如果不设置则使用节点自带的
repHost=''

#path, 如果不设置则使用节点自带的
repPath=''


cd "${0%/*}"
sh ../Core/downloadCores.sh "$repHost" 'MLBox' 'Usgae'
echo "节点保存目录为: $PWD/$nodeDir"
echo '所有 节点文件(.ini结尾) 需要复制到 海外节点 或 海内节点 文件夹才可以用'
alias 'MLBox=../Core/MLBox'
mkdir "$nodeDir" 2>/dev/null
i=1
for v2link in $nodeLinks; do
	v2msg=`MLBox -v2Link="$v2link"`
	eval "$v2msg"
	echo "$ps" | grep -q '/' && ps="${ps//\//\\}"
	filePath="${nodeDir:=$PWD}/${i}_${ps%% *}.ini"
	echo "$v2link" | grep -q '^vless' && protocol='vless' || protocol='vmess'
	echo "protocol=$protocol" >"$filePath"
	echo "mux='$mux'" >>"$filePath"
	echo "$v2msg" | grep -Ev '^host|^sni|^path' >>"$filePath"
	if [ -n "$repHost" ]; then
		host="$repHost"
		sni="$repHost"
	fi
	if [ -n "$repPath" ]; then
		path="$repPath"
	fi
	echo "host='$host'" >>"$filePath"
	echo "sni='$host'" >>"$filePath"
	echo "path='$path'" >>"$filePath"
	echo -E "第$i个节点: ${ps}, 已写入文件: ${i}_${ps%% *}.ini"
	for v in ${v2msg// /_}; do
		unset "${v%=*}"
	done
	i=$((i + 1))
done
