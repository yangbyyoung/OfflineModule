#!/system/bin/sh

PKGNAME=$(grep description "${0%/*}"/module.prop | sed -n 's/.*(//;s/).*//p')

STOCKPATH=$(pm path "$PKGNAME" | sed -n '/base/s/package://p')

[ -n "$STOCKAPPVER" ] && umount -l "$STOCKPATH"