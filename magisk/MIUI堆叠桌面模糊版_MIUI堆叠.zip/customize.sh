DUBUG_FLAG=false

PROPFILE=false

POSTFSDATA=true

LATESTARTSERVICE=false

print_modname() {
  ui_print "堆叠桌面模块@小豬同学"
  ui_print "桌面由酷安@小豬同学"
  ui_print "模块由酷安@小豬同学"
  ui_print "原系统桌面版本:ALPHA-4.26.0.4222-12292007"
  ui_print "
  更新内容如下:
  ■解锁桌面布局
  ■堆叠后台（需手动去设置/桌面/最近任务样式修改为横向排布）
  ■禁用桌面日志
  ■开启平滑动画
  ■开启全机型水波纹下载动画
  ■开启搜索框模糊
  ■隐藏多任务界面小窗应用图标
  ■开启部分低端机型完整动画
  ■开启全机型完整模糊动画
  ■动画速度→1.25f
  ■后台卡片圆角→27f
  ■卡片图标缩小为原来3/4
  ■去除后台卡片上方文字
  ■关闭打开应用时壁纸压暗
  ■修改多任务卡片大小
  ■开启全机型文件夹模糊
  ■文件夹模糊程度→0.625f
  ■修复完文件夹退出应用壁纸先清晰再模糊问题
  ■兼容安卓12和桌面小部件"
  ui_print "卡米或进入系统黑屏请自行进入Rec终端命令输入*/mm删除此模块"
  ui_print "（🌝🌚不会吧，不会吧，不会还有人怕卡米却不装mm管理器吧🌝🌚）"
}

on_install() {
  ui_print "- 正在释放模块文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  TMPAPKDIR=/data/local/tmp
  cp -rf $MODPATH/system/priv-app/MiuiHome/MiuiHome.apk $TMPAPKDIR
  result=$(pm install ${TMPAPKDIR}/MiuiHome.apk 2>&1)
  if [ $result = Success ];then
    echo
    ui_print "- 系统具备核心破解安装成功，可免重启体验"
    echo
  else
    echo
    ui_print "- 重启后生效"
    echo
  fi
    
    ABI=`grep_prop ro.product.cpu.abi`
    case "$ABI" in
        arm64*) Type=arm64 Wenj=arm64-v8a;;
        arm*) Type=arm Wenj=armeabi-v7a;;
        x86_64*) Type=x86_64 Wenj=x86_64;;
        x86*) Type=x86 Wenj=x86;;
        *) echo "！ 未知的架构 ${ABI}，无法安装";;
    esac
    mkdir -p $MODPATH/system/priv-app/MiuiHome/lib/${Type}
    mkdir -p $MODPATH/Home
    unzip -o $MODPATH/system/priv-app/MiuiHome/MiuiHome.apk -d $MODPATH/Home >&2
    cp -rf $MODPATH/Home/lib/${Wenj}/* $MODPATH/system/priv-app/MiuiHome/lib/${Type}
    rm -rf $MODPATH/Home
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}

tmp_list="MiuiHome"

dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"*
done
rm -rf /data/system/package_cache/*
