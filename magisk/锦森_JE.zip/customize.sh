  ui_print "*******************************"
  ui_print "刷入中"
  ui_print "你下一个云控何必是云控"
  ui_print "刷入成功后请你重启手机"
  ui_print "*******************************"
  
  pm clear com.xiaomi.joyose
  pm clear com.xiaomi.powerchecker
  pm uninstall -k --user 0 com.miui.analytics
  pm install-existing --user 0 com.miui.daemon
  rm -f /data/system/package_cache/*
  rm -f /cache/miui-thermal/*
  
    ui_print "*******************************"
    ui_print "如果出现上边出现字母之类的属于正常现象"
    ui_print "如果只要不是刷入失败都无需把log反馈给作者" 
    ui_print "*******************************"
    
    ui_print "*******************************"
    ui_print "第三方调度确认"
    ui_print "如果是第三方，请选择音量上键"
    ui_print "如果是官方，请选择音量下键"
    ui_print "是，请你按音量上键"
    ui_print "否，请你按音量下键"
    ui_print "如果改变调度，请你重新安装本模块"
    ui_print "*******************************"
        key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo "为你你启动第三方调度方案"
  pm disable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
  pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
  pm disable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
  pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
  pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
  pm disable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
  pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
  pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
  pm disable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
  pm disable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
        ;;
        *)
            echo "为你启动官方调度方案"
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
  pm enable com.xiaomi.joyose/predownload.PreDownloadJobScheduler
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
  pm enable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
  pm enable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
  pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
  pm enable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
  pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
  pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
            esac
