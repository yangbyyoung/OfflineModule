#!/bin/sh

start_time="$(date +%s)"

export SKIPMOUNT="false"
export PROPFILE="true"
export POSTFSDATA="true"
export LATESTARTSERVICE="true"
export REPLACE=""
export SKIPUNZIP="0"
export AUTOMOUNT="true"
export ASH_STANDALONE=1
export PATH=/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin
  #环境配置

export ENV='/data/adb/_CBLG/ENV'
export PATH="${PATH}:${ENV}"
  #环境设定

function ui_print () {
  true ;
  "${BOOTMODE}" && {
    echo -e "❤${1}❤" ;
    sleep 0.06 ;
  } || {
    [[ -z "${OUTFD}" ]] && return 255 ;
    echo -e "ui_print ${1}\nui_print" >> "/proc/self/fd/${OUTFD}" ;
    sleep 0.06 ;
  } ;
  return 256 ;
} ;

alias "print"="ui_print" ;
alias "op"="print" ;

alias "get_prop"="grep_prop"
alias "getp"="get_prop"
alias "gp"="getp"

function busybox_install () {
  
  [[ -f '/data/adb/magisk/busybox' ]] && {
    export busybox='/data/adb/magisk/busybox'
  } || {
    [[ -f '/data/adb/ksu/bin/busybox' ]] && {
      export busybox='/data/adb/ksu/bin/busybox'
    }
  }
    #Busybox存放地址检测
  
  [[ -z "${busybox}" ]] && {
    ui_print "   —— 不存在KernelSU/Magisk的BusyBox,请确保使用的是最新版KernelSU/Magisk"
    abort || exit 255
  }
    #不存在Busybox输出
  
    ui_print "   —— 正在安装Busybox"
  "${busybox}" --list | while read applist
    do
      [[ "${applist}" != 'tar' && ! -f "${ENV}/${applist}" ]] && {
        ln -sf "${busybox}" "${ENV}/${applist}"
        [[ "${?}" -eq '0' ]] || {
          ui_print "   —— Busybox安装失败"
          abort || exit 255
        }
      }
  done
  ui_print "   —— 安装成功"
    #释放Busybox
  
}


function print_modname() {
  
  true
  
  var_device="$(grep_prop ro.product.system.device)"
  var_version="$(grep_prop ro.system.build.version.release)"
  var_selinux="$(getenforce)"
  var_qq_group="$(echo -en '872073197' '647299031' '806889171')"
  
  ui_print "   *******************************"
  ui_print "       模块作者: ${MODAUTH}"
  ui_print "       手机型号: ${var_device}"
  ui_print "       系统版本: Android ${var_version}"
  ui_print "       系统架构: ${ARCH}"
  ui_print "       SeLinux: ${var_selinux}"
  ui_print "   *******************************"
  ui_print "   "
  
  yy='false'
  
  "${yy}" && {
    which curl 2>&1 >/dev/null && {
      
      curl -s 'HTTPS://WWW.YY.API.200OK.Work/' 2>&1 >/dev/null
      ui_print "   —— $(curl -s 'HTTPS://WWW.YY.API.200OK.Work/?encode=text&charset=utf-8')"
      
    }
  } || {
    
    ui_print "   —— 纯白的青涩恋歌，热恋的爱情～"
    
  }
  
  ui_print "   "
  ui_print "   "
  ui_print "   —— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')"
  ui_print "   "
  ui_print "   —— 面具版本${MAGISK_VER_CODE}"
  ui_print "   "
  ui_print "   —— 面具代号${MAGISK_VER}"
  ui_print "   "
  ui_print "   "
  ui_print "   "
  ui_print "   —— 请确保从官方渠道下载模块，并且请勿二传"
  ui_print "   "
  ui_print "   "
  ui_print "   —— 模块由 200OK.Work 提供服务"
  ui_print "   "
  ui_print "   "
  
  for group in ${var_qq_group}
    do
      ui_print "   —— QQ交流群：${group}"
      ui_print "   "
  done
  
  [[ -f '/data/adb/magisk_cleaner' ]] && \
    rm -rf '/data/adb/magisk_cleaner'
  
  unzip -oj "$ZIPFILE" "framework/magisk_cleaner" -d "/data/adb/" 1>&2
  [[ -f '/data/adb/magisk_cleaner' ]] || {
    ui_print "   —— 模块文件丢失！"
    abort || exit 255
  }
  chmod 777 '/data/adb/magisk_cleaner'
  '/data/adb/magisk_cleaner'
  
  cd "${MODPATH}"
  : 清理环境，确保兼容性
  
  return 256
  
}

function on_install () {
  
  true
  
  export filepath_old='/sdcard/Android/obb/work.200ok.modules'
  export filepath_old2='/data/adb/work.200ok.modules'
    #老旧的地址
  
  export modid_old=''
    #老旧的名称
  
  export logdir_old='/sdcard/Android/ZS_Plus'
  
  [[ "${modid_old}" != '' ]] && {
    
    [[ -d "$(dirname "${MODPATH}")/$(basename "$(dirname "${MODPATH}")" _update)/${modid_old}" ]] && \
      rm -rf "$(dirname "${MODPATH}")/$(basename "$(dirname "${MODPATH}")" _update)/${modid_old}"
    
    [[ -d "$(dirname "${MODPATH}")/$(basename "$(dirname "${MODPATH}")")/${modid_old}" ]] && \
      rm -rf "$(dirname "${MODPATH}")/$(basename "$(dirname "${MODPATH}")")/${modid_old}"
  
  }
  
  [[ -d "${logdir_old}" ]] && \
    rm -rf "${logdir_old}"
  
  export filepath="$(dirname "${ENV}")"
    #释放地址
  
  export MHOME="${filepath}/Modules"
    #模块路径
  
  [[ -d "${filepath_old}" ]] && {
    
    [[ -d "${filepath}" ]] && {
      
      rm -rf "${filepath_old}"
      
      ui_print "   —— 请勿安装旧版本模块！请通过模块的update功能获取最新版"
      
    }
    
    mv "${filepath_old}/Modules" "${filepath}"
    rm -rf "${filepath_old}"
      #移动原目录
    
    ui_print "   —— 已检测到老旧目录，现已移动"
    
    rm -rf "${ENV}"
      #清理环境
    
    mkdir -p "${filepath}"
    mkdir -p "${MHOME}"
    mkdir -p "${ENV}"
    
    busybox_install
    
  }
  
  [[ -d "${filepath_old2}" ]] && {
    
    [[ -d "${filepath}" ]] && {
      
      rm -rf "${filepath_old2}"
      
      ui_print "   —— 请勿安装旧版本模块！请通过模块的update功能获取最新版"
      
    }
    
    mv "${filepath_old2}/Modules" "${filepath}"
    rm -rf "${filepath_old2}"
      #移动原目录
    
    ui_print "   —— 已检测到老旧目录，现已移动"
    
    rm -rf "${ENV}"
      #清理环境
    
    mkdir -p "${filepath}"
    mkdir -p "${MHOME}"
    mkdir -p "${ENV}"
    
    busybox_install
    
  }
  
  [[ -d "${filepath}" ]] || {
    
    ui_print "   —— 不存在释放目录，已创建"
    
    mkdir -p "${filepath}"
    mkdir -p "${MHOME}"
    mkdir -p "${ENV}"
      #如果没有释放文件夹则创建
    
    busybox_install
  
  }
  
  rm -rf "${MHOME}/${MODID}"
  mkdir -p "${MHOME}/${MODID}"
  
  unzip -oj "$ZIPFILE" "main/*" -d "${MHOME}/${MODID}" 1>&2
  unzip -oj "$ZIPFILE" "common/*" -d "${MODPATH}/" 1>&2
  unzip -oj "$ZIPFILE" "sepolicy.rule" -d "${MODPATH}/" 1>&2
  
  mkdir -p "${MHOME}/${MODID}/framework"
  unzip -oj "$ZIPFILE" "framework/*" -d "${MHOME}/${MODID}/framework" 1>&2
  mv "${MHOME}/${MODID}/framework/zramctl_${ARCH}" "${MHOME}/${MODID}/framework/zramctl"
  rm -rf "${MHOME}/${MODID}/framework/zramctl_*"
  [[ -f "${MHOME}/${MODID}/framework/zramctl" ]] || {
    ui_print "   —— 不存在合适的zramctl文件"
    abort || exit 255
  }
  [[ -f '/data/adb/modules/pandora_kernel/service.sh.cblg' ]] && \
    rm -rf '/data/adb/modules/pandora_kernel/service.sh'
    mv '/data/adb/modules/pandora_kernel/service.sh.cblg' '/data/adb/modules/pandora_kernel/service.sh'
  [[ -d '/data/adb/modules/pandora_kernel' ]] && \
  [[ ! -f '/data/adb/modules/pandora_kernel/disable' ]] && \
    [[ ! -f '/data/adb/modules/pandora_kernel/service.sh.cblg' ]] && {
      mv '/data/adb/modules/pandora_kernel/service.sh' '/data/adb/modules/pandora_kernel/service.sh.cblg'
      echo 'TU9ERElSPSR7MCUvKn0KCiMgJDE6dmFsdWUgJDI6cGF0aApsb2NrX3ZhbCgpIHsKICAgIGlmIFsgLWYgIiQyIiBdOyB0aGVuCiAgICAgICAgdW1vdW50ICIkMiIKICAgICAgICBjaG93biByb290OnJvb3QgIiQyIgogICAgICAgIGNobW9kIDA2NjYgIiQyIgogICAgICAgIGVjaG8gIiQxIiA+IiQyIgogICAgICAgIGNobW9kIDA0NDQgIiQyIgoKICAgICAgICBta2RpciAtcCAiL2RhdGEvbG9jYWwvdG1wL21vdW50X21hc2tzIiQoZGlybmFtZSAiJDIiKSIiCiAgICAgICAgdG91Y2ggIi9kYXRhL2xvY2FsL3RtcC9tb3VudF9tYXNrcyQyIgogICAgICAgIGVjaG8gIiQxIiA+ICIvZGF0YS9sb2NhbC90bXAvbW91bnRfbWFza3MkMiIKICAgICAgICBtb3VudCAtLWJpbmQgIi9kYXRhL2xvY2FsL3RtcC9tb3VudF9tYXNrcyQyIiAiJDIiCiAgICBmaQp9Cgp3YWl0X3VudGlsX2xvZ2luKCkgewogICAgIyBpbiBjYXNlIG9mIC9kYXRhIGVuY3J5cHRpb24gaXMgZGlzYWJsZWQKICAgIHdoaWxlIFsgIiQoZ2V0cHJvcCBzeXMuYm9vdF9jb21wbGV0ZWQpIiAhPSAiMSIgXTsgZG8KICAgICAgICBzbGVlcCAxCiAgICBkb25lCgogICAgIyBpbiBjYXNlIG9mIHRoZSB1c2VyIHVubG9ja2VkIHRoZSBzY3JlZW4KICAgIHdoaWxlIFsgISAtZCAiL3NkY2FyZC9BbmRyb2lkIiBdOyBkbwogICAgICAgIHNsZWVwIDEKICAgIGRvbmUKfQoKaW5pdF96cmFtKCkgewogICAgWyAteiAiJChsc21vZCB8IGdyZXAgenJhbSkiIF0gJiYgaW5zbW9kICRNT0RESVIvbWlzYy96cmFtLmtvCiAgICBybSAtcmYgL2RhdGEvbG9jYWwvdG1wL21vdW50X21hc2sqCiAgICBta2RpciAvZGF0YS9sb2NhbC90bXAvbW91bnRfbWFza3MKICAgIHN3YXBvZmYgL2Rldi9ibG9jay96cmFtMAoKICAgICNsb2NrX3ZhbCAiMSIgL3N5cy9jbGFzcy9ibG9jay96cmFtMC9yZXNldAogICAgbG9ja192YWwgIjAiIC9zeXMvY2xhc3MvYmxvY2svenJhbTAvbWVtX2xpbWl0CiAgICAjbG9ja192YWwgImx6NCIgL3N5cy9jbGFzcy9ibG9jay96cmFtMC9jb21wX2FsZ29yaXRobQogICAgI2xvY2tfdmFsICIkKGNhdCAvcHJvYy9tZW1pbmZvIHwgYXdrICdOUj09MXtwcmludCAkMioxNTM2fScpIiAvc3lzL2NsYXNzL2Jsb2NrL3pyYW0wL2Rpc2tzaXplCgogICAgbWtzd2FwIC9kZXYvYmxvY2svenJhbTAKICAgIHN3YXBvbiAvZGV2L2Jsb2NrL3pyYW0wCgogICAgI3JtIC9kZXYvYmxvY2svenJhbTAKICAgICN0b3VjaCAvZGV2L2Jsb2NrL3pyYW0wCiAgICAjdG91Y2ggL2Rldi9ibG9jay96cmFtMQp9Cgppbml0X25vZGUoKSB7CiAgICBsb2NrX3ZhbCAiMCIgL3N5cy9rZXJuZWwvZ2VkL2hhbC9jdXN0b21fdXBib3VuZF9ncHVfZnJlcQogICAgbG9ja192YWwgIjAiIC9zeXMva2VybmVsL2dlZC9oYWwvZmFzdGR2ZnNfbW9kZQogICAgbG9ja192YWwgIjAiIC9zeXMva2VybmVsL2dlZC9oYWwvZGNzX21vZGUKICAgIGxvY2tfdmFsICIxIiAvc3lzL21vZHVsZS9nZWQvcGFyYW1ldGVycy9pc19HRURfS1BJX2VuYWJsZWQKCiAgICBsb2NrX3ZhbCAiZnJlZSIgL3N5cy9rZXJuZWwvZnBzZ28vY29tbW9uL2ZvcmNlX29ub2ZmCiAgICBsb2NrX3ZhbCAiMSIgL3N5cy9rZXJuZWwvZnBzZ28vY29tbW9uL2Zwc2dvX2VuYWJsZQoKICAgIGxvY2tfdmFsICIwIiAvc3lzL2tlcm5lbC9mcHNnby9mYnQvbGltaXRfY2ZyZXEKICAgIGxvY2tfdmFsICIwIiAvc3lzL2tlcm5lbC9mcHNnby9mYnQvbGltaXRfcmZyZXEKICAgIGxvY2tfdmFsICIwIiAvc3lzL2tlcm5lbC9mcHNnby9mYnQvbGltaXRfY2ZyZXFfbQogICAgbG9ja192YWwgIjAiIC9zeXMva2VybmVsL2Zwc2dvL2ZidC9saW1pdF9yZnJlcV9tCgogICAgaWYgWyAiJChnZXRwcm9wIHJvLmhhcmR3YXJlKSIgPT0gIm10Njk4MyIgXSAmJiBcCiAgICAgICBbICIkKGdldHByb3Agcm8uc3lzdGVtLmJ1aWxkLnZlcnNpb24ucmVsZWFzZSkiIC1ndCAiMTIiIF07IHRoZW4KICAgICAgICBlY2hvICI3IDYgMCIgPiAvcHJvYy9tdGtfbHBtL2NwdWlkbGUvc3RhdGUvZW5hYmxlZAogICAgZmkKCiAgICBybSAtcmYgL2RhdGEvc3lzdGVtL21jZAoKICAgIGlmIFsgIiQoZ2V0cHJvcCByby5oYXJkd2FyZSkiICE9ICJxY29tIiBdOyB0aGVuCiAgICAgICAgcG0gZGlzYWJsZS11c2VyIGNvbS54aWFvbWkuam95b3NlCiAgICAgICAgcmV0dXJuCiAgICBmaQoKICAgIEpPWV9DRkc9Ii9kYXRhL2RhdGEvY29tLnhpYW9taS5qb3lvc2UvZGF0YWJhc2VzL1NtYXJ0UC5kYiIKICAgIGlmIFsgLWYgJEpPWV9DRkcgXTsgdGhlbgogICAgICAgIGNhdCAkTU9ERElSL21pc2MvU21hcnRQLmRiID4gJEpPWV9DRkcKICAgIGZpCgogICAgQlVTX0RJUj0iL3N5cy9kZXZpY2VzL3N5c3RlbS9jcHUvYnVzX2RjdnMiCiAgICBmb3IgZCBpbiAkKGxzICRCVVNfRElSKTsgZG8KICAgICAgICBbICEgLWYgJEJVU19ESVIvJGQvaHdfbWF4X2ZyZXEgXSAmJiBjb250aW51ZQogICAgICAgIE1BWF9GUkVRPSQoY2F0ICRCVVNfRElSLyRkL2h3X21heF9mcmVxKQoKICAgICAgICBmb3IgZGYgaW4gJChscyAkQlVTX0RJUi8kZCk7IGRvCiAgICAgICAgICAgIGxvY2tfdmFsICIkTUFYX0ZSRVEiICIkQlVTX0RJUi8kZC8kZGYvbWF4X2ZyZXEiCiAgICAgICAgZG9uZQogICAgZG9uZQoKICAgIE1JTl9QV1JMVkw9JCgoJChjYXQgL3N5cy9jbGFzcy9rZ3NsL2tnc2wtM2QwL251bV9wd3JsZXZlbHMpIC0gMSkpCiAgICBsb2NrX3ZhbCAiJE1JTl9QV1JMVkwiIC9zeXMvY2xhc3Mva2dzbC9rZ3NsLTNkMC9kZWZhdWx0X3B3cmxldmVsCiAgICBsb2NrX3ZhbCAiJE1JTl9QV1JMVkwiIC9zeXMvY2xhc3Mva2dzbC9rZ3NsLTNkMC9taW5fcHdybGV2ZWwKICAgIGxvY2tfdmFsICIwIiAvc3lzL2NsYXNzL2tnc2wva2dzbC0zZDAvdGhlcm1hbF9wd3JsZXZlbAogICAgbG9ja192YWwgIjEiIC9zeXMvY2xhc3Mva2dzbC9rZ3NsLTNkMC9idXNfc3BsaXQKICAgIGxvY2tfdmFsICIwIiAvc3lzL2NsYXNzL2tnc2wva2dzbC0zZDAvZm9yY2VfYnVzX29uCiAgICBsb2NrX3ZhbCAiMCIgL3N5cy9jbGFzcy9rZ3NsL2tnc2wtM2QwL2ZvcmNlX2Nsa19vbgogICAgbG9ja192YWwgIjAiIC9zeXMvY2xhc3Mva2dzbC9rZ3NsLTNkMC9mb3JjZV9ub19uYXAKICAgIGxvY2tfdmFsICIwIiAvc3lzL2NsYXNzL2tnc2wva2dzbC0zZDAvZm9yY2VfcmFpbF9vbgogICAgbG9ja192YWwgIjAiIC9zeXMvY2xhc3Mva2dzbC9rZ3NsLTNkMC90aHJvdHRsaW5nCgogICAgbG9ja192YWwgIjAiIC9zeXMvbW9kdWxlL21ldGlzL3BhcmFtZXRlcnMvY2x1YWZmX2NvbnRyb2wKICAgIGxvY2tfdmFsICIwIiAvc3lzL21vZHVsZS9tZXRpcy9wYXJhbWV0ZXJzL21pX2Zib29zdF9lbmFibGUKICAgIGxvY2tfdmFsICIwIiAvc3lzL21vZHVsZS9tZXRpcy9wYXJhbWV0ZXJzL21pX2ZyZXFfZW5hYmxlCiAgICBsb2NrX3ZhbCAiMCIgL3N5cy9tb2R1bGUvbWV0aXMvcGFyYW1ldGVycy9taV9saW5rX2VuYWJsZQogICAgbG9ja192YWwgIjAiIC9zeXMvbW9kdWxlL21ldGlzL3BhcmFtZXRlcnMvbWlfc3dpdGNoX2VuYWJsZQogICAgbG9ja192YWwgIjAiIC9zeXMvbW9kdWxlL21ldGlzL3BhcmFtZXRlcnMvbWlfdmlwdGFzawogICAgbG9ja192YWwgIjAiIC9zeXMvbW9kdWxlL21ldGlzL3BhcmFtZXRlcnMvbXBjX2Zib29zdF9lbmFibGUKICAgIGxvY2tfdmFsICIwIiAvc3lzL21vZHVsZS9tZXRpcy9wYXJhbWV0ZXJzL3ZpcF9saW5rX2VuYWJsZQoKICAgIGxvY2tfdmFsICIwOjk5OTkwMDAgMTo5OTk5MDAwIDI6OTk5OTAwMCAzOjk5OTkwMDAgNDo5OTk5MDAwIDU6OTk5OTAwMCA2Ojk5OTkwMDAgNzo5OTk5MDAwIiAvc3lzL2tlcm5lbC9tc21fcGVyZm9ybWFuY2UvcGFyYW1ldGVycy9jcHVfbWF4X2ZyZXEKICAgIGxvY2tfdmFsICIyMDE2MDAwIiAvc3lzL2RldmljZXMvc3lzdGVtL2NwdS9jcHVmcmVxL3BvbGljeTAvc2NhbGluZ19tYXhfZnJlcQp9CgpzdG9wX3NlcnZpY2VzKCkgewogICAgc3RvcCBhZWUubG9nLTEtMQogICAgc3RvcCBjaGFyZ2VfbG9nZ2VyCiAgICBzdG9wIGNvbm5zeXNsb2dnZXIKICAgIHN0b3AgZW1kbG9nZ2VyCiAgICBzdG9wIG1jZF9zZXJ2aWNlCiAgICBzdG9wIG1kbnNkCiAgICBzdG9wIG1pX2ljCiAgICBzdG9wIG1pX3JpY19maWxlCiAgICBzdG9wIG1pX3JpY19pbml0CiAgICBzdG9wIG1pX3JpY19ydW4KICAgIHN0b3AgbWltZC1zZXJ2aWNlCiAgICBzdG9wIG1pbmV0ZAogICAgc3RvcCBtaXVpYm9vc3RlcgogICAgc3RvcCBtb2JpbGVfbG9nX2QKICAgIHN0b3Agb3BsdXNfa2V2ZW50cwogICAgc3RvcCB2ZW5kb3IueGlhb21pLmhpZGwubWluZXQKICAgIHN0b3AgdmVuZG9yLnhpYW9taS5oaWRsLm1pd2lsbAogICAgc3RvcCB2ZW5kb3JfdGNwZHVtcAogICAgc3RvcCBwb3dlci1oYWwtMS0wICYmIHN0YXJ0IHBvd2VyLWhhbC0xLTAKICAgIAogICAgaWYgWyAiJChnZXRwcm9wIHJvLmhhcmR3YXJlKSIgIT0gInFjb20iIF07IHRoZW4KICAgICAgICBzdG9wIG1pX3RoZXJtYWxkCiAgICAgICAgc3RvcCB2ZW5kb3IubWlwZXJmCiAgICBmaQp9Cgp3YWl0X3VudGlsX2xvZ2luCmluaXRfenJhbQppbml0X25vZGUKc3RvcF9zZXJ2aWNlcwoKc2V0ZW5mb3JjZSAwCmRldmljZV9jb25maWcgcHV0IGFjdGl2aXR5X21hbmFnZXIgbWF4X2NhY2hlZF9wcm9jZXNzZXMgMjE0NzQ4MzY0NwpkZXZpY2VfY29uZmlnIHB1dCBhY3Rpdml0eV9tYW5hZ2VyIG1heF9waGFudG9tX3Byb2Nlc3NlcyAyMTQ3NDgzNjQ3CnBtIHVuaW5zdGFsbCAtLXVzZXIgMCBjb20ueGlhb21pLk5ldHdvcmtCb29zdApzZXRlbmZvcmNlIDEK' | base64 -d > '/data/adb/modules/pandora_kernel/service.sh'
    }
  export ENVDIR='/sdcard/Android/_CBLG/Zram_Control_Center/配置文件.MD'
  [[ -f "${ENVDIR}" ]] || echo '#!/bin/sh

export SIZE='2048'
#每个Zram设备块的大小(MiB)，不填默认2048MiB

export NUM='6'
#Zram设备块个数，不填默认6个

export NAME='_CBLG'
#每个Zram设备块名称，不填默认随机六字符，Zram名称为从1叠加

export LEVEL='66'
#每个Zram优先级，不影响使用，不填默认66

export METHOD='zstd'
#Zram压缩方法，不填默认为zstd，内核支持建议使用zstd，更改失败后会尝试更改为lz4

export HNAME='_CBLG'
#存放所有Zram设备块的文件夹名称，不填默认随机六字符

export SWAP='199'
#Swap活跃性，大多数为0-200之间，不填默认199' > "${ENVDIR}"
  unzip -oj "$ZIPFILE" "main/framework/zram_driver" -d "${MHOME}/${MODID}/framework" 1>&2
  chmod 777 "${MHOME}/${MODID}/framework/zram_driver"
  "${MHOME}/${MODID}/framework/zram_driver"
  
  end_time="$(date +%s)"
  
  ui_print "   —— 模块安装完毕，耗时：$(expr ${end_time} - ${start_time})秒"
  
}

function set_permissions() {
  
  true
  
  set_perm_recursive "${MODPATH}" 0 0 0777 0666
  
  return 256
  
}