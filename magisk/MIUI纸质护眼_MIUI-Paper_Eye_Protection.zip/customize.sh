SKIPMOUNT=false

 device="`getprop ro.product.device`"
 MIUI="`getprop ro.miui.ui.version.name`"
 Version="`getprop ro.build.version.incremental`"
 Android="`getprop ro.build.version.release`"
 Sdk="`getprop ro.build.version.sdk`"
 ui_print "#######################"
 ui_print "- 模块: $MODNAME"
 ui_print "- 模块ID: $MODID"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 介绍: $MODdescription"
 ui_print "#######################"
 ui_print "-# 设备相关信息 #-"
 ui_print "- SDK: $Sdk"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- MIUI版本: $MIUI  $Version"
 ui_print "#######################"
 ui_print " "


rm -rf /data/system/package_cache/*
cp -rf /system/vendor/etc/device_features/* $MODPATH/system/vendor/etc/device_features
cp -rf /system/etc/device_features/* $MODPATH/system/etc/device_features

# 纸质护眼代码 提取自小米10 MIUI12.5
sed -i '/<\/features>/i\    <!-- 是否支持纸张模式动画 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 是否支持纸张模式动画 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 是否支持智能护眼 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 是否支持智能护眼 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 是否支持纸质护眼 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 是否支持纸质护眼 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 纸张护眼的默认颜色温度 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 纸张护眼的默认颜色温度 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 纸张护眼的默认纹理 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 纸张护眼的默认纹理 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 纸质护眼的纹理最小值 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 纸质护眼的纹理最小值 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/etc/device_features/*

sed -i '/<\/features>/i\    <!-- 纸质护眼的最大纹理值 -->' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <!-- 纸质护眼的最大纹理值 -->' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/etc/device_features/*


set_perm_recursive  $MODPATH  0  0  0755  0644
