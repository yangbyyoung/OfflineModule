#!/system/bin/sh
rm /data/media/0/Android/ASGuard.config
rm /data/media/0/Android/ASGuard.config.bak
rm /data/media/0/Android/log_ASG.txt
exit 0