#!/system/bin/sh
echo Y > /sys/module/lpm_levels/parameters/sleep_disabled
echo 8 > /sys/block/zram0/max_comp_streams
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all 2> /dev/null
echo 1 > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses 2> /dev/null
echo 1 > /proc/sys/net/ipv4/tcp_timestamps 2> /dev/null
echo 3 > /proc/sys/vm/drop_caches
rm -rf /data/data/com.miui.powerkeeper/databases/*
rm -rf /data/data/com.miui.powerkeeper/databases/user_configure.db
touch /data/data/com.miui.powerkeeper/databases/user_configure.db
echo 8 > /sys/block/zram0/max_comp_streams