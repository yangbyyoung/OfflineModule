am start -a 'android.intent.action.VIEW' -d 'https://github.com/SetoSkins/SetoSkins_Thermal/releases' >/dev/null 2>&1
