#!//bin/env sh
Module_Path="/data/adb/modules"

KernelSu() {
	[ -f "/data/adb/ksud" ] && {
		S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')
		[ "$S" = "v0.3" ] && Module_Path="/data/adb/ksu/modules"
	}

}
KernelSu
# 设置Printx_thermal路径
Rubbish_Path="$Module_Path/Printx_Rubbish"

PrintX_conf="/data/media/0/Android/PrintX/清理垃圾/配置文件.conf"
[ ! -f $PrintX_conf ] && {
    mkdir -p "/data/media/0/Android/PrintX/清理垃圾"
    echo "####################
####################
####################
# Author:作者:& 酷安@只喝橘子味汽水
# WeChat: Suonian-XingHe       
# QQ: 699459180          
# 原作者Github:https://github.com/ManjusakaY
####################
####################
####################
#以下选项.开启填入：true，关闭填入：false

# 是否启用空文件夹扫描检查 
# 默认开启
PrintX_A=true

# 检查的目录
# 默认为/data/media/0
PrintX_B=/data/media/0

# 是否检查子目录
# 默认关闭
PrintX_C=false
# 开启后将则将递归检查该目录下的所有子目录
# 关闭后则只检查该目录

# 是否启用黑名单检查
# 默认开启
PrintX_Blacklist_check=true
" > $PrintX_conf
    exit 255
} || source $PrintX_conf

PrintX_Times="/data/media/0/Android/PrintX/清理垃圾/Times"
if [ -f "$PrintX_Times" ]; then
    source "$PrintX_Times"
fi

# 初始化计数器
DIR=${DIR:-0}
FILE=${FILE:-0}

PrintX_D () {
    for dir in "$1"/*; do
        [ -d "$dir" ] && {
            [ "$(command ls -A "$dir")" ] || {
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除空文件夹: $dir" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
                command rmdir "$dir"
                let DIR++
            }
            [ "${PrintX_C}" = true ] && PrintX_D "$dir"
        }
    done
}

PrintX_Blacklist () {
    [ ! -f /data/media/0/Android/PrintX/清理垃圾/黑名单.conf ] && {
        mkdir -p /data/media/0/Android/PrintX/清理垃圾
        echo "
#文件夹结尾加/，不加/代表文件
/sdcard/Android/PrintX/PrintX_Blacklist.conf
/sdcard/Android/PrintX/Clear.log
/sdcard/fvlog.txt
/sdcard/Alarms/
/sdcard/Audiobooks/
/sdcard/com.tencent.mobileqq/
/sdcard/com.quark.browser/
/sdcard/iApp/
/sdcard/libs/
/sdcard/mfcache/
/sdcard/mipush/
/sdcard/Notifications/
/sdcard/OSSLog/
/sdcard/qqstory/
/sdcard/qsvf/
/sdcard/Ringtones/
/sdcard/tbs/
/sdcard/Recordings/
/sdcard/Podcasts/
/data/media/0/Android/PrintX/清理垃圾/黑名单.conf.bak
/data/media/0/Android/PrintX/清理垃圾/白名单.conf.bak
/data/adb/modules/Printx_Rubbish/service.sh.bak
/data/media/0/com.*
/data/media/0/.*
/data/media/0/DCIM/.*
#
#—————————-————————分割线————————————————
#
#应用类：
#酷安
/data/data/com.coolapk.market/cache/*
/data/data/com.coolapk.market/files/pangle_p/*
/data/data/com.coolapk.market/app_tt_pangle_bykv_file/pangle_com.byted.pangle.m
#酷狗
/data/media/0/aliUnion_apk/
/data/media/0/com.kugou.android_KcSdk/
/data/media/0/kugou_down_c/
/data/media/0/storage/
/data/media/0/kugou/
#/data/media/0/kgmusic/
#知乎缓存
/data/media/0/zhihu/
/data/media/0/ramfs_ext/
#夸克浏览器缓存
/data/media/0/com.quark.browser/
/data/media/0/ttscache/
#酷我音乐相关
/data/media/0/libs/
#小米游戏中心相关目录
/data/media/0/Xiaomi/
/data/media/0/migamecenter/
#网易云相关
/data/media/0/com.netease.cloudmusic/
#天翼云盘相关
/data/media/0/com.cn21.yj/
#QQ浏览器解压文件目录
/data/media/0/MasterArchive/
#软件运行产生的临时文件夹
/data/media/0/Catfish/
#浏览器产生的临时文件和缓存目录
/data/media/0/browser/
#讯飞输入法临时缓存目录
/data/media/0/iFlyIME/
#有道词典临时缓存目录和相关目录
/data/media/0/Youdao/
/data/media/0/netease_pushservice/
#酷狗相关
/data/media/0/kgmusic.ver
#天翼云盘相关
/data/media/0/*_*_log.txt
#抖音垃圾缓存
/data/user/0/com.ss.android.ugc.aweme/files/webview_bytedance
/data/user/0/com.ss.android.ugc.aweme/files/offlineX
/data/user/0/com.ss.android.ugc.aweme/files/luckycat_gecko_root_dir
/data/user/0/com.ss.android.ugc.aweme/files/client_ai
/data/user/0/com.ss.android.ugc.aweme/lib
/data/user/0/com.ss.android.ugc.aweme/cache
/data/media/0/Android/data/com.ss.android.ugc.aweme/cache
/data/user/0/com.ss.android.ugc.aweme/app_assets
/data/user/0/com.ss.android.ugc.aweme/files/plugins
/data/user/0/com.ss.android.ugc.aweme/databases
/data/user/0/com.ss.android.ugc.aweme/files/effect
#快手垃圾缓存
/data/user/0/com.smile.gifmaker/files/ks_webview
/data/user/0/com.smile.gifmaker/app_DvaPlugin/kswebview_so_group/1426545077
/data/user/0/com.smile.gifmaker/app_DvaPlugin/ykit_module/*
#哔哩哔哩垃圾缓存
/data/user/0/tv.danmaku.bili/app_mod_resource
/data/data/tv.danmaku.bili/cache
#
#——————————————————分割线——————————————————
#
#——————————————《  微信  》——————————————
#视频缓存
/data/media/0/Android/data/com.tencent.mm/cache
/data/media/0/Android/data/com.tencent.mm/MicroMsg/.tmp/
/data/media/0/Android/data/com.tencent.mm/MicroMsg/Cache
/data/media/0/Android/data/com.tencent.mm/MicroMsg/wxacache/
/data/data/com.tencent.mm/cache/
#无用重复组网插件
/data/data/com.tencent.mm/MicroMsg/webservice/codecache/
/data/data/com.tencent.mm/MicroMsg/mmslot/webcached/
#X5内核缓存
#腾讯地图SDK日志
/data/data/com.tencent.mm/files/tencentMapSdk/logos/
##/data/data/com.tencent.mm/files/host/
#直播
/data/data/com.tencent.mm/files/public/live/
/data/data/com.tencent.mm/files/public/fts/
/data/data/com.tencent.mm/files/public/OCR
/data/data/com.tencent.mm/files/public/cityService/
/data/data/com.tencent.mm/files/public/box/
/data/data/com.tencent.mm/files/public/CheckResUpdate/
#临时文件
/data/data/com.tencent.mm/MicroMsg/tmp/
#未知web相关文件(占用特别大)
/data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
#广告js
/data/data/com.tencent.mm/MicroMsg/webcompt/wxAd/
#
#——————————————《  QQ  》——————————————
#
/sdcard/Tencent/cache
/sdcard/Tencent/MobileQQ/diskcache/
/sdcard/Tencent/MobileQQ/Scribble/
/sdcard/Tencent/MobileQQ/ScribbleCache/
#缓存...
#其他
/sdcard/Tencent/MobileQQ/qav/
/sdcard/Tencent/MobileQQ/qqmusic/
/sdcard/Tencent/MobileQQ/pddata/
/data/media/0/tencent/QQGallery/log/
#图片缓存
/sdcard/Tencent/MobileQQ/photo/
/sdcard/Tencent/MobileQQ/chatpic/
/sdcard/Tencent/MobileQQ/thumb/
/sdcard/Tencent/MobileQQ/QQ_Images/
/sdcard/Tencent/MobileQQ/QQEditPic
/sdcard/Tencent/MobileQQ/hotpic/
#图片缓存....
#短视频
/sdcard/Tencent/MobileQQ/shortvideo
#短视频缓存...
#广告
/sdcard/Tencent/MobileQQ/qbosssplahAD
/sdcard/Tencent/MobileQQ/pddata
#广告缓存...
#diy名片
/sdcard/Tencent/MobileQQ/.apollo/
/sdcard/Tencent/MobileQQ/vas
/sdcard/Tencent/MobileQQ/lottie/
#个性名片清理...
#Tencent目录下
#小程序
/sdcard/Tencent/mini
/sdcard/Tencent/TMAssistantSDK
#小程序缓存...
#字体
/sdcard/Tencent/.font_info
/sdcard/Tencent/.hiboom_font
#字体缓存....
#礼物
/sdcard/Tencent/.gift
#礼物缓存...
#进场特效
/sdcard/Tencent/.trooprm/enter_effects
#进场特效....
#头像
/sdcard/Tencent/tbs
#tbs插件...
#挂件
/sdcard/Tencent/.pendant
#挂件和背景....
#背景
/sdcard/Tencent/.profilecard
#表情推荐
#表情推荐缓存...
/sdcard/Tencent/.sticker_recommended_pics
/sdcard/Tencent/pe
#聊天表情缓存
/sdcard/Tencent/.emotionsm
/sdcard/Tencent/msflogs/
#聊天缓存...
#戳一戳
/sdcard/Tencent/.vaspoke
/sdcard/Tencent/newpoke
/sdcard/Tencent/poke
#斗图
/sdcard/Tencent/DoutuRes
#视频通话背景
/sdcard/Tencent/funcall
#接收的文件缓存
#接受的文件缓存...(非文件本身)
/sdcard/Tencent/QQfile_recv/.trooptmp
/sdcard/Tencent/QQfile_recv/.tmp
/sdcard/Tencent/QQfile_recv/.thumbnails
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/diskcache
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/Scribble
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/ScribbleCache
#缓存
/data/media/0/Android/data/com.tencent.mobileqq/cache
#图片缓存
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/photo
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/chatpic
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/thumb
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/QQ_Images
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/QQEditPic
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/hotpic
#QQ空间相关
#QQ空间缓存清理....
#压缩文件缓存
/data/media/0/Android/data/com.tencent.mobileqq/qzone/zip_cache
#空间视频缓存
/data/media/0/Android/data/com.tencent.mobileqq/qzone/video_cache
#空间垃圾图片
/data/media/0/Android/data/com.tencent.mobileqq/qzone/imageV2
#空间直播
/data/media/0/Android/data/com.tencent.mobileqq/qzlive/
#短视频
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/shortvideo
#广告
#日志广告小视频...
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/qbosssplahAD
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/pddata
#diy名片
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.apollo
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/vasrm
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/lottie
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/QQ_Images/QQEditPic/
#编辑缓存和日志
#Tencent目录下
#字体
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.font_info
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.hiboom_font
#礼物
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/.gift
#进场特效
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.trooprm/enter_effects
#挂件
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.pendant
#背景
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.profilecard
#表情推荐
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.sticker_recommended_pics
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/pe
#聊天表情缓存
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.emotionsm
#戳一戳
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.vaspoke
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/newpoke
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/poke
#vip图标
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/.vipicon
#斗图
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/DoutuRes
#视频通话背景
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/funcall
#接收的文件缓存
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.trooptmp
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.tmp
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.thumbnails
#未知垃圾下载
/data/media/0/Android/data/com.tencent.mobileqq/qcircle
/data/media/0/Android/data/com.tencent.mobileqq/files/.info
#厘米秀
/data/media/0/Android/data/com.tencent.mobileqq/files/ae/playshow
#小米合作有关广告日志
/data/media/0/tencent/wtlogin
/data/media/0/tencent/QQmail/qmlog
#QQ相机捕获的照片
/sdcard/Android/data/com.tencent.mobileqq/files/tbslog/*txt
#tabLog
/sdcard/Android/data/com.tencent.mobileqq/files/tencent/tbs_live_log
#tab_log
/sdcard/Android/data/com.tencent.mobileqq/files/tencent/tbs_common_log
#在QQ编辑的临时图
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/TMAssistantSDK/Download/com.tencent.mobileqq
#TM助理SDK
/data/media/0/Android/data/com.tencent.mobileqq/Tencent/mini/files/
/data/media/0/Tencent/blob/mqq
#ams缓存
/data/media/0/Tencent/ams/cache
#IMSDK缓存
/data/media/0/Tencent/imsdkvideocache
#节日祝福相关资源缓存
/data/media/0/Tencent/MobileQQ/bless
#/dada目录下
#hippy框架代码缓存(QQ浏览器相关)
/data/data/com.tencent.mobileqq/files/hippy/codecache/
" > /data/media/0/Android/PrintX/清理垃圾/黑名单.conf
    }
    PrintX_Blacklist_PATH="/data/media/0/Android/PrintX/清理垃圾/黑名单.conf"
    local IFS=$'\n'
    qiule=""
    for bl in $(cat $PrintX_Blacklist_PATH | grep -v '#'); do
        qiule="$qiule"$'\n'"$bl"
    done
    PrintX_whilelist_PATH="/data/media/0/Android/PrintX/清理垃圾/白名单.conf"
    [ ! -f "${PrintX_whilelist_PATH}" ] && {
    echo "#白名单列表
#白名单，勿删！勿删！勿删！删了一切后果自负！
/data/
/data/*/
/data/adb/*
/data/adb/*/*
/data/media/0/
/data/media/0/Download/
/data/media/0/Android/
/data/media/0/Android/data/
/data/media/0/Android/media/
/data/media/0/Android/obb/
/data/media/0/DCIM/
/data/media/0/MIUI/
/data/media/0/Movies/
/data/media/0/Music/
/data/media/0/Pictures/
/storage/
/data/media/0/
/data/media/0/Download/
/data/media/0/Android/
/data/media/0/Android/data/
/data/media/0/Android/media/
/data/media/0/Android/obb/
/data/media/0/DCIM/
/data/media/0/MIUI/
/data/media/0/Movies/
/data/media/0/Music/
/data/media/0/Pictures/
/sdcard/
/sdcard/Download/
/sdcard/Android/
/sdcard/Android/data/
/sdcard/Android/media/
/sdcard/Android/obb/
/sdcard/DCIM/
/sdcard/MIUI/
/sdcard/Movies/
/sdcard/Music/
/sdcard/Pictures/
" > /data/media/0/Android/PrintX/清理垃圾/白名单.conf
}
    IFS=$'\n'
    printxxx=""
    for wt in $(cat $PrintX_whilelist_PATH | grep -v '#'); do
        printxxx="$printxxx"$'\n'"$wt"
    done

    function PrintX_direc() {
        local path=$1
        [[ -d "$path" ]] && {
            case $path in
                *'/.') continue ;;
                *'/./') continue ;;
                *'/..') continue ;;
                *'/../') continue ;;
            esac
            rm -rf "$path" && {
                let DIR++
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除文件夹 $path" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
            }
        }
        [[ -f "$path" ]] && {
            rm -rf "$path" && {
                let FILE++
                echo "$(date +"%Y-%m-%d %H:%M:%S") 删除文件 $path" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log
            }
        }
    }
    white_list=()
    for wt in $(echo "$printxxx" | grep -v '*'); do
        white_list+=("$wt")
    done

    for PrintX_item in $(echo "$qiule" | grep -v '*'); do
        PrintX_skip=false
        for PrintX_WM in "${white_list[@]}"; do
            [[ "$PrintX_item" == "$PrintX_WM" ]] && {
                PrintX_skip=true
                break
            }
        done
        [[ "$PrintX_skip" = true ]] && echo "$(date +"%Y-%m-%d %H:%M:%S") 已跳过: $PrintX_item" >> /data/media/0/Android/PrintX/清理垃圾/Clear.log && continue

        PrintX_direc "$PrintX_item"
    done
}

[ "${PrintX_Blacklist_check}" = true ] && PrintX_Blacklist

[ "${PrintX_A}" = true ] && PrintX_D "$PrintX_B"

chmod -R 755 "/data/media/0/Android/PrintX/清理垃圾"
source "$PrintX_Times"
echo "DIRS=$((DIRS+DIR))" > "$PrintX_Times"
echo "FILES=$((FILES+FILE))" >> "$PrintX_Times"
sed -i "/^description=/c description=🌟已累计清理: $DIRS个文件夹 | $FILES个文件 " "$Rubbish_Path/module.prop"