echo "
————————————————————🍂🍃🍂🍃
"
echo "
●————————④检测智商的模块————————●
"
echo "－下面进行智商检测模块的排除"
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
if [[ "${author:7}" = "JK小姐姐" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－这玩意是娱乐模块，除了心里作用，没有实际功效"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
touch $module_id/remove
fi
if [[ "$module_id" = "MagicPower" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－这玩意是娱乐模块，除了心里作用，没有实际功效"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
touch $module_id/remove
fi
done
echo "
————————————————————🍂🍃🍂🍃
"
echo ""
echo ""

