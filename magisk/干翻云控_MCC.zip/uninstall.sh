#!/system/bin/sh
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
pm enable com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.analysis.SettingUploadJobService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
pm enable com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
#手机管家
pm enable com.miui.securitycenter/com.miui.permcenter.root.RootUpdateReceiver
pm enable com.miui.securitycenter/com.miui.antivirus.receiver.UpdaterReceiver
#joyose
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
pm enable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
pm enable com.xiaomi.joyose/predownload.PreDownloadJobScheduler
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
pm enable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
#耗电检测
pm enable com.xiaomi.powerchecker/com.xiaomi.powerchecker.cloudcontrol.CloudUpdateJobService
pm enable com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
#MIUI质量服务
pm enable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm enable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm enable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
pm enable com.miui.securitycenter/com.miui.apppredict.service.AiService
pm enable com.miui.securitycenter/com.miui.apppredict.service.AppPredictService
pm enable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm enable com.miui.securitycenter/com.miui.apppredict.service.AppPredictService
pm enable com.miui.securitycenter/com.miui.apppredict.service.AiService
pm enable com.miui.powercenter/powersaver.PerformanceModeTileService
pm enable com.miui.gamebooster/beauty.BeautyService
pm enable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm enable com.miui.powercenter/powersaver.PerformanceModeTileService
pm enable com.miui.hybrid.settings/platform.PerformanceOptimizationActivity

pm install com.xiaomi.NetworkBoost
pm install com.miui.daemon
pm clear com.xiaomi.joyose
#清除数据joyose
pm clear com.xiaomi.powerchecker
#清除数据耗电检测

rm -f /data/vendor/thermal/config/*