#!/system/bin/sh
# 将此脚本放到/data/adb/service.d
sleep 60s
miuiappcut_path=$(find /data/adb/modules -type f -iname cutapp.sh 2>/dev/null)
su -c "sh $miuiappcut_path"
rm -rf $0