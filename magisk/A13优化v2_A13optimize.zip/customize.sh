# This is customize the module installation process if you need
SKIPMOUNT=false
#这意味着模块不会自动挂载系统分区。
PROPFILE=false
#这意味着模块不会自动修改系统的build.prop文件。
POSTFSDATA=false
#这意味着在挂载数据分区后，模块将不会执行任何脚本。
LATESTARTSERVICE=true
#这意味着模块将在Android系统完成启动后执行脚本。


#下面为Magisk模块刷入时打印的内容
  ui_print "Module installation is complete."
  ui_print "************************************"
  ui_print "             A13优化v2 "
  ui_print "               酷安@Memoryゅ "
  ui_print "感谢你使用这个模块"
  ui_print "************************************"
  ui_print "- Cleaning radio cache..."
  ui_print "- Execution complete!"

#REPLACE 变量用于指定模块应替换哪些系统文件或目录。
#REPLACE 的值应该是文件或目录路径的列表。
REPLACE="
/system/build.prop
"

#模块主逻辑
while read line
do
if [[ "$line" != "debug.sf.latch_unsignaled"* && "$line" != "debug.sf.auto_latch_unsignaled"* ]]
then
   echo $line >>/data/adb/modules_update/A13optimize/system/build.prop
fi
done < /system/build.prop
echo debug.sf.latch_unsignaled=0 >>/data/adb/modules_update/A13optimize/system/build.prop
echo debug.sf.auto_latch_unsignaled=1 >>/data/adb/modules_update/A13optimize/system/build.prop

#此行将 $MODPATH/system/app/UPTsmService 目录及其所有子目录和文件的所有者和组设置为 0（根）。
#它还将目录的权限设置为 0755（所有者的读取、写入和执行;组和其他人的读取和执行），
#将文件的权限设置为 0644（所有者的读取和写入;组和其他人的只读）。
#u:object_r:vendor_file:s0部分将文件和目录的SELinux上下文设置为vendor_file。
#set_perm_recursive $MODPATH 0 0 0755 0644 u:object_r:vendor_file:s0此行与上一行执行的操作相同，但针对$MODPATH目录本身。
  set_permissions() {
  set_perm_recursive $MODPATH/system/app/Mipay 0 0 0755 0644 u:object_r:vendor_file:s0
  set_perm_recursive $MODPATH/system/app/MiuiSuperMarket 0 0 0755 0644 u:object_r:vendor_file:s0
  set_perm_recursive $MODPATH/system/app/TSMClient 0 0 0755 0644 u:object_r:vendor_file:s0
  set_perm_recursive $MODPATH/system/app/UPTsmService 0 0 0755 0644 u:object_r:vendor_file:s0
  set_perm_recursive $MODPATH 0 0 0755 0644 u:object_r:vendor_file:s0
}
