# tailscale4magisk
编译 Tailscale 以便在 Magisk 中使用系统级的 Tailscale
