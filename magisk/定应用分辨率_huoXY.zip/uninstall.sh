rm -rf /data/adb/modules/huoXY
