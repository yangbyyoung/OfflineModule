SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
 require_check_app

}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}

require_check_app() {
  ui_print "*******************************"

  tmppackage=$(dumpsys package com.byyoung.setting | grep version)
  if [ "$tmppackage" = "" ]; then
    ui_print "您还没有安装了爱玩机工具箱，正在跳转链接下载"
    am start -a android.intent.action.VIEW -d https://www.coolapk.com/apk/com.byyoung.setting
  else
    ui_print "您已经安装了爱玩机工具箱，尽情享受吧"
  fi
  ui_print "*******************************"
  ui_print "刷入模块完成，欢迎使用V19.0"

}
