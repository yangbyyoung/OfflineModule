#!/system/bin/sh
EvoMem=${0%/*}
rm -rf /cache/EvoMem.log
log() {
    log_file="/cache/EvoMem.log"
    touch /cache/EvoMem.log
    echo "[$(date | awk '{print $4}')] $@" >>"$log_file"
}
log "模块运行："
. $EvoMem/EvoMem