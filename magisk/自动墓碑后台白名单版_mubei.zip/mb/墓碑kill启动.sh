#!/system/bin/sh
MODDIR=${0%/*}

 sd=/data/media/0/Android/墓碑日志.log
JB="mb.sh"
JB1="mb1.sh"
JB2="mb2.sh"
JB_ID=$(pgrep -f "$JB")
JB1_ID=$(pgrep -f "$JB1")
JB2_ID=$(pgrep -f "$JB2")

if [ "$JB_ID" != "" ]; then
    kill -KILL $JB_ID
fi
  
if [ "$JB1_ID" != "" ]; then
    kill -KILL $JB1_ID
fi
if [ "$JB2_ID" != "" ]; then
    kill -KILL $JB2_ID
fi
  
  
	nohup $MODDIR/mb.sh > /dev/null 2>&1 &
    mb_id="$(pgrep 'mb.sh' | wc -l)"
    mb1_id="$(pgrep 'mb1.sh' | wc -l)"
    mb2_id="$(pgrep 'mb2.sh' | wc -l)"	
	
	if [ "$mb.sh_id" != "0" ]; then
	sed -i 's/\[.*\]/\[ 模式：Kill 19 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	sed -i 's/墓碑.*启动.sh/墓碑kill启动.sh/g' "/data/adb/modules/mubei/service.sh" >/dev/null 2>&1
    echo "$(date '+%T') 已经切换到Kill19模式" >>$sd 
    exit 0
	else
	sed -i 's/\[.*\]/\[ Kill 19 启动失败 \]/g' "/data/adb/modules/mubei/module.prop" >/dev/null 2>&1
	exit 0
fi