MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

source ${0%/*}/path.sh
L="$Backup_path2"

test ! -e $L && echo "不存在文件$L" && exit 1

MOD=`tar -tf $L|cut -f2 -d "/"|uniq|grep -v "[a-zA-Z].db"|grep -v "[a-zA-Z].sh"|sed '/^[[:space:]]*$/d'`
grep_prop(){
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

for i in $MOD;do
Bak=`tar -xvf $L modules/$i/module.prop 2>/dev/null`
done
N=1

for o in $(ls ${Backup_path2%/*}/modules);do
		name=$(grep_prop 'name' ${Backup_path2%/*}/modules/$o/module.prop )
		version=$(grep_prop 'version' ${Backup_path2%/*}/modules/$o/module.prop )
		description=$(grep_prop 'description' ${Backup_path2%/*}/modules/$o/module.prop )
		author=$(grep_prop 'author' ${Backup_path2%/*}/modules/$o/module.prop )
		echo ""
		echo "∞————————————【 $N 】————————————∞"
		echo "备份模块名称: $name "
		echo "作者: $author"
		echo "版本: $version"
		echo "描述: $description"
		echo "∞————————————————————————∞"
		echo ""
		N=$( expr $N + 1)
done
rm -rf ${Backup_path2%/*}/modules