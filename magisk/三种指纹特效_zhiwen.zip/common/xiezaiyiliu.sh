if [ -d "/data/adb/modules/zhiwentexiao_xpheisha2" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xpheisha2
fi
if [ -d "/data/adb/modules/zhiwentexiao_xpiqoo" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xpiqoo
fi
if [ -d "/data/adb/modules/zhiwentexiao_xpopporeno" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xpopporeno
fi
if [ -d "/data/adb/modules/zhiwentexiao_xpvivo" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xpvivo
fi
if [ -d "/data/adb/modules/zhiwentexiao_xpyijia" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xpyijia
fi
if [ -d "/data/adb/modules/zhiwentexiao_xgheisha2" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xgheisha2
fi
if [ -d "/data/adb/modules/zhiwentexiao_xgopporeno" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xgopporeno
fi
if [ -d "/data/adb/modules/zhiwentexiao_xgvivo" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xgvivo
fi
if [ -d "/data/adb/modules/zhiwentexiao_xgyijia" ];then
  rm -rf /data/adb/modules/zhiwentexiao_xgyijia
fi
if [ -d "/data/adb/modules/zhiwentexiao_lgcoloros" ];then
  rm -rf /data/adb/modules/zhiwentexiao_lgcoloros
fi
if [ -d "/data/adb/modules/zhiwentexiao_lgjg" ];then
  rm -rf /data/adb/modules/zhiwentexiao_lgjg
fi
if [ -d "/data/adb/modules/zhiwentexiao_lgopporeno" ];then
  rm -rf /data/adb/modules/zhiwentexiao_lgopporeno
fi
if [ -d "/data/adb/modules/zhiwentexiao_lgyijia" ];then
  rm -rf /data/adb/modules/zhiwentexiao_lgyijia
fi
if [ -d "/data/adb/modules/zhiwentexiao_ndheisha2" ];then
  rm -rf /data/adb/modules/zhiwentexiao_ndheisha2
fi
if [ -d "/data/adb/modules/zhiwentexiao_ndvivo" ];then
  rm -rf /data/adb/modules/zhiwentexiao_ndvivo
fi
if [ -d "/data/adb/modules/zhiwentexiao_ndyijia" ];then
  rm -rf /data/adb/modules/zhiwentexiao_ndyijia
fi
if [ -d "/data/adb/modules/zhiwentexiao_mccoloros" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mccoloros
fi
if [ -d "/data/adb/modules/zhiwentexiao_mcheisha2" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mcheisha2
fi
if [ -d "/data/adb/modules/zhiwentexiao_mcopporeno" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mcopporeno
fi
if [ -d "/data/adb/modules/zhiwentexiao_mcvivo1" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mcvivo1
fi
if [ -d "/data/adb/modules/zhiwentexiao_mcvivo2" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mcvivo2
fi
if [ -d "/data/adb/modules/zhiwentexiao_mcyijia" ];then
  rm -rf /data/adb/modules/zhiwentexiao_mcyijia
fi
  echo "$zhiwen" >> $TMPDIR/module.prop