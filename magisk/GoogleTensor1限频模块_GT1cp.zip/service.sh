#!/system/bin/sh
MODDIR=${0%/*}

sleep 8
sh $MODDIR/cu.sh
echo "
sleep 1
sh /data/adb/modules/GT1cp/cu.sh
" > /data/cron.d/crn.sh
#创建并写入定时任务
echo "*/1 * * * * /data/cron.d/crn.sh" > /data/cron.d/root
chmod 777 -R /data/cron.d/root
chmod 777 -R /data/cron.d/crn.sh
echo /data/cron.d/crn.sh"
" > /data/crn.sh
crond -c /data/cron.d
#by NewtoPhone