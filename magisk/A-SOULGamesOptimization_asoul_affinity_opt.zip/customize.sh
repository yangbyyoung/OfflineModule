CFG_PATH="/sdcard/Android/naki/asopt/asopt.conf"

echo
echo "- 安装此模块前卸载CuToolbox，你不卸载我帮你卸载"
echo
echo "- 配置文件位于 $CFG_PATH"
echo "- 日志系统已移除"
echo

if [ -d /data/adb/modules/unity_affinity_opt ]; then
    mv /data/adb/modules/unity_affinity_opt /data/adb/modules/asoul_affinity_opt
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/AsoulOpt 0 0 0755 0755

note="# preempt：防抢占优化
# 0：关闭
# 1：只允许非游戏线程使用不重要的核心
# 若遇到了一些奇怪的问题
# 可尝试调为0，但会降低游戏性能
"

preempt=$(grep preempt= $CFG_PATH)

if [[ -z $preempt ]]; then
    preempt=$(grep preempt= /data/asopt.conf)
fi

if [[ -z $preempt ]]; then
    preempt=$(grep preempt= /sdcard/Android/asopt/asopt.conf)
fi

if [[ -z $preempt ]]; then
    preempt="preempt=1"
fi

rm -rf /data/adb/asopt
rm -rf /sdcard/Android/asopt
rm /data/asopt.conf
rm /sdcard/Android/naki/asopt/asopt.log

mkdir -p /sdcard/Android/naki/asopt
echo "$note" > $CFG_PATH
echo "$preempt" >> $CFG_PATH
