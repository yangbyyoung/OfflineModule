# uninstall running
# 移除叠加层缓存，如果您不清楚请别擅自修改，没正常移除和其他冲突可能会出现卡第二屏现象
# 为什么要卸载鲨鲨酱，是不是爱上别的女人了！！(#｀д´)
remove_cache()
{
    local target_file
    local target_path="$1"
    for target_file in $(find $target_path -type f -iname '*bscharge*') ; do
        rm -f $target_file
    done
}

drc="/data/resource-cache"
dpc="/data/system/package_cache"
remove_cache $drc
remove_cache $dpc
