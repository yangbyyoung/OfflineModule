# Most mods would like it to be enable
SKIPMOUNT=false
#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用

# Set to true if you need to load system.prop
PROPFILE=false
#是否使用common/system.prop文件

# Set to true if you need post-fs-data script
POSTFSDATA=true
#是否使用post-fs-data脚本执行文件

# Set to true if you need late_start service script
LATESTARTSERVICE=true
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
	ui_print "*******************************"
	ui_print "     自动墓碑后台APP模块    "
	ui_print "      作者：l奋斗的小青年     "
	ui_print " 非常感谢@火柴 大佬的鼎力相助 ! "
	ui_print "   公众号：有效玩机  首发~！ "	
	ui_print "*******************************
	23.04.05号更新内容：	
	- 放宽一点millet屏蔽，修改开机启动。
	- c++版增加v1，v2模式。
	- 该版无微信，QQ推送功能，请自行添加白名单。
	- 添加白名单后，无需重启墓碑脚本。
	- 首次刷入后，请打开一次墓碑APP，再重启手机。
	
	- 添加日志的时间前缀。
	- 前台APP由while循环检测改为按需检测。
	- 修复白名单缓存未回收bug。
	- 解决待机高功耗。
	
	23.02.15号内容：
	- 解决部分网友手机无日志问题。
	- 自动识别小窗，音频状态的APP不会被墓碑。
	- 支持墓碑功能。比beta1版强劲。
	- 采用c++重构代码，效率提升50%以上。
	- 适配软件客户端软件来自大佬@离音。
	- 兼容Android10、到Android13+。
	- 独立运行不依赖系统组件。
	- APP离开前台后立即进入墓碑模式。不耗电，不占用CPU，只占运存。
		bug：
	- 更新白名单后需要手动执行重启墓碑才能生效新到白名单。

	";
	ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"


##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
	ui_print "- 正在释放文件"
	unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'mb/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
	name=$(pm list packages | grep -w package:com.mubei.android)
	mubeiapp="package:com.mubei.android"
	if [[ $name == $mubeiapp ]]
	then
		ui_print "- 墓碑软件端已安装"
	

	else
		ui_print "- 墓碑软件端未安装"
		unzip -o "$ZIPFILE" 'mb.apk' -d /data/local/tmp/ >&2
		#以下安装APK代码来由搞机助手
		export File='/data/local/tmp/mb.apk'
		export Delete_APK='1'
		abort() {
			ui_print "$@" 1>&2
		}
		IFS=$'\n'
		suffix=${File##*.}
		name=`basename "$File"`
		[[ $1 = -s ]] && installer=" -i $installer " || installer=" "
		ui_print "- 正在安装墓碑软件端"
		if [[ ! -f $File ]]; then
			abort "- 文件不存在"
		else
			unzip -l "$File" &>/dev/null
			[[ $? -ne 0 ]] && abort "- $name 不是压缩文件"
		fi
		if [[ $suffix = apk ]]; then
			size=`ls -l "$File" | awk '{print $5}'`
			a="cat \""$File"\" | pm install -r -d -S "$size""$installer" 1> /dev/null"
			eval $a
			result=$?
			if [[ $result = 0 ]]; then
				ui_print "- 墓碑软件端 安装成功"
				[[ $Delete_APK = 1 ]] && rm -f "$File"

			else
				abort -e "- 墓碑软件端 安装失败"
			fi
		fi
	fi
	ui_print "- 已经删除临时文件"


SDK="`getprop ro.build.version.sdk`"
if [[ $SDK -le 28 ]]
	then
	ui_print "- SDK:$SDK 很遗憾，仅支持安卓10及以上的系统。"	
    rm -f /data/adb/modules_update
    ui_print "- 文件清理完成……"	
fi
}

set_permissions() {

	# The following is default permissions, DO NOT remove
	set_perm_recursive  $MODPATH  0  0  0777  0777

	#设置权限，基本不要去动
}

