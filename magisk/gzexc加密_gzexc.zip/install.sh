SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'system/bin/gzexc' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0777 0777
#设置权限，基本不要去动
}