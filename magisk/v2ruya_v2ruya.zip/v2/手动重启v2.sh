. ./config.ini
./核心文件勿动/"$exec".bin stop
echo "已关闭v2，开始重新启动…"
./"手动开启v2".sh