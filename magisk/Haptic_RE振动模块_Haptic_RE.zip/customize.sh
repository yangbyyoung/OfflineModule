
SKIPUNZIP=0
DEBUG=false
IDerror() {
ui_print " >>>:"
ui_print " 删除所有涉及振动的模块-重启."
ui_print " 查看本机/vendor(odm)/firmware目录:"
ui_print " 检查上述文件是否缺失/重复."
ui_print " 把文件补全或删除重复,再安装模块."
ui_print " -"
ui_print " 仅支持米系x轴机型(Miui/HyperOS/部分类原生)"
ui_print " 官改/移植包,作者可能改过振动,兼容性未知."
ui_print " 其他品牌刷的Miui/HyperOS移植包,"
abort " 由于底包(驱动方案)不同,本模块不兼容.谢谢."
}
buttos() {
butto=""
while [ "$butto" = "" ]; do
butto="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
sleep 0.2
done
}
if [ -f /odm/firmware/1_*.bin ] || [ -f /odm/firmware/2_*.bin ]; then
A="odm"
elif [ -f /vendor/firmware/1_*.bin ] || [ -f /vendor/firmware/2_*.bin ]; then
A="vendor"
else
ui_print "! ID文件(1_*.bin、2_*.bin)异常!"
IDerror
fi
M="$MODPATH"
F="$M/File/wave"
pro="$M/File/prop"
C="/$A/firmware"
SC="system$C"
D="$M/$SC"
aw="aw8697_haptic.bin"
dam="data/adb/modules"
sp="system.prop"
msp="$M/$sp"
me="$M/module.prop"
P="`grep_prop ro.product.odm.device /odm/etc/build.prop`"
U="`grep_prop ro.soc.model /vendor/build.prop`"
V="`grep_prop ro.odm.build.version.incremental /odm/etc/build.prop`"
ui_print "- 设备:$P($U)"
ui_print "- $V(SDK:$API)"
if [ "$API" -lt 30 ]; then
abort "- 安卓版本低于11.0"
fi
ui_print "　　　　　　 !风险提示!"
ui_print "-个别机型可能有(功耗/振动异常/无振动等)玄学问题."
ui_print "-建议搜索专版模块,或单独MiuiExtra映射震动."
ui_print "-模块非万能,玄学问题概不负责.是否继续?"
ui_print "　　　　音量↑:安装│音量↓:取消"
buttos
case "$butto" in
"KEY_VOLUMEUP")
ui_print "　　　　 ✓✓"
mv -f $F/*p0* $F/on.sh
. $F/on.sh
;;
*)
abort "　　　　　　　　　　　　 ✓✓"
esac
ui_print ""
ui_print ""
ui_print ""
ui_print ""
