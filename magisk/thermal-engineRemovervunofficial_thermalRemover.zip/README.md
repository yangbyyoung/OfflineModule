# thermal-engine Remover

这个模块可以不直接修改系统地移除温控文件

## 用法
- 在刷入时按音量键选择模式
- 重启即可生效

## Change Log
- 2021.11.04
  - v4.4 Fix the problem that deleting the temperature control of MIUI may cause failure to boot
- 2021.05.28
  - v4.3 fix volume
- 2021.05.03
  - v4.2 fix bug
  - v4.1 add new solution
  - v4.0 refactor
- 2020.03.02
  - v3.0: support magisk 20.1+
- 2018.09.23 
  - v2.1: re-add mode select 
  - v2: modify for full replace
- 2018.09.22 init
