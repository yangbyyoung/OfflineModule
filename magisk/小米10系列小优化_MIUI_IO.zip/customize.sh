SKIPMOUNT=false
need_device="umi|cmi|vangogh|monet|cas"
if [[ "`echo $var_device | egrep $need_device`" = "" ]];then
echo "
- 不支持您的设备！
- 请检查您的设备是否为：
- 小米10：umi
- 小米10 Pro：cmi
- 小米10青春版：vangogh
- 小米10 Lite（国际版）：monet
- 小米10至尊纪念版：cas
"
abort
fi
mktouch $MODPATH/system/vendor/bin/cnss_diag
mktouch $MODPATH/system/vendor/bin/tcpdump
#清理WIFI 日志
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
set_perm_recursive  $MODPATH  0  0  0755  0644
cat $MODPATH/README.md