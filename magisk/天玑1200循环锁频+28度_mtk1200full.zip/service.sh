#!/system/bin/sh
chmod 777 /data/adb/modules/mtk1200full/service.sh
chmod 660 /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
chmod 660 /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
chmod 660 /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
chmod 660 /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
chmod 660 /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq
chmod 660 /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq
echo 设置频率权限完成
chmod 660 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 660 /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
chmod 660 /sys/devices/system/cpu/cpufreq/policy7/scaling_governor
echo 设置模式权限完成
chmod 660 /sys/class/power_supply/bms/temp
echo 设置温度权限完成
echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "performance" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
echo "performance" > /sys/devices/system/cpu/cpufreq/policy7/scaling_governor
echo 模式更改完成
set_cpu_freq() {
  echo "280" > /sys/class/power_supply/bms/temp
  echo "2000000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
  echo "2000000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
  echo "2600000" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
  echo "2600000" > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
  echo "3000000" > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq
  echo "3000000" > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq
}
while true; do
  set_cpu_freq
  sleep 0
done
#不介意二改，但是求标注原作者酷安@ROS西瓜