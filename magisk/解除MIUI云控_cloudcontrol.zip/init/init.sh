
sleep 60

for i in /data/adb/modules/cloudcontrol/sh/*.sh ;do
  chmod 777 $i
  /system/bin/sh $i
done

for i in /data/adb/modules/cloudcontrol/sh/* ;do
  chmod 777 $i
  /system/bin/sh $i
done