mkdir -p /data/.poes/sh
echo 'chmod 755 -R /data/.poes
for i in /data/.poes/sh/*; do
    echo -n "----------" >> /data/.poes/all.log
    date >> /data/.poes/all.log
    sh "$i" >> /data/.poes/all.log 2>&1
done' > /data/.poes/runall.sh