# 安装时显示的模块名称
mod_name="[功能补全]"
# 功能来源
ORIGIN="@买不起裤衩啊"
# 模块介绍
mod_install_desc="\n  ◆ 开启纸质护眼功能(设置-＞显示-＞护眼模式-＞纸质护眼)\n  ◆ 开启扬声器清理和微信视频美颜(设置->更多设置->扬声器清理/视频通话美颜)\n  ◆ 开启听感调节(设置->声音与震动->音质音效->听感调节)"
# 安装时显示的提示
mod_install_info="是否安装？"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc=""
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device=".{0,}" #全部
# 支持的系统版本，持正则表达式
mod_require_version="V125" #全部
# 支持的设备版本，持正则表达式
mod_require_release=".{0,}" #全部



# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
source $TMPDIR/features.sh
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_smart_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/etc/device_features/*
sed -i 's/<bool name=\"support_paper_eyecare\">.*<\/bool>//g' $MODPATH/system/vendor/etc/device_features/*

sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
# 附加值到 system.prop
		add_sysprop "#Settingplus
ro.vendor.audio.spk.clean=true
ro.vendor.audio.spk.stereo=true
ro.vendor.audio.sfx.earadj=true
ro.vendor.audio.soundfx.usb=true
ro.audio.monitorRotation=true
persist.vendor.vcb.enable=true
persist.vendor.vcb.ability=true
"
    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
		return 0
}
