set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

NAME=$(getprop ro.product.name)
BT=/sys/class/power_supply/bms/charge_full

if [ $NAME = "apollo" ];then
 bms=5037000
else
 #扩容电池请修改这个值，如6000ma，请修改为bms=6000000
 bms=$(cat /sys/class/power_supply/bms/charge_full_design)
fi

bms2=$(($bms-20000))

Charging_control=/sys/class/power_supply/battery/input_suspend

Charging_control2=/sys/class/power_supply/battery/charging_enabled

sleep 10
while true;do
battery=$(cat /sys/class/power_supply/bms/charge_counter)

charge_full=$(cat /sys/class/power_supply/bms/charge_full)

count=$(cat /data/adb/modules/battery/sh/count)

charging=$(dumpsys deviceidle get charging)

#日志设置
local logfile=/data/adb/modules/battery/log.txt
local size=5
local maxsize="$((1024*$size))" 
local filesize="$(ls -l "${logfile}" | awk '{print $5}')"

if [[ -f $BT ]];then
if (($charge_full < $bms));then
set_value "$bms" /sys/class/power_supply/bms/charge_full
charge_fulls=$(cat /sys/class/power_supply/bms/charge_full)
if test -f "${logfile}";then
 if test "$filesize" -lt "$maxsize";then
   if test "$charge_fulls" -lt "$bms";then
    echo "log记录时间：$(date '+%y年%m月%d日%T')，修改失败，容量为：$charge_fulls，请刷入解容内核，再尝试刷入本模块！" >> $logfile
   else
	echo "log记录时间：$(date '+%y年%m月%d日%T')，成功修改，修改前，容量为：$charge_full，修改后，容量为：$charge_fulls" >> $logfile
   fi
 else 
   if test "$charge_fulls" -lt "$bms";then
    echo "log记录时间：$(date '+%y年%m月%d日%T')，修改失败，容量为：$charge_fulls，请刷入解容内核，再尝试刷入本模块！" > $logfile
   else
	echo "log记录时间：$(date '+%y年%m月%d日%T')，成功修改，修改前，容量为：$charge_full，修改后，容量为：$charge_fulls" > $logfile
   fi
 fi
else
 if test "$charge_fulls" -lt "$bms";then
    echo "log记录时间：$(date '+%y年%m月%d日%T')，修改失败，容量为：$charge_fulls，请刷入解容内核，再尝试刷入本模块！" > $logfile
 else
	echo "log记录时间：$(date '+%y年%m月%d日%T')，成功修改，修改前，容量为：$charge_full，修改后，容量为：$charge_fulls" > $logfile
 fi
fi
fi

if $charging;then
 if (($battery > $bms2));then
  if (($count=="0"));then
   echo 1 >$Charging_control
   echo 0 >$Charging_control2
   sleep 60
   echo 0 >$Charging_control
   echo 1 >$Charging_control2
   echo 1 >/data/adb/modules/battery/sh/count
   if test -f "${logfile}";then
     echo "log记录时间：$(date '+%y年%m月%d日%T')，充电断充成功！" >> $logfile
   else
     echo "log记录时间：$(date '+%y年%m月%d日%T')，充电断充成功！" > $logfile
   fi
   sleep 30
  fi
 fi
fi

if ! $charging;then
 if (($count=="1"));then
   echo 0 >/data/adb/modules/battery/sh/count
 fi
fi

else
 if test -f "${logfile}";then
  echo "log记录时间：$(date '+%y年%m月%d日%T')，缺少电池文件，模块不支持此机型！" >> $logfile
 else
  echo "log记录时间：$(date '+%y年%m月%d日%T')，缺少电池文件，模块不支持此机型！" >> $logfile
 fi
fi

sleep 60
done