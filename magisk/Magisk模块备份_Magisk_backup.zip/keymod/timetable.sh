#!/system/bin/sh

MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
source $MODPATH/keymod/path.sh

opts2(){
	clear
	reset
	echo "☞=======================================☜"
	echo ""
	echo ""
	echo ""
	echo ""
	echo "●————————————Magisk备份定时任务管理————————————●"
	echo ""
	echo ""
	echo "1.开始进程"
	echo ""
	echo "2.停止进程"
	echo ""
	echo "3.调整时间"
	echo ""
	echo "4.回到主菜单"
	echo ""
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	read c2
	if test $c2 == 1 ;then
		TAO && opts2
	elif [ $c2 == 2 ];then
		TA && opts2
	elif [ $c2 == 3 ];then
		timetabTA && opts2
	elif [ $c2 == 4 ];then
		source $MODPATH/keymod/magiskbackup.sh
	elif [ $c2 != "*[0-9]*" ];then
		opts2
	fi
	echo "☞=======================================☜"
}

TA(){
	ProcessA=`ps -ef | grep -w "$MODPATH/timetable" |grep -v grep |awk '{print $2}' `
	for i in $ProcessA;do
		echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
	done
}

TAO(){
	chmod -R 777 $MODPATH/timetable
	crond -c $MODPATH/timetable
}

writemodulesinfo(){
local file=$MODPATH/module.prop
timesleep=`cat $timetablefile |tr -cd "[0-9]"`
test $timesleep == 10  && timesleep='10分钟'
test $timesleep == 30  && timesleep='30分钟'
test $timesleep == 01  && timesleep='1个小时'
test $timesleep == 001  && timesleep='1天'
test $timesleep == 03  && timesleep='3个小时'
test $timesleep == 06  && timesleep='6个小时'
sed -i "/^description=/c description=备份文件在 "$(dirname $(dirname $Backup_path))"。模拟终端输入magiskbackup，可以选择恢复或者备份模块，您也可以在备份目录恢复或者备份模块。备份时间间隔为: "$timesleep" " $file
}

function timetabTA(){
	reset
	clear
	echo ""
	echo ""
	echo "●——————Magisk备份任务时间程度————●"
	echo ""
	echo "注意！任意在这里选一个都不会特别耗电。"
	echo ""
	echo ""
	echo "1. 10分钟"
	echo "2. 30分钟"
	echo "3. 1小时"
	echo "4. 3小时"
	echo "5. 6小时"
	echo "6. 1天"
	read timetab
	if test $timetab == 1 ;then
		TA
		echo "*/10 * * * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab == 2 ];then
		TA
		echo "*/30 * * * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab == 3 ];then
		TA
		echo "0 */1 * * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab == 4 ];then
		TA
		echo "0 */3 * * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab == 5 ];then
		TA
		echo "0 */6 * * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab == 6 ];then
		TA
		echo "0 0 */1 * *  $MODPATH/timetable/backup.sh " > $timetablefile
		TAO
	elif [ $timetab != "*[0-9]*" ];then
		timetabTA
	fi
}




opts2
