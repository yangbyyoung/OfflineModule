#!/system/bin/sh
/system/xbin/sukp/SuKP-start.sh

exit 0