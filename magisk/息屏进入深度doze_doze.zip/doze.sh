#!/system/bin/sh
Log() {
  txt="/sdcard/Android/doze.log"
  am start -n com.kmou424.ToastCreator/com.kmou424.ToastCreator.MainActivity --es msg "$1" >/dev/null 2>&1
  echo "$(date '+%T') $1" >> $txt
}
screen=`dumpsys window policy | grep "mInputRestricted"|cut -d= -f2`
#識別doze狀態
dumpsys deviceidle | grep -q Enabled=true
Ad=$?
  if [[ $screen = true ]]; then
   if [[ $Ad = 1 ]]; then
      dumpsys deviceidle enable
      dumpsys deviceidle force-idle
      fstrim -v /system
      fstrim -v /data
      fstrim -v /cache
      Log "以執行fstrim"
      Log "關閉屏幕進入Deep Doze"
   fi
  else
   if [[ $Ad = 0 ]]; then
      dumpsys deviceidle disable
      Log "開啟屏幕退出Deep Doze"
   fi
  fi