exit

# 开机前执行这玩意，可能导致GPU异常满载
ged_kpi=/sys/module/sspm_v3/holders/ged/parameters/is_GED_KPI_enabled
umount $ged_kpi
chmod 666 $ged_kpi
echo 0 > $ged_kpi
if [[ ! -f /cache/is_GED_KPI_enabled ]]; then
  chmod 444 $ged_kpi
  echo '0' > /cache/is_GED_KPI_enabled
  chattr +i /cache/is_GED_KPI_enabled
fi
mount --bind /cache/is_GED_KPI_enabled $ged_kpi
