##############################################################

SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

##############################################################

ID="`grep_prop id $TMPDIR/module.prop`"
B="`grep_prop author $TMPDIR/module.prop`"
model="`grep_prop ro.product.system.model`"
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
MIUI="`getprop ro.miui.ui.version.name`"
   ui_print "###############################"
   ui_print "- 模块名称: $MODNAME "
   ui_print "- 模块ID: $ID "
   ui_print "- 模块作者: $B"
   ui_print "- 设备机型: $model"
   ui_print "- 设备代号: $var_device"
   ui_print "- 系统版本: $var_version"
   ui_print "- MIUI版本: $MIUI"    
   ui_print "###############################"

   ui_print "

 如果不开机以下方法卸载模块
 rec→高级→文件管理→data→adb→modules→XianGe_Magisk
 
 "
   ui_print "*******************************"
   ui_print "     永远相信美好的事情即将发生          "
   ui_print "*******************************"

##############################################################

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
/system/app/AnalyticsCore
/system/app/BasicDreams
/system/app/CatchLog
/system/app/Cit
/system/app/goodix_sz
/system/app/MiuiBugReport
/system/app/MiuiDaemon
/system/app/mab
/system/app/MSA
/system/app/MaintenanceMode
/system/app/SimAppDialog
/system/app/PaymentService
/system/app/PrintSpooler
/system/app/Traceur
/system/app/WMService
/system/app/greenguard
/system/app/BookmarkProvider
/system/app/CatcherPatch
/system/app/com.miui.qr
/system/app/KeyChain
/system/app/PacProcessor
/system/priv-app/BuiltInPrintService
/system/priv-app/CallLogBackup
/system/priv-app/MiRcs
/system/priv-app/UserDictionaryProvider
/system/priv-app/BlockedNumberProvider
/system/priv-app/DMRegService
/system/product/app/PhotoTable
/system/system_ext/app/FM
/system/system_ext/priv-app/EmergencyInfo
/system/data-app/MiLiveAssistant
/system/data-app
/system/vendor/data-app
"

##############################################################

print_modname()
{
    return
}

##############################################################

on_install()
{
ui_print "- 正在释放文件 "
#dex2oat优化
ui_print "- dex2oat优化中 "
Everything="cmd package compile -m everything -f"
Package_Name="
com.miui.home
com.miui.freeform
com.miui.miwallpaper
com.android.systemui
com.android.settings
com.miui.notification
com.xiaomi.misettings
com.miui.personalassistant"
for i in $Package_Name; do
$Everything $i > /dev/null && echo "- $i 优化成功"
done
ui_print "- 优化完成 "

##############################################################

#读写速度优化
ui_print "- 读写速度优化中 "
if
/sbin/.magisk/busybox/fstrim -v /data
/sbin/.magisk/busybox/fstrim -v /cache
/sbin/.magisk/busybox/fstrim -v /system
/sbin/.magisk/busybox/fstrim -v /vendor
then : 
elif
/dev/*/.magisk/busybox/fstrim -v /data
/dev/*/.magisk/busybox/fstrim -v /cache
/dev/*/.magisk/busybox/fstrim -v /system
/dev/*/.magisk/busybox/fstrim -v /vendor
then : 
else
echo "- fstrim失败"
fi
echo "
#自动读写速度优化
sleep 5
while true ;do
if
/sbin/.magisk/busybox/fstrim -v /data
/sbin/.magisk/busybox/fstrim -v /cache
/sbin/.magisk/busybox/fstrim -v /system
/sbin/.magisk/busybox/fstrim -v /vendor
then : 
elif
/dev/*/.magisk/busybox/fstrim -v /data
/dev/*/.magisk/busybox/fstrim -v /cache
/dev/*/.magisk/busybox/fstrim -v /system
/dev/*/.magisk/busybox/fstrim -v /vendor
then : 
else
echo "- fstrim失败"
fi
sleep 1d
done" >> $TMPDIR/service.sh
ui_print "- 优化完成 "

##############################################################

#高通WiFi增强
[ -x "$(which magisk)" ] && MIRRORPATH=$(magisk --path)/.magisk/mirror || unset MIRRORPATH
array=$(find /system /vendor -name WCNSS_qcom_cfg.ini)
for CFG in $array
do
[[ -f $CFG ]] && [[ ! -L $CFG ]] && {
SELECTPATH=$CFG
mkdir -p `dirname $MODPATH$CFG`
cp -af $MIRRORPATH$SELECTPATH $MODPATH$SELECTPATH
sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nEND/g' $MODPATH$SELECTPATH
}
done
[[ -z $SELECTPATH ]] && abort "- Installation FAILED. Your device didn't support WCNSS_qcom_cfg.ini." || { mkdir -p $MODPATH/system; mv -f $MODPATH/vendor $MODPATH/system/vendor;}

##############################################################

#游戏高能时刻
DEVICE=`getprop ro.product.device`
if [ -f "/system/etc/device_features/$DEVICE.xml" ];then
mkdir -p $MODPATH/system/etc/device_features/
cp /system/etc/device_features/$DEVICE.xml $MODPATH/system/etc/device_features/
sed -i '3i\\t<bool name="support_game_mi_time">true</bool>' $MODPATH/system/etc/device_features/$DEVICE.xml
else
mkdir -p $MODPATH/system/vendor/etc/device_features/
cp /system/vendor/etc/device_features/$DEVICE.xml $MODPATH/system/vendor/etc/device_features/
sed -i '3i\\t<bool name="support_game_mi_time">true</bool>' $MODPATH/system/vendor/etc/device_features/$DEVICE.xml
fi
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
echo "
#扬声器清理
ro.vendor.audio.spk.clean=true
ro.vendor.audio.spk.stereo=true
#实时模糊
ro.miui.backdrop_sampling_enabled=true" >> $TMPDIR/system.prop

##############################################################

#移除cnss_diag/减少耗电消耗
[[ -e /system/vendor/bin/cnss_diag ]] && mktouch $MODPATH/system/vendor/bin/cnss_diag
echo "
#杀死cnss_diag/减少耗电消耗
sleep 1
stop cnss_diag
killall -9 cnss_diag" >> $TMPDIR/service.sh

##############################################################

echo "
#自动清理缓存
sleep 3
while true ;do
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
sleep 30m
done" >> $TMPDIR/service.sh
echo "
#卸载模块自动清理缓存
dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
rm -f $dda/system@*@"$i"*
done
rm -r /data/system/package_cache/*" >> $TMPDIR/uninstall.sh

##############################################################

#移除温控
mkdir -p ${MODPATH}/system/vendor/bin
mkdir -p ${MODPATH}/system/vendor/etc/init
mkdir -p ${MODPATH}/system/vendor/etc
for tconf in $(ls /system/vendor/bin/*thermald /system/vendor/bin/*thermald)
do
touch ${MODPATH}${tconf}
done
for tconf in $(ls /system/vendor/etc/init/*thermal* /system/vendor/etc/init/*thermal*)
do
touch ${MODPATH}${tconf}
done
for tconf in $(ls /system/vendor/bin/thermal* /system/vendor/bin/thermal*)
do
touch ${MODPATH}${tconf}
done
for tconf in $(ls /system/vendor/etc/thermal* /system/vendor/etc/thermal*)
do
touch ${MODPATH}${tconf}
done
ui_print "- 移除温控成功 "
ui_print "- 全部安装成功 "
}

##############################################################

set_permissions()
{
    set_perm_recursive  $MODPATH  0  0  0755  0644
}

##############################################################