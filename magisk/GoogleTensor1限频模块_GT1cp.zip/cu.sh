chmod 644 /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq
echo 2252000 > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq