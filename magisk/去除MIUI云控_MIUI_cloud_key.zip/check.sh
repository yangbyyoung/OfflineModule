#!/system/bin/sh

if test "$(getprop ro.miui.ui.version.name | tr -cd '[0-9]' )" -gt "12" ;then
cat << "key" 

#########################

	●———— 非MIUI 12————●
	●●●    💢💢💢   ●●●
	※刷入后，出现bug，死机，变砖……
	※爆炸，重生异世界，飞升……
	※变成美少女之类的情况……
	❌❌❌❌❌❌❌❌❌❌
	※※※	本模块概不负责！※※※
	❌❌❌❌❌❌❌❌❌❌
	●●●   💢💢💢   ●●●
	
#########################

key
fi

test "$(getprop ro.miui.ui.version.name)" = "" && abort "仅支持MIUI！"



