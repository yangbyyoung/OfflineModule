#!/system/bin/sh
MODDIR=${0%/*}
log_path="/data/media/0/log_bootprotect.txt"
BOOT_A=$(realpath /dev/block/by-name/boot_a)
BOOT_B=$(realpath /dev/block/by-name/boot_b)
var_device="$(getprop ro.product.device)"
var_version="$(getprop ro.build.version.release)"
var_MIUI_version="$(getprop ro.miui.ui.version.name)"
DATE=$(date "+%Y%m%d-%H%M%S")
#作者 F-19-F
wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
    local test_file="/sdcard/Android/.PERMISSION_TEST"
    true >"$test_file"
    while [ ! -f "$test_file" ]; do
        true >"$test_file"
        sleep 1
    done
    rm "$test_file"
}
grep_cmdline() {
    local REGEX="s/^$1=//p"
    {
        echo $(cat /proc/cmdline)$(sed -e 's/[^"]//g' -e 's/""//g' /proc/cmdline) | xargs -n 1
        sed -e 's/ = /=/g' -e 's/, /,/g' -e 's/"//g' /proc/bootconfig
    } 2>/dev/null | sed -n "$REGEX"
}
wait_until_login
rm -rf $log_path
{
    echo "MTK_BOOTPROTECT $DATE"
    SLOT=$(grep_cmdline androidboot.slot_suffix)
    #通过当前的slot决定要更改的分区
    if [ -z $SLOT ]; then
        SLOT=$(grep_cmdline androidboot.slot)
        [ -z $SLOT ] || SLOT=_${SLOT}
    fi
    # 不是A/B分区设备,强制退出并禁用
    if [ -z $SLOT ]; then
        echo "不是(V-)A/B分区设备,停止运行!"
        true >$MODDIR/disabled
        exit 1
    fi
    echo "- 当前Boot槽位: $SLOT"
    echo "- 设备: $var_device"
    echo "- 系统版本: $var_version"
    echo "- MIUI版本: $var_MIUI_version"
    case $SLOT in
    _a) $MODDIR/abslot-tool -p 0;;
    _b) $MODDIR/abslot-tool -p 1;;
    *) echo "不支持保护";;
    esac
} 2>&1 >>$log_path
