#ps -ef |grep /data/adb/modules/mubei/mb/mb.sh
mb=/data/adb/modules/mubei/mb/mb.sh


mb_id="$(pgrep 'mb.sh' | wc -l)"
mb1_id="$(pgrep 'mb1.sh' | wc -l)"
mb2_id="$(pgrep 'mb2.sh' | wc -l)"

if [ "$mb_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mKill墓碑\e[0m正在运行！"
elif [ "$mb1_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v1墓碑\e[0m正在运行！"
elif [ "$mb2_id" != "0" ]; then
    echo "\n$(date '+%T') ️当前模式：\e[32mFreeze v2墓碑\e[0m正在运行！"
else
    echo "\n\e[31m墓碑已经关闭……！\e[0m"   
fi
