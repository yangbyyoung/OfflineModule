SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print "*******************************"
  ui_print "     微信QQ内存压制    "
  ui_print "*******************************"
}

on_install() {
  mkdir -p /data/crond1
  ui_print "- 正在提取模块文件"
  unzip -o "$ZIPFILE" 'root' -d /data/crond1/ >&2
  chmod 777 /data/crond1/root
  unzip -o "$ZIPFILE" '定时检测清理后台.sh' -d /data/ >&2
  chmod 777 /data/定时检测清理后台.sh
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}