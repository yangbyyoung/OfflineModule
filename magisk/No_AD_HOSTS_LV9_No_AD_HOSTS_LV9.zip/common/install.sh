# remove /data/resource-cache/overlays.list

