MODDIR="$1"
#安卓UI流畅度优化部分
sleep 2s

function white_list()
{
  pgrep -o $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white_list surfaceflinger
white_list webview_zygote

function white()
{
  pgrep -f $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white android.hardware.graphics.composer@2.2-service
white zygote
white zygote64
white com.android.systemui

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 1 > /dev/stune/rt/schedtune.prefer_idle
echo 20 > /dev/stune/rt/schedtune.boost
echo 20 > /dev/stune/top-app/schedtune.boost
echo 1 > /dev/stune/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 50 > /dev/memcg/memory.swappiness
