#!/system/bin/sh
############
#   SuKP   #
#  ver1.1  #
#By supppig#
############
##脚本部分全部开源，禁止用于商业用途，否则后果自负！##
addiptables()
{
if [ "$bjglms" = "1" ];then
adzfuid="REDIRECT --to-ports 3000"
adzfall="RETURN"
else
adzfuid="RETURN"
adzfall="REDIRECT --to-ports 3000"
fi
if [ "$dataadb" = "1" -o "$wifiadb" = "1" ];then
iptables -t nat -N ad_block
sleep 0.1
iptables -t nat -A ad_block -o lo -j RETURN
iptables -t nat -A ad_block -i tun+ -j RETURN
if [ "$wifiadb" = "0" ];then
iptables -t nat -A ad_block -o wlan+ -j RETURN
fi
if [ "$wifiadb" = "1" -a "$wifinoadb" != "" ];then
for x in $wifinoadb
do
iptables -t nat -A ad_block -o wlan+ -s $x -j RETURN
done
fi
iptables -t nat -A ad_block -m owner --uid-owner 0-9999 -j RETURN
iptables -t nat -A ad_block -d 224.0.0.0/3 -j RETURN
if [ "$bjglms" = "0" ];then
for x in $vpn
do
if [ "$x" != "" ];then
bm=$(echo $x | grep -i '[a-z]')
if [ "$bm" != "" ];then
xx=$(grep -m1 -i $x /data/system/packages.list | cut -d' ' -f2)
else
xx=$x
fi
if [ "$xx" != "" ];then iptables -t nat -A ad_block -m owner --uid-owner $xx -j RETURN;fi
fi
done
fi
if [ "$adlwuid" != "" ];then
for x in $adlwuid
do
if [ "$x" != "" ];then iptables -t nat -A ad_block -p tcp -m owner --uid-owner $x -j ${adzfuid};fi
done
fi
iptables -t nat -A ad_block -p tcp -j ${adzfall}
fi
if [ "$dataadb" = "0" -a "$wifiadb" = "1" ];then
x='-o wlan+'
else
x=''
fi
if [ "$dataadb" = "1" -o "$wifiadb" = "1" ];then
iptables -t nat -I OUTPUT $x -p tcp -m multiport --dports 80,8080 -j ad_block
if [ "$?" != "0" ];then
iptables -t nat -I OUTPUT $x -p tcp --dport 80 -j ad_block
iptables -t nat -I OUTPUT $x -p tcp --dport 8080 -j ad_block
fi
fi
if [ "$hotadb" != "0" ];then
iptables -t nat -I PREROUTING -p tcp -m multiport --dports 80,8080 -j REDIRECT --to-ports 3000
if [ "$?" != "0" ];then
iptables -t nat -I PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 3000
iptables -t nat -I PREROUTING -p tcp --dport 8080 -j REDIRECT --to-ports 3000
fi
fi
}
deliptables()
{
iptables -t nat -D OUTPUT -p tcp -m multiport --dports 80,8080 -j ad_block 2>&-
iptables -t nat -D OUTPUT -o wlan+ -p tcp -m multiport --dports 80,8080 -j ad_block 2>&-
iptables -t nat -D OUTPUT -p tcp --dport 80 -j ad_block 2>&-
iptables -t nat -D OUTPUT -p tcp --dport 8080 -j ad_block 2>&-
iptables -t nat -D OUTPUT -o wlan+ -p tcp --dport 80 -j ad_block 2>&-
iptables -t nat -D OUTPUT -o wlan+ -p tcp --dport 8080 -j ad_block 2>&-
iptables -t nat -D PREROUTING -p tcp -m multiport --dports 80,8080 -j REDIRECT --to-ports 3000 2>&-
iptables -t nat -D PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 3000 2>&-
iptables -t nat -D PREROUTING -p tcp --dport 8080 -j REDIRECT --to-ports 3000 2>&-
sleep 0.1
iptables -t nat -F ad_block 2>&-
iptables -t nat -X ad_block 2>&-
}
killprocess()
{
allapp='koolproxy'
for i in $allapp
do
${bkillall} -q $i
done
}
cbbx()
{
type $1 2>&- >&-
if [ "$?" = "0" ];then
eval b$1=$1
else
eval b$1=\"$bbx $1\"
fi
}
automount()
{
echo "supppig" >$1/test.supppig
if [ "$?" = "0" ];then
${brm} -f $1/test.supppig
else
x=$(echo $1 | ${bcut} -d'/' -f2)
${bmount} -o rw,remount /$x 2>&- || ${bmount} -o remount,rw /$x 2>&-
fi
}
kpautoupdate()
{
if [ "$dataadb" = "1" -o "$wifiadb" = "1" -o "$hotadb" != "0" ] && [ "$autoupdate" = "1" ];then
oldtime=0
if [ -s ${kpdir}/supppig ];then
. ${kpdir}/supppig
let oldtimefix=oldtime+28800
lastupdatetime=$(${bdate} '+%Y-%m-%d %H:%M' -d@$oldtimefix)
else
lastupdatetime="从未更新"
fi
newtime=$(${bdate} +%s)
timex=$((newtime-oldtime))
if [ $timex -gt 21600 ];then
x=$(${bdate} '+%Y-%m-%d_%H:%M')
echo "#上次检查更新时间：$x
oldtime=$newtime" >$kpdir/supppig
kpneedupdate="y"
kpupstr="上次检查更新时间为：$lastupdatetime \n广告自动更新任务将于30秒后开始。"
else
kpneedupdate=""
kpupstr="上次检查更新时间为：$lastupdatetime \n广告自动更新任务暂不启动。"
fi
fi
}
DIR="${0%/*}"
bbx=${DIR}'/KoolProxy/busybox'
kpdir=${DIR}'/KoolProxy'
cbbx grep
cbbx cut
cbbx mount
cbbx chmod
cbbx killall
cbbx date
cd $DIR
if ! [ -x "$bbx" ];then
mount -o rw,remount /system 2>&-
mount -o rw,remount /data 2>&-
chown 0:0 $bbx
chmod 777 $bbx
if ! [ -x "$bbx" ];then
echo "权限不足。请赋予KoolProxy文件夹及其子文件夹内所有文件777权限。"
exit 1
fi
fi
automount $kpdir
${bchown} -R 0:0 $DIR
${bchmod} -R 777 $DIR
. ./SuKP-setting.ini
killprocess
deliptables
if [ "$1" = "S" ];then
exit 0
fi
sleep 0.5
${kpdir}/koolproxy -c1 -b ${kpdir} -d >/dev/null &
sleep 0.2
addiptables
kpautoupdate
sleep 1
. ./SuKP-check.sh
if [ "$kpneedupdate" = "y" ];then
${bnohup} ./update-rules.sh a >/dev/null &
fi
