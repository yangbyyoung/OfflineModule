#查杀之前遗留的进程
echo 准备重启：
echo ----------------------------
script_name="Dynamic_fps"
lastID=$(ps -eo pid,args | grep "$script_name" | grep -v 'grep' )
if [ "$lastID" != "" ]
then
            echo "$lastID" | while read pid name; do
            
            if [ "$$" != "$pid" ]; then
            echo "关闭 $pid $name"
            kill -KILL $pid
            fi
            done
echo -----------已关闭-----------
else
echo -----没有正在运行的实例-----
fi
echo ----------------------------
DIR=$(dirname $(readlink -f $0))
scriptfile=Dynamic_fps1.2
#启动程序
$DIR/$scriptfile &
#/system/bin/sh $DIR/守护.sh &