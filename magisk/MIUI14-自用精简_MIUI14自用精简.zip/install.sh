##########################################################################################
#
# Magisk Module Template Config Script
# by 顾青城
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=false
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用
# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false
##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "     	Magisk Module        "
  ui_print "For    By 顾青城"
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now

#添加您要精简的APP/文件夹目录
#例如：精简状态栏，找到状态栏目录为  /system/priv-app/SystemUI/SystemUI.apk
#转化加入:/system/priv-app/SystemUI
#（可以搭配高级设置获取APP目录）

##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  #设置权限，基本不要去动
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.
REPLACE="
/system/product/app/AnalyticsCore
/system/app/EasterEgg
/system/product/app/talkback
/system/priv-app/Backup
/system/product/priv-app/MiuiExtraPhoto
/system/vendor/app/CACertService
/system/priv-app/CallLogBackup
/system/app/PlatformCaptivePortalLogin
/system/product/app/CarWith
/system/app/CatchLog
/system/priv-app/CellBroadcastServiceModulePlatform
/system/product/priv-app/MIUIContentExtension_S
/system/product/app/MiuiCit
/system/priv-app/BackupRestoreConfirmation
/system/priv-app/CellBroadcastLegacyApp
/system/priv-app/LocalTransport
/system/priv-app/ONS
/system/priv-app/SharedStorageBackup
/system/system_ext/app/WAPPushManager
/system/app/WallpaperBackup
/system/system_ext/priv-app/WallpaperCropper
/system/priv-app/MiuiWifiDialog
/system/system_ext/app/CatcherPatch
/system/app/com.miui.qr
/system/system_ext/app/KSICibaEngine
/system/system_ext/app/XMCloudEngine
/system/system_ext/app/TranslationService
/system/product/overlay/VoiceAssistAndroidOverlay
/system/app/MiModemDebugService
/system/system_ext/app/QTIDiagServices
/system/system_ext/priv-app/dpmserviceapp
/system/system_ext/app/datastatusnotification
/system/system_ext/app/colorservice
/system/system_ext/app/atfwd
/system/system_ext/app/embms
/system/system_ext/app/DeviceStatisticsService
/system/system_ext/app/DynamicDDSService
/system/product/app/uimlpaservice
/system/product/app/remoteSimLockAuthentication
/system/product/app/remotesimlockservice
/system/product/app/uimgbaservice
/system/system_ext/app/workloadclassifier
/system/system_ext/app/BluetoothDsDaService
/system/vendor/app/TimeService
/system/product/app/uimremoteclient
/system/product/app/uimremoteserver
/system/product/priv-app/ConfigUpdater
/system/system_ext/priv-app/StorageManager
/system/priv-app/BlockedNumberProvider
/system/product/app/MIUIBarrage
/system/app/MiuiPrintSpoolerBeta
/system/system_ext/priv-app/dcf
/system/product/app/MiDevAuthService
/system/priv-app/DynamicSystemInstallationService
/system/vendor/app/EidService
/system/product/priv-app/MIService
/system/priv-app/ManagedProvisioning
/system/product/app/PowerOffAlarm
/system/vendor/app/IFAAService
/system/product/app/MIUIgreenguard
/system/app/BasicDreams
/system/system_ext/priv-app/EmergencyInfo
/system/app/Joyose
/system/system_ext/priv-app/Provision
/system/product/app/HybridPlatform
/system/priv-app/LiveWallpapersPicker
/system/app/ModemTestBox
/system/app/MiuiAudioMonitor
/system/app/VsimCore
/system/product/priv-app/MIUIMiRcs
/system/product/app/PaymentService
/system/app/MiSightService
/system/product/app/MIUIPrivacyComputing
/system/product/priv-app/MirrorSmartHubPrivate
/system/product/app/MiuiBiometric3389
/system/product/app/MIUIVpnSdkManager
/system/system_ext/app/MiuiDaemon
/system/app/KeyChain
/system/priv-app/MtpService
/system/product/overlay/FontNotoSerifSource
/system/product/app/OtaProvision
/system/product/app/OTrPBroker
/system/app/PacProcessor
/system/app/CompanionDeviceManager
/system/system_ext/priv-app/Polaris
/system/priv-app/ProxyHandler
/system/system_ext/app/QCC
/system/system_ext/app/QColor
/system/system_ext/app/QdcmFF
/system/system_ext/priv-app/QtiWifiService
/system/system_ext/priv-app/QualcommVoiceActivation
/system/priv-app/CalendarProvider
/system/system_ext/priv-app/RemoteProvisioner
/system/product/app/RideModeAudio
/system/priv-app/PackageInstaller
/system/app/SecureElement
/system/vendor/app/SensorTestTool
/system/product/app/SecurityOnetrackService
/system/system_ext/app/DeviceInfo
/system/product/priv-app/MIUIYellowPage
/system/product/priv-app/SettingsIntelligence
/system/app/SimAppDialog
/system/vendor/app/SoterService
/system/product/priv-app/SystemHelper
/system/priv-app/Tag
/system/app/MiuixEditor
/system/product/app/MiLinkCirculate3
/system/system_ext/app/uceShimService
/system/product/app/MIUIReporter
/system/system_ext/app/PowerSaveMode
/system/app/Stk
/system/system_ext/app/ImsRcsService
/system/vendor/app/IWlanService
/system/product/app/MetokNLP
/system/product/priv-app/MIUIAod
/system/app/WapiCertManage
/system/product/app/MaintenanceMode
/system/system_ext/priv-app/WfdService
/system/product/app/WMService
/system/product/priv-app/VipServiceNew
/system/product/app/AiasstVision_L2
/system/product/app/XiaoaiRecommendation
/system/product/app/MIUIAiasstService
/system/product/app/VoiceAssistAndroidT
/system/product/app/XMSFKeeperAll
/system/product/app/MIUISecurityInputMethod
/system/product/priv-app/MIShare
/system/product/app/mi_connect_service
/system/product/priv-app/MIUIVideo
/system/app/digitalkey
/system/product/app/SimActivateService
/system/product/app/MIUIAccessibility
/system/product/app/MINextpay
/system/product/priv-app/DownloadProviderUi
/system/system_ext/app/PerformanceMode
/system/priv-app/BuiltInPrintService
/system/product/app/XiaomiServiceFrameworkCN
/system/app/Traceur
/system/system_ext/priv-app/xrcbservice
/system/product/app/MIUITouchAssistant
/system/product/priv-app/MIUIMusicT
/system/product/app/UPTsmService
/system/priv-app/StatementService
/system/product/app/MiBugReport
/system/priv-app/UserDictionaryProvider
/system/product/priv-app/MiGameCenterSDKService
/system/product/app/MiGameService
/system/app/AutoRegistration
/system/app/CarrierDefaultApp
/system/product/app/VoiceTrigger
/system/app/CertInstaller
/system/product/app/HybridAccessory
/system/product/app/MSA
/system/product/priv-app/MIUIPersonalAssistant
/system/product/app/com.xiaomi.macro
/system/system_ext/priv-app/beyondGnssService
/system/product/app/MIUIFrequentPhrase
/system/product/app/MiuiInputSettings
/system/product/app/ConferenceDialer
/system/product/app/FusedLocationProvider
/system/priv-app/InputDevices
/system/priv-app/DMRegService
/system/priv-app/MediaProviderLegacy
/system/product/app/GoogleLocationHistory
/system/vendor/app/CneApp
/system/app/PrintRecommendationService
"