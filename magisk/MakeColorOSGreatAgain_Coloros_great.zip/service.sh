setprop sys.enable.hypnus 0
setprop persist.sys.horae.enable 0
setprop persist.vendor.enable.hans 0
setprop sys.hans.enable 0

stop horae
stop oppo_theias
stop hans
stop orms-hal-1-0
stop vendor.performance-1-0
