#清理精简应用的数据
#来自酷安 @代号10007 的图文
rm rf /data/system/package_cache/*
rm rf /data/dalvik-cache/*/system@*@AnalyticsCore*
rm rf /data/dalvik-cache/*/system@*@MIService*
rm rf /data/dalvik-cache/*/system@*@HybridPlatform*
rm rf /data/dalvik-cache/*/system@*@MIUIBrowser*
rm rf /data/dalvik-cache/*/system@*@MiuiDaemon*
rm rf /data/dalvik-cache/*/system@*@SogouInput*
rm rf /data/dalvik-cache/*/system@*@MIUIQuickSearchBox*
rm rf /data/dalvik-cache/*/system@*@QuickSearchBox_M2M3*
rm rf /data/dalvik-cache/*/system@*@MiBugReport*
rm rf /data/dalvik-cache/*/system@*@MSA*