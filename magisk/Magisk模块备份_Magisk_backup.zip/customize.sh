SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/Module_backup.sh
key_source $MODPATH/cp.sh
key_source $MODPATH/busybox.sh
key_source $MODPATH/install_MOD.sh
set_perm_recursive $MODPATH  0  0  0755 0777
set_perm_recursive $MODPATH/system/bin/magiskbackup  0  2000  0755 0755

