#!/system/bin/sh

dir="${0%/*}"
MODPATH="${dir%/*}"

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g' | head -n 1
}


function Running_thermal_lib_file_remove(){
echo -e "- 查找其他温控文件！\n"
find /system /system_ext /vendor /product -iname '*thermal*' -type f  2> /dev/null | sed '/.*android.*/d;/.*libthermalclient.*/d;/.*thermal-engine.*/d;/.*thermal.*conf/d;/.*hardware.*/d;/.*mi_thermald.*/d' | while read file ;do
file=$(correctpath $file  )
test "${file##*/}" = "mi_thermald" && continue
test "${file##*/}" = "thermal_manager" && continue
test "${file##*/}" = "thermal-engine" && continue
if test -n $file ;then
	if test ! -f "$MODPATH${file}" ;then
		mkdir -p $MODPATH${file%/*}
			chmod 0755 "$MODPATH${file%/*}"
			touch $MODPATH$file && echo "成功替换: $file"
		chmod 0644 "$MODPATH$file"
	fi
fi
done
echo -e "\n∞————————————————————————∞\n"
}

function delete_replace_thermal_lib_file(){
echo -e "- 查找其他温控文件！\n"
find ${MODPATH}/system -iname '*thermal*' -type f  2> /dev/null | sed '/.*android.*/d;/.*libthermalclient.*/d;/.*thermal-engine.*/d;/.*thermal.*conf/d;/.*hardware.*/d;/.*mi_thermald.*/d' | while read file ;do
if test -f $file ;then
	rm -rf "${file}" && echo "成功删除: ${file}"
fi
/data/adb/magisk/busybox find ${MODPATH}/system -type d -empty -exec rm -rf {} \; 2>/dev/null
done
echo -e "\n∞————————————————————————∞\n"
}

if test "$(show_value '替换系统温控文件')" = "是" ;then
	echo -e "\n※你已选择\e[31;40m替换温控二进制文件和温控驱动！\e[0m\n※需\e[31m重启生效\e[0m！\n"
	Running_thermal_lib_file_remove
else
	echo -e "\n※你已选择\e[32;40m恢复温控二进制文件和温控驱动\e[0m\n※需\e[31m重启生效\e[0m！\n"
	delete_replace_thermal_lib_file
fi
