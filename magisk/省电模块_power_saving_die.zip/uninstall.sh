#wm enable-blur 0
local googleservice="
com.google.android.gms
com.google.android.gsf
com.android.vending
com.google.android.syncadapters.contacts
com.google.android.onetimeinitializer
com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
"
for n in $googleservice
do
    pm enable $n
done

rm -rf /data/SakikoPower.conf
rm -rf /data/battery_optimization.conf
rm -rf /cache/SakikoPower.log
