# 𝘣𝘺 𝘤𝘤𝘢𝘦𝘰@ᴛɢ
set_perm_recursive $MODPATH 0 0 0755 0755
