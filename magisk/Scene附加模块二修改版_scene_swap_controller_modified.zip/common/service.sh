#! /vendor/bin/sh
MODDIR=${0%/*}

module_version=`grep '^versionCode=' $MODDIR/module.prop | cut -f2 -d '='`

setprop vtools.swap.module "$module_version"

sh /system/bin/scene_swap_module.sh >> /cache/swap.log
echo "全部完成！" >> /cache/swap.log

# 开机后trim一下，有助于尽量保持写入速度
busybox=/data/adb/magisk/busybox
if [[ -f $busybox ]]; then
  sm fstrim 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  # $busybox fstrim /data 2>/dev/null
  # $busybox fstrim /cache 2>/dev/null
  # $busybox fstrim /system 2>/dev/null
  sm fstrim 2>/dev/null
fi
