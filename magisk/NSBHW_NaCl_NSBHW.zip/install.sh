SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By 小白杨（爱玩机工具箱）"
 ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'product/media/theme/default/framework-res' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/etc/device_features/alioth.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/etc/device_features/aliothin.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/mdss_dsi_k11a_38_08_0a_dsc_cmd_mi.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/etc/qdcm_calib_data_xiaomi_38_08_0a_cmd_mode_dsc_dsi_panel.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/hw/displayfeature.default.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/hw/vendor.xiaomi.hardware.displayfeature@1.0-impl.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib/vendor.xiaomi.hardware.displayfeature@1.0.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/hw/displayfeature.default.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/hw/vendor.xiaomi.hardware.displayfeature@1.0-impl.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/vendor/lib64/vendor.xiaomi.hardware.displayfeature@1.0.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}