AUTOMOUNT=true
SKIPUNZIP=0
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
REPLACE="
"
chmod 755 $MODPATH/txdhhroot/zip
if [ $Device = "cepheus" ]; then
mkdir -p $MODPATH/wenjian
mkdir -p $MODPATH/wenjian1
unzip -o -q /system/system_ext/priv-app/MiuiSystemUI/MiuiSystemUI.apk -d $MODPATH/wenjian
mv $MODPATH/wenjian/classes.dex $MODPATH/wenjian/classes3.dex
cp -rf $MODPATH/txdhhroot/all.dex $MODPATH/wenjian/classes.dex
mkdir -p $MODPATH/system/system_ext/priv-app/MiuiSystemUI
cd $MODPATH/wenjian
$MODPATH/txdhhroot/zip -0 -r -q $MODPATH/system/system_ext/priv-app/MiuiSystemUI/MiuiSystemUI.apk *
elif [ $Device = "raphael" ]; then
mkdir -p $MODPATH/wenjian
mkdir -p $MODPATH/wenjian1
unzip -o -q /system/system_ext/priv-app/MiuiSystemUI/MiuiSystemUI.apk -d $MODPATH/wenjian
rm -rf $MODPATH/wenjian/res/drawable-nxhdpi-v4/gxzw_green_light.webp
cp -rf $MODPATH/txdhhroot/raphael/gxzw_green_light.webp $MODPATH/wenjian/res/drawable-nxhdpi-v4
mv $MODPATH/wenjian/classes.dex $MODPATH/wenjian/classes3.dex
cp -rf $MODPATH/txdhhroot/all.dex $MODPATH/wenjian/classes.dex
mkdir -p $MODPATH/system/system_ext/priv-app/MiuiSystemUI
cd $MODPATH/wenjian
$MODPATH/txdhhroot/zip -0 -r -q $MODPATH/system/system_ext/priv-app/MiuiSystemUI/MiuiSystemUI.apk *
fi
if [ $Device = "cepheus" ]; then
unzip -o -q /system/app/VoiceTrigger/VoiceTrigger.apk -d $MODPATH/wenjian1
mv $MODPATH/wenjian1/classes.dex $MODPATH/wenjian1/classes5.dex
cp -rf $MODPATH/txdhhroot/cepheus/classes.dex $MODPATH/wenjian1
mkdir -p $MODPATH/system/app/VoiceTrigger
cd $MODPATH/wenjian1
$MODPATH/txdhhroot/zip -0 -r -q $MODPATH/system/app/VoiceTrigger/VoiceTrigger.apk *
elif [ $Device = "raphael" ]; then
unzip -o -q /system/app/VoiceTrigger/VoiceTrigger.apk -d $MODPATH/wenjian1
mv $MODPATH/wenjian1/classes.dex $MODPATH/wenjian1/classes5.dex
cp -rf $MODPATH/txdhhroot/raphael/classes.dex $MODPATH/wenjian1
mkdir -p $MODPATH/system/app/VoiceTrigger
cd $MODPATH/wenjian1
$MODPATH/txdhhroot/zip -0 -r -q $MODPATH/system/app/VoiceTrigger/VoiceTrigger.apk *
fi
rm -rf $MODPATH/txdhhroot
rm -rf $MODPATH/wenjian1
rm -rf $MODPATH/wenjian  
cp -rf /system/vendor/etc/device_features/* $MODPATH/system/vendor/etc/device_features
cp -rf /system/etc/device_features/* $MODPATH/system/etc/device_features
cp -rf /system/vendor/etc/wifi/WCNSS_qcom_cfg.ini $MODPATH/system/vendor/etc/wifi/WCNSS_qcom_cfg.ini
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_papermode_animation\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_smart_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_paper_eyecare\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <float name=\"paper_eyecare_default_value\">91.0<\/float>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_default_texture\">13<\/integer>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_min_texture\">0<\/integer>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <integer name=\"paper_eyecare_max_texture\">25<\/integer>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_mi_game_countdown\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_mi_game_countdown\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_game_mi_time\">true<\/bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"support_game_mi_time\">true<\/bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/<\/features>/i\    <bool name="support_game_gunsight">true</bool>' $MODPATH/system/etc/device_features/*
sed -i '/<\/features>/i\    <bool name="support_game_gunsight">true</bool>' $MODPATH/system/vendor/etc/device_features/*
sed -i '/gChannelBondingMode5GHz=1/i\gChannelBondingMode24GHz=1' $MODPATH/system/vendor/etc/wifi/WCNSS_qcom_cfg.ini
[[ -e /system/vendor/bin/cnss_diag ]] && mktouch $MODPATH/system/vendor/bin/cnss_diag
mktouch $MODPATH/system/app/Traceur/.replace
mktouch /data/adb/riru/enable_hide
//coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
if [[ "$coolapkTesting" != "" ]];then
am start -d 'coolmarket://u/1168920' >/dev/null 2>&1
fi
