SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/install_MOD.sh
key_source $MODPATH/busybox.sh
key_source $MODPATH/scripts.sh
key_source $MODPATH/sysnc.sh
key_source $MODPATH/thank.sh
set_perm_recursive  $MODPATH/system/bin/qw  0  2000  0755  0755
test -d $MODPATH/busybox && set_perm_recursive $MODPATH/busybox 0 0 0755 0755

