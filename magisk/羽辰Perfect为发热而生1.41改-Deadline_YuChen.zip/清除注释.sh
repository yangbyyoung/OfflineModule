A=/data/adb/modules/YuChen
B=$A/mods
sed -i "s/ #.*//g" $A/service.sh
sed -i "/^#/d" $A/service.sh
sed -i '1i#!/system/bin/sh' $A/service.sh
sed -i "s/ #.*//g" $B/powersave.sh
sed -i "/^#/d" $B/powersave.sh
sed -i "s/ #.*//g" $B/balance.sh
sed -i "/^#/d" $B/balance.sh
sed -i "s/ #.*//g" $B/performance.sh
sed -i "/^#/d" $B/performance.sh
sed -i "s/ #.*//g" $B/fast.sh
sed -i "/^#/d" $B/fast.sh
sed -i "s/ #.*//g" $B/standby.sh
sed -i "/^#/d" $B/standby.sh
rm -rf $A/清除注释.sh