rm -rf /data/media/0/Android/Hc_tombstone
setprop persist.sys.gz.enable true
setprop persist.sys.brightmillet.enable true
setprop persist.sys.powmillet.enable true
setprop persist.sys.millet.newversion true
setprop persist.sys.millet.handshake true