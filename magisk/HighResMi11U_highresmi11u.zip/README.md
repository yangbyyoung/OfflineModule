#Module description
Force High resolution for RAW Format by Arnova8G2