#!/system/bin/sh
id="Electricity-and-Information"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
export PATH=/system/bin:$MODPATH/busybox:$PATH
export TZ=Asia/Shanghai

# >>初始化<<
#当前目录
MODDIR=${0%/*}
#临时目录
tmp_path="$MODDIR/tmp"
#判断临时目录
[[ ! -d $tmp_path ]] && mkdir -p $tmp_path
#充电控制路径
Value="$tmp_path/Value"
Value2="$tmp_path/Value2"
#当前电量
Discharge_time="$tmp_path/time"
Charging_time="$tmp_path/time2"
#通用路径
MODXinXi="${MODPATH}/module.prop"
sdcard="/sdcard/Android"
[[ ! -d $sdcard/设备与电量使用详情/ ]] && mkdir -p /sdcard/Android/设备与电量使用详情

#记录今日重启次数
txt_1="/sdcard/Android/设备与电量使用详情/$(date "+%Y-%m-%d").txt"
[[ ! -d $tmp_path/Restart-Times/ ]] && mkdir -p $tmp_path/Restart-Times
START_LOG="$tmp_path/Restart-Times/$(date "+%Y-%m-%d").log"
if [[ -e $txt_1 ]]; then
	if [[ ! -f $START_LOG ]]; then
		rm -rf $tmp_path/Restart-Times/* >/dev/null
		echo 1 > $START_LOG
		TIMES=1
	else
		TIMES2=`cat $START_LOG`
		TIMES="$(expr $TIMES2 + 1)"
		echo $TIMES > $START_LOG
	fi
	Number=`cat $START_LOG`
	echo "$(date '+%T') 今日设备已重启 $Number 次" >> $txt_1
fi
# <<初始化完成>>

#判断文件是否存在 是则打开(cat) 否则返回信息
Read() {
	[[ -f $1 ]] && cat $1 || echo "缺少$1"
}

#输出时间与信息
log() {
	echo "$(date '+%T') $1: $2" >> $3
}
log2() {
	echo "$1 [$(date '+%T')] $2" >> $3
}

#获取电池充放电信息
Power_value() {
	Read /sys/class/power_supply/$2/uevent | grep "$1" | sed 's/=/= /g' | awk '{print $2}'
}

#计算总体时长耗时
endtime() {
	case $1 in
	1) starttime=$starttime ;;
	2) starttime=$(Read $2 | awk '{print $2}''{print $3}') ;;
	esac
	endtime=$(date "+%Y-%m-%d %H:%M:%S")
	duration=$(echo $(($(date +%s -d "${endtime}") - $(date +%s -d "${starttime}"))) | awk '{t=split("60 秒 60 分 24 时 999 天",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}')
	[[ -n $duration ]] && echo "耗时:$duration" || echo "耗时:0秒"
}

#调试
debug="$MODDIR/debug.conf"
function settings() {
	Read $debug | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}




#echo "#!/system/bin/sh
#. ${0%/*}/tools/bin.sh
#aosp=${0%/*}/aosp_mod.sh
#Add_path" > $sdcard/啟動.sh

#echo 'if [[ $(pgrep -f "aosp_mod.sh" | grep -v 'grep' | wc -l) == 0 ]]; then
#    busybox sh $aosp start &
#else
#    busybox sh $aosp stop &
#fi' >> $sdcard/啟動.sh

#if [[ $1 == stop ]]; then
#    log "aosp_mod.sh" "你終止了程序" "$txt" 
#    kill -9 $(pgrep -f "aosp_mod.sh" | grep -v 'grep') >/dev/null    
#else
#    if [[ $1 == start ]]; then
#        log "aosp_mod.sh" "收到start 執行中..." "$txt" 
#    else
#        log "aosp_mod.sh" "請輸入操作 stop or start" "$txt" 
#        exit 1
#    fi
#fi




#开始循环
while :;do

##初始化: 防止误删/不存在
#判断临时目录
[[ ! -d $tmp_path ]] && mkdir -p $tmp_path
#判断主记录目录和记录文件
[[ ! -d $sdcard/设备与电量使用详情/ ]] && mkdir -p $sdcard/设备与电量使用详情
txt="$sdcard/设备与电量使用详情/$(date "+%Y-%m-%d").txt"
[[ ! -e $txt ]] && $MODDIR/Equipment_Details.sh | sh $MODDIR/Equipment_Details.sh

#判断亮屏/息屏
screen=$(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2)
[[ $screen == true ]] && M="息屏" || M="亮屏"
#判断设备温度
gs=$(($(dumpsys battery | awk '/temperature/{print $2}') / 10))

#充电端电压电流
charge_a=$(echo $(Power_value "INPUT_CURRENT_NOW=" usb) | awk '{printf "%.3f", $1/1000000}')
charge_v=$(echo $(Power_value "POWER_SUPPLY_VOLTAGE_NOW=" usb) | awk '{printf "%.3f", $1/1000000}')
#本机端电压电流
Charge_v=$(echo $(Power_value "POWER_SUPPLY_VOLTAGE_NOW=" bms) | awk '{printf "%.3f", $1/1000000}')
Charge=$(echo $(Power_value "POWER_SUPPLY_CURRENT_NOW=" bms) | awk '{printf "%.0f", $1/1000}')
power3=$(echo $Charge | sed 's/-//g')
#充电状态
status=$(dumpsys battery | awk '/status/{print $2}')
Powerstate=$(dumpsys battery | awk '/level/{print $2}')

	if [[ $(dumpsys battery | awk '/status/{print $2}') == 2 ]]; then
		#记录充电中
		[[ ! -e $Charging_time ]] && echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Charging_time
		if [[ ! $(Read $Charging_time | awk '{print $1}') == $Powerstate ]]; then
			protocol_xs=$(Power_value "POWER_SUPPLY_TYPE=" usb)
			log "充电中($M)" "协议:$protocol_xs 电量:$Powerstate% ${charge_v}V ${power3}mA $gs℃ $(Read $Charging_time | awk '{print $1}')%>$Powerstate% $(endtime 2 $Charging_time)" "$txt"
			sed -i "/^description=/c description=充电中($M): 协议:$protocol_xs 电量:$Powerstate% ${charge_v}V ${power3}mA $gs℃ $(Read $Charging_time | awk '{print $1}')%>$Powerstate% $(endtime 2 $Charging_time)" "$MODXinXi"
			echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Charging_time
			rm -rf $Discharge_time
		fi
		#记录充电开始时间
		[[ ! -e $Value ]] && echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Value
		if [[ -e $Value2 ]]; then
			value_2=$(Read $Value2 | awk '{print $1}')
			valuee_2=$(($value_2 - $Powerstate))％
			log2 ">>开始充电<<" "上次电量:$value_2％ > $Powerstate％ 减少$valuee_2 放电共$(endtime 2 $Value2)" "$txt" "1"
			sed -i "/^description=/c description=开始充电: 上次电量:$value_2％ > $Powerstate％ 减少$valuee_2 放电共$(endtime 2 $Value2)" "$MODXinXi"
			echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Charging_time
			rm -rf $Value2
		fi
	else
		#记录放电开始时间
		[[ ! -e $Discharge_time ]] && echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Discharge_time
		if [[ ! $(Read $Discharge_time | awk '{print $1}') == $Powerstate ]]; then
			log "放电中" "电量:$Powerstate% ${Charge_v}V $gs℃ $(Read $Discharge_time | awk '{print $1}')%>$Powerstate% $(endtime 2 $Discharge_time)" "$txt"
			sed -i "/^description=/c description=放电中: 电量:$Powerstate% ${Charge_v}V $gs℃ $(Read $Discharge_time | awk '{print $1}')%>$Powerstate% $(endtime 2 $Discharge_time)" "$MODXinXi"
			echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Discharge_time
			rm -rf $Charging_time
		fi
		#记录充电结束
		[[ ! -e $Value2 ]] && echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Value2
		if [[ -e $Value ]]; then
			value_2=$(Read $Value | awk '{print $1}')
			valuee_2=$(($Powerstate - $value_2))％
			log2 "<<结束充电>>" "本次电量:$value_2％ > $Powerstate％ 增加$valuee_2 充电共$(endtime 2 $Value)" "$txt" "1"
			sed -i "/^description=/c description=结束充电: 本次电量:$value_2％ > $Powerstate％ 增加$valuee_2 充电共$(endtime 2 $Value)" "$MODXinXi"
			echo "$Powerstate $(date +"%Y-%m-%d %H:%M:%S")" > $Discharge_time
			rm -rf $Value
		fi
	fi

	#循环时间
	[[ -f $debug ]] && sleep $(settings sleep) || sleep 10s
done

