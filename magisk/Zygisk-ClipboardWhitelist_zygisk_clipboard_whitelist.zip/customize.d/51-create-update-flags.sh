# Create flags that indicate module updated or installed

ui_print "- Reset installed flags"

touch "$MODPATH/.module_updated"
