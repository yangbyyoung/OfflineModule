if [ -d "${0%/*}/alpine" ];then
if [ "$(getprop sys.boot_completed)" != "1" ];then
rm -rf /data/alpine
mv ${0%/*}/alpine /data
${0%/*}/init "/data/alpine"
else
${0%/*}/init "${0%/*}/alpine"
fi
fi
