#!/sbin/sh

rm -rf /data/system/package_cache/*
rm -rf /storage/emulated/0/Android/MIUI12.5+/