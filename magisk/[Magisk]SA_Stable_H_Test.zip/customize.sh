#!/sbin/sh
SKIPUNZIP=0
AUTOMOUNT=true
ROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE="
/system/priv-app/OPNetworkSetting
/system/app/OPTelephonyCollectionData
/system/system_ext/priv-app/OPNetworkSetting
/system/system_ext/app/OPEngMode
"
  ui_print "///解压文件ing///解压完成///重启使用///😘😘😘"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2