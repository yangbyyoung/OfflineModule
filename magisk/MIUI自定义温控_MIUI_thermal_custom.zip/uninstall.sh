#test

function unlock_thermal(){
local target="${1}" 
/data/adb/magisk/busybox chattr -R -i "${target}" >/dev/null 2>&1
/data/adb/magisk/busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
busybox chattr -R -i "${target}" >/dev/null 2>&1
busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
chattr -R -i "${target}" >/dev/null 2>&1
chattr -R -i "${target%/*}" >/dev/null 2>&1
rm -rf "${target}"/*
}


function running_uninstall(){
unlock_thermal "/data/thermal/config"
unlock_thermal "/data/vendor/thermal/config"
am broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
}



( running_uninstall &)

