function white_list()
{
  pgrep -o  -n $1 | while read pid; do
  echo $pid > /dev/cpuset/audio-app/cgroup.procs
  echo $pid > /dev/cpuset/audio-app/cgroup.procs
  echo $pid > /dev/cpuset/system-background/cgroup.procs
   renice -n -10 -p $pid
  done
}

white_list launcher
white_list com.android.wallpaper.livepicker