#!/system/bin/sh

MODDIR=${0%/*}
setenforce 1
echo 1 >/sys/fs/selinux/enforce
sleep 7
MODDIR=${0%/*}
setenforce 0
echo 0 >/sys/fs/selinux/enforce
sleep 30
MODDIR=${0%/*}
setenforce 1
echo 1 >/sys/fs/selinux/enforce