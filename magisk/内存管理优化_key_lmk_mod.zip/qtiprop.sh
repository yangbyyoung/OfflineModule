#!/system/bin/sh
function delete_qti_value() {
local file="$1"
local list="
ro.vendor.qti.sys.fw.bservice_enable
ro.vendor.qti.sys.fw.use_trim_settings
ro.sys.fw.bg_apps_limit
ro.vendor.qti.sys.fw.bg_apps_limit
ro.vendor.qti.sys.fw.bservice_limit
ro.vendor.qti.sys.fw.bservice_age
ro.vendor.qti.sys.fw.empty_app_percent
ro.vendor.qti.sys.fw.trim_empty_percent
ro.vendor.qti.sys.fw.trim_cache_percent
ro.vendor.qti.sys.fw.trim_enable_memory
ro.vendor.qti.core_ctl_min_cpu
ro.vendor.qti.core_ctl_max_cpu
"
	for value in $list
	do
		sed -i "/$value/d" "$file"
	done
}

qualcomm_prop=`getprop | egrep -w "qualcomm|qti" | wc -l`
qualcomm_package=`pm list package -s | egrep -w "qualcomm|qti" | wc -l`
if test $qualcomm_prop -lt 1 -a $qualcomm_package -lt 1 ;then 
	echo "- 非高通骁龙设备！删除有关的prop值 !"
	delete_qti_value "$MODPATH/system.prop"
else 
	return 0
fi



