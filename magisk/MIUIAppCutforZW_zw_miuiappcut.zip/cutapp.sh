#!/system/bin/sh
MODDIR=${0%/*}

cutapp() {
for cutapp_path in $(find /system -type d -iname "$1" 2>/dev/null | sed -e '/\/bin/ d' -e '/\/etc/ d' -e '/\/lib/ d' -e '/\/lib64/ d' -e '/\/media/ d');do
  if [[ ! -f "$MODDIR/$cutapp_path/.replace" ]];then
     [[ ! -d "$MODDIR/$cutapp_path" ]] && mkdir -p "$MODDIR/$cutapp_path" 2>/dev/null
     touch "$MODDIR/$cutapp_path/.replace"
     [[ $? == 0 ]] && chmod 644 "$MODDIR/$cutapp_path/.replace" || { rm -rf "$MODDIR/$cutapp_path";return 0;}
     [[ ! -f "$MODDIR/$cutapp_path/${2}.txt" && -n "${2}" ]] && touch "$MODDIR/$cutapp_path/${2}.txt"
  fi
done
}

collatelog() {
num=1
echo "   *** 已生效的屏蔽APP列表 ***" >$MODDIR/cutapp_list.txt
echo "  (整理于$(date +"%Y年%m月%d日%T"))" >>$MODDIR/cutapp_list.txt
echo "">>$MODDIR/cutapp_list.txt
for cutapp_name_1 in $(find $MODDIR/system -type f -iname ".replace" 2>/dev/null);do
  cutapp_name_2=${cutapp_name_1%/*}
  cutapp_name_3=$(find $cutapp_name_2 -type f -iname "*.txt" 2>/dev/null)
  if [[ -n $cutapp_name_3 ]];then
    cutapp_name_4=${cutapp_name_3%\.*}
    cutapp_name_5=${cutapp_name_4##*/}
  else
    cutapp_name_5="-"
  fi
  echo "${num}、${cutapp_name_5}  ${cutapp_name_2#*zw_miuiappcut}" >>$MODDIR/cutapp_list.txt
  num=$(($num+1))
done
}

for temp_cutapp_1 in $(cat $MODDIR/cutapp.txt);do
  temp_cutapp_2=$(echo $temp_cutapp_1 | $(magisk --path)/.magisk/busybox/awk -F ';' '{print $1,$2}')
  cutapp $temp_cutapp_2 &
done
wait;collatelog

# 屏蔽mdnsd;多播DNS查询服务
test -f /system/bin/mdnsd -a -s /system/bin/mdnsd && { mkdir -p "$MODDIR/system/bin";touch "$MODDIR/system/bin/mdnsd";echo "${num}、多播DNS查询服务A  /system/bin/mdnsd" >>$MODDIR/cutapp_list.txt;}
test -f /system/etc/init/mdnsd.rc -a -s /system/etc/init/mdnsd.rc && { mkdir -p "$MODDIR/system/etc/init";touch "$MODDIR/system/etc/init/mdnsd.rc";num=$(($num+1));echo "${num}、多播DNS查询服务B  /system/etc/init/mdnsd.rc" >>$MODDIR/cutapp_list.txt;}
# 屏蔽cnss_diag;高通Wifi日志抓取服务，解决wlan_logs写入问题
test -f /system/vendor/bin/cnss_diag -a -s /system/vendor/bin/cnss_diag && { mkdir -p "$MODDIR/system/vendor/bin";touch "$MODDIR/system/vendor/bin/cnss_diag";num=$(($num+1));echo "${num}、高通Wifi日志抓取服务  /system/vendor/bin/cnss_diag" >>$MODDIR/cutapp_list.txt;}

rm -r /data/adb/service.d/appcut_service.sh 2>/dev/null
reboot