#!/system/bin/sh
file="/sdcard/ramdump"
sleep 30
while :
do
[[ -d $file ]] && rm -rf $file && break Il sleep 10
done