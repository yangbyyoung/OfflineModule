#!/system/bin/sh
SKIPUNZIP=0
ASH_STANDALONE=0

name="`grep_prop name $TMPDIR/module.prop`"
author="`grep_prop author $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"

echo "*********************"
echo "- 模块信息"
echo "- 名称: $name"
echo "- 作者：$author"
echo "- $description"

REPLACE="
/system/app/PowerKeeper
/system/app/Joyose
"

#卸载旧模块
echo "- "
echo "- 检测旧模块~"
sleep 1
modfile=/data/adb/modules/Mi12_TemperatureControl
if [ ! -d $modfile ];then
echo "- 未发现旧模块，继续为你安装模块！"
else
echo "- 检测到你安装有旧版"
sh $modfile/uninstall.sh
echo "- 避免新旧版冲突，已为你卸载旧版模块！"
fi
echo "- "
echo "- 安装模块~"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
mkdir $MODPATH/backup
cp -f /data/vendor/thermal/config/* $MODPATH/backup/
rm -rf /data/vendor/thermal/config
mkdir /data/vendor/thermal/config
cp -rf $MODPATH/cloud/* /data/vendor/thermal/config/
cp -rf $MODPATH/system/* /data/vendor/thermal/config/
chattr -R -i /data/vendor/thermal/config/*
chattr +i /data/vendor/thermal/config/*
chattr +i /data/vendor/thermal/config
chmod 777 /data/vendor/thermal/config/*
chmod 777 /data/vendor/thermal/config
set_perm_recursive $MODPATH 0 0 0755 0644