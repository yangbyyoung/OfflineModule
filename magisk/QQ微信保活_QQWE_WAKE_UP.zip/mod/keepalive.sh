
for i in com.tencent.mobileqq com.tencent.mm ;do
	pgrep -f "$i" | while read pid ;do
		echo -17 > /proc/$pid/oom_adj
	done
done
