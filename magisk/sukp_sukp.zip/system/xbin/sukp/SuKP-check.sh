#!/system/bin/sh
echo "===SuKP v1.1==="
echo "===by supppig==="
getbackstring()
{
[ -z "$ss" ] && str=$($1) || str=$ss && ss=""
f="0" && re=""
for x in $str
do
if [ "$f" = "0" ];then
f="0" && [ "$x" = "$2" ] && f="1"
else
ff="1" && for xx in $3;do [ $x = $xx ] && ff="0";done
if [ "$ff" = "1" ];then
[ -z "$re" ] && re=$x || re=$re" "$x
fi
f="0"
fi
done
[ -z "$re" ] && re=$4
}
findstring()
{
iptables -t $1 | ${bgrep} -q "$2" && re="$3" || re="$4"
[ "$5" = "y" ] && echo "$re"
}
findstringbyss()
{
if [ "$ss" = "" ];then
re="$2"
reb="n"
else
re="$1"
reb="y"
fi
ss=""
[ "$3" = "y" ] && echo "$re"
[ "$3" = "yn" ] && echo -n "$re"
}
cbbx()
{
type $1 2>&- >&-
if [ "$?" = "0" ];then
eval b$1=$1
else
eval b$1=\"$bbx $1\"
fi
}
DIR="${0%/*}"
cd $DIR
bbx=${DIR}'/KoolProxy/busybox'
kpdir=${DIR}'/KoolProxy'
cbbx grep
cbbx cut
cbbx pidof
. ./SuKP-setting.ini
echo "=====广告过滤====="
kpversion='v'$($kpdir/koolproxy -v)
${bpidof} 'koolproxy' >/dev/null && echo "插件：✔kooolproxy ($kpversion)"||echo "插件：✘koolproxy ($kpversion)"
${bpidof} 'koolproxy' >/dev/null && kprunning="y" || kprunning="n"
if [ "$kprunning" = "y" ];then
echo -n "过滤范围："
ss=$(iptables -t nat -S OUTPUT | ${bgrep} 'ad_block')
if [ "$ss" = "" ];then
bdgl_c="n"
echo -n "✘数据  ✘WiFi  "
else
bdgl_c="y"
ss=$(iptables -t nat -S OUTPUT | ${bgrep} 'ad_block' | ${bgrep} -v wlan)
findstringbyss "✔" "✘"
echo -n "$re数据  "
x=$(iptables -t nat -S ad_block | ${bgrep} 'wlan' | ${bgrep} '\-s')
if  [ "$x" = "wlan" ];then
echo -n "✘WiFi  "
wifiadb_c="n"
else
echo -n "✔WiFi  "
wifiadb_c="y"
fi
fi
ss=$(iptables -t nat -S PREROUTING | ${bgrep} '8080' | ${bgrep} '3000')
findstringbyss "✔" "✘"
echo "$re热点"
#bdgl_c=y才有继续的价值
if [ "$bdgl_c" = "y" ];then
ss=$(iptables -t nat -S ad_block | ${bgrep} tcp | ${bgrep} -v uid | ${bgrep} 3000)
findstringbyss "└过滤模式：全局过滤" "└过滤模式：过滤指定应用" "y"
[ "$reb" = "y" ] && pstr="└不过滤应用：" || pstr="└过滤应用："
[ "$reb" = "y" ] && x="" || x="未设置(设置不合理)"
ss=$(iptables -t nat -S ad_block | ${bgrep} tcp | ${bgrep} uid)
getbackstring "" "--uid-owner" "0-9999" "$x"
if [ "$re" != "" ];then
echo "${pstr}${re}"
fi
ss=$(iptables -t nat -S ad_block | ${bgrep} -v tcp | ${bgrep} uid)
getbackstring "" "--uid-owner" "0-9999" "$x"
if [ "$re" != "" ];then
echo "└VPN软件：${re}"
fi
if [ "$wifiadb_c" = "y" ];then
ss=$(iptables -t nat -S ad_block)
getbackstring "" "-s" "" ""
if [ "$re" != "" ];then
echo "└WiFi放行白名单："$re
fi
fi
fi
echo ""
str=$(${bgrep} '^!x.*rules' -m1 $kpdir/rules/koolproxy.txt | ${bgrep} -o '20[0-9\|-]\{6,8\}\ \([0-9]\)\{1,2\}:[0-9]\{1,2\}')
[ "$str" != "" ] && echo "静态规则更新日期：$str"
str=$(${bgrep} '^!x.*video' -m1 $kpdir/rules/koolproxy.txt | ${bgrep} -o '20[0-9\|-]\{6,8\}\ \([0-9]\)\{1,2\}:[0-9]\{1,2\}')
[ "$str" != "" ] && echo "视频规则更新日期：$str"
str=$(${bgrep} -v '^!' $kpdir/rules/koolproxy.txt | ${bgrep} -v '^$' | ${bwc} -l)
[ "$str" != "" ] && echo "有效规则：$str条"
[ "$kpupstr" != "" ] && echo -e $kpupstr
fi
echo ""
echo ✺ nat表 ad_block链:
iptables -t nat -S ad_block
echo ""
echo ✺ nat表 OUTPUT链:
iptables -t nat -S OUTPUT
echo ""
echo ✺ nat表 PREROUTING链:
iptables -t nat -S PREROUTING
