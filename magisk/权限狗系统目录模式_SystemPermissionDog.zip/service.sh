MODDIR="${0%/*}"
mount -t overlay -o lowerdir=/system/etc/permissions/privapp-permissions-PermissionDog.xml,upperdir=$MODDIR/system/etc/permissions/privapp-permissions-PermissionDog.xml,workdir=$MODDIR/worker KSU /system
mount -t overlay -o lowerdir=/system/priv-app/PermissionDog/,upperdir=$MODDIR/system/priv-app/PermissionDog/,workdir=$MODDIR/worker KSU /system
