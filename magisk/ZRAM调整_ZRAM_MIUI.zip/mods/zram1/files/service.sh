#!/system/bin/sh
MODDIR=${0%/*}
M=$(free -m|grep "Mem"|awk '{print $2}' ) 
echo $Z
sleep 10
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo $(echo $M/2 |bc)M> /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0