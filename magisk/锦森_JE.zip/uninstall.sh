#!/system/bin/sh
chattr -i /data/system/mcd/df
pm clear com.xiaomi.joyose
pm clear com.xiaomi.powerchecker
am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
sleep 2s
am force-stop com.xiaomi.joyose
rm -f /cache/miui-thermal/*
rm -f /data/vendor/thermal/config/*
rm -f /data/system/package_cache/*
cp /vendor/etc/thermal*.conf /data/vendor/thermal/config/

