MODDIR=${0%/*}

rm -rf /data/adb/jshook
