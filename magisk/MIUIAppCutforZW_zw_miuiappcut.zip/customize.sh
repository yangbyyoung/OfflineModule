##########################################################################################
#
# Magisk模块安装脚本
#
##########################################################################################
##########################################################################################
#
# 使用说明:
#
# 1. 将文件放入系统文件夹(删除placeholder文件)
# 2. 在module.prop中填写您的模块信息
# 3. 在此文件中配置和调整
# 4. 如果需要开机执行脚本，请将其添加到post-fs-data.sh或service.sh
# 5. 将其他或修改的系统属性添加到system.prop
#
##########################################################################################
##########################################################################################
#
# 安装框架将导出一些变量和函数。
# 您应该使用这些变量和函数来进行安装。
#
# !请不要使用任何Magisk的内部路径，因为它们不是公共API。
# !请不要在util_functions.sh中使用其他函数，因为它们也不是公共API。
# !不能保证非公共API在版本之间保持兼容性。
#
# 可用变量:
#
# MAGISK_VER (string):当前已安装Magisk的版本的字符串(字符串形式的Magisk版本)
# MAGISK_VER_CODE (int):当前已安装Magisk的版本的代码(整型变量形式的Magisk版本)
# BOOTMODE (bool):如果模块当前安装在Magisk Manager中，则为true。
# MODPATH (path):你的模块应该被安装到的路径
# TMPDIR (path):一个你可以临时存储文件的路径
# ZIPFILE (path):模块的安装包（zip）的路径
# ARCH (string): 设备的体系结构。其值为arm、arm64、x86、x64之一
# IS64BIT (bool):如果$ARCH(上方的ARCH变量)为arm64或x64，则为true。
# API (int):设备的API级别（Android版本）
#
# 可用函数:
#
# ui_print <msg>
#     打印(print)<msg>到控制台
#     避免使用'echo'，因为它不会显示在定制recovery的控制台中。
#
# abort <msg>
#     打印错误信息<msg>到控制台并终止安装
#     避免使用'exit'，因为它会跳过终止的清理步骤
#
##########################################################################################

##########################################################################################
# 变量
##########################################################################################

# 如果您需要更多的自定义，并且希望自己做所有事情
# 请在custom.sh中标注SKIPUNZIP=1
# 以跳过提取操作并应用默认权限/上下文上下文步骤。
# 请注意，这样做后，您的custom.sh将负责自行安装所有内容。
SKIPUNZIP=1
# 如果您需要调用Magisk内部的busybox
# 请在custom.sh中标注ASH_STANDALONE=1
ASH_STANDALONE=0
# 已安装模块路径
MODDIR=$(echo $MODPATH | sed "s/modules_update/modules/")

##########################################################################################
# 安装设置
##########################################################################################

# 如果SKIPUNZIP=1你将可能会需要使用以下代码
# 当然，你也可以自定义安装脚本，需要时请删除#
# 将 $ZIPFILE 提取到 $MODPATH
#  ui_print "- 解压模块文件"
#  unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
# 删除多余文件
# rm -rf \
# $MODPATH/system/placeholder $MODPATH/customize.sh \
# $MODPATH/*.md $MODPATH/.git* $MODPATH/LICENSE 2>/dev/null

ui_print "

    #######################################
                MIUIAppCut for ZW
                    乐阿兰那
    #######################################
       基于我多年的MIUI APP精简积累制作；中度精简！
    刷入前务必根据自己需要修改cutapp.txt文件！！模
    块安装后，以及双数月(2月、4月...)均执行一次。
    【原理】读取cutapp.txt，搜索/system中是否有对
    应APP，有则建立屏蔽文件夹。
            **************************
    【提醒】模块安装过程中将检测手机是否已经进行了破
    解卡米操作，需要耗时1~3分钟！！！未破解卡米的手
    机不适合使用本模块，强制使用可能导致变砖！
    #######################################

"
stop_install() {
test $BOOTMODE && { touch disable $MODDIR;ui_print "-   【提醒】检测到安装有旧版模块，已禁用！";}
abort "-   模块安装程序终止"
}
# 清理旧cutapp文件夹
test $BOOTMODE && { rm -rf $MODDIR/system 2>/dev/null;rm -rf $MODPATH/system 2>/dev/null;}
# 将 $ZIPFILE 提取到 $MODPATH
ui_print "-   开始解压模块文件"
unzip -qo "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
# 检测是否已破解卡米
ui_print "-   开始检测手机是否已经进行了破解卡米操作，耗时1~3分钟！"
test -z "$(which dexdump)" &&  { ui_print "-   没有dexdump命令，无法解包classes*.dex文件";stop_install;}
services_path=$(find / -type f -iname "services.jar" 2>/dev/null)
test -z "$services_path" && { ui_print "-   没有services.jar文件，无法检测是否已经破解卡米";stop_install;}
services_size=$(/system/bin/ls -l /system/framework/services.jar | cut -f5 -d ' ')
test "$services_size" -le "4000000" && { ui_print "-   services.jar小于4MB，未合并odex";stop_install;}
unzip -qo "$services_path" classes.dex classes2.dex -d $TMPDIR >&2
jckm_1=$(dexdump -d $TMPDIR/classes*.dex | grep -f $MODPATH/jckm.txt | wc -l)
test "$jckm_1" -ge "1" &&  { ui_print "-   没有事先破解卡米，模块不适用！！！";stop_install;} ||
ui_print "-   恭喜！！已实现破解卡米，模块适用！"
# 拷贝appcut_service.sh至service.d文件夹
ui_print "-   为第一次执行做准备"
cp -f $MODPATH/appcut_service.sh /data/adb/service.d/appcut_service.sh

##########################################################################################
# 权限设置
##########################################################################################
# 请注意，magisk模块目录中的所有文件/文件夹都有$MODPATH前缀-在所有文件/文件夹中保留此前缀
# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644
chmod -R 775 $MODPATH
chmod 775 /data/adb/service.d/appcut_service.sh
test $? == 0 && ui_print "-   准备完毕，将在重启后执行"

#################################
# 删除多余文件
#################################
rm -rf $MODPATH/customize.sh $MODPATH/*.md $MODPATH/jckm.txt $MODPATH/appcut_service.sh 2>/dev/null