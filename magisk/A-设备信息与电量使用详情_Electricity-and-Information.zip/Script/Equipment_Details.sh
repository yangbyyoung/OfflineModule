#!/system/bin/sh

id="Electricity-and-Information"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
export PATH=/system/bin:$MODPATH/busybox:$PATH
export TZ=Asia/Shanghai


MODDIR=${0%/*}

My_grep_prop() {
  local REGEX="s/$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop /vendor/build.prop /product/build.prop'
  sed -n "$REGEX" $FILES 2>/dev/null | head -n 1
}

#打开文件
Read() {
  [[ -f $1 ]] && cat $1
}

#读取Magisk的util_functions.sh
#magisk_util_functions="/data/adb/magisk/util_functions.sh"
#function settings() {
#  Read $magisk_util_functions | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
#}

KS="/sys/class/power_supply"
MODEL="$(My_grep_prop 'ro\.product\.model')"
[[ -z $MODEL ]] && MODEL="$(My_grep_prop 'ro\.product\.vendor\.model')"
MANUFACTURER="$(My_grep_prop 'ro\.product\.manufacturer')"
[[ -z $MANUFACTURER ]] && MANUFACTURER="$(My_grep_prop 'ro\.product\.vendor\.manufacturer')"
#电池容量
[[ -e $KS/bms/charge_full ]] && Battery_capacity="$(($(cat $KS/bms/charge_full) / 1000))mAh" || Battery_capacity="淦 找不到相关信息"
#闪存颗粒
[[ -e /proc/scsi/scsi ]] && UFS_MODEL=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $2}') && Particles=$(sed -n 3p /proc/scsi/scsi | awk '/Vendor/{print $4}') || UFS_MODEL="unknown"
#闪存类型
[[ -e /sys/block/sda/size ]] && ROM_TYPE="UFS" || ROM_TYPE="eMMC"
#电池循环次数
[[ -e $KS/battery/cycle_count ]] && CYCLE_COUNT="$(Read $KS/battery/cycle_count) 次" || CYCLE_COUNT="淦 找不到相关信息"
#MIUI版本
MIUI=$(getprop ro.miui.ui.version.name)
[[ -z $MIUI ]] && MIUI="你这是啥版本！？"

txt3="/sdcard/Android/设备与电量使用详情/$(date "+%Y-%m-%d").txt"
echo "– 品牌: $MANUFACTURER
– 型号: $MODEL
– 代号: $(getprop ro.product.device) 
– MIUI版本: $MIUI
– Android版本: $(getprop ro.build.version.release)
– RAM: $(Read /proc/meminfo | head -n 1 | awk '{print $2/1000}')MB
– SDK: $(getprop ro.build.version.sdk)
– CPU: $(getprop ro.board.platform) $(($(Read /sys/devices/system/cpu/kernel_max) + 1))核心
– 架构: $(getprop ro.product.cpu.abi)
– 闪存类型: $ROM_TYPE
– 闪存颗粒: $UFS_MODEL $Particles
– 内核版本: $(uname -r) 
– 电池循环次数: $CYCLE_COUNT
– 电池容量(内核记录数据): $Battery_capacity
– Magisk版本: [$(magisk -v)] ($(magisk -V))
------------------------------------------------------------------" > $txt3

#START_LOG="$MODDIR/Script_Record.log"
#ECHO_MESSAGE() {
#	echo "$(date '+%T') $@" >> $MESSAGE
#}

#[[ ! -d $MODDIR/tmp ]] && mkdir -p $MODDIR/tmp
#if [[ ! -f $START_LOG ]]; then
#	echo 1 > $START_LOG
#	TIMES=1
#else
#	TIMES2=`cat $START_LOG`
#	TIMES="$(expr $TIMES2 + 1)"
#	echo "$TIMES" > "$START_LOG"
#fi

#Number=`cat $START_LOG`
#MODXinXi="/data/adb/modules/Small-Optimization/module.prop"
#输出到/sdcard/Android/MIUI小优化配置
#ECHO_MESSAGE ">> Small-Optimization 初始化完成 <<"
#ECHO_MESSAGE "已正常运行 $Number 次"
#输出修改$MODXinXi 路径文件指定文字行的内容
#sed -i "/^description=/c description=“ 提高系统稳定性，优化系统流畅度？” 配置文件 >> [[ /sdcard/Android/MIUI小优化配置/ ]] << 已正常运行 $Number 次" "$MODXinXi"
