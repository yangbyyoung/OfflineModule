#!/system/bin/sh

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

find /system /system_ext /vendor /product -iname '*thermal*.conf' -type f | sed '/thermal-map.*.conf/d'  2> /dev/null | while read file ;do
	echo "$( correctpath "$file" )" >> "$TMPDIR/thermal_list.txt"
done

echo "$(cat "$TMPDIR/thermal_list.txt" | sort | uniq )" > "$TMPDIR/thermal_list.txt"

for i in $(ls $MODPATH/system/vendor/etc)
do
	sed -i "/$i/d" "$TMPDIR/thermal_list.txt"
done

cat "$TMPDIR/thermal_list.txt" | while read file ;do
		mkdir -p "${MODPATH}/${file%/*}"
	cp -rf "${MODPATH}/system/vendor/etc/thermal-normal.conf" "$MODPATH/${file}"
done

rm -rf /data/vendor/thermal
mkdir -p /data/vendor/thermal/config

cp -rf $MODPATH/system/vendor/etc/* /data/vendor/thermal/config

