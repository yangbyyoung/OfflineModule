SKIPUNZIP=1

ZYGISK_MODULE_LIB_NAME=cleanerhooks

# Extract verify.sh
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort "*********************************************************"
fi
. $TMPDIR/verify.sh

# Extract util_functions.sh
ui_print "- Extracting util_functions.sh"
extract "$ZIPFILE" 'util_functions.sh' "$TMPDIR"
. $TMPDIR/util_functions.sh

# Functions from util_functions.sh (it will be loaded by riru.sh)
check_android_version
check_magisk_version
enforce_install_from_magisk_app

# Check architecture
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

# Extract libs
ui_print "- Extracting module files"

extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'service.sh' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"

# Riru v24+ load files from the "riru" folder in the Magisk module folder
# This "riru" folder is also used to determine if a Magisk module is a Riru module

mkdir "$MODPATH/zygisk"

if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ]; then
  extract_library 'armeabi-v7a'
  if [ "$IS64BIT" = true ]; then
    extract_library 'arm64-v8a'
  fi
fi

if [ "$ARCH" = "x86" ] || [ "$ARCH" = "x64" ]; then
  extract_library 'x86'
  if [ "$IS64BIT" = true ]; then
    extract_library 'x86_64'
  fi
fi

extract "$ZIPFILE" 'cleaner.dex' "$MODPATH"

set_perm_recursive "$MODPATH" 0 0 0755 0644
