OK=$(sed -n '2p' /data/powercfg.sh)
if [ $OK = '#羽辰Perfect调度' ];then
rm -rf /data/powercfg.*
fi