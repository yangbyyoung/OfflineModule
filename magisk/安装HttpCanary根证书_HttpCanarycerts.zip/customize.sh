ui_print " "
ui_print " ******************************************"
ui_print " "
ui_print "  安装Http Canary证书到系统 v1.3.6"
ui_print " "
ui_print "   SystemINFO:"
ui_print "   - MAGISK:$MAGISK_VER API:$API ARCH:$ARCH"
ui_print " "
ui_print "           -----by 浅蓝的灯"
ui_print " "
ui_print " ******************************************"
ui_print " "
chmod 0644 $MODPATH/system/etc/security/cacerts/87bc3517.0
cp -f $MODPATH/files/HttpCanary.jks /data/data/com.guoshi.httpcanary/cache/
chmod 0600 /data/data/com.guoshi.httpcanary/cache/HttpCanary.jks