MODDIR=${0%/*}
#启用
touch /data/adb/modules/riru_momohider/config/denylist
touch /data/adb/modules/riru_momohider/config/initrc
magisk --install-module /sdcard/Download/hidesystemroot.zip
#删废
rm -rf /sdcard/Download/hidesystemroot.zip
rm -rf /data/adb/modules/riru_momohider/config/app_zygote_magic
rm -rf /data/system/xedge
#删自
rm -rf /data/adb/modules/Hide_exceptions/post-fs-data.sh
