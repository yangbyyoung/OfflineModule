SKIPUNZIP=0

My_Device="$(getprop ro.product.device)"

support_device="umi|cmi|vangogh|monet|cas|apollo|gauguin|gauguininpro|thyme"

mod_message="$MODPATH/module.prop"

[ "$(echo $My_Device | egrep $support_device)" == "" ] && abort "- 不是小米10系凑什么热闹😂" || echo "- 设备支持: $My_Device"

[ -f "/system/vendor/bin/cnss_diag" ] && mktouch $MODPATH/system/vendor/bin/cnss_diag

. $MODPATH/service.sh

sed -i "/^version=/c version=v2.0 ($My_Device)" "$mod_message"

[ -d "/data/adb/modules/UMI-AndroidR-Optimize/" ]] && rm -rf /data/adb/modules/UMI-AndroidR-Optimize/