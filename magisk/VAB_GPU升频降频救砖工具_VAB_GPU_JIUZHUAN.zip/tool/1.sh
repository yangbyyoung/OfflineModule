MODPATH=${0%/*}
LOG=$MODPATH/num
for i in $(seq 1 $1)  
 do   
 if [[ `getprop init.svc.bootanim` = "stopped" ]]; then
    if [[ ! -f $LOG ]]; then
        echo "0" >$LOG
     fi
    sed -i "/^description=/c description=先刷入本模块，备份最开始能开机的数据，可以不用重启，然后就可以在KonaBess调参数，在KonaBess选择打包并刷入新镜像，重启调试，如果卡开机一分钟会自动还原，耐心等待，已为你还原$(cat $LOG)次。" $MODPATH/module.prop   
        exit 0
 fi
 sleep 1
 done
Brush_in=""
IMG=""
SLOT=`cat /proc/cmdline | tr '[:space:]' '\n' | sed -rn 's/androidboot.slot.{0,7}=//p'`
if [[ -n "$SLOT" ]]; then
        echo "- 当前使用的分区：$SLOT"
        case $SLOT in
            _a)
                IMG="/dev/block/bootdevice/by-name/vendor_boot_a"  
                Brush_in="$MODPATH/tool/vendor_boot/vendor_boot.img"
            ;;
            _b)
                IMG="/dev/block/bootdevice/by-name/vendor_boot_b"  
                 Brush_in="$MODPATH/tool/vendor_boot/vendor_boot.img"
         
            ;;
        esac
fi


e=${IMG##*/}
echo "- 您当前选择了$e分区"
echo "- 刷入文件路径：$Brush_in"
echo "- 检测刷入镜像文件是否存在"
[[ ! -L "$IMG" ]] && abort "！$e分区不存在无法刷入"
    if [[ -f "$Brush_in" ]]; then
        echo "- 开始刷写$e分区"
        dd if="$Brush_in" of="$IMG"
    else
        abort "！$Brush_in刷入文件不存在无法刷写到$e分区"
    fi
    echo "- 完成"
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        num=`cat $LOG`
        p="$(expr $num + 1)"
        echo "$p" >$LOG
    fi
    reboot
exit 0
 