AUTOMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
SKIPMOUNT=false
DEBUG=true

print_modname() {
  ui_print "***********************"
  ui_print "MiSoundBOOST!!!!"
  ui_print "Design By Huber_HaYu 以及团队的支持"
  ui_print "SetoSkins bug_casc 灵聚、神生 mly墨临渊（本模块协助成员）"
  ui_print "感谢各位的支持和帮助"
  ui_print "***********************"
}

on_install() {
pm uninstall-system-updates com.miui.misound
rm -rf /data/system/package_cache/*
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'LICENSE' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2

 boot_first_load
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}

# 【本模块纯参数调音，如需引用调音文件请注明作者】
sleep 0.4s
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
sleep 1.5s
ui_print "请稍后..."
sleep 3s
ui_print "------------------------------"
ui_print "【团队感谢：SetoSkins(代码) shadow3(代码) 灵聚、神生(代码)"
ui_print "mly墨临渊(调音、调试) 中二的番茄（辅助调音） big_chair(辅助调音) bug_casc(辅助调音)】"
ui_print "AI参数调整：ChatGPT"
ui_print "------------------------------"
sleep 1s
ui_print "A13 NFC Fix"
sleep 1s
#Pangu Fix
a=$(getprop ro.system.build.version.release)
if [ $a == "13" ]; then
    ui_print "Android Version:13"
    sleep 0.5s
    ui_print "Fixing.."
    sleep 1s
    mkdir -p $MODPATH/system/product/
    cp -r /product/pangu/system/* $MODPATH/system/product/
fi    
if [ $a == "12" ]; then
    ui_print "无需修复 已跳过"
fi