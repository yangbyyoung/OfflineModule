#!/system/bin/sh
SKIPUNZIP=1
"$MODPATH/protect_call"