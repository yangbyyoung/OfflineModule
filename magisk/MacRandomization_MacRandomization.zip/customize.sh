AUTOMOUNT=true
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false
print_modinfo() {
  ui_print "*******************************"
  ui_print " Mac Randomization v1.1      "
  ui_print "在开发者模式中新增Mac地址随机化"
  ui_print "*******************************"
}

print_modinfo