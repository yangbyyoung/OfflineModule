

[ -f "$MODPATH/customize.d/00-verify-resources.sh" ] || abort "! Part '00-verify-resources.sh' not found"
. "$MODPATH/customize.d/00-verify-resources.sh"
[ -f "$MODPATH/customize.d/10-enforce-api-version.sh" ] || abort "! Part '10-enforce-api-version.sh' not found"
. "$MODPATH/customize.d/10-enforce-api-version.sh"
[ -f "$MODPATH/customize.d/11-enforce-arch.sh" ] || abort "! Part '11-enforce-arch.sh' not found"
. "$MODPATH/customize.d/11-enforce-arch.sh"
[ -f "$MODPATH/customize.d/20-enforce-magisk-version.sh" ] || abort "! Part '20-enforce-magisk-version.sh' not found"
. "$MODPATH/customize.d/20-enforce-magisk-version.sh"
[ -f "$MODPATH/customize.d/25-check-incompatible-module.sh" ] || abort "! Part '25-check-incompatible-module.sh' not found"
. "$MODPATH/customize.d/25-check-incompatible-module.sh"
[ -f "$MODPATH/customize.d/30-place-libraries.sh" ] || abort "! Part '30-place-libraries.sh' not found"
. "$MODPATH/customize.d/30-place-libraries.sh"
[ -f "$MODPATH/customize.d/40-initialize-data-directory.sh" ] || abort "! Part '40-initialize-data-directory.sh' not found"
. "$MODPATH/customize.d/40-initialize-data-directory.sh"
[ -f "$MODPATH/customize.d/90-restore-module-permission.sh" ] || abort "! Part '90-restore-module-permission.sh' not found"
. "$MODPATH/customize.d/90-restore-module-permission.sh"


rm -rf $MODPATH/customize.d