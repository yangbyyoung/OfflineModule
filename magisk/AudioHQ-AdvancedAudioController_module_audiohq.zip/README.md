# audiohq
## Description
Provide binary and apk for controlling each applications volume

## Installation
Flash it on MagiskManager
<font color="#FF000">DO NOT FLASH ON: Flyme,EMUI,GAME Phone system or any oem modified system(EXCEPT MIUI for now)</font>

## Pages
[English Page](https://alcatraz323.github.io/audiohq/index_en.html)
[中文页面](https://alcatraz323.github.io/audiohq/index.html)

#### More
The matched stable apk has been added to module file(will be mounted to /system/priv-app),apk is also published on GooglePlay And Coolapk