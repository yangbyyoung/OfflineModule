# Tell user aml is needed if applicable
FILES=$(find $NVBASE/modules/*/system $MODULEROOT/*/system -type f -name "*audio_effects*.conf" -o -name "*audio_effects*.xml" 2>/dev/null | sed "/$MODID/d")
if [ ! -z "$FILES" ] && [ ! "$(echo $FILES | grep '/aml/')" ]; then
  ui_print " "
  ui_print "   ! Conflicting audio mod found!"
  ui_print "   ! You will need to install !"
  ui_print "   ! Audio Modification Library !"
  sleep 3
fi

processing_patch() {
  if [ "$1" == "pre" ]; then
    CONF=pre_processing
    XML=preprocess
  elif [ "$1" == "post" ]; then
    CONF=output_session_processing
    XML=postprocess
  fi
  case $2 in
    *.conf) if [ ! "$(sed -n "/^$CONF {/,/^}/p" $2)" ]; then
              echo -e "\n$CONF {\n    $3 {\n        $4 {\n        }\n    }\n}" >> $2
            elif [ ! "$(sed -n "/^$CONF {/,/^}/ {/$3 {/,/^    }/p}" $2)" ]; then
              sed -i "/^$CONF {/,/^}/ s/$CONF {/$CONF {\n    $3 {\n        $4 {\n        }\n    }/" $2
            elif [ ! "$(sed -n "/^$CONF {/,/^}/ {/$3 {/,/^    }/ {/$4 {/,/}/p}}" $2)" ]; then
              sed -i "/^$CONF {/,/^}/ {/$3 {/,/^    }/ s/$3 {/$3 {\n        $4 {\n        }/}" $2
            fi;;
    *.xml) if [ ! "$(sed -n "/^ *<$XML>/,/^ *<\/$XML>/p" $2)" ]; then     
             sed -i "/<\/audio_effects_conf>/i\    <$XML>\n       <stream type=\"$3\">\n            <apply effect=\"$4\"\/>\n        <\/stream>\n    <\/$XML>" $2
           elif [ ! "$(sed -n "/^ *<$XML>/,/^ *<\/$XML>/ {/<stream type=\"$3\">/,/<\/stream>/p}" $2)" ]; then     
             sed -i "/^ *<$XML>/,/^ *<\/$XML>/ s/    <$XML>/    <$XML>\n        <stream type=\"$3\">\n            <apply effect=\"$4\"\/>\n        <\/stream>/" $2
           elif [ ! "$(sed -n "/^ *<$XML>/,/^ *<\/$XML>/ {/<stream type=\"$3\">/,/<\/stream>/ {/^ *<apply effect=\"$4\"\/>/p}}" $2)" ]; then
             sed -i "/^ *<$XML>/,/^ *<\/$XML>/ {/<stream type=\"$3\">/,/<\/stream>/ s/<stream type=\"$3\">/<stream type=\"$3\">\n            <apply effect=\"$4\"\/>/}" $2
           fi;;
  esac
}

ui_print "   Patching existing audio_effects files..."
CFGS="$(find /system /vendor -type f -name "*audio_effects*.conf" -o -name "*audio_effects*.xml")"
for OFILE in ${CFGS}; do
  FILE="$MODPATH$(echo $OFILE | sed "s|^/vendor|/system/vendor|g")"
  cp_ch -n $ORIGDIR$OFILE $FILE
  case $FILE in
    *.conf) if [ ! "$(grep "gaudiosolmusicone" $FILE)" ]; then
              if [ ! "$(grep '^ *proxy {' $FILE)" ]; then
                sed -i "s/^libraries {/libraries {\n  proxy { #$MODID\n    path $LIBPATCH\/lib\/soundfx\/libeffectproxy.so\n  } #$MODID/g" $FILE
              fi
              sed -i "s/^effects {/effects {\n  gaudiosolmusicone { #$MODID\n    library proxy\n    uuid 6475483e-c7ed-44f0-8a15-1530c42039aa\n\n    libsw {\n      library gaudio_sw\n      uuid f27317f4-c984-4de6-9a90-545759495bf2\n    }\n\n    libhw {\n      library gaudio_hw\n      uuid c75e44ec-e3e9-4212-8ef2-25b61d8feba6\n    }\n  } #$MODID/g" $FILE
              sed -i "s/^libraries {/libraries {\n  gaudio_hw { #$MODID\n    path $LIBPATCH\/lib\/soundfx\/libgaudiosolmusicone_hw.so\n  } #$MODID/g" $FILE
              sed -i "s/^libraries {/libraries {\n  gaudio_sw { #$MODID\n    path $LIBPATCH\/lib\/soundfx\/libgaudiosolmusicone_sw.so\n  } #$MODID/g" $FILE
              processing_patch "post" "$FILE" "music" "gaudiosolmusicone"
            fi;;
    *.xml) if [ ! "$(grep "gaudiosolmusicone" $FILE)" ]; then
             if [ ! "$(grep "<library name=\"proxy\" path=\"libeffectproxy.so\"\/>" $FILE)" ]; then
               sed -i "/<libraries>/ a\        <library name=\"proxy\" path=\"libeffectproxy.so\"\/><!--$MODID-->" $FILE
             fi
             sed -i "/<libraries>/ a\        <library name=\"gaudio_hw\" path=\"libgaudiosolmusicone_hw.so\"\/><!--$MODID-->" $FILE
             sed -i "/<libraries>/ a\        <library name=\"gaudio_sw\" path=\"libgaudiosolmusicone_sw.so\"\/><!--$MODID-->" $FILE
             sed -i -e "/<effects>/ a\        <effectProxy name=\"gaudiosolmusicone\" library=\"proxy\" uuid=\"6475483e-c7ed-44f0-8a15-1530c42039aa\"><!--$MODID-->" -e "/<effects>/ a\            <libsw library=\"gaudio_sw\" uuid=\"f27317f4-c984-4de6-9a90-545759495bf2\"\/>" -e "/<effects>/ a\            <libhw library=\"gaudio_hw\" uuid=\"c75e44ec-e3e9-4212-8ef2-25b61d8feba6\"\/>" -e "/<effects>/ a\        <\/effectProxy><!--$MODID-->" $FILE
             processing_patch "post" "$FILE" "music" "gaudiosolmusicone"
           fi;;
    esac
done

ui_print "   A12 might require PERMISSIVE SELINUX!"

[ $API -ge 26 ] && sed -i "s|<LIBDIR>|/vendor|g" $MODPATH/.aml.sh || sed -i "s|<LIBDIR>|/system|g" $MODPATH/.aml.sh
