MODDIR=${0%/*}
lastVersion=$(getprop ro.build.version.incremental)
lastVersionFilePath=$MODDIR/lastVersion
productDirPath=$MODDIR/system/product
if [ ! -f $lastVersionFilePath ] || [ ! -d "$productDirPath"  ] || [ $(cat $lastVersionFilePath) != $lastVersion ] ; then
   mkdir -p ${productDirPath}
   cp -p -a -R /system/product/pangu/system/* ${productDirPath}
   echo "$lastVersion" >$lastVersionFilePath
else
   echo "已经完成此版本号的应用挂载！"
fi