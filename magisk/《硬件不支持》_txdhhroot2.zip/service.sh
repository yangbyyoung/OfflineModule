MODDIR=${0%/*}
until [ $(getprop init.svc.bootanim) = "stopped" ]; do
echo "开始执行"
sleep 5
done
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch /data/user_de/0/com.miui.home/cache/debug_log
chmod 000 /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService
stop cnss_diag
killall -9 cnss_diag
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes