Package=$(pm list packages -3 | grep "^package:" | cut -f2 -d ':')

if [ "$tripartite_app" = "everything" ]; then
	for i in $Package
		do
			cmd package compile -m everything $i
		done
elif [ "$tripartite_app" = "speed" ]; then
	for i in $Package
		do
			cmd package compile -m speed $i
		done
else
	echo "$(date "+%Y-%m-%d %H:%M:%S") E : 配置输入有误" >>"$DEX2OAT_LOG"
fi
