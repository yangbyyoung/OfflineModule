
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" 2>/dev/null
        chmod u+x "$2" 2>/dev/null
        echo "$1" > "$2" && chmod 0644 "$2" || echo "修改"$2"失败！"
    fi
}


#禁用lmk
set_value 0 /sys/module/lowmemorykiller/parameters/enable_lmk
#禁用自适应lmk
set_value 0 /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
#禁用lmk调试，节省性能消耗。
set_value 0 /sys/module/lowmemorykiller/parameters/debug_level
#提高zram/swapfile使用率
set_value 100 /proc/sys/vm/swappiness
set_value 102400 /proc/sys/vm/extra_free_kbytes
set_value 256  /proc/sys/vm/watermark_scale_factor