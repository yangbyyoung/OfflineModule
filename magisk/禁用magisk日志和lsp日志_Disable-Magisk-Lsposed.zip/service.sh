#!/system/bin/sh
grep_prop() {
    local REGEX="s/^$1=//p"
    shift
    local FILES="$@"
    [[ -z "$FILES" ]] && FILES='/system/build.prop'
    sed -n "$REGEX" ${FILES} 2>/dev/null | head -n 1
}
MODDIR=${0%/*}
LSPMISC_PATH=$(cat /data/adb/lspd/misc_path)
LSPBASE_PATH="/data/misc/$LSPMISC_PATH"
LSPLOG_PATH="${LSPBASE_PATH}/log"
LSP_NEW_LOG_PATH="/data/adb/lspd/log"

#清理面具日志
chmod 777  /cache/magisk.log
rm -rf /cache/magisk.log
touch /cache/magisk.log
chmod 000  /cache/magisk.log
    mkdir -p ${LOG_PATH}
        rm "${LOG_FILE}"
        
#定义整型变量
a=1
   while true
    do
sleep 3
mkdir -p ${LSPLOG_PATH}
rm "${LSPLOG_PATH}/modules.log" 
rm "${LSPLOG_PATH}/all.log" 
mkdir -p ${LSP_NEW-LOG_PATH}
rm "${LSP_NEW_LOG_PATH}/modules.log" 
rm "${LSP_NEW_LOG_PATH}/all.log" 
rm "${LOG_PATH}/modules.log" 
a=$(($a+1))
echo $a
     if [[ $a>3 ]]; then
            break
        fi
done

