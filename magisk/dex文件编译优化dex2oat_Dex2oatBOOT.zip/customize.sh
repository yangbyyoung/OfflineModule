#定义相关路径和文件
DEX2OAT_CONFIG="/data/adb/Dex2oatBOOT/dex2oat基础配置.prop"
OPTIONALAPP_CONFIG="/data/adb/Dex2oatBOOT/dex2oat自选应用列表.prop"

#创建配置文件
mkdir /data/adb/Dex2oatBOOT
if [ ! -d $DEX2OAT_CONFIG ]; then
	touch $DEX2OAT_CONFIG
fi
if [ ! -d $OPTIONALAPP_CONFIG ]; then
	touch $OPTIONALAPP_CONFIG
fi
touch /data/adb/Dex2oatBOOT/重启手机.sh
touch /data/adb/Dex2oatBOOT/删除编译内容.sh

#读取旧配置
system_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^系统应用=" | cut -f2 -d '=')
tripartite_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^三方应用=" | cut -f2 -d '=')
optional_app=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^自选应用=" | cut -f2 -d '=')
dexopt_ota=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^更新系统时=" | cut -f2 -d '=')
dexopt_boot=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^系统启动时=" | cut -f2 -d '=')
dexopt_install=$(sed '/^#/d' "$DEX2OAT_CONFIG" | grep "^安装应用时=" | cut -f2 -d '=')
Optionalapp=$(cat $OPTIONALAPP_CONFIG | grep -v '^#')

#写入配置
if [ ! -d /data/adb/modules/Dex2oatBOOT/service.sh ]; then
echo "#dex2oat基础配置
#可填：
#无
#speed 性能一般，所占空间适中
#everything 性能最好，所占空间大
#模块配置
系统应用=speed
三方应用=无
自选应用=everything
#调整系统默认dex2oat的配置
#可填：verify、quicken、space-profile、space、speed-profile、speed、everything，可不填
更新系统时=speed-profile
系统启动时=verify
安装应用时=speed-profile
" >"$DEX2OAT_CONFIG"

echo "#dex2oat自选应用配置（填包名，一行一个）
com.google.android.webview
com.miui.home
miui.systemui.plugin
com.miui.securityadd
com.android.systemui
" >"$OPTIONALAPP_CONFIG"
else
echo "#dex2oat基础配置
#可填：
#无
#speed 性能一般，所占空间适中
#everything 性能最好，所占空间大
#模块配置
系统应用=$system_app
三方应用=$tripartite_app
自选应用=$optional_app
#调整系统默认dex2oat的配置
#可填：verify、quicken、space-profile、space、speed-profile、speed、everything，可不填
更新系统时=$dexopt_ota
系统启动时=$dexopt_boot
安装应用时=$dexopt_install
" >"$DEX2OAT_CONFIG"

echo "#dex2oat自选应用配置（填包名，一行一个）
$Optionalapp
" >"$OPTIONALAPP_CONFIG"
fi

echo "reboot" >"/data/adb/Dex2oatBOOT/重启手机.sh"

cp $MODPATH/删除编译内容.sh /data/adb/Dex2oatBOOT/删除编译内容.sh

rm -rf /data/第一次安装dex2oat
