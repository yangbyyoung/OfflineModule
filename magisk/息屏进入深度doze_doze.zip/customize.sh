SKIPUNZIP=0
REPLACE="
"
if [[ `find /data/app -name "com.kmou424.ToastCreator*" -type d` ]]; then
echo " * 已存在toast依賴"
rm -rf $MODPATH/toast.apk
else
echo " * 安裝相關依賴:"
echo " *  - ToastCreator"
echo " * toast插件來自kmou424協助開發 K大NB! YYDS!"
pm install -r -g $MODPATH/toast.apk >/dev/null 2>&1
 if [[ $? = 0 ]]; then
   echo " * 安裝成功"
 else
   echo " * 安裝失敗"
 fi
rm -rf $MODPATH/toast.apk
fi
cat $MODPATH/script/doze.conf > /storage/emulated/0/Android/doze.conf