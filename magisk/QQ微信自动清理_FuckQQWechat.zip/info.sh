author="`grep_prop author $TMPDIR/module.prop`"
name="`grep_prop name $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
id="`grep_prop id $TMPDIR/module.prop`"

echo ""
echo "∞————————————————————————∞"
echo "－品牌: `getprop ro.product.brand`"
echo "－代号: `getprop ro.product.device`"
echo "－模型: `getprop ro.product.model`"
echo "－安卓版本: `getprop ro.build.version.release`"
[[ "`getprop ro.miui.ui.version.name`" != "" ]] && echo "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
#echo "－内核版本: `uname -a `"
echo "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
echo "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
echo "∞————————————————————————∞"
echo ""
echo "∞————————————————————————∞"
echo "- 模块信息"
echo "- 名称: $name    "
echo "- 作者：$author"
echo "- 用处:$description    "
echo "∞————————————————————————∞"
echo ""

Dream_tip(){
echo "∞————————————————————————∞"
echo ""
echo "
- 如果卡开机请在
- rec→高级→文件管理
- →data→adb→modules
- 删除$id这个文件夹"
echo ""
echo "∞————————————————————————∞"
}