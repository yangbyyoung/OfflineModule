#!/system/bin/sh
while true
do
#Sleep延迟调节，单位秒，延迟越大占用越小，直接删掉就是全力跑
#嫌键盘灯反应的慢就改小一点，0.5，0.4啥的，当然你也可以直接删掉也就是无延迟循环，不过就算那样占用也不过一个logd的量而已
sleep 1
screen="`dumpsys window policy | grep "mInputRestricted"|cut -d= -f2`"
if [[ true == $screen ]];then
   echo "0" > /sys/class/leds/button-backlight/brightness 
   echo "0" > /sys/class/leds/button-backlight1/brightness
elif [[ false == $screen ]];then
#64那个大概是亮度，米6好像上限就是64，你改高一点大概也没啥反作用，我懒得动了
   echo "64" > /sys/class/leds/button-backlight1/brightness 
   echo "64" > /sys/class/leds/button-backlight/brightness
fi
done
#BY OLX_LY_C