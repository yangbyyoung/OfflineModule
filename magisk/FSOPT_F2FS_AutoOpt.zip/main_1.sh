MODDIR=${0%/*}
userdata=`cat "$MODDIR/datafile/userdata_num"`
if [ `dumpsys deviceidle | grep mScreenOn` == "mScreenOn=true" ] ; then
	#init
	function infoend(){
  		count_trim=`cat "$MODDIR/datafile/count_trim"`
  		count_gc=`cat "$MODDIR/datafile/count_gc"`
  		if [ "$trimed" == "1" ] ; then
  			echo " # " >> $MODDIR/datafile/TRIM_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_TRIM.log > $MODDIR/datafile/TRIM_tmpO.log
			cat $MODDIR/datafile/TRIM_tmpN.log $MODDIR/datafile/TRIM_tmpO.log >/sdcard/Android/fsopt/FSopt_TRIM.log
			sed -i '101,109d' /sdcard/Android/fsopt/FSopt_TRIM.log
			count_trim=$(($count_trim + 1 ))
		fi
		if [ "$gced" == "1" ] ; then
			echo " # " >> $MODDIR/datafile/GC_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_GC.log > $MODDIR/datafile/GC_tmpO.log
			cat $MODDIR/datafile/GC_tmpN.log $MODDIR/datafile/GC_tmpO.log >/sdcard/Android/fsopt/FSopt_GC.log
			sed -i '97,109d' /sdcard/Android/fsopt/FSopt_GC.log
			count_gc=$(($count_gc + 1 ))
		fi
		echo "$count_trim" > $MODDIR/datafile/count_trim
		echo "$count_gc" > $MODDIR/datafile/count_gc
	}
	
	function cpud(){
		out=$(echo "scale=$4; $1*$2/$3" | bc)
		echo $out
		return $?
	}
	
	function tf_gc(){				
		if [ "$2" -ge "$3" ] ; then
			out=$(cpud $2 $5 $6 2)
			if [ "$2" -ge "$4" ] ; then
				out=$(cpud $2 $5 $7 2)
				echo " --- $1: $out GB " >> $MODDIR/datafile/GC_tmpN.log
			else
				echo " --- $1: $out MB " >> $MODDIR/datafile/GC_tmpN.log
			fi
		else
			out=$(cpud $2 $5 $8 2)
			echo " --- $1: $out KB " >> $MODDIR/datafile/GC_tmpN.log
		fi
	}

	function backup_value(){
		cp_interval=`cat "/sys/fs/f2fs/$userdata/cp_interval"`
		dirty_nats_ratio=`cat "/sys/fs/f2fs/$userdata/dirty_nats_ratio"`
		discard_idle_interval=`cat "/sys/fs/f2fs/$userdata/discard_idle_interval"`
		gc_idle=`cat "/sys/fs/f2fs/$userdata/gc_idle"`
		gc_idle_interval=`cat "/sys/fs/f2fs/$userdata/gc_idle_interval"`
		gc_max_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_max_sleep_time"`
		gc_min_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_min_sleep_time"`
		gc_no_gc_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_no_gc_sleep_time"`
		gc_urgent=`cat "/sys/fs/f2fs/$userdata/gc_urgent"`
		gc_urgent_sleep_time=`cat "/sys/fs/f2fs/$userdata/gc_urgent_sleep_time"`
		gc_urgent_high_remaining=`cat "/sys/fs/f2fs/$userdata/gc_urgent_high_remaining"`
		idle_interval=`cat "/sys/fs/f2fs/$userdata/idle_interval"`
		ram_thresh=`cat "/sys/fs/f2fs/$userdata/ram_thresh"`
	}
	
	function set_value(){
		echo 1 > "/sys/fs/f2fs/$userdata/gc_booster"
		echo 3 > "/sys/fs/f2fs/$userdata/cp_interval"
		echo 1 > "/sys/fs/f2fs/$userdata/dirty_nats_ratio"
		echo 1 > "/sys/fs/f2fs/$userdata/discard_idle_interval"
		echo 2 > "/sys/fs/f2fs/$userdata/gc_idle"
		echo 1 > "/sys/fs/f2fs/$userdata/gc_idle_interval"
		echo 2000 > "/sys/fs/f2fs/$userdata/gc_max_sleep_time"
		echo 500 > "/sys/fs/f2fs/$userdata/gc_min_sleep_time"
		echo 1000 > "/sys/fs/f2fs/$userdata/gc_no_gc_sleep_time"
		echo 1 > "/sys/fs/f2fs/$userdata/gc_urgent"
		echo 50 > "/sys/fs/f2fs/$userdata/gc_urgent_sleep_time"
		echo 0 > "/sys/fs/f2fs/$userdata/gc_urgent_high_remaining"
		echo 1 > "/sys/fs/f2fs/$userdata/idle_interval"
		echo 1 > "/sys/fs/f2fs/$userdata/ram_thresh"
	}

	function re_value(){
		echo 0 > "/sys/fs/f2fs/$userdata/gc_booster"
		echo "$cp_interval" > "/sys/fs/f2fs/$userdata/cp_interval"
		echo "$dirty_nats_ratio" > "/sys/fs/f2fs/$userdata/dirty_nats_ratio"
		echo "$discard_idle_interval" > "/sys/fs/f2fs/$userdata/discard_idle_interval"
		echo "$gc_idle" > "/sys/fs/f2fs/$userdata/gc_idle"
		echo "$gc_idle_interval" > "/sys/fs/f2fs/$userdata/gc_idle_interval"
		echo "$gc_max_sleep_time" > "/sys/fs/f2fs/$userdata/gc_max_sleep_time"
		echo "$gc_min_sleep_time" > "/sys/fs/f2fs/$userdata/gc_min_sleep_time"
		echo "$gc_no_gc_sleep_time" > "/sys/fs/f2fs/$userdata/gc_no_gc_sleep_time"
		echo "$gc_urgent" > "/sys/fs/f2fs/$userdata/gc_urgent"
		echo "$gc_urgent_sleep_time" > "/sys/fs/f2fs/$userdata/gc_urgent_sleep_time"
		echo "$gc_urgent_high_remaining" > "/sys/fs/f2fs/$userdata/gc_urgent_high_remaining"
		echo "$idle_interval" > "/sys/fs/f2fs/$userdata/idle_interval"
		echo "$ram_thresh" > "/sys/fs/f2fs/$userdata/ram_thresh"
	}

	function gc_main(){
		backup_value
		echo lock_me >/sys/power/wake_lock
		initunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
		runcycle=0
		counts=0
		set_value
		until [ `cat "/sys/fs/f2fs/$userdata/unusable"` == "0" ] ; do
			if [ `cat "/sys/fs/f2fs/$userdata/gc_urgent"` != "GC_URGENT_HIGH" ] ; then
				set_value
			fi
			cpuload
			runcycle=$(($runcycle + 1 ))
			if	[ "$usage" -ge "50" ] ;then
				counts=$(($counts + 1 ))
				if	[ "$counts" -ge "5" ] ;then
					break 1
				fi
			else
				if	[ "$counts" -ge "1" ] ;then
					counts=$(($counts - 1 ))
				fi
			fi
		done
		re_value
		echo lock_me >/sys/power/wake_unlock
		free_space=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		endunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
		unusegc=$(($initunuse - $endunuse))
		if [ $unusegc -lt "0" ];then
		    unusegc=0
		fi
	}

	function gc_rtime(){
		if [ "$runcycle" -ge 60 ] ; then
			runtime_m=$(cpud $runcycle 1 60 0)
			runtime_s=$(echo "scale=0; $runcycle - $runtime_m*60" | bc)
			echo " --- GC_Runtime: $runtime_m Min $runtime_s Sec " >> $MODDIR/datafile/GC_tmpN.log
		else
			echo " --- GC_Runtime: $runcycle Sec " >> $MODDIR/datafile/GC_tmpN.log
		fi
	}

	function gc_scale(){
		diskfree=$(/bin/df /data | grep -w block | awk '{print $2,$3,$4}')
		diskfree=$(echo $diskfree | awk '{print $3}')
		unuse_block=`cat "/sys/fs/f2fs/$userdata/unusable"`
		scale_gc=$(echo "scale=0; $diskfree*7/400" | bc)
	}

	function cpuload(){
		info_old=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
		total_old=$(echo $info_old | awk '{print $1+$2+$3+$4+$5+$6+$7}')
		usage_old=$(echo $info_old | awk '{print $1+$2+$3}')
		sleep 1
		info_new=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
		total_new=$(echo $info_new | awk '{print $1+$2+$3+$4+$5+$6+$7}')
		usage_new=$(echo $info_new | awk '{print $1+$2+$3}')
		busy=$(($usage_new - $usage_old))
		cputime=$(($total_new - $total_old))
		usage=$(echo "scale=0; $busy*100/$cputime" | bc)
	}
	
	function fstrimd(){
		rundata=`date "+%Y-%m-%d %H:%M:%S"`
		echo " # " > $MODDIR/datafile/TRIM_tmpN.log
		echo " --- $rundata " >> $MODDIR/datafile/TRIM_tmpN.log
		trim_fail=`cat "$MODDIR/datafile/trim_fail"`
		$MODDIR/bin/busybox fstrim -v /data > $MODDIR/datafile/trim_inf
		trim=`cat "$MODDIR/datafile/trim_inf" | tr -cd "[0-9]"`
		if [ "$trim" == "0" -o "$trim" == "" -o "$trim" == "NULL" ] ; then
			echo " --- DATA: 无需TRIM " >> $MODDIR/datafile/TRIM_tmpN.log
			trim_fail=$(($trim_fail + 1 ))
			echo "$trim_fail" > $MODDIR/datafile/trim_fail
		else
			trimed=1
			echo 0 > $MODDIR/datafile/trim_fail
			if [ "$trim" -ge "1000000" ] ; then
				out=$(cpud $trim 1 1000000 2)
				if [ "$trim" -ge "1000000000" ] ; then
					out=$(cpud $trim 1 1000000000 2)
					echo " --- DATA: $out GB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
				else
					echo " --- DATA: $out MB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
				fi
			else
				out=$(cpud $trim 1 1000 2)
				echo " --- DATA: $out KB trimmed " >> $MODDIR/datafile/TRIM_tmpN.log
			fi
		fi
		echo "NULL" > $MODDIR/datafile/trim_inf
	}

	#Main
	trimed=0
	gced=0
	gc_scale
	if [ `cat "/sys/fs/f2fs/$userdata/unusable"` -ge "$scale_gc" ] ; then
		if [ `cat "/sys/class/power_supply/battery/status"` = "Charging" -o `cat "/sys/class/power_supply/battery/capacity"` -ge "30" ] ;then
			fstrimd
			rundata=`date "+%Y-%m-%d %H:%M:%S"`
			echo " # " > $MODDIR/datafile/GC_tmpN.log
			echo " --- $rundata " >> $MODDIR/datafile/GC_tmpN.log
			gc_main
			gc_rtime
			tf_gc "已回收空间" $unusegc 245 244141 4096  1000000 1000000000 1000
			tf_gc "待回收空间" $endunuse 245 244141 4096 1000000 1000000000 1000
			if [ $free_space != "" ];then
				tf_gc "空闲块空间" $free_space 1 476 2097152 1000000 1000000000 1
			fi
			gced=1
			infoend
			trimed=0
			gc_scale
			if [ `cat "/sys/fs/f2fs/$userdata/unusable"` -le "5000" ] ; then
				echo "Lock" > $MODDIR/datafile/SleepLocker
			fi
		else
			fstrimd
			infoend
		fi
	else
		fstrimd
		infoend
	fi
	if [ "$trim_fail" -ge "10" ] ; then
		echo "Y" > $MODDIR/datafile/trim_disable
	fi
fi
if [ "$trimed" == "1" ] ; then
	echo "Lock" > $MODDIR/datafile/SleepLocker
fi
