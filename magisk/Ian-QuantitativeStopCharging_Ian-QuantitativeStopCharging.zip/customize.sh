StopInstalling() {
  rm -rf $MODPATH >/dev/null 2>&1
  rm -rf $TMPDIR >/dev/null 2>&1
  exit 1
}
if [ -f "/sys/class/power_supply/battery/input_suspend" ]; then
  #Qualcomm snapdragon 870 (It's in common use in theory)
  sed -i "/^charging_control_file=/c charging_control_file=/sys/class/power_supply/battery/input_suspend" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/sys/class/qcom-battery/input_suspend" ]; then
  #Qualcomm snapdragon 888
  sed -i "/^charging_control_file=/c charging_control_file=/sys/class/qcom-battery/input_suspend" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/sys/class/battery/input_suspend" ]; then
  #Qualcomm snapdragon 855
  sed -i "/^charging_control_file=/c charging_control_file=/sys/class/battery/input_suspend" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/proc/mtk_battery_cmd/current_cmd" ]; then
  #MediaTek
  sed -i "/^charging_control_file=/c charging_control_file=/proc/mtk_battery_cmd/current_cmd" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0::0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=0::1" "$MODPATH/switch.conf"
elif [ -f "/proc/mtk_battery_cmd/en_power_path" ]; then
  #MediaTek
  sed -i "/^charging_control_file=/c charging_control_file=/proc/mtk_battery_cmd/en_power_path" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=1" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=0" "$MODPATH/switch.conf"
elif [ -f "/proc/driver/charger_limit_enable" ]; then
  #MediaTek (Maybe)
  sed -i "/^charging_control_file=/c charging_control_file=/proc/driver/charger_limit_enable" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/proc/driver/charger_limit" ]; then
  #MediaTek (Maybe)
  sed -i "/^charging_control_file=/c charging_control_file=/proc/driver/charger_limit" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=100" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/sys/kernel/debug/google_charger/chg_suspend" ]; then
  #Google devices
  sed -i "/^charging_control_file=/c charging_control_file=/sys/kernel/debug/google_charger/chg_suspend" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/sys/kernel/debug/google_charger/input_suspend" ]; then
  #Google devices
  sed -i "/^charging_control_file=/c charging_control_file=/sys/kernel/debug/google_charger/input_suspend" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=0" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=1" "$MODPATH/switch.conf"
elif [ -f "/sys/kernel/debug/google_charger/chg_mode" ]; then
  #Google devices
  sed -i "/^charging_control_file=/c charging_control_file=/sys/kernel/debug/google_charger/chg_mode" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=1" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=0" "$MODPATH/switch.conf"
elif [ -f "/sys/devices/platform/soc/soc:oplus,chg_intf/oplus_chg/battery/mmi_charging_enable" ]; then
  #OnePlus devices
  sed -i "/^charging_control_file=/c charging_control_file=/sys/devices/platform/soc/soc:oplus,chg_intf/oplus_chg/battery/mmi_charging_enable" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=1" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=0" "$MODPATH/switch.conf"
elif [ -f "/sys/class/power_supply/battery/battery_charging_enabled" ]; then
  #Older devices
  sed -i "/^charging_control_file=/c charging_control_file=/sys/class/power_supply/battery/battery_charging_enabled" "$MODPATH/switch.conf"
  sed -i "/^start_charging_flag=/c start_charging_flag=1" "$MODPATH/switch.conf"
  sed -i "/^stop_charging_flag=/c stop_charging_flag=0" "$MODPATH/switch.conf"
else
  ui_print "- This module is not applicable to your device"
  ui_print "- The module installer is about to be stopped"
  StopInstalling
fi