#!/system/bin/sh
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH

MODDIR=/data/adb/modules/845-ESA-key
dir1="/data/vendor/thermal/config"
dir2="/data/thermal/config"

function thermalkill(){
if test -e ${1%/*} -a ! -e "$1" ;then
chattr -i -a -A ${1%/*}
rm -rf ${1%/*}
fi
if test -e "$1";then
chattr -i -a -A "$1"
rm -rf "$1"/*
cp -rf $MODDIR/system/vendor/etc/* "$1" && chmod -R 0755 "$1"
else
chattr -i -a -A "$1"
mkdir -p "$1"
cp -rf $MODDIR/system/vendor/etc/* "$1" && chmod -R 0755 "$1"
fi
}


thermalkill $dir1 2>/dev/null
thermalkill $dir2 2>/dev/null

set_value() {
	if test -f "$2" ;then
		chmod 0777 "$2" >/dev/null 2>&1
		echo "$1" > "$2" && {
			chmod 0755 "$2" >/dev/null 2>&1
		} || echo "修改"$2"失败！"
	fi
}

set_value '100' /sys/class/power_supply/bms/temp_cool
set_value '600' /sys/class/power_supply/bms/temp_warm
set_value '600' /sys/class/power_supply/bms/temp_hot

