#!/system/bin/sh

function echo_head_info(){
echo "品牌=`getprop ro.product.brand`"
echo "代号=`getprop ro.product.device`"
echo "模型=`getprop ro.product.model`"
echo "安卓版本=`getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && echo "MIUI版本=MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
echo "内核版本=`uname -a `"
echo "处理器=$(getprop ro.board.platform)"
echo "上次云控更新日期:$(content query --uri 'content://com.miui.powerkeeper.configure/SimpleSettings/misc' --where "name='last_sync_cloud_info'" | sed 's|.*value=||g;s|,.*||g')"
}

function echo_find_current_message(){
find /sys -iname "input_current_settled" -o -iname "*_charge_level" -o -iname "*current*max" -o -iname "charge*current*" -o -iname "*_current*" -o -iname "current_*" -o -iname "default_.*_icl_ma" -o -iname "current_*limit" -o -iname "limit*current" 2> /dev/null | while read value ;do
cat << key 
名称=${value##*/}
值=`cat "${value}" 2>/dev/null`
路径=${value}

key
done
}

function echo_restrict_message(){
	find /sys -iname "sw_jeita_enabled" -o -iname "force_fast_charge" -o -iname "pd_allowed" -o -iname "allow_hvdcp3" -o -iname "input_current_limited" -o -iname "restricted_charging" -o -iname "step_charging_enabled" 2> /dev/null | while read restrict ;do
	cat << key 
名称=${restrict##*/}
值=`cat "${restrict}" 2>/dev/null`
路径=${restrict}

key
done
}

cat << key > "${0%/*}/可能的电流大小路径.prop"

$(echo_head_info)

#############
$(echo_find_current_message)

#############
key


cat << key > "${0%/*}/可能的充电限制路径.prop"

$(echo_head_info)

#############
$(echo_restrict_message)

#############
key
