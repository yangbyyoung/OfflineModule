#!/system/bin/sh
MODDIR=${0%/*}
chmod a+x $MODDIR/*.sh
BASEDIR="$(dirname $(readlink -f "$0"))"

sh $BASEDIR/运存防线启动.sh