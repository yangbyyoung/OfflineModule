#!/system/bin/sh
MODDIR=${0%/*}

b=/sdcard/Download


mkdir $b/Magisk备份文件
cd /data/adb
cp -rf /data/adb $b/Magisk备份文件/MagiskScript

cd /data/data/com.topjohnwu.magisk
cp -rf /data/data/com.topjohnwu.magisk $b/Magisk备份文件/MagiskUserData
rm -rf $b/Magisk备份文件/MagiskUserData/cache

cd /data/user_de/0/com.topjohnwu.magisk
cp -rf /data/user_de/0/com.topjohnwu.magisk $b/Magisk备份文件/MagiskFrameworkData

cd $b/Magisk备份文件
tar -cvf Magisk备份文件.tar -C $b/Magisk备份文件 .
rm -rf $b/Magisk备份文件

