rm -rf /data/adb/service.d/Delete.sh
rm -rf /data/system/package_cache/*