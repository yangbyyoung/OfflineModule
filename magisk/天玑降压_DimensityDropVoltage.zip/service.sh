#!/system/bin/sh

MODDIR=${0%/*}

dalvikvm -cp $MODDIR/drop Main $MODDIR
exit 0
