HChen=${0%/*}
HChen=${HChen//\/main_program/}
sdk=$(getprop ro.system.build.version.sdk)
magiskpolicy --live "allow system_server * * *"
a=10 && b=5 && c=4 && d=3 && e=1 && f=1000000
ksu_check=false && record=0
[[ -f "/data/adb/ksud" ]] && ksu_check=true
zram=$(grep 'MemTotal' </proc/meminfo | tr -cd "0-9")
swap_conf="$HChen/swap/swap.ini"
{ [[ -f $swap_conf ]] && { . "$swap_conf" && echo "- [i]: 配置文件读取成功"; } || { echo "- [!]: 配置文件读取异常" && exit 1; }; } || { echo "- [!]: 缺少$swap_conf" && exit 2; }
set_value_log() {
  echo "- [i]:设置$2" && now=$(cat "$2")
  { [[ $1 == "$now" ]] && echo "- [i]:目标设置为:$1,实际设置为:$now"; } || { echo "- [!]:目标设置为:$1,实际设置为:$now"; }
}
set_value() {
  { [[ -f "$2" ]] && {
    chmod 666 "$2" &>/dev/null
    echo "$1" >"$2"
    chmod 664 "$2" &>/dev/null
    set_value_log "$1" "$2"
  }; } || { echo "- [!]: 不存在$2文件"; }
}
update_overlay() {
  { sed -i "s/\(Name=\"$1\"[[:blank:]]*Value=\"\)[^\"]*\(\"\)/\1$2\2/g" "$qcom_now_file" && { grep -q "Name=\"$1\"[[:blank:]]*Value=\"$2\"" "$qcom_now_file"; }; } && { echo "$1=$2" >>"$HChen"/Qualcomm; }
}
camera_mod() {
  sed -i "s/\"$1\": true/\"$1\": $2/g" "$camera_now_file"
}
send_notifications() {
  { [[ $(pm list package | grep -w 'com.google.android.ext.services') != "" ]]; } && { cmd notification allow_assistant "com.google.android.ext.services/android.ext.services.notification.Assistant"; }
  su -lp 2000 -c \
    "cmd notification post -S messaging --conversation '$2' --message '$2':'$1' Tag '$RANDOM'" &>/dev/null
}
for_mod() {
  for i in $1; do
    $2 $3 $4 $5 $i$6 $7
  done
}
echo "---------------------------------------------------------------------------"
set_zram() {
  [[ ! -e /dev/block/zram0 ]] && { { [[ -e /sys/class/zram-control ]] && echo "- [i]:内核支持ZRAM"; } || { echo "- [!]:内核不支持ZRAM" && return; }; }
  { [[ $zram -gt $(($f * 15)) ]] && zram_in=$(($a + $b + $c)); } || { [[ $zram -gt $(($f * 11)) ]] && zram_in=$(($a + $b)); } || { [[ $zram -gt $(($f * 7)) ]] && zram_in=$(($a + $e)); } || { [[ $zram -gt $(($f * 5)) ]] && zram_in=$(($a - $e)); } || { [[ $zram -gt $(($f * 3)) ]] && zram_in=$(($a - $d)); } || { zram_in=$b; }
  zram_size=$(awk 'BEGIN{print '$zram_in'*(1024^3)}')
  echo "- [i]:重置ZRAM所有设置"
  for_mod "/dev/block/zram*" "swapoff" "" "" "" "" &>/dev/null
  [[ $zram_size == "0" ]] && return
  set_value none /sys/block/zram0/backing_dev
  set_value 1 /sys/block/zram0/writeback_limit_enable
  set_value 0 /sys/block/zram0/writeback_limit
  set_value 1 /sys/block/zram0/reset
  set_value 0 /sys/block/zram0/mem_limit
  set_value 8 /sys/block/zram0/max_comp_streams
  echo "- [i]:正在设置压缩模式"
  echo "$comp_algorithm" >/sys/class/block/zram0/comp_algorithm
  tt=$(cat /sys/class/block/zram0/comp_algorithm)
  ttt=$(echo "$tt" | sed 's/\[//g' | sed 's/]//g' | sed 's/ /\n/g' | grep -w "$comp_algorithm")
  { [[ $comp_algorithm == "$ttt" ]] && echo "- [i]:目标设置为:$comp_algorithm,实际设置为:$ttt"; } || { echo "- [!]:目标设置为:$comp_algorithm,实际设置为:$ttt"; }
  echo "- [i]:正在设置ZRAM大小"
  echo "$zram_size" >/sys/block/zram0/disksize
  pk=$(cat /sys/block/zram0/disksize)
  { [[ $pk == "$zram_size" ]] && echo "- [i]:目标设置为:$zram_size,实际设置为:$pk"; } || { echo "- [!]:目标设置为:$zram_size,实际设置为:$pk"; }
  echo "- [i]:初始化ZRAM" && mkswap /dev/block/zram0 &>/dev/null
  echo "- [i]:启动ZRAM" && swapon /dev/block/zram0 &>/dev/null
}
set_vm_params() {
  echo "---------------------------------------------------------------------------"
  swappinessd="/proc/sys/vm/swappiness"
  echo "160" >$swappinessd
  { [[ $? -eq 1 ]] && swappiness=95; } || { swappiness=160; }
  echo "- [i]:正在设置swappiness"
  echo "$swappiness" >$swappinessd
  tk=$(cat $swappinessd)
  { [[ $tk == "$swappiness" ]] && echo "- [i]:目标设置为:$swappiness,实际设置为:$tk"; } || { echo "- [!]:目标设置为:$swappiness,实际设置为:$tk"; }
  set_value "$swappiness" /dev/memcg/memory.swappiness
  set_value "$swappiness" /dev/memcg/apps/memory.swappiness
  set_value "$swappiness" /sys/fs/cgroup/memory/apps/memory.swappiness
  set_value "$swappiness" /sys/fs/cgroup/memory/memory.swappiness
  { [[ $zram -gt $(($f * 15)) ]] && watermark=500; } || { [[ $zram -gt $(($f * 11)) ]] && watermark=450; } || { [[ $zram -gt $(($f * 7)) ]] && watermark=400; } || { [[ $zram -gt $(($f * 5)) ]] && watermark=350; } || { [[ $zram -gt $(($f * 3)) ]] && watermark=300; } || { watermark=250; }
  echo "- [i]:正在设置watermark"
  echo "$watermark" >/proc/sys/vm/watermark_scale_factor
  lt=$(cat /proc/sys/vm/watermark_scale_factor)
  { [[ $lt == "$watermark" ]] && echo "- [i]:目标设置为:$watermark,实际设置为:$lt"; } || { echo "- [!]:目标设置为:$watermark,实际设置为:$lt"; }
  echo "- [i]:设置cache参数"
  set_value 10 /proc/sys/vm/dirty_background_ratio
  set_value 80 /proc/sys/vm/dirty_ratio
  set_value 2000 /proc/sys/vm/dirty_expire_centisecs
  set_value 300 /proc/sys/vm/dirty_writeback_centisecs
  set_value 150 /proc/sys/vm/vfs_cache_pressure
  echo "- [i]:设置其它vm参数"
  set_value 1 /proc/sys/vm/oom_kill_allocating_task
  set_value 0 /proc/sys/vm/oom_dump_tasks
  set_value 1 /proc/sys/vm/compact_unevictable_allowed
  set_value 0 /proc/sys/vm/block_dump
  set_value 20 /proc/sys/vm/stat_interval
  set_value 1 /proc/sys/vm/overcommit_memory
  set_value 0 /proc/sys/vm/panic_on_oom
  set_value 0 /sys/module/process_reclaim/parameters/enable_process_reclaim
  set_value 0 /sys/kernel/mi_reclaim/enable
  { [[ $comp_algorithm == "zstd" ]] && set_value 0 /proc/sys/vm/page-cluster; } || { set_value 1 /proc/sys/vm/page-cluster; }
}
other_setting() {
  lowmemorykiller="/sys/module/lowmemorykiller/parameters"
  [[ -d $lowmemorykiller ]] && {
    set_value 1024,1025,1026,1027,1028,1029 $lowmemorykiller/minfree
    set_value 0 $lowmemorykiller/vmpressure_file_min
    set_value 0 $lowmemorykiller/enable_adaptive_lmk
    set_value 0 $lowmemorykiller/oom_reaper
    echo "- [i]:设置lmk优化(旧内核)"
  }
  for_mod "/sys/block/sd*" "set_value" "deadline" "" "" "/queue/scheduler"
  for_mod "/sys/block/sd*" "set_value" "256" "" "" "/queue/read_ahead_kb"
  for_mod "/sys/block/sd*" "set_value" "64" "" "" "/queue/nr_requests"
  for_mod "/sys/block/sd*" "set_value" "2" "" "" "/queue/rq_affinity"
  echo "- [i]:设置io调度参数完成"
  [[ -f /sys/kernel/mm/lru_gen/enabled ]] && { set_value y /sys/kernel/mm/lru_gen/enabled && echo "- [i]:设置开启multi-gen LRU"; }
  camera_file="/system/system_ext/etc/camerabooster.json"
  { [[ $ksu_check != "true" ]] && { camera_folder="$HChen/system/system_ext/etc/" && camera_now_file="$HChen/system/system_ext/etc/camerabooster.json"; }; } || { camera_folder="$HChen/system_ext/etc/" && camera_now_file="$HChen/system_ext/etc/camerabooster.json"; }
  [[ -f $camera_file ]] && { { [[ ! -f $camera_now_file ]] && {
    let record++
    mkdir -p "$camera_folder"
    cp -f "$camera_file" "$camera_folder" && {
      camera_mod cam_boost_enable false
      camera_mod 3rdcam_boost_enable false
      camera_mod cam_boost_opt_enable false
      camera_mod cam_boost_forcestop_enable false
      camera_mod mms_camcpt_enable false
      camera_mod inhibit_procs_enable false
      camera_mod inhibit_3rdprocs_enable false
      camera_mod oom_update_support false
      camera_mod cam_reclaim_enable false
      camera_mod adj_swap_support false
      camera_mod trim_memory_support false
      camera_mod cam_boost_early_enable false
      camera_mod perceptible_support false
      echo "- [i]:已优化相机杀后台问题"
      echo "- [!]:为了完全生效请再重启一次"
    } || { echo "- [!]:复制相机配置文件失败"; }
  }; } || { { [[ $(du -k "$camera_now_file" | cut -f1) -ne 0 ]] && { echo "- [i]:已优化相机杀后台问题"; }; } || { echo "- [!]:修改后相机配置文件为空"; }; }; }
  qcom_file="/vendor/etc/perf/perfconfigstore.xml"
  { [[ $ksu_check != "true" ]] && { qcom_folder="$HChen/system/vendor/etc/perf/" && qcom_now_file="$HChen/system$qcom_file"; }; } || { qcom_folder="$HChen/vendor/etc/perf/" && qcom_now_file="$HChen$qcom_file"; }
  [[ "$(getprop ro.hardware)" == "qcom" ]] && { {
    [[ -f $qcom_file ]] && [[ $(du -k "$qcom_file" | cut -f1) -ne 0 ]] && {
      { [[ ! -f $qcom_now_file ]] && {
        mkdir -p "$qcom_folder"
        cp -f "$qcom_file" "$qcom_folder"
        touch "$HChen"/Qualcomm
        update_overlay vendor.debug.enable.lm false update_overlay ro.vendor.qti.sys.fw.bservice_age 2147483647
        update_overlay ro.vendor.qti.sys.fw.bservice_limit 2147483647
        update_overlay ro.vendor.perf.enable.prekill false
        update_overlay vendor.prekill_MIN_ADJ_to_Kill 1001
        update_overlay vendor.prekill_MAX_ADJ_to_Kill 1001
        update_overlay vendor.debug.enable.memperfd false
        update_overlay ro.lmk.thrashing_limit_pct_dup 100
        update_overlay ro.lmk.kill_heaviest_task_dup false
        update_overlay ro.lmk.kill_timeout_ms_dup 500
        update_overlay ro.lmk.thrashing_threshold 100
        update_overlay ro.lmk.thrashing_decay 10
        update_overlay ro.lmk.nstrat_psi_partial_ms 600
        update_overlay ro.lmk.nstrat_psi_complete_ms 900
        update_overlay ro.lmk.nstrat_psi_scrit_complete_stall_ms 1000
        update_overlay ro.lmk.nstrat_wmark_boost_factor 0
        update_overlay ro.lmk.enhance_batch_kill false
        update_overlay ro.lmk.enable_watermark_check false
        update_overlay ro.lmk.enable_preferred_apps false
        update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 2147483647
        update_overlay ro.vendor.qti.sys.fw.empty_app_percent 100
        update_overlay ro.lmk.enable_userspace_lmk false
        update_overlay vendor.perf.phr.enable 0
        update_overlay ro.lmk.super_critical 1001
        update_overlay ro.lmk.direct_reclaim_pressure 100
        update_overlay ro.lmk.reclaim_scan_threshold 0
        update_overlay ro.vendor.qti.am.reschedule_service true
        update_overlay ro.lmk.nstrat_low_swap 0
        echo "- [i]:成功执行高通专改"
        echo "- [!]:为了完全生效请再重启一次"
        let record++
      }; } || { echo "- [i]:成功执行高通专改"; }
    }
  } || { echo "- [!]:源文件为空，无法进行高通专改"; }; }
}
on_prop_pool() {
  prop_pool="
  ro.config.low_ram=false
  persist.sys.mms.bg_apps_limit=2147483647
  persist.sys.mms.write_lmkd=false
  persist.sys.mms.camcpt_enable=false
  persist.sys.mms.compact_enable=false
  persist.sys.mms.single_compact_enable=false
  persist.sys.mms.min_zramfree_kb=2147483647
  persist.miui.miperf.enable=false
  ro.config.per_app_memcg=false
  ro.vendor.qti.sys.fw.bservice_limit=2147483647
  persist.device_config.activity_manager.max_cached_processes=2147483647
  persist.sys.spc.enabled=false
  persist.sys.spc.extra_free_enable=false
  persist.sys.spc.screenoff_kill_enable=false
  persist.sys.spc.pressure.enable=false
  ro.lmk.use_minfree_levels=false
  ro.lmk.debug=false
  ro.lmk.thrashing_limit=100
  ro.lmk.thrashing_limit_decay=10
  ro.lmk.psi_partial_stall_ms=600
  ro.lmk.psi_complete_stall_ms=900
  ro.lmk.swap_free_low_percentage=0
  ro.lmk.low=1001
  ro.lmk.medium=1001
  ro.lmk.critical=1001
  ro.lmk.critical_upgrade=false
  ro.lmk.upgrade_pressure=100
  ro.lmk.downgrade_pressure=100
  ro.lmk.kill_heaviest_task=false
  ro.lmk.kill_timeout_ms=500
  ro.lmk.enhance_batch_kill=false
  ro.lmk.enable_adaptive_lmk=false
  persist.sys.oom_crash_on_watchdog=false
  persist.sys.lmk.camera.mem_reclaim=false
  persist.sys.lmk.reportkills=false
  sys.lmk.reportkills=0
  ro.lmk.swap_util_max=100
  persist.sys.spc.kill.proc.enable=false
  persist.sys.miui.camera.boost.enable=false
  persist.sys.miui.camera.boost.killAdj_threshold=1001
  persist.sys.miui.camera.boost.kill701_threshold=0
  persist.sys.minfree_6g=1024,1025,1026,1027,1028,1029
  persist.sys.minfree_8g=1024,1025,1026,1027,1028,1029
  persist.sys.minfree_12g=1024,1025,1026,1027,1028,1029
  persist.sys.minfree_def=1024,1025,1026,1027,1028,1029
  persist.sys.lmk.camera_minfree_levels=1024:1001,1025:1001,1026:1001,1027:1001,1028:1001,1029:1001
  persist.sys.lmk.camera_minfree_6g_levels=1024:1001,1025:1001,1026:1001,1027:1001,1028:1001,1029:1001
  persist.sys.oplus.hybridswap_app_uid_memcg=false
  persist.sys.oplus.hybridswap_app_memcg=false
  sys.lmk.minfree_levels=1024:1001,1025:1001,1026:1001,1027:1001,1028:1001,1029:1001
  persist.sys.debug.enable_scout_memory_monitor=false
  persist.sys.debug.enable_scout_memory_resume=false
  persist.sys.miui.adj_swap_free_percentage.enable=false
  persist.sys.oppo.junkmonitor=false
  vendor.sys.vm.killtimeout=500
  ro.sys.fw.bg_apps_limit=2147483647
  ro.vendor.qti.sys.fw.bg_apps_limit=2147483647
  persist.sys.oplus.nandswap=false
  persist.sys.oplus.lmkd_super_critical_threshold_12g=0
  persist.sys.oplus.lmkd_super_critical_threshold_16g=0
  persist.sys.oplus.lmkd_super_critical_threshold_8g=0
  persist.sys.oplus.wmark_extra_free_kbytes_12g=0
  persist.sys.oplus.wmark_extra_free_kbytes_8g=0
  ro.sys.fw.empty_app_percent=100
  persist.vendor.qti.memory.enable=false
  persist.vendor.sys.memplus.enable=false
  persist.vendor.qti.memory.fooI=false
  vendor.debug.enable.lm=false
  ro.vendor.qti.sys.fw.bservice_age=2147483647
  ro.vendor.perf.enable.prekill=false
  vendor.prekill_MIN_ADJ_to_Kill=1001
  vendor.prekill_MAX_ADJ_to_Kill=1001
  vendor.debug.enable.memperfd=false
  ro.lmk.thrashing_limit_pct_dup=100
  ro.lmk.kill_heaviest_task_dup=false
  ro.lmk.kill_timeout_ms_dup=500
  ro.lmk.thrashing_threshold=100
  ro.lmk.thrashing_decay=10
  ro.lmk.nstrat_psi_partial_ms=600
  ro.lmk.nstrat_psi_complete_ms=900
  ro.lmk.nstrat_psi_scrit_complete_stall_ms=1000
  ro.lmk.nstrat_wmark_boost_factor=0
  ro.lmk.enable_watermark_check=false
  ro.lmk.enable_preferred_apps=false
  ro.vendor.qti.sys.fw.empty_app_percent=100
  ro.lmk.enable_userspace_lmk=false
  vendor.perf.phr.enable=0
  ro.lmk.super_critical=1001
  ro.lmk.direct_reclaim_pressure=100
  ro.lmk.reclaim_scan_threshold=0
  ro.vendor.qti.am.reschedule_service=true"
  echo "- [i]:开始进行prop参数修改"
  [[ -f "$HChen"/Prop_on ]] && prop_on=$(cat "$HChen"/Prop_on)
  { [[ $prop_on == 0 ]] && {
    echo "- [!]:为了完全生效请再重启一次"
    let record++
    echo "vtools.swap.controller=module" >"$HChen"/system.prop
    for p in $prop_pool; do
      check_prop=$(echo "$p" | cut -d '=' -f1)
      [[ $(getprop "$check_prop") != "" ]] && {
        resetprop "$check_prop" "$(echo "$p" | cut -d '=' -f2)"
        echo "$check_prop" "$(getprop "$check_prop")"
        echo "$p" >>"$HChen"/system.prop
      }
    done
    [[ $sdk != "33" ]] && { [[ $(getprop ro.lmk.use_psi) != "" ]] && {
      resetprop ro.lmk.use_psi true
      echo "ro.lmk.use_psi $(getprop ro.lmk.use_psi)"
      echo "ro.lmk.use_psi=true" >>"$HChen"/system.prop
    }; }
    echo -n "1" >"$HChen"/Prop_on
  }; } || {
    prop_kk=$(cat "$HChen"/system.prop)
    echo "- [i]:正在加载prop参数列表"
    echo "$prop_kk"
    for k in $prop_kk; do
      one=$(getprop "$(echo "$k" | cut -d '=' -f1)")
      two=$(echo "$k" | cut -d '=' -f2 | tr -d '[:cntrl:]')
      kk=$(echo "$k" | cut -d '=' -f1 | tr -d '[:cntrl:]')
      [[ $one != "$two" ]] && {
        echo "- [!]:$kk设置失败,设置为:$two,实际为:$one"
        resetprop "$kk" "$two"
        pp=$(getprop "$kk")
        echo "- [i]:尝试重新设置$kk,设置为:$pp"
      }
    done
    let prop_on++
    echo -n "$prop_on" >"$HChen"/Prop_on
  }
  echo "- [i]:修改prop参数完毕"
  [[ -f $qcom_now_file ]] && [[ $(du -k "$HChen/Qualcomm" | cut -f1) -eq 0 ]] && { echo "- [!]:修改后高通配置文件为空"; }
  [[ -f "$HChen"/Qualcomm ]] && { { [[ $(du -k "$HChen/Qualcomm" | cut -f1) -ne 0 ]] && { echo "- [i]:读取高通专改内容" && cat "$HChen"/Qualcomm; }; } || { echo "- [!]:高通专改修改内容为空"; }; }
}
stop_services() {
  stopd() {
    { stop "$1"; } && { echo "- [i]:已停止服务:$1"; }
  }
  echo "- [i]:正在处理无用系统服务"
  stopd slad
  stopd oplus_kevents
  stopd vendor_tcpdump
  stopd miuibooster
  stopd sla-service-hal-1-0
  [[ $(getprop Build.BRAND) == "MTK" ]] && {
    stopd aee.log-1-1
    stopd charge_logger
    stopd connsyslogger
    stopd emdlogger
    stopd mobile_log_d
  }
}
binding_mod() {
  for_mod "$(pgrep "$1")" "taskset" "-p" "$2" "" "" &>/dev/null
  for_mod "$(pgrep "$1")" "renice" "-n" "$3" "-p" "" &>/dev/null
}
thread_binding() {
  kswapd_cpus=11110000
  mask=$(echo "obase=16;$((2#$kswapd_cpus))" | bc)
  binding_mod kswapd "$mask" -10
  echo "- [i]:设置kswapd线程成功"
  kswapd_cpusd=00001111
  maskd=$(echo "obase=16;$((2#$kswapd_cpusd))" | bc)
  binding_mod oom_reaper "$maskd" -6
  echo "- [i]:设置oom_reaper线程成功"
  binding_mod lmkd "$maskd" -6
  echo "- [i]:设置lmkd线程成功"
}
close_miui() {
  packages=$(pm list packages -s | sed 's/package://g' | grep 'com.mediatek.duraspeed')
  [[ $(getprop Build.BRAND) == "MTK" ]] && { {
    [[ $close_kuaiba == "on" ]] && [[ $packages == "com.mediatek.duraspeed" ]] && {
      pm disable com.mediatek.duraspeed &>/dev/null
      pm disable com.mediatek.duraspeed/com.mediatek.duraspeed.DuraSpeedAppReceiver &>/dev/null
      pm disable com.mediatek.duraspeed/com.mediatek.duraspeed.RestrictHistoryActivity &>/dev/null
      pm disable com.mediatek.duraspeed/com.mediatek.duraspeed.DuraSpeedMainActivity &>/dev/null
      pm clear com.mediatek.duraspeed &>/dev/null
      echo "- [i]:成功处理MTK快霸"
    }
  } || { [[ $close_kuaiba == "on" ]] && echo "- [i]:成功处理MTK快霸"; }; }
}
hot_patch() {
  { [[ -d "/data/adb/modules/Hot_patch/" ]] || [[ -d "/data/adb/ksu/modules/Hot_patch/" ]]; } && {
    rm -rf /data/adb/modules/Hot_patch/
    rm -rf /data/adb/ksu/modules/Hot_patch/
    echo "- [i]:成功删除补丁模块"
  }
}
scene_delete() {
  ksu="/data/adb/ksu/modules"
  magisk="/data/adb/modules"
  check="
  $ksu/scene_swap_controller
  $ksu/swap_controller
  $magisk/scene_swap_controller
  $magisk/swap_controller
  /data/adb/swap_controller/
  /data/swap_recreate
  /data/swapfile*"
  for t in $check; do
    [[ -d $t ]] && rm -rf "$t" && echo "- [!]:发现冲突已经删除目录:$t" && delete=yes
  done
}
volume_keys() {
  timeout=0
  while :; do
    sleep 0.5
    let timeout++
    [[ $timeout -gt 30 ]] && {
      send_notifications "$1" "保后台能力增强模块"
      break
    }
    volume="$(getevent -qlc 1 | awk '{ print $3 }')"
    case "$volume" in
    KEY_VOLUMEUP)
      send_notifications "$2" "保后台能力增强模块"
      sleep 10
      reboot
      ;;
    KEY_VOLUMEDOWN)
      send_notifications "$3" "保后台能力增强模块"
      ;;
    *) continue ;;
    esac
    break
  done
}
last_mod() {
  { [[ $record != "0" ]] && {
    send_notifications "提示:为了所有修改完全生效请再重启一次!$(echo -en "\n正在进行音量键监听!")$(echo -en "\n按音量上键自动重启")$(echo -en "\n按音量下键手动重启")" "保后台能力增强模块"
    volume_keys "注意:超时未检测到音量键，请手动重启!" "注意:即将在10秒后重启!" "注意:已经取消重启，请手动重启!"
  }; } || { [[ $delete == "yes" ]] && {
    send_notifications "警告:发现冲突！模块已经自动处理，请再重启一次!$(echo -en "\n正在进行音量键监听!")$(echo -en "\n按音量上键自动重启")$(echo -en "\n按音量上键手动重启")" "保后台能力增强模块"
    volume_keys "注意:超时未检测到音量键，请手动重启!" "注意:即将在10秒后重启!" "注意:已经取消重启，请手动重启!"
  }; } || {
    time=$(date "+%Y年%m月%d日_%H时%M分%S秒")
    send_notifications "$(echo -en "保后台模块成功启动!")$(echo -en "\n启动时间:$time")$(echo -en "\n设置压缩模式:$tt")$(echo -en "\n设置ZRAM大小:$pk")" "保后台能力增强模块"
  }
}
{
  chmod 666 /sys/class/block/zram0/comp_algorithm
  chmod 666 /sys/block/zram0/disksize
  chmod 666 /proc/sys/vm/swappiness
  chmod 666 /proc/sys/vm/watermark_scale_factor
}
{
  scene_delete
  set_zram
  set_vm_params
  other_setting
  on_prop_pool
  stop_services
  thread_binding
  close_miui
  hot_patch
  sleep 10 && {
    last_mod
  }
}
