#!/system/bin/sh

function install_magisk_busybox() {
mkdir -p /data/adb/busybox
/data/adb/magisk/busybox --install -s /data/adb/busybox
chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

#添加busybox，避免参数无用。
install_magisk_busybox

#死循环快充，已经弃用！
#sleep_time="${2}m"

#模块目录
dir="${0%/*}"
MODPATH="${dir%/*}"
#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}


#限制电流数值
limit_current="$( show_value '修改电流数' | tr -cd '[0-9]' )"
#脚本文件
script_file="${0%/*}/charge.sh"
#删除旧的脚本
test -f "${script_file}" && rm -rf "${script_file}"

#模块目录
dir="${0%/*}"
MODPATH="${dir%/*}"
#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}



#模块的函数支持
function print_head() {
cat << key

export PATH=/data/adb/busybox:\$PATH


function battery_status() {
	dumpsys battery | grep 'status' | grep -Eo "[0-9]"
}

function key_echo(){
test -f "\${2}" && {
	chmod 0777 "\${2}"
		echo "\${1}" > "\${2}"
	chmod 0444 "\${2}" 
	}
}

#智能充电保护
resetprop -p persist.vendor.night.charge true

limit_current="$limit_current"

key
}


function limit_current() {
	local file="$1"
	test -f "$file" && {
		local value="$(cat $file)"
		#echo "存在 $file 值：$value "
cat<<key
			key_echo "\$limit_current" $file
key
	}
}

function check_restrict() {
	local file="$1"
	test -f "$file" && {
		local value="$(cat $file)"
		#echo "存在 $file 值：$value "
cat<<key
			key_echo "1" $file
key
	}
}

function check_limit() {
	local file="$1"
	test -f "$file" && {
		local value="$(cat $file)"
		#echo "存在 $file 值：$value "
cat<<key
			key_echo "0" $file
key
	}
}


function echo_current(){
		find /sys -iname "*_charge_level" -o -iname "boost_current" -o -iname "input_current_settled" -o -iname "hw_current_max" -o -iname "pd_current_max" -o -iname "constant_charge_current_max"  -o -iname "charge_current"  -o -iname "restricted_current" -o -iname "current_max" -o -iname "thermal_input_current" -o -iname "fast_charge_current" -o -iname "constant_charge_current" -o -iname "hw_current" -o -iname "pd_current"  -o -iname "default_.*_icl_ma" -o -iname "dcp_max_current" -o -iname "hvdcp_max_current" -o -iname "ctm_current_max" -o -iname "sdp_current_max" -o -iname "max_current" -o -iname "input_current" 2> /dev/null | while read i ;do
local current=$(cat ${i})
test "$(echo "$current" | grep -w '\-' )" != "" && continue
test "$current" = "0" && continue
test "$current" = "1" && continue
		limit_current "$i"
	done
}

function echo_restrict(){
	find /sys -iname "skip_thermal" -o -iname "force_fast_charge" -o -iname "pd_allowed" -o -iname "allow_hvdcp3" 2> /dev/null | while read restrict ;do
	check_restrict "$restrict"
done
}

function echo_limit(){
	find /sys -iname "safety_timer_enabled" -o -iname "system_temp_level" -o -iname "dynamic_fv_enabled" -o -iname "input_current_limited" -o -iname "sw_jeita_enabled" -o -iname "restricted_charging" -o -iname "step_charging_enabled" 2> /dev/null | while read limit ;do
	check_limit "$limit"
done
}


function find_current(){
	find /sys -iname "*current*max" -type f -o -iname "charge*current*" -type f 2> /dev/null | while read value ;do
	limit_current "$value"
done
}


#死循环快充模式
function mode_1(){
cat <<key>${script_file}

$(print_head)

while :; do
	if test "\$(battery_status)" = "2" ;then
$(echo_current)
$(echo_restrict)
$(echo_limit)
		sleep 1s
	else
		sleep $sleep_time
	fi
done
key
}

#仅在开机后执行五次
function mode_2(){
cat <<key>${script_file}

$(print_head)
a="0"
while :; do
$(echo_current)
$(echo_restrict)
$(echo_limit)
		a=\$((\$a + 1))
	test "\$a" = "5" && break
done
key
}

#不修改电流，仅解除充电限制。
function mode_3(){
cat <<key>${script_file}

$(print_head)
a="0"
while :; do
$(echo_restrict)
$(echo_limit)
		a=\$((\$a + 1))
	test "\$a" = "5" && break
done
key
}


if test "$(show_value '修改充电速度')" != "是" ;then
echo "不修改充电速度……"
#输出并且运行脚本
mode_3 && {
chmod -R 0777 "${script_file%/*}"
nohup "${script_file}" & >/dev/null 2>&1
}
else
mode_2 && {
chmod -R 0777 "${script_file%/*}"
nohup "${script_file}" & >/dev/null 2>&1
}
fi
