check_android_version() {
  if [ "$API" -ge 29 ]; then
    ui_print "- Android SDK version: $API"
  else
    ui_print "*********************************************************"
    ui_print "! Requires Android Q (API 29) or above"
    abort "*********************************************************"
  fi
}

check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER ($MAGISK_VER_CODE)"

  if [ "$MAGISK_VER_CODE" -lt 24000 ]; then
    ui_print "*******************************"
    ui_print " Please install Magisk v24+! "
    ui_print "*******************************"
  fi
}

enforce_install_from_magisk_app() {
  if [ ! "$BOOTMODE" ]; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Some recovery has broken implementations, install with such recovery will finally cause Riru or Riru modules not working"
    ui_print "! Please install from Magisk app"
    abort "*********************************************************"
  fi
}

extract_library() {
  ui_print "- Extracting ${1} libraries"
  extract "$ZIPFILE" "lib/${1}/lib$ZYGISK_MODULE_LIB_NAME.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/lib$ZYGISK_MODULE_LIB_NAME.so" "$MODPATH/zygisk/${1}.so"
}
