# Magisk Module Template

This `README.md` will be shown in Magisk Manager. Place any information / changelog / notes you like.

**Please update `README.md` if you want to submit your module to the online repo!**

Github has its own online markdown editor with a preview feature, you can use it to update your `README.md`! If you need more advanced syntax, check the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

For more information about modules and repos, please check the [official documentations](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)

---
# **MIUI12.5骁龙870开机自检动画**

## Description
修改默认开机动画/system/media/bootanimation.zip
替换为骁龙870开机自检动画

## Changelog
- Version 1.5.2 更新素材，重切分片以修复跳变，并且整合版本号
- Date 21.04.28
- Version 1.3 再次修改desc结构以修复动画循环问题
- Date 21.04.28
- Version 1.2 修改desc结构以缩短末尾帧过长的驻留时间
- Date 21.04.28
- Version 1.1 适配大小1080×2340以修正畸变
- Date 21.04.28
- Version 1.0 原结构素材套用未做改动
- Date 21.04.28

## Requirements
- 只适用于MIUI12.5默认开机动画
- 如有第三方主题或使用其他开机动画magisk模块请勿刷入

## Instructions
- 测试机型为红米K40
- 参考环境为Android 11/Magisk 23.0
- 仅在测试机型刷入成功且使用正常
- 刷入机型和版本未做限制，请自行甄别慎重刷入