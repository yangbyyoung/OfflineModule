sleep 2s

#通过对sched_relax_domain_level值的修改，扩大cpu负载均衡时查找的范围，防止因为某个范围内的核心因为负载过大而降低性能。

echo 1 > /dev/cpuset/sched_relax_domain_level
echo 1 > /dev/cpuset/system-background/sched_relax_domain_level
echo 1 > /dev/cpuset/background/sched_relax_domain_level
echo 1 > /dev/cpuset/foreground/sched_relax_domain_level
echo 1 > /dev/cpuset/top-app/sched_relax_domain_level