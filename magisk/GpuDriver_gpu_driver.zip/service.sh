# !/system/bin/sh
#

gpudir=/sys/class/kgsl/kgsl-3d0;

getlist=$(cat $gpudir/gpu_available_frequencies)
getfreq=${getlist%% *}
shortfreq=$(echo $getfreq | sed 's/000000//g')

echo $shortfreq > $gpudir/max_clock_mhz
echo $getfreq > $gpudir/max_gpuclk
echo $getfreq > $gpudir/devfreq/max_freq

sleep 1
done