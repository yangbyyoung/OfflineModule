MODDIR=${0%/*}
#简易触发器
while true ; do
  	if [ `cat "$MODDIR/SleepLocker"` == "Lock" ] ; then
		userdata=`cat "$MODDIR/userdata_num"`
		free_space=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		sleeptime=$(echo "scale=0; $free_space/3" | bc)
  		sleep $sleeptime
  		echo "UnLock" >$MODDIR/SleepLocker
  	else
		level=0
		until [ "$level" -ge "60" ] ; do
			info_old=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
			total_old=$(echo $info_old | awk '{print $1+$2+$3+$4+$5+$6+$7}')
			usage_old=$(echo $info_old | awk '{print $1+$2+$3}')
			sleep 5
			info_new=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
			total_new=$(echo $info_new | awk '{print $1+$2+$3+$4+$5+$6+$7}')
			usage_new=$(echo $info_new | awk '{print $1+$2+$3}')
			busy=$(($usage_new - $usage_old))
			cputime=$(($total_new - $total_old))
			usage=$(echo "scale=0; $busy*100/$cputime" | bc)
			if [ "$usage" -le "39" ] ; then
				level=$(($level + 1 ))
			else
				if [ "$level" -ge "2" ] ; then
					level=$(($level - 2 ))
				fi
  			fi
  		done
  		sh $MODDIR/main.sh
  	fi
done
