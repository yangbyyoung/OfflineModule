bootpath=$(find /system /my_product -type f -iname "*bootanimation*.zip" 2>/dev/null | sed 's/\/product/\/system\/product/g' | sed 's/\/system\/system/\/system/g' )
for i in $bootpath;do
mkdir -p $MODPATH/$(dirname $i)
cp -rf $MODPATH/*.zip $MODPATH/$i
done

bootpath_dark=$(find /system /product -type f -iname "*bootanimation-dark*.zip" 2>/dev/null | sed 's/\/product/\/system/product/g' | sed 's/\/system\/system/\/system/g' )
for d in $bootpath_dark;do
mkdir -p $MODPATH/$(dirname $d)
cp -rf $MODPATH/*.zip $MODPATH/$d
done



#检测冲突模块
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
for o in $bootpath;do
if [[ -e "$module_id/$o" ]] && [[ "$module_id" != "$id" ]] && [[ ! -e "$module_id/remove" ]] && [[ ! -e "$module_id/disable" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块存在开机动画"
echo "－已经停用……"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
touch $module_id/disable
fi
done
for i in $bootpath_dark;do
if [[ -e "$module_id/$i" ]] && [[ "$module_id" != "$id" ]] && [[ ! -e "$module_id/remove" ]] && [[ ! -e "$module_id/disable" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块存在开机动画"
echo "－已经停用……"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
touch $module_id/disable
fi
done
done



