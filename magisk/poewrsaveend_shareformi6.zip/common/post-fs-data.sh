#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
#
#these will not work.
echo 1 > /sys/module/snd_soc_wcd9xxx/parameters/impedance_detect_en
echo 1 > /sys/module/snd_soc_wcd9330/parameters/high_perf_mode
echo 0 > /sys/module/lowmemorykiller/parameters/debug_level
echo 1 > /sys/block/mmcblk0/queue/rq_affinity
echo 0 > /sys/block/mmcblk0/queue/nomerges
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 1 > /sys/block/mmcblk0/queue/add_random
echo 1 > /sys/kernel/dyn_fsync/Dyn_fsync_active
echo 1 > /sys/kernel/autosmp/conf/scroff_single_core
echo 1 > /sys/kernel/autosmp/conf/min_cpus
echo 265 > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo 1 > /sys/class/graphics/fb0/SRGB
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/sync/parameters/fsync_enabled