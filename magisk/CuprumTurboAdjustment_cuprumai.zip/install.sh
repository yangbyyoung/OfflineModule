#!/sbin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
#CupumTurbo Installer V5.0
ui_print "- CCCCCC  U    U  PPPPPP  RRRRRR  U    U  M     M"
ui_print "- C       U    U  P    P  R    R  U    U  M  M  M"
ui_print "- C       U    U  PPPPPP  RRR     U    U  M     M"
ui_print "- C       U    U  P       R  R    U    U  M     M"
ui_print "- CCCCCC  UUUUUU  P       R    R  UUUUUU  M     M"
ui_print "- Copyright (C) Chenzyadb ALL Rights Reserved."
ui_print "- Powered by Magisk (@topjohnwu)"
ui_print " "
ui_print "- Check if this adjustment is available for your device."
SDK=$(getprop ro.build.version.sdk)
KernelVersionStr=$(uname -srm | awk '{print $2}')
KernelVersionS=${KernelVersionStr:2:2}
KernelVersionA=${KernelVersionStr:0:1}
KernelVersionB=${KernelVersionS%.*}
PLATFORM_ABI=$(uname -srm | awk '{print $3}')
ui_print "- Android SDK: ${SDK} ."
ui_print "- Linux Kernel: ${KernelVersionStr} ."
ui_print "- Platform ABI: ${PLATFORM_ABI} ."
if [ ${SDK} -lt 26 ] ; then
 ui_print "- Your SDK is lower than 26, Please update your system."
 exit 1
fi 
if [ "$PLATFORM_ABI" != "aarch64" ]&&[ "$PLATFORM_ABI" != "armv8l" ]&&[ "$PLATFORM_ABI" != "armv8a" ] ; then
 ui_print "- Your Platform ABI isn't AARCH64, Abort."
 exit 1
fi
ui_print "- This adjustment is available for your device."
ui_print " "
ui_print "- Install service.sh & blank userspace boost files."
unzip -o "$ZIPFILE" 'system/*' -d ${MODPATH} >&2
unzip -qjo "$ZIPFILE" 'service.sh' -d $MODPATH >&2
ui_print "- Files installation Success."
ui_print "- Install CuprumTurbo Binaries."
rm -rf ${MODPATH}/CuprumTurbo_Lib/
mkdir -p ${MODPATH}/CuprumTurbo_Lib/
rm -rf /data/Cuprum_Custom/
mkdir -p /data/Cuprum_Custom/
unzip -qjo "$ZIPFILE" "common/bin/CuLoader" -d "${MODPATH}/CuprumTurbo_Lib/" 
unzip -qjo "$ZIPFILE" "common/bin/CuAware" -d "${MODPATH}/CuprumTurbo_Lib/" 
unzip -qjo "$ZIPFILE" "common/bin/libcuprum" -d "${MODPATH}/CuprumTurbo_Lib/" 
unzip -qjo "$ZIPFILE" "common/bin/taskset" -d "${MODPATH}/CuprumTurbo_Lib/" 
unzip -qjo "$ZIPFILE" "common/bin/TasksetHelper" -d "${MODPATH}/CuprumTurbo_Lib/" 
unzip -qjo "$ZIPFILE" "common/scripts/powercfg.sh" -d "/data/" 
chmod -R 7777 ${MODPATH}/CuprumTurbo_Lib/
chmod 7777 ${MODPATH}/service.sh
ui_print "- Binaries installation Success."
echo "balance" > /data/Cuprum_Custom/mode
chmod 0666 /data/Cuprum_Custom/mode
unzip -qjo "$ZIPFILE" "common/app/base.apk" -d "/data/local/tmp/" 
APK_INSTALL=$(pm install -r /data/local/tmp/base.apk)
ui_print "- APP Install: $APK_INSTALL."
rm -rf /data/local/tmp/base.apk
ui_print "- All done,erase temp files."
ui_print " "