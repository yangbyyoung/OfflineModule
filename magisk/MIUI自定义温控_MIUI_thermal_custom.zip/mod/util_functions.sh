#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:${0%/*}:$PATH
}

install_magisk_busybox 2>/dev/null

id="$(echo "${0%/*}" | cut -d'/' -f5)"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g' | head -n 1
}

#写入日志的目录
local util_functions_log_file="$MODPATH/运行日志.log"

#提供支持的函数
#锁定数值
function set_value() {
	if test -f "$2" ;then
		chmod 0777 "$2" > /dev/null 2>&1
			echo "$1" > "$2"
		chmod 0444 "$2" > /dev/null 2>&1
		test "$(cat "$2")" = "$1" || { 
			echo "修改"$2"失败！"
		echo "$(date '+%F %T') [E] 修改 "$2" 为 [ "$1" ] 失败" >> "$util_functions_log_file"
		}
	else
	echo "$(date '+%F %T') [W] 不存在 "$2" " >> "$util_functions_log_file"
	fi
}

#设置权限和用户组以及selinux上下文
function set_perm() {
	chown -R $2:$3 $1 || return 1
	chmod -R $4 $1 || return 1
		CON=$5
	test -z $CON  && CON=u:object_r:system_file:s0
	chcon -R $CON $1 || return 1
}

#解密MIUI温控
function decrypt_mi_thermal(){
local target="${1}"
local output="${2}"
miui-thermal -i="${target}" -o="${output}" -d='true' >/dev/null
}

#加密MIUI温控
function ecrypt_mi_thermal(){
local target="${1}"
local output="${2}"
miui-thermal -i="${target}" -o="${output}" -d='false' >/dev/null
}

#解锁MIUI云温控路径
function unlock_MIUI_thermal_folder(){
chattr -R -i "/data/vendor/thermal/config" >/dev/null 2>&1
chattr -R -i "/data/vendor/thermal" >/dev/null 2>&1
echo "@coolapk10007" > "/data/vendor/thermal/config/thermal.txt" 2>/dev/null || {
rm -rf "/data/vendor/thermal"
mkdir -p "/data/vendor/thermal/config"
}
chattr -R -i -a '/data/vendor/thermal'
	mkdir -p '/data/vendor/thermal/config'
		chmod -R 0771 '/data/vendor/thermal'
	chown -R root:system '/data/vendor/thermal'
chcon -R 'u:object_r:vendor_data_file:s0' '/data/vendor/thermal'
}


#纠正路径
function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

