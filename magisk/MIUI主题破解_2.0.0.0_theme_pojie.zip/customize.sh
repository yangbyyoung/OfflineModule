  AUTOMOUNT=true
  
  #读取参数
  MOD_Version="`grep_prop version $TMPDIR/module.prop`"
  MOD_Author="`grep_prop author $TMPDIR/module.prop`"
  MOD_Description="`grep_prop description $TMPDIR/module.prop`"
  MOD_Id="`grep_prop id $TMPDIR/module.prop`"
  Market_Name="`getprop ro.product.marketname`"
  Device="`getprop ro.product.device`"
  Model="`getprop ro.product.model`"
  Version="`getprop ro.build.version.incremental`"
  Android="`getprop ro.build.version.release`"
  ABI="`grep_prop ro.product.cpu.abi`"
  
  #打印参数
  ui_print "- $MOD_Description"
  ui_print "- "
  ui_print "- 模块版本："
  ui_print "- $MOD_Version"
  ui_print "- "
  ui_print "- 模块ID："
  ui_print "- $MOD_Id"
  ui_print "- "
  ui_print "- 模块制作：$MOD_Author"
  ui_print "- Coolapk@强子Loner"
  sleep 0.2
  ui_print "- "
  ui_print "- 相关信息："
  ui_print "- 机型：$Market_Name"
  ui_print "- 设备代号：$Device"
  ui_print "- 认证型号：$Model"
  ui_print "- 安卓版本：Android $Android"
  ui_print "- MIUI版本：$Version"
  ui_print "- "
  ui_print "- 正在刷入..."
  ui_print "- "

  #安装
  unzip -o "$ZIPFILE" 'YuK/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  echo "- 正在设置权限..."
  rm -rf /data/system/theme/rights/*
  cp -rf $MODPATH/YuK/default.mra /data/system/theme/rights
  chmod 000 /data/system/theme/rights
  chattr +i /data/system/theme/rights
  rm -rf /data/system/package_cache/*
  rm -rf /data/data/com.android.thememanager/*
  rm -rf /data/user/0/com.android.thememanager/*
  rm -rf /data/user_de/0/com.android.thememanager/*
  rm -rf /data/app/*/com.android.thememanager*
  rm -rf /data/app/com.android.thememanager*
  case "$ABI" in
      arm64*) Type=arm64 Text=arm64-v8a;;
      arm*) Type=arm Text=armeabi-v7a;;
      x86_64*) Type=x86_64 Text=x86_64;;
      x86*) Type=x86 Text=x86;;
      *) echo "！ 存在未知架构：${ABI}，无法完成安装...";;
  esac
  mkdir -p $MODPATH/system/app/ThemeManager/lib/${Type}
  mkdir -p $MODPATH/ThemeManager
  unzip -o $MODPATH/system/app/ThemeManager/ThemeManager.apk -d $MODPATH/ThemeManager >&2
  cp -rf $MODPATH/ThemeManager/lib/${Text}/* $MODPATH/system/app/ThemeManager/lib/${Text}
  rm -rf $MODPATH/ThemeManager
  rm -rf $MODPATH/YuK
  tmp_list="ThemeManager"
  dda=/data/dalvik-cache/arm
  [ -d $dda"64" ] && dda=$dda"64"
  for i in $tmp_list; do
	  rm -f $dda/system@*@"$i"*
  done
  echo "- "
  echo "- 设置成功..."
  
  #注意事项
  ui_print "- "
  ui_print "- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  ui_print "- !!!                                  !!!"
  ui_print "-       不用了请直接卸载，不要选择禁用模块。"
  ui_print "- !!!                                  !!!"
  ui_print "-     禁用模块不卸载会导致不定时恢复默认主题。"
  ui_print "- !!!                                  !!!"
  ui_print "- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  sleep 0.5

  #打印刷入时间
  Time=$(date "+%Y年%m月%d日 %H:%M:%S")
  echo "- "
  echo "- 刷入时间：$Time"
  description=$MODPATH/module.prop
  echo "刷入时间：$Time." >> $description
  echo "- "
  echo "- 完成..."