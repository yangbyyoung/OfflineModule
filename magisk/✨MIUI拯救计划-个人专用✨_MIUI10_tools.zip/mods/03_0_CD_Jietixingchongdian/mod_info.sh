# 安装时显示的模块名称
mod_name="充电策略-禁用阶梯式充电限制"
# 功能来源
SOURCE="@White白话君"
# 模块介绍
mod_install_desc="取缔模块：禁用阶梯式充电限制模块.zip$SOURCE"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装[$mod_name]"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_name]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装[$mod_name]"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""
# 支持的设备，支持正则表达式(多的在后面加上|)
mod_require_device=".{0,}" #全部
# 支持的系统版本，持正则表达式
mod_require_version=".{0,}" #全部
# 支持的设备版本，持正则表达式
mod_require_release=".{0,}" #全部

if [ $var_bootanimation = true ]; then
		ui_print "----------------------------"
		ui_print "    已存在类似的[$mod_name]是否继续安装？"
		ui_print "   [音量+]：继续安装[$mod_name]"
		ui_print "   [音量-]：跳过安装[$mod_name]"
	if $VOLKEY_FUNC; then
		ui_print "   继续安装[$mod_name]"
	else
		ui_print "   跳过安装[$mod_name]"
		MOD_SKIP_INSTALL=true
	fi
fi

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
#		mkdir -p $MODPATH/system
#		cp -r $MOD_FILES_DIR/system/* $MODPATH/system

		# 附加值到 system.prop
#		add_sysprop ""
		# 从文件附加值到 system.prop
#		add_sysprop_file $MOD_FILES_DIR/system.prop
		# 添加service.sh
		add_service_sh $MOD_FILES_DIR/service.sh
		# 添加post-fs-data.sh
#		add_postfsdata_sh $MOD_FILES_DIR/post-fs-data.sh

#		ui_print "    设置权限"

		return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
		return 0
}
