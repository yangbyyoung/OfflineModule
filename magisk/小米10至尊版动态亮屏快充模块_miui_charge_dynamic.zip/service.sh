warm="/sys/class/power_supply/battery/temp"
step_charging="/sys/class/power_supply/battery/step_charging_enabled"
chmod 777 /sys/class/power_supply/battery/*
chattr -R -i /sys/class/power_supply/*
chmod -R 777 /sys/class/power_supply/*
chattr -R -i /data/vendor/thermal/config/*
rm -f /data/vendor/thermal/config/*
until [[ $jslx == true ]]; do
sleep 10s
capacity="/sys/class/power_supply/battery/capacity"
current_now="/sys/class/power_supply/battery/current_now"
chg_lv=`[[ -f $capacity ]] && cat $capacity`
chg_sd=`[[ -f $current_now ]] && cat $current_now`
Charging_control=/sys/class/power_supply/battery/input_suspend
Charging_control2=/sys/class/power_supply/battery/charging_enabled
data=`[[ -f $warm ]] && cat $warm`
#current=100000
if [[ $chg_lv -le 94 ]]; then
  if [[ $data -le 419 ]]; then
  echo '11900000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '0' > $step_charging
  elif [ "$data" -ge "419" ]&&[ "$data" -lt "449" ];then
  echo '4000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '0' > $step_charging
  elif [[ "$data" -ge "449" ]];then
  echo '1000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  echo '0' > $step_charging
    fi
elif [[ $chg_lv -gt 94 ]]; then
echo '11900000' > "/sys/class/power_supply/battery/constant_charge_current_max"
sleep 10m
fi
done
