DEX2OAT_LOG="/data/adb/Dex2oatBOOT/dex2oat日志.log"
Package=$(pm list packages -a | grep "^package:" | cut -f2 -d ':')
for i in $Package
	do
		cmd package compile --reset $i
	done
echo "$(date "+%Y-%m-%d %H:%M:%S") I : 已删除全部应用编译内容" >>"$DEX2OAT_LOG"
