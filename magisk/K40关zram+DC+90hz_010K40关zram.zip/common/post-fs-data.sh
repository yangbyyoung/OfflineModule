#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 此脚本将在post-fs-data模式下执行

#setprop vnswap.enabled false
#setprop ro.config.zram false
#setprop ro.config.zram.support false
#setprop zram.disksize 0
#write /proc/sys/vm/admin_reserve_kbytes 0
#write /proc/sys/vm/min_free_kbytes 0
#write /proc/sys/vm/extra_free_kbytes 0
#write /proc/sys/vm/swappiness 0
#echo N > /sys/module/msm_thermal/parameters/enabled
#swapoff /dev/block/zram0
