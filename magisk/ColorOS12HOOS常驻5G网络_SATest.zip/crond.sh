#定时方式采用crontab，不会导致额外的电量消耗和资源占用，某些模块采用的是while循环执行（比如循环吃掉垃圾这个模块）会导致额外的性能消耗，不建议使用此方式

#提示：想要看定时进程是否启动，请使用scene软件，在进程管理那边，选择其他进程，搜索crond，如果有这个进程代表启动成功
#开始执行...

#创建目录
mkdir 777 /data/adb/modules/SATest/cron.d
mkdir 777 /data/adb/modules/SATest/crond
#创建并写入定时任务
echo "*/5 * * * * /data/adb/modules/SATest/crond/sa.sh" > /data/adb/modules/SATest/cron.d/root
#设置权限
chmod 777 -R /data/adb/modules/SATest/cron.d/root
#创建并写入定时执行脚本
echo "
#开始
#HOOS
#5G状态
settings put system system 5g_nr_working 1
#不要问,这是关联5G命令行
resetprop persist.radio.testmode ture
resetprop persist.vendor.radio.optelopt_debug false
resetprop persist.vendor.radio.default_smart_sa_enabled false
resetprop persist.radio.ischinatelecom false
resetprop persist.radio.ischinamobile false
resetprop persist.vendor.radio.pingpong.duration false
resetprop persist.vendor.radio.smart_sa_screen_off_min false
resetprop persist.vendor.radio.smart_sa_dereg_timer_min false
resetprop persist.vendor.radio.smart_sa_enable_timeout_min false
resetprop persist.vendor.radio.smart_sa_keep_disable_min false
resetprop persist.vendor.radio.pingpong.count false
#不要问,这是打开5G开关
resetprop persist.vendor.radio.sa_enabled ture
# 这个开关 1.2.3.4
resetprop persist.vendor.radio.arfcn_test_mode 4
#不要问,这是智能5G开关
resetprop smart_fiveg false
settings put system system smart_fiveg false
#不要问,这是智能5G开关
resetprop persist.radio.usersetting.smart5g false
resetprop persist.radio.userchange.smart5g false
#不要问,这是智能SA/NSA开关
resetprop persist.vendor.radio.default_sa_enabled ture
resetprop persist.vendor.radio.default_smart_sa_enabled false

#COS
#智能5G
settings put system system oplus_show_fiveg_status 1
settings put system system oplus_support_fiveg_status 1
settings put system system oplus.radio.smart5g_switch 0
settings put system system oplus.radio.smart5g_switch1 0
settings put system system oplus.radio.smart5g_switch2 0
settings put system system oplus.radio.smart5g_switch3 0
settings put system system oplus.radio.smart5g_switch4 0
settings put system system oplus.radio.smart5g_switch5 0
settings put system system oplus.radio.light_smart5g_switch=0
#SA城市白名单
settings put system system oplus.radio.loc_control_switch 0
#NSA+SA
settings put system system user_auto_mode 0
settings put system system user_nr_mode 3
settings put system system user_nr_mode_sub 3
settings put system system user_operator_nr_mode 1
settings put system system user_rotation 0
#///////////////////////////////////////////////
#SA测试
settings put system oplus.network.nr_mode_test sa_only
resetprop persist.oplus.network.nr_mode_test sa_only
#SA城市白名单
settings put system oplus.radio.loc_control_switch false
resetprop persist.oplus.radio.loc_control_switch false
resetprop persist.sys.oplus.radio.loc_control_switch false
#SA回落未返回
settings put system oplus.software.radio.sa_rat_control 1
resetprop persist.oplus.software.radio.sa_rat_control 1
resetprop persist.sys.oplus.software.radio.sa_rat_control 1
#TAC变化尝试恢复SA
settings put system oplus.software.radio.sa_tac_control 1
resetprop persist.oplus.software.radio.sa_tac_control 1
resetprop persist.sys.oplus.software.radio.sa_tac_control 1
#灭屏回退SA
settings put system oplus.software.radio.screen_off_disable_sa_enabled 1
resetprop persist.oplus.software.radio.screen_off_disable_sa_enabled 1
resetprop persist.sys.oplus.software.radio.screen_off_disable_sa_enabled 1
#SA注册失败回退SA
settings put system oplus.software.radio.sa_reg_timeout_enabled false
resetprop persist.oplus.software.radio.sa_reg_timeout_enabled false
resetprop persist.sys.oplus.software.radio.sa_reg_timeout_enabled false
#查询SA状态失败回退SA
settings put system oplus.software.radio.backoff_sa_cause_network_reject false
resetprop persist.oplus.software.radio.backoff_sa_cause_network_reject false
resetprop persist.sys.oplus.software.radio.backoff_sa_cause_network_reject false
#PING SA/PING失败回退SA
settings put system oplus.software.radio.sa_pingpong_control_disabled false
resetprop persist.oplus.software.radio.sa_pingpong_control_disabled false
resetprop persist.sys.oplus.software.radio.sa_pingpong_control_disabled false
#SA数据拨号失败回退SA
settings put system oplus.software.radio.data_call_control_disabled ture
resetprop persist.oplus.software.radio.data_call_control_disabled ture
resetprop persist.sys.oplus.software.radio.data_call_control_disabled ture
#关闭5G DUMP测试
settings put system oplus.software.radio.disable_5g_nr_5gdump false
resetprop persist.oplus.software.radio.disable_5g_nr_5gdump false
resetprop persist.sys.oplus.software.radio.disable_5g_nr_5gdump false
#IMS通信注册异常回退SA
settings put system oplus.software.radio.sa_ims_control_disabled false
resetprop persist.oplus.software.radio.sa_ims_control_disabled false
resetprop persist.sys.oplus.software.radio.sa_ims_control_disabled false
#禁用SA信号弱退回4G
settings put system oplus.radio.enable_weak_signal_backoff 0
resetprop persist.oplus.radio.enable_weak_signal_backoff 0
resetprop persist.sys.oplus.radio.enable_weak_signal_backoff 0
#WIFI通话回退SA
settings put system oplus.software.radio.wfc_disable_nrsa false
resetprop persist.oplus.software.radio.wfc_disable_nrsa false
resetprop persist.sys.oplus.software.radio.wfc_disable_nrsa false
#DND异常回退SA
settings put system oplus.software.radio.smart5g_rtt_check_sa false
resetprop persist.oplus.software.radio.smart5g_rtt_check_sa false
resetprop persist.sys.oplus.software.radio.smart5g_rtt_check_sa false
#强制恢复SA
persist.oplus.software.radio.recovery_nrmode=true
persist.sys.oplus.software.radio.recovery_nrmode=true
#屏蔽SA最小值
settings put system oplus.network.sa_screen_off_min 0
resetprop persist.oplus.network.sa_screen_off_min 0
settings put system oplus.network.sa_nw_rej_sec 0
settings put system oplus.network.sa_nw_rej_sec 0
resetprop persist.oplus.network.sa_nw_rej_sec 0
settings put system oplus.network.sa_pingpong_duration 0
resetprop persist.oplus.network.sa_pingpong_duration 0
settings put system oplus.network.sa_reg_timeout_min 0
resetprop persist.oplus.network.sa_reg_timeout_min 0
settings put system oplus.network.sa_tac_change_min 0
resetprop persist.oplus.network.sa_tac_change_min 0

resetprop persist.sys.assert.panic false
resetprop persist.sys.oplus.radio.backoff_sa_cause_weak_signal false
resetprop persist.sys.oplus.radio.backoff_sa_cause_weak_signal.config false
resetprop persist.sys.oplus.radio.weak_sa.backoff false
resetprop persist.sys.oplus.radio.weak_sa.backoff_daily_count 0
resetprop persist.sys.oplus.radio.weak_sa.dot_daily_count 0

resetprop ro.oplus.radio.disable_sa_dump_times 0
resetprop ro.oplus.radio.tac_changed_timer 0
resetprop ro.oplus.radio.sa_backoff_recover_time 3

resetprop persist.sys.oplus.operator.opta=0
resetprop persist.vendor.radio.lte_con_stat_delay_timer=0
resetprop persist.vendor.radio.scg_con_stat_delay_timer=0

settings put system oplus.radio.light_smart5g_cfg=ver_num=0;screenoff_speed=0;lowbat_speed=0;lowbat_thres=0;dis_endc_timer=0
settings put system oplus.radio.smart5g_ext_basic=ver_num=1;update_time=1
settings put system oplus.radio.smart5g_sa_cfg=ver_num=1;nr_prio_ctrl=1;lte_pref_prohibit_t=900;sa_pref_prohibit_t0=120;sa_pref_prohibit_stage_num=5;irat_pingpong_restrain=false
settings put system oplus.radio.smart5g_thermal_cfg=ver_num=1;enable=1;sa_deprio_enable=1;prohibitinterval=0

am start-foreground-service -n com.oplus.crashbox/.ExceptionMonitorService
# 结束
" > /data/adb/modules/SATest/crond/sa.sh
#设置sh权限
chmod 777 -R /data/adb/modules/SATest/crond/sa.sh

#启动crond定时进程
crond -c /data/adb/modules/SATest/cron.d





