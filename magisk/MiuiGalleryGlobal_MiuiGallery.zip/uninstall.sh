MODID=MiuiGallery
APP="MiuiGallery
     RtMiCloudSDK
     com.miui.gallery
     com.xiaomi.micloud.sdk"
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/system/package_cache -type f -name *$APPS*`
  rm -rf /data/user/*/$APPS
done
rm -rf /metadata/magisk/$MODID
rm -rf /mnt/vendor/persist/magisk/$MODID
rm -rf /persist/magisk/$MODID
rm -rf /data/unencrypted/magisk/$MODID
rm -rf /cache/magisk/$MODID


