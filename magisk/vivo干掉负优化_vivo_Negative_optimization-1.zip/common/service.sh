#!/system/bin/sh
MODDIR=${0%/*}

install_config="$MODDIR/install_config.conf"
function get_prop() {
  cat $install_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

# set_value value path
function set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2
  fi
}

function wait_sys_boot_completed()
{
	while true
	do
		sleep 10
		boot_completed=$(getprop sys.boot_completed)
		if [[ "$boot_completed" == "1" ]];then
			return
		fi
	done
}
#wait_sys_boot_completed

if [ $(get_prop log) = "TRUE" ]; then
    rm -rf /data/vivono.log
    echo 等待运行 >> /data/vivono.log
fi
while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 1
done

#dmode=$(get_prop mode)
gw=$(get_prop gwd)
fue=$(get_prop fued)
gcp=$(get_prop gcp)
iflog=$(get_prop log)
if [ "$iflog" = "TRUE" ]; then
    echo 开始运行 >> /data/vivono.log
    echo 开始获取信息 >> /data/vivono.log
    #echo "模式："$dmode >> /data/vivono.log
    #echo "模式："$dmode
    echo "是否降级gamewatch："$gw >> /data/vivono.log
    echo "是否降级gamewatch："$gw
    echo "是否降级FUE："$fue >> /data/vivono.log
    echo "是否降级FUE："$fue
    echo "是否破解游戏魔盒："$gcp >> /data/vivono.log  
    echo "是否破解游戏魔盒："$gcp
fi

#if [ "$dmode" = "common" ];
#then
#使用普通版
if [ "$gw" = "true" ]; then
    pm install -r -d $MODDIR/GameWatch_3.0.0.46.apk
    if [ "$iflog" = "TRUE" ]; then
            echo 尝试降级gw >> /data/vivono.log
    fi
fi
    
if [ "$fue" = "true" ]; then
    pm install -r -d $MODDIR/FuntouchUIEngine_2.0.0.4.apk
    if [ "$iflog" = "TRUE" ]; then    
        echo 尝试降级fue >> /data/vivono.log
    fi
fi
    
if [ "$gcp" = "true" ]; then
    pm install -r -d $MODDIR/gamecube_11.1.4.009.apk
    if [ "$iflog" = "TRUE" ]; then
        echo 尝试破解GameCube >> /data/vivono.log
    fi
fi
#else
#修复版
#    if [ "$gw" = "true" ]; then
 #       pm install $MODDIR/GameWatch_3.0.0.46.apk
#        if [ "$iflog" = "TRUE" ]; then
#            echo 尝试降级gw >> /data/vivono.log
   #     fi
 #   fi
    
#    if [ "$fue" = "true" ]; then
 #       pm install $MODDIR/FuntouchUIEngine_2.0.0.4.apk
#        if [ "$iflog" = "TRUE" ]; then
#            echo 尝试降级fue >> /data/vivono.log
   #     fi
#    fi
    
  #  if [ "$gcp" = "true" ]; then
  #      pm install $MODDIR/gamecube_11.1.4.009.apk
   #     if [ "$iflog" = "TRUE" ]; then
     #       echo 尝试破解GameCube >> /data/vivono.log
   #     fi
   # fi