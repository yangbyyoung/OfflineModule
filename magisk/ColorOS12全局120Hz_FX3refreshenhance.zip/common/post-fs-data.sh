#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# show Message
title="description=ColorOS 12 全局120Hz刷新率模块，当前状态："
endname="。模块不受Magisk功能开关影响，若配置失效，请卸载模块后重新安装。"
model=""
if [ -f "/data/system/refresh_rate_config.bak" ];then
  model="已启用"
fi

#失效的脚本
if [ -f "$MODDIR/enabled_function/refresh_rate_config.sh" ];then
  if [ `grep -c 'enableRateOverride=\"false\"' '/data/system/refresh_rate_config.xml'` -eq '0' ];then
  model="已失效"
  #rm -rf /data/system/refresh_rate_config.bak
  fi
fi

description=$title$model$endname
sed -i "s/description=.*$/$description/g" $MODDIR/module.prop
# 此脚本将在post-fs-data模式下执行


