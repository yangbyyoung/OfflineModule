print_modname() {
  ui_print "刷新率修复模块"
  ui_print "刷入中"
}


set_permissions() {

  set_perm_recursive  $MODPATH  0  0  0755  0644
}


