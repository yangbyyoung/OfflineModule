SKIPMOUNT=false
AUTOMOUNT=true
print_modname() {
  ui_print "Extracted from Project Kaleidoscope"
  ui_print "Version: Sunflower Leaf Beta 2"
}
REPLACE=""
on_install() {
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}
