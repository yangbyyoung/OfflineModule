# 安装时显示的模块名称
mod_name="王者荣耀VT优化：Koolight&听风辰"
# 模块介绍
mod_install_desc="✨开启王者荣耀VT优化并合并CF优化配置文件（方案来自：听风辰@酷安）"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"


# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0

mod_install_yes()
{
wz=/data/data/com.tencent.tmgp.sgame/shared_prefs
prefs=$wz/com.tencent.tmgp.sgame.v2.playerprefs.xml
CF=$TMPDIR/OpenGLES3Config.xml
CF_Path=$wz/OpenGLES3Config.xml
on_install() {
rm -rf $CF_Path
sleep 0.5
cp -rf $CF $wz
ui_print "- 复制CF优化文件成功"
if [ ! -f "$prefs" ]; then
ui_print "- 未找到王者优化参数文件"
exit;
fi
ui_print "- 开始移除原未优化参数";
sed -i '/.*<int name="VulkanTryCount" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableVulkan" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableGLES3" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableMTR" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="DisableMTR" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="sgame_ALL_HighFPS" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableHWVendorOpt" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="UnityGraphicsQuality" value=".*" \/>/'d "$prefs"
sed -i '/.*<int name="EnableGPUReport" value=".*" \/>/'d "$prefs"
ui_print "- 开始载入VT优化参数";
sed  -i '2a \ \ \ \ <int name="VulkanTryCount" value="1" \/>' "$prefs";
sed  -i '3a \ \ \ \ <int name="EnableVulkan" value="2" \/>' "$prefs";
sed  -i '4a \ \ \ \ <int name="EnableGLES3" value="3" \/>' "$prefs";
sed  -i '5a \ \ \ \ <int name="EnableMTR" value="1" \/>' "$prefs";
sed  -i '6a \ \ \ \ <int name="DisableMTR" value="3" \/>' "$prefs";
sed -i '7a \ \ \ \ <int name="sgame_ALL_HighFPS" value="1" \/>' "$prefs";
sed -i '8a \ \ \ \ <int name="EnableHWVendorOpt" value="1" \/>' "$prefs";
sed -i '9a \ \ \ \ <int name="UnityGraphicsQuality" value="1" \/>' "$prefs";
sed -i '10a \ \ \ \ <int name="EnableGPUReport" value="2" \/>' "$prefs";
chmod 550 $wz
chmod 440 $prefs
ui_print "- 配置文件权限设置成功"
ui_print "- 开启VT成功"
}


    return 0
}

mod_install_no()
{
    return 0
}