#!/system/bin/sh


source "${0%/*}/util_functions.sh"

function cp_MTK_thermal_conf_find(){
local MTK_MODPATH_config_DIR="${MODPATH}/mod/MTK_thermal"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	mkdir -p "${MODPATH}/system/vendor/etc/thermal" "${MODPATH}/system/vendor/etc/.tp"
		touch "${MODPATH}/system/vendor/etc/thermal/.replace"
	touch "${MODPATH}/system/vendor/etc/.tp/.replace"
	find $(magisk --path)/.magisk/mirror/vendor/etc/thermal $(magisk --path)/.magisk/mirror/vendor/.tp -iname "*.conf" -type f -o -iname "*.mtc" -type f 2>/dev/null | while read file ;do
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/thermal/${file##*/}"
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/.tp/${file##*/}"
	done
		cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/thermal"
	cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/.tp" 
fi
}

cp_MTK_thermal_conf_find
