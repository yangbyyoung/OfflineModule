SKIPUNZIP=0
DEBUG=false
M="$MODPATH"; F="$M/File/wave"; pro="$M/File/prop"; obui="/odm/etc/build.prop"; vbui="/vendor/build.prop"; aw="aw8697_haptic.bin"; P="`grep_prop ro.product.odm.device $obui`"; V="`grep_prop ro.odm.build.version.incremental $obui`"; Fv="`grep_prop ro.vendor.build.version.incremental $vbui`"
if [ "$API" -lt 30 ]; then
ui_print ""
ui_print "-设备:$P-$V(SDK:$API)"
abort "-安卓版本低于11.0"
fi
buttos() {
butto=""
while [ "$butto" = "" ]; do
butto="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
sleep 0.2
done
}
ui_print "　　　　　　　　 !风险警告!"
if [[ $Fv == V816*.*.* ]]; then
ui_print "-HyperOS改动较大!部分振动可能不匹配,自行测试."
sleep 0.1
fi
ui_print "-如果检测Root(找到magisk)请自行隐藏,介意勿用."
ui_print "-对隐藏环境有严格要求的用户,不建议安装本模块."
ui_print "-因检测Root造成的任何困扰与后果，概不负责!"
ui_print "-个别机型可能有功耗/振动异常/无振动等玄学问题."
ui_print "-模块并非万能，玄学问题请勿反馈，是否继续?"
sleep 0.1
ui_print "　　　　　　音量↑:安装│音量↓:取消"
buttos
case "$butto" in
"KEY_VOLUMEUP")
ui_print "　　　　　　 ✓✓"
;;
*)
abort "　　　　　　　　　　　　　　　 ✓✓"
esac
ui_print "******************************************"
ui_print "　　　　　　　　［马达驱动目录］"
ui_print "　 (老机型选vendor│8g2/8g3机型选odm)"
ui_print "　　　　 音量↑:vendor│音量↓: odm"
buttos
case "$butto" in
"KEY_VOLUMEUP")
ui_print "　　　　　✓✓"
C="/vendor/firmware"; defprop="/vendor/build.prop"
;;
*)
ui_print "　　　　　　　　　　　　　　　 ✓✓"
C="/odm/firmware"; defprop="/odm/etc/build.prop"
esac
SC="system$C"; D="$M/$SC"; sp="system.prop"; msp="$M/$sp"; mde="$M/module.prop"; dam="data/adb/modules"; instdir="$dam/$MODID"; vibmod="/$dam/*/$SC"; ime="`grep_prop sys.haptic.keyboard $defprop`"; NAME="`grep_prop name $mde`"; AUT="`grep_prop author $mde`"; VER="`grep_prop version $mde`"; VC="`grep_prop versionCode $mde`"; . $F/*.*; tap="`grep_prop sys.haptic.tap.normal $msp`"; 　=　