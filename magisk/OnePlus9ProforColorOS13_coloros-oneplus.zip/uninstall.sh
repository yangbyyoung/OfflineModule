# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
if [[ `getprop ro.build.version.oplusrom.display` == "13.0" ]]
then
dd if=${0%/*}/dtbo_bak.img of=/dev/block/by-name/dtbo$(getprop ro.boot.slot_suffix)
fi
