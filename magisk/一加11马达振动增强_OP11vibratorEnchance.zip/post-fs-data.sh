#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
# 这个脚本将以 post-fs-data 模式执行(系统启动前执行)
MODDIR=${0%/*}
mount --bind $MODDIR/my_product/etc/vibrator_service_config/inputmethod_duration_map.xml /my_product/etc/vibrator_service_config/inputmethod_duration_map.xml
mount --bind $MODDIR/my_product/etc/vibrator/effect2waveform.xml /my_product/etc/vibrator/effect2waveform.xml
#可弃用修改项
#mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml
#mount --move olddir newdir