#!/system/bin/sh
MODDIR=${0%/*}
function auto_game_swtich_enable () {
	while true ; do
	echo 1 > /proc/touchpanel/game_switch_enable
	sleep 1
	done
}
auto_game_swtich_enable &