
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

fstrim -v /data
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor

sm fstrim 2>/dev/null
