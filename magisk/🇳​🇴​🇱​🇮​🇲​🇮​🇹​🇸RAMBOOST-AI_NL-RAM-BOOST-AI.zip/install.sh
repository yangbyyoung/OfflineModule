#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=false
MODDIR=/data/adb/modules

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

# Set what you want to display when installing your module
print_modname() {
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 1.5
ui_print "
╭━╮╱╭┳━━━╮
┃┃╰╮┃┃╭━╮┃
┃╭╮╰╯┃┃╱┃┃
┃┃╰╮┃┃┃╱┃┃
┃┃╱┃┃┃╰━╯┃
╰╯╱╰━┻━━━╯"
ui_print ""
sleep 1.5
ui_print "
╭╮╱╱╭━━┳━╮╭━┳━━┳━━━━┳━━━╮
┃┃╱╱╰┫┣┫┃╰╯┃┣┫┣┫╭╮╭╮┃╭━╮┃
┃┃╱╱╱┃┃┃╭╮╭╮┃┃┃╰╯┃┃╰┫╰━━╮
┃┃╱╭╮┃┃┃┃┃┃┃┃┃┃╱╱┃┃╱╰━━╮┃
┃╰━╯┣┫┣┫┃┃┃┃┣┫┣╮╱┃┃╱┃╰━╯┃
╰━━━┻━━┻╯╰╯╰┻━━╯╱╰╯╱╰━━━╯"
sleep 1.5
ui_print ""
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 1
ui_print ""
ui_print "
╭━━━┳━━━┳━╮╭━╮
┃╭━╮┃╭━╮┃┃╰╯┃┃
┃╰━╯┃┃╱┃┃╭╮╭╮┃
┃╭╮╭┫╰━╯┃┃┃┃┃┃
┃┃┃╰┫╭━╮┃┃┃┃┃┃
╰╯╰━┻╯╱╰┻╯╰╯╰╯"
sleep 0.7
ui_print "
╭━━╮╭━━━┳━━━┳━━━┳━━━━╮
┃╭╮┃┃╭━╮┃╭━╮┃╭━╮┃╭╮╭╮┃
┃╰╯╰┫┃╱┃┃┃╱┃┃╰━━╋╯┃┃╰╯
┃╭━╮┃┃╱┃┃┃╱┃┣━━╮┃╱┃┃
┃╰━╯┃╰━╯┃╰━╯┃╰━╯┃╱┃┃
╰━━━┻━━━┻━━━┻━━━╯╱╰╯"
sleeo 0.7
ui_print "
╭━━━┳━━╮
┃╭━╮┣┫┣╯
┃┃╱┃┃┃┃
┃╰━╯┃┃┃
┃╭━╮┣┫┣╮
╰╯╱╰┻━━╯"
sleep 2
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  ▌ᴘᴏᴡᴇʀᴇᴅ ʙʏ ɴᴏʟɪᴍɪᴛꜱ "
sleep 0.5
ui_print "  ▌ʀᴀᴍ ʙᴏᴏꜱᴛ ᴀɪ "
sleep 0.5
ui_print "  ▌ᴛʜɪꜱ ᴍᴏᴅᴜʟᴇ ɪꜱ ᴜɴɪᴠᴇʀꜱᴀʟ "
sleep 0.2
ui_print "  ▌ᴠᴇʀꜱɪᴏɴ - 1.0 "
sleep 2
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.5
ui_print "  ▌ɴᴏ ʟɪᴍɪᴛꜱ ▰ ʀᴀᴍ ʙᴏᴏꜱᴛ ᴀɪ "
sleep 0.5
ui_print "  ▌ᴅᴇᴠɪᴄᴇ ▰ $(getprop ro.product.model)"
sleep 0.5
ui_print "  ▌ʙʀᴀɴᴅ ▰ $(getprop ro.product.system.manufacturer)"
sleep 0.5
ui_print "  ▌ᴘʀᴏᴄᴇꜱꜱᴏʀ ▰ $(getprop ro.product.board)"
sleep 0.5
ui_print "  ▌ᴄᴘᴜ ▰ $(getprop ro.hardware)"
sleep 0.5
ui_print "  ▌ᴀɴᴅʀᴏɪᴅ ᴠᴇʀꜱɪᴏɴ ▰ $(getprop ro.build.version.release)"
sleep 0.5
ui_print "  ▌ᴋᴇʀɴᴇʟ ▰ $(uname -r)"
sleep 0.5
ui_print "  ▌ʀᴀᴍ ▰ $(free | grep Mem |  awk '{print $2}')"
sleep 2
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  ▌ᴊᴏɪɴ @ɴʟxᴘᴇʀꜰᴏʀᴍᴀɴᴄᴇᴄʜᴀᴛꜱ "
sleep 0.5
ui_print "  ▌ᴏɴ ᴛᴇʟᴇɢʀᴀᴍ ꜰᴏʀ ᴍᴏʀᴇ!!"
sleep 1.5
ui_print "  ▌ᴄʜᴇᴄᴋɪɴɢ ᴡʜɪᴄʜ ᴀʀᴍ ʏᴏᴜʀ ᴅᴇᴠɪᴄᴇ ʜᴀꜱ"
sleep 2
ui_print "  ▌ʏᴏᴜʀ ᴀʀᴍ ɪꜱ ▰ $(getprop ro.product.cpu.abi)"
sleep 1
ui_print "  ▌ᴇxᴛʀᴀᴄᴛɪɴɢ ᴀɴᴅ ᴍᴏᴠɪɴɢ ꜰɪʟᴇꜱ ꜰᴏʀ ▰ $(getprop ro.product.cpu.abi)"
[[ "$IS64BIT" == "true" ]] && tar -xf "$MODPATH/nlramboostai64.tar.xz" -C "$MODPATH" || tar -xf "$MODPATH/nlramboostai32.tar.xz" -C "$MODPATH"
sleep 2.5
ui_print "  ▌ᴀʟʟ ꜱᴄʀɪᴘᴛꜱ ᴘʟᴀᴄᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ"
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 1
  ui_print "  ▌ɪ ᴀᴍ ɴᴏᴛ ʀᴇꜱᴘᴏɴꜱɪʙʟᴇ ꜰᴏʀ ᴀɴʏ ᴘʀᴏʙʟᴇᴍꜱ "
  sleep 0.5
  ui_print "  ▌ʏᴏᴜ ꜰᴀᴄᴇ ᴀꜰᴛᴇʀ ꜰʟᴀꜱʜɪɴɢ ᴛʜɪꜱ ᴍᴏᴅᴜʟᴇ" 
  sleep 0.5
  ui_print "  ▌ɴᴏ ɴᴇᴇᴅ ꜰᴏʀ ᴀɴʏ ᴛᴇʀᴍɪɴᴀʟ ᴄᴏᴍᴍᴀɴᴅ"
  sleep 0.5
  ui_print "  ▌ʀᴀᴍ ʙᴏᴏꜱᴛ ᴡɪʟʟ ᴀᴜᴛᴏ ᴇxᴇᴄᴜᴛᴇ ᴀꜰᴛᴇʀ ʙᴏᴏᴛ"
  sleep 0.5
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sleep 3
}


on_install() {
  sleep 0.5
  ui_print "  ▌ᴍᴏᴅᴜʟᴇ ʙʏ @ᴢᴏᴛᴏɢ️"
  sleep 0.5
  ui_print "  ▌ᴛʜᴀɴᴋꜱ ᴛᴏ @ᴄʀᴀɴᴋᴠ2"
  pm install /data/local/tmp/NLxPERFORMANCEToast.apk
  sleep 2
  ui_print "  ▌ᴅᴏɴᴇ "
  rm -rf $TMPR
}


set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
}

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh