#!/system/bin/sh
#清除Joyose数据
pm clear com.xiaomi.joyose >/dev/null 2>&1
#清除MIUI电量和性能数据
pm clear com.miui.powerkeeper >/dev/null 2>&1

