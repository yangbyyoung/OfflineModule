#!/system/bin/sh
MODDIR=${0%/*}
System_Activation()
{
	local wait_start=0
	until [[ $(getprop sys.boot_completed) -eq 1 ]]; do
		local wait_start=$((${wait_start} + 1))
		[[ ${wait_start} -ge 150 ]] && exit 1
		sleep 2
	done
}
System_Activation
sdcard_rw()
{
	local test_file="/sdcard/Android/.TEST_FILE"
	touch $test_file
	while [[ ! -f $test_file ]]; do
		touch $test_file
		sleep 1
	done
	rm $test_file
}
sdcard_rw

for scripts in $MODDIR/Script/*.sh
do
	$scripts 2>/dev/null &
done
