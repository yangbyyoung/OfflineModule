SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true


##########################################################################################
# Installation Message
##########################################################################################
  ui_print "*******************************"
  ui_print "     	Magisk Module:         "
  ui_print "For Coolapk    By 莫莫笑（修改者你好HEIIO）"
  ui_print "*******************************"
  
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "####################"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "————————————————————————————"
echo "####################"
echo "#                      "
echo "#                      " 
echo "#                      "
echo "####################"
echo "#                      "
echo "#                      " 
echo "#                      "
echo "####################"
echo "————————————————————————————"
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "####################"
echo "————————————————————————————"
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "#                      "
echo "####################"
echo "————————————————————————————"
echo "####################"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "#                  #"
echo "####################" 
"————————————————————————————"

   echo "注意！！！"
   echo "如果要恢复日志，请在magisk manager 里面停用或者卸载，不要在rec里面强制删除，不然无法恢复日志。"
ui_print "


  "●系统类优化："
    
   ‖删除无用垃圾，享受简约
   ‖禁用I/O调试，禁用Analysis，减少性能开销
   ‖关闭magisk 内核 miui 内测日志等其他无用日志...减少功耗（logo v7）
   ‖开启优化SurfaceFlinger缓冲区，体验流畅的MIUI12
   ‖优化系统睡眠
   ‖开启深度睡眠，待机更省电
   ‖更改wifi 扫描时间，以省电
   ‖sqlite提速(来自水龙）
   ‖内存优化回收
   ‖内核日志关闭（disabled by amktiao）
   ‖禁止mi-rcs写入日志，以省电
   ‖内核优化，纵享新丝滑
   ‖利用fstrim对设备读写进行优化
    =以下来自stm工具箱=
   ‖开启Surface Flinger硬件加速，可提升系统流畅度
   ‖开启同用宽带压缩UBWC，可降低屏幕功耗，需设备支持
   ‖开启大TCP数据包，可提升移动网络网速
   ‖还有更多其他功能等（二改新增的功能）……
    
  "●功能性开关："
    
   ‖扬声器清理(miui)
   ‖视频工具箱-音效-影音功能(miui)（UI开关）
   ‖开启MEMC动态补偿（miui）（UI 开关）
    =（有些机型功能实现不完全 玄）=
  
  "●附加功能："
   
   ‖开机40秒清理电池优化名单(来自酷安@大铁 早起刷刷机)
   ‖安卓UI流畅度优化，提高ui相关进程优先级(来自酷安@温亮平)
   
     鸣谢：
    酷安@风雪如花剑如霜
    酷安@大铁 早起刷刷机
    酷安@amktiao
    酷安@温亮平
    酷安@阿巴酱
    还有等等等等……
    
   ……………………
"
##########################################################################################
# Permissions
##########################################################################################

#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {

  set_perm_recursive  $MODPATH  0  0  0755  0644
  set_perm  $MODPATH/system/bin/logd       0       0       0550
  
}
#添加您要精简的APP/文件夹目录


##########################################################################################
# Custom Functions
##########################################################################################
#!system/bin/sh

#来自 旧梦
echo "正在添加应用中……"
path=/data/user/0/com.miui.securitycenter/files/gamebooster/freeformlist
for i in `pm list packages | sed 's/.*://g'`; do
	[[ -z `grep -F $i $path` ]] && echo $i >> $path
done
chmod 700 `dirname $path`
chmod 444 $path

echo "- 完成！"

/sbin/.magisk/busybox/chattr -i -a -A /cache/magisk.log
chmod 777 /cache/magisk.log
/sbin/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.miui.home/cache/debug_log
chmod 777 /data/user_de/0/com.miui.home/cache/debug_log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log

rm -rf /cache/magisk.log
touch   /cache/magisk.log
chmod 000  /cache/magisk.log
/sbin/.magisk/busybox/chattr +i  /cache/magisk.log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 

#停用Analysis 来自风雪大佬
pm disable com.miui.analytics
pm disable com.miui.systemAdSolution

echo"模块的id MOMOXIAO"