MODDIR=${0%/*}


sysctl -w vm.swappiness=0
swapoff /dev/block/zram0

#sed -ri 's/.*swap.*/#&/' /etc/fstab

swapoff -a
sed -i '/swap/s/^$/#\1/g' /etc/fstab