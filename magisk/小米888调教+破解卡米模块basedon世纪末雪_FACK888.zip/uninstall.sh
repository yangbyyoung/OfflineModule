rm -rf /data/swapfile*
rm -rf /data/swap_recreate
rm -rf /data/swap_config.conf
rm -rf /data/powercfg.sh
rm -rf /data/adb/modules/snow