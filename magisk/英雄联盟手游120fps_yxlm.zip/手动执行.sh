MODDIR=${0%/*}

find /data/media/0/Android/data/com.tencent.lolm/files/SaveData/Local/* -name "Setting" -exec echo>$MODDIR/配置文件 {} \;
Setting1=$(sed -n '1p' $MODDIR/配置文件)
Setting2=$(sed -n '2p' $MODDIR/配置文件)
Setting3=$(sed -n '3p' $MODDIR/配置文件)
Setting4=$(sed -n '4p' $MODDIR/配置文件)
Setting5=$(sed -n '5p' $MODDIR/配置文件)

if [ -s $MODDIR/配置文件 ];then
cp -rf $MODDIR/*fps $Setting1
cp -rf $MODDIR/*fps $Setting2
cp -rf $MODDIR/*fps $Setting3
cp -rf $MODDIR/*fps $Setting4
cp -rf $MODDIR/*fps $Setting5
chmod 440 $Setting1
chmod 440 $Setting2
chmod 440 $Setting3
chmod 440 $Setting4
chmod 440 $Setting5
rm -rf $MODDIR/配置文件
echo "- 脚本结束，修改成功。"
else
echo "- 未找到配置文件，脚本结束。"
fi