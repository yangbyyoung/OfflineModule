#!/data/adb/modules/iris_helper/busybox sh
MODDIR=${0%/*}
config_file="$MODDIR/iriscfgcustomize.conf"
tmp_cfg="$MODDIR/tmp_cfg"
timer=2.5

> "$tmp_cfg" && chmod 644 "$tmp_cfg"

ihelper_getTopApp(){
  name_app=$(dumpsys activity activities|grep topResumedActivity=|tail -n 1|cut -d "{" -f2|cut -d "/" -f1|cut -d " " -f3)
}

ihelper_readBlock(){
  local line_numrb=-1
  local start_reading="f"
  while read -r liner; do
    line_numrb=$((line_numrb + 1))
    if [ "$line_numrb" -eq "$1" ]; then
      start_reading="t"
    fi
    if [ "$start_reading" = "t" ]; then
      printf '%s\n' "$liner" >> "$tmp_cfg"
      if [[ "$liner" = app:* || "$liner" = "END" ]]; then
        echo "}" >> "$tmp_cfg"        
        break
      fi
    fi
  done < "$config_file"
}

ihelper_assignParams(){
  params_a=-2
  params_b=-2
  params_c=-2
  params_d=-2
  while read -r lineP; do
    case "$lineP" in
      params_a:*)
        local value=${lineP#*: }
        params_a=$value
        ;;
      params_b:*)
        local value=${lineP#*: }
        params_b=$value
        ;;
      params_c:*)
        local value=${lineP#*: }
        params_c=$value
        ;;
      params_d:*)
        local value=${lineP#*: }
        params_d=$value
        ;;
      "}")
        break
        ;;
    esac
  done < "$tmp_cfg"
}


ihelper_getParams(){
  ihelper_found_ta="f"
  line_number=0
  while read -r lineg; do
    line_number=$((line_number + 1))
    if [[ "$lineg" == "app: \"$1\"" ]]; then
      ihelper_found_ta="t"
      break
    fi
    if [[ "$lineg" == "END" ]]; then
      break
    fi
  done < $config_file
  if [ "$ihelper_found_ta" == "t" ]; then
    ihelper_readBlock "$line_number"
    ihelper_assignParams
    ihelper_process
  else
    ihelper_default
  fi
}

ihelper_default(){
  /odm/bin/irisConfig 47 1 0
  /odm/bin/irisConfig 258 1 0
  /odm/bin/irisConfig 267 2 3 0
  /odm/bin/irisConfig 273 1 0
}

ihelper_process(){
  if [ "$params_a" != "-2" ]; then
    /odm/bin/irisConfig $params_a
  fi
  if [ "$params_b" != "-2" ]; then
    /odm/bin/irisConfig $params_b
  fi
  if [ "$params_c" != "-2" ]; then
    /odm/bin/irisConfig $params_c
  fi
  if [ "$params_d" != "-2" ]; then
    /odm/bin/irisConfig $params_d
  fi
  > $tmp_cfg
}

while true; do
  ihelper_getTopApp
  if [ "$name_app" != "$current_app" ]; then
    ihelper_getParams "$name_app"
    current_app="$name_app"
  fi
  sleep "$timer"
done