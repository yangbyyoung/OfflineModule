LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
SKIPMOUNT=false
print_modname() {
 ui_print "*******************************"
 ui_print "       Magisk  模块       "
 ui_print "    由UBISOFT ®️LOGO    "
 ui_print "《刺客信条 : 奥德赛》   修改"
 ui_print "最终解释权由 UBISOFT 所有"
 ui_print "*******************************"
}
on_install() {
 ui_print "正在写入文件"
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print "修改完成！"
 ui_print "本模块启动画面自带声音"
 ui_print "请在设置内开启！"
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}