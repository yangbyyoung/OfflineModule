#!/system/bin/sh
MODDIR=${0%/*}
chmod 777 $MODDIR/bin/ddns-go
while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
echo "PowerManagerService.noSuspend" > /sys/power/wake_lock
while true;
do
process=`$(pgrep ddns-go)`; 
if [ "$process" == "" ]; then
$MODDIR/bin/ddns-go -c $MODDIR/config/ddns_go_config.yaml
fi
sleep 3 ;
done ;