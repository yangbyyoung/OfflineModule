while [ "$(getprop sys.boot_completed)" != "1" ]
 do
   sleep 5
 done
 
cmd statusbar send-disable-flag statusbar-expansion
