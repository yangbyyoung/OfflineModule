chattr -i /data/user/0/com.xiaomi.joyose
chattr -i /data/vendor/thermal
chattr -i /data/vendor/thermal/config
