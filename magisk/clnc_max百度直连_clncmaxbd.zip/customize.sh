SKIPUNZIP=0


REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里建立您自己的清单
REPLACE="
"


unzip -oj "$ZIPFILE" 'clnc_bd' -d $MODPATH/clnc_bd >&2
[ -d /data/clncmax/clnc_bd ] && rm -rf /data/clncmax/clnc_bd
cp -af $MODPATH/clnc_bd /data/clncmax/clnc_bd
chmod -R 777 /data/clncmax/clnc_bd


  # 默认权限请勿删除
  set_perm_recursive $MODPATH 0 0 0777 0777

