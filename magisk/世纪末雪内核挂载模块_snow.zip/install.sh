rm -rf /data/vendor/diag
rm -rf /data/vendor/fpdump
rm -rf /data/vendor/location
rm -rf /data/vendor/log
rm -rf /data/vendor/pddump
rm -rf /data/vendor/ramdump
rm -rf /data/vendor/ramdump_ssr
rm -rf /data/vendor/ssrdump
rm -rf /data/vendor/tz_log
rm -rf /data/vendor/wlan_logs
rm -rf /data/swap_config.conf
rm -rf /data/swapfile
rm -rf /data/powercfg.sh
rm -rf /data/adb/modules/snow
#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用
SKIPMOUNT=false

#是否使用common/system.prop文件
PROPFILE=true

#是否使用post-fs-data脚本执行文件
POSTFSDATA=true

#是否在开机时候允许允许common/service.sh中脚本
LATESTARTSERVICE=true
ui_print "****************************************"
ui_print "******内核调校模块 by世纪陌雪*********"
ui_print "****************************************"
ui_print " "
ui_print "1.增加系统流畅度度"
ui_print "2.删除温控释放高通火龙888"
ui_print "3.加入试做频谱适配scene"
ui_print "4.适配最新scene虚拟空间调整"
ui_print "5.处理器体质开机后请去cache查看CPU.log"
ui_print "6.开机后请去cache查看snow.log"
ui_print " "
ui_print "****************************************"
ui_print "**************重启后生效****************"
ui_print "****************************************"
REPLACE="
"
REPLACE="
 "
# 判断是否有busybox依赖
if [[ -f "/system/bin/busybox" ]]; then
ui_print " "
ui_print "有busybox依赖分区优化将在开机后执行"
ui_print " "
elif [[ -f "/system/xbin/busybox" ]]; then
ui_print " "
ui_print "有busybox依赖分区优化将在开机后执行"
ui_print " "
else
ui_print " "
ui_print "没有外部busybox，采用系统程序执行!"
ui_print " "
fi;

set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}

on_install() {
  ui_print "- 提取模块文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  rm -rf /data/vendor/thermal
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-4k.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-8k.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-camera.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-chg-only.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-class0.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-mgame.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-nolimits.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-phone.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-tgame.conf
  cp /data/adb/modules_update/snow/system/vendor/etc/thermal-normal.conf /data/adb/modules_update/snow/system/vendor/etc/thermal-video.conf
  rm -rf /data/powercfg.sh
  mv -f /data/adb/modules_update/snow/system/bin/powercfg.sh /data/
  rm -rf /data/adb/modules_update/snow/system/bin/powercfg.sh
  rm -rf /data/swap_config.conf
  mv -f /data/adb/modules_update/snow/system/bin/swap_config.conf /data/
  rm -rf /data/adb/modules_update/snow/system/bin/swap_config.conf
}