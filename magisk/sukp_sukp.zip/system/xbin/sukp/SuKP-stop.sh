#!/system/bin/sh
cd "${0%/*}"
./SuKP-start.sh S
sleep 1
./SuKP-check.sh