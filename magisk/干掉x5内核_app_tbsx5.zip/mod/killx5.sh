#!/system/bin/sh
MODDIR=${0%/*}

while :;do

limitlog(){  
local logfile=$1  
local maxsize=$2 
filesize=`ls -l $logfile | awk '{ print $5 }'`
if [ $filesize -gt $maxsize ];then
echo " " > $logfile
fi
}

MAX=$((1024*10000))

rmthch(){
if [[ -e "$1" ]];then
rm -rf "$1"
touch "$1"
chmod 000 "$1"
fi
}

X5=`find /data/data -name '*app_tbs*' -type d -o -name '*app_tbs_64*' -type d -o -iname '*app_x5webview*' -type d -o -iname '*app_xwalk*' -type d`
X5backup=`find /data/media -name '*.tbs.*'`

if [[ "$X5" != "" ]];then
for i in $X5;do
rmthch $i 2>/dev/null
echo "时间:  $(date +%y年%m月%d日%H点%M分) 清理: $i" >>$MODDIR/清理日志.log
limitlog $MODDIR/清理日志.log $MAX
done
fi

if [[ "$X5backup" != "" ]];then
for i in $X5backup;do
rm -rf $i 2>/dev/null
echo "时间:  $(date +%y年%m月%d日%H点%M分) 清理: $i" >>$MODDIR/清理日志.log
limitlog $MODDIR/清理日志.log $MAX
done
fi

#清理时间间隔，手机会sleep，时间间隔会有所延长。
sleep 3h
done
