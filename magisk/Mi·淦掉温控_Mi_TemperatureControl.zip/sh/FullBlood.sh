#!/system/bin/sh
chattr -i /sys/class/power_supply/battery/constant_charge_current_max
chmod 777 /sys/class/power_supply/battery/die_health
chmod 777 /sys/class/power_supply/battery/health
chmod 777 /sys/class/power_supply/usb/connector_health

echo '0' > /sys/class/power_supply/battery/step_charging_enabled
echo '0' > /sys/class/power_supply/battery/input_suspend
sleep 1
done

warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo Good > /sys/class/power_supply/battery/die_health
  echo Good > /sys/class/power_supply/battery/health
  echo Good > /sys/class/power_supply/usb/connector_health
sleep 1s
done
