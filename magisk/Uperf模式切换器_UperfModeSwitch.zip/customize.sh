SKIPUNZIP=0
set_perm_recursive $MODPATH/system/bin/yc 0 2000 0755 0755