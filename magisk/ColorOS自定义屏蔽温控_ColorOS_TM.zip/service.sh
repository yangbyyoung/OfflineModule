#!/bin/sh
MODDIR=${0%/*}

chmod -R 777 $MODDIR/
cd $MODDIR/
rm -rf Build
rm -rf MTeam
{
sleep 35
/system/bin/sh "$MODDIR/ColorOS_SYS.sh"
/system/bin/sh "$MODDIR/ColorOS_TM.sh"
exit 0
}
