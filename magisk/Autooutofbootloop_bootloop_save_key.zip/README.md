### 自动救砖

在如下目录
```
/cache
/data 
/mnt/vendor/persist 
/data/unencrypted
```
创建文件 [ `dismod` ] 可禁用模块，[ `remod` ]则移除所有模块，
其他情况会自动救砖。

```
模块制作思路
zygote 启动异常 来自于 [HuskyDG](https://github.com/Magisk-Modules-Alt-Repo/HuskyDG_BootloopSaver)，感谢大佬！
其他思路来源于我自己
```

- v2
 > ①修改 `pgrep` 为 `pidof` 查找 `zygote`
 > ②感谢 @coolapk **[夕七](http://www.coolapk.com/u/905288)** 的测试。
 
- v3
 > ①优化日志记录！
 > ②优化启动时间！
 
- v4
 > ①添加音量键救砖，开机动画界面按三次即可自动救砖。
 > ②优化部分判断逻辑
 
