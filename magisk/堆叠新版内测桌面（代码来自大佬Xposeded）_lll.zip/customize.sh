DUBUG_FLAG=false

PROPFILE=false

POSTFSDATA=true

LATESTARTSERVICE=false

print_modname() {
  ui_print "堆叠桌面由酷安@TAT趙制作"
  ui_print "🌟模块以酷安@Honey打包模块二改🌟"
  ui_print "✨模块由酷安@南橘北彘打包制作✨"
  ui_print "卡米或进入系统黑屏请自行进入Rec终端命令输入*/mm删除此模块"
}

on_install() {
  ui_print "- 正在释放模块文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  TMPAPKDIR=/data/local/tmp
  cp -rf $MODPATH/system/priv-app/MiuiHome/MiuiHome.apk $TMPAPKDIR
  result=$(pm install ${TMPAPKDIR}/MiuiHome.apk 2>&1)
  if [ $result = Success ];then
    echo
    ui_print "- 系统具备核心破解安装成功，可免重启体验"
    echo
  else
    echo
    ui_print "- 重启后生效"
    echo
  fi
    
    ABI=`grep_prop ro.product.cpu.abi`
    case "$ABI" in
        arm64*) Type=arm64 Wenj=arm64-v8a;;
        arm*) Type=arm Wenj=armeabi-v7a;;
        x86_64*) Type=x86_64 Wenj=x86_64;;
        x86*) Type=x86 Wenj=x86;;
        *) echo "！ 未知的架构 ${ABI}，无法安装";;
    esac
    mkdir -p $MODPATH/system/priv-app/MiuiHome/lib/${Type}
    mkdir -p $MODPATH/Home
    unzip -o $MODPATH/system/priv-app/MiuiHome/MiuiHome.apk -d $MODPATH/Home >&2
    cp -rf $MODPATH/Home/lib/${Wenj}/* $MODPATH/system/priv-app/MiuiHome/lib/${Type}
    rm -rf $MODPATH/Home
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}

tmp_list="MiuiHome"

dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"*
done
rm -rf /data/system/package_cache/*
