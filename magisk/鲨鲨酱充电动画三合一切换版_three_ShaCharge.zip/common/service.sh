#!/system/bin/sh
# 嘿嘿嘿(º﹃º )鲨鲨酱～
MODDIR=${0%/*}
MODANIMDIR="$MODDIR/system/vendor/overlay/BsCharge"
chcon "u:object_r:vendor_overlay_file:s0" $MODANIMDIR/BsCharge0.apk
chcon "u:object_r:vendor_overlay_file:s0" /system/vendor/overlay/BsCharge0.apk  2>/dev/null
exit 0
