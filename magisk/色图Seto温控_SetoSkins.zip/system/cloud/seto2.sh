sleep 50
rm -rf /data/adb/service.d/seto.sh
rm -rf /data/adb/service.d/seto2.sh
rm -rf /data/media/0/Android/备份温控（请勿删除）