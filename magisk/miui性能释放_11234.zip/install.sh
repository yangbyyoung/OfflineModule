SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
print_modname() {
 ui_print "*******************************"
 ui_print "  	Magisk Module        "
 ui_print " By  ------- 安洋"
 ui_print "*******************************"
 ui_print ""
 ui_print "对小米机型的温控配置进行修改，去除一部分配置以达到性能完美释放，打游戏时温度会控制在43左右"
 ui_print ""
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'auto_mount' -d $MODPATH >&2
 ui_print "- 注入文件中"
 unzip -o "$ZIPFILE" 'system/vendor/etc/thermald-devices.conf' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}