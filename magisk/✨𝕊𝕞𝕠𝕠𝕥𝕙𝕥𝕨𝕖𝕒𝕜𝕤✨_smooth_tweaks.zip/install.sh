# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

print_modname() {
  ui_print "                 "
  ui_print "
░██████╗███╗░░░███╗░█████╗░░█████╗░████████╗██╗░░██╗
██╔════╝████╗░████║██╔══██╗██╔══██╗╚══██╔══╝██║░░██║
╚█████╗░██╔████╔██║██║░░██║██║░░██║░░░██║░░░███████║
░╚═══██╗██║╚██╔╝██║██║░░██║██║░░██║░░░██║░░░██╔══██║
██████╔╝██║░╚═╝░██║╚█████╔╝╚█████╔╝░░░██║░░░██║░░██║
╚═════╝░╚═╝░░░░░╚═╝░╚════╝░░╚════╝░░░░╚═╝░░░╚═╝░░╚═╝

████████╗░██╗░░░░░░░██╗███████╗░█████╗░██╗░░██╗░██████╗
╚══██╔══╝░██║░░██╗░░██║██╔════╝██╔══██╗██║░██╔╝██╔════╝
░░░██║░░░░╚██╗████╗██╔╝█████╗░░███████║█████═╝░╚█████╗░
░░░██║░░░░░████╔═████║░██╔══╝░░██╔══██║██╔═██╗░░╚═══██╗
░░░██║░░░░░╚██╔╝░╚██╔╝░███████╗██║░░██║██║░╚██╗██████╔╝
░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░"
ui_print "                  "
ui_print "                  "
sleep 0.25
ui_print " By. Desire - Telegram @DESIRE_TM "
ui_print "                 "
}
  
set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive "$MODPATH/system/bin" root root 0777 0755
  set_perm_recursive $MODPATH/system/etc/init.d 0 0 0755 0644

}