#是否全权接管安装流程
#SKIPUNZIP=1

#替换或新增文件放入system文件夹
#vendor product system-ext等目录前加system/
#若需启动时执行命令的使用post-fs-data.sh或service.sh
#修改系统属性build.prop,使用system.prop

# 以下为精简列表，填入文件夹路径而不是文件
# 一行一个，例system/app/yomol/
REPLACE="
/system/product/app/AnalyticsCore
/system/product/priv-app/MIService
/system/product/app/HybridPlatform
/system/product/priv-app/MIUIBrowser
/system/system_ext/app/MiuiDaemon
/system/product/app/SogouInput
/system/product/priv-app/MIUIQuickSearchBox
/system/product/priv-app/QuickSearchBox_M2M3
/system/product/app/MiBugReport
/system/product/app/MSA
/system/product/app/system/
"

# 此文件将被安装脚本在 util_functions.sh 之后 source 化（设置为环境变量）
# 若需自定义操作, 请在此以函数方式定义它，然后在update-binary调用这些函数
# 不要直接向update-binary添加代码，因为这样不方便模块迁移
# 尽量不要对update-binary文件做其他修改，尽量只在其中执行函数调用

#以下为清理精简应用的数据
#来自酷安 @代号10007 的图文
rm rf /data/system/package_cache/*
rm rf /data/dalvik-cache/*/system@*@AnalyticsCore*
rm rf /data/dalvik-cache/*/system@*@MIService*
rm rf /data/dalvik-cache/*/system@*@HybridPlatform*
rm rf /data/dalvik-cache/*/system@*@MIUIBrowser*
rm rf /data/dalvik-cache/*/system@*@MiuiDaemon*
rm rf /data/dalvik-cache/*/system@*@SogouInput*
rm rf /data/dalvik-cache/*/system@*@MIUIQuickSearchBox*
rm rf /data/dalvik-cache/*/system@*@QuickSearchBox_M2M3*
rm rf /data/dalvik-cache/*/system@*@MiBugReport*
rm rf /data/dalvik-cache/*/system@*@MSA*
print_modname() {
ui_print "
**************************************************************
- 模块: $MODNAME
- 模块ID: $MODID
- 作者: $MODAUTHOR
- 介绍: $MODdescription
**************************************************************
 "
}
