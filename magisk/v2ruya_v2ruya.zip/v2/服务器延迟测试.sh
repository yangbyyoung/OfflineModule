echo "\E[1;36m"
if [ -f ping（结果）.txt ]; then 
rm -r ping（结果）.txt; 
fi
cd ${0%/*}/核心文件勿动
files="/data/v2/节点配置文件"
for file in $files/*
do
filenameini="basename $file"
filename=`echo ${filenameini%.*}`
addr=`cat $file | grep "addr" | cut -d '"' -f 2 | cut -d '=' -f 2 | cut -d ':' -f 1`
naip="$filename"-"$addr"
$naip >> ${0%/*}/核心文件勿动/ip
done

echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
echo "在测延迟之前必须关闭clnc和v2等代理工具"
echo "只支持直连节点，理论上不支持中转节点"
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
echo "正在测试延迟...不要退出"
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
echo "测试过程会输出→ping（测试中）.txt"

while read line
do
ip=`echo ${line##*-}`
ping=`setsid ping -c 50 -w 4 -A -q $ip`
avgping=$(echo "$ping" | grep "rtt" | cut -d '=' -f 2 | cut -d '/' -f 2)
avgpingzs=$(echo "$avgping" | cut -d '.' -f 1)
if [[ "$avgping" = "" ]];then
zt="❌无法连接"
elif [[ "$avgpingzs" -ge 0 && "$avgpingzs" -le 10 ]];then
zt="❗无效连接"
elif [[ "$avgpingzs" -ge 10 && "$avgpingzs" -le 100 ]];then
zt="🟢极速"
elif [[ "$avgpingzs" -ge 100 && "$avgpingzs" -le 150 ]];then
zt="🔵良好"
elif [[ "$avgpingzs" -ge 150 && "$avgpingzs" -le 200 ]];then
zt="🟡一般"
elif [[ "$avgpingzs" -ge 200 ]];then
zt="🔴较差"
fi
echo "延迟:$avgping"ms  $zt ｜ "$line" >> ${0%/*}/ping（测试中）.txt
done < ip
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
echo "ping值已输出→ping（结果）.txt"
rm -r ${0%/*}/核心文件勿动/ip
cd ${0%/*}
mv ping（测试中）.txt ping（结果）.txt
echo "\n测出ping值不代表节点有网，没有ping值也不代表节点没网，ping低也不代表体验就好\n仅供参考，实际体验可能有很大差别" >> ${0%/*}/ping（结果）.txt