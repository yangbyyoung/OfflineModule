SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/WCNSS_qcom_cfg.sh
key_source $MODPATH/cnss_diag.sh
set_perm_recursive  $MODPATH  0  0  0755  0644

