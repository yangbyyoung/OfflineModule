- 0.01
 > 已经适配scene，可用scene切换调度模式。
 > 或者使用`setprop Key.Esa.sate balance`(balance是模式) 
 > 模块会进行lmk和vm调整，优化内存回收。
 > 模块也会启用自带的温控，如果有其他温控模块，也可以用，但不保证不冲突。
 > 模块会禁用msm_irqbalance。
 
- 0.02
 > 采用crond 模式进行模式监测，时间为1分钟。
 
- 0.03
 > 修正部分bug。

- 0.04
 > 优化省电模式过于流畅的bug。

- 0.05
 > 移除部分不合理参数。
 > 添加`I/O 统计或者调试`的禁用。

- 0.06
 > 禁用`perf`，即触摸升频
 > 下调省电和均衡模式`GPU频率`。
 > 在忘了说调度的脚本路径在`/data/powercfg.sh` 和 `/data/adb/modules/845-ESA-key/crond/powercfg.sh` 
 > 用shell指令输入 `sh /data/powercfg.sh balance `，指令也可进行切换调度。
 > 如果不想用crond 监测，可以在模块内修改，删除(重命名)压缩包(模块目录)内的`crond`文件夹即可。
 > crond 监测时间改为每3分钟监测1次。
 > 如果不想对GPU限制，需在调度的脚本路径修改：将`GPU_POWER_SET` 这个字符删除(带function 可以不用管)或者说注释掉。

- 0.07
 > 取消对`perf`文件夹下的内存配置文件修改
 > 将均衡模式的最高负载改为2649600

- 0.08
 > `均衡`和`省电`模式下关闭schedutil加速，仅在`性能`和`极速`下开启，确保不会让大核频繁唤醒。
