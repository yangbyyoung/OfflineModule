#!/system/bin/sh
MODDIR=${0%/*}
ylxy=`wm size | grep Physical| cut -d ':' -f2 | xargs echo`
_peiz=$MODDIR/配置.conf
_qt_jinc=$(dumpsys activity | grep mResume | cut -d '/' -f1 | awk -F" " '{print $4}')
ifjinc=`cat ${_peiz} | grep "${_qt_jinc}"`
xgxy=`sed "/^$_qt_jinc /!d;s/.* //" $_peiz`
if [[ $ifjinc != '' ]];then
if [[ `wm size | grep Override | cut -d ':' -f2 | xargs echo` != "$xgxy" ]]; then
wm size $xgxy
echo "修改" $xgxy
fi
else
if [[ `wm size | cut -d ':' -f2 | xargs echo` != "$ylxy" ]]; then
wm size $ylxy
echo "恢复"
fi
fi