MODDIR=${0%/*}
if [[ "$MODPATH" == "" ]]; then
  MODPATH=$MODDIR
fi

sku=$(getprop ro.boot.hardware.sku | tr 'A-Z' 'a-z')
if [[ "$sku" == "" ]]; then
  sku=$(getprop ro.product.odm.device)
fi

slot=$(getprop ro.boot.slot_suffix)
echo '当前系统插槽：' $slot

img=''
case "$sku" in
penrose)
  img='devcfg.img'
;;
*)
  echo '无可用镜像文件'
  exit 2
;;
esac

if [[ -f $MODPATH/$img && -e /dev/block/by-name/devcfg$slot ]]; then
  dd if=$MODPATH/$img of=/dev/block/by-name/devcfg$slot
  echo '安装完成，现在可以重启手机'
  echo '此操作具有一定风险，如果你还没有备份重要数据，建议先备份再重启！'
else
  echo '必要文件路径无法访问，安装失败！'
  exit 2
fi

