#!/system/bin/sh

Module_Path="/data/adb/modules"

# 设置Manjusaka_thermal路径

thermal_path="$Module_Path/Manjusaka_thermal"

# 更改文件夹及其子文件夹权限为755

find "$thermal_path" -type d -exec chmod -R 755 {} + >/dev/null 2>&1

# 等待3秒钟

sleep 3

# 启动后台进程

nohup "$thermal_path/Manjusaka.sh" >/dev/null 2>&1 &