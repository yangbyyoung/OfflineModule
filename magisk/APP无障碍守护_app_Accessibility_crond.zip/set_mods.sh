#!/system/bin/sh

id="app_Accessibility_crond"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
CROND_FILE=$MODPATH/crond/root

function show_value() {
	local value=$1
	local file=$MODPATH/模块配置.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g;s/，/,/g;s/——/-/g;s/：/:/g;s/[[:space:]]//g'
}

function set_crond_fast() {
	mkdir -p ${CROND_FILE%/*}
	sed -i "s/.*app_set_Accessibility.sh//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	echo "* * * * * /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh
	* * * * * sleep 5 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh
	* * * * * sleep 10 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh
	* * * * * sleep 25 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh 
	* * * * * sleep 35 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh
	* * * * * sleep 45 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh
	* * * * * sleep 55 && /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh " >>$CROND_FILE
	sed -i "s/	//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	chmod -R 777 $MODPATH/crond
}

function set_crond_comoon() {
	mkdir -p ${CROND_FILE%/*}
	sed -i "s/.*app_set_Accessibility.sh//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	echo "*/"$(show_value "扫描时间")" * * * * /data/adb/$Magisk_mod/$id/crond/app_set_Accessibility.sh" >>$CROND_FILE
	chmod -R 777 $MODPATH/crond
}

function set_crond_battery() {
	mkdir -p ${CROND_FILE%/*}
	sed -i "s/.*white.sh//g;/^[[:space:]]*$/d" $CROND_FILE 2>/dev/null
	echo "*/"$(show_value "电池优化白名单清理扫描时间")" * * * * /data/adb/$Magisk_mod/$id/crond/white.sh" >>$CROND_FILE
	chmod -R 777 $MODPATH/crond
}

if test $(show_value "无障碍保活定时任务") == 开启; then
	set_crond_comoon
	if test $(show_value "高强度扫描") == 开启; then
		set_crond_fast
	fi
fi

if test $(show_value "电池优化白名单清理") == 开启; then
	set_crond_battery
fi

if test "$(show_value "电池优化白名单清理")" != "开启" -a "$(show_value "无障碍保活定时任务")" != "开启"; then
	rm -rf $MODPATH/crond
fi
