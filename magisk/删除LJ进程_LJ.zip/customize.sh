REPLACE="
/system/system/app/AnalyticsCore
/system/system/app/BasicDreams
/system/system/app/BookmarkProvider
/system/app/BookmarkProvider
/system/app/BuiltInPrintService
/system/app/CarrierDefaultApp
/system/app/CatcherPatch
/system/app/CatchLog
/system/app/Cit
/system/app/com.miui.qr
/system/app/GooglePrintRecommendationService
/system/product/priv-app/GoogleServicesFramework
/system/product/priv-app/GooglePlayServicesUpdate
/system/product/priv-app/GooglePartnerSetup
/system/product/priv-app/GoogleOneTimeInitializer
/system/product/priv-app/GmsCore
/system/product/app/xdivert
/system/product/app/talkback
/system/priv-app/PlatformNetworkPermissionConfig
/system/priv-app/MiService
/system/priv-app/MiRcs
/system/priv-app/CtsShimPrivPrebuilt
/system/priv-app/ContentExtension
/system/data-app/XiaoAiSpeechEngine
/system/data-app/VirtualSim
/system/data-app/SmartTravel
/system/data-app/MiMobileNoti
/system/data-app/MiLiveAssistant
/system/data-app/GoogleContactsSyncAdapter
/system/app/VsimCore
/system/app/VoiceTrigger
/system/app/VoiceAssist
/system/app/Updater
/system/app/TouchAssistant
/system/app/Stk
/system/app/SecurityInputMethod

"

#注释！！！看，一定要看！！！！！！
#有什么需要反馈的去酷安主页
#前面如果是一个#，则是没有添加进精简列表的项目
#如果前面是一大堆######则是添加进精简列表的文件！
# /system/app/AiAsstVision	AI虚拟服务(智能电话助理支持组件)	可删		
# /system/app/BasicDreams	基本互动屏保	可删
# /system/app/BTProductionLineTool	未知，翻译为BT生产线工具	建议保留	
# /system/app/CloudService	小米云服务	建议保留	
# /system/app/CtsShimPrebuilt	与Goolge N CTS 相关	建议保留	
# /system/app/daxService	杜比音效组件	可删	
# /system/app/DeskClock	时钟	建议保留	
# /system/app/Dolby	杜比音效	可删	
# /system/app/FidoAuthen	生物识别技术组件	可删	可能关于指纹的组件，删后指纹依然可用，无不良反应
# /system/app/FidoClient	生物识别技术组件	可删	可能关于指纹的组件，删后指纹依然可用，无不良反应
# /system/app/FrequentPhrase	常用语	可删	
# /system/app/FusedLocationProvider	融合位置服务	建议保留	。
# /system/app/GuardProvider	MIUI安全组件	建议保留	
# /system/app/HTMLViewer	HTML查看器	可删	卸载影响少数公共WiFi登录
# /system/app/Joyose	负一屏计步器	建议保留		
# /system/app/KSICibaEngine	金山翻译组件	可删	
# /system/app/LiveWallpapersPicker	动态壁纸选择器	可删	删后无法正常使用动态壁纸
# /system/app/mab	小米商城系统组件	可删	
# /system/app/MiCloudSync	小米云同步	建议保留	
# /system/app/MiLinkService2	小米投屏	可删	
# /system/app/Mipay	小米钱包	可删	
# /system/app/MiPlayClient	小米投屏服务	可删	
# /system/app/MiSound	小米音质音效	建议保留	删后App音量无法独立控制
# /system/app/MiuiBiometric	人脸识别解锁	建议保留	
# /system/app/MiuiBluetooth	小米蓝牙组件	建议保留	
# /system/app/MiuiSuperMarket	小米应用商店	可删	
# /system/app/MiuiSystemUIPlugin	未知，翻译为状态栏插件	建议保留	
# /system/app/MiuiWallpaper	MIUI壁纸	可删	删后无法使用超级壁纸
# /system/app/NextPay	小米支付	可删	
# /system/app/NQNfcNci	NFC服务	可删	
# /system/app/OsuLogin	未知，翻译为Osu登录	建议保留	可能连wifi的时候会用的到
# /system/app/OTrPBroker	未知，翻译为TAM服务	建议保留	
# /system/app/PacProcessor	代理自动配置相关	可删	
# /system/app/PaymentService	米币支付	可删	
# /system/app/PlatformCaptivePortalLogin	wifi认证	可删	删除后若wifi链接出现问题，可能会造成无法跳转进入wifi的网页进行验证
# /system/app/PowerChecker	耗电检测	可删	
# /system/app/PowerKeeper	电池和性能	建议保留	
# /system/app/QColor	QTI增强颜色模式	建议保留	
# /system/app/SecureElement	NFC功能相关	可删	
# /system/app/securityadd	系统服务组件	建议保留	
# /system/app/SecurityCoreAdd	安全核心组件	建议保留	删后会导致 系统分身/应用双开 不可用
# /system/app/SimAppDialog	SIM卡应用程序对话框	可删	
# /system/app/SimContact	SIM卡联系人	可删	
# /system/app/SmsExtra	短信智能识别	建议保留	可能是用来自动识别验证码的
# /system/app/SogouInput	搜狗输入法	可删	
# /system/app/ThemeManager	小米主题	建议保留	
# /system/app/ThemeModule	小米主题组件	建议保留	
# /system/app/TProxy	未知，翻译为T代理	建议保留	
# /system/app/Traceur	系统跟踪	建议保留	
# /system/app/TranslationService	翻译服务	可删	
# /system/app/WallpaperBackup	壁纸备份	可删	
# /system/app/WapiCertManage	WAPI证书管理	建议保留	
# /system/app/WAPPushManager	WAP推送服务	可删	
# /system/app/WMService	未知，不知道什么服务	建议保留	
# /system/app/workloadclassifier	未知	建议保留	高通app
# /system/app/XiaomiModemDebugService	小米调试服务	建议保留	
# /system/app/XiaomiServiceFramework	小米服务框架	建议保留	
# /system/app/XiaomiSimActivateService	小米SIM卡激活服务	建议保留	
# /system/app/XMCloudEngine	小米云同步账号登录	建议保留	
# /system/app/XMSFKeeper	未知，翻译为小米服务框架保管	建议保留	
# /system/app/YouDaoEngine	有道翻译组件	可删	
# /system/data-app/CleanMaster	手机管家垃圾清理	建议保留
# /system/data-app/MiDrive	小米云盘	可删
# /system/data-app/Notes	小米便签	建议保留
# /system/data-app/VipAccount	小米社区	可删
# /system/data-app/Weather	小米天气	建议保留

	
# /system/priv-app/Backup	备份	可删	
# /system/priv-app/BackupRestoreConfirmation	备份恢复程序	可删	
# /system/priv-app/beyondGeofenceService	定位服务	建议保留	
# /system/priv-app/BlockedNumberProvider	存储已屏蔽的号码	建议保留	通讯录黑名单
# /system/priv-app/Browser	浏览器	可删	删后会导致需要打开网页的项目报错，后期装个浏览器就可解决
# /system/priv-app/Calendar	日历	建议保留	
# /system/priv-app/CalendarProvider	日历储存	建议保留	
# /system/priv-app/CallLogBackup	备份通话记录	建议保留	小米云服务中备份通话记录的
# /system/priv-app/CloudBackup	桌面云备份	建议保留	
# /system/priv-app/CloudServiceSysbase	小米云备份组件	建议保留	
# /system/priv-app/DMRegService	未知，翻译为DM注册服务	可删	
# /system/priv-app/DynamicSystemInstallationService	动态系统更新	可删	Android系统推出更新后用户可以先升级进行试用，觉得系统没有问题后再正式安装此次更新
# /system/priv-app/InProcessNetworkStack	网络堆栈服务	建议保留	
# /system/priv-app/LocalTransport	未知，翻译为本地传输服务	建议保留	
# /system/priv-app/ManagedProvisioning	设备配置器	建议保留	手机不连接其他设备的话可以删
# /system/priv-app/MiGameCenterSDKService	小米游戏服务	可删	用来玩小米游戏时的付费验证SDK
# /system/priv-app/Mirror	跨屏协作	可删	
# /system/priv-app/MiShare	小米互传	可删	
# /system/priv-app/MiuiAod	小米万象息屏	可删	
# /system/priv-app/MiuiExtraPhoto	MIUI额外照片	建议保留	
# /system/priv-app/MiuiFreeformService	MIUI自由窗口	建议保留	
# /system/priv-app/MiuiGallery	小米相册	建议保留	
# /system/priv-app/MiuiHome	小米桌面	建议保留	
# /system/priv-app/MiuiPackageInstaller	应用包管理组件	建议保留	
# /system/priv-app/MiuiScreenRecorder	小米录屏	建议保留	
# /system/priv-app/MiuiScreenshot	小米截屏	建议保留	
# /system/priv-app/MiuiVideo	小米视频	可删	
# /system/priv-app/Music	小米音乐	可删	
# /system/priv-app/MusicFX	音效	可删	
# /system/priv-app/NewHome	小米桌面内容中心	可删		
# /system/priv-app/ONS	未知	建议保留		
# /system/priv-app/PersonalAssistant	智能助理(负一屏)	建议保留	
# /system/priv-app/ProxyHandler	代理处理器	可删	
# /system/priv-app/QuickSearchBox	搜索	可删	
# /system/priv-app/RtMiCloudSDK	未知，可能跟小米云同步有关	建议保留	
# /system/priv-app/SharedStorageBackup	共享储存备份	可删	
# /system/priv-app/SoundRecorder	录音机	建议保留	
# /system/priv-app/StatementService	实现App Links(报表服务)	建议保留	
# /system/priv-app/Tag	Nfc相关组件	可删	
# /system/priv-app/UserDictionaryProvider	用户词典	可删	
# /system/priv-app/VpnDialogs	Vpn组件	建议保留	
# /system/priv-app/WfdService	WFD服务	可删	详细解释请百度
# /system/priv-app/YellowPage	黄页	建议保留	删后来电可能无法显示归属地
# /system/product/app/aiasst_service	AI虚拟服务(智能电话助理支持组件)	可删	
# /system/product/app/PhotoTable	主页照片小部件	可删	
# /system/product/app/remoteSimLockAuthentication	远程SIM卡锁定身份验证	建议保留	
# /system/product/app/remotesimlockservice	远程SIM卡锁定服务	建议保留	
# /system/product/app/TrichromeLibrary	安卓10版本的Webview	建议保留	



# /system/product/priv-app/CarrierConfig	运营商配置	建议保留	
# /system/product/priv-app/ConfigUpdater	配置更新	建议保留	
# /system/product/priv-app/EmergencyInfo	急救信息	可删	
# /system/product/priv-app/ims	HD高清通话	建议保留	该App是Volte高清通话的一个服务，删了会无法在通知栏显示HD
# /system/product/priv-app/QAS_DVC_MSP	一种基于LTE的广播或多播技术	可删	运营商会在您睡觉的时候帮您下载好软件
# /system/product/priv-app/WallpaperCropper	壁纸选择器	可删	
# /system/vendor/app/CACertService	未知	建议保留	高通app
# /system/vendor/app/CneApp	未知	建议保留	高通app
# /system/vendor/app/com.qualcomm.qti.improvetouch.service	未知	建议保留	高通app
# /system/vendor/app/IWlanService	未知	建议保留	高通app
# /system/vendor/app/NotchOverlay	未知	建议保留	
# /system/vendor/app/pasrservice	未知	建议保留	高通app
# /system/vendor/app/PowerOffAlarm	关机闹钟	建议保留	高通app
# /system/vendor/app/QDMA	快速存储器访问	建议保留	
# /system/vendor/app/QDMA-UI	快速存储器访问界面	建议保留	
# /system/vendor/app/QFingerprintService	未知	建议保留	高通app
# /system/vendor/app/SoterService	索特服务	建议保留	
# /system/vendor/app/TimeService	时间服务	建议保留	高通app















# #####/system/app/BookmarkProvider	google N 浏览器相关，书签存储	可删	
# #####/system/app/BuiltInPrintService	系统打印服务	可删	
# #####/system/app/CarrierDefaultApp	运营商默认应用	可删	
# #####/system/app/CatcherPatch	获取补丁	可删	
# #####/system/app/CatchLog	CatchLog	可删		
# ######/system/app/Cit	硬件检测工具	可删	
# ######/system/app/com.miui.qr	Cit_QR	可删	可能用于出厂测试	
# ######/system/app/GooglePrintRecommendationService	谷歌服务	可删	
# ######/system/app/greenguard	安全守护服务	可删	
# ######/system/app/HybridAccessory	智慧生活	可删	
# ######/system/app/HybridPlatform	快应用服务框架	可删	
# ######/system/app/mi_connect_service	小米互联通信服务	可删	
# ######/system/app/MiuiAccessibility	小米闻声	可删	
# ######/system/app/MiuiAudioMonitor	未知，可能是唱歌用的	可删	
# ######/system/app/MiuiBugReport	用户反馈	可删	
# ######/system/app/MiuiContentCatcher	应用程序扩展服务	可删	传送门内容抓取，传送门删除了就可以删除此项
# ######/system/app/MiuiDaemon	用户信息收集	可删	
# ######/system/app/MiuiVpnSdkManager	游戏加速里的网络加速功能	可删	
# ######/system/app/MSA	小米国内广告组件	可删	
# ######/system/app/OPWallet	一加公交卡	可删	
# ######/system/app/PrintSpooler	打印处理服务	可删	
# ######/system/app/SecurityInputMethod	小米安全键盘	可删	
# ######/system/app/Stk	USIM卡应用	可删	
# ######/system/app/TouchAssistant	悬浮球	可删	
# ######/system/app/Updater	系统更新	可删	
# ######/system/app/VoiceAssist	小爱同学	可删	
# ######/system/app/VoiceTrigger	小爱同学唤醒	可删	
# ######/system/app/VsimCore	虚拟SIM卡内核	可删	
# ######/system/data-app/GoogleContactsSyncAdapter	Google通讯录同步	可删
# ######/system/data-app/MiLiveAssistant	小米直播助手	可删
# ######/system/data-app/MiMobileNoti	小米全球上网组件	可删
# ######/system/data-app/SmartTravel	智能出行	可删
# ######/system/data-app/VirtualSim	小米全球上网	可删
# ######/system/data-app/XiaoAiSpeechEngine	系统语音引擎	可删
# ######/system/priv-app/ContentExtension	传送门	可删	
# ######/system/priv-app/CtsShimPrivPrebuilt	测试工具	可删	Google原生的CTS兼容性测试预制的东西
# ######/system/priv-app/MiRcs	MIUI免费网络短信	可删	
# ######/system/priv-app/MiService	服务与反馈	可删	
# ######/system/priv-app/PlatformNetworkPermissionConfig	谷歌全家桶组件	可删	
# ######/system/product/app/talkback	盲人模式	可删	
# ######/system/product/app/xdivert	数据迁移	可删	小米一键迁移数据到新手机服务
# ######/system/product/priv-app/GmsCore	谷歌Play服务	可删	
# ######/system/product/priv-app/GoogleOneTimeInitializer	谷歌套件安装组件	可删	一次性批量初始化各种Google应用
# ######/system/product/priv-app/GooglePartnerSetup	谷歌合作伙伴设置	可删	
# ######/system/product/priv-app/GooglePlayServicesUpdater	谷歌服务更新程序	可删	
# ######/system/product/priv-app/GoogleServicesFramework	谷歌服务框架	可删	