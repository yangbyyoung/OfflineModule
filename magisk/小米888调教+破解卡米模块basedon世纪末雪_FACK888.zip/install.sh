#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用
SKIPMOUNT=false
#是否使用common/system.prop文件
PROPFILE=true
#是否使用post-fs-data脚本执行文件
POSTFSDATA=true
#是否在开机时候允许允许common/service.sh中脚本
LATESTARTSERVICE=true

REPLACE="
"
print_modname() {
ui_print "******************************"
ui_print "        内核调校模块         "
ui_print "******************************"
ui_print " "
ui_print "************************************************"
ui_print "1.保持系统流畅度且省电"
ui_print "2.删除温控释放高通火龙888"
ui_print "3.删除温控不跳电"
ui_print "4.处理器体质开机后请去cache查看CPU.log"
ui_print "5.省电/均衡/性能 调度参数可调-scene"
ui_print "************************************************"
ui_print " "
ui_print "****************************************"
ui_print "*************重启后生效**************"
ui_print "****************************************"
}

set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}
swap_config="/data/swap_config.conf"
# ro.lmk.enhance_batch_kill false
update_overlay() {
  local prop="$1"
  local value="$2"
  sed -i "s/Name=\"$prop\" Value=\".*\"/Name=\"$prop\" Value=\"$value\"/" $overlay_file
}
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $TMPDIR/system.prop
}

get_prop() {
  cat $swap_config | grep "^$1=" | cut -f2 -d '='
}
origin_dir="/system/vendor/etc/perf"
origin_file="$origin_dir/perfconfigstore.xml"
overlay_dir="$MODPATH$origin_dir"
overlay_file="$MODPATH$origin_file"
old_module_file=/data/adb/modules/snow$origin_dir/perfconfigstore.xml
if [[ -e $old_module_file ]]; then
  old_module_version=`grep '^versionCode=' /data/adb/modules/snow/module.prop | cut -f2 -d '='`
  if [[ "$old_module_version" == "" ]] || [[ "$old_module_version" -lt 2000 ]]; then
    ui_print "************************************"
    ui_print "正在删除旧版模块并继续安装!"
    ui_print "************************************"
    rm -rf /data/swapfile*
    rm -rf /data/swap_recreate
    rm -rf /data/swap_config.conf
    rm -rf /data/powercfg.sh
    rm -rf /data/adb/modules/snow
  fi
    else
    ui_print "************************************"
    ui_print "未发现旧版模块继续安装"
    ui_print "************************************"
fi
if [[ -e $old_module_file ]]; then
  old_module_version=`grep '^versionCode=' /data/adb/modules/snow/module.prop | cut -f2 -d '='`
  if [[ "$old_module_version" == "" ]] || [[ "$old_module_version" -lt 2000 ]]; then
    ui_print "***************************************************************"
    ui_print "未完全删除请删除旧版模块并重启手机，回来再安装!"
    ui_print "***************************************************************"
    exit 2
  fi
fi
# 判断是否有busybox依赖
if [[ -f "/system/bin/busybox" ]]; then
  ui_print "************************************************"
  ui_print "有busybox依赖分区优化将在开机后执行"
  ui_print "************************************************"
  elif [[ -f "/system/xbin/busybox" ]]; then
  ui_print "************************************************"
  ui_print "有busybox依赖分区优化将在开机后执行"
  ui_print "************************************************"
  else
  ui_print "************************************************"
  ui_print "没有外部busybox，采用系统程序执行!"
  ui_print "************************************************"
fi

swap_enable=false
swap_size=4096
swap_use_loop=false
zram_enable=true
zram_size=4096

# 检测UFS健康
ufs_health_check() {
  # 0x00	未找到有关设备使用寿命的信息。
  # 0x01	设备估计使用寿命的 0% 到 10%。
  # 0x02	设备估计使用寿命的 10% 到 20%。
  # 0x03	设备估计使用寿命的 20% 到 30%。
  # 0x04	设备估计使用寿命的 30% 到 40%。
  # 0x05	设备估计使用寿命的 40% 到 50%。
  # 0x06	设备估计使用寿命的 50% 到 60%。
  # 0x07	设备估计使用寿命的 60% 到 70%。
  # 0x08	设备估计使用寿命的 70% 到 80%。
  # 0x09	设备估计使用寿命的 80% 到 90%。
  # 0x0A	设备估计使用寿命的 90% 到 100%。
  # 0x0B	设备已超过其估计的使用寿命。
  bDeviceLifeTimeEstA=$(cat /sys/kernel/debug/*.ufshc/dump_health_desc | grep bDeviceLifeTimeEstA | cut -f2 -d '=' | cut -f2 -d ' ')
  # 0x00	未定义成员。
  # 0x01	正常。消耗不到 80% 的保留区块。
  # 0x02	消耗了 80% 的保留区块。
  # 0x03	危急。消耗了 90% 的保留区块。
  # 所有其他值	保留供将来使用。
  bPreEOLInfo=$(cat /sys/kernel/debug/*.ufshc/dump_health_desc | grep bPreEOLInfo | cut -f2 -d '=' | cut -f2 -d ' ')
  if [[ "$bDeviceLifeTimeEstA" == "0x01" ]] || [[ "$bDeviceLifeTimeEstA" == "0x1" ]]; then
    if [[ "$bPreEOLInfo" == "0x01" ]] || [[ "$bPreEOLInfo" == "0x1" ]]; then
      return 1
    fi
  elif [[ "$bDeviceLifeTimeEstA" == "" ]] && [[ "$bPreEOLInfo" == "" ]]; then
    return 1
  fi
  return 0
}

# 根据设备性能自动调整参数
auto_config () {
  MemTotalStr=`cat /proc/meminfo | grep MemTotal`
  MemTotalKB=${MemTotalStr:16:8}
  ui_print "- RAM Total:${MemTotalKB}KB"

  ufs_health_check
  ufs_health_ok=$?
  soc_platform=$(getprop ro.board.platform)

  if [[ "$zram_enable" == "true" ]]; then
    ui_print "- ZRAM ON ${zram_size}MB"
  else
    ui_print "- ZRAM OFF"
  fi
}

on_install() {
ui_print "- 提取模块文件"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
echo "" > /data/swap_recreate
echo "
# 是否配置swapfile
swap=false
# swapfile大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=4096
# swapfile使用顺序
#  0 与zram同时使用
# -2 用完zram后再使用
#  5 优先于zram使用）
swap_priority=-2
# 是否将swapfile挂载为回环设备
# 在很多设备上性能表现很差。如非必要，不建议开启
swap_use_loop=false
# 是否配置zram
# 注意: 设为false并不代表禁用zram，而是保持系统默认配置
# 如果你想关闭系统默认开启的zram，则因设为true，并配置zram_size为0
zram=true
# zram大小(MB)，部分设备超过2047会开启失败
zram_size=4096
# zram压缩算法(可设置的值取决于内核支持)
# lzo和lz4都很常见，性能也很好
comp_algorithm=lz4
# 使用SWAP的积极性
# 不要设置的太低，避免在内存严重不足时才开始大量回收内存，导致IO压力集中。建议值30~100
swappiness=100
# 额外空余内存(kbytes)
# 数值越大越容易触发swap和内存回收
extra_free_kbytes=102400
# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值。如果我有8G物理内存，那么回收10%就是一口气回收了大概800M，这个过程需要消耗不少性能，导致短时间卡住
# 但是设置太小也会导致swap因为每次回收的内存量太少而效率过低，出现连续的卡顿掉帧
# 因此，请酌情设置watermark_scale_factor
watermark_scale_factor=50
" > $swap_config
device=$(getprop ro.product.vendor.name)
manufacturer=$(getprop ro.product.vendor.manufacturer)
platform=$(getprop ro.board.platform)
if [[ -f $origin_file ]]
then
mkdir -p $overlay_dir
cp $origin_file $overlay_file
update_overlay ro.lmk.use_psi true
update_overlay ro.lmk.psi_partial_stall_ms 70
update_overlay ro.lmk.psi_complete_stall_ms 700
update_overlay ro.lmk.thrashing_limit 100
update_overlay ro.lmk.thrashing_limit_decay 10
update_overlay ro.lmk.swap_util_max 100
update_overlay ro.lmk.swap_free_low_percentage 20
update_overlay ro.lmk.debug false
update_overlay ro.config.low_ram false
update_overlay ro.lmk.use_minfree_levels true
update_overlay ro.lmk.low 1001
update_overlay ro.lmk.medium 900
update_overlay ro.lmk.critical 800
update_overlay ro.lmk.critical_upgrade true
update_overlay ro.lmk.upgrade_pressure 100
update_overlay ro.lmk.downgrade_pressure 100
update_overlay ro.lmk.kill_heaviest_task true
update_overlay ro.lmk.kill_timeout_ms 0
update_overlay ro.lmk.debug false
fi
rm -f /data/vendor/thermal/config
rm -f /data/vendor/thermal/thermal.dump
rm -f /data/vendor/thermal/thermal_history.dump
rm -rf /data/powercfg.sh
mv -f /data/adb/modules_update/FACK888/system/bin/powercfg.sh /data/
rm -rf /data/adb/modules_update/FACK888/system/bin/powercfg.sh
}