MODDIR=${0%/*}

TMPDIR=/data/local/tmp/mount_lib

# Extract from diting_global:13/V14.0.3.0.TLFMIXM
# Pzqqt: Tweak the middle core scheduling frequency table (cpufreq_table4) to adapt to SM7475
insmod $MODDIR/module/perfmgr_diting-hack.ko || :

rm -rf $TMPDIR
mkdir -p $TMPDIR/system_ext/lib64

sed 's?ro.product.product.name?ro.product.prodcut.name?' \
    /system_ext/lib64/libmigui.so \
    > $TMPDIR/system_ext/lib64/libmigui.so

mount --bind "$TMPDIR/system_ext/lib64/libmigui.so" "/system_ext/lib64/libmigui.so"

restorecon /system_ext/lib64/libmigui.so
