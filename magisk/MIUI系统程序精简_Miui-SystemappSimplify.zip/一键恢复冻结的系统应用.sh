#!/system/bin/sh
file=${0%/*}/冻结包名.conf
cat "${file}" | grep -v "^#" | while read packagename ;do
pm enable $packagename
done