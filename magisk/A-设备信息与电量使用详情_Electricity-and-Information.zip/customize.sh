function key_source(){
if test -e "$1" ;then
	source "$1"
	rm -rf "$1"
fi
}
key_source $MODPATH/busybox.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}
set_perm_recursive $MODPATH/Script 0 0 0755 0755
ui_print "
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
- v2.0更新: 每日重启次数统计(脚本运行开始计算)

- 模块作用: 显示设备相关信息与电池电量使用情况
- 与 [ AccuBattery ] 数据一致  且cpu占用几乎为0

- 详情查看: [ /sdcard/Android/设备与电量使用详情/ ]
- 模块脚本cpu占用可用 [ Scene ] 的进程管理搜索进程: Power_Detail 进行查看
- 若cpu占用超过10％ 则说明你的设备不适合使用

- 感谢@落叶凄凉TEL(臭臭的高雄)
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
"