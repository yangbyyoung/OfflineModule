#! /vendor/bin/sh

MODDIR=${0%/*}
conf="$MODDIR/swap/swap.log"

sys_inf=$(head -n 1 $MODDIR/swap/swap.conf)
echo "${sys_inf// /}" >$conf

function get_prop() {
  cat $MODDIR/swap/swap.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

# 解析配置
memory_control=$(get_prop memory_control)

# 设置内存管理方式
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $MODDIR/system.prop
}
if [ "$memory_control" == "lmk" ]; then
update_system_prop ro.lmk.low 1001
update_system_prop ro.lmk.medium 1001
update_system_prop ro.lmk.critical 100
update_system_prop ro.lmk.critical_upgrade true
update_system_prop ro.lmk.swap_free_low_percentage 10
update_system_prop ro.lmk.kill_timeout_ms 0
update_system_prop ro.lmk.use_psi false
update_system_prop ro.lmk.psi_partial_stall_ms 750
update_system_prop ro.lmk.psi_complete_stall_ms 1000
elif [ "$memory_control" == "psi1" ]; then
update_system_prop ro.lmk.low 1001
update_system_prop ro.lmk.medium 1001
update_system_prop ro.lmk.critical 1001
update_system_prop ro.lmk.critical_upgrade false
update_system_prop ro.lmk.swap_free_low_percentage 10
update_system_prop ro.lmk.kill_timeout_ms 10
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 750
update_system_prop ro.lmk.psi_complete_stall_ms 1000
elif [ "$memory_control" == "psi2" ]; then
update_system_prop ro.lmk.low 1001
update_system_prop ro.lmk.medium 1001
update_system_prop ro.lmk.critical 1001
update_system_prop ro.lmk.critical_upgrade false
update_system_prop ro.lmk.swap_free_low_percentage 20
update_system_prop ro.lmk.kill_timeout_ms 10
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 350
update_system_prop ro.lmk.psi_complete_stall_ms 700
elif [ "$memory_control" == "psi3" ]; then
update_system_prop ro.lmk.low 1001
update_system_prop ro.lmk.medium 1001
update_system_prop ro.lmk.critical 1001
update_system_prop ro.lmk.critical_upgrade false
update_system_prop ro.lmk.swap_free_low_percentage 30
update_system_prop ro.lmk.kill_timeout_ms 10
update_system_prop ro.lmk.use_psi true
update_system_prop ro.lmk.psi_partial_stall_ms 50
update_system_prop ro.lmk.psi_complete_stall_ms 300
else
set="false"
fi

if [ "$set" != "false" ]; then
echo "✔设置内存管理方式 [$memory_control] (可前往配置参数文件修改)" >>$conf
else
echo "✘不存在内存管理方式 [$memory_control] (请检查参数是否设置正确)" >>$conf
fi
