#!/sbin/sh
rm -rf /data/system/users/0/package-restrictions.xml
rm -rf /data/system/package_cache/*




