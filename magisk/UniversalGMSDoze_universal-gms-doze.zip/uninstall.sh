#!/system/bin/sh

#
# Universal GMS Doze by the
# open-source loving GL-DP and all contributors;
# Patches Google Play services app and certain processes/services to be able to use battery optimization
#

# Remove all module files after un-installation
rm -rf /data/adb/universal-gms-doze
