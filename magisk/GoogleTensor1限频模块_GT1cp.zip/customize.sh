SKIPUNZIP=0
  ui_print "*******************************"
  ui_print "    由NewtoPhone 制作"
  ui_print "*******************************"
on_install()
mkdir 777 /data/cron.d
# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644

