#!/system/bin/sh
# 此脚本将在late_start service 模式执行
# 如果您需要知道此脚本和模块的放置位置，请使用${MODDIR}
until [[ $(getprop sys.boot_completed) -eq 1 ]];do
  sleep 1s
done

MODDIR=${0%/*}
serviced=${0%modules*}"service.d"
test_crond=$($(magisk --path)/.magisk/busybox/crond --help &>/dev/null;echo $?)
if [[ $test_crond != "0" ]];then
  for crond_command in $(find / -type f -name "crond" 2>/dev/null);do
    $crond_command --help &>/dev/null
    [[ $? == "0" ]] && { alias crond="$crond_command";break;}
  done
  unset crond_command
else
  alias crond="$(magisk --path)/.magisk/busybox/crond"
fi

rm -f ${MODDIR}/root ${MODDIR}/root_temp 2>/dev/null
touch ${MODDIR}/root ${MODDIR}/root_temp
sleep 90s
crond_pid_list=$(/system/bin/ps -ef | grep -v "grep" | grep " crond " | awk '{print $2}')
if [[ -n "$crond_pid_list" && ! -s ${MODDIR}/root ]]
then
  for crond_pid in $crond_pid_list;do
    crond_pid_cwd=$(/system/bin/ls -la /proc/$crond_pid | grep "cwd" | awk '{print $10}')
    cat ${crond_pid_cwd}/* | grep -E "^\* | ^[0-9] | ^[0-5][0-9] | ^\*/. | ^[0-9]/. | ^[0-5][0-9]/. " >>${MODDIR}/root_temp
    unset crond_pid crond_pid_cwd
  done
  crond_head='#!/system/bin/sh\nSHELL=/system/bin/bash\nMAILTO=root\nHOME=/\nmagisk_path=$(magisk --path)/.magisk/busybox\nPATH=/sbin:/system/bin:$magisk_path:$PATH\n'
  sort -n ${MODDIR}/root_temp | uniq >${MODDIR}/root
  crond_task_num=$(wc -l ${MODDIR}/root | awk '{print $1}')
  sed -i "1i\ $crond_head" ${MODDIR}/root
  rm ${MODDIR}/root_temp
  crond_task_killnum="0"
  for crond_pid in $crond_pid_list;do
    kill -15 $crond_pid
    [[ $? == "0" ]] && crond_task_killnum=$(($crond_task_killnum+1)) || { kill -9 $crond_pid;[[ $? == "0" ]] && crond_task_killnum=$(($crond_task_killnum+1));}
    unset crond_pid
  done
else
  [[ -s ${MODDIR}/root ]] && mod_abort="初始${MODDIR}/root非空白文档;"
  [[ ! -f ${MODDIR}/root ]] && mod_abort+="未能创建${MODDIR}/root文档;"
  [[ -z "$crond_pid_list" ]] && mod_abort+="未搜索到第三方Crond服务;"
fi
unset crond_pid_list
if [[ -z "$mod_abort" && -s ${MODDIR}/root ]]
then
  chmod 777 ${MODDIR}/root
  crond -c ${MODDIR}
  sleep 5s
  crond_pid_test=$(/system/bin/ps -ef | grep -v grep | grep "crond -c ${MODDIR}")
  [[ -z "$crond_pid_test" ]] && crond_command=$(type crond | awk '{print $7}')
  [[ -z "$crond_pid_test" ]] && { sed -i "/^description=.*/ d" ${MODDIR}/module.prop;echo "description=【😔模块执行失败，未能成功启动模块的Crond服务A】Crond命令异常，命令路径：${crond_command};root文件大小$(/system/bin/ls -lh ${MODDIR}/root | awk '{print $5}')；总共收纳了${crond_task_num}个定时任务，终止了${crond_task_killnum}个第三方Crond服务；$(date +"%Y-%m-%d %H:%M.%S")。" >> ${MODDIR}/module.prop;exit 1;}
else
  sed -i "/^description=.*/ d" ${MODDIR}/module.prop
  [[ -n "$mod_abort" ]] && result_failure=$mod_abort"；root文件大小"$(/system/bin/ls -lh ${MODDIR}/root | awk '{print $5}') || result_failure="root文件为空："$(/system/bin/ls -lh ${MODDIR}/root | awk '{print $5}')"k"
  echo "description=【😔模块执行失败，不予启动Crond服务】原因：${result_failure};$(date +"%Y-%m-%d %H:%M.%S")" >> ${MODDIR}/module.prop
  exit 1
fi
crond_pid_list=$(/system/bin/ps -ef | grep -v grep | grep " crond " | awk 'BEGIN{ORS="★"}{print "PID:"$2,$8,$9}');
crond_pid_num=$(/system/bin/ps -ef | grep -v grep | grep " crond " | wc -l)
sed -i "/^description=.*/ d" ${MODDIR}/module.prop
if [[ $crond_pid_num == "1" ]]
then
  echo "description=【😄模块执行成功】总共收纳了${crond_task_num}个定时任务，终止了${crond_task_killnum}个第三方Crond服务。按Linux准则，系统只需运行一个Crond服务，由其读取配置文件，统一管理所有定时任务，没必要同时运行多个Crond服务。Crond服务虽资源消耗小，但毕竟会消耗资源！目前，一些模块会独立启动Crond服务，修改配置文件到自己模块文件夹中；平白浪费资源甚至造成服务冲突。本模块旨在解决上述问题，实现系统只运行一个Crond进程，统一管理所有模块的Crond服务。" >> ${MODDIR}/module.prop
elif [[ $crond_pid_num > 1 ]];then
  echo "description=【😊模块执行成功,但有漏网的Crond服务在运行】总共收纳了${crond_task_num}个定时任务，终止了${crond_task_killnum}个第三方Crond服务;目前，运行中的Crond服务有：$crond_pid_list。" >> ${MODDIR}/module.prop
else
  echo "description=【😔模块执行失败，未能成功启动模块的Crond服务B】root文件大小$(/system/bin/ls -lh ${MODDIR}/root | awk '{print $5}')；总共收纳了${crond_task_num}个定时任务，终止了${crond_task_killnum}个第三方Crond服务；$(date +"%Y-%m-%d %H:%M.%S")。" >> ${MODDIR}/module.prop
fi