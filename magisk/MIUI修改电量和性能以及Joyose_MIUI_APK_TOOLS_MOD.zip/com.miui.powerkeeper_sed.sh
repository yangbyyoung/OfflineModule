#!/system/bin/sh

function unpack_miui_power(){
echo "- 反编译MIUI电量和性能文件中……"
MIUIpower=$(pm path com.miui.powerkeeper | cut -d ':' -f2 )
MIUIsyspower="/system/app/PowerKeeper/PowerKeeper.apk"
MIUIsyspowerdir="$MODPATH${MIUIsyspower%/*}"
mkdir -p $MIUIsyspowerdir $MODPATH/apk
cp -rf $MIUIpower $MODPATH/apk/base.apk
cd $MODPATH/apk
$apktool d -q -r -f -m $MODPATH/apk/base.apk
echo "- 修改文件中……"
}

function mod_all_frame(){
echo "- 修改全局高刷……"
find $MODPATH -type f -name "DisplayFrameSetting.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method public static isFeatureOn()Z/,/^\.end method/d' $file
sed -i '/^\.method private setScreenEffect(Ljava\/lang\/String;II)V/,/^\.end method/d' $file
sed -i '/^\.method private setScreenEffectInternal(II)V/,/^\.end method/d' $file
cat <<"key" >>$file
.method public static isFeatureOn()Z
    .locals 1
    const/4 v0, 0x0
    return v0
.end method
.method private setScreenEffect(Ljava/lang/String;II)V
    .locals 1
    return-void
.end method
.method private setScreenEffectInternal(II)V
    .locals 1
    return-void
.end method
key
done
}

function mod_battery_recovery(){
echo "- 防止电池白名单恢复……"
find $MODPATH -type f -name "ForceDozeController.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method private removeWhiteListAppsIfEnterForceIdle()V/,/^\.end method/d' $file
sed -i '/^\.method private restoreWhiteListAppsIfQuitForceIdle()V/,/^\.end method/d' $file
cat <<"key" >>$file
.method private removeWhiteListAppsIfEnterForceIdle()V
    .locals 1
    return-void
.end method
.method private restoreWhiteListAppsIfQuitForceIdle()V
    .locals 1
    return-void
.end method
key
done
}

function mod_cloud_control(){
echo "- 修改MIUI电量和性能云控……"
find $MODPATH -type f -name "LocalUpdateUtils.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method public static startCloudSyncData(Landroid\/content\/Context;Z)V/,/^\.end method/d' $file
cat <<"key" >>$file
.method public static startCloudSyncData(Landroid/content/Context;Z)V
    .locals 1
    return-void
.end method
key
done
}


function mod_clear_app(){
echo "- 修改息屏后台清理APP……"
find $MODPATH -type f -name "PowerStateMachine.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method private clearAppWhenScreenOffTimeOut()V/,/^\.end method/d' $file
sed -i '/^\.method private clearAppWhenScreenOffTimeOutInNight()V/,/^\.end method/d' $file
cat <<"key" >>$file
.method private clearAppWhenScreenOffTimeOutInNight()V
    .locals 1
    return-void
.end method
.method private clearAppWhenScreenOffTimeOut()V
    .locals 1
    return-void
.end method
key
done
find $MODPATH -type f -name "SleepModeControllerNew.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method private clearApp()V/,/^\.end method/d' $file
cat <<"key" >>$file
.method private clearApp()V
    .locals 1
    return-void
.end method
key
done
}


function mod_app_Frozen(){
echo "- 修改MILLET墓碑……"
find $MODPATH -type f -name "FrozenAppController.smali" 2>/dev/null | while read file ;do
sed -i '/^\.method private appIsAllowToFrozen(I)Z/,/^\.end method/d' $file
cat <<"key" >>$file
.method private appIsAllowToFrozen(I)Z
    .locals 1
    const/4 p0, 0x1
    return p0
.end method
key
done
}


unpack_miui_power && {
#全局高刷
mod_all_frame
#防止电池白名单恢复
mod_battery_recovery
#云控
mod_cloud_control
#息屏后台清理APP
mod_clear_app
#MILLET墓碑
mod_app_Frozen

echo "- 完成！"
echo "- 输出修改文件中……"
cd $MODPATH/apk
$apktool b -q -f -c $MODPATH/apk/base -o PowerKeeper.apk
echo "- 对apk文件zip对齐优化中……"
$zipalign -f 4 $MODPATH/apk/PowerKeeper.apk $MODPATH$MIUIsyspower
echo "- 修改完成！" 
echo ""
test "$(echo "${MIUIpower}" | grep '^/data' )" != "" && rm -rf "${MIUIpower%/*}"
}
