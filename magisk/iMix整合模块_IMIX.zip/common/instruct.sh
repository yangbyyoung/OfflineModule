ui_print "
  ●iMix 整合模块：
  
    此模块目前整合：
     【负优化v997 无温控：夕阳醉歌】
     【安卓UI流畅度优化：温亮平】
     【MIUI动画渲染优化：PD1587 & The Voyager】
     【清理电池优化名单：大铁 早起刷刷机】
     【移除温控：Han | 情非得已c】来自搞机助手
     【王者荣耀VT优化：Koolight&听风辰】
     【MIUI12.5精简：水宝cb】
     【Wifi Bonding - 让Wi-Fi带宽提速（高通）：simonsmh】

   感谢以上大佬的支持
  
  ●附加MMX MIUI优化模块中：
     【关闭高通wifi日志】
     【SurfaceFlinger优化】

  ●附加：
     【将 自动跳过 转为系统软件】
"
