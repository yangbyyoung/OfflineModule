# 关于Dolby杜比Dax文件
-
文件来源Redmi Note11T Pro(Pro+)
已通过美国MIT LICENCE文件认证 /项目免费授权/

# 关于音频渲染文件、Buffer破解
-
文件来源Github GNU免费授权
库文件经过GND LICENCE文件认证 /免费授权文件/

# 关于作者
-
酷安@Huber_HaYu 

#关于团队
-
酷安@Big_Chair @bug_casc @SetoSkins @shadow3 @灵聚、神生 @mly墨临渊 @中二的番茄 @big_chair @bug_casc携手调整音频参数，感谢各位的协助及支持

# 关于Huber的话
-
本人做的更多的是杜比音频参数配置，音频驱动文件也用过（用的少）
如果觉得效果还不错还希望能够得到大家的支持:)
如果觉得效果不满意可以选择等后续版本更新，我会逐渐完善音频效果:)