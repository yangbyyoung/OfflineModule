#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
find /data/data -name 'app_tbs' -type d -print -exec rm -rf {} \;
find /data/data -name 'app_tbs_64' -type d -print -exec rm -rf {} \;
  chmod 771 /data/data/com.tencent.mobileqq/app_tbs
  rm -rf /data/data/com.tencent.mobileqq/app_tbs
  mkdir /data/data/com.tencent.mobileqq/app_tbs
  chmod 000 /data/data/com.tencent.mobileqq/app_tbs
  
  chmod 771 /data/data/com.tencent.mm/app_tbs
  rm -rf /data/data/com.tencent.mm/app_tbs
  mkdir /data/data/com.tencent.mm/app_tbs
  chmod 000 /data/data/com.tencent.mm/app_tbs
  
  chmod 771 /data/data/com.tencent.mm/app_tbs_64
  rm -rf /data/data/com.tencent.mm/app_tbs_64
  mkdir /data/data/com.tencent.mm/app_tbs_64
  chmod 000 /data/data/com.tencent.mm/app_tbs_64
  
  chmod 771 /data/data/com.tencent.mobileqq/app_x5webview
  rm -rf /data/data/com.tencent.mobileqq/app_x5webview
  mkdir /data/data/com.tencent.mobileqq/app_x5webview
  chmod 000 /data/data/com.tencent.mobileqq/app_x5webview
  
  chmod 771 /data/data/com.tencent.mm/app_x5webview
  rm -rf /data/data/com.tencent.mm/app_x5webview
  mkdir /data/data/com.tencent.mm/app_x5webview
  chmod 000 /data/data/com.tencent.mm/app_x5webview
  
  chmod 771 /data/data/com.tencent.mm/app_xwalk*
  rm -rf /data/data/com.tencent.mm/app_xwalk*
  mkdir /data/data/com.tencent.mm/app_xwalk*
  chmod 000 /data/data/com.tencent.mm/app_xwalk*