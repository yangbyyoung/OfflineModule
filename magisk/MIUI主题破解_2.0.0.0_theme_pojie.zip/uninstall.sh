Android="`getprop ro.build.version.release`"
tmp_list="ThemeManager"
dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"*
done
rm -rf /data/system/package_cache/*
chattr -i /data/system/theme/rights
chmod 775 /data/system/theme
chmod 775 /data/system/theme/rights
if [ "$Android" == "11" ]; then
  rm -rf /data/app/*/com.android.thememanager*
else
  rm -rf /data/app/com.android.thememanager*
fi