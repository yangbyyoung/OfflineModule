SKIPMOUNT=false PROPFILE=false POSTFSDATA=false LATESTARTSERVICE=true
#####################################################################################
MIUI="`getprop ro.miui.ui.version.name`"
ID="`grep_prop id $TMPDIR/module.prop`"
print_modname() {
    ui_print "###############################"
    ui_print "- 模块: $MODNAME "
    ui_print "- 模块ID: $ID "
    ui_print "- 模块作者: 阿巴酱"
    ui_print "- 感谢指导: 雲迟（永远是我的导师）"
    ui_print "- 你的设备: $MIUI"    
    ui_print "- 常规精简"
    ui_print "###############################"
}
on_install() {
    if [ $MIUI = "V12" ] ; then :
    elif [ $MIUI = "V125" ] ; then : 
    else echo "- 抱歉，当前MIUI版本不支持（已支持的版本：MIUI12/12.5）" 
    rm -rf $MODPATH; rm -rf $TMPDIR; exit 1; fi
    ui_print " "
    ui_print "- 你的系统版本符合"
#####################################################################################
#不要修改到上面的内容，否则刷入失败！

#  ABajiang：
#  ● 以下精简如果有你需要用到的功能，删除对应内容即可，看下面的注释。

REPLACE="
/system/app/GFDelmarSetting
/system/priv-app/Stk1
/system/priv-app/ViPERFX
/system/product/app/PhotoTable
/system/app/BasicDreams
/system/app/ModemTestBox
/system/app/Cit
/system/app/talkback
/system/app/AntHalService
/system/product/priv-app/EmergencyInfo
/system/priv-app/MiRcs
/system/app/WMService
/system/app/WAPPushManager
/system/app/Traceur
/system/app/MiuiBugReport
/system/priv-app/MiService
/system/app/MiuiDaemon
/system/app/Userguide
/system/priv-app/UserDictionaryProvider
/system/priv-app/BlockedNumberProvider
/system/app/Stk
/system/app/SimAppDialog
/system/app/SimContact
/system/app/CatchLog
/system/app/AnalyticsCore
/system/app/MSA
/system/priv-app/NewHome
/system/app/HybridAccessory
/system/app/HybridPlatform
/system/app/goodix_sz
"

ui_print "

# ● 注释如下：
# ✔ 新增：Goodix指纹（出厂检测指纹用的，没任何影响，新路径） /system/app/GFDelmarSetting
# ✔ 新增：联发科USIM卡应用（每次开机都提醒，没啥用处又占内存）/system/priv-app/Stk1
# 乌龟rom包的蝰蛇音效（后台持续运行费电，故而关闭，如有需要请自行删除路径）/system/priv-app/ViPERFX
# 基本互动屏保（两个，无用功能，已被废除）/system/app/BasicDreams，/system/product/app/PhotoTable
# MODEM测试工具（官方维修人员专用）/system/app/ModemTestBox
# cit硬件功能检测（官方维修人员专用）/system/app/Cit
# 残疾人无障碍服务/system/app/talkback
# 天线服务/system/app/AntHalService
# 急救信息（无需用到且接口已被废除）/system/product/priv-app/EmergencyInfo
# 小米免费短信服务（大概已知是移动对移动发送短信可免费，实用性=0且特别耗电）/system/priv-app/MiRcs
# 推送服务（两个，没任何影响）/system/app/WMService，/system/app/WAPPushManager
# 系统跟踪（无关痛痒的生成systrace报告，精简可提升流畅度）/system/app/Traceur
# 用户反馈/system/app/MiuiBugReport
# 服务与反馈/system/priv-app/MiService
# 用户信息收集/system/app/MiuiDaemon
# 用户手册/system/app/Userguide
# 用户字典/system/priv-app/UserDictionaryProvider
# 存储已屏蔽的号码（无任何影响）/system/priv-app/BlockedNumberProvider
# 高通USIM卡应用（每次开机都提醒，没啥用处又占内存）/system/app/Stk
# SIM日志（无用）/system/app/SimAppDialog
# SIM联系人（现在谁还用sim卡存储联系人号码..）/system/app/SimContact
# 反馈bug时收集日志/system/app/CatchLog
# 广告组件（两个）/system/app/AnalyticsCore，/system/app/MSA
# 内容中心/system/priv-app/NewHome
# 快应用支持组件/system/app/HybridAccessory（快应用组件精简后，息屏状态下按指纹会等一秒钟左右才会出现指纹解锁图案开始解锁）
# 快应用服务框架（占后台的应用。如果还存在可以在应用商店卸载，需要用到再重装）/system/app/HybridPlatform
# Goodix指纹（出厂检测指纹用的，没任何影响）/system/app/goodix_sz

# 如果需要精简更多 请安装【额外精简】
"


}

—————————————————————————————————————————————

# ●温馨提醒：注意以下列出的千万不要精简!!否则可能卡米!!!
# SecurityCoreAdd 安全核心组件
# XiaomiServiceFramework 小米服务框架
# MiSettings 设置
# MiuiSystemUI 系统UI
# miui 系统核心组件
# Updater 系统更新
# MIUI12不能精简浏览器，MIUI12.5可以。


set_permissions() {
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  set_perm_recursive  $MODPATH  0  0  0755  0644
  ui_print " "
  sleep 0.5
  ABajiang=$MODPATH/module.prop
  time0=$(date "+%Y-%m-%d %H:%M")
  echo "- 当前时间: $time0"
  echo "$time0" >> $ABajiang
  sleep 2
#Author of this module: ABajiang
#Here is the author's cool home page, if there is a problem with the use of modules can contact the author!
  coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolmarket://u/1132618' >/dev/null 2>&1
  fi
#Please do not modify this line of code, respect the author. Thank.
}