sudo
dstPath=""
for path in "/storage/emulated/0" "/sdcard" "/mnt/sdcard" "/storage/sdcard0" "/storage/self/primary"; do
    if [ -d "$path" ]; then
        for path_game in "$path/Android/data/com.bilibili.azurlane/files" "$path/Android/data/com.bilibili.blhx.mi/files" "$path/Android/data/com.bilibili.blhx.uc/files" "$path/Android/data/com.tencent.tmgp.bilibili.blhx/files" "$path/Android/data/com.bilibili.blhx.baidu/files" "$path/Android/data/com.bilibili.blhx.dl/files" "$path/Android/data/com.bilibili.blhx.m4399/files"; do
            if [ -d "$path_game" ]; then
                dstPath="$path_game/"
                cp -Rf /data/adb/modules_update/zygisk_azurlane/zygisk/AssetBundles "$dstPath"
                
                
                echo "找到AssetBundles路径: $dstPath"
                break
            fi
        done
        break
    fi
done

if [ -z "$dstPath" ]; then
    echo "游戏路径未找到,请手动替换AssetBundles文件夹!!!"
echo "游戏路径未找到,请手动替换AssetBundles文件夹!!!"
echo "游戏路径未找到,请手动替换AssetBundles文件夹!!!"
echo "游戏路径未找到,请手动替换AssetBundles文件夹!!!"
fi
#cp -Rf /data/adb/modules_update/zygisk_azurlane/zygisk/armeabi-v7a.so /data/local/tmp/abc.so

ui_print "更新地址:https://github.com/liusj5257/azurlane_anti_name
过场图随机12张,皮肤,特触,敌我船名,誓约之戒
修改日志:
v1.0.6
修改X64模拟器调用X86模块,无需使用ADB强行安装X64版本的游戏
v1.0.5
支持逍遥x86模拟器
v1.0.4
支持夜神X86模拟器
v1.0.3
自动替换AssetBundles相关UI资源
修复对MIUI的支持,未生效重启游戏

支持以下几个包名:
"com.bilibili.azurlane"
"com.bilibili.blhx.mi"
"com.bilibili.blhx.uc"
"com.tencent.tmgp.bilibili.blhx"
"com.bilibili.blhx.baidu"
"com.bilibili.blhx.dl"
"com.bilibili.blhx.m4399"
"