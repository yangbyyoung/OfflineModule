#!/system/bin/sh

id="app_Accessibility_crond"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
file=$MODPATH/Conf/无障碍服务.conf

export PATH=/system/bin:$MODPATH/busybox:$PATH

function app_get_Accessibility() {
	local package=$1
	local package_Accessibility_cont=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g" | sort | uniq | wc -l)
	local package_Accessibility_double=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g;s/[[:space:]]//g" | sed ':a;N;$!ba;s/\n/:/g')
	local package_Accessibility=$(dumpsys package $package | grep -w "android.permission.*ACCESSIBILITY_SERVICE" | grep -E -o "($package/.*[$ ])" | sed "s/filter.*//g;s/[[:space:]]//g" | sort | uniq)
	if test $package_Accessibility_cont -gt 1; then
		echo $package_Accessibility_double
	else
		echo $package_Accessibility
	fi
}

function trimmer_file() {
	if test -e $file; then
		local trimmer=$(sed '/^[[:space:]]*$/d' $file | sort | uniq)
		echo "$trimmer" >${file}
		sed -i "1i #一行代表一个无障碍服务\n#\"/\"前面代表应用包名。" $file
	fi
}

pm list package -a | cut -d':' -f2 | while read package; do
	echo "$(app_get_Accessibility $package)" >>${file}
done

trimmer_file
