# Magisk Installer

**Update `README.md` if you want to submit your module to the online repo!**

支持更多应用的应用小窗