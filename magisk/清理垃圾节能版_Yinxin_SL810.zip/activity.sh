#!/bin/env sh

#>> 交流群组：308265111

Yixin=${0%/*}
chmod -R 755 "$Yixin"
cd "$Yixin/bin"

#Setting environment variables
export PATH="$PATH:$(magisk --path)/.magisk/busybox"

# in case of /data encryption is disabled
while [ $(getprop sys.boot_completed) != 1 ]; do
	sleep 1
done

#Run script program
awk 'BEGIN {
	i=0;
	do {
		system(" \
		[[ ! -f activity_xf.rc ]] && exit 0 \
		/system/bin/sh ./activity.sh \
		sleep 5 \
		")
		i = i + 1
	}
	while (i)
exit;
}'
