#!/system/bin/sh
echo 1 >/sys/module/ged/parameters/enable_game_self_frc_detect
echo 1 >/sys/module/ged/parameters/ged_force_mdp_enable
echo 1 >/sys/module/ged/parameters/gx_game_mode
