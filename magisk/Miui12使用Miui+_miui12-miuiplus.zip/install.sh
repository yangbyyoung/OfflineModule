SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

Start_Time=$(date "+%Y-%m-%d %H:%M:%S")
Print_Time=$(date "+%m.%d")



Ver=版本：$version，刷入时间：$Print_Time


 MODNAME="`grep_prop name $TMPDIR/module.prop`"
 MODAUTHOR="`grep_prop author $TMPDIR/module.prop`"
 MODdescription="`grep_prop description $TMPDIR/module.prop`"
 device="`getprop ro.product.system.device`"
 Version="`getprop ro.build.version.incremental`"
 Android="`getprop ro.build.version.release`"
 Sdk="`getprop ro.build.version.sdk`"
 
 ui_print "##################"
 ui_print "- 模块相关信息 -"
 ui_print "- 模块: $MODNAME"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 介绍: $MODdescription"
 ui_print "##################"
 ui_print "- 设备相关信息 -"
 ui_print "- 设备SDK: $Sdk"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- 当前版本: $Version"
 ui_print "##################"

rm -rf /data/system/package_cache/*




on_install() {
  ui_print "- 释放文件中..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644

}
