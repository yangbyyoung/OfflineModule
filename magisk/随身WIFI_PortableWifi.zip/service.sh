#!/system/bin/sh
# 不用猜测您的模块将安装在哪
# 如果您需要知道此脚本的位置，请始终使用$MODDIR设置模块
# 如果Magisk将来更改其安装点,这将确保您的模块仍能正常工作
MODDIR=${0%/*}

#延时开启
sleep 30
chmod 777 $MODDIR/PortableWifi.sh
sh -c $MODDIR/PortableWifi.sh &
