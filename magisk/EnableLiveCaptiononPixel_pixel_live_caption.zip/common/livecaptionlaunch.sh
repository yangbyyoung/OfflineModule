cd /data/adb/service.d
./livecaption.sh.x