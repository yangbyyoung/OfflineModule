#!/system/bin/sh
SYS=/system
VEN=/vendor
NVBASE=/data/adb
MOUNTEDROOT=/data/adb/modules
MODID=microG_tao
DIRSEPOL=false
SYSOVER=false
LIBDIR=/system
MAGISK=true
ROOT=
INFO=/data/adb/modules/microG_tao/microG_tao-files
﻿# This script will be executed in late_start service mode
magiskpolicy --live "﻿# Put sepolicy statements here"
