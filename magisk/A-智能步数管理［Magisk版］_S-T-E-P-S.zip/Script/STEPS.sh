#!/system/bin/sh

id="/data/adb/modules/S-T-E-P-S"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
export PATH=/system/bin:$MODPATH/busybox:$PATH
export TZ=Asia/Shanghai


#输出时间与信息
log() {
	echo "$(date '+%T'): $1" >> $2
}

#判断文件是否存在 是则打开(cat) 否则返回信息
Read() {
	[[ -f $1 ]] && cat $1
}

#配置
function settings() {
	Read $Self_definition | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

#通用路径
MODDIR=${0%/*}
MODXINXI="${MODPATH}/module.prop"
SDCARD="/sdcard/Android"
#自定义文件
Self_definition="$SDCARD/步数管理配置/设置自定义参数.conf"
#存放日志的路径
LOGPATH="$SDCARD/步数管理配置/运行日志"

#当前时间
Discharge_time="$MODDIR/tmp/time"
#计算总体时长耗时
endtime() {
	case $1 in
	1) starttime=$starttime ;;
	2) starttime=$(Read $2 | awk '{print $2}''{print $3}') ;;
	esac
	endtime=$(date "+%Y-%m-%d %H:%M:%S")
	duration=$(echo $(($(date +%s -d "${endtime}") - $(date +%s -d "${starttime}"))) | awk '{t=split("60 秒 60 分钟 24 小时 999 天",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}')
	[[ -n $duration ]] && echo "$duration" || echo "0秒"
}

#获取随机数
function rand() {
    min=$1    
    max=$(($2-$min+1))    
    #增加一个10位的数再求余
    num=$(($RANDOM+1000000000))
    echo $(($num%$max+$min))
}

###开始循环
while :;
do

	#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	#-----检测是否存在 防止误删/不存在
	#是否有模块需要的主目录
	[[ ! -d $SDCARD/步数管理配置/ ]] && mkdir -p $SDCARD/步数管理配置/
	#是否有模块需要的自定义文件
	[[ ! -e $Self_definition ]] && cp $MODDIR/设置自定义参数.conf $SDCARD/步数管理配置/
	#是否有模块存档日志的目录
	[[ ! -d $LOGPATH ]] && mkdir -p $LOGPATH
	#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	#模块的时间日志文件
	LOGTXT="$LOGPATH/$(date "+%Y-%m-%d").log"

	#是否记录日志
	case $(settings 是否保留日志) in
	y|Y|yes|YES|是|保留)
		[[ ! -f $MODDIR/tmp/log-reserve ]] && touch $MODDIR/tmp/log-reserve ;;
	n|N|no|NO|否|不保留)
		[[ -f $MODDIR/tmp/log-reserve ]] && rm -rf $MODDIR/tmp/log-reserve
		[[ ! -f $MODDIR/tmp/log-No-Reservations ]] && touch $MODDIR/tmp/log-No-Reservations
		[[ ! -f $LOGTXT ]] && rm -rf $LOGPATH/* ;;
	esac

	#检测24点过后是否重新运行
	case $(settings 24点过后是否自动重新运行) in
	n|N|no|NO|否|不运行)
		if [[ ! -f $LOGTXT ]]; then
			touch $MODDIR/tmp/stop
			sed -i "/^description=/c description=当前运行状态: Stopping 已设置24点过后不自动运行(如需运行请打开附属模块)" "$MODXINXI"
			log "Exit ! 已设置24点过后不自动运行(如需运行请打开附属模块)" "$LOGTXT"
			[[ ! -f /data/adb/$Magisk_mod/STEPS-Switch/disable ]] && touch /data/adb/$Magisk_mod/STEPS-Switch/disable
			exit 1
		fi ;;
	y|Y|yes|YES|是|运行)
		if [[ ! -f $LOGTXT ]]; then
			sed -i "/^description=/c description=当前运行状态: Running 运行中" "$MODXINXI"
			log "新的一天~" "$LOGTXT"
			log ">>开始记录今日运行状态<<" "$LOGTXT"
			[[ -f /data/adb/$Magisk_mod/STEPS-Switch/disable ]] && rm -rf /data/adb/$Magisk_mod/STEPS-Switch/disable && log "<<已重新开始运行>>" "$LOGTXT"
		fi ;;
	esac

	#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	#增加的步数
	case $(settings 随机步数) in
	n|N|no|NO|关|关闭)
		[[ ! -f $MODDIR/tmp/Fixed-steps ]] && touch $MODDIR/tmp/Fixed-steps && [[ -f $MODDIR/tmp/Random-steps ]] && rm -rf $MODDIR/tmp/Random-steps
		steps=$(settings 固定步数) ;;
	y|Y|yes|YES|开|开启)
		[[ ! -f $MODDIR/tmp/Random-steps ]] && touch $MODDIR/tmp/Random-steps && [[ -f $MODDIR/tmp/Fixed-steps ]] && rm -rf $MODDIR/tmp/Fixed-steps
		A=$(settings A随机步数)
		B=$(settings B随机步数)
		rnd=$(rand $A $B)
		steps=$rnd ;;
	esac

	current=$(date "+%Y-%m-%d") 
	#echo 时间:$current
	ss=$(date -d $current +%s)
	currentTimeStamp=$ss"000"
	string=$(content query --uri content://com.miui.providers.steps/item --projection _steps --where "_begin_time>$currentTimeStamp")
	result=$(echo $string | grep "No")

	if ((${#result}>0)); then
		print 0
	else
		array=($(echo $string | tr 'Row:  _steps=' ' ')) 
		i=0
			for var in ${array[@]}; do
			((i+=var))
			done
		len=${#array[@]}
		d=$((len*len/8-len/4))
		today_step=$((i-d))
	fi

	#步数到达多少停止运行
	if [[ $today_step -ge $(settings 步数到达多少停止运行) ]]; then
		log "Exit ! 当前:$today_step步 已达到停止运行设定值:$(settings 步数到达多少停止运行)步" "$LOGTXT"
		log "<<停止运行:达到设定值>>" "$LOGTXT"
		sed -i "/^description=/c description=当前运行状态: Stopping 已达到停止运行设定值:$(settings 步数到达多少停止运行)步 停止时步数:$today_step步" "$MODXINXI"
		touch /data/adb/$Magisk_mod/STEPS-Switch/disable
		exit 2
	fi

	if [[ -f $MODDIR/tmp/stopping-exit ]]; then
		touch /data/adb/$Magisk_mod/STEPS-Switch/disable && log "<<核心进程已终止>>" "$LOGTXT"
		exit 3
	fi

	#增加步数
	currentr=$(date "+%Y-%m-%d %H:%M:%S")
	timeStamp=$(date -d "$currentr" +%s) 
	#将current转换为时间戳，精确到毫秒  
	currentStamp=$timeStamp"000"
	string=$(content query --uri content://com.miui.providers.steps/item --projection _id --sort "_id DESC")
	array=($(echo $string | tr 'Row: _end_time, _begin_time=' ' ')) 
	id=${array[1]}
	begin=$(expr $currentStamp \- 1000)
	content insert --uri content://com.miui.providers.steps/item --bind _begin_time:s:$begin --bind _id:i:$((id+1)) --bind _end_time:s:$currentStamp --bind _mode:i:2 --bind _steps:i:$steps

	#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	#判断亮屏/息屏
	screen=$(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2)
	[[ $screen == true ]] && M="息屏" || M="亮屏"

	#输出日志
	[[ ! -e $Discharge_time ]] && echo "$(date +"%Y-%m-%d %H:%M:%S")" > $Discharge_time
	[[ -f $MODDIR/tmp/Fixed-steps ]] && log "实际步数:$today_step 经过$(endtime 2 $Discharge_time)模块为设备增加了$steps步(固定值 $M) 增加后步数：$((today_step+steps))" "$LOGTXT"
	[[ -f $MODDIR/tmp/Random-steps ]] && log "实际步数:$today_step 经过$(endtime 2 $Discharge_time)模块为设备增加了$steps步(随机$A-$B $M) 增加后步数：$((today_step+steps))" "$LOGTXT"
	echo "$(date +"%Y-%m-%d %H:%M:%S")" > $Discharge_time

	#多久循环一次
	[[ -e $Self_definition ]] && sleep $(settings 多久增加一次步数) || sleep 1m
done


