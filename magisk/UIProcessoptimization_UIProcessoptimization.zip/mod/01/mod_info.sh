mod_name="UIProcessoptimization"
mod_install_desc="UI渲染"
mod_install_info="是否安装"
mod_select_yes_text="安装"
mod_select_yes_desc="[$mod_name]"
mod_select_no_text="不安装"
MODDIR=${0%/*}
mod_install_yes() {
echo "
sleep 2s
function white()
{
  pgrep -o  -n $1 | while read pid; do
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  echo 6-7 > /dev/cpuset/restricted/cpus
  echo 4-7 > /dev/cpuset/top-app/cpus
  chmod 444 /dev/cpuset/restricted/cpus
   renice -n -18 -p $pid
  done
}

white surfaceflinger
white system_server
white android
white [kswapd0]
white com.android.touch.gestures
white [touch_wq]
white hwservicemanager
white [suspend_sync]
white [vsync_retire_wo]

su -c /data/adb/modules/UIProcessoptimization/service_*.sh

echo 成功启动  感谢使用 🤩 by Ammmmmmm 小花生 FMR 永久免费 严禁加密 禁止商用 盗版全家只有一个户口页 > /cache/magisk.log
" > $MODPATH/service.sh
    return 0
}

mod_install_no() {
    return 0
}
