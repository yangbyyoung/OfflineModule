Murong_Naiyi=${0%/*}
mount --bind $Murong_Naiyi/Murong_Naiyi.zip /system/media/bootanimation.zip
mount --bind $Murong_Naiyi/Murong_Naiyi.zip /product/media/bootanimation.zip
