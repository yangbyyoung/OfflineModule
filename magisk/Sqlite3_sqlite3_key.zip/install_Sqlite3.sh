#@coolapk 10007

id="$id"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"


if test "$(which -a sqlite3)" != "" ;then
	if test ! -d "$local_MODPATH" ;then
		abort "- 已存在sqlite3文件！| sqlite3 already installed ！"
	fi
fi


target_file="${MODPATH}/sqlite3"

if test -d /system/xbin ;then
	install_dir="/system/xbin"
elif test -d /system/bin ;then
	install_dir="/system/bin"
elif test -d /vendor/bin -o -d /system/vendor/bin ;then
	install_dir="/system/vendor/bin"
elif test -d /product/bin -o -d /system/product/bin ;then
	install_dir="/system/product/bin"
fi

if test "$install_dir" != "" ;then
	install_dir="$MODPATH/$install_dir"
	mkdir -p "${install_dir}"
	cp -rf "${target_file}" "${install_dir}/sqlite3"
else
	for i in $(echo $PATH | sed 's/:/\n/g' )
	do
		mkdir -p "$MODPATH/${i}"
		cp -rf "${target_file}" "${MODPATH}/${i}/sqlite3"
	done
		busybox="/data/adb/magisk/busybox"
	for links in $( $busybox find $MODPATH -type d -maxdepth 1 | grep -wv "system$" | grep -Ev "^$MODPATH$")
	do
	mkdir -p "$MODPATH/system"
		$busybox ln -snf "$links" "$MODPATH/system"
	done
fi

rm -rf "$target_file"
set_perm_recursive $MODPATH 0 0 0755 0755








