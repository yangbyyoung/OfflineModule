#!/system/bin/sh

source "${0%/*}/util_functions.sh"


#zygote pid1
sleep 15s
pid1="$(find_zygote)"
sleep 15s
pid2="$(find_zygote)"
sleep 15s
pid3="$(find_zygote)"


if "$(compare_value "$pid1" "$pid2")" && "$(compare_value "$pid2" "$pid3")" ;then
	if test -z "$(find_zygote)" ;then
		run_main && change_description "[E] 获取不到 zygote 的 PID ！" "[E] PID of zygote is missing!" "false" "true"
		reboot
	else
		change_description "正常启动😘！" "Normal start😘！" "true" 
		exit 0
	fi
fi

sleep 15s
pid4="$(find_zygote)"
$(compare_value "$pid3" "$pid4") && change_description "虚惊一场😱！" "False alarm😱！" "true" && exit 0

run_main && change_description "爷给你救回来了😏！" "God rescued you 😏!" "true"
reboot

