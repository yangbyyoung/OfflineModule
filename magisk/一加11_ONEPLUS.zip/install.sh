SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false
Market_Name=`getprop ro.product.marketname`
Device=`getprop ro.product.device`
Model=`getprop ro.product.model`
Version=`getprop ro.build.version.incremental`
Android=`getprop ro.build.version.release`
CPU_ABI=`getprop ro.product.cpu.abi`
print_modname() {
  ui_print "*******************************"
  ui_print " 机型修改：一加11 "
  ui_print " 模块作者：大风起兮云飞扬 "
  ui_print 
  ui_print " 相关信息："
  ui_print " 机型：$Market_Name"
  ui_print " 设备代号：$Device"
  ui_print " 认证型号：$Model"
  ui_print " 安卓版本：Android $Android"
  ui_print " 系统版本：$Version"
  ui_print " CPU架构：$CPU_ABI"
  ui_print "*******************************"
}
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
 
}