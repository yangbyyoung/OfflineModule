busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
test -e "$magiskbusybox" && {
	chmod 0777 "$magiskbusybox"
	mkdir -p "$busyboxdir"
	echo "－ 安装Magisk的busybox 中……"
	$magiskbusybox --install -s $busyboxdir && echo "－ 完成！" || abort "－ 错误！"
} || abort "－ 您的magisk busybox 怎么不见了？"

CROND_FILE=$MODPATH/keymod/task/root
if test ! -e $CROND_FILE; then
	Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
		echo "0 6,18 * * * /data/adb/$Magisk_mod/$id/keymod/task/QQMM.sh" >>$CROND_FILE
		echo "*/2 * * * * /data/adb/$Magisk_mod/$id/keymod/task/QQWEA.sh" >>$CROND_FILE
	chmod -R 777 $CROND_FILE
fi
