function key_killstop (){
	pgrep -f "$1" | while read pid ;do
	kill -19 "$pid"
done
}

function key_killwake (){
pgrep -f "$1" | while read pid ;do
kill -18 "$pid"
done
}

pross="
tcpdump
cnss_diag
charge_logger
mm-pp-dpps
"

a=0

until $(dumpsys deviceidle get screen) ;do
sleep 5
done

while :;do
for i in $pross ;do
key_killstop $i 2> /dev/null
done
a=$(($a+1))
test $a == 8 && break
done
