#!/system/bin/sh

chmod +x AutoAudio.sh

cp -f /data/adb/modules/K50G/prop/HarmanSettings/InGame/james.dsp.speaker.xml /data/data/james.dsp/shared_prefs/

mkdir -p /data/data/james.dsp/shared_prefs
sleep 0.5
if [ -d "/storage/emulated/0/Android/Hubert/AutoTap" ]; then
    ui_print "pass"
    sleep 2
    else
        am start --windowingMode 5 -n com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
        sleep 0.5
        input keyevent KEYCODE_BACK
        am start com.miui.misound/com.miui.misound.HeadsetSettingsActivity
        sleep 1
        x=914
        y=593
        input tap $x $y
        sleep 0.2
        input tap $x $y
        sleep 0.2
        input tap $x $y
        sleep 0.2
        input tap $x $y
        sleep 0.2
        input tap $x $y
        sleep 0.4
        input tap $x $y
        sleep 0.4
        x=396
        y=776
        input tap $x $y
        sleep 0.3
        x=278
        y=632
        input tap $x $y
        sleep 0.3
        input keyevent KEYCODE_BACK
        sleep 0.3
        input keyevent 25
        sleep 0.01
        input keyevent 25
        sleep 0.01
        input keyevent 25
        input keyevent 25
        input keyevent 25
        sleep 0.01
        input keyevent 25
        input keyevent 25
        input keyevent 25
        sleep 0.01
        input keyevent 25
        input keyevent 25
        input keyevent 25
        input keyevent 25
        sleep 0.01
        input keyevent 25
        input keyevent 25
        input keyevent 25
        mkdir -p /storage/emulated/0/Android/Hubert/AutoTap
fi
sleep 0.4
mkdir -p /etc/dolby
cp -f /data/adb/modules/K50G/AI_Huber/dolby/dax_default.xml /etc/dolby
# ALL CODE BY Huber_HaYu IN CoolApk
# 非开发者不要触动这里的代码！否则可能导致 严重错误/自动调谐 失效！
while true; do
    sleep 2
    
    # Games
    if [ -d "/storage/emulated/0/Android/Hubert/1" ]; then
        # Genshin Impact
        HoYoImpact=$(pidof com.miHoYo.Yuanshen)
        
        # Genshin Statt
        if [ -n "$HoYoImpact" ]; then
            sleep 1
            am start --windowingMode 5 -n james.dsp/james.dsp.activity.DSPManager
            sleep 0.6
            input keyevent KEYCODE_BACK
            rm -rf /storage/emulated/0/Android/Hubert/1
                
            else
                echo "Genshin Impact Not Found."
                sleep 0.6
        fi
        
        else
            # Impact Stop
            Impact=$(pidof com.miHoYo.Yuanshen)
            
            # Impact Test
            if [ -n "$Impact" ]; then
                echo "Impact is Running!"
                    
                else
                    JAMES=$(pidof james.dsp)
                    if [ -n "$JAMES" ]; then
                        kill $JAMES
                    fi
                    mkdir -p /storage/emulated/0/Android/Hubert/1
            fi
    fi

    if [ -d "/storage/emulated/0/Android/Hubert/2" ]; then
        # Muse Dash
        MuseDash=$(pidof com.prpr.musedash.TapTap)
        
        # Muse Go
        if [ -n "$MuseDash" ]; then
            sleep 1
            am start --windowingMode 5 -n james.dsp/james.dsp.activity.DSPManager
            sleep 0.6
            input keyevent KEYCODE_BACK
            rm -rf /storage/emulated/0/Android/Hubert/2
                
            else
                echo "Muse Dash Not Found."
                sleep 0.6
        fi
        
        else
            # Muse Dash Stop
            Muse=$(pidof com.prpr.musedash.TapTap)
            
            # Muse Test
            if [ -n "$Muse" ]; then
                echo "Muse Dash is Running!"
                    
                else
                    JAMES=$(pidof james.dsp)
                    if [ -n "$JAMES" ]; then
                        kill $JAMES
                    fi
                    mkdir -p /storage/emulated/0/Android/Hubert/2
            fi
    fi
    
    if [ -d "/storage/emulated/0/Android/Hubert/3" ]; then
        # ArkNights
        ArkNights=$(pidof com.hypergryph.arknights)
        
        # ArN Start
        if [ -n "$ArkNights" ]; then
            sleep 1
            am start --windowingMode 5 -n james.dsp/james.dsp.activity.DSPManager
            sleep 0.6
            input keyevent KEYCODE_BACK
            rm -rf /storage/emulated/0/Android/Hubert/3
                
            else
                echo "ArkNights Not Found."
                sleep 0.6
        fi
        
        else
            # hyperbryph Stop
            Ark=$(pidof com.hypergryph.arknights)
            
            # ArkNights Test
            if [ -n "$Ark" ]; then
                echo "Muse Dash is Running!"
                    
                else
                    JAMES=$(pidof james.dsp)
                    if [ -n "$JAMES" ]; then
                        kill $JAMES
                    fi
                    mkdir -p /storage/emulated/0/Android/Hubert/3
            fi
    fi    

    if [ -d "/storage/emulated/0/Android/Hubert/4" ]; then
        # Phigros
        PHI=$(pidof com.PigeonGames.Phigros)
        
        # Phigros Go
        if [ -n "$PHI" ]; then
            sleep 1
            am start --windowingMode 5 -n james.dsp/james.dsp.activity.DSPManager
            sleep 0.6
            input keyevent KEYCODE_BACK
            rm -rf /storage/emulated/0/Android/Hubert/4
                
            else
                echo "Phigros Not Found."
                sleep 0.6
        fi
        
        else
            # Phi Stop
            PhiG=$(pidof com.PigeonGames.Phigros)
            
            # Phi Test
            if [ -n "$PhiG" ]; then
                echo "Phigros is Running!"
                    
                else
                    JAMES=$(pidof james.dsp)
                    if [ -n "$JAMES" ]; then
                        kill $JAMES
                    fi
                    mkdir -p /storage/emulated/0/Android/Hubert/4
                    cp -f /data/adb/modules/K50G/prop/HarmanSettings/InGame/james.dsp.speaker.xml /data/data/james.dsp/shared_prefs/
            fi
    fi    
done