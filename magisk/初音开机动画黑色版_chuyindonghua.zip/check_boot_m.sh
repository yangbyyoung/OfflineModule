echo ""
echo "∞————————————————————————∞"
echo ""

if [[ "$bootpath" != "" ]];then
echo " -当前查找到的▲开机动画文件▲:"
for i in $bootpath;do
echo -e "\n$i"
[[ -z $i ]] && abort "－不存在支持的开机动画路径"
done
bootanimation_check=1
fi

if [[ "$bootpath_dark" != "" ]];then
echo " -当前查找到的▲开机动画文件▲:"
for i in $bootpath_dark;do
echo -e "\n$i"
[[ -z $i ]] && abort "－不存在支持的开机动画路径"
done
bootanimation_check=2
fi
echo ""
echo ""
echo "∞————————————————————————∞"