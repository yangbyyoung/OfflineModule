SKIPMOUNT=false
LATESTARTSERVICE=false

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {

  set_perm_recursive  $MODPATH  0  0  0755  0755
  
}

print_modname() {
  ui_print "一切模块均有风险，请自行承担后果"
  ui_print "********************"
  ui_print "安装完成后需要重启车机生效。注意，是重启车机，不是熄火点火，因为有的车机熄火是休眠"
  ui_print "********************"
  ui_print "模块安装完成，请立即重启车机。。。"
}