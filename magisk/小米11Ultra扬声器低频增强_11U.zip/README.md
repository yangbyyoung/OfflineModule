#此模块内音频参数来自ChatGPT初号机001

#本机型最后一个版本，详情请了解酷安@Huber_HaYu

# 关于Dolby杜比文件
-
杜比DAX/Control文件来源Xiaomi 11ULTRA官方
杜比StageFright文件来源Redmi官方，文件破解来源Huber（空文件）
已通过美国MIT LICENCE文件认证 /项目免费授权/（仅模块，非杜比）

# 关于作者
-
酷安@Huber_HaYu 

#关于音频团队
-
酷安@Big_Chair @casc @SetoSkins @shadow3 @灵聚、神生 @mly墨临渊 @中二的番茄 ChatGPT(AI)携手调整音频参数，感谢各位的协助及支持

# 关于Huber的话
-
本人做的更多的是杜比音频参数配置，音频驱动文件也用过（用的少）
如果觉得效果还不错还希望能够得到大家的支持:)