warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
sleep 7s
data=`[[ -f $warm ]] && cat $warm`
if [[ $data -le 420 ]]; then
  echo '5900000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "420" ]&&[ "$data" -lt "425" ];then
  echo '5400000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "425" ]&&[ "$data" -lt "430" ];then
  echo '5100000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "430" ]&&[ "$data" -lt "435" ];then
  echo '4800000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "435" ]&&[ "$data" -lt "440" ];then
  echo '4500000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "440" ]&&[ "$data" -lt "445" ];then
  echo '4200000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "445" ]&&[ "$data" -lt "450" ];then
  echo '3900000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "450" ]&&[ "$data" -lt "455" ];then
  echo '3200000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "455" ]&&[ "$data" -lt "460" ];then
  echo '2700000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "460" ]&&[ "$data" -lt "465" ];then
  echo '2000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "465" ]&&[ "$data" -lt "470" ];then
  echo '1500000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "470" ]&&[ "$data" -lt "475" ];then
  echo '1000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [[ "$data" -ge "475" ]];then
  echo '1000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
fi
done