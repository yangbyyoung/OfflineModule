## Litegapps
What is LiteGapps? Litegapps is a package of google applications such as Playstore, Google Play service and so on. Litegapps is made as light and minimal as possible, and with the help of Magisk it becomes systemless.
## Litegapps++ (double plus)
LiteGapps++ (Double Plus) is the development of "litegapps" which allows it to support almost all versions of android and architecture while maintaining its small size. There are also MAGISK,RECOVERY,AUTO versions available.
