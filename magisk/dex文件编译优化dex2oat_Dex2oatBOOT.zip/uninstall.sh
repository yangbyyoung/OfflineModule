#清除模块卸载残留
Package=$(pm list packages -a | grep "^package:" | cut -f2 -d ':')
for i in $Package
	do
		cmd package compile --reset $i
	done
rm -rf /data/adb/Dex2oatBOOT

