SKIPUNZIP=1
ASH_STANDALONE=1
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
dd if=$MODPATH/dtbo.img of=/dev/block/by-name/dtbo_a
dd if=$MODPATH/dtbo.img of=/dev/block/by-name/dtbo_b
cp -r /product/etc/device_features/alioth.xml $MODPATH/system/product/etc/device_features/alioth.xml
sed -i 's/support_dc_backlight">false/support_dc_backlight">true/g' $MODPATH/system/product/etc/device_features/alioth.xml
sed -i '/<item>120<\/item>/a\        <item>90</item>' $MODPATH/system/product/etc/device_features/alioth.xml
echo `getprop ro.system.build.version.incremental` >$MODPATH/version.log
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:vendor_file:s0

