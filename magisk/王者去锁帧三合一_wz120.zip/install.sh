SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
print_modname() {
  ui_print "*******************************"
  ui_print "     去除OPPO王者锁帧黑名单    "
  ui_print "   全局120帧+修改机型iQOO11   "
  ui_print "*******************************"
}
on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'my_product/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}
