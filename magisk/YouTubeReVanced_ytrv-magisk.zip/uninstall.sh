#!/system/bin/sh
{
	rm ${NVBASE}/rvhc/com.google.android.youtube_rv.apk
	rmdir ${NVBASE}/rvhc
	if  :; then
		until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 1; done
		until [ "$(getprop init.svc.bootanim)" = stopped ]; do sleep 1; done
		sleep 3
		pm uninstall com.google.android.youtube
	fi
} &
