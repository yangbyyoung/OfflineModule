#!/system/bin/sh

# Wait till device boot process completes
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

MODDIR=${0%/*}
APPNAME=$(grep description "$MODDIR"/module.prop | sed -n 's/.*=//;s/(.*//p')
PKGNAME=$(grep description "$MODDIR"/module.prop | sed -n 's/.*(//;s/).*//p')

STOCKAPPVER=$(pm dump "$PKGNAME" | sed -n '/versionName/s/.*=//p' | sed -n '1p')
RVAPPVER=$(sed -n '/version=/s/version=v//p' "$MODDIR"/module.prop)

if [ "$STOCKAPPVER" = "$RVAPPVER" ]
then
    STOCKAPK=$(pm path "$PKGNAME" | grep base | cut -d ":" -f2)
    RVAPK="$MODDIR/app/${APPNAME}Revanced-$RVAPPVER.apk"

    chmod 0644 "$RVAPK"
    chown system:system "$RVAPK"
    chcon u:object_r:apk_data_file:s0 "$RVAPK"

    mount -o bind "$RVAPK" "$STOCKAPK"
fi
"$MODDIR"/detach.sh