#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

# 开机等待时间，时间过短会导致脚本无法正确执行(即使你找到了最佳的最短时间也是建议保留部分时间加载系统资源再执行脚本)

sleep 20

# ------清理脚本------

# Magisk_该模块缓存
rm -rf /storage/emulated/0/Android/YouGod.log
rm -rf /storage/emulated/0/Android/Doze日志.txt
sleep 10
echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/YouGod.log
echo "$(date "+%Y-%m-%d %H:%M:%S") [Magisk_该模块缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log
# Magisk_该模块缓存

# Magisk日志[新旧版本路径一致]
rm -rf /cache/magisk.log
echo "$(date "+%Y-%m-%d %H:%M:%S") [Magisk日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log
# Magisk日志[新旧版本路径一致]

# 清理MIUI桌面日志-系统目录
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
# 清理MIUI桌面日志-存储目录
rm -rf /storage/emulated/0/MIUI/debug_log
echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI桌面日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log
# 清理MIUI系统日志
rm -rf /data/vendor/charge_logger
echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI系统日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 清理wlan_logs日志
rm -rf /data/vendor/wlan_logs
echo "$(date "+%Y-%m-%d %H:%M:%S") [Wlan_Logs日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log
echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/YouGod.log

# BATKILL x5 uc 缓存禁用
# 说明:原理就是去除文件夹的写入权限(chmod 000)，防删处理(chattr +i)达到禁用效果
echo "$(date "+%Y-%m-%d %H:%M:%S") [X5_UC_内核] 清理开始 " >> /storage/emulated/0/Android/YouGod.log

# 高德地图
# 垃圾文件
rm -rf /data/media/0/amap
touch /data/media/0/amap
chmod 000 /data/media/0/amap
echo "$(date "+%Y-%m-%d %H:%M:%S") [高德地图] 垃圾文件已清理" >> /storage/emulated/0/Android/YouGod.log

# 哔哩哔哩
# 日志文件
rm -rf /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
touch /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
chmod 000 /data/media/0/Android/data/tv.danmaku.bili/files/blog_v2
echo "$(date "+%Y-%m-%d %H:%M:%S") [哔哩哔哩] 日志文件已清理" >> /storage/emulated/0/Android/YouGod.log

# 铁路12306
# 启动广告
rm -rf /data/data/com.MobileTicket/databases/ads_database
rm -rf /data/data/com.MobileTicket/databases/ads_database-journal
touch /data/data/com.MobileTicket/databases/ads_database
touch /data/data/com.MobileTicket/databases/ads_database-journal
chmod 000 /data/data/com.MobileTicket/databases/ads_database
chmod 000 /data/data/com.MobileTicket/databases/ads_database-journal
echo "$(date "+%Y-%m-%d %H:%M:%S") [铁路12306] 启动广告已禁用" >> /storage/emulated/0/Android/YouGod.log

#拼多多缓存商品图片
rm -rf /data/user/0/com.xunmeng.pinduoduo/cache/image_manager_disk_cache
touch /data/user/0/com.xunmeng.pinduoduo/cache/image_manager_disk_cache
chmod 000 /data/user/0/com.xunmeng.pinduoduo/cache/image_manager_disk_cache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [拼多多] 日志文件已清理" >> /storage/emulated/0/Android/YouGod.log

# 腾讯QQ
# 日志文件
rm -rf /data/media/0/tencent/msflogs
rm -rf /data/media/0/tencent/wtlogin
rm -rf /data/media/0/tencent/wns/Logs
touch /data/media/0/tencent/msflogs
touch /data/media/0/tencent/wtlogin
touch /data/media/0/tencent/wns/Logs
chmod 000 /data/media/0/tencent/msflogs
chmod 000 /data/media/0/tencent/wtlogin
chmod 000 /data/media/0/tencent/wns/Logs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯QQ] 日志文件已清理" >> /storage/emulated/0/Android/YouGod.log

rm -rf /data/media/0/tencent/tbs
rm -rf /data/media/0/tbs
rm -rf /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
touch /data/media/0/tencent/tbs
touch /data/media/0/tbs
touch /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
chmod 000 /data/media/0/tencent/tbs
chmod 000 /data/media/0/tbs
chmod 000 /data/media/0/Android/data/com.tencent.mobileqq/files/tbslog
echo "$(date "+%Y-%m-%d %H:%M:%S") [QQ] X5内核备份和日志已清理" >> /storage/emulated/0/Android/YouGod.log

# X5内核禁用
# 腾讯网盘
rm -rf //data/data/com.qq.qcloud/app_tbs
touch //data/data/com.qq.qcloud/app_tbs
chmod 000 //data/data/com.qq.qcloud/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯网盘] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 腾讯地图
rm -rf /data/data/com.tencent.map/app_tbs
touch /data/data/com.tencent.map/app_tbs
chmod 000 /data/data/com.tencent.map/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯地图] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 腾讯QQ
rm -rf /data/data/com.tencent.mobileqq/app_tbs
touch /data/data/com.tencent.mobileqq/app_tbs
chmod 000 /data/data/com.tencent.mobileqq/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [腾讯QQ] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# QQ邮箱
rm -rf /data/data/com.tencent.androidqqmail/app_tbs
touch /data/data/com.tencent.androidqqmail/app_tbs
chmod 000 /data/data/com.tencent.androidqqmail/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [QQ邮箱] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 京喜
rm -rf /data/data/com.jd.pingou/app_tbs
touch /data/data/com.jd.pingou/app_tbs
chmod 000 /data/data/com.jd.pingou/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京喜] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 京东
rm -rf /data/data/com.jingdong.app.mall/app_tbs
touch /data/data/com.jingdong.app.mall/app_tbs
chmod 000 /data/data/com.jingdong.app.mall/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京东] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 京东极速版
rm -rf /data/data/com.jd.jdlite/app_tbs
touch /data/data/com.jd.jdlite/app_tbs
chmod 000 /data/data/com.jd.jdlite/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [京东极速版] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 歌词适配
rm -rf /data/data/com.mylrc.mymusic/app_tbs
touch /data/data/com.mylrc.mymusic/app_tbs
chmod 000 /data/data/com.mylrc.mymusic/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [歌词适配] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 哔哩哔哩
rm -rf /data/data/tv.danmaku.bili/app_tbs
touch /data/data/tv.danmaku.bili/app_tbs
chmod 000 /data/data/tv.danmaku.bili/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [哔哩哔哩] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 朴朴超市
rm -rf /data/data/com.pupumall.customer/app_tbs
touch /data/data/com.pupumall.customer/app_tbs
chmod 000 /data/data/com.pupumall.customer/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [朴朴超市] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 叮咚买菜
rm -rf /data/data/com.yaya.zone/app_tbs
touch /data/data/com.yaya.zone/app_tbs
chmod 000 /data/data/com.yaya.zone/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [叮咚买菜] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# 和彩云网盘
rm -rf /data/data/com.chinamobile.mcloud/app_tbs
touch /data/data/com.chinamobile.mcloud/app_tbs
chmod 000 /data/data/com.chinamobile.mcloud/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [和彩云网盘] X5内核已禁用" >> /storage/emulated/0/Android/YouGod.log

# UC内核禁用
# 铁路12306
rm -rf /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
rm -rf /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
touch /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
touch /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
chmod 000 /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/1647655313/12709173_315504000000/lib/libwebviewuc.so
chmod 000 /data/data/com.MobileTicket/app_h5container/uc/3.21.0.174.200825145737/so/lib/libwebviewuc.so
echo "$(date "+%Y-%m-%d %H:%M:%S") [铁路12306] UC内核已禁用" >> /storage/emulated/0/Android/YouGod.log

echo "$(date "+%Y-%m-%d %H:%M:%S") [X5_UC_内核] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/YouGod.log

# SD Maid 清理
# 路径由“SD Maid”提取
echo "$(date "+%Y-%m-%d %H:%M:%S") [SD Maid] 清理开始 " >> /storage/emulated/0/Android/YouGod.log

# 清理“应用程序无响应”事件日志
rm -rf /data/anr
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用程序无响应] 事件日志 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 清理Android系统临时文件
rm -rf /data/local/tmp
echo "$(date "+%Y-%m-%d %H:%M:%S") [Android系统临时文件] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 清理Android系统日志文件
rm -rf /data/log
rm -rf /data/logger
echo "$(date "+%Y-%m-%d %H:%M:%S") [Android系统日志文件] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# Dropbox 文件夹包含不断生成的日志文件
# 说明：logcat
rm -rf /data/system/dropbox
echo "$(date "+%Y-%m-%d %H:%M:%S") [Logcat日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 清理应用启动统计信息
# 说明：权限管理-使用分析（Google/Firebase Analytics等）
rm -rf /data/system/usagestats
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用使用分析统计信息] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 清理应用崩溃日志
rm -rf /data/tombstones
echo "$(date "+%Y-%m-%d %H:%M:%S") [应用崩溃日志] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

echo "$(date "+%Y-%m-%d %H:%M:%S") [SD Maid] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/YouGod.log

echo "$(date "+%Y-%m-%d %H:%M:%S") [微信垃圾日志_缓存] 清理开始 " >> /storage/emulated/0/Android/YouGod.log

# 开始处理根目录文件 
# 日志文件
rm -rf /data/data/com.tencent.mm/files/xlog/
rm -rf /data/media/0/tencent/MicroMsg/xlog
rm -rf /data/media/0/Android/data/com.tencent.mm/files/tbslog
rm -rf /data/data/com.tencent.mm/files/live_log/
rm -rf /data/data/com.tencent.mm/files/com.tencent.mm:tools/logging_cache/
rm -rf /data/data/com.tencent.mm/files/webnet/cacheinfo/
rm -rf /data/data/com.tencent.mm/app_appcache/
rm -rf /data/data/com.tencent.mm/cache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [日志文件] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

# 主缓存 
rm -rf /data/data/com.tencent.mm/MicroMsg/webview_tmpl/tmpls/
rm -rf /data/data/com.tencent.mm/cache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [主缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

# 插件
rm -rf /data/data/com.tencent.mm/app_xwalk_[0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z][0-9a-zA-Z]/
rm -rf /data/data/com.tencent.mm/app_xwalkplugin/
#rm -rf /data/data/com.tencent.mm/files/host/
echo "$(date "+%Y-%m-%d %H:%M:%S") [插件] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

# 视频缓存
rm -rf /storage/emulated/0/Android/data/com.tencent.mm/cache
echo "$(date "+%Y-%m-%d %H:%M:%S") [视频缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 升级缓存
rm -rf /data/media/0/tencent/MicroMsg/CheckResUpdate
echo "$(date "+%Y-%m-%d %H:%M:%S") [升级缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# 广告缓存
rm -rf /data/media/0/tencent/MicroMsg/sns_ad_landingpages
echo "$(date "+%Y-%m-%d %H:%M:%S") [广告缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# WebView缓存
rm -rf /data/data/com.tencent.mm/app_webview/GPUCache/
echo "$(date "+%Y-%m-%d %H:%M:%S") [WebView缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# TBS插件 X5内核
rm -rf /data/data/com.tencent.mm/app_tbs
echo "$(date "+%Y-%m-%d %H:%M:%S") [TBS插件 X5内核] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

# 直播
rm -rf /data/data/com.tencent.mm/files/public/live/
rm -rf /data/data/com.tencent.mm/files/public/fts/
rm -rf /data/data/com.tencent.mm/files/public/OCR
rm -rf /data/data/com.tencent.mm/files/public/cityService/
rm -rf /data/data/com.tencent.mm/files/public/tagsearch/
rm -rf /data/data/com.tencent.mm/files/public/box/
rm -rf /data/data/com.tencent.mm/files/public/CheckResUpdate/
rm -rf /data/data/com.tencent.mm/files/public/websearch/
echo "$(date "+%Y-%m-%d %H:%M:%S") [直播] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

# 开始处理内部存储目录文件
rm -rf /storage/emulated/0/tencent/micromsg/xlog/
rm -rf /storage/emulated/0/tencent/wtlogin/
rm -rf /storage/emulated/0/tencent/WeixinWork/src_log/
rm -rf /storage/emulated/0/tencent/msflogs/
rm -rf /storage/emulated/0/tencent/MicroMsg/wxanewfiles/5c1669df814221fd564749b945374831/miniprogramLog/
rm -rf /storage/emulated/0/tencent/XG/Logs/
rm -rf /storage/emulated/0/tencent/MicroMsg/7013ef886407f01edd3cb3bb5dea60a8/logcat/
rm -rf /storage/emulated/0/tencent/Wmp/com.tencent.wework/log/
rm -rf /storage/emulated/0/tencent/MobileQQ/log/
rm -rf /storage/emulated/0/tencent/tga/liveplugin/log/
rm -rf /storage/emulated/0/tencent/MicroMsg/7013ef886407f01edd3cb3bb5dea60a8/locallog/
rm -rf /storage/emulated/0/tencent/WeixinWork/gyoospb/
echo "$(date "+%Y-%m-%d %H:%M:%S") [公共目录垃圾日志_缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

sleep 5

echo "$(date "+%Y-%m-%d %H:%M:%S") [微信垃圾日志_缓存] 清理完成 " >> /storage/emulated/0/Android/YouGod.log

# ---------微信清理完成---------

# ------清理脚本------

# ------优化脚本------

echo "$(date "+%Y-%m-%d %H:%M:%S") ------------------------- " >> /storage/emulated/0/Android/YouGod.log

#酷安 官宣呐
chmod 777 /system/bin/gx0524
su -c $MODDIR/gx.sh & >/dev/null 2>&1
/sbin/magisk su -c 'sh /data/adb/modules/gx0524/IPk.sh'
/sbin/magisk su -c 'sh /data/adb/modules/gx0524/IPg.sh'

    # Chown polling nodes as needed from UI running on system server
    chmod -h 0200 /sys/devices/msm_sdcc.1/polling
    chmod -h 0200 /sys/devices/msm_sdcc.2/polling
    chmod -h 0200 /sys/devices/msm_sdcc.3/polling
    chmod -h 0200 /sys/devices/msm_sdcc.4/polling

    chown -h system.system /sys/devices/msm_sdcc.1/polling
    chown -h system.system /sys/devices/msm_sdcc.2/polling
    chown -h system.system /sys/devices/msm_sdcc.3/polling
    chown -h system.system /sys/devices/msm_sdcc.4/polling


#米柚耗电进程优化

echo "$(date "+%Y-%m-%d %H:%M:%S") [MIUI耗电进程优化] 开始 " >> /storage/emulated/0/Android/YouGod.log

# 干掉logd
if [ ! -f "/system/bin/logd" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]logd已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/YouGod.log
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在logd，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/YouGod.log
  am kill logd
  killall -9 logd
  stop logd
  rm -rf /system/bin/logd
fi

# 干掉logd.rc
if [ ! -f "/system/etc/init/logd.rc" ];then
  echo "$(date "+%Y-%m-%d %H:%M:%S") [无需优化]logd.rc已被优化，已生效，无需更改-看到我代表执行成功" >> /storage/emulated/0/Android/YouGod.log
else
  echo "$(date "+%Y-%m-%d %H:%M:%S") [执行优化]存在logd.rc，重启生效-看到我代表需要重启" >> /storage/emulated/0/Android/YouGod.log
  am kill logd.rc
  killall -9 logd.rc
  stop logd.rc
  rm -rf /system/etc/init/logd.rc
fi

echo "$(date "+%Y-%m-%d %H:%M:%S") [脚本结束] 每次重启都会生成该脚本，大概2分钟可以执行完毕！" >> /storage/emulated/0/Android/YouGod.log

done
# ------小优化脚本------
