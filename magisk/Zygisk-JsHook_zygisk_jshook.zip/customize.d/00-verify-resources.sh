ui_print "- Verify module resources"

function do_verify() {
    [ -f "$MODPATH/$1" ] || abort "! Module resource '$1' not found"

    (echo "$2  $MODPATH/$1" | sha256sum -c -s -) || abort "! Module resource '$1' verify failed"

    ui_print "  '$1' verified"
}

do_verify classes.dex 4c1ed55c41dea99e29a6440b9ba4cf75b76c0fabe4d719ad18060b861c53122a
do_verify customize.d/10-enforce-api-version.sh 2718f3493bcb01c30c770169ac88eeacfffa4bb0414813d76beb62d6854b7b6e
do_verify customize.d/11-enforce-arch.sh cb4066ff670fce4b0d4c9df752808d25c9b93e99f6d3809a16e7637308b6cb90
do_verify customize.d/20-enforce-magisk-version.sh 39c4cf061fd705ddfa9c3c473d4d506295dd2b409c933a2cd5fa46057a8bf7ef
do_verify customize.d/25-check-incompatible-module.sh 8574e539dfb713a83bedd94bb8e2187fe9fcc1e4a2c06632055925760b6f0fd2
do_verify customize.d/30-place-libraries.sh 6eb1ac5b571614f9c0a782c5daf82ff72ac8ee5b61b63855c55d3c1152071f66
do_verify customize.d/40-initialize-data-directory.sh 10bf0e0c8db05158b2a53845af4bb7a1bb24567f0a0c35b6680d0cc5b8f82e42
do_verify customize.d/90-restore-module-permission.sh 0f36308f5bd915778712ef2abd003628ea6178614a56455a8ac171f6b2a6b8cd
do_verify daemon 3ab846f2190a4528e5e7b1a42d752d712fd8873a56c8200fbc5eb41924973cd2
do_verify daemon.apk 58107adb240b9758d8d63575ec254ae27777ca3827413a22ebc966f47d557b6b
do_verify module.prop 0a08a2758a9f8dd60e4a33ade9a816abd4cbcccc0eb51d2d3ab102751c15e35c
do_verify post-fs-data.sh 324b919278869b862215c2488db55a7b4d9451d539d30ddcf42ba8f5400dbe49
do_verify service.sh 38c8926dedfec18a6ff2dbf31bfaba3c7b316b3de0720306c1e998eff9739252
do_verify uninstall.sh f7bfcf59f645b48c830b35d61dd357fccb1fb67e2fc49c11a83b2963548b73a0
do_verify zygisk/arm64-v8a.so 3f679774f5a83f5c7c9d3baf062235715b1829235623a2382a9fcb5576c2286a
do_verify zygisk/armeabi-v7a.so 3c4aa10f5fa4f29557fd7c7658546be986255bcb786aece8dd0eee9135a102cb
do_verify zygisk/x86.so 158739baafd9938a964d683152caaafd654a7b7537ec921943b07206bfc01cdc
do_verify zygisk/x86_64.so 4ab8aaa176edc2d4ce448c559ab527b9bb15a6e315d2e02f1dcc8419aba7e9e8


unset -f do_verify