#!/system/bin/sh
$MODPATH=/data/adb/modules/MCC/
#开机休眠
until [ $(getprop sys.boot_completed) == 1 ]; do
sleep 1
done

#电量和性能
pm disable com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
pm disable com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
#手机管家
pm disable com.miui.securitycenter/com.miui.permcenter.root.RootUpdateReceiver
pm disable com.miui.securitycenter/com.miui.antivirus.receiver.UpdaterReceiver
#耗电检测
pm disable com.xiaomi.powerchecker/com.xiaomi.powerchecker.cloudcontrol.CloudUpdateJobService
pm disable com.xiaomi.market/com.xiaomi.mipush.sdk.PushMessageHandler
#MIUI质量服务
pm disable com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.FileUploadService
pm disable com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
pm disable com.miui.daemon/com.miui.daemon.mqsas.jobs.EventUploadService
#joyose
pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
pm disable com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.smartp.SmartPAlarmReceiver
pm disable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm disable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm disable com.miui.securitycenter/com.miui.apppredict.service.AppPredictService
pm disable com.miui.securitycenter/com.miui.apppredict.service.AiService
pm disable com.miui.powercenter/powersaver.PerformanceModeTileService
pm disable com.miui.gamebooster/beauty.BeautyService
pm disable com.xiaomi.joyose/smartop.gamebooster.receiver.BoostRequestReceiver
pm disable com.miui.powercenter/powersaver.PerformanceModeTileService
pm disable com.miui.hybrid.settings/platform.PerformanceOptimizationActivity
pm uninstall -k --user 0 com.xiaomi.NetworkBoost
pm uninstall -k --user 0 com.miui.analytics
pm uninstall -k --user 0 com.miui.daemon

#清除数据休眠
sleep 10s
stop miuibooster
pm clear com.xiaomi.joyose
pm clear com.miui.daemon
#清除数据joyose
rm -f /data/vendor/thermal/config/*

sleep 2s

cp $MODPATH/data/vendor/thermal/config/* /data/vendor/thermal/config/

chmod 771 /data/vendor/thermal/config/*

