SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}

key_source $MODPATH/ylg.sh

key_source $MODPATH/key.sh
key_source $MODPATH/WCNSS_qcom_cfg.sh
key_source $MODPATH/features.sh
key_source $MODPATH/sed.sh

key_source $MODPATH/ylg_again.sh

. $MODPATH/service.sh
settings put global hide_error_dialogs 1
set_perm_recursive  $MODPATH  0  0  0755  0644
 