# v10.0.0 - June 24, 2023

## Anniversary Update 🎉🎉🎉

## Highlights
- Support for Gallery
- Support for Camera
- Support for Compass
- Support for Miui Backup
- Support for YellowPages
- Support for Gallery Editor
- Support for POCO Launcher
- Support for Mi Input Settings
- Support for System Apps Updater

## Other changes
- Amoled Dark Mode
- New Control Center UI
- Design improvements, updates & fixes

---

Made with ❤️