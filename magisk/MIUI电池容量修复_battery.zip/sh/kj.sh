set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

# 解除充电限制
set_value "0" /sys/class/power_supply/battery/input_current_limited

# 禁用阶梯式充电限制
set_value '0' /sys/class/power_supply/battery/step_charging_enabled