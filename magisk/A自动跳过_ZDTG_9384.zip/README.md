# Magisk Module 模板

**警告：模块id 不能包含 英文字母，数字和半角符号 之外的字符，否则模块将无法正常加载/卸载！**

**如果你想把模块上传到在线存储库,请修改 `README.md` !** 当用户点击 Magisk Manager 中的模块时，这个 "README.md" 将显示在 Webview 对话框中，所以请确保在这里放置一些信息/修改日志/注释。

如果你不熟悉 Markdown 的语法，可以从GitHub的在线 Markdown 编辑器开始，它将允许你在发布之前进行预览。 如果你需要更多帮助, [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) 将非常方便.

有关模块和存储库的更多信息，请参阅 [官方文档](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)
