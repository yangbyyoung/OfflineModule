#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

   del_fonts(){

   rm -rf $1/Mi*/ 2>/dev/null

   }

   for mods in `ls /data/adb/modules/`

   do

   del_fonts "/data/adb/modules/$mods/system/fonts"
   
   done
   
   rm -rf $MODDIR/module.prop 2>/dev/null
  
   touch $MODDIR/module.prop 2>/dev/null
  
   echo "id=MIUIFonts
  
   name=MIUI系统字体不全局生效、卡顿等问题修复模块
  
   version=V1.0
  
   versionCode=1
  
   author=数码迷（微信公众号ID：wanshuma）QQ群：773665666
  
   description=解决MIUI系统刷入Magisk字体模块不全局生效、卡顿等一系列问题，理论上支持所有MIUI11及以上系统，为防止冲突请卸载或停用其它类似的模块。" > $MODDIR/module.prop