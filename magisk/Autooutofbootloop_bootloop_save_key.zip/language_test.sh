#!/system/bin/sh

local value=$(getprop persist.sys.locale)
test "$value" = "" && value=$(getprop ro.product.locale)
if test "$(echo $value | grep -w "zh")" != "" ;then
	rm -rf $MODPATH/module.en.prop
else
	mv -f $MODPATH/module.prop "$MODPATH/module.prop.bak"
	mv -f $MODPATH/module.en.prop "$MODPATH/module.prop"
fi