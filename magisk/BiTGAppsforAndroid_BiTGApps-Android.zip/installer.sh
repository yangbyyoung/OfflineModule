# This file is part of The BiTGApps Project

# Allow mounting, when installation base is Magisk
if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
  # Mount partitions
  mount -o remount,rw,errors=continue / > /dev/null 2>&1
  mount -o remount,rw,errors=continue /dev/root > /dev/null 2>&1
  mount -o remount,rw,errors=continue /dev/block/dm-0 > /dev/null 2>&1
  mount -o remount,rw,errors=continue /system > /dev/null 2>&1
  mount -o remount,rw,errors=continue /product > /dev/null 2>&1
  mount -o remount,rw,errors=continue /system_ext > /dev/null 2>&1
  # Set installation layout
  SYSTEM="/system"
  # Backup installation layout
  SYSTEM_AS_SYSTEM="$SYSTEM"
  # System is writable
  touch $SYSTEM/.rw >/dev/null 2>&1 || exit 1
fi

# Detect whether in boot mode
[ -z $BOOTMODE ] && ps | grep zygote | grep -qv grep && BOOTMODE="true"
[ -z $BOOTMODE ] && ps -A 2>/dev/null | grep zygote | grep -qv grep && BOOTMODE="true"
[ -z $BOOTMODE ] && BOOTMODE="false"

# Strip leading directories
if [ "$BOOTMODE" = "false" ]; then
  DEST="-f5-"
else
  DEST="-f6-"
fi

# Extract utility script
if [ "$BOOTMODE" = "false" ]; then
  unzip -o "$ZIPFILE" "util_functions.sh" -d "$TMP" 2>/dev/null
fi
# Allow unpack, when installation base is Magisk
if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
  $(unzip -o "$ZIPFILE" "util_functions.sh" -d "$TMP" >/dev/null 2>&1)
fi
chmod +x "$TMP/util_functions.sh"

# Load utility functions
. $TMP/util_functions.sh

ui_print() {
  if [ "$BOOTMODE" = "true" ]; then
    echo "$1"
  fi
  if [ "$BOOTMODE" = "false" ]; then
    echo -n -e "ui_print $1\n" >> /proc/self/fd/$OUTFD
    echo -n -e "ui_print\n" >> /proc/self/fd/$OUTFD
  fi
}

print_title "BiTGApps $version Installer"

recovery_actions() {
  if [ "$BOOTMODE" = "false" ]; then
    OLD_LD_LIB=$LD_LIBRARY_PATH
    OLD_LD_PRE=$LD_PRELOAD
    OLD_LD_CFG=$LD_CONFIG_FILE
    unset LD_LIBRARY_PATH
    unset LD_PRELOAD
    unset LD_CONFIG_FILE
  fi
}

recovery_cleanup() {
  if [ "$BOOTMODE" = "false" ]; then
    [ -z $OLD_LD_LIB ] || export LD_LIBRARY_PATH=$OLD_LD_LIB
    [ -z $OLD_LD_PRE ] || export LD_PRELOAD=$OLD_LD_PRE
    [ -z $OLD_LD_CFG ] || export LD_CONFIG_FILE=$OLD_LD_CFG
  fi
}

build_defaults() {
  # Compressed Packages
  ZIP_FILE="$TMP/zip"
  # Extracted Packages
  mkdir $TMP/unzip
  # Create links
  UNZIP_DIR="$TMP/unzip"
  TMP_SYS="$UNZIP_DIR/tmp_sys"
  TMP_PRIV="$UNZIP_DIR/tmp_priv"
  TMP_PRIV_SETUP="$UNZIP_DIR/tmp_priv_setup"
  TMP_FRAMEWORK="$UNZIP_DIR/tmp_framework"
  TMP_SYSCONFIG="$UNZIP_DIR/tmp_config"
  TMP_DEFAULT="$UNZIP_DIR/tmp_default"
  TMP_PERMISSION="$UNZIP_DIR/tmp_perm"
  TMP_PREFERRED="$UNZIP_DIR/tmp_pref"
  TMP_OVERLAY="$UNZIP_DIR/tmp_overlay"
}

on_partition_check() {
  system_as_root=`getprop ro.build.system_root_image`
  slot_suffix=`getprop ro.boot.slot_suffix`
  AB_OTA_UPDATER=`getprop ro.build.ab_update`
  dynamic_partitions=`getprop ro.boot.dynamic_partitions`
}

ab_partition() {
  device_abpartition="false"
  if [ ! -z "$slot_suffix" ]; then
    device_abpartition="true"
  fi
  if [ "$AB_OTA_UPDATER" = "true" ]; then
    device_abpartition="true"
  fi
}

system_as_root() {
  SYSTEM_ROOT="false"
  if [ "$system_as_root" = "true" ]; then
    SYSTEM_ROOT="true"
  fi
}

super_partition() {
  SUPER_PARTITION="false"
  if [ "$dynamic_partitions" = "true" ]; then
    SUPER_PARTITION="true"
  fi
}

is_mounted() {
  grep -q " $(readlink -f $1) " /proc/mounts 2>/dev/null
  return $?
}

grep_cmdline() {
  local REGEX="s/^$1=//p"
  { echo $(cat /proc/cmdline)$(sed -e 's/[^"]//g' -e 's/""//g' /proc/cmdline) | xargs -n 1; \
    sed -e 's/ = /=/g' -e 's/, /,/g' -e 's/"//g' /proc/bootconfig; \
  } 2>/dev/null | sed -n "$REGEX"
}

setup_mountpoint() {
  test -L $1 && mv -f $1 ${1}_link
  if [ ! -d $1 ]; then
    rm -f $1
    mkdir $1
  fi
}

mount_apex() {
  if "$BOOTMODE"; then
    return 255
  fi
  test -d "$SYSTEM/apex" || return 1
  ui_print "- Mounting /apex"
  local apex dest loop minorx num
  setup_mountpoint /apex
  test -e /dev/block/loop1 && minorx=$(ls -l /dev/block/loop1 | awk '{ print $6 }') || minorx="1"
  num="0"
  for apex in $SYSTEM/apex/*; do
    dest=/apex/$(basename $apex | sed -E -e 's;\.apex$|\.capex$;;')
    test "$dest" = /apex/com.android.runtime.release && dest=/apex/com.android.runtime
    mkdir -p $dest
    case $apex in
      *.apex|*.capex)
        # Handle CAPEX APKs
        unzip -qo $apex original_apex -d /apex
        if [ -f "/apex/original_apex" ]; then
          apex="/apex/original_apex"
        fi
        # Handle APEX APKs
        unzip -qo $apex apex_payload.img -d /apex
        mv -f /apex/apex_payload.img $dest.img
        mount -t ext4 -o ro,noatime $dest.img $dest 2>/dev/null
        if [ $? != 0 ]; then
          while [ $num -lt 64 ]; do
            loop=/dev/block/loop$num
            (mknod $loop b 7 $((num * minorx))
            losetup $loop $dest.img) 2>/dev/null
            num=$((num + 1))
            losetup $loop | grep -q $dest.img && break
          done
          mount -t ext4 -o ro,loop,noatime $loop $dest 2>/dev/null
          if [ $? != 0 ]; then
            losetup -d $loop 2>/dev/null
          fi
        fi
      ;;
      *) mount -o bind $apex $dest;;
    esac
  done
  export ANDROID_RUNTIME_ROOT="/apex/com.android.runtime"
  export ANDROID_TZDATA_ROOT="/apex/com.android.tzdata"
  export ANDROID_ART_ROOT="/apex/com.android.art"
  export ANDROID_I18N_ROOT="/apex/com.android.i18n"
  local APEXJARS=$(find /apex -name '*.jar' | sort | tr '\n' ':')
  local FWK=$SYSTEM/framework
  export BOOTCLASSPATH="${APEXJARS}\
  $FWK/framework.jar:\
  $FWK/framework-graphics.jar:\
  $FWK/ext.jar:\
  $FWK/telephony-common.jar:\
  $FWK/voip-common.jar:\
  $FWK/ims-common.jar:\
  $FWK/framework-atb-backward-compatibility.jar:\
  $FWK/android.test.base.jar"
}

umount_apex() {
  test -d /apex || return 255
  local dest loop
  for dest in $(find /apex -type d -mindepth 1 -maxdepth 1); do
    if [ -f $dest.img ]; then
      loop=$(mount | grep $dest | cut -d" " -f1)
    fi
    (umount -l $dest
    losetup -d $loop) 2>/dev/null
  done
  rm -rf /apex 2>/dev/null
  unset ANDROID_RUNTIME_ROOT
  unset ANDROID_TZDATA_ROOT
  unset ANDROID_ART_ROOT
  unset ANDROID_I18N_ROOT
  unset BOOTCLASSPATH
}

umount_all() {
  if [ "$BOOTMODE" = "false" ]; then
    umount -l /system_root > /dev/null 2>&1
    umount -l /system > /dev/null 2>&1
    umount -l /product > /dev/null 2>&1
    umount -l /system_ext > /dev/null 2>&1
  fi
}

mount_all() {
  if "$BOOTMODE"; then
    return 255
  fi
  mount -o bind /dev/urandom /dev/random
  [ "$ANDROID_ROOT" ] || ANDROID_ROOT="/system"
  setup_mountpoint $ANDROID_ROOT
  if ! is_mounted /data; then
    mount /data
    if [ -z "$(ls -A /sdcard)" ]; then
      mount -o bind /data/media/0 /sdcard
    fi
  fi
  $SYSTEM_ROOT && ui_print "- Device is system-as-root"
  $SUPER_PARTITION && ui_print "- Super partition detected"
  # Required for System installation
  IS_MAGISK_MODULES="false" && [ -d "/data/adb/modules" ] && IS_MAGISK_MODULES="true"
  # Set recovery fstab
  [ -f "/etc/fstab" ] && cp -f '/etc/fstab' $TMP && fstab="/tmp/fstab"
  [ -f "/system/etc/fstab" ] && cp -f '/system/etc/fstab' $TMP && fstab="/tmp/fstab"
  # Check A/B slot
  [ "$slot" ] || slot=$(getprop ro.boot.slot_suffix 2>/dev/null)
  [ "$slot" ] || slot=`grep_cmdline androidboot.slot_suffix`
  [ "$slot" ] || slot=`grep_cmdline androidboot.slot`
  [ "$slot" ] && ui_print "- Current boot slot: $slot"
  if [ "$SUPER_PARTITION" = "true" ] && [ "$device_abpartition" = "true" ]; then
    unset ANDROID_ROOT && ANDROID_ROOT="/system_root" && setup_mountpoint $ANDROID_ROOT
    for block in system product system_ext; do
      for slot in "" _a _b; do
        blockdev --setrw /dev/block/mapper/$block$slot > /dev/null 2>&1
      done
    done
    ui_print "- Mounting /system"
    mount -o ro -t auto /dev/block/mapper/system$slot $ANDROID_ROOT > /dev/null 2>&1
    mount -o rw,remount -t auto /dev/block/mapper/system$slot $ANDROID_ROOT > /dev/null 2>&1
    if ! is_mounted $ANDROID_ROOT; then
      if [ "$(grep -w -o '/system_root' $fstab)" ]; then
        BLOCK=`grep -v '#' $fstab | grep -E '/system_root' | grep -oE '/dev/block/dm-[0-9]' | head -n 1`
      fi
      if [ "$(grep -w -o '/system' $fstab)" ]; then
        BLOCK=`grep -v '#' $fstab | grep -E '/system' | grep -oE '/dev/block/dm-[0-9]' | head -n 1`
      fi
      mount -o ro -t auto $BLOCK $ANDROID_ROOT > /dev/null 2>&1
      mount -o rw,remount -t auto $BLOCK $ANDROID_ROOT > /dev/null 2>&1
    fi
    is_mounted $ANDROID_ROOT || on_abort "! Cannot mount $ANDROID_ROOT"
    if [ "$(grep -w -o '/product' $fstab)" ]; then
      ui_print "- Mounting /product"
      mount -o ro -t auto /dev/block/mapper/product$slot /product > /dev/null 2>&1
      mount -o rw,remount -t auto /dev/block/mapper/product$slot /product > /dev/null 2>&1
      if ! is_mounted /product; then
        BLOCK=`grep -v '#' $fstab | grep -E '/product' | grep -oE '/dev/block/dm-[0-9]' | head -n 1`
        mount -o ro -t auto $BLOCK /product > /dev/null 2>&1
        mount -o rw,remount -t auto $BLOCK /product > /dev/null 2>&1
      fi
    fi
    if [ "$(grep -w -o '/system_ext' $fstab)" ]; then
      ui_print "- Mounting /system_ext"
      mount -o ro -t auto /dev/block/mapper/product$slot /system_ext > /dev/null 2>&1
      mount -o rw,remount -t auto /dev/block/mapper/product$slot /system_ext > /dev/null 2>&1
      if ! is_mounted /system_ext; then
        BLOCK=`grep -v '#' $fstab | grep -E '/system_ext' | grep -oE '/dev/block/dm-[0-9]' | head -n 1`
        mount -o ro -t auto $BLOCK /system_ext > /dev/null 2>&1
        mount -o rw,remount -t auto $BLOCK /system_ext > /dev/null 2>&1
      fi
    fi
  fi
  if [ "$SUPER_PARTITION" = "true" ] && [ "$device_abpartition" = "false" ]; then
    unset ANDROID_ROOT && ANDROID_ROOT="/system_root" && setup_mountpoint $ANDROID_ROOT
    for block in system product system_ext; do
      blockdev --setrw /dev/block/mapper/$block > /dev/null 2>&1
    done
    ui_print "- Mounting /system"
    mount -o ro -t auto /dev/block/mapper/system $ANDROID_ROOT > /dev/null 2>&1
    mount -o rw,remount -t auto /dev/block/mapper/system $ANDROID_ROOT > /dev/null 2>&1
    is_mounted $ANDROID_ROOT || on_abort "! Cannot mount $ANDROID_ROOT"
    if [ "$(grep -w -o '/product' $fstab)" ]; then
      ui_print "- Mounting /product"
      mount -o ro -t auto /dev/block/mapper/product /product > /dev/null 2>&1
      mount -o rw,remount -t auto /dev/block/mapper/product /product > /dev/null 2>&1
    fi
    if [ "$(grep -w -o '/system_ext' $fstab)" ]; then
      ui_print "- Mounting /system_ext"
      mount -o ro -t auto /dev/block/mapper/system_ext /system_ext > /dev/null 2>&1
      mount -o rw,remount -t auto /dev/block/mapper/system_ext /system_ext > /dev/null 2>&1
    fi
  fi
  if [ "$SUPER_PARTITION" = "false" ] && [ "$device_abpartition" = "false" ]; then
    ui_print "- Mounting /system"
    mount -o ro -t auto $ANDROID_ROOT > /dev/null 2>&1
    mount -o rw,remount -t auto $ANDROID_ROOT > /dev/null 2>&1
    if ! is_mounted $ANDROID_ROOT; then
      if [ -e "/dev/block/by-name/system" ]; then
        BLOCK="/dev/block/by-name/system"
      elif [ -e "/dev/block/bootdevice/by-name/system" ]; then
        BLOCK="/dev/block/bootdevice/by-name/system"
      elif [ -e "/dev/block/platform/*/by-name/system" ]; then
        BLOCK="/dev/block/platform/*/by-name/system"
      else
        BLOCK="/dev/block/platform/*/*/by-name/system"
      fi
      # Do not proceed without system block
      [ -z "$BLOCK" ] && on_abort "! Cannot find system block"
      # Mount using block device
      mount $BLOCK $ANDROID_ROOT > /dev/null 2>&1
    fi
    is_mounted $ANDROID_ROOT || on_abort "! Cannot mount $ANDROID_ROOT"
    if [ "$(grep -w -o '/product' $fstab)" ]; then
      ui_print "- Mounting /product"
      mount -o ro -t auto /product > /dev/null 2>&1
      mount -o rw,remount -t auto /product > /dev/null 2>&1
    fi
  fi
  if [ "$SUPER_PARTITION" = "false" ] && [ "$device_abpartition" = "true" ]; then
    ui_print "- Mounting /system"
    mount -o ro -t auto /dev/block/bootdevice/by-name/system$slot $ANDROID_ROOT > /dev/null 2>&1
    mount -o rw,remount -t auto /dev/block/bootdevice/by-name/system$slot $ANDROID_ROOT > /dev/null 2>&1
    is_mounted $ANDROID_ROOT || on_abort "! Cannot mount $ANDROID_ROOT"
    if [ "$(grep -w -o '/product' $fstab)" ]; then
      ui_print "- Mounting /product"
      mount -o ro -t auto /dev/block/bootdevice/by-name/product$slot /product > /dev/null 2>&1
      mount -o rw,remount -t auto /dev/block/bootdevice/by-name/product$slot /product > /dev/null 2>&1
    fi
  fi
  # Mount bind operation
  case $ANDROID_ROOT in
    /system_root) setup_mountpoint /system;;
    /system)
      if [ -f "/system/system/build.prop" ]; then
        setup_mountpoint /system_root
        mount --move /system /system_root
        mount -o bind /system_root/system /system
      fi
    ;;
  esac
  if is_mounted /system_root; then
    if [ -f "/system_root/build.prop" ]; then
      mount -o bind /system_root /system
    else
      mount -o bind /system_root/system /system
    fi
  fi
  # Product is a dedicated partition
  if is_mounted /product; then
    ln -sfn /product /system/product
  fi
  # Set installation layout
  SYSTEM="/system"
  # Backup installation layout
  SYSTEM_AS_SYSTEM="$SYSTEM"
  # System is writable
  if ! touch $SYSTEM/.rw >/dev/null 2>&1; then
    on_abort "! Read-only file system"
  fi
}

unmount_all() {
  if [ "$BOOTMODE" = "false" ]; then
    ui_print "- Unmounting partitions"
    umount_apex
    if [ "$(grep -w -o '/system_root' $fstab)" ]; then
      umount -l /system_root > /dev/null 2>&1
    fi
    if [ "$(grep -w -o '/system' $fstab)" ]; then
      umount -l /system > /dev/null 2>&1
    fi
    umount -l /system_root > /dev/null 2>&1
    umount -l /system > /dev/null 2>&1
    umount -l /product > /dev/null 2>&1
    umount -l /system_ext > /dev/null 2>&1
    umount -l /dev/random > /dev/null 2>&1
  fi
}

f_cleanup() { (find .$TMP -mindepth 1 -maxdepth 1 -type f -not -name 'recovery.log' -not -name 'busybox-arm' -exec rm -rf '{}' \;); }

d_cleanup() { (find .$TMP -mindepth 1 -maxdepth 1 -type d -exec rm -rf '{}' \;); }

on_abort() {
  ui_print "$*"
  unmount_all
  recovery_cleanup
  f_cleanup
  d_cleanup
  ui_print "! Installation failed"
  ui_print " "
  true
  sync
  exit 1
}

on_installed() {
  unmount_all
  recovery_cleanup
  f_cleanup
  d_cleanup
  ui_print "- Installation complete"
  ui_print " "
  true
  sync
  exit "$?"
}

sideload_config() {
  if [ "$BOOTMODE" = "false" ]; then
    unzip -o "$ZIPFILE" "bitgapps-config.prop" -d "$TMP" 2>/dev/null
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    $(unzip -o "$ZIPFILE" "bitgapps-config.prop" -d "$TMP" >/dev/null 2>&1)
  fi
}

get_bitgapps_config() {
  for d in /sdcard /sdcard1 /external_sd /usb_otg /usbstorage /data/media/0 /tmp; do
    for f in $(find $d -iname "bitgapps-config.prop" 2>/dev/null); do
      if [ -f "$f" ]; then
        BITGAPPS_CONFIG="$f"
      fi
    done
  done
}

profile() {
  SYSTEM_PROPFILE="$SYSTEM/build.prop"
  BITGAPPS_PROPFILE="$BITGAPPS_CONFIG"
}

get_file_prop() { grep -m1 "^$2=" "$1" | cut -d= -f2; }

get_prop() {
  for f in $SYSTEM_PROPFILE $BITGAPPS_PROPFILE; do
    if [ -e "$f" ]; then
      prop="$(get_file_prop "$f" "$1")"
      if [ -n "$prop" ]; then
        break
      fi
    fi
  done
  if [ -z "$prop" ]; then
    getprop "$1" | cut -c1-
  else
    printf "$prop"
  fi
}

on_systemless_check() {
  supported_module_config="false"
  if [ -f "$BITGAPPS_CONFIG" ]; then
    supported_module_config="$(get_prop "ro.config.systemless")"
  fi
}

on_setup_check() {
  supported_setup_config="false"
  if [ -f "$BITGAPPS_CONFIG" ]; then
    supported_setup_config="$(get_prop "ro.config.setupwizard")"
  fi
}

on_version_check() {
  if [ "$TARGET_ANDROID_SDK" = "32" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="32"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="12"
  fi
  if [ "$TARGET_ANDROID_SDK" = "31" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="31"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="12"
  fi
  if [ "$TARGET_ANDROID_SDK" = "30" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="30"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="11"
  fi
  if [ "$TARGET_ANDROID_SDK" = "29" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="29"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="10"
  fi
  if [ "$TARGET_ANDROID_SDK" = "28" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="28"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="9"
  fi
  if [ "$TARGET_ANDROID_SDK" = "27" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="27"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="8.1.0"
  fi
  if [ "$TARGET_ANDROID_SDK" = "26" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="26"
    android_version="$(get_prop "ro.build.version.release")" && supported_version="8.0.0"
  fi
  if [ "$TARGET_ANDROID_SDK" = "25" ]; then
    android_sdk="$(get_prop "ro.build.version.sdk")" && supported_sdk="25"
  fi
  # Instructions for Android Nougat
  if [ "$(grep -w -o "ro.build.version.release=7.1.2" $SYSTEM/build.prop)" ]; then
    android_version="$(get_prop "ro.build.version.release")" && supported_version="7.1.2"
  fi
  if [ "$(grep -w -o "ro.build.version.release=7.1.1" $SYSTEM/build.prop)" ]; then
    android_version="$(get_prop "ro.build.version.release")" && supported_version="7.1.1"
  fi
}

on_platform_check() {
  device_architecture="$(get_prop "ro.product.cpu.abi")"
}

on_target_platform() {
  ANDROID_PLATFORM_ARM32="armeabi-v7a"
  ANDROID_PLATFORM_ARM64="arm64-v8a"
}

build_platform() {
  if [ "$TARGET_ANDROID_ARCH" = "ARM" ]; then
    ANDROID_PLATFORM="$ANDROID_PLATFORM_ARM32"
  fi
  if [ "$TARGET_ANDROID_ARCH" = "ARM64" ]; then
    ANDROID_PLATFORM="$ANDROID_PLATFORM_ARM64"
  fi
}

check_sdk() {
  if [ "$android_sdk" = "$supported_sdk" ]; then
    ui_print "- Android SDK version: $android_sdk"
  else
    on_abort "! Unsupported Android SDK version"
  fi
}

check_version() {
  if [ "$android_version" = "$supported_version" ]; then
    ui_print "- Android version: $android_version"
  else
    on_abort "! Unsupported Android version"
  fi
}

check_platform() {
  for targetarch in $ANDROID_PLATFORM; do
    if [ "$device_architecture" = "$targetarch" ]; then
      ui_print "- Android platform: $device_architecture"
    else
      on_abort "! Unsupported Android platform"
    fi
  done
}

RTP_cleanup() {
  # Did this 6.0+ system already boot and generated runtime permissions
  if [ -e /data/system/users/0/runtime-permissions.xml ]; then
    # Check if permissions were granted to Google Playstore, this permissions should always be set in the file if GApps were installed before
    if ! grep -q "com.android.vending" /data/system/users/*/runtime-permissions.xml; then
      # Purge the runtime permissions to prevent issues if flashing GApps for the first time on a dirty install
      rm -rf /data/system/users/*/runtime-permissions.xml
    fi
  fi
  # Did this 11.0+ system already boot and generated runtime permissions
  RTP="$(find /data -iname "runtime-permissions.xml" 2>/dev/null)"
  if [ -e "$RTP" ]; then
    # Check if permissions were granted to Google Playstore, this permissions should always be set in the file if GApps were installed before
    if ! grep -q "com.android.vending" $RTP; then
      # Purge the runtime permissions to prevent issues if flashing GApps for the first time on a dirty install
      rm -rf "$RTP"
    fi
  fi
}

mk_component() {
  for d in \
    $UNZIP_DIR/tmp_sys \
    $UNZIP_DIR/tmp_priv \
    $UNZIP_DIR/tmp_priv_setup \
    $UNZIP_DIR/tmp_framework \
    $UNZIP_DIR/tmp_config \
    $UNZIP_DIR/tmp_default \
    $UNZIP_DIR/tmp_perm \
    $UNZIP_DIR/tmp_pref \
    $UNZIP_DIR/tmp_overlay; do
    install -d "$d"
    # Set permission recursively
    chmod -R 0755 $TMP
  done
}

system_layout() {
  if [ "$supported_module_config" = "false" ]; then
    SYSTEM_ADDOND="$SYSTEM/addon.d"
    SYSTEM_APP="$SYSTEM/app"
    SYSTEM_PRIV_APP="$SYSTEM/priv-app"
    SYSTEM_ETC_CONFIG="$SYSTEM/etc/sysconfig"
    SYSTEM_ETC_DEFAULT="$SYSTEM/etc/default-permissions"
    SYSTEM_ETC_PERM="$SYSTEM/etc/permissions"
    SYSTEM_ETC_PREF="$SYSTEM/etc/preferred-apps"
    SYSTEM_FRAMEWORK="$SYSTEM/framework"
    SYSTEM_OVERLAY="$SYSTEM/product/overlay"
  fi
}

system_module_layout() {
  if [ "$supported_module_config" = "true" ]; then
    SYSTEM_SYSTEM="$SYSTEM/system"
    SYSTEM_APP="$SYSTEM/system/app"
    SYSTEM_PRIV_APP="$SYSTEM/system/priv-app"
    SYSTEM_ETC="$SYSTEM/system/etc"
    SYSTEM_ETC_CONFIG="$SYSTEM/system/etc/sysconfig"
    SYSTEM_ETC_DEFAULT="$SYSTEM/system/etc/default-permissions"
    SYSTEM_ETC_PERM="$SYSTEM/system/etc/permissions"
    SYSTEM_ETC_PREF="$SYSTEM/system/etc/preferred-apps"
    SYSTEM_FRAMEWORK="$SYSTEM/system/framework"
    for d in \
      $SYSTEM_SYSTEM \
      $SYSTEM_APP \
      $SYSTEM_PRIV_APP \
      $SYSTEM_ETC \
      $SYSTEM_ETC_CONFIG \
      $SYSTEM_ETC_DEFAULT \
      $SYSTEM_ETC_PERM \
      $SYSTEM_ETC_PREF \
      $SYSTEM_FRAMEWORK; do
      install -d "$d" && chmod 0755 "$d"
      chcon -h u:object_r:system_file:s0 "$d"
    done
  fi
}

product_module_layout() {
  if [ "$supported_module_config" = "true" ]; then
    SYSTEM_PRODUCT="$SYSTEM/system/product"
    SYSTEM_OVERLAY="$SYSTEM/system/product/overlay"
    for d in $SYSTEM_PRODUCT $SYSTEM_OVERLAY; do
      install -d "$d" && chmod 0755 "$d"
      chcon -h u:object_r:system_file:s0 "$d"
    done
  fi
}

common_module_layout() {
  if [ "$supported_module_config" = "true" ]; then
    SYSTEM_APP="$SYSTEM/system/app"
    SYSTEM_PRIV_APP="$SYSTEM/system/priv-app"
    SYSTEM_ETC="$SYSTEM/system/etc"
    SYSTEM_ETC_CONFIG="$SYSTEM/system/etc/sysconfig"
    SYSTEM_ETC_DEFAULT="$SYSTEM/system/etc/default-permissions"
    SYSTEM_ETC_PERM="$SYSTEM/system/etc/permissions"
    SYSTEM_ETC_PREF="$SYSTEM/system/etc/preferred-apps"
    SYSTEM_FRAMEWORK="$SYSTEM/system/framework"
    SYSTEM_OVERLAY="$SYSTEM/system/product/overlay"
  fi
}

pre_installed_v25() {
  for i in ExtShared FaceLock GoogleCalendarSyncAdapter GoogleContactsSyncAdapter GoogleExtShared; do
    rm -rf $SYSTEM_APP/$i
  done
  for i in ConfigUpdater ExtServices GmsCoreSetupPrebuilt GoogleExtServices GoogleLoginService GoogleServicesFramework Phonesky PrebuiltGmsCore; do
    rm -rf $SYSTEM_PRIV_APP/$i
  done
  for i in \
    $SYSTEM_ETC_CONFIG/google.xml \
    $SYSTEM_ETC_CONFIG/google_build.xml \
    $SYSTEM_ETC_CONFIG/google_exclusives_enable.xml \
    $SYSTEM_ETC_CONFIG/google-hiddenapi-package-whitelist.xml \
    $SYSTEM_ETC_CONFIG/google-rollback-package-whitelist.xml \
    $SYSTEM_ETC_CONFIG/google-staged-installer-whitelist.xml \
    $SYSTEM_ETC_DEFAULT/default-permissions.xml \
    $SYSTEM_ETC_DEFAULT/gapps-permission.xml \
    $SYSTEM_ETC_PERM/privapp-permissions-google.xml \
    $SYSTEM_ETC_PERM/split-permissions-google.xml \
    $SYSTEM_ETC_PREF/google.xml; do
    rm -rf $i
  done
  rm -rf $SYSTEM_OVERLAY/PlayStoreOverlay.apk
}

pkg_TMPSys() {
  file_list="$(find "$TMP_SYS/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_SYS/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_SYS/${file}" "$SYSTEM_APP/${file}"
    chmod 0644 "$SYSTEM_APP/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_APP/${dir}"
  done
}

pkg_TMPPriv() {
  file_list="$(find "$TMP_PRIV/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_PRIV/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_PRIV/${file}" "$SYSTEM_PRIV_APP/${file}"
    chmod 0644 "$SYSTEM_PRIV_APP/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_PRIV_APP/${dir}"
  done
}

pkg_TMPSetup() {
  file_list="$(find "$TMP_PRIV_SETUP/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_PRIV_SETUP/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_PRIV_SETUP/${file}" "$SYSTEM_PRIV_APP/${file}"
    chmod 0644 "$SYSTEM_PRIV_APP/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_PRIV_APP/${dir}"
  done
}

pkg_TMPFramework() {
  file_list="$(find "$TMP_FRAMEWORK/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_FRAMEWORK/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_FRAMEWORK/${file}" "$SYSTEM_FRAMEWORK/${file}"
    chmod 0644 "$SYSTEM_FRAMEWORK/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_FRAMEWORK/${dir}"
  done
}

pkg_TMPConfig() {
  file_list="$(find "$TMP_SYSCONFIG/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_SYSCONFIG/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_SYSCONFIG/${file}" "$SYSTEM_ETC_CONFIG/${file}"
    chmod 0644 "$SYSTEM_ETC_CONFIG/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_ETC_CONFIG/${dir}"
  done
}

pkg_TMPDefault() {
  file_list="$(find "$TMP_DEFAULT/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_DEFAULT/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_DEFAULT/${file}" "$SYSTEM_ETC_DEFAULT/${file}"
    chmod 0644 "$SYSTEM_ETC_DEFAULT/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_ETC_DEFAULT/${dir}"
  done
  # Exception permission is limited to Android Q
  if [ "$android_sdk" != "29" ]; then
    rm -rf $SYSTEM_ETC_DEFAULT/gapps-permission.xml
  fi
}

pkg_TMPPref() {
  file_list="$(find "$TMP_PREFERRED/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_PREFERRED/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_PREFERRED/${file}" "$SYSTEM_ETC_PREF/${file}"
    chmod 0644 "$SYSTEM_ETC_PREF/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_ETC_PREF/${dir}"
  done
}

pkg_TMPPerm() {
  file_list="$(find "$TMP_PERMISSION/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_PERMISSION/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_PERMISSION/${file}" "$SYSTEM_ETC_PERM/${file}"
    chmod 0644 "$SYSTEM_ETC_PERM/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_ETC_PERM/${dir}"
  done
}

pkg_TMPOverlay() {
  file_list="$(find "$TMP_OVERLAY/" -mindepth 1 -type f | cut -d/ ${DEST})"
  dir_list="$(find "$TMP_OVERLAY/" -mindepth 1 -type d | cut -d/ ${DEST})"
  for file in $file_list; do
    install -D "$TMP_OVERLAY/${file}" "$SYSTEM_OVERLAY/${file}"
    chmod 0644 "$SYSTEM_OVERLAY/${file}"
  done
  for dir in $dir_list; do
    chmod 0755 "$SYSTEM_OVERLAY/${dir}"
  done
}

sdk_v25_install() {
  ui_print "- Installing GApps"
  ZIP="zip/core/ConfigUpdater.tar.xz
       zip/core/GmsCoreSetupPrebuilt.tar.xz
       zip/core/GoogleExtServices.tar.xz
       zip/core/GoogleLoginService.tar.xz
       zip/core/GoogleServicesFramework.tar.xz
       zip/core/Phonesky.tar.xz
       zip/core/PrebuiltGmsCore.tar.xz
       zip/sys/FaceLock.tar.xz
       zip/sys/GoogleCalendarSyncAdapter.tar.xz
       zip/sys/GoogleContactsSyncAdapter.tar.xz
       zip/sys/GoogleExtShared.tar.xz
       zip/Sysconfig.tar.xz
       zip/Default.tar.xz
       zip/Permissions.tar.xz
       zip/Preferred.tar.xz
       zip/overlay/PlayStoreOverlay.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  tar -xf $ZIP_FILE/sys/FaceLock.tar.xz -C $TMP_SYS 2>/dev/null
  tar -xf $ZIP_FILE/sys/GoogleCalendarSyncAdapter.tar.xz -C $TMP_SYS
  tar -xf $ZIP_FILE/sys/GoogleContactsSyncAdapter.tar.xz -C $TMP_SYS
  tar -xf $ZIP_FILE/sys/GoogleExtShared.tar.xz -C $TMP_SYS
  tar -xf $ZIP_FILE/core/ConfigUpdater.tar.xz -C $TMP_PRIV
  tar -xf $ZIP_FILE/core/GmsCoreSetupPrebuilt.tar.xz -C $TMP_PRIV 2>/dev/null
  tar -xf $ZIP_FILE/core/GoogleExtServices.tar.xz -C $TMP_PRIV
  tar -xf $ZIP_FILE/core/GoogleLoginService.tar.xz -C $TMP_PRIV 2>/dev/null
  tar -xf $ZIP_FILE/core/GoogleServicesFramework.tar.xz -C $TMP_PRIV
  tar -xf $ZIP_FILE/core/Phonesky.tar.xz -C $TMP_PRIV
  tar -xf $ZIP_FILE/core/PrebuiltGmsCore.tar.xz -C $TMP_PRIV
  tar -xf $ZIP_FILE/Sysconfig.tar.xz -C $TMP_SYSCONFIG
  tar -xf $ZIP_FILE/Default.tar.xz -C $TMP_DEFAULT
  tar -xf $ZIP_FILE/Permissions.tar.xz -C $TMP_PERMISSION
  tar -xf $ZIP_FILE/Preferred.tar.xz -C $TMP_PREFERRED
  tar -xf $ZIP_FILE/overlay/PlayStoreOverlay.tar.xz -C $TMP_OVERLAY 2>/dev/null
  pkg_TMPSys
  pkg_TMPPriv
  pkg_TMPConfig
  pkg_TMPDefault
  pkg_TMPPref
  pkg_TMPPerm
  pkg_TMPOverlay
}

dialer_config() {
  ZIP="zip/framework/DialerPermissions.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  tar -xf $ZIP_FILE/framework/DialerPermissions.tar.xz -C $TMP_PERMISSION
  pkg_TMPPerm
  chcon -h u:object_r:system_file:s0 "$SYSTEM_ETC_PERM/com.google.android.dialer.framework.xml"
  chcon -h u:object_r:system_file:s0 "$SYSTEM_ETC_PERM/com.google.android.dialer.support.xml"
}

dialer_framework() {
  ZIP="zip/framework/DialerFramework.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  tar -xf $ZIP_FILE/framework/DialerFramework.tar.xz -C $TMP_FRAMEWORK
  pkg_TMPFramework
  chcon -h u:object_r:system_file:s0 "$SYSTEM_FRAMEWORK/com.google.android.dialer.support.jar"
}

maps_config() {
  ZIP="zip/framework/MapsPermissions.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  tar -xf $ZIP_FILE/framework/MapsPermissions.tar.xz -C $TMP_PERMISSION
  pkg_TMPPerm
  chcon -h u:object_r:system_file:s0 "$SYSTEM_ETC_PERM/com.google.android.maps.xml"
}

maps_framework() {
  ZIP="zip/framework/MapsFramework.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  tar -xf $ZIP_FILE/framework/MapsFramework.tar.xz -C $TMP_FRAMEWORK
  pkg_TMPFramework
  chcon -h u:object_r:system_file:s0 "$SYSTEM_FRAMEWORK/com.google.android.maps.jar"
}

backup_script() {
  if [ -d "$SYSTEM_ADDOND" ] && [ "$supported_module_config" = "false" ]; then
    ui_print "- Installing OTA survival script"
    ADDOND="70-bitgapps.sh"
    if [ "$BOOTMODE" = "false" ]; then
      unzip -o "$ZIPFILE" "$ADDOND" -d "$TMP"
    fi
    # Allow unpack, when installation base is Magisk
    if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
      $(unzip -o "$ZIPFILE" "$ADDOND" -d "$TMP" >/dev/null 2>&1)
    fi
    # Install OTA survival script
    rm -rf $SYSTEM_ADDOND/$ADDOND
    cp -f $TMP/$ADDOND $SYSTEM_ADDOND/$ADDOND
    chmod 0755 $SYSTEM_ADDOND/$ADDOND
    chcon -h u:object_r:system_file:s0 "$SYSTEM_ADDOND/$ADDOND"
    # Allow SetupWizard to survive OTA upgrade
    sed -i -e 's/setup_config="false"/setup_config="true"/g' $SYSTEM_ADDOND/$ADDOND
  fi
}

get_setup_config() {
  if [ "$supported_module_config" = "false" ]; then
    for i in AndroidMigratePrebuilt GoogleBackupTransport GoogleRestore SetupWizard*; do
      rm -rf $SYSTEM/app/$i $SYSTEM/priv-app/$i
      rm -rf $SYSTEM/product/app/$i $SYSTEM/product/priv-app/$i
      rm -rf $SYSTEM/system_ext/app/$i $SYSTEM/system_ext/priv-app/$i
    done
    for i in ManagedProvisioning Provision LineageSetupWizard; do
      rm -rf $SYSTEM/app/$i $SYSTEM/priv-app/$i
      rm -rf $SYSTEM/product/app/$i $SYSTEM/product/priv-app/$i
      rm -rf $SYSTEM/system_ext/app/$i $SYSTEM/system_ext/priv-app/$i
    done
    for i in $SYSTEM/etc/permissions $SYSTEM/product/etc/permissions $SYSTEM/system_ext/etc/permissions; do
      rm -rf $i/com.android.managedprovisioning.xml $i/com.android.provision.xml
    done
  fi
  if [ "$supported_module_config" = "true" ]; then
    for i in ManagedProvisioning Provision LineageSetupWizard; do
      mkdir $SYSTEM_SYSTEM/app/$i $SYSTEM_SYSTEM/priv-app/$i
      mkdir $SYSTEM_SYSTEM/product/app/$i $SYSTEM_SYSTEM/product/priv-app/$i
      mkdir $SYSTEM_SYSTEM/system_ext/app/$i $SYSTEM_SYSTEM/system_ext/priv-app/$i
      touch $SYSTEM_SYSTEM/app/$i/.replace $SYSTEM_SYSTEM/priv-app/$i/.replace
      touch $SYSTEM_SYSTEM/product/app/$i/.replace $SYSTEM_SYSTEM/product/priv-app/$i/.replace
      touch $SYSTEM_SYSTEM/system_ext/app/$i/.replace $SYSTEM_SYSTEM/system_ext/priv-app/$i/.replace
    done
    for i in $SYSTEM_SYSTEM/etc/permissions $SYSTEM_SYSTEM/product/etc/permissions $SYSTEM_SYSTEM/system_ext/etc/permissions; do
      touch $i/com.android.managedprovisioning.xml $i/com.android.provision.xml
    done
  fi
  ZIP="zip/core/GoogleBackupTransport.tar.xz zip/core/GoogleRestore.tar.xz zip/core/SetupWizardPrebuilt.tar.xz"
  if [ "$BOOTMODE" = "false" ]; then
    for f in $ZIP; do unzip -o "$ZIPFILE" "$f" -d "$TMP"; done
  fi
  # Allow unpack, when installation base is Magisk
  if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
    for f in $ZIP; do $(unzip -o "$ZIPFILE" "$f" -d "$TMP" >/dev/null 2>&1); done
  fi
  if [ -f "$ZIP_FILE/core/GoogleBackupTransport.tar.xz" ]; then
    tar -xf $ZIP_FILE/core/GoogleBackupTransport.tar.xz -C $TMP_PRIV_SETUP
  fi
  if [ -f "$ZIP_FILE/core/GoogleRestore.tar.xz" ]; then
    tar -xf $ZIP_FILE/core/GoogleRestore.tar.xz -C $TMP_PRIV_SETUP
  fi
  tar -xf $ZIP_FILE/core/SetupWizardPrebuilt.tar.xz -C $TMP_PRIV_SETUP
  pkg_TMPSetup
}

on_setup_install() {
  if [ "$supported_setup_config" = "true" ]; then
    ui_print "- Installing SetupWizard"
    get_setup_config
  fi
}

get_flags() {
  DATA="false"
  DATA_DE="false"
  if grep ' /data ' /proc/mounts | grep -vq 'tmpfs'; then
    # Data is writable
    touch /data/.rw && rm /data/.rw && DATA="true"
    # Data is decrypted
    if [[ "$DATA" ]] && [ -d "/data/system" ]; then
      touch /data/system/.rw && rm /data/system/.rw && DATA_DE="true"
    fi
  fi
  if [ -z $KEEPFORCEENCRYPT ]; then
    # No data access means unable to decrypt in recovery
    if { ! $DATA && ! $DATA_DE; }; then
      KEEPFORCEENCRYPT="true"
    else
      KEEPFORCEENCRYPT="false"
    fi
  fi
  if [ "$KEEPFORCEENCRYPT" = "true" ]; then
    on_abort "! Encrypted data partition"
  fi
}

is_encrypted_data() {
  case $supported_module_config in
    "true" )
      ui_print "- Systemless installation"
      get_flags
      ;;
    "false" )
      return 0
      ;;
  esac
}

require_new_magisk() {
  if "$supported_module_config"; then
    if [ ! -f "/data/adb/magisk/util_functions.sh" ]; then
      on_abort "! Please install Magisk v20.4+"
    fi
    # Do not source utility functions
    if [ -f "/data/adb/magisk/util_functions.sh" ]; then
      UF="/data/adb/magisk/util_functions.sh"
      grep -w 'MAGISK_VER_CODE' $UF >> $TMP/VER_CODE
      chmod 0755 $TMP/VER_CODE && . $TMP/VER_CODE
      if [ "$MAGISK_VER_CODE" -lt "20400" ]; then
        on_abort "! Please install Magisk v20.4+"
      fi
    fi
    # Magisk Require Additional Setup
    if [ ! -d "/data/adb/modules" ]; then
      on_abort "! Please install Magisk v20.4+"
    fi
  fi
}

set_bitgapps_module() {
  case $supported_module_config in
    "false" )
      # Required for System installation
      $IS_MAGISK_MODULES || return 255
      ;;
  esac
  # Always override previous installation
  rm -rf /data/adb/modules/BiTGApps
  mkdir /data/adb/modules/BiTGApps
  chmod 0755 /data/adb/modules/BiTGApps
}

set_module_layout() {
  if [ "$supported_module_config" = "true" ]; then
    SYSTEM="/data/adb/modules/BiTGApps"
    # Override update information
    rm -rf $SYSTEM/module.prop
  fi
  if [ "$supported_module_config" = "false" ]; then
    MODULE="/data/adb/modules/BiTGApps"
    # Override update information
    rm -rf $MODULE/module.prop
  fi
}

override_module() {
  if [ "$supported_module_config" = "true" ]; then
    mkdir $SYSTEM_SYSTEM/app/ExtShared
    mkdir $SYSTEM_SYSTEM/priv-app/ExtServices
    touch $SYSTEM_SYSTEM/app/ExtShared/.replace
    touch $SYSTEM_SYSTEM/priv-app/ExtServices/.replace
  fi
}

fix_gms_hide() {
  if [ "$supported_module_config" = "true" ]; then
    mount -o remount,rw,errors=continue $SYSTEM_AS_SYSTEM/priv-app/PrebuiltGmsCore 2>/dev/null
    umount -l $SYSTEM_AS_SYSTEM/priv-app/PrebuiltGmsCore 2>/dev/null
    rm -rf $SYSTEM_AS_SYSTEM/priv-app/PrebuiltGmsCore 2>/dev/null
    mv -f $SYSTEM_SYSTEM/priv-app/PrebuiltGmsCore $SYSTEM_AS_SYSTEM/priv-app 2>/dev/null
  fi
}

fix_module_perm() {
  if [ "$supported_module_config" = "true" ]; then
    for i in $SYSTEM_SYSTEM/app $SYSTEM_SYSTEM/priv-app; do
      (chmod 0755 $i/*) 2>/dev/null
      (chmod 0644 $i/*/.replace) 2>/dev/null
    done
    for i in $SYSTEM_SYSTEM/etc/default-permissions $SYSTEM_SYSTEM/etc/permissions $SYSTEM_SYSTEM/etc/preferred-apps $SYSTEM_SYSTEM/etc/sysconfig; do
      (chmod 0644 $i/*) 2>/dev/null
    done
  fi
}

module_platform() {
  if [ "$TARGET_ANDROID_ARCH" = "ARM" ]; then
    MODULE_PLATFORM="arm"
  fi
  if [ "$TARGET_ANDROID_ARCH" = "ARM64" ]; then
    MODULE_PLATFORM="arm64"
  fi
}

module_Json() {
  case $TARGET_ANDROID_SDK in
    "32" )
      MODULE_URL='https://raw.githubusercontent.com/BiTGApps/Module/master'
      MODULE_JSN="${MODULE_PLATFORM}/${TARGET_ANDROID_SDK}/module.json"
      ;;
  esac
}

module_info() {
  case $TARGET_ANDROID_SDK in
    "25" | "26" | "27" | "28" | "29" | "30" | "31" )
      return 255
      ;;
  esac
  if [ "$supported_module_config" = "true" ]; then
    echo -e "id=BiTGApps-Android" >> $SYSTEM/module.prop
    echo -e "name=BiTGApps for Android" >> $SYSTEM/module.prop
    echo -e "version=$version" >> $SYSTEM/module.prop
    echo -e "versionCode=$versionCode" >> $SYSTEM/module.prop
    echo -e "author=TheHitMan7" >> $SYSTEM/module.prop
    echo -e "description=Custom Google Apps Project" >> $SYSTEM/module.prop
    echo -e "updateJson=${MODULE_URL}/${MODULE_JSN}" >> $SYSTEM/module.prop
    # Set permission
    chmod 0644 $SYSTEM/module.prop
  fi
}

system_info() {
  case $TARGET_ANDROID_SDK in
    "25" | "26" | "27" | "28" | "29" | "30" | "31" )
      return 255
      ;;
  esac
  if [ "$supported_module_config" = "false" ] && $IS_MAGISK_MODULES; then
    echo -e "id=BiTGApps-Android" >> $MODULE/module.prop
    echo -e "name=BiTGApps for Android" >> $MODULE/module.prop
    echo -e "version=$version" >> $MODULE/module.prop
    echo -e "versionCode=$versionCode" >> $MODULE/module.prop
    echo -e "author=TheHitMan7" >> $MODULE/module.prop
    echo -e "description=Custom Google Apps Project" >> $MODULE/module.prop
    echo -e "updateJson=${MODULE_URL}/${MODULE_JSN}" >> $MODULE/module.prop
    # Set permission
    chmod 0644 $MODULE/module.prop
  fi
}

module_probe() {
  if [ "$supported_module_config" = "true" ] && [ -d "/data/adb/service.d" ]; then
    if [ "$BOOTMODE" = "false" ]; then
      unzip -o "$ZIPFILE" "modprobe.sh" -d "$TMP"
    fi
    # Allow unpack, when installation base is Magisk
    if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
      $(unzip -o "$ZIPFILE" "modprobe.sh" -d "$TMP" >/dev/null 2>&1)
    fi
    # Install module service
    rm -rf /data/adb/service.d/modprobe.sh
    cp -f $TMP/modprobe.sh /data/adb/service.d/modprobe.sh
    chmod 0755 /data/adb/service.d/modprobe.sh
    chcon -h u:object_r:adb_data_file:s0 "/data/adb/service.d/modprobe.sh"
    # Update file GROUP
    chown -h root:shell /data/adb/service.d/modprobe.sh
  fi
}

module_service() {
  if [ "$supported_module_config" = "true" ] && [ -d "/data/adb/post-fs-data.d" ]; then
    if [ "$BOOTMODE" = "false" ]; then
      unzip -o "$ZIPFILE" "service.sh" -d "$TMP"
    fi
    # Allow unpack, when installation base is Magisk
    if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
      $(unzip -o "$ZIPFILE" "service.sh" -d "$TMP" >/dev/null 2>&1)
    fi
    # Install module service
    rm -rf /data/adb/post-fs-data.d/service.sh
    cp -f $TMP/service.sh /data/adb/post-fs-data.d/service.sh
    chmod 0755 /data/adb/post-fs-data.d/service.sh
    chcon -h u:object_r:adb_data_file:s0 "/data/adb/post-fs-data.d/service.sh"
    # Update file GROUP
    chown -h root:shell /data/adb/post-fs-data.d/service.sh
  fi
}

module_cleanup() {
  if [ "$supported_module_config" = "true" ]; then
    if [ "$BOOTMODE" = "false" ]; then
      unzip -o "$ZIPFILE" "uninstall.sh" -d "$TMP"
    fi
    # Allow unpack, when installation base is Magisk
    if [[ "$(getprop "sys.bootmode")" = "2" ]]; then
      $(unzip -o "$ZIPFILE" "uninstall.sh" -d "$TMP" >/dev/null 2>&1)
    fi
    # Module uninstall script
    rm -rf $SYSTEM/uninstall.sh
    cp -f $TMP/uninstall.sh $SYSTEM/uninstall.sh
    chmod 0755 $SYSTEM/uninstall.sh
    chcon -h u:object_r:system_file:s0 "$SYSTEM/uninstall.sh"
  fi
}

pre_install() {
  umount_all
  recovery_actions
  on_partition_check
  ab_partition
  system_as_root
  super_partition
  mount_all
  mount_apex
  sideload_config
  get_bitgapps_config
  profile
  on_version_check
  check_sdk
  check_version
  on_platform_check
  on_target_platform
  build_platform
  check_platform
  RTP_cleanup
  on_systemless_check
}

df_partition() {
  # Get the available space left on the device
  size=`df -k $ANDROID_ROOT | tail -n 1 | tr -s ' ' | cut -d' ' -f4`
  # Disk space in human readable format (k=1024)
  ds_hr=`df -h $ANDROID_ROOT | tail -n 1 | tr -s ' ' | cut -d' ' -f4`
  # Common target
  CAPACITY="$CAPACITY"
  # Print partition type
  partition="System"
}

df_checker() {
  if [ "$size" -gt "$CAPACITY" ]; then
    ui_print "- ${partition} Space: $ds_hr"
  else
    ui_print "! Insufficient space in ${partition}"
    on_abort "! Current space: $ds_hr"
  fi
}

post_install() {
  df_partition
  df_checker
  build_defaults
  mk_component
  system_layout
  is_encrypted_data
  require_new_magisk
  set_bitgapps_module
  set_module_layout
  system_module_layout
  product_module_layout
  common_module_layout
  pre_installed_v25
  sdk_v25_install
  on_setup_check
  on_setup_install
  backup_script
  override_module
  fix_gms_hide
  fix_module_perm
  dialer_config
  dialer_framework
  maps_config
  maps_framework
  module_platform
  module_Json
  module_info
  system_info
  module_probe
  module_service
  module_cleanup
  on_installed
}

# Begin installation
{
  pre_install
  post_install
}
# End installation

# End method
