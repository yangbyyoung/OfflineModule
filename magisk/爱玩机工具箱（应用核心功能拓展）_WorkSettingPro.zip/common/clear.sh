sleep 45
#rm -rf /data/anr/*
rm -rf /data/local/cache/*
#rm -rf /data/system/dropbox/*
#rm -rf /data/anr/*
