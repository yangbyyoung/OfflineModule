#!/system/bin/sh

rm -rf /data/adb/accurate_battery
