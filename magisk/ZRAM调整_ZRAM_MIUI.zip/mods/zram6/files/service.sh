#!/system/bin/sh
MODDIR=${0%/*}
sleep 10
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 4G > /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0