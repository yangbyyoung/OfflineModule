MODDIR=${0%/*}
while [ $(getprop sys.boot_completed) -ne 1 ] || [ "$(getprop init.svc.bootanim | tr '[:upper:]' '[:lower:]')" != "stopped" ]; do
  sleep 1
done
if [ ! -f "$MODDIR/switch.conf" ]; then
  sed -i "/^description=/c description=[ Error! ️]️ switch.conf does not exist, please reinstall this module." "$MODDIR/module.prop"
  exit
fi
if [ ! -f "$MODDIR/config.conf" ]; then
  sed -i "/^description=/c description=[ Error! ️]️ config.conf does not exist, please reinstall this module." "$MODDIR/module.prop"
  exit
fi
switch_conf="$(cat "$MODDIR/switch.conf" | egrep -v '^#')"
charging_control_file="$(echo "$switch_conf" | egrep '^charging_control_file=' | sed -n 's/charging_control_file=//g;$p')"
start_charging_flag="$(echo "$switch_conf" | egrep '^start_charging_flag=' | sed -n 's/start_charging_flag=//g;$p')"
stop_charging_flag="$(echo "$switch_conf" | egrep '^stop_charging_flag=' | sed -n 's/stop_charging_flag=//g;$p')"
config_conf="$(cat "$MODDIR/config.conf" | egrep -v '^#')"
charge_stop="$(echo "$config_conf" | egrep '^charge_stop=' | sed -n 's/charge_stop=//g;$p')"
charge_start="$(echo "$config_conf" | egrep '^charge_start=' | sed -n 's/charge_start=//g;$p')"
time_before_charge_stop="$(echo "$config_conf" | egrep '^time_before_charge_stop=' | sed -n 's/time_before_charge_stop=//g;$p')"
chmod 0644 $charging_control_file
sed -i "/^description=/c description=[ The module is running ] Stop charging when the power of the device is the specified value, and resume charging when the power of the device is less than or equal to the specified value." "$MODDIR/module.prop"
while :; do
dumpsys_battery="$(dumpsys battery)"
battery_level="$(echo "$dumpsys_battery" | egrep 'level: ' | sed -n 's/.*level: //g;$p')"
input_suspend="$(cat "$charging_control_file")"
if [ "$battery_level" -ge "$charge_stop" ]; then
  if [ "$input_suspend" -ne "$stop_charging_flag" ]; then
    sleep $time_before_charge_stop
	echo $stop_charging_flag > $charging_control_file
	sed -i "/^description=/c description=[ Charging stopped ] Stop charging when the power of the device is the specified value, and resume charging when the power of the device is less than or equal to the specified value." "$MODDIR/module.prop"
	sleep 10s
  fi
elif [ "$battery_level" -le "$charge_start" ]; then
  if [ "$input_suspend" -ne "$start_charging_flag" ]; then
	echo $start_charging_flag > $charging_control_file
	sed -i "/^description=/c description=[ Charging resumed ] Stop charging when the power of the device is the specified value, and resume charging when the power of the device is less than or equal to the specified value." "$MODDIR/module.prop"
	sleep 10s
  fi
fi
sleep 10s
done