# ZRAM分区参数调整
echo "128" > /sys/block/zram0/queue/read_ahead_kb
echo "36" > /sys/block/zram0/queue/nr_requests

# 调整虚拟空间页面集群
echo "0" > /proc/sys/vm/page-cluster