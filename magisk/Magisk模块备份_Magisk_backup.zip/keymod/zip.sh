
MODPATH="/data/adb/modules/Magisk_backup"
timetablefile="$MODPATH/timetable/root"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH


function modC(){
	num=0
	for o in $(ls /data/adb/modules);do
		name=$(cat /data/adb/modules/$o/module.prop | grep 'name'| cut -d = -f2 )
		author=$(cat /data/adb/modules/$o/module.prop | grep 'author'| cut -d = -f2 )
		description=$(cat /data/adb/modules/$o/module.prop | grep 'description'| cut -d = -f2 )
		echo "$o"
		num=$( expr $num + 1)
	done
}

function modname(){
	for q in $(ls /data/adb/modules);do
		name=$(cat /data/adb/modules/$q/module.prop | grep 'name'| cut -d = -f2 )
		if test $cmod == $q;then
			echo "$name"
		fi
	done
}

backopt2(){
	echo ""
	echo ""
	echo "∞————————————————————————∞"
	echo ""
	echo ""
	echo "1.继续选择其他模块"
	echo ""
	echo "2.回到模块备份终端控制器"
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	read d
	if test $d == 1 ;then
		modCzip
	elif [ $d == 2 ];then
		source $MODPATH/keymod/magiskbackup.sh
	elif $d != "*[0-9]*" ;then
		backopt2
	fi
	echo ""
	echo "∞————————————————————————∞"
}

function errorexit(){
echo "—— 他娘的，我的意大利炮去哪了？"
echo "—— 请截图发给模块开发者。"
exit 
}

function zipmod(){
	TMPDIR="/data/local/tmp/module"
	#清理临时目录
	rm -rf $TMPDIR 2>/dev/null && echo "—— 已清理临时文件！"
	#模版文件
	file="$MODPATH/keymod/key.zip"
	#magisk模块总目录
	modsdir="/data/adb/modules"
	#创建临时目录
	TMPDIR="/data/local/tmp/module"
	mkdir -p $TMPDIR && echo "—— 临时目录创建成功！" || errorexit
	#输出目录
	targetdir="/data/media/0/Android"
	#复制文件和添加模版
	cp -rf $modsdir/$cmod $TMPDIR
	unzip -o -q $file -d $TMPDIR/$cmod && echo "—— 解压模版成功！" || errorexit
	#模块目录
	moduledir="$TMPDIR/$cmod"
	#打包并输出模块
	cd $moduledir
	echo "—— 模块打包中…………"
	zip -r "$targetdir/$(modname)".zip  ./* > /dev/null  && echo "已经输出到 "$targetdir" "$(modname)" " || errorexit
}


function modCzip(){
	num=0
	for i in $(ls /data/adb/modules);do
		name=$(cat /data/adb/modules/$i/module.prop | grep 'name'| cut -d = -f2 )
		author=$(cat /data/adb/modules/$i/module.prop | grep 'author'| cut -d = -f2 )
		description=$(cat /data/adb/modules/$i/module.prop | grep 'description'| cut -d = -f2 )
		size=` du -sh /data/adb/modules/$i |awk '{print $1}'`
		num=$( expr $num + 1)
		echo " "
		echo "∞————————————【 $num 】————————————∞"
		echo ""
		echo "－名称：$name"
		echo "－作者：$author"
		echo "－简介：$description"
		echo " "
		echo "－大小：$size"
		echo " "
		echo "∞——————————————————————————————∞"
		echo " "
	done
	modc=$(modC)
	echo ""
	echo ""
	echo "- 请输入你要选择输出模块的序号"
	echo ""
	echo ""
	echo ""
	echo ""
	input=0
	read input
	if test "$input" -ge 1 ;then
		input=$( expr $input \* 1 2> /dev/null)
		cmod=$( echo "$modc"| sed -n ${input}p 2> /dev/null )
		echo "——您已选择: $(modname) " && zipmod
		backopt2
	elif [ "$input" != "*[0-9]*" ];then
		echo ""
		echo "————请您输入数字"
		echo ""
		sleep 1
		reset
		clear
		modCzip
	fi
}

modCzip

