# 🧿结界
### version=V3.47
## 防劫持，拦截各类广告、恶意网站，保护上网安全！
![AD](https://gitee.com/coolapk-code_9527/border/raw/master/image/AD.jpg)
***
* [Hosts-源](https://raw.githubusercontent.com/Coolapk-Code9527/-Hosts-/master/system/etc/hosts)
* [问题反馈](http://cfyfcie48msjtlnk.mikecrm.com/LWZv5oE)
* [打赏捐赠](https://gitee.com/coolapk-code_9527/border/raw/master/image/ALIPAY.jpg)
***
![ALIPAY](https://gitee.com/coolapk-code_9527/border/raw/master/image/ALIPAY.jpg)
