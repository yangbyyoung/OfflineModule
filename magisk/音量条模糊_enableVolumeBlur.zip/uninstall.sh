#!/sbin/sh
# 酷安@Bugme7
# 版本 v2.0
rm -rf /data/system/package_cache/*
rm -rf /data/adb/modules_update/enableVolumeBlur
rm -rf /data/adb/modules/enableVolumeBlur