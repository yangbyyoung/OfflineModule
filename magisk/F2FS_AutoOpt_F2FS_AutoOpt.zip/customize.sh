	#init
	function enforce_se(){
		setenforce 1
	}

	function permissive_se(){
		setenforce 0
	}

	function check_selinux(){
		restore_se=""
		if [ `getenforce` == "Permissive" ] ; then
			restore_se="permissive_se"
		else
			restore_se="enforce_se"
		fi
	}

	function check_fs(){
		if [[ `mount | grep ' /data ' | grep ' f2fs '` == "" ]] ; then
			echo " ------ DATA分区的文件系统不是F2FS，模块不可用！"
			$restore_se
			exit 0
		else
			echo " >>> DATA分区的文件系统为: F2FS "
			data=`find -L /dev/block/mapper/ -iname 'userdata' | head -1`
			temp=`ls -al $data`
			userdata="${temp##*/}"
			if [ -d /sys/fs/f2fs/$userdata ] ; then
				echo " >>> DATA分区号：$userdata (已加密) "
				echo " >>> F2FS接口：/sys/fs/f2fs/$userdata "
			else
				data=`find -L /dev/block/ -iname 'userdata' | head -1`
				temp=`ls -al $data`
				userdata="${temp##*/}"
				if  [ -d /sys/fs/f2fs/$userdata ] ; then
					echo " >>> DATA分区号：$userdata (未加密) "
					echo " >>> F2FS接口：/sys/fs/f2fs/$userdata "
				else
					data_numsda=`echo "$userdata" | tr -cd "dm-"`
					data_numdm=`echo "$userdata" | tr -cd "sd"`
					if [ "$data_numsda" != "dm-" ] ; then
						if [ "$data_numdm" != "sd" ] ; then
						echo " >>> ERROR！无法获取到DATA分区的分区号，安装已取消！"
						$restore_se
						exit 0
						fi
					fi
					echo " >>> ERROR！/sys/fs/f2fs/路径下无DATA分区的F2FS接口，模块不可用 "
					sleep 0.2
					echo " >>> 安装已取消！"
					$restore_se
					exit 0
				fi
			fi
			echo "$userdata" >/$MODPATH/userdata_num
		fi
	}

	function testapi(){
		sleep 0.2
		if [ $2 ] ; then
			echo " >>> 接口: $1 --------- OK"
		else
			echo " >>> 接口: $1 --------- ERROR！"
			echo " >>> 请检查$3 "
			apiloss=$(($apiloss + 1))
		fi
	}

#install
ui_print " ------ F2FS自动优化 [Magisk/KernelSU] "
sleep 0.3
ui_print " ------ 检测运行环境 "
sleep 0.3
check_selinux
permissive_se
check_fs
apiloss=0
testapi "set_gc_urgent" "-e /sys/fs/f2fs/$userdata/gc_urgent" "/sys/fs/f2fs/$userdata/gc_urgent是否存在"
testapi "set_gc_speed" "-e /sys/fs/f2fs/$userdata/gc_urgent_sleep_time" "/sys/fs/f2fs/$userdata/gc_urgent_sleep_time是否存在"
testapi "set_wake_lock" "-e /sys/power/wake_lock -a -e /sys/power/wake_unlock" "/sys/power/wake_lock和wake_unlock是否存在"
testapi "info_fs_unusable" "-e /sys/fs/f2fs/$userdata/unusable" "/sys/fs/f2fs/$userdata/unusable是否存在"
testapi "info_fs_free_segments" "-e /sys/fs/f2fs/$userdata/free_segments" "/sys/fs/f2fs/$userdata/free_segments是否存在"
testapi "info_cputime" "-e /proc/stat" "/proc/stat是否存在"
testapi "info_screen" "`dumpsys deviceidle | grep mScreenOn` == mScreenOn=true" " dumpsys deviceidle | grep mScreenOn 命令是否可用"
testapi "info_battery" "-e /sys/class/power_supply/battery/capacity -a -e /sys/class/power_supply/battery/status" "/sys/class/power_supply/battery/capacity和status是否存在"
if [ "$apiloss" -ge "1" ] ; then
	echo " ------ ERROR！缺失 $apiloss 个接口，安装已取消"
	$restore_se
	exit 0
fi
mkdir /sdcard/Android/fsopt
chmod 0755 /$MODPATH/main.sh
chmod 0755 /$MODPATH/busybox
$restore_se
sleep 0.2
ui_print " > "
sleep 0.5
ui_print " ------ 安装已完成，请重启！"
