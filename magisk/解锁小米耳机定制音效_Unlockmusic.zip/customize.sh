#默认不动
SKIPMOUNT=true
#如果想启用system.prop的参数，则改为true
PROPFILE=true
#开机前执行的命令，想启用则改为true
POSTFSDATA=true
#开机后执行的命令，想启用则改为true
LATESTARTSERVICE=false

#安装模块时打印的信息，不需要的部分可以自己删除，也可以自己添加。
print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 您的设备:
 #- SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
  #- 安卓版本: Android $Android
  - MIUI版本: $MIUI  $Version
 ****************************
 "
}
# 获取机型
var_device=$(getprop ro.product.device)

# 获取Android 版本
var_version=$(getprop ro.build.version.release)

# 获取MIUI大版本
var_MIUI_version=$(getprop ro.miui.ui.version.name)

# 获取模块版本
module_version="`grep_prop version $TMPDIR/module.prop`"

# 获取模块名称
module_name="`grep_prop name $TMPDIR/module.prop`"

# 获取模块id
module_id="`grep_prop id $TMPDIR/module.prop`"

# 获取模块作者
module_author="`grep_prop author $TMPDIR/module.prop`"

# 获取模块支持的机型
require_version="`grep_prop require_version $TMPDIR/module.prop`"

# 获取模块支持的Android版本
require_device="`grep_prop require_device $TMPDIR/module.prop`"

# 获取模块支持的MIUI大版本
require_MIUI_version="`grep_prop require_MIUI_version $TMPDIR/module.prop`"
# 安装脚本
on_install() {
  
  # 检测Android 版本
  if [ -n "$require_version" ]; then
    if [ "$var_version" != "$require_version" ]; then
      ui_print "- 您的Android 版本不支持此模块"
      run_exit # 如果不支持则自动退出安装
    fi
  fi

  # 检测MIUI大版本
  if [ -n "$require_MIUI_version" ]; then
    if [ "$var_MIUI_version" != "$require_MIUI_version" ]; then
      ui_print "- 您的MIUI版本不支持此模块"
      run_exit # 如果不支持则自动退出安装
    fi
  fi

  ui_print "- 正在安装"
  
}

