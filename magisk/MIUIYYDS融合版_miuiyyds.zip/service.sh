MODDIR=${0%/*}

while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
  sleep 50
done

# Disable various useless services of MIUI
pm disable "com.miui.systemAdSolution"
pm disable "com.xiaomi.joyose/.smartop.gamebooster.receiver.BoostRequestReceiver"
pm disable "com.xiaomi.joyose/.smartop.SmartOpService" 
pm disable "com.xiaomi.joyose.sysbase.MetokClService" 
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity"
pm disable "com.miui.daemon/.performance.cloudcontrol.CloudControlSyncService" 
pm disable "com.miui.daemon/.performance.statistics.services.GraphicDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.AtraceDumpService"
pm disable "com.miui.daemon/.performance.SysoptService"
pm disable "com.miui.daemon/.performance.MiuiPerfService"
pm disable "com.miui.daemon/.performance.server.ExecutorService"
pm disable "com.miui.daemon/.mqsas.jobs.EventUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.FileUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.HeartBeatUploadService"
pm disable "com.miui.daemon/.mqsas.providers.MQSProvider"
pm disable "com.miui.daemon/.performance.provider.PerfTurboProvider"
pm disable "com.miui.daemon/.performance.system.am.SysoptjobService"
pm disable "com.miui.daemon/.performance.system.am.MemCompactService"
pm disable "com.miui.daemon/.performance.statistics.services.FreeFragDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.DefragService"
pm disable "com.miui.daemon/.performance.statistics.services.MeminfoService"
pm disable "com.miui.daemon/.performance.statistics.services.IonService"
pm disable "com.miui.daemon/.performance.statistics.services.GcBoosterService"
pm disable "com.miui.daemon/.mqsas.OmniTestReceiver"
pm disable "com.miui.daemon/.performance.MiuiPerfService"
pm disable "com.tencent.mm:support"
pm disable "com.tencent.mm:recovery"
# Disable collective Device administrators
pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService

cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
cmd appops set com.google.android.gms.location.history BOOT_COMPLETED ignore
cmd appops set com.google.android.gm BOOT_COMPLETED ignore
cmd appops set com.google.android.marvin.talkback BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.googleassistant BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.carrier.log BOOT_COMPLETED ignore
cmd appops set com.android.providers.partnerbookmarks BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.wellbeing BOOT_COMPLETED ignore
cmd appops set com.google.android.as BOOT_COMPLETED ignore
cmd appops set com.android.connectivity.metrics BOOT_COMPLETED ignore
cmd appops set com.android.bips BOOT_COMPLETED ignore
cmd appops set com.google.android.printservice.recommendation BOOT_COMPLETED ignore
cmd appops set com.android.hotwordenrollment.xgoogle BOOT_COMPLETED ignore
cmd appops set com.google.android.printservice.recommendation BOOT_COMPLETED ignore
cmd appops set com.android.hotwordenrollment.xgoogle BOOT_COMPLETED ignore
# Disable GMS and IMS run in startup and restart it on boot (custom permissions for Oxygen OS)
cmd appops set com.google.android.gms AUTO_START ignore
cmd appops set com.google.android.ims AUTO_START ignore
cmd appops set com.xiaomi.finddevice AUTO_START ignore
cmd appops set com.miui.analytics AUTO_START ignore
cmd appops set com.google.android.gms.location.history AUTO_START ignore
cmd appops set com.google.android.gm AUTO_START ignore
cmd appops set com.google.android.marvin.talkback AUTO_START ignore
cmd appops set com.google.android.apps.googleassistant AUTO_START ignore
cmd appops set com.google.android.apps.carrier.log AUTO_START ignore
cmd appops set com.android.providers.partnerbookmarks AUTO_START ignore
cmd appops set com.google.android.apps.wellbeing AUTO_START ignore
cmd appops set com.google.android.as AUTO_START ignore
cmd appops set com.android.connectivity.metrics AUTO_START ignore
cmd appops set com.android.bips AUTO_START ignore
cmd appops set com.google.android.printservice.recommendation AUTO_START ignore
cmd appops set com.android.hotwordenrollment.okgoogle AUTO_START ignore
cmd appops set com.android.hotwordenrollment.xgoogle AUTO_START ignore
cmd appops set com.xiaomi.joyose RUN_IN_BACKGROUND ignore 
cmd appops set org.codeaurora.gps.gpslogsave RUN_IN_BACKGROUND ignore 
cmd appops set com.android.onetimeinitializer RUN_IN_BACKGROUND ignore 
cmd appops set com.qualcomm.qti.perfdump RUN_IN_BACKGROUND ignore  

# Clean junk files
rm -rf /data/*.log
rm -rf /data/adb/lspd/log/*.log
rm -rf /data/vendor/wlan_logs
rm -rf /data/vendor/charge_logger/*
rm -rf /data/*.txt
rm -rf /cache/*.apk
rm -rf /data/anr/*
rm -rf /data/backup/pending/*.tmp
rm -rf /data/cache/*.*
rm -rf /data/data/*.log
rm -rf /data/data/*.txt
rm -rf /data/log/*.log
rm -rf /data/log/*.txt
rm -rf /data/local/*.apk
rm -rf /data/local/*.log
rm -rf /data/local/*.txt
rm -rf /data/mlog/*
rm -rf /data/system/*.log
rm -rf /data/system/*.txt
rm -rf /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -rf /data/system/shared_prefs/*
rm -rf /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -rf /sdcard/*.log
rm -rf /sdcard/*.CHK 
rm -rf /sdcard/duilite
rm -rf /sdcard/DkMiBrowserDemo
rm -rf /sdcard/.xlDownload
rm -rf /sdcard/.UTSystemConfig
rm -rf /sdcard/.tbs
rm -rf /sdcard/.protected_image

# 此文件为Magisk默认隐藏Root列表
# 系统服务
magiskhide --add cmb.pb
magiskhide --add com.chinamworld.main
magiskhide --add com.unionpay
magiskhide --add com.icbc
magiskhide --add com.chinamworld.bocmbci
magiskhide --add com.android.bankabc
magiskhide --add com.cmbchina.ccd.pluto.cmbActivity
magiskhide --add com.webank.wemoney
magiskhide --add com.yitong.mbank.psbc
magiskhide --add com.bankcomm.Bankcomm
magiskhide --add com.citiccard.mobilebank
magiskhide --add cn.com.spdb.mobilebank.per
magiskhide --add com.ecitic.bank.mobile
magiskhide --add com.forms
magiskhide --add com.pingan.paces.ccms
magiskhide --add com.cgbchina.xpt
magiskhide --add com.ccb.companybank
magiskhide --add com.miui.virtualsim
magiskhide --add com.miui.virtualsim com.android.phone
magiskhide --add com.miui.virtualsim com.miui.virtualsim:authentication
magiskhide --add com.miui.virtualsim com.miui.virtualsim:pushservice
# Google
magiskhide --add com.google.android.gsf
magiskhide --add com.google.android.gms
magiskhide --add com.android.vending
# 银行类
magiskhide --add cmb.pb
magiskhide --add com.android.bankabc
magiskhide --add com.icbc
magiskhide --add com.cib.cibmb
magiskhide --add cn.com.spdb.mobilebank.per
magiskhide --add com.chinamworld.main
magiskhide --add com.chinamworld.bocmbci
magiskhide --add com.bankcomm.Bankcomm
magiskhide --add com.yitong.mbank.psbc
magiskhide --add com.ecitic.bank.mobile
magiskhide --add com.mybank.android.phone
# 58同城
magiskhide --add com.wuba
###############################
for i in logd statsd traced cnss_diag vendor.cnss_diag tcpdump vendor.tcpdump ipacm-diag vendor.ipacm-diag ramdump subsystem_ramdump charge_logger miuibooster; do
  kill_svc "$i"
done

for item in `dumpsys deviceidle whitelist`
do
    app=`echo "$item" | cut -f2 -d ','`
    echo "deviceidle whitelist -$app"
    dumpsys deviceidle whitelist -$app
done
# 
dumpsys deviceidle whitelist +com.xiaomi.xmsf
dumpsys deviceidle whitelist +com.woc.offselinux
dumpsys deviceidle whitelist +com.android.contacts
dumpsys deviceidle whitelist +com.tencent.mm
# ============================================
loop=$(cat /sys/block/zram0/backing_dev | grep -o "loop[0-9]*")
# ============================================
sync
echo "3" >/proc/sys/vm/drop_caches
echo "1" >/proc/sys/vm/compact_memory
echo "5" >/proc/sys/vm/dirty_ratio
echo "1" >/proc/sys/vm/dirty_background_ratio
# vm缓冲:缓解杀后台
echo "1500" >/proc/sys/vm/dirty_expire_centisecs 
echo "1000" >/proc/sys/vm/dirty_writeback_centisecs
# ============================================
if [ $loop != "" ]; then
	chmod 777 /sys/block/zram0/backing_dev
	echo "/dev/block/$loop" >/sys/block/zram0/backing_dev
	# zram_write
	# 回写容量限制: 你想限制的阈值*256，102400就是400MB
	echo "102400" >/sys/block/zram0/writeback_limit
	# writeback限制
	echo "1" >/sys/block/zram0/writeback_limit_enable
	# 把zram0中的页面标记为idle
	echo "all" >/sys/block/zram0/idle
	# 把zram0中的idle页丢到writeback
	echo "idle" >/sys/block/zram0/writeback
	# 切换回写调速器
	echo "none" >/sys/block/"$loop"/queue/scheduler
	exit 0
fi