MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    [ ! -f "$2" ] && return
    umount "$2"

    chmod +w "$2"
    echo "$1" | tee -a /dev/mount_mask "$2"
    mount --bind /dev/mount_mask "$2"
    rm /dev/mount_mask
}

while [ -z `getprop sys.boot_completed` ]; do
    sleep 1
done

for i in `find /data/adb/modules -name CuDaemon | cut -f 5 -d /`; do
    touch /data/adb/modules/$i/remove
done

for i in /sys/devices/system/cpu/cpu*/core_ctl/enable; do lock_val "0" $i; done
lock_val "0" /sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus
lock_val "0" /sys/module/mtk_fpsgo/parameters/boost_affinity
lock_val "0" /sys/module/fbt_cpu/parameters/boost_affinity
lock_val "0" /sys/kernel/fpsgo/minitop/enable

killall -15 AsoulOpt
nohup $MODDIR/AsoulOpt > /dev/null 2>&1 &
