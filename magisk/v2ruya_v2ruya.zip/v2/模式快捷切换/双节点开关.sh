cd /data/v2
pd=`sed -n 7p ./config.ini`
	echo "\E[1;36m"
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
if [[ "sjd=" == ${pd} ]]||[[ "sjd=0" == ${pd} ]]; then
echo "已开启双节点"
sed -i "/sjd=/csjd=1" config.ini

elif [[ "sjd=1" == ${pd} ]]; then
echo "已关闭双节点"
sed -i "/sjd=/csjd=0" config.ini

else
echo -e "提示:失败，默认关闭双节点"
sed -i "/sjd=/csjd=0" config.ini
fi
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
rm -f ./*.bak