#!/system/bin/sh
MODDIR=${0%/*}

#恢复权限
chmod 0755 /system/bin/logd
chmod 0755 /system/etc/init/logd.rc

#检测系统启动并禁用权限
while [ 1 = 1 ]
  do
    sleep 3s
    bootd=$(getprop sys.boot_completed)
    if [[ "$bootd" == "1" ]]; then
      chmod 0000 /system/bin/logd
      chmod 0000 /system/etc/init/logd.rc
      break
    fi
  done

#防止进程死灰复燃
while [ 1 = 1 ]
  do
    killall -9 logd 2>/dev/null
    sleep 5m
  done