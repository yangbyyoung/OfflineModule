#!/system/bin/sh

export PATH="${0%/*}:/system/bin":$PATH

file="/data/data/com.miui.powerkeeper/databases/user_configure.db"

sqlite3 "$file" << EOF
#update misc set value=120 where name='key_temp_threshold_xo_thermal';
#update misc set value=120 where name='key_temp_threshold';
#update misc set value=120 where name='xo_temp_threshold';
#update misc set value=120 where name='xo_temp_thresholdclr';
update misc set value='2147483647' where name='app_bg_max_check_time';
update misc set value='2147483647' where name='app_bg_time_threshold';
update misc set value='false' where name='night_clean_process';
#update misc set value='{"list60":""}' where name='fps_group';
#update misc set value='' where name='dfps_group';
update misc set value='{"game":""}' where name='thermal_group';
EOF



