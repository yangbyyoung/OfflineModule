MODDIR=${0%/*}
Charging_control=/sys/class/power_supply/battery/input_suspend
Charging_control2=/sys/class/power_supply/battery/charging_enabled
Start=463
Stop=480
Delay=30s
Set_Greedy_Time=1
[[ ! -f $Charging_control && ! -f $Charging_control2 ]] && exit 1
until [[ $jslx == true ]]; do
[[ -n $Delay ]] && sleep $Delay
Status=`[[ -f $Charging_control ]] && cat $Charging_control`
Status2=`[[ -f $Charging_control2 ]] && cat $Charging_control2`
if [[ $(dumpsys battery|awk '/temperature/{print $2}') -le $Start ]]; then
  if [[ $Status -eq 1 || $Status2 -eq 0 ]]; then
 if [[ -n $D ]]; then
D=$D
elif [[ -z $D ]]; then
[[ -f $Charging_control ]] && echo 0 >$Charging_control
[[ -f $Charging_control2 ]] && echo 1 >$Charging_control2
D=1
unset C
 fi
  fi
elif [[ $(dumpsys battery|awk '/temperature/{print $2}') -ge $Stop ]]; then
   if [[ $Status -eq 0 || $Status2 -eq 1 ]]; then
 if [[ -n $C ]]; then
C=$C
elif [[ -z $C ]]; then
[[ -n $Set_Greedy_Time ]] && sleep $Set_Greedy_Time
[[ -f $Charging_control ]] && echo 1 >$Charging_control
[[ -f $Charging_control2 ]] && echo 0 >$Charging_control2
C=1
unset D
 fi
  fi
fi
done
