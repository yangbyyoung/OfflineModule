sleep 2s

function white_list()
{
  pgrep -o $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white_list surfaceflinger
white_list webview_zygote

function white()
{
  pgrep -f $1 | while read pid; do
  renice -n -20 -p $pid
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  done
}
white android.hardware.graphics.composer@2.2-service
white zygote
white zygote64
white com.android.systemui

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 1 > /dev/stune/rt/schedtune.prefer_idle
echo 20 > /dev/stune/rt/schedtune.boost
echo 20 > /dev/stune/top-app/schedtune.boost
echo 1 > /dev/stune/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 50 > /dev/memcg/memory.swappiness
#通过对sched_relax_domain_level值的修改，扩大cpu负载均衡时查找的范围，防止因为某个范围内的核心因为负载过大而降低性能。

echo 1 > /dev/cpuset/sched_relax_domain_level
echo 1 > /dev/cpuset/system-background/sched_relax_domain_level
echo 1 > /dev/cpuset/background/sched_relax_domain_level
echo 1 > /dev/cpuset/foreground/sched_relax_domain_level
echo 1 > /dev/cpuset/top-app/sched_relax_domain_level