#!/system/bin/sh
MODDIR=${0%/*}

capacity_raw=/sys/class/power_supply/bms/capacity_raw
capacity=/sys/class/power_supply/bms/capacity

run_binary(){
  if [[ -f $capacity ]] && [[ -f $capacity_raw ]]; then
    chmod 777 $capacity
    nohup $MODDIR/accurate_battery > /dev/null 2>&1 &
  fi
}

run_binary