SKIPUNZIP=0
REPLACE="
/system/usr/keylayout/gpio-keys.kl
/system/vendor/usr/keylayout/gpio-keys.kl
"