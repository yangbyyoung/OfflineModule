##########################################################################################
#
# Magisk模块自定义安装脚本
#
##########################################################################################


##########################################################################################
# 替换列表
##########################################################################################

# 列出要在系统中直接替换的所有目录
# 您可以在变量名中声明要直接替换的文件夹列表REPLACE。模块安装程序脚本将提取此变量并为您创建文件.replace。

# 按以下格式构建替换列表
# 示例
REPLACE_EXAMPLE="
/system/app/YouTube
/system/app/Bloatware
"
#上面的替换列表将导致创建以下文件：
#$MODPATH/system/app/YouTube/.replace
#$MODPATH/system/app/Bloatware/.replace

# 在这里构建自定义替换列表
REPLACE="
"

##########################################################################################
# 显示内容
##########################################################################################
#getprop | grep net.dns
#nslookup 127.0.0.1
[ -f $TMPDIR/ipv4dns.prop ] && cp -af $TMPDIR/ipv4dns.prop $MODPATH/ipv4dns.prop
[ -f $TMPDIR/ipv6dns.prop ] && cp -af $TMPDIR/ipv6dns.prop $MODPATH/ipv6dns.prop
[ -f $TMPDIR/ipv4dnsovertls.prop ] && cp -af $TMPDIR/ipv4dnsovertls.prop $MODPATH/ipv4dnsovertls.prop
[ -f $TMPDIR/ipv6dnsovertls.prop ] && cp -af $TMPDIR/ipv6dnsovertls.prop $MODPATH/ipv6dnsovertls.prop
ipv4dns=`cat $MODPATH/ipv4dns.prop | awk '!/#/ {print $NF}' | cut -d "=" -f 2`
ipv6dns=`cat $MODPATH/ipv6dns.prop | awk '!/#/ {print $NF}' | cut -d "=" -f 2`
ipv4dnsovertls=`cat $MODPATH/ipv4dnsovertls.prop | awk '!/#/ {print $NF}' | cut -d "=" -f 2`
ipv6dnsovertls=`cat $MODPATH/ipv6dnsovertls.prop | awk '!/#/ {print $NF}' | cut -d "=" -f 2`
ipv4dnsprop=`cat $MODPATH/ipv4dns.prop | awk '!/#/ {print $NF}'`
ipv6dnsprop=`cat $MODPATH/ipv6dns.prop | awk '!/#/ {print $NF}'`
ipv4dnsovertlsprop=`cat $MODPATH/ipv4dnsovertls.prop | awk '!/#/ {print $NF}'`
ipv6dnsovertlsprop=`cat $MODPATH/ipv6dnsovertls.prop | awk '!/#/ {print $NF}'`
AndroidSDK=`getprop ro.build.version.sdk`
dotmode=`settings get global private_dns_mode`
iptdnsTesting=`iptables -t nat -nL OUTPUT --line-numbers | grep 'dpt:53 ' | awk 'NR==1{print $(NF)}' | cut -d ':' -f 2- | cut -d ':' -f 1`
ipt6dnsTesting=`ip6tables -t nat -nL OUTPUT --line-numbers | grep 'dpt:53 ' | awk 'NR==1{print $(NF)}' | cut -d ':' -f 2- | sed 's/\:53//g'`
accept_packages=`cat $MODPATH/packageswhite.prop | awk '!/#/ {print $NF}'`
get_package_uid(){ grep "${1}" /data/system/packages.list | awk '{print $2}' | sed 's/[^0-9]//g'; }
    set +eux
    ModulesPath=/data/adb/modules
    [[ -d $ModulesPath/hostsjj && ! -f $ModulesPath/hostsjj/disable ]] && ui_print "- [🧿结界]模块支持DNS更改,可停用此模块❗"
    [[ ! -f /system/xbin/busybox && ! -f /system/bin/busybox ]] && ui_print "- 未检测到[busybox]模块,许多Linux命令将不能被执行,可能会发生错误‼️"
    ui_print " ======================================================== "
    ui_print "- DNS配置文件列表："
    ui_print " ======================================================== "
if [[ -s $MODPATH/ipv4dns.prop ]];then
    ui_print "- 📄IPV4 DNS️"
    ui_print "$ipv4dnsprop"
else
    ui_print "- 📄IPV4 DNS️"
    ui_print "- 🈳❗"
fi
    
ip6tables -t nat -nL >/dev/null 2>&1
if [[ "$?" -eq 0 && -s $MODPATH/ipv6dns.prop ]];then
    ui_print " "
    ui_print "- 📄IPV6 DNS"
    ui_print "$ipv6dnsprop"
else
    ui_print " "
    ui_print "- 📄IPV6 DNS"
    ui_print "- 🈳/不支持ip6tables转换,'nat'表不存在❗"
fi

if [[ "$AndroidSDK" -ge "28" && "$dotmode" != "" && -s $MODPATH/ipv4dnsovertls.prop ]];then
    ui_print " "
    ui_print "- 📄IPV4 DNS Over TLS"
    ui_print "$ipv4dnsovertlsprop"
fi

if [[ "$AndroidSDK" -ge "28" && "$dotmode" != "" && -s $MODPATH/ipv6dnsovertls.prop ]];then
    ui_print " "
    ui_print "- 📄IPV6 DNS Over TLS"
    ui_print "$ipv6dnsovertlsprop"
fi

    ui_print " ======================================================== "
    ui_print "- 如想自定义DNS可到模块[ipv4dns.prop/ipv6dns.prop/ipv4dnsovertls.prop/ipv6dnsovertls.prop]配置文件添加修改! "
    ui_print " ======================================================== "
    ui_print "- 正在测试DNS网络连通性, 请耐心等待‼️"
    ui_print " ======================================================== "
    sleep 3
    
[[ "$iptdnsTesting" != "" ]] && iptables -t nat -F OUTPUT >/dev/null 2>&1
[[ "$ipt6dnsTesting" != "" ]] && ip6tables -t nat -F OUTPUT >/dev/null 2>&1
sync
if [[ -s $MODPATH/ipv4dns.prop ]];then
for dns in $ipv4dns; do
    setsid ping -c 5 -A -w 1 $dns | tee -a $MODPATH/ipv4dns.log
    sleep 0.2
done
fi

ip6tables -t nat -nL >/dev/null 2>&1
if [[ "$?" -eq 0 && -s $MODPATH/ipv6dns.prop ]];then
for dnss in $ipv6dns; do
    setsid ping6 -c 5 -A -w 1 $dnss | tee -a $MODPATH/ipv6dns.log
    sleep 0.2
done
fi

if [[ "$AndroidSDK" -ge "28" && "$dotmode" != "" && -s $MODPATH/ipv4dnsovertls.prop ]];then
for dot in $ipv4dnsovertls; do
    setsid ping -c 5 -A -w 1 $dot | tee -a $MODPATH/ipv4dnsovertls.log
    sleep 0.2
done
fi

if [[ "$AndroidSDK" -ge "28" && "$dotmode" != "" && -s $MODPATH/ipv6dnsovertls.prop ]];then
for dots in $ipv6dnsovertls; do
    setsid ping6 -c 5 -A -w 1 $dots | tee -a $MODPATH/ipv6dnsovertls.log
    sleep 0.2
done
fi
wait
sync
sleep 1
    ui_print " "
    ui_print " "
    ui_print " ======================================================== "
    
avg=`cat $MODPATH/ipv4dns.log | grep 'min/avg/max' | cut -d "=" -f 2 | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
ewma=`cat $MODPATH/ipv4dns.log | grep -w 'ipg/ewma' | sed 's/.*ipg\/ewma//g' | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
avgtest=`echo $avg | awk -F"/" '{printf("%.f\n",$2)}' `
ewmatest=`echo $ewma | awk -F"/" '{printf("%.f\n",$2)}' `
dnsavg=`cat $MODPATH/ipv4dns.log | grep -B 2 "$avg" | awk 'NR==1{print $2}' `
dnsewma=`cat $MODPATH/ipv4dns.log | grep -B 2 "$ewma" | awk 'NR==1{print $2}' `
avgname=`cat $MODPATH/ipv4dns.prop | grep "$dnsavg" | cut -d "=" -f 1`
ewmaname=`cat $MODPATH/ipv4dns.prop | grep "$dnsewma" | cut -d "=" -f 1`
RoundTripTime=`cat $MODPATH/ipv4dns.log | grep -oE "min\/avg\/max|min\/avg\/max\/mdev" | awk 'NR==1' | sed 's/min/最低值/g;s/avg/平均值/g;s/max/最高值/g;s/mdev/平均偏差/g' `
ewmaRoundTripTime=`cat $MODPATH/ipv4dns.log | grep -o 'ipg/ewma' | awk 'NR==1' `

sleep 1
if [[ "$dnsavg" != "" && "$avgtest" -lt 150 ]];then
    iptables -t nat -F OUTPUT
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination $dnsavg:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination $dnsavg:53
    [[ "$accept_packages" != "" ]] && {
    for APP in $accept_packages;do
    UID=`get_package_uid $APP`
    [[ "$UID" != "" ]] && iptables -t nat -I OUTPUT -m owner --uid-owner ${UID} -j ACCEPT || continue
    done;}
    ui_print " "
    ui_print "- IPV4_DNS：[$avgname]🔸$dnsavg "
if [[ "$avgtest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${RoundTripTime} = ${avg} ms🟢极速"
elif [[ "$avgtest" -ge 30 && "$avgtest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${RoundTripTime} = ${avg} ms🔵良好"
elif [[ "$avgtest" -ge 60 && "$avgtest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${RoundTripTime} = ${avg} ms🟡一般"
elif [[ "$avgtest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${RoundTripTime} = ${avg} ms🔴较差"
fi
    ui_print " "
    ui_print " ======================================================== "
elif [[ "$dnsewma" != "" && "$ewmatest" -lt 150 ]];then
    iptables -t nat -F OUTPUT
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination $dnsewma:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination $dnsewma:53
    [[ "$accept_packages" != "" ]] && {
    for APP in $accept_packages;do
    UID=`get_package_uid $APP`
    [[ "$UID" != "" ]] && iptables -t nat -I OUTPUT -m owner --uid-owner ${UID} -j ACCEPT || continue
    done;}
    ui_print " "
    ui_print "- IPV4_DNS：[$ewmaname]🔸$dnsewma "
if [[ "$ewmatest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmaRoundTripTime} = ${ewma} ms🟢极速"
elif [[ "$ewmatest" -ge 30 && "$avgtest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmaRoundTripTime} = ${ewma} ms🔵良好"
elif [[ "$ewmatest" -ge 60 && "$avgtest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmaRoundTripTime} = ${ewma} ms🟡一般"
elif [[ "$ewmatest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmaRoundTripTime} = ${ewma} ms🔴较差"
fi
    ui_print " "
    ui_print " ======================================================== "
else
    iptables -t nat -F OUTPUT
    ui_print " "
    ui_print "- IPV4_DNS：更换失败❗"
    ui_print " "
    ui_print " ======================================================== "
fi
sleep 1
ipv6avg=`cat $MODPATH/ipv6dns.log | grep 'min/avg/max' | cut -d "=" -f 2 | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
ipv6ewma=`cat $MODPATH/ipv6dns.log | grep -w 'ipg/ewma' | sed 's/.*ipg\/ewma//g' | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
ipv6avgtest=`echo $ipv6avg | awk -F"/" '{printf("%.f\n",$2)}' `
ipv6ewmatest=`echo $ipv6ewma | awk -F"/" '{printf("%.f\n",$2)}' `
ipv6dnsavg=`cat $MODPATH/ipv6dns.log | grep -B 2 "$ipv6avg" | awk 'NR==1{print $2}' `
ipv6dnsewma=`cat $MODPATH/ipv6dns.log | grep -B 2 "$ipv6ewma" | awk 'NR==1{print $2}' `
ipv6avgname=`cat $MODPATH/ipv6dns.prop | grep "$ipv6dnsavg" | cut -d "=" -f 1`
ipv6ewmaname=`cat $MODPATH/ipv6dns.prop | grep "$ipv6dnsewma" | cut -d "=" -f 1`
ipv6RoundTripTime=`cat $MODPATH/ipv6dns.log | grep -oE "min\/avg\/max|min\/avg\/max\/mdev" | awk 'NR==1' | sed 's/min/最低值/g;s/avg/平均值/g;s/max/最高值/g;s/mdev/平均偏差/g' `
ipv6ewmaRoundTripTime=`cat $MODPATH/ipv6dns.log | grep -o 'ipg/ewma' | awk 'NR==1' `

if [[ "$ipv6dnsavg" != "" && "$ipv6avgtest" -lt 150 ]];then
    ip6tables -t nat -F OUTPUT
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination $ipv6dnsavg:53
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination $ipv6dnsavg:53
    [[ "$accept_packages" != "" ]] && {
    for APP in $accept_packages;do
    UID=`get_package_uid $APP`
    [[ "$UID" != "" ]] && ip6tables -t nat -I OUTPUT -m owner --uid-owner ${UID} -j ACCEPT || continue
    done;}
    ui_print " "
    ui_print "- IPV6_DNS：[$ipv6avgname]🔸$ipv6dnsavg "
if [[ "$ipv6avgtest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6RoundTripTime} = ${ipv6avg} ms🟢极速"
elif [[ "$ipv6avgtest" -ge 30 && "$ipv6avgtest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6RoundTripTime} = ${ipv6avg} ms🔵良好"
elif [[ "$ipv6avgtest" -ge 60 && "$ipv6avgtest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6RoundTripTime} = ${ipv6avg} ms🟡一般"
elif [[ "$ipv6avgtest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6RoundTripTime} = ${ipv6avg} ms🔴较差"
fi
    ui_print " "
    ui_print " ======================================================== "
elif [[ "$ipv6dnsewma" != "" && "$ipv6ewmatest" -lt 150 ]];then
    ip6tables -t nat -F OUTPUT
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination $ipv6dnsewma:53
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination $ipv6dnsewma:53
    [[ "$accept_packages" != "" ]] && {
    for APP in $accept_packages;do
    UID=`get_package_uid $APP`
    [[ "$UID" != "" ]] && ip6tables -t nat -I OUTPUT -m owner --uid-owner ${UID} -j ACCEPT || continue
    done;}
    ui_print " "
    ui_print "- IPV6_DNS：[$ipv6ewmaname]🔸$ipv6dnsewma "
if [[ "$ipv6ewmatest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmaRoundTripTime} = ${ipv6ewma} ms🟢极速"
elif [[ "$ipv6ewmatest" -ge 30 && "$ipv6ewmatest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmaRoundTripTime} = ${ipv6ewma} ms🔵良好"
elif [[ "$ipv6ewmatest" -ge 60 && "$ipv6ewmatest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmaRoundTripTime} = ${ipv6ewma} ms🟡一般"
elif [[ "$ipv6ewmatest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmaRoundTripTime} = ${ipv6ewma} ms🔴较差"
fi
    ui_print " "
    ui_print " ======================================================== "
else
    ip6tables -t nat -F OUTPUT
    ui_print " "
    ui_print "- IPV6_DNS：更换失败(或当前网络不支持IPV6)❗"
    ui_print " "
    ui_print " ======================================================== "
fi
sleep 1
dotavg=`cat $MODPATH/ipv4dnsovertls.log | grep 'min/avg/max' | cut -d "=" -f 2 | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
dotewma=`cat $MODPATH/ipv4dnsovertls.log | grep -w 'ipg/ewma' | sed 's/.*ipg\/ewma//g' | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
dotavgtest=`echo $dotavg | awk -F"/" '{printf("%.f\n",$2)}' `
dotewmatest=`echo $dotewma | awk -F"/" '{printf("%.f\n",$2)}' `
dotdnsavg=`cat $MODPATH/ipv4dnsovertls.log | grep -B 2 "$dotavg" | awk 'NR==1{print $2}' `
dotdnsewma=`cat $MODPATH/ipv4dnsovertls.log | grep -B 2 "$dotewma" | awk 'NR==1{print $2}' `
ewmadotRoundTripTime=`cat $MODPATH/ipv4dnsovertls.log | grep -o 'ipg/ewma' | awk 'NR==1' `
dotRoundTripTime=`cat $MODPATH/ipv4dnsovertls.log | grep -oE "min\/avg\/max|min\/avg\/max\/mdev" | awk 'NR==1' | sed 's/min/最低值/g;s/avg/平均值/g;s/max/最高值/g;s/mdev/平均偏差/g' `
ipv6dotavg=`cat $MODPATH/ipv6dnsovertls.log | grep 'min/avg/max' | cut -d "=" -f 2 | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
ipv6dotewma=`cat $MODPATH/ipv6dnsovertls.log | grep -w 'ipg/ewma' | sed 's/.*ipg\/ewma//g' | sort -t '/' -k 2n | awk 'NR==1{print $1}' `
ipv6dotavgtest=`echo $ipv6dotavg | awk -F"/" '{printf("%.f\n",$2)}' `
ipv6dotewmatest=`echo $ipv6dotewma | awk -F"/" '{printf("%.f\n",$2)}' `
ipv6dotdnsavg=`cat $MODPATH/ipv6dnsovertls.log | grep -B 2 "$ipv6dotavg" | awk 'NR==1{print $2}' `
ipv6dotdnsewma=`cat $MODPATH/ipv6dnsovertls.log | grep -B 2 "$ipv6dotewma" | awk 'NR==1{print $2}' `
ipv6dotRoundTripTime=`cat $MODPATH/ipv6dnsovertls.log | grep -oE "min\/avg\/max|min\/avg\/max\/mdev" | awk 'NR==1' | sed 's/min/最低值/g;s/avg/平均值/g;s/max/最高值/g;s/mdev/平均偏差/g' `
ipv6ewmadotRoundTripTime=`cat $MODPATH/ipv6dnsovertls.log | grep -o 'ipg/ewma' | awk 'NR==1' `

if [[ "$ipv6dotdnsavg" != "" && "$dotavgtest" -gt "$ipv6dotavgtest" && "$ipv6dotavgtest" -lt 150 ]];then
    ui_print " "
    ui_print "- 系统支持【DNS Over TLS】"
    settings put global private_dns_specifier $ipv6dotdnsavg
    dotspecifier=`settings get global private_dns_specifier`
    dotavgname=`cat $MODPATH/ipv4dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ipv6dotavgname=`cat $MODPATH/ipv6dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ui_print "- DNS_Over_TLS：[$ipv6dotavgname]🔸$dotspecifier "
if [[ "$ipv6dotavgtest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6dotRoundTripTime} = ${ipv6dotavg} ms🟢极速"
elif [[ "$ipv6dotavgtest" -ge 30 && "$ipv6dotavgtest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6dotRoundTripTime} = ${ipv6dotavg} ms🔵良好"
elif [[ "$ipv6dotavgtest" -ge 60 && "$ipv6dotavgtest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6dotRoundTripTime} = ${ipv6dotavg} ms🟡一般"
elif [[ "$ipv6dotavgtest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6dotRoundTripTime} = ${ipv6dotavg} ms🔴较差"
fi
    [[ "$dotspecifier" = 'dns.cfiec.net' ]] && ui_print "- 此DNS服务商仅支持IPV6网络❗"
elif [[ "$dotdnsavg" != "" && "$dotavgtest" -lt 150 ]];then
    ui_print " "
    ui_print "- 系统支持【DNS Over TLS】"
    settings put global private_dns_specifier $dotdnsavg
    dotspecifier=`settings get global private_dns_specifier`
    dotavgname=`cat $MODPATH/ipv4dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ipv6dotavgname=`cat $MODPATH/ipv6dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ui_print "- DNS_Over_TLS：[$dotavgname]🔸$dotspecifier "
if [[ "$dotavgtest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${dotRoundTripTime} = ${dotavg} ms🟢极速"
elif [[ "$dotavgtest" -ge 30 && "$dotavgtest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${dotRoundTripTime} = ${dotavg} ms🔵良好"
elif [[ "$dotavgtest" -ge 60 && "$dotavgtest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${dotRoundTripTime} = ${dotavg} ms🟡一般"
elif [[ "$dotavgtest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${dotRoundTripTime} = ${dotavg} ms🔴较差"
fi
    [[ "$dotspecifier" = 'dns.cfiec.net' ]] && ui_print "- 此DNS服务商仅支持IPV6网络❗"
elif [[ "$ipv6dotdnsewma" != "" && "$dotewmatest" -gt "$ipv6dotewmatest" && "$ipv6dotewmatest" -lt 150 ]];then
    ui_print " "
    ui_print "- 系统支持【DNS Over TLS】"
    settings put global private_dns_specifier $ipv6dotdnsewma
    dotspecifier=`settings get global private_dns_specifier`
    dotewmaname=`cat $MODPATH/ipv4dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ipv6dotewmaname=`cat $MODPATH/ipv6dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ui_print "- DNS_Over_TLS：[$ipv6dotewmaname]🔸$dotspecifier "
if [[ "$ipv6dotewmatest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmadotRoundTripTime} = ${ipv6dotewma} ms🟢极速"
elif [[ "$ipv6dotewmatest" -ge 30 && "$ipv6dotewmatest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmadotRoundTripTime} = ${ipv6dotewma} ms🔵良好"
elif [[ "$ipv6dotewmatest" -ge 60 && "$ipv6dotewmatest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmadotRoundTripTime} = ${ipv6dotewma} ms🟡一般"
elif [[ "$ipv6dotewmatest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ipv6ewmadotRoundTripTime} = ${ipv6dotewma} ms🔴较差"
fi
    [[ "$dotspecifier" = 'dns.cfiec.net' ]] && ui_print "- 此DNS服务商仅支持IPV6网络❗"
elif [[ "$dotdnsewma" != "" && "$dotewmatest" -lt 150 ]];then
    ui_print " "
    ui_print "- 系统支持【DNS Over TLS】"
    settings put global private_dns_specifier $dotdnsewma
    dotspecifier=`settings get global private_dns_specifier`
    dotewmaname=`cat $MODPATH/ipv4dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ipv6dotewmaname=`cat $MODPATH/ipv6dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
    ui_print "- DNS_Over_TLS：[$dotewmaname]🔸$dotspecifier "
if [[ "$dotewmatest" -le 30 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmadotRoundTripTime} = ${dotewma} ms🟢极速"
elif [[ "$dotewmatest" -ge 30 && "$dotewmatest" -le 60 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmadotRoundTripTime} = ${dotewma} ms🔵良好"
elif [[ "$dotewmatest" -ge 60 && "$dotewmatest" -le 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmadotRoundTripTime} = ${dotewma} ms🟡一般"
elif [[ "$dotewmatest" -ge 90 ]];then
    ui_print " "
    ui_print "- Ping往返时间："
    ui_print "- ${ewmadotRoundTripTime} = ${dotewma} ms🔴较差"
fi
    [[ "$dotspecifier" = 'dns.cfiec.net' ]] && ui_print "- 此DNS服务商仅支持IPV6网络❗"
fi

if [[ "$AndroidSDK" -ge "28" && "$dotmode" == "opportunistic" ]];then
    ui_print " "
    ui_print "- DNS_Over_TLS状态：[自动🔄]"
    ui_print "- [DNS Over TLS]比普通DNS更安全但可能并不是很稳定,请酌情启用!"
    ui_print "- 仅更改服务器地址,未调整开关状态,加密DNS优先级大于iptables规则!"
    ui_print "- 如网络出问题请[关闭].(无法连接网络、无法加载图片、连接VPN没网等❗)"
    ui_print " "
    ui_print " ======================================================== "
elif [[ "$AndroidSDK" -ge "28" && "$dotmode" == "off" ]];then
    ui_print " "
    ui_print "- DNS_Over_TLS状态：[关闭❎]"
    ui_print "- 如需开启："
    ui_print "- [MIUI]-设置-连接与共享-私人DNS"
    ui_print "- [参考]-设置-无线和网络-加密DNS/私密DNS/私人DNS"
    ui_print "- [其他]-设置-网络和互联网-高级-加密DNS/私密DNS/私人DNS"
    ui_print "- [DNS Over TLS]比普通DNS更安全但可能并不是很稳定,请酌情启用!"
    ui_print "- 仅更改服务器地址,未调整开关状态,加密DNS优先级大于iptables规则!"
    ui_print "- 如网络出问题请[关闭].(无法连接网络、无法加载图片、连接VPN没网等❗)"
    ui_print " "
    ui_print " ======================================================== "
elif [[ "$AndroidSDK" -ge "28" && "$dotmode" == "hostname" ]];then
    ui_print " "
    ui_print "- DNS_Over_TLS状态：[开启✅]"
    ui_print "- 如需关闭："
    ui_print "- [MIUI]-设置-连接与共享-私人DNS"
    ui_print "- [参考]-设置-无线和网络-加密DNS/私密DNS/私人DNS"
    ui_print "- [其他]-设置-网络和互联网-高级-加密DNS/私密DNS/私人DNS"
    ui_print "- [DNS Over TLS]比普通DNS更安全但可能并不是很稳定,请酌情启用!"
    ui_print "- 仅更改服务器地址,未调整开关状态,加密DNS优先级大于iptables规则!"
    ui_print "- 如网络出问题请[关闭].(无法连接网络、无法加载图片、连接VPN没网等❗)"
    ui_print " "
    ui_print " ======================================================== "
fi

NetworkAgentInfo=`dumpsys connectivity | grep 'NetworkAgentInfo{' | grep -v 'ims'`
Network_type=`echo $NetworkAgentInfo | sed -n 's/.*type: //g;s/,.*//g;$p'`
Network_LinkAddresses=`echo $NetworkAgentInfo | sed -n 's/.*LinkAddresses: \[//;s/\].*//g;s/ //g;s/\,/\n- /g;s/\/..//g;s/- $//g;$p'`
Network_DnsAddresses=`echo $NetworkAgentInfo | sed -n 's/.*DnsAddresses: \[//;s/\].*//g;s/ //g;s/\,/\n- /g;s/\///g;s/- $//g;$p'`

if [[ -n "$Network_LinkAddresses" && -n "$Network_DnsAddresses" ]];then
    ui_print " "
    ui_print "- [️⚙️系统网络信息属性] — $Network_type"
    ui_print "- 内网IP地址："
    ui_print "- $Network_LinkAddresses"
    ui_print "- DNS服务器地址："
    ui_print "- $Network_DnsAddresses"
    ui_print " "
    ui_print " ======================================================== "
fi

if `curl --help >/dev/null 2>&1` ;then
curl_netease=`curl --connect-timeout 10 -m 10 -s 'nstool.netease.com' | awk '{print $2}' | cut -d '=' -f 2 | sed "s/'//g"`
curl_neteaseIP=`curl --connect-timeout 10 -m 10 -s $curl_netease | awk '{print $2}'`
curl_neteaseDNS=`curl --connect-timeout 10 -m 10 -s $curl_netease | awk '{print $4}'`
curl_cip_neteaseIP=`curl --connect-timeout 5 -m 5 -s "cip.cc/$curl_neteaseIP" | grep '数据二' | cut -d ':' -f 2`
curl_cip_neteaseDNS=`curl --connect-timeout 5 -m 5 -s "cip.cc/$curl_neteaseDNS" | grep '数据二' | cut -d ':' -f 2`
    ui_print " "
    ui_print "- [🧰网易DNS检测工具]"
    ui_print "- IP地址信息：$curl_neteaseIP $curl_cip_neteaseIP"
    ui_print "- DNS地址信息：$curl_neteaseDNS $curl_cip_neteaseDNS"
    ui_print "- 数据来源：http://nstool.netease.com | http://cip.cc"
    ui_print " "
    ui_print " ======================================================== "
elif `wget --help >/dev/null 2>&1` ;then
wget_netease=`wget -q -T 10 -O- 'nstool.netease.com' | awk '{print $2}' | cut -d '=' -f 2 | sed "s/'//g"`
wget_neteaseIP=`wget -q -T 10 -O- "$wget_netease" | awk '{print $2}'`
wget_neteaseDNS=`wget -q -T 10 -O- $wget_netease | awk '{print $4}'`
wget_cip_neteaseIP=`wget -q -T 10 -O- "cip.cc/$wget_neteaseIP" | grep '数据二' | cut -d ':' -f 2`
wget_cip_neteaseDNS=`wget -q -T 10 -O- "cip.cc/$wget_neteaseDNS" | grep '数据二' | cut -d ':' -f 2`
    ui_print " "
    ui_print "- [🧰网易DNS检测工具]"
    ui_print "- IP地址信息：$wget_neteaseIP $wget_cip_neteaseIP"
    ui_print "- DNS地址信息：$wget_neteaseDNS $wget_cip_neteaseDNS"
    ui_print "- 数据来源：http://nstool.netease.com | http://cip.cc"
    ui_print " "
    ui_print " ======================================================== "
fi

if `curl --help >/dev/null 2>&1` ;then
    ui_print " "
    curl --connect-timeout 5 -m 5 -s -L -w '- 🔍网站测试：%{url_effective}\n- 状态码：%{http_code}\n- 解析时间：%{time_namelookup}\n- 连接时间：%{time_connect}\n- 预转移时间：%{time_pretransfer}\n- 开始转移时间：%{time_starttransfer}\n- 总 时 间：%{time_total}\n' -o /dev/null 'www.baidu.com' | sed 's/0.000000/失败/g'
    ui_print " "
    ui_print " ======================================================== "
fi
sleeptime=`cat $MODPATH/service.sh | grep 'sleep' | awk 'END{print $2}' | sed 's/s/秒/g;s/[0-9]$/&秒/g;s/m/分钟/g;s/h/小时/g;s/d/天/g' `
    ui_print " "
    ui_print "- 👾工作原理：根据ping包往返时间自动选取DNS,利用iptables规则对数据包进行网络地址转换，重写包的DNS目标地址. [⏱️每$sleeptime刷新一次]"
    ui_print "- ⚠️注：Ping命令一般用于网络连通性的测试,不能作为网络衡量的唯一标准, 具体以实用情况为准!"
    ui_print " "
    ui_print " ======================================================== "

sleep 1
description=$MODPATH/module.prop
dotmode=`settings get global private_dns_mode`
dotspecifier=`settings get global private_dns_specifier`
iptdnsTesting=`iptables -t nat -nL OUTPUT --line-numbers | grep 'dpt:53 ' | awk 'NR==1{print $(NF)}' | cut -d ':' -f 2- | cut -d ':' -f 1`
ipt6dnsTesting=`ip6tables -t nat -nL OUTPUT --line-numbers | grep 'dpt:53 ' | awk 'NR==1{print $(NF)}' | cut -d ':' -f 2- | sed 's/\:53//g'`
ipv4Testingname=`cat $MODPATH/ipv4dns.prop | grep "$iptdnsTesting" | cut -d "=" -f 1`
ipv6Testingname=`cat $MODPATH/ipv6dns.prop | grep "$ipt6dnsTesting" | cut -d "=" -f 1`
dotTestingname=`cat $MODPATH/ipv4dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
ipv6dotTestingname=`cat $MODPATH/ipv6dnsovertls.prop | grep "$dotspecifier" | cut -d "=" -f 1`
refreshtime=`date +"%Y-%m-%d %H:%M:%S"`

if [[ "$ipv4Testingname" != "" && "$ipv6Testingname" != "" && "$ipv6dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\] - IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\] - 私人DNS：\["$ipv6dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv4Testingname" != "" && "$ipv6Testingname" != "" && "$dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\] - IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\] - 私人DNS：\["$dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv4Testingname" != "" && "$ipv6dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\] - 私人DNS：\["$ipv6dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv4Testingname" != "" && "$dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\] - 私人DNS：\["$dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv4Testingname" != "" && "$ipv6Testingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\] - IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv6Testingname" != "" && "$ipv6dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\] - 私人DNS：\["$ipv6dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv6Testingname" != "" && "$dotTestingname" != "" ]];then
sed -i "s/- .*/- IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\] - 私人DNS：\["$dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv4Testingname" != "" ]];then
sed -i "s/- .*/- IPV4：\["$ipv4Testingname"："$iptdnsTesting"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv6Testingname" != "" ]];then
sed -i "s/- .*/- IPV6：\["$ipv6Testingname"："$ipt6dnsTesting"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$ipv6dotTestingname" != "" ]];then
sed -i "s/- .*/- 私人DNS：\["$ipv6dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
elif [[ "$dotTestingname" != "" ]];then
sed -i "s/- .*/- 私人DNS：\["$dotTestingname"："$dotspecifier"\]   --- 刷新时间：\[""$refreshtime""\] /g" $description
else
sed -i "s/- .*/- /g" $description
fi

echo > $MODPATH/ipv4dns.log
echo > $MODPATH/ipv6dns.log
echo > $MODPATH/ipv4dnsovertls.log
echo > $MODPATH/ipv6dnsovertls.log
author=`cat $MODPATH/module.prop | grep 'author' | cut -d "=" -f 2`
    ui_print "- 🙇🏻by $author"
    ui_print " "
    ui_print " "
    ui_print " "
    sleep 5
#am start -a android.intent.action.VIEW -d 'http://nstool.netease.com' >/dev/null 2>&1
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
if [[ "$coolapkTesting" != "" ]];then
am start -d 'coolmarket://u/1539433' >/dev/null 2>&1
fi

##########################################################################################
#
# 安装框架将导出一些变量和函数。
# 您应该使用这些变量和函数进行安装。
# 
# !不要使用任何Magisk内部路径，因为它们不是公共API。
# !请勿在util_functions.sh中使用其他函数，因为它们不是公共API。
# !不保证非公共API可以保持版本之间的兼容性。
##########################################################################################
# 可用变量
##########################################################################################
#
# MAGISK_VER (string): 当前安装的Magisk的版本字符串（例如v20.0）
# MAGISK_VER_CODE (int): 当前安装的Magisk的版本代码（例如20000）
# BOOTMODE (bool): 如果模块当前正在Magisk Manager中安装,则为true
# MODPATH (path): 应安装模块文件的路径
# TMPDIR (path): 临时存储文件的地方
# ZIPFILE (path): 安装模块zip文件
# ARCH (string): 设备的CPU架构.值为arm,arm64,x86或x64
# IS64BIT (bool): 如果$ ARCH是arm64或x64,则为true
# API (int): 设备的API级别(Android版本)（例如，21对于Android 5.0）
#
##########################################################################################
# 可用功能
##########################################################################################
#
# ui_print <msg>
#     打印 <msg> 到安装界面
#     避免使用 'echo' 因为它不会显示在自定义安装界面
#
# abort <msg>
#     打印错误消息 <msg> 到安装界面和终止安装
#     避免使用 'exit' 因为它会跳过终止清理步骤
#
# set_perm <目标> <所有者> <组> <权限> [环境]
#     如果未设置[环境]，则默认值为 "u:object_r:system_file:s0"
#     该函数是以下命令的简写：
#       chown 所有者.组 目标
#       chmod 权限 目标
#       chcon 环境 目标
#
# set_perm_recursive <目录> <所有者> <组> <权限> <文件权限> [环境]
#     如果未设置[context]，则默认值为"u:object_r:system_file:s0"
#     对于<目录>中的所有文件，它将调用：
#       set_perm file 所有者 组 文件权限 环境
#     对于<目录>中的所有目录（包括自身），它将调用：
#       set_perm dir 所有者 组 权限 环境
#
##########################################################################################


##########################################################################################
# 权限设置
##########################################################################################


# 只有一些特殊文件需要特定权限
# 安装完成后，此功能将被调用
# 对于大多数情况，默认权限应该已经足够

#set_permissions() {
  # 默认规则
  # set_perm_recursive $MODPATH 0 0 0755 0644
  # 以下是一些例子:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
#}

# 您可以添加更多功能来协助您的自定义脚本代码









