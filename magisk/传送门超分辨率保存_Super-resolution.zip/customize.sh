DUBUG_FLAG=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false
exist=false

var_device="`getprop ro.product.board`"
var_version="`grep_prop ro.*build.version.incremental`"

print_modname() {
  ui_print "******************************"
  ui_print " $MODNAME "
  ui_print "******************************"
  ui_print " 作者：$MODauthor "
  ui_print " 介绍：$MODdescription "
  ui_print "******************************"
}

Compatible() {
cd /data/adb/modules/
for module_id in $(ls)
do
if [ ! "$module_id" = "$MODID" ];then
  let id++
  module_name=$(cat $module_id/module.prop | grep 'name')
  module_author=$(cat $module_id/module.prop | grep 'author')
  module_description=$(cat $module_id/module.prop | grep 'description')
  device_features1=$(find $module_id/ -name "device_features")
  if [ ! -z $device_features1 ];then
    exist=true
    ui_print "******************************"
    ui_print "******************************"
    ui_print "    模块id：$module_id"
    ui_print "    名称：${module_name:5}"
    ui_print "    作者：${module_author:7}"
    ui_print "    简介：${module_description:12}"
    ui_print "- 检测到冲突模块，启动兼容模式，本模块失效，模块内容已移至冲突模块"
    for file in $device_features1; do
      # 传送门超分辨率保存
	  sed -i '/<\/features>/i\    <bool name=\"support_SR_for_image_display\">true<\/bool>' $file/*xml
    done
  fi
fi
done
}

on_install() {
  ui_print "- 正在插入传送门超分辨率保存"
  Compatible
  if [ $exist = false ];then
  for files in /system /system_ext /vendor /product; do
  device_features=$(find $files -name "device_features")
  for file in $device_features; do
  if [ $files = /system ];then
  mkdir -p $MODPATH$device_features
  cp -rf $file/*xml $MODPATH$device_features
  # 传送门超分辨率保存
	sed -i '/<\/features>/i\    <bool name=\"support_SR_for_image_display\">true<\/bool>' $MODPATH$device_features/*xml
  else
  mkdir -p $MODPATH/system$device_features
  cp -rf $file/*xml $MODPATH/system$device_features
  # 传送门超分辨率保存
	sed -i '/<\/features>/i\    <bool name=\"support_SR_for_image_display\">true<\/bool>' $MODPATH/system$device_features/*xml
  fi
  done
  done
  fi
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}
