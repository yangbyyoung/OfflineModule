#!/system/bin/sh
echo
echo 查询温控脚本，感谢coolapk@代号10007的温控脚本
echo
echo 请你以ROOT权限执行
echo 
echo 正在运行...
sleep 2s
find /system /vendor /product /system_ext -type f -iname "*thermal*" -exec ls -s -h {} \; 2>/dev/null | sed '/hardware/d'
echo
echo
echo =============================================
echo
echo    如果文件为空，则移除成功，否则失败
echo    如果不为空或者出现跳电问题，请截图向我反馈
echo    .so不用管,mi_thermald和thermal-engine删除可能跳电也不用管
echo
echo =============================================
echo
echo