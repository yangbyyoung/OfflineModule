SKIPMOUNT=false
AUTOMOUNT=true
LATESTARTSERVICE=true
print_modname() {
 ui_print "- 将 SearchEVO 以及 CopyEVO 安装到系统"
}
on_install() {
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print "- 模块刷入完毕，重启生效"
 ui_print "- SearchEVO 当前版本：4.0.0.0.3"
 ui_print "- CopyEVO 当前版本：0.4.6"
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}