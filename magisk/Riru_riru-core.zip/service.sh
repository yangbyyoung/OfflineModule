#!/system/bin/sh
MODDIR=${0%/*}
TMPPROP="$(magisk --path)/riru.prop"
MIRRORPROP="$(magisk --path)/.magisk/modules/riru-core/module.prop"
sh -Cc "cat '$MODDIR/module.prop' > '$TMPPROP'"
mkdir -p "$(magisk --path)/riru"

patch_lib(){
    /data/adb/magisk/magiskboot hexpatch "$1" \
    726f2e64616c76696b2e766d2e6e61746976652e62726964676500 \
    726f2e7a79676f7465000000000000000000000000000000000000
}

patch_libandroid_runtime(){
if [ -f /system/lib/libandroid_runtime.so ]; then
    cp -af /system/lib/libandroid_runtime.so "$(magisk --path)/riru/libandroid_runtime.so.32"
    magisk --clone-attr /system/lib/libandroid_runtime.so "$(magisk --path)/riru/libandroid_runtime.so.32"
    patch_lib "$(magisk --path)/riru/libandroid_runtime.so.32"
    mount --bind "$(magisk --path)/riru/libandroid_runtime.so.32" /system/lib/libandroid_runtime.so
fi

if [ -f /system/lib64/libandroid_runtime.so ]; then
    cp -af /system/lib64/libandroid_runtime.so "$(magisk --path)/riru/libandroid_runtime.so.64"
    magisk --clone-attr /system/lib64/libandroid_runtime.so "$(magisk --path)/riru/libandroid_runtime.so.64"
    patch_lib "$(magisk --path)/riru/libandroid_runtime.so.64"
    mount --bind "$(magisk --path)/riru/libandroid_runtime.so.64" /system/lib64/libandroid_runtime.so
fi

# restart zygote
stop; start;
}

# comment this line if you patch libandroid_runtime directly
patch_libandroid_runtime

if [ $? -eq 0 ]; then
  mount --bind "$TMPPROP" "$MIRRORPROP"
  sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ⛔ post-fs-data.sh fails to run. Magisk is broken on this device. ] /g' "$MODDIR/module.prop"
  exit
fi

