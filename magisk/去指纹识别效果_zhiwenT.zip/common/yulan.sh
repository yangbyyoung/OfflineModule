if [ -d "/data/adb/zhiwen/xg/heisha2" ];then
  cp -r /data/adb/yulan/xg/heisha2/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/xg/opporeno" ];then
  cp -r /data/adb/yulan/xg/opporeno/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/xg/vivo" ];then
  cp -r /data/adb/yulan/xg/vivo/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/xg/yijia" ];then
  cp -r /data/adb/yulan/xg/yijia/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/lg/coloros" ];then
  cp -r /data/adb/yulan/lg/coloros/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/lg/jiguang" ];then
  cp -r /data/adb/yulan/lg/jiguang/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/lg/opporeno" ];then
  cp -r /data/adb/yulan/lg/opporeno/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/lg/yijia" ];then
  cp -r /data/adb/yulan/lg/yijia/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/nd/coloros" ];then
  cp -r /data/adb/yulan/nd/coloros/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/nd/heisha2" ];then
  cp -r /data/adb/yulan/nd/heisha2/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/nd/vivo" ];then
  cp -r /data/adb/yulan/nd/vivo/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/nd/yijia" ];then
  cp -r /data/adb/yulan/nd/yijia/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/coloros" ];then
  cp -r /data/adb/yulan/mc/coloros/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/heisha2" ];then
  cp -r /data/adb/yulan/mc/heisha2/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/opporeno" ];then
  cp -r /data/adb/yulan/mc/opporeno/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/vivo1" ];then
  cp -r /data/adb/yulan/mc/vivo1/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/vivo2" ];then
  cp -r /data/adb/yulan/mc/vivo2/* $MODPATH/Settings/res/raw/
fi
if [ -d "/data/adb/zhiwen/mc/yijia" ];then
  cp -r /data/adb/yulan/mc/yijia/* $MODPATH/Settings/res/raw/
fi
  