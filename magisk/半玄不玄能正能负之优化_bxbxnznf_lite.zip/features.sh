A=$MODPATH/system/vendor/etc/device_features
B=$MODPATH/system/etc/device_features
[ ! -d $A ] && mkdir -p $A
[ ! -d $B ] && mkdir -p $B
C=$A/*.xml
D=$B/*.xml
[ ! -e $C ] && cp -rf /system/vendor/etc/device_features/* $A
[ ! -e $D ] && cp -rf /system/etc/device_features/* $B