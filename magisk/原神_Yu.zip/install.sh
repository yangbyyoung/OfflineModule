#!/system/bin/sh
MODDIR=${0%/*}
cd $MODDIR/system/vendor/overlay/BsCharge
cp $MODDIR/Operate/TianXuan/1/BsCharge.apk.xz $(pwd)
xz -d *.xz