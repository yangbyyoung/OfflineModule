#!/system/bin/sh

chmod a+x GameSwitch.sh

# Genshin Impact
while true; do
    sleep 1.5
    if [ -d "/storage/emulated/0/Hubert" ]; then
        HoYoImpact=$(pidof com.miHoYo.Yuanshen)
        if [ -n "$HoYoImpact" ]; then
            sleep 1
            am start --windowingMode 5 -n james.dsp/james.dsp.activity.DSPManager
            sleep 0.6
            input keyevent KEYCODE_BACK
            rm -rf /storage/emulated/0/Hubert
            else
                echo "Genshin Impact Not Found."
                sleep 0.5
        fi
        else
            Impact=$(pidof com.miHoYo.Yuanshen)
            if [ -n "$Impact" ]; then
                echo "Game Running Or Not KILL!"
                else
                    JAMES=$(pidof james.dsp)
                    if [ -n "$JAMES" ]; then
                        kill $JAMES
                    fi
                    mkdir -p /storage/emulated/0/Hubert
            fi
    fi
done