#!/system/bin/sh
MODDIR=${0%/*}
sleep 3
pm uninstall --user 0 com.miui.misound