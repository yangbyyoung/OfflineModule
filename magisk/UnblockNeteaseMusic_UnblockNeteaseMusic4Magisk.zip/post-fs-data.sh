#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

re=$(grep -m1 -i "com.netease.cloudmusic" /data/system/packages.list | cut -d' ' -f2)
iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner $re -m tcp --dport 80 -j DNAT --to 47.102.206.98:12345
iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner $re -m tcp --dport 443 -j DNAT --to 47.102.206.98:12346

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread