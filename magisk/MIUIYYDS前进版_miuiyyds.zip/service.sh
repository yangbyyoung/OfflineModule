MODDIR=${0%/*}

while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
  sleep 30
done
# 关闭MIUI负优化服务
pm disable "com.miui.systemAdSolution"
pm disable "com.xiaomi.joyose/.cloud.CloudServerReceiver"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService"
pm disable "com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService"
pm disable "com.miui.daemon/.performance.cloudcontrol.CloudControlSyncService" 
pm disable "com.miui.daemon/.performance.statistics.services.GraphicDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.AtraceDumpService"
pm disable "com.miui.daemon/.performance.SysoptService"
pm disable "com.miui.daemon/.performance.MiuiPerfService"
pm disable "com.miui.daemon/.performance.server.ExecutorService"
pm disable "com.miui.daemon/.mqsas.jobs.EventUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.FileUploadService"
pm disable "com.miui.daemon/.mqsas.jobs.HeartBeatUploadService"
pm disable "com.miui.daemon/.mqsas.providers.MQSProvider"
pm disable "com.miui.daemon/.performance.provider.PerfTurboProvider"
pm disable "com.miui.daemon/.performance.system.am.SysoptjobService"
pm disable "com.miui.daemon/.performance.system.am.MemCompactService"
pm disable "com.miui.daemon/.performance.statistics.services.FreeFragDumpService"
pm disable "com.miui.daemon/.performance.statistics.services.DefragService"
pm disable "com.miui.daemon/.performance.statistics.services.MeminfoService"
pm disable "com.miui.daemon/.performance.statistics.services.IonService"
pm disable "com.miui.daemon/.performance.statistics.services.GcBoosterService"
pm disable "com.miui.daemon/.mqsas.OmniTestReceiver"
pm disable "com.miui.daemon/.performance.MiuiPerfService"
pm disable "com.miui.daemon/.performance.mispeed.CloudServerReceiver"
pm disable "com.xiaomi.market/com.xiaomi.market.reverse_ad.wakeup.ReverseAdWakeUpService"
pm disable "com.xiaomi.market/com.xiaomi.market.reverse_ad.service.ReverseAdScheduleService"
pm disable "com.xiaomi.market/com.xiaomi.market.reverse_ad.page.WebReverseAdActivity"
pm disable "com.xiaomi.market/com.xiaomi.market.business_ui.directmail.SourceFileDownloadAdsActivity"
pm disable "com.tencent.mm:support"
pm disable "com.tencent.mm:recovery"
sleep 10
# 清理缓存垃圾
rm -rf /data/*.log
rm -rf /data/adb/lspd/log/*.log
rm -rf /data/vendor/wlan_logs
rm -rf /data/vendor/charge_logger/*
rm -rf /data/*.txt
rm -rf /cache/*.apk
rm -rf /data/anr/*
rm -rf /data/backup/pending/*.tmp
rm -rf /data/cache/*.*
rm -rf /data/data/*.log
rm -rf /data/data/*.txt
rm -rf /data/log/*.log
rm -rf /data/log/*.txt
rm -rf /data/local/*.apk
rm -rf /data/local/*.log
rm -rf /data/local/*.txt
rm -rf /data/mlog/*
rm -rf /data/system/*.log
rm -rf /data/system/*.txt
rm -rf /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -rf /data/system/shared_prefs/*
rm -rf /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -rf /sdcard/*.log
rm -rf /sdcard/*.CHK 
rm -rf /sdcard/duilite
rm -rf /sdcard/DkMiBrowserDemo
rm -rf /sdcard/.xlDownload
rm -rf /sdcard/.UTSystemConfig
rm -rf /sdcard/.tbs
rm -rf /sdcard/.protected_image
###############################