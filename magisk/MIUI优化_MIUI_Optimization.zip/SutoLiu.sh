#!/system/bin/sh
set_sys_def_scaling_governor()
{
	local i=60
	while [ $i -gt 0 ]; do
		if [ "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)" ==  "performance" ]; then
			sleep 1
			i=$(($i-1))
		else
			SYS_DEF_SCALING_GOVERNOR=`cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor`
			i=0
		fi
	done
	if [ -z "$SYS_DEF_SCALING_GOVERNOR" ]; then
		if [[ "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors)" == *"walt"* ]]; then
			SYS_DEF_SCALING_GOVERNOR=walt
		elif [[ "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors)" == *"schedutil"* ]]; then
			SYS_DEF_SCALING_GOVERNOR=schedutil
		elif [[ "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors)" == *"ondemand"* ]]; then
			SYS_DEF_SCALING_GOVERNOR=ondemand
		else
			exit 1
		fi
	fi
}
performance_mode()
{
	for CPU in `ls /sys/devices/system/cpu/cpu*/online`; do
		[ -f $CPU ] && echo "1" > $CPU
	done
	for SCALING_GOVERNOR_PATH in `ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor`; do
		[[ "$(cat ${SCALING_GOVERNOR_PATH%/*}/scaling_available_governors)" == *"performance"* ]] && echo "performance" > $SCALING_GOVERNOR_PATH
	done
	if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
		echo "1" > /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled
	elif [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
		echo "Y" > /sys/module/lpm_levels/parameters/sleep_disabled
	fi
	for POLICY_PATH in `ls -d /sys/devices/system/cpu/cpufreq/policy*`; do
		if [ -f ${POLICY_PATH}/cpuinfo_max_freq ] && [ -f ${POLICY_PATH}/scaling_min_freq ]; then
			echo "$(cat ${POLICY_PATH}/cpuinfo_max_freq)" > ${POLICY_PATH}/scaling_min_freq
		fi
	done
}
balanced_mode()
{
	for CPU in `ls /sys/devices/system/cpu/cpu*/online`; do
		[ -f $CPU ] && echo "1" > $CPU
	done
	for SCALING_GOVERNOR_PATH in `ls /sys/devices/system/cpu/cpufreq/policy*/scaling_governor`; do
		[[ "$(cat ${SCALING_GOVERNOR_PATH%/*}/scaling_available_governors)" == *"$SYS_DEF_SCALING_GOVERNOR"* ]] && echo "$SYS_DEF_SCALING_GOVERNOR" > $SCALING_GOVERNOR_PATH
	done
	if [ -f /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled ]; then
		echo "0" > /sys/devices/system/cpu/qcom_lpm/parameters/sleep_disabled
	elif [ -f /sys/module/lpm_levels/parameters/sleep_disabled ]; then
		echo "N" > /sys/module/lpm_levels/parameters/sleep_disabled
	fi
	for POLICY_PATH in `ls -d /sys/devices/system/cpu/cpufreq/policy*`; do
		if [ -f ${POLICY_PATH}/cpuinfo_min_freq ] && [ -f ${POLICY_PATH}/scaling_min_freq ]; then
			echo "$(cat ${POLICY_PATH}/cpuinfo_min_freq)" > ${POLICY_PATH}/scaling_min_freq
		fi
	done
}
set_sys_def_scaling_governor
while true; do
	dumpsys battery reset && sleep 1
	[ "$(settings get system speed_mode)" == 0 ] && settings put system speed_mode 1
	if [[ "$(dumpsys battery)" == *"status: 2"* ]] || [[ "$(dumpsys battery)" == *"status: 5"* ]]; then
		[ "$(getprop sutoliu.powered_on_performance_enhancements)" ==  "Y" ] && performance_mode
		local i=1
		while [ "$i" -gt "0" ]; do
			sleep 1
			if [[ "$(dumpsys battery)" == *"status: 2"* ]] || [[ "$(dumpsys battery)" == *"status: 5"* ]]; then
				i=1
			else
				i=0
			fi
		done
	else
		[ "$(getprop sutoliu.powered_on_performance_enhancements)" ==  "Y" ] && balanced_mode
		local i=1
		while [ "$i" -gt "0" ]; do
			sleep 6
			if [[ "$(dumpsys battery)" == *"status: 2"* ]] || [[ "$(dumpsys battery)" == *"status: 5"* ]]; then
				i=0
			else
				i=1
			fi
		done
	fi
done
