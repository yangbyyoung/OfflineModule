#!/sbin/sh
# 酷安@Bugme7
# 版本 v1.0
rm -rf /data/system/package_cache/*
rm -rf /data/adb/modules_update/MiVoiceOpti
rm -rf /data/adb/modules/MiVoiceOpti