zjlPath="${0%/*}/*/ZJL"
${zjlPath} -o -d