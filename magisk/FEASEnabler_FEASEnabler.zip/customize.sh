SKIPUNZIP=0
MODDIR=${0%/*}

# remove old version
MODS_PATH="/data/adb/modules"
[ -d "${MODS_PATH}/Feasenabler" ] && rm -rf "${MODS_PATH}/Feasenabler"

# permission
chmod a+x "$MODPATH/bin/inject64"
chmod a+x "$MODPATH/bin/inject32"
chmod a+x "$MODPATH/bin/magiskpolicy"
