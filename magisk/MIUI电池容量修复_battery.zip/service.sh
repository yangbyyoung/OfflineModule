#!/system/bin/sh
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动
until [ "$(getprop sys.boot_completed)" -eq "1" ]; do
  sleep 2
done

chmod 777 $MODDIR/sh/battery.sh
chmod 777 $MODDIR/sh/kj.sh
chmod 777 $MODDIR/sh/accurate_battery.sh
chmod 777 $MODDIR/sh/accurate_battery

su -c $MODDIR/sh/kj.sh
su -c $MODDIR/sh/accurate_battery.sh
nohup $MODDIR/sh/battery.sh > /dev/null 2>&1 &
