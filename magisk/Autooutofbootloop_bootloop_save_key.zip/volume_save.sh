#!/system/bin/sh

source "${0%/*}/util_functions.sh"

volume_key="$MODPATH/tools/keycheck"

#运行三次音量键，自动救砖！
$volume_key
$volume_key
$volume_key
$volume_key

#运行音量键救砖
if test "$(getprop service.bootanim.exit)" != "1" ;then
	if test "$(getprop sys.boot_completed)" != "1" ;then
		run_main && change_description "[I] 执行音量键救砖！" "[I] Try to press the volume key to fix bootloop！" "false" "true"
		reboot
	fi
fi

