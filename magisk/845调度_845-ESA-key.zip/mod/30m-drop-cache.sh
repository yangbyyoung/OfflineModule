until $(dumpsys deviceidle get screen) ;do
	sleep 5
done

sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
sync
