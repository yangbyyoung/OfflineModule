app='
com.miui.screenrecorder
com.miui.contentextension
com.miui.quickappCenter.miAppStore
com.miui.powerkeeper
com.miui.qr
com.miui.contentcatcher
name.mikanoshi.customiuizer
miui.systemui.plugin
com.miui.packageinstaller
com.miui.gaojishezhi.plus
com.miui.extraphoto
com.miui.securityadd
com.miui.gallery
com.miui.securitycenter
com.miui.tsmclient
com.miui.guardprovider
com.miui.backup
com.android.settings.overlay.miui
com.miui.notification
com.miui.micloudsync
com.miui.daemon
com.miui.hybrid
android.miui.overlay
com.miui.vsimcore
com.miui.securitycore
com.miui.phrase
com.miui.player
com.miui.miservice
com.miui.system
cn.xylin.miui.step.manage
com.miui.translation.kingsoft
com.miui.catcherpatch
com.miui.systemui.devices.overlay
com.miui.compass
com.miui.cit
com.miui.rom
com.miui.vpnsdkmanager
com.miui.personalassistant
com.miui.misound
com.xposed.miuianesthetist
com.miui.bugreport
com.miui.documentsuioverlay
com.mixapplications.miuithemeeditor
com.tianma.tweaks.miui
com.miui.voicetrigger
com.android.systemui.overlay.miui
com.miui.translation.youdao
com.miui.cloudbackup
com.miui.face.overlay.miui
com.miui.mishare.connectivity
com.miui.freeform
top.juruo.miuigetupdateurl
com.miui.nextpay
com.miui.notes
com.miui.theme
com.miui.video
com.miui.wmsvc
com.miui.translationservice
com.miui.cloudservice
com.miui.hybrid.accessory
com.miui.audiomonitor
com.miui.translation.xmcloud
com.miui.touchassistant
cn.iqianye.miui.whitebar
com.xmiui.packageinstaller
com.miui.calculator
com.miui.cloudservice.sysbase
com.miui.miwallpaper
com.miui.cleanmaster
com.miui.analytics
com.miui.weather2
com.omarea.miuieditor
com.miui.yellowpage
com.miui.accessibility
com.miui.systemui.carriers.overlay
com.miui.systemui.overlay.devices.android
com.miui.voiceassist
com.miui.smarttravel
com.miui.smsextra
com.lbe.security.miui
com.miui.newmidrive
com.miui.core
com.miui.face
com.miui.home
com.miui.audioeffect
com.tencent.mobileqq
com.tencent.mm
com.eg.android.AlipayGphone
com.taobao.taobao
'
echo ""
echo ""
echo ""
echo "
————————————————————🍂🍃🍂🍃
"
echo "
●————————②Magisk hide 检测————————●
"
echo "－如果不是特别必要，请不要用magisk hide 某个应用"
echo ""
echo "－magisk hide 自20.0以后，造成内存泄露的情况严重"
echo "－目前是无解的，你可以选择放弃magisk hide
－或者使用magisk lite (似乎是个不错的选择🤔？)"
echo ""
echo "－magisk hide 默认hide GMS(即谷歌全家桶)"
echo ""
echo "－就目前看来，除了GMS 和银行类应用，以及极少数游戏"
echo "－需要magisk hide 外，大多数情况不需要。"
echo ""
echo "－所以不要用magisk hide MIUI 全家桶！！！！"
echo "－hide MIUI 全家桶并无卵用，或者用处不大。"

for i in $app;do
magiskhide ls|grep $i && echo "－存在可能通过magisk hide发生内存泄露 包名：$i"
magiskhide rm $i 2>/dev/null
done
echo "
————————————————————🍂🍃🍂🍃
"
