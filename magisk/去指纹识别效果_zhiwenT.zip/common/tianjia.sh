if [ -d "/data/adb/zhiwen/xp/heisha2" ];then
  jieshao=黑鲨2息屏指纹特效
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xp/iqoo" ];then
  jieshao=iqoo息屏指纹特效
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xp/opporeno" ];then
  jieshao=opporeno息屏指纹特效
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xp/vivo" ];then
  jieshao=vivo息屏指纹特效
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xp/yijia" ];then
  jieshao=一加息屏指纹特效
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xg/heisha2" ];then
  jieshao=黑鲨2指纹特效替换星光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xg/opporeno" ];then
  jieshao=opporeno指纹特效替换星光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xg/vivo" ];then
  jieshao=vivo指纹特效替换星光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/xg/yijia" ];then
  jieshao=一加指纹特效替换星光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/lg/coloros" ];then
  jieshao=coloros指纹特效替换流光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/lg/jiguang" ];then
  jieshao=极光指纹特效替换流光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/lg/opporeno" ];then
  jieshao=opporeno指纹特效替换流光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/lg/yijia" ];then
  jieshao=一加指纹特效替换流光
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/coloros" ];then
  jieshao=coloros指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/heisha2" ];then
  jieshao=黑鲨2指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/opporeno" ];then
  jieshao=opporeno指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/vivo1" ];then
  jieshao=vivo1指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/vivo2" ];then
  jieshao=vivo2指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
if [ -d "/data/adb/zhiwen/mc/yijia" ];then
  jieshao=一加指纹特效替换脉冲
  zhiwen="，$jieshao $zhiwen"
fi
  echo "$zhiwen" >> $TMPDIR/module.prop