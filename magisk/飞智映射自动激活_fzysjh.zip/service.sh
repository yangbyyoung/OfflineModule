#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
until [[ $(getprop sys.boot_completed) = 1 ]] && [[ $(getprop dev.bootcomplete) = 1 ]] && [[ $(getprop service.bootanim.exit) = 1 ]] && [[ $(getprop init.svc.bootanim) = stopped ]]; do
    sleep 5
done

sleep 5

# Init inject files path
path1=/sdcard/Documents/flydigi/server/FZToolHelperAndroid.jar
path2=/sdcard/Documents/flydigi/server/motionelf_server
path3=/sdcard/Documents/flydigi/server/libmotionelf_server.so
path1_old=/sdcard/Android/data/com.fdg.flashplay.farsee/files/Documents/server/FZToolHelperAndroid.jar
path2_old=/sdcard/Android/data/com.fdg.flashplay.farsee/files/Documents/server/motionelf_server
path3_old=/sdcard/Android/data/com.fdg.flashplay.farsee/files/Documents/server/libmotionelf_server.so

fzjh_jar=/data/local/tmp/FZToolHelperAndroid.jar
fzjh_server=/data/local/tmp/motionelf_server
fzjh_lib=/data/local/tmp/libmotionelf_server.so

# Delete previous inject files
if [ -f $fzjh_jar ]; then
	rm -rf $fzjh_jar
fi

if [ -f $fzjh_server ]; then
	rm -rf $fzjh_server
fi

if [ -f $fzjh_lib ]; then
	rm -rf $fzjh_lib
fi

# Copy inject files
if [ -f $path1 ]; then
	    cp $path1 $fzjh_jar
		chmod 0777 $fzjh_jar
    echo "OK: jar file copied successfully" >&2
elif [ -f $path1_old ]; then
        cp $path1_old $fzjh_jar
		chmod 0777 $fzjh_jar
    echo "OK: jar file copied successfully from old path" >&2
else
    echo "ERROR: No found jar file! " >&2
    exit 1
fi

if [ -f $path2 ]; then
	    cp $path2 $fzjh_server
		chmod 0777 $fzjh_server
    echo "OK: server file copied successfully" >&2
elif [ -f $path2_old ]; then
        cp $path2_old $fzjh_server
		chmod 0777 $fzjh_server
    echo "OK: server file copied successfully from old path" >&2
else
    echo "ERROR: No found server file! " >&2
    exit 1
fi

if [ -f $path3 ]; then
	    cp $path3 $fzjh_lib
		chmod 0777 $fzjh_lib
    echo "OK: so file copied successfully" >&2
elif [ -f $path3_old ]; then
        cp $path3_old $fzjh_lib
		chmod 0777 $fzjh_lib
    echo "OK: so file copied successfully from old path" >&2
else
    echo "ERROR: No found so file! " >&2
    exit 1
fi

# Execute mapping service 
if [ -x $fzjh_server ]; then
    exec $fzjh_server &
else
    echo "Cannot execute fzjh_server" >&2
    exit 1
fi
