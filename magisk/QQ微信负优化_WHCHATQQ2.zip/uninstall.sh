#!/sbin/sh

file="
/data/system/ifw/com.tencent.mm$.xml
/data/system/ifw/com.coolapk.market$.xml
/data/system/ifw/com.tencent.mobileqq$.xml
/data/system/ifw/com.tencent.tim$.xml
/data/media/0/Android/QQ微信负优化
"
for i in $file;do
test -e "$i"  && rm -rf "$i"
done