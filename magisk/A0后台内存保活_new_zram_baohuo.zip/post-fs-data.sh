#! /bin/sh
MODDIR=${0%/*}
su -c /data/adb/modules/new_zrambaohuo/service.sh
su -c /data/adb/modules/new_zrambaohuo/lock.sh