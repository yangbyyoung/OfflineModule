#!/system/bin/sh

grep_prop() {
    local REGEX="s/^$1=//p"
    shift
    local FILES="$@"
    [[ -z "$FILES" ]] && FILES='/system/build.prop'
    sed -n "$REGEX" ${FILES} 2>/dev/null | head -n 1
}

#清理面具日志(来自旧梦)
chmod 777  /cache/magisk.log
rm -rf /cache/magisk.log
touch /cache/magisk.log
chmod 000  /cache/magisk.log
MODDIR=${0%/*}


RIRU_PATH="/data/adb/riru"
RIRU_PROP="$(magisk --path)/.magisk/modules/riru-core/module.prop"
TARGET="${RIRU_PATH}/modules"
LSPMISC_PATH=$(cat /data/adb/lspd/misc_path)
LSPBASE_PATH="/data/misc/$LSPMISC_PATH"

EDXPMISC_PATH=$(cat /data/adb/edxp/misc_path)
EDXPBASE_PATH="/data/misc/$EDXPMISC_PATH"
EDXPLOG_PATH="${EDXPBASE_PATH}/0/log"

LSP_NEW_LOG_PATH="/data/adb/lspd/log"
LSPLOG_PATH="${LSPBASE_PATH}/log"
#定义整型变量
a=1
   while true
    do
sleep 3
mkdir -p ${LSPLOG_PATH}
rm "${LSPLOG_PATH}/modules.log" 
rm "${LSPLOG_PATH}/all.log" 
mkdir -p  ${LSPBASE_PATH}
rm "${LSPBASE_PATH}/0/log/error.log" 
rm "${LSPBASE_PATH}/0/log/all.log" 

mkdir -p ${EDXPLOG_PATH}
rm "${EDXPLOG_PATH}/error.log" 
rm "${EDXPLOG_PATH}/all.log" 

mkdir -p ${LSP_NEW-LOG_PATH}
rm "${LSP_NEW_LOG_PATH}/modules.log" 
rm "${LSP_NEW_LOG_PATH}/all.log" 
 
 mkdir -p /cache/
 rm /cache/magisk.log
a=$(($a+1))
echo $a
     if [[ $a>5 ]]; then
            break
        fi
done

   
