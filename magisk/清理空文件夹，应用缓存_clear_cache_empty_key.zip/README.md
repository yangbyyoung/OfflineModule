## 清理空文件(夹)，应用缓存

### 说明
#### 这个清理空文件夹，在我看来用处不大，对于强迫症患者可能有点用
#### 模块会扫描应用文件夹下的所有带 'cache' 的文件夹，就体验来说，比较暴力，可能会误杀一些应用，例如[阅读](https://www.coolapk.com/apk/io.legado.app.release)里的小说缓存，QQ/微信的登陆信息，以及90%的手机网游(数据包)。
#### 模块目前已经给`QQ` `微信` `阅读` 以及腾讯的一些应用白名单，不会被清理。
#### 所以建议将你的游戏包名放入模块配置文件`/data/adb/(lite_)modules/clear_cache_empty_key/notclear.conf`

- ### 0.04
 > #### 日志保存在`/data/adb/modules(lite_modules)/clear_cache_empty_key/log`下。
 > #### `cachedir`代表缓存文件夹，`emptyfile`代表空文件，`emptydir`代表空文件夹。
 > #### 模块主要扫描`/data/data` 和 `/data/media/[0-9]/Android/data`
 > #### 模块采用crond 定时任务，每隔3个小时执行一次。
 
- ### 0.05
 > #### 模块改为扫描`/data/user/*[0-9]*` 和 `/data/media。`

- ### 0.06
 > #### 扫描`/data/user/*[0-9]*`无法清理所有目录(`/data/user/0` 是`/data/data`链接出来的，所以不存在。 )
 > #### 改为扫描`/data/user /data/data /data/media`
 
- ### 0.07
 > #### 修复模块内存信息显示不正确的bug。
 
- ### 0.08
 > #### 尝试修复微信过期登陆的问题(表示没遇到过，小声逼逼。)
 
- ### 0.09
 > #### 腾讯都是垃圾！！！
 
- ### 0.10
 > #### 最后一次更新了！停更了！
 
- ### 0.11
 > #### 被迫更新？？采用新的crond方法。
 
- ### 0.12
 > #### 应要求，将`cache`文件夹的扫描目录改为`/data/user` `/data/data` `/data/media/*[0-9]*/Android`
 > #### 其余功能与0.11相同。
 
- ### 0.13
 > #### 改为每天早上`7点`清理。
 > #### 更正部分清理bug。

- ### 0.14
 > #### 目前仅清理`规范`的缓存文件夹。
 > #### 不再清理`空文件`，仅清理空文件夹。
 > #### 模块禁用清理的黑名单在模块目录`notclearapps.conf`里边(`/data/adb/(lite_)modules/clear_cache_empty_key/notclearapps.conf`)，需要在里边填写包名。
 
- ### 0.15
 > #### 模块禁用清理的`黑名单`更改为，模块目录`notclear.conf`里边(`/data/adb/(lite_)modules/clear_cache_empty_key/notclear.conf`)，需要在里边填写关键词，例如`Tencent` `tencent`。
 
- ### 0.18
 > #### 修正部分Bug，应要求添加清理垃圾文件的功能，配置文件在`/data/adb/(lite_)modules/clear_cache_empty_key/clear.conf`，实现功能是参考了 [@Kotch](http://www.coolapk.com/u/1132618) 大佬的清理黑名单列表(因为懒得再写一份，Kotch的已经写的很好了)。
 > #### 我也不知道为啥老的模块突然又被翻出来，就这样吧，我感觉也没啥更新的必要了。
 