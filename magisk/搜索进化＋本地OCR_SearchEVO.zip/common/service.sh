while [ ! -d /sdcard/Android ] || [ $(getprop "sys.boot_completed") != 1 ]; do sleep 1; done
UID=$(id -u); PKG=com.jwg.searchEVO; DIR=/data/user/$UID/$PKG/shared_prefs; PFR=$DIR/${PKG}_preferences.xml; SCC=$DIR/ScreenContentConfig.xml; INT="intent:#Intent;launchFlags=0x00800000;component=$PKG/.settings.DialogActivity;end"
if pm path $PKG | grep -q /system/app; then pm install /system/app/SearchEVO/base.apk; fi
touch -t 198001010000.00 *.xml; cp -pfu *.xml $DIR
sed -i 's/ASSIST/ACCESSIBILITY/' $PFR #将屏幕内容获取方式设为无障碍模式
sed -i 's/SHARE/SCAN_QR/' $SCC #将分享按钮替换为识别屏幕二维码
if grep -q '"corner_enable"' $PFR; then sed -i 's/corner_enable" value="false/corner_enable" value="true/' $PFR; else sed -i '$ s/^/    <boolean name="corner_enable" value="true" \/>\n/' $PFR; fi #开启手势功能
am force-stop $PKG; am start $INT; input keyevent 3 #重启主程序使新配置生效
pm grant $PKG android.permission.CAMERA #获取相机权限用于扫码功能
pm grant $PKG android.permission.READ_CONTACTS allow #获取联系人权限
pm grant $PKG android.permission.READ_SMS allow #获取短信权限
pm grant $PKG android.permission.WRITE_SECURE_SETTINGS #防止无障碍服务失效
settings put secure enabled_accessibility_services $(echo $(settings get secure enabled_accessibility_services):$PKG/$PKG.accessibility.MyAccessibilityService | sed 's/:/\n/g' | sort -u | tr -s '\n' ':' | sed 's/:$//g') #开启无障碍服务
settings put secure assistant $PKG/.assist.AssistService #设为默认数字助理应用
settings put secure voice_interaction_service $PKG/.assist.AssistService
appops set $PKG READ_CLIPBOARD allow #获取剪贴板读取权限
appops set $PKG GET_USAGE_STATS allow #获取使用情况访问权限
appops set $PKG PROJECT_MEDIA allow #搜索进化获取投影权限
appops set com.jwg.copyevo PROJECT_MEDIA allow #本地OCR获取投影权限