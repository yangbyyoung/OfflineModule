#!/system/bin/sh
#202104012
#Petit-Abba
#Environment Variables

# The system's busybox is more comfortable.
PATH="/system/bin"
# Executable Binary File Location.
