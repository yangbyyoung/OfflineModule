#!/system/bin/sh

#重新启动MIUI云控
function restart_mi_thermald(){
pgrep -f mi_thermald | while read pid ;do
	kill -15 $pid
	kill -9 $pid
done
for i in $(which -a mi_thermald)
do
	nohup "$i" >/dev/null 2>&1 &
done
}


function run_restart_mi_thermald(){
local a=0
while :;do
a=$(($a + 1))
if test "$(ls /data/vendor/thermal/config/*.conf 2>/dev/null )" != "" ;then
	restart_mi_thermald
	break
fi
	sleep 10s 
test "$a" = "18" && break
done
}

run_restart_mi_thermald


