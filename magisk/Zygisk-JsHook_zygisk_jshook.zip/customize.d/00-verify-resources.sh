ui_print "- Verify module resources"

function do_verify() {
    [ -f "$MODPATH/$1" ] || abort "! Module resource '$1' not found"

    (echo "$2  $MODPATH/$1" | sha256sum -c -s -) || abort "! Module resource '$1' verify failed"

    ui_print "  '$1' verified"
}

do_verify classes.dex 01854021c0f154e63c057a4dc3f12d1882737e383457a8aa061c152ae0add483
do_verify customize.d/10-enforce-api-version.sh 2718f3493bcb01c30c770169ac88eeacfffa4bb0414813d76beb62d6854b7b6e
do_verify customize.d/11-enforce-arch.sh cb4066ff670fce4b0d4c9df752808d25c9b93e99f6d3809a16e7637308b6cb90
do_verify customize.d/20-enforce-magisk-version.sh 39c4cf061fd705ddfa9c3c473d4d506295dd2b409c933a2cd5fa46057a8bf7ef
do_verify customize.d/25-check-incompatible-module.sh 8574e539dfb713a83bedd94bb8e2187fe9fcc1e4a2c06632055925760b6f0fd2
do_verify customize.d/30-place-libraries.sh 6eb1ac5b571614f9c0a782c5daf82ff72ac8ee5b61b63855c55d3c1152071f66
do_verify customize.d/40-initialize-data-directory.sh 10bf0e0c8db05158b2a53845af4bb7a1bb24567f0a0c35b6680d0cc5b8f82e42
do_verify customize.d/90-restore-module-permission.sh 0f36308f5bd915778712ef2abd003628ea6178614a56455a8ac171f6b2a6b8cd
do_verify daemon 3ab846f2190a4528e5e7b1a42d752d712fd8873a56c8200fbc5eb41924973cd2
do_verify daemon.apk d5929caec09d95a319264726c9ea6af9d1ceea0cdd55b7de1f3d5e6fdf62b255
do_verify module.prop ccc46ca421cc5f1b2f1f484d135c4883649ca6ebe74064ae7c91373daa48deeb
do_verify post-fs-data.sh 324b919278869b862215c2488db55a7b4d9451d539d30ddcf42ba8f5400dbe49
do_verify service.sh 38c8926dedfec18a6ff2dbf31bfaba3c7b316b3de0720306c1e998eff9739252
do_verify uninstall.sh f7bfcf59f645b48c830b35d61dd357fccb1fb67e2fc49c11a83b2963548b73a0
do_verify zygisk/arm64-v8a.so ab6262f5eef0eff74c4651cb93a5b1eb62d3aecae62f5c5cfeab42b81b7098d9
do_verify zygisk/armeabi-v7a.so 722ee14684bd478936f08631f2b36cb7bdfe00e92a3d1c09b6e92dd0ca217e04
do_verify zygisk/x86.so 7287d2345050df81bcc9b9e3a1656ca7d2246b34c19143f1e420e0564f28de56
do_verify zygisk/x86_64.so 857ce6fd81d2b25227e395c616a446017af1ffb8f47b39896a2cb75304c0fb67


unset -f do_verify