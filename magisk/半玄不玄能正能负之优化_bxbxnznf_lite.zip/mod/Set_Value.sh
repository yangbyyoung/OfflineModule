MODDIR=${0%/*}
test ! -e $MODDIR/log && mkdir -p $MODDIR/log
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH

# 写个勾巴注释

set_value() {
	[ ! -f "$2" ] && return 1
    chmod +w "$2" 2> /dev/null
	if ! echo "$1" > "$2" 2> /dev/null
	then
		echo "$(date +%y年%m月%d日%H点%M分): - 写入失败: $2 → $1" >> $MODDIR/log/set_value.log
		return 1
	fi
		echo "$(date +%y年%m月%d日%H点%M分): - 写入成功: $2 → $1" >> $MODDIR/log/set_value.log
}

set_value "0" /proc/sys/kernel/sched_autogroup_enabled

set_value "0" /proc/sys/kernel/sched_schedstats

set_value "0" /proc/sys/vm/page-cluster

set_value "0" /proc/sys/vm/oom_dump_tasks

set_value "0" /sys/module/subsystem_restart/parameters/enable_ramdumps

set_value "0" /sys/module/binder/parameters/debug_mask
set_value "0" /sys/module/binder_alloc/parameters/debug_mask

set_value "0" /sys/module/msm_show_resume_irq/parameters/debug_mask
set_value "N" /sys/kernel/debug/debug_enabled

set_value "off" /proc/sys/kernel/printk_devkmsg

set_value "0" /sys/module/lowmemorykiller/parameters/enable_lmk
set_value "0" /sys/module/lowmemorykiller/parameters/debug_level
set_value "100" /proc/sys/vm/swappiness
set_value "256" /proc/sys/vm/watermark_scale_factor
set_value "102400" /proc/sys/vm/extra_free_kbytes

set_value "3000" /proc/sys/vm/dirty_expire_centisecs

set_value "20" /proc/sys/vm/stat_interval

set_value "16" /sys/block/sda/queue/iosched/quantum
set_value "1" /sys/block/sda/queue/iosched/back_seek_penalty

set_value "1" /dev/cpuset/sched_relax_domain_level
set_value "1" /dev/cpuset/system-background/sched_relax_domain_level
set_value "1" /dev/cpuset/background/sched_relax_domain_level
set_value "1" /dev/cpuset/foreground/sched_relax_domain_level
set_value "1" /dev/cpuset/top-app/sched_relax_domain_level

set_value "128" /sys/block/sda/queue/read_ahead_kb
set_value "128" /sys/block/sde/queue/read_ahead_kb
set_value "128" /sys/block/mmcblk0/queue/read_ahead_kb
set_value "128" /sys/block/dm-5/queue/read_ahead_kb
set_value "128" /sys/block/zram0/queue/read_ahead_kb
set_value "36" /sys/block/sda/queue/nr_requests

for i in $(find /sys/block/*/queue/iostats  /sys/block/*/queue/nomerges);do
set_value "0" "$i"
done