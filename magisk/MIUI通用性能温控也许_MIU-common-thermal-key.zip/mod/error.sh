settings put global hide_error_dialogs 1
settings put secure disabled_print_services com.android.bips/.BuiltInPrintService
settings put global passport_ad_status OFF

settings put global GPUTUNER_SWITCH true

