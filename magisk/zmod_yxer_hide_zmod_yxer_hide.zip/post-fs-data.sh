MODDIR=${0%/*}


if [ "$(magisk -V)" -lt 26300 ]; then
  touch "$MODDIR/disable"
fi
