MODDIR=${0%/*}
chown root.root /data/system/theme/rights
chmod 000 /data/system/theme/rights
chattr +i /data/system/theme/rights
chmod 731 /data/system/theme

