if [ ! -f "/data/adb/magisk/busybox" ] && [ ! -f "/data/adb/ksu/bin/busybox" ]; then
   abort "此设备可能不兼容，请反馈！"
fi
if [ "$(ls /dev/block/by-name | wc -l)" == "0" ]; then
   abort "此设备可能不兼容，请反馈！"
fi

unzip -o "$ZIPFILE" -x 'META-INF/*' customize.sh -d $MODPATH >&2
ui_print "
-- 出于安全考虑，模块会在每次开机防护后禁用30秒

-- 原理: 把核心分区设备块从/dev移除

-- 由于提前移除了挂载点，所以大部分格机命令会找不到对应的分区

-- 部分设备支持执行模块目录stop.sh文件临时关闭保护

-- 修改 'partition.ini' 文件可以自定义保护分区

-- 出现影响使用的问题请立即卸载本模块并反馈
"
set_perm_recursive $MODPATH 0 0 0755 0644

