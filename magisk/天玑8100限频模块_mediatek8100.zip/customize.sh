SKIPUNZIP=0


  ui_print "*******************************"
  ui_print "    正在刷入全新V2版本"
  ui_print "    由NewtoPhone 制作"
  ui_print "*******************************"
  ui_print "人生处处有望，你也是，(*ﾟ∀ﾟ)(≧∇≦)b "
  ui_print "*******************************"



on_install()
sleep 1
chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
echo 1700000 > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo 2100000 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
#无法描述的事情('・ω・')

mkdir 777 /data/cron.d

# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644

