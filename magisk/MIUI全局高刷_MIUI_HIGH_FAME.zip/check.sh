app='PowerKeeper'
packagename='com.miui.powerkeeper'

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

echo ""
echo "∞————————————————————————∞"
echo "- 检查设备状态中……"
check_lite=$( pm list package | grep -w "com.miui.powerkeeper" | wc -l)

test "$check_lite" -lt "1" && abort "－ 未找到电量和性能！"

for i in `find /system /system_ext /vendor /product -iname "$app" -type d`;do
	folder=`correctpath "$i"`
	test -e $folder && mktouch "$MODPATH$folder/.replace"
	test -d "$folder/lib" && cp -rf "$folder/lib" "$MODPATH$folder/lib"
done

check_freeze=$(pm list package -d | grep -w "com.miui.powerkeeper" | wc -l )

test "$check_freeze" -ge "1" && {
pm enable com.miui.powerkeeper >/dev/null 2>&1 && echo "－ 已经解冻MIUI 电量和性能！"
}

a=0
find /data/adb/modules -iname "PowerKeeper.apk" -type f 2>/dev/null | while read file ;do
mod_id=$(echo $file | cut -d '/' -f5 )
test "$mod_id" = "MIUI_HIGH_FAME" && continue
touch "/data/adb/modules/$mod_id/disable" && a=$(($a+1))
done 
test "$a" -ge "1" && echo "- 已经禁用冲突模块！"
echo "- 完成！"
echo ""
echo "∞————————————————————————∞"
