while [ ! -d /sdcard/Android ] || [ $(getprop "sys.boot_completed") != 1 ]; do sleep 1; done
pm grant com.jwg.searchEVO android.permission.CAMERA #获取相机权限用于扫码功能
pm grant com.jwg.searchEVO android.permission.WRITE_SECURE_SETTINGS #防止无障碍服务失效
settings put secure enabled_accessibility_services $(echo $(settings get secure enabled_accessibility_services):com.jwg.searchEVO/com.jwg.searchEVO.accessibility.MyAccessibilityService | sed 's/:/\n/g' | sort -u | tr -s '\n' ':' | sed 's/:$//g') #开启无障碍服务
settings put secure assistant com.jwg.searchEVO/.assist.AssistService #设为默认数字助理应用
settings put secure voice_interaction_service com.jwg.searchEVO/.assist.AssistService
appops set com.jwg.searchEVO READ_CLIPBOARD allow #获取剪贴板读取权限
appops set com.jwg.searchEVO GET_USAGE_STATS allow #获取使用情况访问权限
appops set com.jwg.searchEVO PROJECT_MEDIA allow #搜索进化获取投影权限
appops set com.jwg.copyevo PROJECT_MEDIA allow #本地OCR获取投影权限
sed -i 's/ASSIST/ACCESSIBILITY/' /data/user/*/com.jwg.searchEVO/shared_prefs/com.jwg.searchEVO_preferences.xml #将屏幕内容获取方式设为无障碍模式
cp -u ScreenContentConfig.xml /data/user/*/com.jwg.searchEVO/shared_prefs; sed -i 's/SHARE/SCAN_QR/' /data/user/*/com.jwg.searchEVO/shared_prefs/ScreenContentConfig.xml #将分享按钮替换为识别屏幕二维码
if grep -q '"corner_enable"' /data/user/*/com.jwg.searchEVO/shared_prefs/com.jwg.searchEVO_preferences.xml; then sed -i 's/corner_enable" value="false/corner_enable" value="true/' /data/user/*/com.jwg.searchEVO/shared_prefs/com.jwg.searchEVO_preferences.xml; else sed -i '$ s/^/    <boolean name="corner_enable" value="true" \/>\n/' /data/user/*/com.jwg.searchEVO/shared_prefs/com.jwg.searchEVO_preferences.xml; fi #开启手势功能
am force-stop com.jwg.searchEVO