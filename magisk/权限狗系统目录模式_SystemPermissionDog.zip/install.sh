SKIPMOUNT=false
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用

print_modname() {
  ui_print "*******************************"
  ui_print "  KernelSU Module"
  ui_print "     By linying"
  ui_print "*******************************"
  ui_print "建议安装压缩包内的权限狗后重启，否则部分机型卡可能第二屏"
  ui_print "*******************************"
  ui_print "警告⚠⚠⚠本模块仅为自用分享，出现任何问题请自行解决，因为刷入导致黑砖等概不负责"
  ui_print "刷入即为您同意此免责声明"
  ui_print "*******************************"
}

#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  mkdir "$MODPATH/system"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  #设置权限，基本不要去动
}

LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=true
