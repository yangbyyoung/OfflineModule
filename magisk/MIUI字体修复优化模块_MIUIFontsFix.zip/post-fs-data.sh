#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

(

until [ $(getprop sys.boot_completed) -lt 1 ]; do

   for i in `ls /data/adb/modules/`

   do

   rm -rf "/data/adb/modules/$i/system/fonts/"Mi*.*tf/ >/dev/null 2>&1

   done

   echo "id=MIUIFontsFix

   name=MIUI字体修复优化模块

   version=V1.0

   versionCode=1

   author=数码迷（微信公众号ID：wanshuma）QQ群：773665666

   description=一个模块即可解决MIUI系统字体的一系列问题！例如：刷入Magisk字体模块不全局生效、卡顿、在某些APP中不显示字重......等等，并且不会引起“卡米”的现象。【MIUI全局字体修复✅ 卡顿修复✅ 本模块已生效✅】" > $MODDIR/module.prop

   for i in `ls /data/adb/modules/`

   do

   if [[ -f "/data/adb/modules/$i/system/fonts/ShuMaMi-Subset.ttc" ]] && [[ ! -f "/data/adb/modules/$i/system/fonts/no_replace" ]];then

   rm -rf "/data/adb/modules/$i/system/etc" >/dev/null 2>&1

   rm -rf "/data/adb/modules/$i/system/system_ext" >/dev/null 2>&1

   cp -rf "$MODDIR/files/etc" "/data/adb/modules/$i/system/etc" >/dev/null 2>&1

   cp -rf "$MODDIR/files/system_ext" "/data/adb/modules/$i/system/system_ext" >/dev/null 2>&1

   echo "id=MIUIFontsFix

   name=MIUI字体修复优化模块

   version=V1.0

   versionCode=1

   author=数码迷（微信公众号ID：wanshuma）QQ群：773665666

   description=一个模块即可解决MIUI系统字体的一系列问题！例如：刷入Magisk字体模块不全局生效、卡顿、在某些APP中不显示字重......等等，并且不会引起“卡米”的现象。【MIUI全局字体修复✅ 卡顿修复✅ 字重显示修复✅ 本模块已生效✅】" > $MODDIR/module.prop

   fi

   done

done

)&