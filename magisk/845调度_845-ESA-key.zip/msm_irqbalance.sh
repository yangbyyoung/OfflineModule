#!/system/bin/sh

files=`find /system /vendor /product /system_ext -iname "*msm_irqbalance*" -type f 2> /dev/null `

function correctpath(){
	case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	esac
}


echo ""
echo "∞————————————————————————∞"
echo ""
echo "－ 查找有关msm_irqbalance的文件中……"
echo ""
test -n $file && {
	echo "－ 已找到文件！"
	for i in $files ;do
		echo "－ 路径: $i "
		file=$(correctpath $i)
		mktouch $MODPATH$file
	done && echo "－ 创建空文件成功！"
	echo ""
} || echo "－ 找不到msm_irqbalance相关文件 ！"
echo ""
echo "∞————————————————————————∞"

