# 安装时显示的模块名称
mod_name="MIUI12.5精简：水宝cb（精简部分）"
mod_install_desc="精简系统常驻软件与无用软件，减少后台占用，提高流畅度（黄历，快应用框架，用户与反馈，钱包等），如果有问题请取消$mod_name"
# 安装时显示的提示
mod_install_info="是否安装$mod_name"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{

#黄历
mktouch $MODPATH/system/priv-app/YellowPage/.replace

#快应用框架
mktouch $MODPATH/system/app/HybridPlatform

#用户与反馈（2个）
mktouch $MODPATH/system/app/MiuiBugReport/.replace

mktouch $MODPATH/system/priv-app/MiService/.replace

#钱包（3个）
mktouch $MODPATH/system/app/PaymentService/.replace

mktouch $MODPATH/system/app/NextPay/.replace

mktouch $MODPATH/system/app/Mipay/.replace

#系统常驻软件（5个）
mktouch $MODPATH/system/vendor/app/CACertService/.replace

mktouch $MODPATH/system/vendor/app/CneApp/.replace

mktouch $MODPATH/system/system_ext/app/atfwd/.replace

mktouch $MODPATH/system/system_ext/app/com.qualcomm.qti.services.systemhelper/.replace

mktouch $MODPATH/system/system_ext/app/xdivert/.replace

#无用系统软件
mktouch $MODPATH/system/app/BookmarkProvider/.replace

mktouch $MODPATH/system/app/CarrierDefaultApp/.replace

mktouch $MODPATH/system/app/CatchLog/.replace

mktouch $MODPATH/system/app/HybridPlatform/.replace

mktouch $MODPATH/system/app/HybridAccessory/.replace

mktouch $MODPATH/system/app/PlatformCaptivePortalLogin

mktouch $MODPATH/system/priv-app/Music/.replace

mktouch $MODPATH/system/app/MiuiAccessibility/.replace

mktouch $MODPATH/system/app/TouchAssistant/.replace

mktouch $MODPATH/system/priv-app/Tag/.replace

mktouch $MODPATH/system/app/FrequentPhrase/.replace

mktouch $MODPATH/system/priv-app/BuiltInPrintService/.replace

mktouch $MODPATH/system/app/MiuiVpnSdkManager/.replace

mktouch $MODPATH/system/app/PrintSpooler/.replace/.replace

mktouch $MODPATH/system/app/YouDaoEngine/.replace

mktouch $MODPATH/system/app/Joyose/.replace

mktouch $MODPATH/system/app/ModemTestBox/.replace

mktouch $MODPATH/system/app/WMService/.replace

mktouch $MODPATH/system/system_ext/app/WAPPushManager/.replace

mktouch $MODPATH/system/app/Traceur/.replace

mktouch $MODPATH/system/app/WallpaperBackup/.replace

mktouch $MODPATH/system/app/KeyChain/.replace

mktouch $MODPATH/system/priv-app/MiShare/.replace

mktouch $MODPATH/system/app/BasicDreams/.replace

mktouch $MODPATH/system/app/AutoRegistration/.replace

mktouch $MODPATH/system/app/PacProcessor/.replace

mktouch $MODPATH/system/app/AiAsstVision/.replace

mktouch $MODPATH/system/app/Cit/.replace

mktouch $MODPATH/system/priv-app/BlockedNumberProvider/.replace

mktouch $MODPATH/system/priv-app/UserDictionaryProvider/.replace

mktouch $MODPATH/system/app/com.miui.qr/.replace

mktouch $MODPATH/system/priv-app/MiRcs/.replace

mktouch $MODPATH/system/app/XMCloudEngine/.replace

mktouch $MODPATH/system/priv-app/MusicFX/.replace

mktouch $MODPATH/system/priv-app/CallLogBackup/.replace

mktouch $MODPATH/system/product/app/aiasst_service/.replace

mktouch $MODPATH/system/product/app/talkback/.replace

mktouch $MODPATH/system/app/LiveWallpapersPicker/.replace

mktouch $MODPATH/system/product/app/PowerOffAlarm/.replace

mktouch $MODPATH/system/product/app/PhotoTable/.replace

mktouch $MODPATH/system/priv-app/DMRegService/.replace

mktouch $MODPATH/system/app/SimAppDialog/.replace

mktouch $MODPATH/system/priv-app/ONS/.replace

mktouch $MODPATH/system/system_ext/app/SimContact/.replace

mktouch $MODPATH/system/app/SecurityInputMethod/.replace

mktouch $MODPATH/system/system_ext/priv-app/EmergencyInfo/.replace

mktouch $MODPATH/system/app/MaintenanceMode/.replace

mktouch $MODPATH/system/system_ext/app/QColor/.replace

mktouch $MODPATH/system/app/CompanionDeviceManager/.replace

mktouch $MODPATH/system/app/TranslationService/.replace

mktouch $MODPATH/system/priv-app/LocalTransport/.replace

mktouch $MODPATH/system/app/MiuiDaemon/.replace

mktouch $MODPATH/system/app/PowerChecker/.replace

mktouch $MODPATH/system/app/WapiCertManage/.replace

mktouch $MODPATH/system/app/VsimCore/.replace

mktouch $MODPATH/system/data-app/.replace

mktouch $MODPATH/system_ext/priv-app/WfdService/.replace

mktouch $MODPATH/system/vendor/data-app/.replace

mktouch $MODPATH/system/media/wallpaper/.replace

mktouch $MODPATH/system/app/MiuiAudioMonitor/.replace

mktouch $MODPATH/system/app/XiaomiModemDebugService/.replace

mktouch $MODPATH/system/priv-app/SystemHelper/.replace

mktouch $MODPATH/system/app/BTProductionLineTool/.replace

mktouch $MODPATH/system/app/GFDelmarSetting/.replace

mktouch $MODPATH/system/priv-app/DynamicSystemInstallationService/.replace

mktouch $MODPATH/system/priv-app/ProxyHandler/.replace

    return 0
}

# 按下[音量-]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_no()
{
    return 0
}

