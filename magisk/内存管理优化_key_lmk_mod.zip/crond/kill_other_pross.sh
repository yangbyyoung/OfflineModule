


#测试用
#topapp=`dumpsys window | grep 'mCurrentFocus' | tr '[[:space:]]' '\n' | sed '/\//!d;s|\/.*||g'`
#recentapp=`am stack list | sed '/taskId/!d;s|[[:space:]]taskId=.*[0-9]:[[:space:]]||g;s|\/.*||g;s|[[:space:]]||g;/^com.miui.home$/d' | grep -w "${value}" | head -n 1`

function topapp() {
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d '/' -f1)
	echo "$app"
}

function recentapp(){
	local value="${1}"
	am stack list | sed '/taskId/!d;s|[[:space:]]taskId=.*[0-9]:[[:space:]]||g;s|\/.*||g;s|[[:space:]]||g;/^com.miui.home$/d' | grep -w "${value}" | head -n 1
}

function app_service(){
local packagename="${1}"
	dumpsys activity s | sed '/ServiceRecor/!d;s|}||g;s|.*[[:space:]]||g' | grep -w "${packagename}"
}

function notification_simulation(){
local title="${2}"
local text="${1}"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
	test -z "${title}" && title='10007'
	test -z "${text}" && text='您未给出任何信息'
su -lp 2000 -c "cmd notification post -S messaging --conversation '${title}' --message '${title}':'${text}' 'Tag' '$(echo $RANDOM)' " >/dev/null 2>&1
}

function limit_app_other_pross(){
local target="${1}"
if test "$(echo ${target} | cut -d':' -f2 )" = "别影响我" ;then
	local pross="$(echo ${target} | cut -d':' -f1 )"
		test "$(pgrep -f "${pross}")" = "" && return
		test "$(topapp)" = "${pross}" && return
	if test "$(topapp)" = "${pross}" -o "$(recentapp "${pross}" )" = "${pross}" ;then
			#echo "跳过清理 [ ${pross} ]"
		return
	else
		pgrep -lf "${pross}:" | sed '/:MSF$/d;/:push$/d;/:main$/d;/:play$/d;/:ijkservice$/d' | while read raw ;do
			pid=`echo "${raw}" | awk '{print $1}' `
				name=`echo "${raw}" | awk '{print $2}' | cut -d':' -f2`
					servicename=`app_service "${pross}" | grep -i "${name}"`
						am stop-service "${servicename}"
				kill -9 ${pid} && { sed -i "/^description=/c description="$(date +%H:%M)" ，已回收"${pross}"的附加进程。配置文件在$MODPATH目录下，$MODPATH/Conf是限制应用的名单。" "$MODPATH/module.prop"
			notification_simulation "$(date +%H:%M) ，已回收"${pross}"的附加进程。" "内存管理优化模块"
			}
		done
	fi
else
	local pross="${target}"
		test "$(pgrep -f "${pross}")" = "" && return
		test "$(topapp)" = "${pross}" && return
		if test "$(topapp)" = "${pross}" ;then
			#echo "跳过清理 [ ${pross} ]"
			return
		else
		pgrep -lf "${pross}:" | sed '/:MSF$/d;/:push$/d;/:main$/d;/:play$/d;/:ijkservice$/d' | while read raw ;do
			pid=`echo "${raw}" | awk '{print $1}' `
				name=`echo "${raw}" | awk '{print $2}' | cut -d':' -f2`
					servicename=`app_service "${pross}" | grep -i "${name}"`
						am stop-service "${servicename}"
				kill -9 ${pid} && { sed -i "/^description=/c description="$(date +%H:%M)" ，已回收"${pross}"的附加进程。配置文件在$MODPATH目录下，$MODPATH/Conf是限制应用的名单。" "$MODPATH/module.prop"
			notification_simulation "$(date +%H:%M) ，已回收"${pross}"的附加进程。" "内存管理优化模块"
			}
		done
	fi
fi
}



conf_file="$MODPATH/Conf/清理附加进程.prop"
cat "${conf_file}" | sed '/^#/d;/^[[:space:]]*$/d' | while read package; do
	limit_app_other_pross "$package"
done

