#!/system/bin/sh
MODDIR=${0%/*}

chmod 777 $MODDIR/sh
chmod 777 $MODDIR/init
chmod 777 $MODDIR/init/init.sh

/system/bin/sh $MODDIR/init/init.sh
