# **Module Name**
ColorOS 12 全局120Hz模块
## Changelog
v1.1 优化了文本
v1.1 添加了生效检测
v1.2 修复了c25不生效的bug
v1.2 完全的全局120Hz
v1.3 适配了ratemagic关键词
v1.3 解决双清导致文件不生效的bug
v1.3 将激进模式与保守模式的开关写成一句话(默认是激进模式,修改见enabled_function/refresh_rate_config.sh)
v1.4 删除了重复的配置
## Requirements
- Color OS 12 C22+
## Instructions
这是一个Color OS 12的全局120Hz模块模块，通过修改系统配置文件，修改屏幕刷新率。
- 出于安全考虑，更新模块时请卸载之前的本模块后重启，再安装新的模块，否则新模块不生效。
- 默认系统配置位于data/system/refresh_rate_config.xml
- 如果需要还原改动，请直接卸载本模块。
- 请在系统升级前卸载本模块。
- 受技术能力，财力，以及系统迭代的限制，模块可能并不稳定(尽管开发者在OPPO Find X3 ColorOS 12 C24/25上顺利运行)，因本模块造成的资料、财产损失与开发者无关，当您安装本模块即表示同意该条内容。
## Links
coolapk@Hash
[Module XDA Forum Thread](https://forum.xda-developers.com/apps/magisk/module-url-here "Module official XDA thread")
[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
