#!/system/bin/sh
#脚本来自@coolapk 1007

[ "$(id -u)" != "0" ] && echo "请您先授予root 权限并且先输入su，再输入qw" && exit

MODPATH=/data/adb/modules/WHCHATQQ 
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
codeversion='0.52'

alias free=$BUSYBOXDIR/free

opts(){
	reset
	clear
	echo ""
	echo "☞=======================================☜"
	checksate
	echo ""
	echo "●——————欢迎来到QQ微信小(负？)优化(版本: $codeversion)————●"
	echo ""
	echo ""
	echo "0. 查看使用手册"
	echo ""
	echo "1. 定时任务管理"
	echo ""
	echo "2. pm命令禁用/启用组件"
	echo ""
	echo "3. ifw禁用/启用组件"
	echo -e "\n\e[0;31m如果更新了模块版本，建议请再次启用ifw一遍\e[0m"
	echo ""
	echo "4. 编译应用(增加可用内存/省电)"
	echo ""
	echo "5. 刷新主菜单"
	echo ""
	echo "\e[0;40m6. QQ微信垃圾清理\e[0m"
	echo ""
	echo "7. 退出"
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	read c1
	if [ $c1 == 1 ] ;then
		qwtimetab
	elif [ $c1 == 2 ];then
		controlspm
	elif [ $c1 == 3 ];then
		controlsifw
	elif [ $c1 == 4 ];then
		dexota
	elif [ $c1 == 5 ];then
		reset
		clear
		echo "－刷新中……………"
		sleep 10
		sync
		opts
	elif [ $c1 == 6 ];then
		source $MODPATH/scripts/cleartrash.sh
	elif [ $c1 == 7 ];then
		reset
		clear
		exit
	elif [ $c1 == 0 ];then
		source $MODPATH/scripts/useinfo.sh
	elif [ "$c1" != "*[0-9]*" ];then
		reset
		clear
		opts
	fi
}

qwtimetab(){
	echo ""
	reset 
	clear
	echo "☞=======================================☜"
	echo ""
	echo ""
	echo "●——————定时任务管理————●"
	echo ""
	echo ""
	echo ""
	echo ""
	echo "1. 亮屏清理"
	echo ""
	echo "2. 息屏清理"
	echo ""
	echo "3. 回收空闲内存"
	echo ""
	#echo "4. 睡眠模式(测试版)"
	#echo ""
	echo "4. 回到菜单"
	echo ""
	echo ""
	echo ""
	echo ""
	read c2
	if [ $c2 == 1 ];then
		qwtimetaba
	elif [ $c2 == 2 ];then
		qwtimetabb
	elif [ $c2 == 3 ];then
		qwtimetabc
	#elif [ $c2 == 4 ];then
		#qwtimetabd
	elif [ $c2 == 4 ];then
		opts
	elif [ "$c2" != "*[0-9]*" ];then
		reset
		clear
		qwtimetab
	fi
}


dexota(){
	echo ""
	echo "☞=======================================☜"
	echo ""
	echo ""
	echo ""
	echo "●——————编译应用————●"
	echo ""
	echo ""
	echo ""
	echo ""
	echo "1. 编译系统应用(speed)"
	echo ""
	echo "2. 编译QQ和微信(speed)"
	echo ""
	echo "3. 回到菜单"
	echo ""
	echo ""
	echo ""
	echo ""
	read c10
	if [ $c10 == 1 ];then
		speedapp
		dexota
	elif [ $c10 == 2 ];then
		echo "编译中……"
		echo "请耐心等待……"
		cmd package compile -m speed com.tencent.mobileqq 2>/dev/null
		cmd package compile -m speed com.tencent.mm 2>/dev/null
		dexota
	elif [ $c10 == 3 ];then
		opts
	elif [ "$c10" != "*[0-9]*" ];then
		reset
		clear
		dexota
	fi
}

controlspm(){
	echo ""
	echo "☞=======================================☜"
	echo ""
	echo ""
	echo ""
	echo "●——————Pm命令————●"
	echo ""
	echo ""
	echo ""
	echo " pm 状态约有10秒钟左右的延迟，请耐心等待变化，或者到主菜单刷新"
	echo ""
	echo "1. 禁用组件(QQ)"
	echo ""
	echo "2. 禁用组件(微信)"
	echo ""
	echo "3. 启用组件(QQ)"
	echo ""
	echo "4. 启用组件(微信)"
	echo ""
	echo "5. 回到菜单"
	echo ""
	echo ""
	echo ""
	echo ""
	read c3
	if [ $c3 == 1 ];then
		controlspmdQQ 2>/dev/null
		controlspm
	elif [ $c3 == 2 ];then
		controlspmdMM 2>/dev/null
		controlspm
	elif [ $c3 == 3 ];then
		controlspmeQQ 2>/dev/null
		controlspm
	elif [ $c3 == 4 ];then
		controlspmeMM 2>/dev/null
		controlspm
	elif [ $c3 == 5 ];then
		opts
	elif [ "$c3" != "*[0-9]*" ];then
		reset
		clear
		controlspm
	fi
}


controlsifw(){
	echo ""
	echo "☞=======================================☜"
	echo ""
	echo ""
	echo "●——————ifw管理————●"
	echo ""
	echo ""
	echo " ifw的启用等于pm的禁用组件。"
	echo ""
	echo ""
	echo "1. 禁用"
	echo ""
	echo "2. 启用"
	echo ""
	echo "3. 回到菜单"
	echo ""
	echo ""
	echo ""
	echo ""
	read c4
	if [ $c4 == 1 ];then
		controlsifwe
	elif [ $c4 == 2 ];then
		controlsifwd
	elif [ $c4 == 3 ];then
		opts
	elif [ "$c4" != "*[0-9]*" ];then
		reset
		clear
		controlsifw
	fi
}

backopt(){
	echo ""
	echo ""
	echo ""
	echo "∞————————————————————————∞"
	echo ""
	echo "1.回到菜单"
	echo ""
	echo "2.退出"
	echo ""
	echo "- 请用键盘输入数字，进行选择"
	echo ""
	echo ""
	echo ""
	echo ""
	read choice3
	if [ $choice3 == 1 ];then
		opts
	elif [ $choice3 == 2 ];then
		reset
		clear
		exit
	fi
	echo ""
	echo "∞————————————————————————∞"
}

function checkpmsate(){
	local file="/data/system/users/0/package-restrictions.xml"
	local parten1=$( sed -n "/<pkg name=\"com.tencent.mobileqq\".*/=" $file )
	local parten2=$(sed -n "/<item name=\"com.tencent.mobileqq.mini.app.InternalAppBrandTaskPreloadReceiver\".*\/>/=" $file )
	local overpartentrue=$(sed -n ""$parten1","$parten2"p" $file | sed '/^.*<enabled-components>/,/^.*<\/enabled-components>/d' | grep disable | wc -l )

	local packageqq=`pm list package -3|sed 's/package://'|grep -w 'com.tencent.mobileqq'`
	local packagemm=`pm list package -3|sed 's/package://'|grep -w 'com.tencent.mm'`

	if test $overpartentrue -ge 1 -a "$packageqq" != "";then
		local PMQQS='\e[0;42m 已禁用QQ广播接收器\e[0m'
	else
		local PMQQS=''
	fi
	local parten3=$( sed -n "/<pkg name=\"com.tencent.mm\".*/=" $file )
	local parten4=$(sed -n "/<item name=\"com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver\".*\/>/=" $file )
	local overpartentrue2=$(sed -n ""$parten3","$parten4"p" $file | sed '/^.*<enabled-components>/,/^.*<\/enabled-components>/d' | grep disable | wc -l )
	
	if test $overpartentrue2 -ge 1 -a "$packagemm" != "";then
		local PMMMS='\e[0;42m 已禁用微信广播接收器\e[0m'
	else
		local PMMMS=''
	fi

	if test $overpartentrue -ge 1  -a "$packageqq" != "" -o $overpartentrue2 -ge 1 -a "$packagemm" != "";then
		echo " pm状态: $PMMMS $PMQQS \n"
	fi
}

function speedapp(){
	app="$(pm list package -s|sed 's/package://g')"
	count="$(pm list package -s|sed 's/package://g'|wc -l)"
	mode=speed
	num=0
	for i in $app;do
		cmd package compile -m $mode $i  > /dev/null 2>&1
		num=$(expr $num + 1 )
		percentage=`echo "scale=1;$num*100/$count"|bc 2>/dev/null`
		echo "进度: $percentage%"
	done
}

checksate(){
local WEB=$(grep -w "com.tencent.mm*" $MODPATH/keymod/B/*.sh | grep -v "com.tencent.mobileqq*" | wc -l )
local QQB=$(grep -w "com.tencent.mobileqq*" $MODPATH/keymod/B/*.sh | wc -l )

local WEA=$(grep -w 'com.tencent.mm*' $MODPATH/keymod/A/*.sh | grep -v "com.tencent.mobileqq*" | wc -l )
local QQA=$(grep -w "com.tencent.mobileqq*" $MODPATH/keymod/A/*.sh | wc -l )

[ $WEB -gt 0 ] && WEBsate='\e[0;35m微信\e[0m' || WEBsate=''
[ $QQB -gt 0 ] && QQBsate='\e[0;35mQQ\e[0m' || QQBsate=''
[ $WEA -gt 2 ] && WEAsate='\e[0;35m微信\e[0m' || WEAsate=''
[ $QQA -gt 2 ] && QQAsate='\e[0;35mQQ\e[0m' || QQAsate=''


if test -e $MODPATH/keymod/AK ;then
	AK='\e[0;42m 是 \e[0m'
else
	AK='\e[0;41m 否 \e[0m'
fi

if test -e $MODPATH/keymod/BK ;then
	BK='\e[0;42m 是 \e[0m'
else
	BK='\e[0;41m 否 \e[0m'
fi

if test -e $MODPATH/keymod/CK ;then
	CK='\e[0;42m 是 \e[0m'
else
	CK='\e[0;41m 否 \e[0m'
fi

if test -e $MODPATH/keymod/DK ;then
	DK='\e[0;42m 是 \e[0m'
else
	DK='\e[0;41m 否 \e[0m'
fi

echo ""
echo "●——————当前状态————●"
local Process=`ps -ef | grep -w "$MODPATH/keymod/A" |grep -v grep |awk '{print $2}'| wc -l`
if test $Process -ge 1 ;then
	echo "\n 亮屏清理任务: \e[0;42m 启用 \e[0m 目标应用: $WEAsate $QQAsate \n\n 是否开机自启任务: $AK  \n "
else
	echo "\n 亮屏清理任务: \e[0;41m 禁用 \e[0m "
fi
local Process1=`ps -ef | grep -w "$MODPATH/keymod/B" |grep -v grep |awk '{print $2}'| wc -l`
if test $Process1 -ge 1 ;then
	echo "\n 息屏清理任务: \e[0;42m 启用 \e[0m 目标应用: $WEBsate $QQBsate \n\n 是否开机自启任务:  $BK \n "
else
	echo "\n 息屏清理任务: \e[0;41m 禁用 \e[0m "
fi
local Process2=`ps -ef | grep -w "$MODPATH/keymod/C" |grep -v grep |awk '{print $2}'| wc -l`
if test $Process2 -ge 1 ;then
	echo "\n 回收空闲内存: \e[0;42m 启用 \e[0m \n\n 是否开机自启任务:  $CK \n "
else
	echo "\n 回收空闲内存: \e[0;41m 禁用 \e[0m "
fi
#local Process2=`ps -ef | grep -w "$MODPATH/keymod/D" |grep -v grep |awk '{print $2}'| wc -l`
#if test $Process2 -ge 1 ;then
	#echo "\n 睡眠模式: \e[0;42m 启用 \e[0m \n\n 是否开机自启任务:  $DK \n "
#else
	#echo "\n 睡眠模式: \e[0;41m 禁用 \e[0m "
#fi
local ifwsate=`find /data/system/ifw -name "com.tencent.mobileqq*" -o -name "com.tencent.mm*"|wc -l`
if test $ifwsate -ge 4 ;then
	echo "\n ifw状态: \e[0;42m 启用 \e[0m \n "
elif [ $ifwsate -lt 4 -a $ifwsate -ge 1 ];then
	echo "\n ifw状态: \e[0;43m 部分启用 \e[0m \n "
elif [ $ifwsate -lt 1 ];then
	echo "\n ifw状态: \e[0;41m 禁用 \e[0m \n "
fi

checkpmsate

function M(){
all=$(free -m|grep "Mem"|awk '{print $2}')
use=$( free -m|grep "Mem"|awk '{print $3}')
echo "$(( $use*100/$all ))"
}

echo "————当前内存使用量$(M 2>/dev/null) ％"
echo ""
echo "∞————————————————————————∞"
echo ""
}

controlspmdQQ(){
	local QQ='
	com.tencent.mobileqq/com.tencent.tmdownloader.TMAssistantDownloadService
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.InternalAppBrandTaskPreloadReceiver
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver1
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver2
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver3
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver4
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver5
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver6
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver7
	'
	for i in $QQ;do
		pm disable $i > /dev/null
	done
}

controlspmdMM(){
	local MM='
	com.tencent.mm/com.tencent.tmdownloader.TMAssistantDownloadService
	com.tencent.mm/com.tencent.mm.sandbox.updater.AppUpdaterUI
	com.tencent.mm/com.tencent.mm.sandbox.updater.AppInstallerUI
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver1
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver2
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver3
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver4
	com.tencent.mm/com.tencent.mm.booter.MMReceivers$SandBoxProcessReceiver
	'
	for i in $MM;do
		pm disable $i > /dev/null
	done
}


controlspmeQQ(){
	local QQ='
	com.tencent.mobileqq/com.tencent.tmdownloader.TMAssistantDownloadService
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.InternalAppBrandTaskPreloadReceiver
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver1
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver2
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver3
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver4
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver5
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver6
	com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver7
	'
	for i in $QQ;do
		pm enable $i > /dev/null
	done
}

controlspmeMM(){
	local MM='
	com.tencent.mm/com.tencent.tmdownloader.TMAssistantDownloadService
	com.tencent.mm/com.tencent.mm.sandbox.updater.AppUpdaterUI
	com.tencent.mm/com.tencent.mm.sandbox.updater.AppInstallerUI
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver1
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver2
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver3
	com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver4
	com.tencent.mm/com.tencent.mm.booter.MMReceivers$SandBoxProcessReceiver
	'
	for i in $MM;do
		pm enable $i > /dev/null
	done
}


controlsifwd(){
local ifw=/data/system/ifw
local file="$MODPATH/keymod/ifw"
echo "- 配置权限文件中，请耐心等待……"
[ ! -e "$ifw" ]  && mkdir -p $ifw
cp -rf $file/* $ifw
chmod -R 0700 $ifw
chown -R system:system $ifw
echo "- 完成！"
backopt
}

controlsifwe(){
local file="
/data/system/ifw/com.tencent.mm.xml
/data/system/ifw/com.tencent.mm$.xml
/data/system/ifw/com.tencent.mobileqq.xml
/data/system/ifw/com.tencent.mobileqq$.xml
"
for i in $file;do
rm -rf "$i" 2>/dev/null && echo "已删除"
done
backopt
}


function timeQQA(){
	local QQC='
	com.tencent.mobileqq:tool\*
	com.tencent.mobileqq:qzone\*
	com.tencent.mobileqq:picture\*
	com.tencent.mobileqq:mini\*
	com.tencent.mobileqq:TMAssistantDownloadSDKService\*
	com.tencent.mobileqq:Peak\*
	com.tencent.mobileqq:video\*
	com.tencent.mobileqq:mini_internal\*
	com.tencent.mobileqq:hotpot\*
	'
	for i in $QQC;do
		sed -i "s/$i//g" $MODPATH/keymod/A/QQWEA.sh
		sed -i '/^[[:space:]]*$/d' $MODPATH/keymod/A/QQWEA.sh
	done
}

function timeQQB(){
	local QQC='
	com.tencent.mobileqq:tool\*
	com.tencent.mobileqq:qzone\*
	com.tencent.mobileqq:picture\*
	com.tencent.mobileqq:mini\*
	com.tencent.mobileqq:TMAssistantDownloadSDKService\*
	com.tencent.mobileqq:Peak\*
	com.tencent.mobileqq:video\*
	com.tencent.mobileqq:mini\*
	com.tencent.mobileqq:hotpot\*
	'
	for i in $QQC;do
		sed -i "s/$i//g" $MODPATH/keymod/B/QQWEB.sh
		sed -i '/^[[:space:]]*$/d' $MODPATH/keymod/B/QQWEB.sh
	done
}

function timeWEA(){
	local WEC='
	com.tencent.mm:sandbox\*
	com.tencent.mm:exdevice\*
	com.tencent.mm:appbrand\*
	com.tencent.mm:tools\*
	com.tencent.mm:TMAssistantDownloadSDKService\*
	com.tencent.mm:hotpot\*
	'
	for i in $WEC;do
		sed -i "s/$i//g" $MODPATH/keymod/A/QQWEA.sh
		sed -i '/^[[:space:]]*$/d' $MODPATH/keymod/A/QQWEA.sh
	done
}

function timeWEB(){
	local WEC='
	com.tencent.mm:sandbox\*
	com.tencent.mm:exdevice\*
	com.tencent.mm:appbrand\*
	com.tencent.mm:tools\*
	com.tencent.mm:TMAssistantDownloadSDKService\*
	com.tencent.mm:hotpot\*
	'
	for i in $WEC;do
		sed -i "s/$i//g" $MODPATH/keymod/B/QQWEB.sh
		sed -i '/^[[:space:]]*$/d' $MODPATH/keymod/B/QQWEB.sh
	done
}

function resetQQWEA(){
cat << "key" > $MODPATH/keymod/A/QQWEA.sh

MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

pose="
com.tencent.mm:sandbox*
com.tencent.mm:exdevice*
com.tencent.mobileqq:tool*
com.tencent.mobileqq:qzone*
com.tencent.mm:tools*
com.tencent.mobileqq:TMAssistantDownloadSDKService*
com.tencent.mobileqq:mini*
com.tencent.mm:hotpot*
com.tencent.mobileqq:hotpot*
"

function topapp(){
	app=$(dumpsys window | grep mCurrentFocus | egrep -o "[^ ]*/[^\\}]+" | cut -d/ -f1 )
	echo "$app"
}

function killapp(){
for i in $pose;do
		pgrep -f "$i" | while read PID;do
		test "$(topapp)" = "com.tencent.mm" && break
		test "$(topapp)" = "com.tencent.mobileqq" && break
		kill -9 "$PID"
	done
done
}
function calculate_mem (){
	local memWE=$(dumpsys meminfo com.tencent.mm | grep -w "TOTAL" | head -n 1 | sed 's/[[:space:]]/\n/g' | sed '/^[[:space:]]*$/d' | sed -n '2p' )
	local memQQ=$(dumpsys meminfo com.tencent.mobileqq | grep -w "TOTAL" | head -n 1 | sed 's/[[:space:]]/\n/g' | sed '/^[[:space:]]*$/d' | sed -n '2p')
	test -n "$memQQ" -o  -n "$memWE"  && {
		if test -n "$memQQ" -a -n "$memWE" ;then
			memQQ=$(($memQQ/1024))
			memWE=$(($memWE/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB，微信运行内存"$memWE" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		elif test -n "$memQQ" ;then
			memQQ=$(($memQQ/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，QQ运行内存 "$memQQ" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		elif test -n "$memWE" ;then
			memWE=$(($memWE/1024))
			sed -i "/^description=/c description=[ "$(date +%H:%M)" ] ，微信运行内存 "$memWE" MB。为QQ和微信省内存省电？也许会更加耗内耗电，请自行测试。可在终端输入"qw"，或者请到/data/media/0/Android/QQ微信省电小模块，执行qw.sh脚本。" "$MODPATH/module.prop"
		fi
	}
}

if test -e $MODPATH/disable -o -e $MODPATH/remove ;then
	sed -i "/^description=/c description=[ "$(date +%H:%M)" ]，您已手动停止模块！" "$MODPATH/module.prop"
	exit 1
fi


if test "$(topapp)" != "com.tencent.mm" -a "$(topapp)" != "com.tencent.mobileqq" ;then
killapp
calculate_mem
fi



key
}

function resetQQWEB(){
	cat << "key" > $MODPATH/keymod/B/QQWEB.sh

MODPATH=/data/adb/modules/WHCHATQQ 
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

	pose="
	com.tencent.mm:sandbox*
	com.tencent.mm:exdevice*
	com.tencent.mobileqq:tool*
	com.tencent.mobileqq:qzone*
	com.tencent.mm:tools*
	com.tencent.mm:appbrand*
	com.tencent.mobileqq:picture*
	com.tencent.mobileqq:mini*
	com.tencent.mobileqq:video*
	com.tencent.mobileqq:TMAssistantDownloadSDKService*
	com.tencent.mm:TMAssistantDownloadSDKService*
	com.tencent.mobileqq:Peak*
	com.tencent.mobileqq:mini*
	com.tencent.mm:hotpot*
	com.tencent.mobileqq:hotpot*
"
	sate=`dumpsys window policy | grep -w 'mInputRestricted' | cut -d= -f2`
	if test $sate == true ;then
		for i in $pose;do
			pgrep -f "$i" | while read PID;do
			kill -9 "$PID"
		done
	done
fi
key
}

function timetabTA(){
	reset
	clear
	echo ""
	echo ""
	echo "●——————亮屏任务激进程度选择————●"
	echo ""
	echo "注意！只要是CPU平均消耗量不到1%，就不算特别耗电。"
	echo ""
	echo ""
	echo "1. \e[0;32m30秒\e[0m，平均CPU消耗接近为:\e[0;36m0.1% - 0.2%\e[0m ，卡顿程度:\e[0;46m无\e[0m "
	echo "2. \e[0;32m1分钟\e[0m，平均CPU消耗接近为:\e[0;36m0.1% - 0.2%\e[0m ，卡顿程度:\e[0;46m无\e[0m"
	echo "3. \e[0;32m2分钟\e[0m，平均CPU消耗接近为:\e[0;36m0\e[0m ，卡顿程度:\e[0;46m无\e[0m"
	echo "4. \e[0;32m5分钟\e[0m，平均CPU消耗接近为:\e[0;36m0\e[0m ，卡顿程度:\e[0;46m无\e[0m"
	read timetab
	if test $timetab == 1 ;then
	
	TA 2>/dev/null
		echo "* * * * *  $MODPATH/keymod/A/QQWEA.sh
		* * * * *  sleep 30 && $MODPATH/keymod/A/QQWEA.sh " > $MODPATH/keymod/A/root
	chmod -R 777 $MODPATH/keymod/*
	crond -c $MODPATH/keymod/A
	
	elif [ $timetab == 2 ];then
	TA 2>/dev/null
		echo "* * * * *  $MODPATH/keymod/A/QQWEA.sh " > $MODPATH/keymod/A/root
	chmod -R 777 $MODPATH/keymod/*
	crond -c $MODPATH/keymod/A
	
	elif [ $timetab == 3 ];then
	
	TA 2>/dev/null
		echo "*/2 * * * *  $MODPATH/keymod/A/QQWEA.sh " > $MODPATH/keymod/A/root
		chmod -R 777 $MODPATH/keymod/*
	crond -c $MODPATH/keymod/A
		
	elif [ $timetab == 4 ];then
	
	TA 2>/dev/null
		echo "*/2 * * * *  $MODPATH/keymod/A/QQWEA.sh " > $MODPATH/keymod/A/root
	chmod -R 777 $MODPATH/keymod/*
	crond -c $MODPATH/keymod/A
	
	fi
}



TAO(){
echo ""
echo ""
echo ""
echo ""
echo "●——————亮屏任务清理(配置)————●"
echo ""
echo "1. 为微信开启"
echo ""
echo "2. 为QQ开启"
echo ""
echo "3. 全部开启"
echo ""
echo "4. 回到上级菜单"
echo ""
echo ""
echo ""
chmod -R 777 $MODPATH/keymod/*
read c7
if [ $c7 == 1 ];then
TA
resetQQWEA
timeQQA
crond -c $MODPATH/keymod/A
elif [ $c7 == 2 ];then
TA
resetQQWEA
timeWEA
crond -c $MODPATH/keymod/A
elif [ $c7 == 3 ];then
TA
resetQQWEA
crond -c $MODPATH/keymod/A
elif [ $c7 == 4 ];then
reset
clear
qwtimetaba
fi
TAO
}

TBO(){
echo ""
echo ""
echo ""
echo ""
echo "●——————息屏任务清理(配置)————●"
echo ""
echo "1. 为微信开启"
echo ""
echo "2. 为QQ开启"
echo ""
echo "3. 全部开启"
echo ""
echo "4. 回到上级菜单"
echo ""
echo ""
echo ""
chmod -R 777 $MODPATH/keymod/*
read c8
if [ $c8 == 1 ];then
resetQQWEB
timeQQB
crond -c $MODPATH/keymod/B
elif [ $c8 == 2 ];then
resetQQWEB
timeWEB
crond -c $MODPATH/keymod/B
elif [ $c8 == 3 ];then
resetQQWEB
crond -c $MODPATH/keymod/B
elif [ $c8 == 4 ];then
reset
clear
qwtimetabb
fi
TBO
}


TCO(){
chmod -R 777 $MODPATH/keymod/*
crond -c $MODPATH/keymod/C
qwtimetabc
}


TDO(){
chmod -R 777 $MODPATH/keymod/*
crond -c $MODPATH/keymod/D
qwtimetabd
}


TA(){
ProcessA=`ps -ef | grep -w "$MODPATH/keymod/A" |grep -v grep |awk '{print $2}'`
for i in $ProcessA;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
done
}


TB(){
ProcessB=`ps -ef | grep -w "$MODPATH/keymod/B" |grep -v grep |awk '{print $2}'`
for i in $ProcessB;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
done
reset
clear
qwtimetabb
}

TC(){
ProcessC=`ps -ef | grep -w "$MODPATH/keymod/C" |grep -v grep |awk '{print $2}'`
for i in $ProcessC;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
done
reset
clear
qwtimetabc
}

TD(){
ProcessB=`ps -ef | grep -w "$MODPATH/keymod/D" |grep -v grep |awk '{print $2}'`
for i in $ProcessB;do
echo "$i" | while read PID;do kill -9 "$PID" 2> /dev/null ;done
done
reset
clear
qwtimetabd
}

qwtimetabastart(){
echo ""
echo ""
echo ""
echo ""
echo "●——————开机自启用亮屏任务清理————●"
echo ""
echo ""
echo "1. 启用"
echo ""
echo "2. 不启用"
echo ""
read choose
	if [ $choose == 1 ];then
	touch $MODPATH/keymod/AK && echo "已启用！" 
	elif [ $choose == 2 ];then
	rm -rf $MODPATH/keymod/AK && echo "已禁用！" 
	fi
	reset
	clear
	qwtimetaba
}

qwtimetabbstart(){
echo ""
echo ""
echo ""
echo ""
echo "●——————开机自启用息屏任务清理————●"
echo ""
echo ""
echo "1. 启用"
echo ""
echo "2. 不启用"
echo ""
echo ""
echo ""
echo ""
read chooseb
	if [ $chooseb == 1 ];then
	touch $MODPATH/keymod/BK && echo "已启用！" 
	elif [ $chooseb == 2 ];then
	rm -rf $MODPATH/keymod/BK && echo "已禁用！"
	fi
	reset
	clear
	qwtimetabb
}

qwtimetabcstart(){
echo ""
echo ""
echo ""
echo ""
echo "●——————开机自启用内存回收————●"
echo ""
echo ""
echo "1. 启用"
echo ""
echo "2. 不启用"
echo ""
echo ""
echo ""
echo ""
read choosec
	if [ $choosec == 1 ];then
	touch $MODPATH/keymod/CK && echo "已启用！" 
	elif [ $choosec == 2 ];then
	rm -rf $MODPATH/keymod/CK && echo "已禁用！"
	fi
	reset
	clear
	qwtimetabc
}

qwtimetabdstart(){
echo ""
echo ""
echo ""
echo ""
echo "●——————开机自启用睡眠模式————●"
echo ""
echo ""
echo "1. 启用"
echo ""
echo "2. 不启用"
echo ""
echo ""
echo ""
echo ""
read choosed
	if [ $choosed == 1 ];then
	touch $MODPATH/keymod/DK && echo "已启用！" 
	elif [ $choosed == 2 ];then
	rm -rf $MODPATH/keymod/DK && echo "已禁用！"
	fi
	reset
	clear
	qwtimetabd
}

qwtimetabc(){
echo ""
echo "☞=======================================☜"
echo ""
echo ""
echo "●——————回收空闲内存————●"
echo ""
echo ""
echo ""
echo ""
echo ""
echo "1. 停止进程"
echo ""
echo "2. 开始进程"
echo ""
echo "3. 开机自启用任务管理"
echo ""
echo "4. 返回上一级菜单"
echo ""
echo ""
echo ""
read c9
if [ $c9 == 1 ];then
TC
elif [ $c9 == 2 ];then
TCO
elif [ $c9 == 3 ];then
qwtimetabcstart
elif [ $c9 == 4 ];then
qwtimetab
elif [ "$c9" != "*[0-9]*" ];then
reset
clear
qwtimetabc
fi
}

qwtimetabd(){
echo ""
echo "☞=======================================☜"
echo ""
echo ""
echo "●——————睡眠模式(测试版)————●"
echo ""
echo ""
echo "每天1:20分自动关闭QQ、微信，以及定时清理任务"
echo ""
echo "每天6:20分自动打开QQ、微信，以及定时清理任务"
echo ""
echo "到点了，如果开启睡眠模式了，如果没有到时间，QQ和微信是不会有消息的。"
echo ""
echo "如果需要解除睡眠状态，输入数字4，选择下面的唤醒QQ微信即可。"
echo ""
echo "1. 停止进程"
echo ""
echo "2. 开始进程"
echo ""
echo "3. 开机自启用睡眠模式"
echo ""
echo "4. 唤醒QQ微信！"
echo ""
echo "5. 返回上一级菜单"
echo ""
echo ""
echo ""
read c11
if [ $c11 == 1 ];then
TD
elif [ $c11 == 2 ];then
TDO
elif [ $c11 == 3 ];then
qwtimetabdstart
elif [ $c11 == 4 ];then
sh $MODPATH/keymod/D/wakeup.sh && qwtimetabd
elif [ $c11 == 5 ];then
qwtimetab
elif [ "$c11" != "*[0-9]*" ];then
reset
clear
qwtimetabd
fi
}

qwtimetabb(){
echo ""
echo "☞=======================================☜"
echo ""
echo ""
echo "●——————息屏任务清理————●"
echo ""
echo " 注意！息屏清理任务会清理QQ和微信的小程序！"
echo ""
echo ""
echo ""
echo "1. 停止进程"
echo ""
echo "2. 开始进程"
echo ""
echo "3. 开机自启用任务管理"
echo ""
echo "4. 返回上一级菜单"
echo ""
echo ""
echo ""
read c6
if [ $c6 == 1 ];then
TB
elif [ $c6 == 2 ];then
TBO
elif [ $c6 == 3 ];then
qwtimetabbstart
elif [ $c6 == 4 ];then
qwtimetab
elif [ "$c6" != "*[0-9]*" ];then
reset
clear
qwtimetabb
fi
}

qwtimetaba(){
echo ""
echo "☞=======================================☜"
echo ""
echo ""
echo "●——————亮屏任务清理————●"
echo ""
echo ""
echo ""
echo ""
echo "1. 停止进程"
echo ""
echo "2. 开始进程"
echo ""
echo "3. 设置亮屏任务激进程度"
echo ""
echo "4. 开机自启用任务管理"
echo ""
echo "5. 返回上一级菜单"
echo ""
echo ""
echo ""
read c5
if [ $c5 == 1 ];then
TA && qwtimetaba
elif [ $c5 == 2 ];then
TAO
elif [ $c5 == 3 ];then
timetabTA && qwtimetaba
elif [ $c5 == 4 ];then
qwtimetabastart
elif [ $c5 == 5 ];then
qwtimetab
elif [ "$c5" != "*[0-9]*" ];then
reset
clear
qwtimetaba
fi
}

opts
