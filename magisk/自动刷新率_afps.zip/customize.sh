# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm  $MODPATH/afps/afps    0  0  0755
