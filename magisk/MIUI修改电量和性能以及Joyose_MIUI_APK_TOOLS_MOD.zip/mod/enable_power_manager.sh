#!/system/bin/sh

function enable_apps(){
pm enable "${@}"
	pm unsuspend "${@}"
	pm unhide "${@}"
pm install-existing --user 0 "${@}"
}

enable_apps "com.xiaomi.joyose"
enable_apps "com.miui.powerkeeper"

