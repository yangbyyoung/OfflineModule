#!/system/bin/sh

Module_Path="/data/adb/modules"
       
   if [[ -f "/data/adb/ksud" ]]; then  
          S=$(/data/adb/ksud -V | awk '/ksud/{gsub("ksud ", ""); print substr($0,1,4)}')     
          if [[ "$S" = "v0.3" ]]; then
            Module_Path="/data/adb/ksu/modules"
          fi
   fi

# 设置Manjusaka_thermal路径

thermal_path="$Module_Path/Manjusaka_thermal"

# 更改文件夹及其子文件夹权限为755

find "$thermal_path" -type d -exec chmod -R 755 {} + >/dev/null 2>&1

# 等待3秒钟

sleep 3

# 启动后台进程

nohup "$thermal_path/Manjusaka_thermal.sh" >/dev/null 2>&1 &