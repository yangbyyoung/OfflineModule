echo
echo
echo " 此模块用于黑鲨4s解锁温度墙95度"
echo " 温度墙本身与模块无关，模块本身只是判断机型刷入而已 "
echo " 你可以刷入后删除模块 "
echo
echo


soc=$(cat /sys/devices/soc0/machine | tr 'A-Z' 'a-z')
if [[ "$soc" != "sm8250" ]]; then
  echo
  echo
  echo "此模块仅适用于骁龙870平台"
  echo
  echo

  exit 2
fi

sku=$(getprop ro.product.board | tr 'A-Z' 'a-z')
if [[  "$sku" == "penrose" ]]; then
  echo
else
  echo "此模块仅适用于黑鲨4s"
  exit 2
fi


# 以下内容同 service.sh


slot=$(getprop ro.boot.slot_suffix)
echo '当前系统插槽：' $slot

img=''
case "$sku" in
penrose)
  img='devcfg.img'
;;
*)
  echo '无可用镜像文件'
  exit 2
;;
esac

if [[ -f $MODPATH/$img && -e /dev/block/by-name/devcfg$slot ]]; then
  dd if=$MODPATH/$img of=/dev/block/by-name/devcfg$slot
  echo '安装完成，现在可以重启手机'
  echo '此操作具有一定风险，如果你还没有备份重要数据，建议先备份再重启！'
else
  echo '必要文件路径无法访问，安装失败！'
  exit 2
fi
