﻿#部分代码来源于Rei Ryuki，Github链接：https://github.com/reiryuki

#杜比全景声DOLBY ATMOS™
·杜比应用和编解码文件源于  Dolby™ 杜比实验室
·MIT证书文件仅授权于此Magisk模块，并非杜比应用和编解码文件

#资源来源
- https://dumps.tadiphone.dev/dumps/redmi/alioth qssi-user-12-SKQ1.211006.001-V13.0.3.0.SKHEUXM-release-keys
- MiSound.apk: apkmirror.com
- system_10: https://dumps.tadiphone.dev/dumps/xiaomi/ginkgo ginkgo-user-10-QKQ1.200114.002-V12.0.6.0.QCOEUXM-release-keys
- daxService.apk: https://dumps.tadiphone.dev/dumps/motorola/rhode user-12-S1SR32.38-124-3-a8403-release-keys
- libhwdap.so: Changed HEX fragment from da21499d2582294ffaae39537a04bcaa to 9108c3a04682ef4aadb8d53e26da0253
- libswdap.so: https://dumps.tadiphone.dev/dumps/motorola/rhode user-12-S1SR32.38-124-3-a8403-release-keys changed HEX fragment from da21499d2582294ffaae39537a04bcaa to a46db06a16c511466681452799218539

#特别感谢&捐赠（Rei Ryuki）
- This Magisk Module is always will be free but you can however show us that you are care by making a donations:
- https://ko-fi.com/reiryuki
- https://www.paypal.me/reiryuki
- https://t.me/androidryukimodsdiscussions/2619
·捐赠页面属于Rei Ryuki，支持可自愿捐赠，本人(Huber_HaYu)做的更多的是dax文件调音
