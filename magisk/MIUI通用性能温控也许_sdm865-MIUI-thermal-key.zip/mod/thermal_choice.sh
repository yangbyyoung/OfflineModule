#!/system/bin/sh

function unlock_thermal(){
local target="${1}" 
/data/adb/magisk/busybox chattr -R -i "${target}" >/dev/null 2>&1
/data/adb/magisk/busybox chattr -R -i "${target%/*}" >/dev/null 2>&1
}

function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}

#解除MIUI云控目录限制
function unlock_folder(){
chattr -R -i -a '/data/vendor/thermal'
	mkdir -p '/data/vendor/thermal/config'
		chmod -R 0771 '/data/vendor/thermal'
	chown -R root:system '/data/vendor/thermal'
chcon -R 'u:object_r:vendor_data_file:s0' '/data/vendor/thermal'
}


unlock_thermal "/data/thermal/config"
unlock_thermal "/data/vendor/thermal/config"


dir="${0%/*}"
MODPATH="${dir%/*}"


#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function cp_MTK_thermal_conf_find(){
local MTK_MODPATH_config_DIR="${MODPATH}/thermal/MTK_thermal"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	mkdir -p "${MODPATH}/system/vendor/etc/thermal" "${MODPATH}/system/vendor/etc/.tp"
		touch "${MODPATH}/system/vendor/etc/thermal/.replace"
	touch "${MODPATH}/system/vendor/etc/.tp/.replace"
	find $(magisk --path)/.magisk/mirror/vendor/etc/thermal $(magisk --path)/.magisk/mirror/vendor/.tp -iname "*.conf" -type f -o -iname "*.mtc" -type f 2>/dev/null | while read file ;do
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/thermal/${file##*/}"
		cp -rf "${MTK_MODPATH_config_DIR%/*}/disable_thermal.conf" "${MODPATH}/system/vendor/etc/.tp/${file##*/}"
	done
		cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/thermal"
	cp -rf $MTK_MODPATH_config_DIR/*.conf "${MODPATH}/system/vendor/etc/.tp" 
fi
}

function echo_check_result(){
local check_item=`find /system /system_ext /vendor /product -iname "*thermal*.conf" -type f 2>/dev/null | grep -Ei 'pubgmhd|sgame' | wc -l`
if test "${check_item}" -ge "2" ;then
	echo "true"
fi
}

target_thermal="$(show_value '温控配置')"
if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" != "" ;then
	target_thermal="MTK_${target_thermal}"
	conf_file="${MODPATH}/thermal/MTK/$target_thermal.conf"
else
	conf_file="${MODPATH}/thermal/$target_thermal.conf"
fi

if test "$(echo_check_result)" = "true" ;then
	target_thermal="${target_thermal}"
	conf_file="${MODPATH}/thermal/old_thermal/$target_thermal.conf"
fi

if test -f "$conf_file" ;then
	echo "- 您已选择 [ $target_thermal ℃ ]！"
	cp -rf "$conf_file" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
else
	echo "- 不存在配置文件！"
	echo "- 自动选择46℃温控文件！"
	cp -rf "${MODPATH}/thermal/46.conf" "${MODPATH}/system/vendor/etc/thermal-normal.conf"
fi

find /system /system_ext /vendor /product -iname '*thermal*.conf' -type f 2>/dev/null | sed '/thermal.*map.*\.conf/d;/thermal-normal\.conf/d;/thermald.*devices.*\.conf/d'  2> /dev/null | while read file ;do
	echo "$( correctpath "$file" )" >> "$MODPATH/thermal_list.txt"
done

echo "$(cat "$MODPATH/thermal_list.txt" | sort | uniq )" > "$MODPATH/thermal_list.txt"


cat "$MODPATH/thermal_list.txt" | while read file ;do
	if test "$(show_value '温控配置')" = "nolimit" ;then
		test "$(echo "${file}" | grep -E 'tgame|mgame' )" != "" && continue
	fi
		mkdir -p "${MODPATH}/${file%/*}"
		#test "${file##*/}" = "thermal-chg-only.conf" && continue
	cp -rf "${MODPATH}/system/vendor/etc/thermal-normal.conf" "$MODPATH/${file}"
done

if test "$(show_value '游戏温控配置')" = "是" ;then
	if test "$(echo_check_result)" = "true" ;then
		find /system /system_ext /vendor /product -iname "thermal*tgame.conf" -type f -o -iname "thermal*sgame.conf" -type f -o -iname "thermal*pubgmhd.conf" -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
		mkdir -p "$MODPATH/${truely_path%/*}"
		cp -rf ${MODPATH}/thermal/old_thermal/game.conf "$MODPATH/$truely_path"
	done
else
	find /system /system_ext /vendor /product -iname '*thermal*tgame*.conf' -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
			mkdir -p "$MODPATH/${truely_path%/*}"
	if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" = "" ;then
		cp -rf ${MODPATH}/thermal/thermal-tgame.conf "$MODPATH/$truely_path"
	else
		cp -rf ${MODPATH}/thermal/MTK/MTK_thermal-tgame.conf "$MODPATH/$truely_path"
	fi
		done
	find /system /system_ext /vendor /product -iname '*thermal*mgame*.conf' -type f 2>/dev/null | while read file ;do
		truely_path=`correctpath "$file"`
			mkdir -p "$MODPATH/${truely_path%/*}"
	if test "$(echo $(getprop ro.board.platform) | grep -Ei '^mt.*' )" = "" ;then
		cp -rf ${MODPATH}/thermal/thermal-mgame.conf "$MODPATH/$truely_path"
	else
		cp -rf ${MODPATH}/thermal/MTK/MTK_thermal-mgame.conf "$MODPATH/$truely_path"
	fi
		done
	fi
fi

rm -rf "$MODPATH/thermal_list.txt"

cp_MTK_thermal_conf_find

thermal_dir="${MODPATH}/system/vendor/etc"
target="/data/vendor/thermal/config"

mkdir -p "$target"
cp -rf $thermal_dir/* $target
unlock_folder

sed -i '/description=/d' "$MODPATH/module.prop"
sed -i "/author=.*/a\description= 当前已选择[ $target_thermal ]。温度配置可以在[ $MODPATH/配置.prop ]下选择，有[ 43℃，46℃，48℃，无限制 ]几种选择，更改完执行[ $MODPATH/service.sh ]就行，无需重启。" "$MODPATH/module.prop"



