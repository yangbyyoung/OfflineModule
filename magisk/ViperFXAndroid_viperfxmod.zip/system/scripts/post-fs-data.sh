#!/system/bin/sh
# Kill audioserver PID if it exists already
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID
