#!/system/bin/sh
#官宣粉丝交流群：938499734
#ColorOS玩机交流群：872254795
#禁止商用*转载请获取作者许可
MODDIR=${0%/*}
#refresh rate
mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml
#Resolution
mount --bind $MODDIR/my_product/etc/sys_resolution_switch_config.xml /my_product/etc/sys_resolution_switch_config.xml
mount --bind $MODDIR/my_product/etc/extension/feature_com.coloros.athena.xml /my_product/etc/extension/feature_com.coloros.athena.xml
mount --bind $MODDIR/my_product/etc/extension/sys_osense_decisionmaker_config.xml /my_product/etc/extension/sys_osense_decisionmaker_config.xml
mount --bind $MODDIR/my_product/etc/extension/sys_osense_common_config.xml /my_product/etc/extension/sys_osense_common_config.xml
#Athenabe late
chmod 777 -R $MODDIR/map
chmod 777 -R $MODDIR/SG_Athena
while true; do
$MODDIR/SG_Athena && $MODDIR/map
done
