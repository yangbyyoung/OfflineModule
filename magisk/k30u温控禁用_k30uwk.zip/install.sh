
SKIPMOUNT=false            #安装后自关闭
PROPFILE=false              #system.prop
POSTFSDATA=false          #post-fs-data
LATESTARTSERVICE=false    #service.sh

# 安装
  unzip -o "$ZIPFILE" "system/*" -d $MODPATH >&2
  rm -rf /data/vendor/thermal/config/*
  chattr +i /data/vendor/thermal/config
  rm -rf /data/user/0/com.miui.powerkeeper/*
  rm -rf /data/system/package_cache/*
  rm -rf /data/app/com.miui.powerkeeper/*
  echo "如需恢复，请解压模块以ROOT权限执行一遍uninstall.sh"

# 权限  
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
}