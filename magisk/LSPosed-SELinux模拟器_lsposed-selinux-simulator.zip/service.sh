mount --bind $(dirname "$0")/simulator /sys/fs/selinux/enforce
