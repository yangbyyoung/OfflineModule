rm -rf /data/system/package_cache/*
rm -rf /data/adb/modules_update/MIUI_MiuiGallery
rm -rf /data/adb/modules/MIUI_MiuiGallery
