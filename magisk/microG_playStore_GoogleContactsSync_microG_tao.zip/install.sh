SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
microG_tao
on_install() {
 ui_print "解压中"
 unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/priv-app/GoogleContactsSyncAdapter/GoogleContactsSyncAdapter.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/priv-app/GoogleServicesFramework/GoogleServicesFramework.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/priv-app/PrebuiltGmsCore/PrebuiltGmsCore.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/priv-app/Phonesky/Phonesky.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/priv-app/DroidGuard/DroidGuard.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/sysconfig/org.microG.xml' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/etc/permissions/privapp-permissions-org.microG.xml' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}