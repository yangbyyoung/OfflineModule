echo "
- 卸载CuToolbox，你不卸载我帮你
- Uninstall CuToolbox, otherwise I will help you
"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/AsoulOpt 0 0 0755
rm -rf /data/adb/modules/unity_affinity_opt /data/adb/asopt /data/asopt.conf /sdcard/Android/asopt /sdcard/Android/naki/asopt
