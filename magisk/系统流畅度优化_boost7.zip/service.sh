#利用chrt命令，把和渲染、触控相关的进程优先级设置为实时调度（rt)，进而增加流畅度，注意：不可随意增加进程，因为实时调度是给核心进程使用的

#另外模块附带了一些其他优化
chmod 777 /data/adb/modules/boost7/service.sh

function boost()
{
  pgrep -o $1 | while read pid; do
  echo $pid > /dev/cpuset/top-app/cgroup.procs
  echo $pid > /dev/stune/top-app/cgroup.procs
  chrt -f -p $pid 70
  done
}

boost composer
boost touchpan
boost pq
boost sensors
boost system_server
boost surfaceflinger