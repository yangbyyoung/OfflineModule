function MyPrint() {
 echo "$@"
 sleep 0.03
}

REPLACE="
/system/app/SecurityAdd
/system/app/MiuiSecurityAdd
/system/app/MIUISecurityAdd
/system/priv-app/SecurityCenter
/system/priv-app/MiuiSecurityCenter
/system/priv-app/MIUISecurityCenter
"

enforce_install_from_magisk_app() {
 if $BOOTMODE; then
  ui_print "- Installing from Magisk app"
 else
  ui_print "*********************************************************"
  ui_print "! Install from recovery is NOT supported"
  ui_print "! Recovery sucks"
  ui_print "! Please install from Magisk app"
  abort "*********************************************************"
 fi
}

check_magisk_version() {
 ui_print "- Magisk version: $MAGISK_VER_CODE"
 if [ "$MAGISK_VER_CODE" -lt 24000 ]; then
  ui_print "*********************************************************"
  ui_print "! Please install Magisk v24.0+ (24000+)"
  abort "*********************************************************"
 fi
}

check_magisk_version
enforce_install_from_magisk_app

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
MyPrint "- MIUI13 version ${VERSION}"

function getFileMD5() {
 if [[ -f "$1" ]]; then
  echo $(md5sum "$1" | awk '{ print $1 }')
 else echo "error"
 fi
}

function dalvik_cache() {
 getName=$(basename "$(GetApkPath $1 apk)" '.apk')
 dda=/data/dalvik-cache/arm
 [[ -d ${dda}64 ]] && dda=${dda}64
 for i in $getName; do
  rm -rf $dda/system@*@${i}*
 done
}
  
function Get_Choose() {
 local choose
 local branch
 while :; do
  choose="$(getevent -qlc 1 | awk '{ print $3 }')"
  case "$choose" in
  KEY_VOLUMEUP) branch="0" ;;
  KEY_VOLUMEDOWN) branch="1" ;;
  *) continue ;;
  esac
  echo "$branch"
  break
 done
}

function GetApkPath() {
 file_path=$(pm path "$1" | sed 's/package://g')
 if [[ $(echo "$2" | grep "apk") == "apk" ]]; then
  echo "${file_path}"
 elif [[ $(echo "$2" | grep "path") == "path" ]]; then
  echo "${file_path%/*}"
 elif [[ $(echo "$2" | grep "name") == "name" ]]; then
  echo "${file_path##*/}"
 fi
}

function Other_Apps() {
 if [[ -z "$(pm path com.xiaomi.macro)" ]]; then
  ui_print "- 未安装自动连招，开始安装..."
  install_macro=$(pm install "$MODPATH/Apks/Macro.apk")
  if [[ "$install_macro" == "Success" ]]; then
   ui_print "- 自动连招安装完成"
  fi
 elif [[ $(getFileMD5 "$(GetApkPath com.xiaomi.macro 'apk')") == "9c9a36d9e864ca5b48ede42fca5a0e4a" ]]; then
  ui_print "- 已安装自动连招，跳过安装"
 else ui_print "- 自动连招MD5不统一，重新安装自动连招..."
  install_macro2=$(pm install -r "$MODPATH/Apks/Macro.apk")
  if [[ "$install_macro2" == "Success" ]]; then
    ui_print "- 自动连招安装完成"
  else ui_print "- 自动连招安装失败"
  fi
 fi

 if [[ -z "$(pm path com.xiaomi.barrage)" ]]; then
  ui_print "- 未安装弹幕通知，开始安装..."
  install_barrage=$(pm install "$MODPATH/Apks/Barrage.apk")
  if [[ "$install_barrage" == "Success" ]]; then
   ui_print "- 弹幕通知安装完成"
  fi
 elif [[ $(getFileMD5 "$(GetApkPath com.xiaomi.barrage 'apk')") == "bd07f87017fab0e03570e4231ef2528a" ]]; then
   ui_print "- 已安装弹幕通知，跳过安装"
 else ui_print "- 弹幕通知MD5不统一，重新安装弹幕通知..."
  install_barrage2=$(pm install -r "$MODPATH/Apks/Barrage.apk")
  if [[ "$install_barrage2" == "Success" ]]; then
    ui_print "- 弹幕通知安装完成"
  else ui_print "- 弹幕通知安装失败"
  fi
 fi
}

function App_Install() {
 ApkResult=$(echo "$(GetApkPath $1 'path')" | grep "/data/app/")
 if [[ "$ApkResult" != "" ]]; then
  ui_print "- 发现data/app存在已更新App"
  ui_print "- 为保证开机，正在卸载更新..."
  Uninstall=$(pm uninstall "$1")
  if [[ "$Uninstall" == "Success" ]]; then
   sleep 2
   ui_print "- 卸载更新完成，正在清理缓存...."
   mkdir -p "$MODPATH$(GetApkPath $1 'path')x"
   mv "$MODPATH/$2.apk" "$MODPATH$(GetApkPath $1 'path')x/$(basename $(GetApkPath $1 'apk') '.apk')x.apk"
   sleep 2
   ui_print "- $2 安装完成"
  fi
 else
  mkdir -p "$MODPATH$(GetApkPath $1 'path')x"
  mv "$MODPATH/$2.apk" "$MODPATH$(GetApkPath $1 'path')x/$(basename $(GetApkPath $1 'apk') '.apk')x.apk"
  ui_print "- $2 安装完成"
 fi
 sleep 2
 rm -rf "$MODPATH/Apks"
 rm -rf /data/system/package_cache/*
}

MyPrint " "
MyPrint "(!) 刷入说明："
MyPrint "- MIUI13放心刷入 MIUI12、12.5存在小BUG 弹幕&通知会一起出现 系统BUG本人无法解决 "
MyPrint "- 原作者酷安@一只小柒夏，二改作者酷安@这只是只兔子"
MyPrint "- 刷入完成重启后将默认删除手机管家游戏加速数据 游戏内工具箱可能无了 游戏空间重新勾选游戏方可解决 卸载模块恢复原版管家"
MyPrint " "
MyPrint "(?) 确认刷入吗？(请选择)"
MyPrint "- 按音量键＋: 刷入 √"
MyPrint "- 按音量键－: 取消 ×"
if [[ $(Get_Choose) == 0 ]]; then
 MyPrint "- 已选择刷入 开始刷入模块..."
 MyPrint "$(Other_Apps)"
 mv $MODPATH/Detection.sh /data/adb/service.d/Delete.sh
 MyPrint "$(App_Install com.miui.securityadd 'SecurityAdd')"
 MyPrint "$(App_Install com.miui.securitycenter 'SecurityCenter')"
else
 rm -rf "$MODPATH"
 rm -rf /data/adb/modules/MIuiBarrage
 rm -rf /data/adb/service.d/Delete.sh
 MyPrint "- 已选择取消 正在删除模块..."
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644
