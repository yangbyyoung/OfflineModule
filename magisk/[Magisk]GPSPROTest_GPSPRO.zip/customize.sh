#!/sbin/sh
SKIPUNZIP=0
AUTOMOUNT=true
ROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE="
"
  ui_print "///解压文件ing///解压完成///重启使用///😘😘😘///爱你＾3＾"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2