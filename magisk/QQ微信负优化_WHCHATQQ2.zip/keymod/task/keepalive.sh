#!/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=${MODPATH}/busybox:/system/bin:$PATH

processmainq=$(ps -ef | grep -w 'com.tencent.mobileqq:MSF' | grep -v grep | wc -l)
processmainw=$(ps -ef | grep -w 'com.tencent.mm:push' | grep -v grep | wc -l)

function wake_up_process_all() {
	local QQservice='
	com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService
	'
	local MMservice='
	com.tencent.mm/com.tencent.mm.booter.CoreService
	'

	if test "$processmainq" -lt "1" -o "$processmainw" -lt "1"; then
		test "$processmainq" -lt "1" && {
			sed -i "/^description=/c description="$(date +%H:%M)"，QQ被杀死，已经为您保活。" $MODPATH/module.prop
		}
		test "$processmainw" -lt "1" && {
			sed -i "/^description=/c description="$(date +%H:%M)"，微信被杀死，已经为您保活。" $MODPATH/module.prop
		}
		for i in $QQservice $MMservice; do
			am startservice -n $i
		done
		for i in com.tencent.mm com.tencent.mobileqq; do
			dumpsys deviceidle whitelist +$i
		done
	fi
}

function wake_up_process_QQ() {
	local QQservice='
	com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService
	'

	if test "$processmainq" -lt "1"; then
		sed -i "/^description=/c description="$(date +%H:%M)"，QQ被杀死，已经为您保活。" $MODPATH/module.prop
		for i in $QQservice; do
			am startservice -n $i
		done
		dumpsys deviceidle whitelist +com.tencent.mobileqq
	fi
}

function wake_up_process_MM() {
	local MMservice='
	com.tencent.mm/com.tencent.mm.booter.CoreService
	'

	if test "$processmainq" -lt "1"; then
		sed -i "/^description=/c description="$(date +%H:%M)"，微信被杀死，已经为您保活。" $MODPATH/module.prop
		for i in $MMservice; do
			am startservice -n $i
		done
		dumpsys deviceidle whitelist +com.tencent.mm
	fi
}

function show_value() {
	local value=$1
	local file=/data/media/0/Android/QQ微信负优化/QQ微信负优化.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

if test $(show_value "保活目标应用") == QQ; then
	wake_up_process_QQ
elif test $(show_value "保活目标应用") == 微信; then
	wake_up_process_MM
else
	wake_up_process_all
fi
