SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************
 请在模块路径下修改ID文件，模块路径都找不到请你卸载此模块
 "
set_perm_recursive $MODPATH 0 0 0755 0777