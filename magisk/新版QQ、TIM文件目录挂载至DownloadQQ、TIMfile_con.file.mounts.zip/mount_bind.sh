
umask 002

logs() {
  echo -e "$(date +"[%F %T]") ${1}" >> $MODDIR/mo.log
  [ -n "$ab" ] && echo " $1"
  [ -z "$2" ] && return 0
  [ "$2" -eq 2 ] && continue || return 0
  [ "$2" -eq "$ab" ] && abort "$1" || return 0
  [ "$2" -eq 1 ] && exit 1 || return 0
}


wait_true() {
  local ints=0
  while [ $ints -le 666 ]; do
    mountpoint -q /storage/emulated 2>/dev/null && break || sleep 2
    ints=$((ints + 2))
  done
  mountpoint -q /storage/emulated 2>/dev/null || return 1
  ints=0
  while [ $ints -le 666 ]; do
    [ -d /sdcard/Android ] && break || sleep 2
    ints=$((ints + 2))
  done
  return 0
}

set_ch() {
  chcon u:object_r:media_rw_data_file:s0 "$1" 2>/dev/null || logs "! 安全上下文:$1"
  chown media_rw:media_rw "$1" 2>/dev/null || logs "! 所有者:用户组:$1"
}

mo() {
  local m1=${1%\#\*\#*}
  local m2=${1##*\#\*\#}
  grep -q -e "$m1" /proc/self/mountinfo && umount "$m1"
  [[ -d "$m2" ]] || logs "! 不存在:${m2#/data/media/0/}" 2
  [[ -d "$m1" ]] || mkdir -p "$m1"
  mount --bind "$m2" "$m1" || logs "! 挂载失败:${m2#/data/media/0/}"
  set_ch "$m1"
  grep -q -e "$m1" /proc/self/mountinfo && logs "- 已挂载:${m2#/data/media/0/}→${m1#/data/media/0/}"
#  if [[ "$(echo -n ${m1} |grep -o '^/data/media/0')" == '/data/media/0' ]] ; then am broadcast --user 0 -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file:///storage/emulated/0/${m1#/data/media/0/}" &>/dev/null & ; fi
  return 0
}

log_ln() {
[ -f $MODDIR/mo.log ] && ln -f $MODDIR/mo.log /data/media/0/Android/log_mo_bind.txt || logs "! 链接失败:Android/log_mo_bind.txt"
set_ch /data/media/0/Android/log_mo_bind.txt
}


