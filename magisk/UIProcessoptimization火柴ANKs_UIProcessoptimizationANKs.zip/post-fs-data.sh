#!/system/bin/sh

cmd package compile -m speed -f com.android.systemui