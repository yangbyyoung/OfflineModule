SKIPMOUNT=false
key_source(){
source $1
rm -rf $1
}
key_source $MODPATH/key.sh
key_source $MODPATH/bootanimation.sh
key_source $MODPATH/check_boot_m.sh
key_source $MODPATH/check_bootanimation.sh
key_source $MODPATH/boot_view.sh
set_perm_recursive  $MODPATH  0  0  0755  0644
