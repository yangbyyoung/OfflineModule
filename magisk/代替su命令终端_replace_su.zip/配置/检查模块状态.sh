#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MAGISKMOD=/data/adb/modules/
ID=replace_su
MODDIR=$MAGISKMOD/$ID
SYSTEM=/system
BIN=$SYSTEM/bin
MIRRORPROP=$MODDIR/module.prop
BFPROP=$MODDIR/配置/备用module
# 该脚本将在设备开机后作为延迟服务启动
if [ -d "$MAGISKMOD/$ID" ]; then
echo "模块存在"
else
rm -rf /data/adb/service.d/检测模块状况.sh & echo "模块没了，我也该没了"
fi

if [ -f "$MODDIR/disable" ]; then
cp -r $BFPROP $MIRRORPROP
else
echo "运行着"
fi

if [ -f "$MODDIR/remove" ]; then
echo "不操作"
else
echo "运行着"
fi

if [ -d "$MODDIR/配置/文件名" ]; then
echo "文件夹还在"
else
mkdir $MODDIR/配置/文件名
fi

if [ -f "$MODDIR/配置/LOG" ]; then
echo "文件存在"
else
touch $MODDIR/配置/LOG
chmod 777 $MODDIR/配置/LOG
fi

if [ -f "$MODDIR/配置/LOG_VAB" ]; then
echo "文件存在"
else
touch $MODDIR/配置/LOG_VAB
chmod 777 $MODDIR/配置/LOG_VAB
fi
done
