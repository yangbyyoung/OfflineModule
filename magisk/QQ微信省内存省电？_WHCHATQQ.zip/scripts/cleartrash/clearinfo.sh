MODPATH="/data/adb/modules/WHCHATQQ"
BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

tencenttbs="/data/media/*/Tencent/tbs"

mmvideo="/data/media/*/Android/data/com.tencent.mm/MicroMsg/*/video"
qqvideo="/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/shortvideo"

liteapp1="/data/data/com.tencent.mm/MicroMsg/*/appbrand/pkg/"
liteapp2="/data/data/com.tencent.mm/files/liteapp"
liteapp3="/data/data/com.tencent.mm/MicroMsg/*/game"

qqx5="/data/data/com.tencent.mobileqq/app_tbs*"

mmx5="/data/data/com.tencent.mobileqq/app_tbs*"
mmx52="/data/data/com.tencent.mm/app_xwalk*"

qqchatpic="/data/media/*/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/chatpic"
qqlitegame="/data/data/com.tencent.mobileqq/files/minigame"
qqliteapp="/data/data/com.tencent.mobileqq/files/mini"

mmpypic="/data/media/*/Tencent/micromsg/*/sns"
mmchatpic="/data/media/*/Tencent/micromsg/*/image2"

mmchatpicsize=` du -sh $mmchatpic 2>/dev/null | awk '{print $1}' `
mmpypicsize=` du -sh $mmpypic 2>/dev/null | awk '{print $1}' `
mmvideosize=` du -sh $mmvideo 2>/dev/null | awk '{print $1}' `
liteappsize1=` du -sh $liteapp1 2>/dev/null | awk '{print $1}'`
liteappsize2=` du -sh $liteapp2 2>/dev/null | awk '{print $1}'`
liteappsize3=` du -sh $liteapp3 2>/dev/null | awk '{print $1}'`

echo ""
echo "∞————————————————————————∞"
echo ""
echo "微信聊天缓存视频大小:\n$mmvideosize "
echo ""
echo "微信聊天图片大小:\n$mmchatpicsize "
echo ""
echo "微信朋友圈预览的视频和图片大小:\n$mmpypicsize "
echo ""
echo "微信小程序大小:\n"$liteappsize1"\n"$liteappsize2" "
echo ""
echo "微信小程序(游戏)大小:\n"$liteappsize3" "
echo ""
echo "∞————————————————————————∞"

qqvideosize=` du -sh $qqvideo 2>/dev/null | awk '{print $1}' `
qqchatpicsize=` du -sh $qqchatpic 2>/dev/null | awk '{print $1}' `
qqlitegamesize=` du -sh $qqlitegame 2>/dev/null | awk '{print $1}' `
qqliteappsize=` du -sh $qqliteapp 2>/dev/null | awk '{print $1}' `

echo ""
echo "∞————————————————————————∞"
echo ""
echo "QQ聊天缓存视频大小:\n$qqvideosize "
echo ""
echo "QQ聊天缓存图片大小:\n$qqchatpicsize "
echo ""
echo "QQ小程序大小:\n$qqliteappsize "
echo ""
echo "QQ小程序(游戏)大小:\n$qqlitegamesize "
echo ""
echo "∞————————————————————————∞"

tencenttbssize=` du -sh $tencenttbs 2>/dev/null | awk '{print $1}' `
qqx5size=` du -sh $qqx5 2>/dev/null | awk '{print $1}' `
mmx5size=` du -sh $mmx5 2>/dev/null | awk '{print $1}' `
mmx52size=` du -sh $mmx52 2>/dev/null | awk '{print $1}' `


echo ""
echo "∞————————————————————————∞"
echo ""
echo "腾讯x5内核备份文件大小:\n$tencenttbssize "
echo ""
echo "QQx5内核文件大小: \n$qqx5size "
echo ""
echo "微信x5内核文件大小: \n$mmx5size\n$mmx52size"
echo ""
echo "∞————————————————————————∞"