#!/system/bin/sh

export PATH=$(magisk --path)/.magisk/busybox:$PATH


function lock_folder(){
if test -d "${1}" ;then
	chmod -R 0000 "${1}"
	rm -rf ${1}/* 2>/dev/null
	chmod -R 0000 "${1}"
	chown -R root:root "${1}"
	chcon -R u:object_r:system_file:s0 "${1}"
fi
}

function add_high_fps(){
local target_folder="/data/system/mcd"
local target_package="${1}"
local tune_fps=`dumpsys display | grep 'DisplayModeRecord' | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' | grep -Eo '^90$|^120$' `
if test "${tune_fps}" = "120" ;then
	target_fps="120"
elif test "${tune_fps}" = "90" ;then
	target_fps="90"
else
	target_fps="120"
fi
test ! -d "${target_folder}" && mkdir -p "${target_folder}"
touch ${target_folder}/{df,arc.ini,ui_fps.ini}

chmod -R 0755 "${target_folder}"
chown -R system:system "${target_folder}"
chcon -R 'u:object_r:system_data_file:s0' "${target_folder}"

sed -i "/${target_package}/d" ${target_folder}/{arc.ini,ui_fps.ini}
sed -i '/^\[CUSTOMIZE\]$/d' ${target_folder}/{arc.ini,ui_fps.ini}
sed -i '1i \[CUSTOMIZE\]' ${target_folder}/{arc.ini,ui_fps.ini}
cat << key >> ${target_folder}/arc.ini
${target_package}="${target_fps} ${target_fps}"
key
cat << key >> ${target_folder}/ui_fps.ini
${target_package}="${target_fps} ${target_fps}"
key
}

#两个锁帧文件夹
#如果你懂得修改，那么请你自己修改这个文件夹，并注释掉这两行，或者删除此脚本。
lock_folder "/data/system/migt"
#lock_folder "/data/system/mcd"


#添加需要修改的游戏包名
Gamepackage=`cat "${0%/*}/Joyose/应用包名.prop" 2>/dev/null | sed '/^#/d;/^[[:space:]]*$/d'`

if test "${Gamepackage}" = "" ;then
Gamepackage='
com.qqgame.hlddz
com.pubg.imobile
com.tencent.tmgp.cod
com.riotgames.league.wildrift
com.tencent.tmgp.wdsj666
com.tencent.tmgp.qqx5
com.tencent.shootgame
com.tencent.tmgp.bh3
com.tencent.tmgp.dwrg
com.fungames.sniper3d
com.netease.hyxd
com.tencent.tmgp.cf
com.tencent.tmgp.speedmobile
com.tencent.lolm
com.miHoYo.Yuanshen
com.miHoYo.GenshinImpact
com.miHoYo.ys.bilibili
com.miHoYo.ys.mi
'
fi

for package in ${Gamepackage}
do
	add_high_fps "${package}"
done
