#!/system/bin/sh
sdcard_rw() {
	local file="/data/media/0/huzeDynamicDCdimming.test"
	if [[ -f "${file}" ]]; then
		rm "${file}"
		while [[ -f "${file}" ]]; do
			sleep 3
			rm "${file}"
		done
	else
		touch "${file}"
		until [[ -f "${file}" ]]; do
			sleep 3
			touch "${file}"
		done
		rm "${file}"
	fi
}
sdcard_rw
limit_brightness=20	#开启DC调光的最高亮度: 屏幕亮度到达15%及以下开启DC调光
cat <<CONFIG > "${0%/*}/module.prop"
id=huzeDynamicDCdimming
name=动态DC调光
version=v1.1
versionCode=202111161
author=酷安@沍澤
description=屏幕亮度低至${limit_brightness}%时自动开启DC调光
CONFIG
while true; do
	float_brightness=$(settings get system screen_brightness_float)
	if [[ ${float_brightness:0:1} = 1 ]]; then
		settings put system dc_back_light 0
	else
		float_brightness=${float_brightness:2:2}
		if [[ ${float_brightness:0:1} = 0 ]]; then
			settings put system dc_back_light 1
		else
			[[ ${#float_brightness} = 1 ]] && float_brightness="${float_brightness}0"
			if [[ ${float_brightness} -gt ${limit_brightness} ]]; then
				settings put system dc_back_light 0
			else
				settings put system dc_back_light 1
			fi
		fi
	fi
	sleep 600
done