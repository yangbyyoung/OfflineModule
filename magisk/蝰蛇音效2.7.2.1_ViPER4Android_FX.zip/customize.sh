#模块内容全部进magisk系统=0
#更多自定义=1
SKIPUNZIP=0
NEWFOL="/storage/emulated/0/Android/data/com.pittvandewitt.viperfx/files"
# Create the new scoped storage directory
ui_print " "
ui_print "- Placing Files to New Directory:"
ui_print "  $NEWFOL"
mkdir -p $NEWFOL

[ ! -d "$NEWFOL/DDC" ] && mkdir -p "$NEWFOL/DDC" 2>/dev/null
SDCARD="/storage/emulated/0/Android/data/com.pittvandewitt.viperfx/files"
CUSTOM_VDC_FILES=$(find $SDCARD/ -name '*.vdc' -not -path "$SDCARD/Android/*" -not -path "$SDCARD/ViPER4Android/*")
[ -n "$CUSTOM_VDC_FILES" ] && CUSTOM_VDC_FOUND=true || CUSTOM_VDC_FOUND=false
[ -z "$(ls "$NEWFOL/DDC" 2>/dev/null)" ] && DDC_FOLDER_EMPTY=true || DDC_FOLDER_EMPTY=false
if [ $DDC_FOLDER_EMPTY = true ] && [ $CUSTOM_VDC_FOUND = false ]; then
  ui_print " "
  ui_print "- Copying original V4A vdcs"
  ui_print " "
  ui_print "   Note that some of these aren't that great"
  ui_print "   Check out here for better ones:"
  ui_print "   https://t.me/vdcservice"
  ui_print " "
  mkdir -p "$NEWFOL/DDC" 2>/dev/null
  unzip -oj $MODPATH/vdcs.zip -d $NEWFOL/DDC >&2
else 
  ui_print " "
  ui_print "  Skipping Viper original vdc copy"
  [ $DDC_FOLDER_EMPTY = false ] && ui_print "    the folder is not empty"
  [ $CUSTOM_VDC_FOUND = true ] && ui_print "    custom vdcs have been found"
  ui_print " "
fi
rm $MODPATH/vdcs.zip >/dev/null 2>&1
if [ $CUSTOM_VDC_FOUND = true ]; then
  ui_print " "
  ui_print "- Copying custom V4A vdcs"
  ui_print " "
  ui_print "  Found these custom files:"
  ui_print "$CUSTOM_VDC_FILES"
  ui_print " "
  for file in $CUSTOM_VDC_FILES; do
    cp -fv "$file" "$NEWFOL/DDC"
  done
fi

if [ -z "$(ls "$NEWFOL/DDC-Orig" 2>/dev/null)" ]; then
  ui_print " "
  ui_print "- Copying Viper DDC files"
  ui_print " "
  mkdir -p $NEWFOL/DDC-Orig 2>/dev/null
  unzip -oj $MODPATH/DDC.zip -d $NEWFOL/DDC-Orig >&2
else
  ui_print " "
  ui_print "  Skipping Viper DDC-Orig copy, folder is not empty"
  ui_print " "
fi
rm $MODPATH/DDC-Orig.zip >/dev/null 2>&1

if [ -z "$(ls "$NEWFOL/Kernel" 2>/dev/null)" ]; then
  ui_print " "
  ui_print "- Copying Viper IRS files"
  ui_print " "
  mkdir -p $NEWFOL/Kernel 2>/dev/null
  unzip -oj $MODPATH/ViperIRS.zip -d $NEWFOL/Kernel >&2
else
  ui_print " "
  ui_print "  Skipping Viper IRS copy, folder is not empty"
  ui_print " "
fi

rm $MODPATH/ViperIRS.zip >/dev/null 2>&1
if [ -z "$(ls "$NEWFOL/Preset" 2>/dev/null)" ]; then
  ui_print " "
  ui_print "- Copying Viper Preset files"
  ui_print " "
  mkdir -p $NEWFOL/Preset 2>/dev/null
  unzip -oj $MODPATH/Preset.zip -d $NEWFOL/Preset >&2
else
  ui_print " "
  ui_print "  Skipping Viper Preset copy, folder is not empty"
  ui_print " "
fi
rm $MODPATH/Preset.zip >/dev/null 2>&1

path_audio() {
if [ -f /system/etc/audio_effects.conf ]; then
ui_print "- 修改 system/etc/audio_effects.conf"
	if [ -f $MODPATH/system/etc/audio_effects.conf ]; then
		rm -f $MODPATH/system/etc/audio_effects.conf
	fi
	cat /system/etc/audio_effects.conf > $MODPATH/system/etc/audio_effects.conf
	SYSTEM_CONFIG_MAGISK=$MODPATH/system/etc/audio_effects.conf
	sed -i "/v4a_standard_fx {/,/}/d" $SYSTEM_CONFIG_MAGISK
	sed -i "/v4a_fx {/,/}/d" $SYSTEM_CONFIG_MAGISK
	if [ $API -lt 26 ];then
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/lib\/soundfx\/libv4a_fx.so\n  }/" $SYSTEM_CONFIG_MAGISK
	else
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $SYSTEM_CONFIG_MAGISK
	fi
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $SYSTEM_CONFIG_MAGISK
fi
if [ -f /system/etc/audio_effects.xml ]; then
ui_print "- 修改 system/etc/audio_effects.xml"
	if [ -f $MODPATH/system/etc/audio_effects.xml ]; then
		rm -f $MODPATH/system/etc/audio_effects.xml
	fi
	cat /system/etc/audio_effects.xml > $MODPATH/system/etc/audio_effects.xml
	SYSTEM_MAGISK_XML=$MODPATH/system/etc/audio_effects.xml
	sed -i "/v4a_standard_fx/d" $SYSTEM_MAGISK_XML
    sed -i "/v4a_fx/d" $SYSTEM_MAGISK_XML
	sed -i "/<libraries>/ a\        <library name=\"v4a_fx\" path=\"libv4a_fx.so\"\/>" $SYSTEM_MAGISK_XML
	sed -i "/<effects>/ a\        <effect name=\"v4a_standard_fx\" library=\"v4a_fx\" uuid=\"41d3c987-e6cf-11e3-a88a-11aba5d5c51b\"\/>" $SYSTEM_MAGISK_XML
fi
if [ -f /system/etc/audio_effects_tune.conf ]; then
ui_print "- 修改 system/etc/audio_effects_tune.conf"
	if [ -f $MODPATH/system/etc/audio_effects_tune.conf ]; then
		rm -f $MODPATH/system/etc/audio_effects_tune.conf
	fi
	cat /system/etc/audio_effects_tune.conf > $MODPATH/system/etc/audio_effects_tune.conf
	SYSTEM_CONFIG_TUNE_MAGISK=$MODPATH/system/etc/audio_effects_tune.conf
	sed -i "/v4a_standard_fx {/,/}/d" $SYSTEM_CONFIG_TUNE_MAGISK
	sed -i "/v4a_fx {/,/}/d" $SYSTEM_CONFIG_TUNE_MAGISK
	if [ $API -lt 26 ]; then
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/lib\/soundfx\/libv4a_fx.so\n  }/" $SYSTEM_CONFIG_TUNE_MAGISK
	else
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $SYSTEM_CONFIG_TUNE_MAGISK
	fi
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $SYSTEM_CONFIG_TUNE_MAGISK
fi
if [ -f /system/etc/audio_effects_tune.xml ]; then
ui_print "- 修改 system/etc/audio_effects_tune.xml"
	if [ -f $MODPATH/system/etc/audio_effects_tune.xml ]; then
		rm -f $MODPATH/system/etc/audio_effects_tune.xml
	fi
	cat /system/etc/audio_effects_tune.xml > $MODPATH/system/etc/audio_effects_tune.xml
	SYSTEM_MAGISK_TUNE_XML=$MODPATH/system/etc/audio_effects_tune.xml
	sed -i "/v4a_standard_fx/d" $SYSTEM_MAGISK_TUNE_XML
    sed -i "/v4a_fx/d" $SYSTEM_MAGISK_TUNE_XML
	sed -i "/<libraries>/ a\        <library name=\"v4a_fx\" path=\"libv4a_fx.so\"\/>" $SYSTEM_MAGISK_TUNE_XML
	sed -i "/<effects>/ a\        <effect name=\"v4a_standard_fx\" library=\"v4a_fx\" uuid=\"41d3c987-e6cf-11e3-a88a-11aba5d5c51b\"\/>" $SYSTEM_MAGISK_TUNE_XML
fi
if [ -f /system/vendor/etc/audio_effects.conf ]; then
ui_print "- 修改 system/vendor/etc/audio_effects.conf"
	if [ -f $MODPATH/system/vendor/etc/audio_effects.conf ]; then
		rm -f $MODPATH/system/vendor/etc/audio_effects.conf
	fi
	cat  /system/vendor/etc/audio_effects.conf > $MODPATH/system/vendor/etc/audio_effects.conf
	VENDOR_CONFIG_MAGISK=$MODPATH/system/vendor/etc/audio_effects.conf
	sed -i "/v4a_standard_fx {/,/}/d" $VENDOR_CONFIG_MAGISK
	sed -i "/v4a_fx {/,/}/d" $VENDOR_CONFIG_MAGISK
	if [ $API -lt 26 ];then
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/lib\/soundfx\/libv4a_fx.so\n  }/" $VENDOR_CONFIG_MAGISK
	else
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $VENDOR_CONFIG_MAGISK
	fi
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $VENDOR_CONFIG_MAGISK
fi
if [ -f /system/vendor/etc/audio_effects.xml ]; then
ui_print "- 修改 system/vendor/etc/audio_effects.xml"
	if [ -f $MODPATH/system/vendor/etc/audio_effects.xml ]; then
		rm -f $MODPATH/system/vendor/etc/audio_effects.xml
	fi
	cat /system/vendor/etc/audio_effects.xml > $MODPATH/system/vendor/etc/audio_effects.xml
	VENDOR_MAGISK_XML=$MODPATH/system/vendor/etc/audio_effects.xml
	sed -i "/v4a_standard_fx/d" $VENDOR_MAGISK_XML
    sed -i "/v4a_fx/d" $VENDOR_MAGISK_XML
	sed -i "/<libraries>/ a\        <library name=\"v4a_fx\" path=\"libv4a_fx.so\"\/>" $VENDOR_MAGISK_XML
	sed -i "/<effects>/ a\        <effect name=\"v4a_standard_fx\" library=\"v4a_fx\" uuid=\"41d3c987-e6cf-11e3-a88a-11aba5d5c51b\"\/>" $VENDOR_MAGISK_XML
fi
if [ -f /system/vendor/etc/audio_effects_tune.conf ]; then
ui_print "- 修改 system/vendor/etc/audio_effects_tune.conf"
	if [ -f $MODPATH/system/vendor/etc/audio_effects_tune.conf ]; then
		rm -f $MODPATH/system/vendor/etc/audio_effects_tune.conf
	fi
	cat  /system/vendor/etc/audio_effects_tune.conf > $MODPATH/system/vendor/etc/audio_effects_tune.conf
	VENDOR_CONFIG_TUNE_MAGISK=$MODPATH/system/vendor/etc/audio_effects_tune.conf
	sed -i "/v4a_standard_fx {/,/}/d" $VENDOR_CONFIG_TUNE_MAGISK
	sed -i "/v4a_fx {/,/}/d" $VENDOR_CONFIG_TUNE_MAGISK
	if [ $API -lt 26 ]; then
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/lib\/soundfx\/libv4a_fx.so\n  }/" $VENDOR_CONFIG_TUNE_MAGISK
	else
		sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx.so\n  }/" $VENDOR_CONFIG_TUNE_MAGISK
	fi
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $VENDOR_CONFIG_TUNE_MAGISK
fi
if [ -f /system/vendor/etc/audio_effects_tune.xml ]; then
ui_print "- 修改 system/vendor/etc/audio_effects_tune.xml"
	if [ -f $MODPATH/system/vendor/etc/audio_effects_tune.xml ]; then
		rm -f $MODPATH/system/vendor/etc/audio_effects_tune.xml
	fi
	cat /system/vendor/etc/audio_effects_tune.xml > $MODPATH/system/vendor/etc/audio_effects_tune.xml
	VENDOR_MAGISK_TUNE_XML=$MODPATH/system/vendor/etc/audio_effects_tune.xml
	sed -i "/v4a_standard_fx/d" $VENDOR_MAGISK_TUNE_XML
    sed -i "/v4a_fx/d" $VENDOR_MAGISK_TUNE_XML
	sed -i "/<libraries>/ a\        <library name=\"v4a_fx\" path=\"libv4a_fx.so\"\/>" $VENDOR_MAGISK_TUNE_XML
	sed -i "/<effects>/ a\        <effect name=\"v4a_standard_fx\" library=\"v4a_fx\" uuid=\"41d3c987-e6cf-11e3-a88a-11aba5d5c51b\"\/>" $VENDOR_MAGISK_TUNE_XML
fi
}

# 卸载旧版ViPER4Android
ui_print "- 卸载旧版ViPER4Android..."
for i in $(find /data/app -maxdepth 1 -type d -name "*com.pittvandewitt.viperfx*" -o -name "*com.audlabs.viperfx*" -o -name "*com.vipercn.viper4android_v2*"); do
  case "$i" in
    *"com.pittvandewitt.viperfx"*) pm uninstall com.pittvandewitt.viperfx >/dev/null 2>&1;;
    *"com.audlabs.viperfx"*) pm uninstall com.audlabs.viperfx >/dev/null 2>&1;;
    *"com.vipercn.viper4android"*) pm uninstall com.vipercn.viper4android_v2 >/dev/null 2>&1;;
  esac
done

# 清除旧版ViPER4Android安装残余
ui_print "- 清除旧版ViPER4Android安装残余..."
for i in $(find /data/data -maxdepth 1 -name "*ViPER4AndroidFX*" -o -name "*com.audlabs.viperfx*" -o -name "*com.vipercn.viper4android_v2*"); do
  rm -rf $i 2>/dev/null
done

# 是否需要额外AML模块
FILES=$(find $NVBASE/modules/*/system $MODULEROOT/*/system -type f -name "*audio_effects*.conf" -o -name "*audio_effects*.xml" 2>/dev/null | sed "/$MODID/d")
if [ ! -z "$FILES" ] && [ ! "$(echo $FILES | grep '/aml/')" ]; then
  ui_print " "
  ui_print "- 音频模块冲突 ！"
  ui_print "- 请安装Audio Modification Library !"
  ui_print " "
  sleep 3
fi

if [ -d $MODPATH ]; then
ui_print " "
ui_print "- 正在升级中..."
ui_print " "
	ui_print "- 补丁音频配置文件"
	path_audio
	
	ui_print "- 驱动so文件处理..."
	if [ $API -ge 28 ] && [ ! -f /system/vendor/lib/libstdc++.so ]; then
		if [ -f /system/lib/libstdc++.so ]; then
			rm -f $MODPATH/system/vendor/lib/libstdc++.so
			cat /system/lib/libstdc++.so > $MODPATH/system/vendor/lib/libstdc++.so
		fi
		if [ -f /system/lib64/libstdc++.so ]; then
			rm -f $MODPATH/system/vendor/lib64/libstdc++.so
			cat /system/lib64/libstdc++.so > $MODPATH/system/vendor/lib64/libstdc++.so
		fi
	fi
	if [ $API -lt 26 ]; then
		rm -rf $MODPATH/system/vendor/lib
		rm -rf $MODPATH/system/vendor/lib64
		case $ARCH in
			x86) ui_print "- X86平台so文件处理"
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/arm*
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/x86_64
				 rm -f $MODPATH/system/lib/soundfx/libv4a_fx.so
				 mv -f $MODPATH/system/lib/soundfx/libv4a_fx_x86.so $MODPATH/system/lib/soundfx/libv4a_fx.so;;
			x86_64) ui_print "- X86-64平台so文件处理"
					rm -rf $MODPATH/system/app/ViPER4Android/lib/arm*
					rm -rf $MODPATH/system/app/ViPER4Android/lib/x86
					rm -f $MODPATH/system/lib/soundfx/libv4a_fx.so
					mv -f $MODPATH/system/lib/soundfx/libv4a_fx_x86.so $MODPATH/system/lib/soundfx/libv4a_fx.so;;
			arm64) ui_print "- ARM64平台so文件处理"
				   rm -rf $MODPATH/system/app/ViPER4Android/lib/arm
				   rm -rf $MODPATH/system/app/ViPER4Android/lib/x86*
				   rm -f $MODPATH/system/lib/soundfx/libv4a_fx_x86.so;;
			arm) ui_print "- ARM平台so文件处理"
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/arm64
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/x86*
				 rm -f $MODPATH/system/lib/soundfx/libv4a_fx_x86.so;;
		esac
	else
		rm -rf $MODPATH/system/lib
		if [ !"$IS64BIT" ]; then
			rm -rf $MODPATH/system/vendor/lib64
		fi
		case $ARCH in
			x86) ui_print "- X86平台so文件处理"
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/arm*
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/x86_64
				 rm -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx.so
				 mv -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx_x86.so $MODPATH/system/vendor/lib/soundfx/libv4a_fx.so;;
			x86_64) ui_print "- X86-64平台so文件处理"
					rm -rf $MODPATH/system/app/ViPER4Android/lib/arm*
					rm -rf $MODPATH/system/app/ViPER4Android/lib/x86
					rm -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx.so
					mv -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx_x86.so $MODPATH/system/vendor/lib/soundfx/libv4a_fx.so;;
			arm64) ui_print "- ARM64平台so文件处理"
				   rm -rf $MODPATH/system/app/ViPER4Android/lib/arm
				   rm -rf $MODPATH/system/app/ViPER4Android/lib/x86*
				   rm -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx_x86.so;;
			arm) ui_print "- ARM平台so文件处理"
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/arm64
				 rm -rf $MODPATH/system/app/ViPER4Android/lib/x86*
				 rm -f $MODPATH/system/vendor/lib/soundfx/libv4a_fx_x86.so;;
		esac
	fi
fi

ui_print "- 设置文件权限及安全上下文..."
set_perm_recursive $MODPATH 0 0 0755 0644
if [ -d $MODPATH/system/vendor ]; then
  set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:vendor_file:s0
  [ -d $MODPATH/system/vendor/etc ] && set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
fi

ui_print " "
ui_print "- 模块处理完成"
ui_print "- 请重启后检验"

