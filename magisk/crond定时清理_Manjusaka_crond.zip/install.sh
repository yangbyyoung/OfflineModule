##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
print_modname() {
    return
}


# Copy/extract your module files into $MODPATH in on_install.
on_install() {
  unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null
  ui_print "- Author: Manjusaka"
  ui_print "- Group: 647299031"
    # 欢迎拆包查看，请勿二改
  # 作者：Manjusaka（酷安@曼珠沙华Y）
  # 群组：647299031
}
set_permissions() {
    return
}