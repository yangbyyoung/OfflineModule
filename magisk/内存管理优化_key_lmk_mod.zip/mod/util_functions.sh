#!/system/bin/sh
#编写作者：@coolapk 10007
#gitee主页https://gitee.com/keytoolazy/mapdepot

#创建busybox目录，避免无命令，或者命令冲突。
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

install_magisk_busybox 2>/dev/null

id="$(echo "${0%/*}" | cut -d'/' -f5)"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

#限制日志大小
function limitlog(){
	local logfile="${2}"
	local size="${1}"
	local maxsize="$((1024*$size))"
	test ! -f "${logfile}" && echo "日志不存在！" && return 1 
	local filesize="$(ls -l "${logfile}" | awk '{print $5}')"
	if test "$filesize" -gt "$maxsize" ;then
		echo " " > "${logfile}"
	else 
		return 1
	fi
}

#写入日志的目录
local util_functions_log_file="$MODPATH/运行日志.log"

limitlog "10" "$util_functions_log_file"

#提供支持的函数
#锁定数值
function set_value() {
	local temp_value="${0%/*}/temp"
	if test -f "$2" ;then
		cat "$2" > "$temp_value" 2>/dev/null
		chmod 0777 "$2" > /dev/null 2>&1
			echo "$1" > "$2"
		chmod 0444 "$2" > /dev/null 2>&1
		test "$(cat "$2")" = "$1" || { 
			echo "修改"$2"失败！"
		echo "$(date '+%F %T') [E] 修改 "$2" [ $(cat $temp_value) ] 为 [ "$1" ] 失败！" >> "$util_functions_log_file"
		}
	rm -rf "$temp_value"
	else
	echo "$(date '+%F %T') [W] 不存在 "$2" ！ " >> "$util_functions_log_file"
	fi
}

#设置权限和用户组以及selinux上下文
function set_perm() {
	chown -R $2:$3 $1 || return 1
	chmod -R $4 $1 || return 1
		CON=$5
	test -z $CON  && CON=u:object_r:system_file:s0
	chcon -R $CON $1 || return 1
}

# $1:task_name $2:cgroup_name $3:"cpuset"/"stune"
change_task_cgroup()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            echo "$temp_tid" > "/dev/$3/$2/tasks"
        done
    done
}

# $1:process_name $2:cgroup_name $3:"cpuset"/"stune"
change_proc_cgroup()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        echo $temp_pid > "/dev/$3/$2/cgroup.procs"
    done
}

# $1:task_name $2:thread_name $3:cgroup_name $4:"cpuset"/"stune"
change_thread_cgroup()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            if [ "$(grep "$2" /proc/$temp_pid/task/$temp_tid/comm)" != "" ]; then
                echo "$temp_tid" > "/dev/$4/$3/tasks"
            fi
        done
    done
}

# $1:task_name $2:hex_mask(0x00000003 is CPU0 and CPU1)
change_task_affinity()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            taskset -p "$2" "$temp_tid" > /dev/null
        done
    done
}

# $1:task_name $2:nice(relative to 120)
change_task_nice()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            renice "$2" -p "$temp_tid"
        done
    done
}



