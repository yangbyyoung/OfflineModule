MODDIR=${0%/*}
TMPDIR="/dev/mount_lib"

mkdir -p $TMPDIR

sed 's#ro.product.product.name#ro.voyager.feas_ioctlon#' \
        /system_ext/lib64/libmigui.so \
        > $TMPDIR/libmigui.so

mount --bind "$TMPDIR/libmigui.so" "/system_ext/lib64/libmigui.so"

restorecon /system_ext/lib64/libmigui.so
