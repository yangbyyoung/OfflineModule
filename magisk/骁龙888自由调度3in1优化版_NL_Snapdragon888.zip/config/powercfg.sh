# 2022-10-20
# yylcl
# cpu_product=Qualcomm
# cpu_model=lahaina
# cluster_count=3
# clusters=("0" "4" "7")
# cpu_num=("0 1 2 3" "4 5 6" "7")
# cluster0_freq_table=1804800 1708800 1612800 1497600 1401600 1305600 1209600 1094400 998400 902400 806400 691200 595200 499200 403200 300000  
# cluster1_freq_table=2419200 2342400 2227200 2112000 1996800 1881600 1766400 1670400 1555200 1440000 1324800 1209600 1075200 960000 844800 710400  
# cluster2_freq_table=2841600 2764800 2688000 2592000 2496000 2380800 2265600 2150400 2035200 1900800 1785600 1670400 1555200 1420800 1305600 1190400 1075200 960000 844800  
# available_governor=conservative powersave performance schedutil 
# gpu_product=Adreno660
# gpu_freq_table=0:800000000 1:710000000 2:620000000 3:530000000 4:440000000 5:350000000 6:260000000 7:170000000 
# gpu_count=10
# available_scheduler=mq-deadline kyber bfq none
# scheduling mode=powersave balance performance fast

action=$1

if [[ "$action" = "powersave" ]]; then
# 核心开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-6" > /dev/cpuset/foreground/cpus
echo "0-6" > /dev/cpuset/top-app/cpus
# 小核
echo '8000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '998400' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1209600' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '403200' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '16000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1075200' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '1555200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '844800' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '16000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '1075200' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '1555200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '844800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '350000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo '170000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
# echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '5' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '7' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '7' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
#
#
elif [[ "$action" = "balance" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-1" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-6" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '8000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '998400' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1209600' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '595200' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '16000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1555200' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '1766400' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '1075200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '16000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '1670400' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '1900800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '1190400' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '440000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo '260000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
# echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '4' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '6' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '6' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
#
#
elif [[ "$action" = "performance" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-2" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '8000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '1305600' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1497000' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '902400' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '16000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '1881600' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '2112000' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '1440000' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '8000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '2035200' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '2265600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '1555200' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '620000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo '440000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
# echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '2' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '4' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '4' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
#
#
elif [[ "$action" = "fast" ]]; then
# 处理器开关
echo '1' > /sys/devices/system/cpu/cpu0/online
echo '1' > /sys/devices/system/cpu/cpu1/online
echo '1' > /sys/devices/system/cpu/cpu2/online
echo '1' > /sys/devices/system/cpu/cpu3/online
echo '1' > /sys/devices/system/cpu/cpu4/online
echo '1' > /sys/devices/system/cpu/cpu5/online
echo '1' > /sys/devices/system/cpu/cpu6/online
echo '1' > /sys/devices/system/cpu/cpu7/online
# 核心分配
echo "0-3" > /dev/cpuset/background/cpus
echo "0-3" > /dev/cpuset/system-background/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
# 小核
echo '8000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/down_rate_limit_us
echo '1612800' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo '1804800' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo '1209600' > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# 大核
echo '16000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/down_rate_limit_us
echo '2227200' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rtg_boost_freq
echo '4000' > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo '2419200' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo '1766400' > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
# 超大核
echo '8000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
echo '2380800' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo '90' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo '1' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/pl
echo '0' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/rtg_boost_freq
echo '2000' > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 'schedutil' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo '2841600' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo '1900800' > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
# GPU部分
echo '800000000' > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo '620000000' > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
# echo 'msm-adreno-tz' > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo '0' > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo '2' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo '2' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
fi