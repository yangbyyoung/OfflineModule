#!/system/bin/sh
#特别鸣谢Magisk提供服务支持：by topjohnwu


MODDIR=${0%/*}
sd="/data/media/0/Android/墓碑日志.log"

#set -x    # 开启调试模式
wait_boot_completed() {
  i=5
  while true; do
    sleep $i
    completed=$(getprop sys.boot_completed)
    if [[ "$completed" == "1" ]];then
      return
    fi
  done
}

wait_boot_completed

mkdir_boot() {
sleep 5
    mkdir /dev/freezer > /dev/null 2>&1
    mount -t cgroup -ofreezer freezer /dev/freezer > /dev/null 2>&1
    sleep 1
    mkdir /dev/freezer/thaw > /dev/null 2>&1
    mkdir /dev/freezer/frozen > /dev/null 2>&1
    echo FROZEN > /dev/freezer/frozen/freezer.state > /dev/null 2>&1
    echo THAWED > /dev/freezer/thaw/freezer.state > /dev/null 2>&1

    mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup > /dev/null 2>&1
    mkdir /sys/fs/cgroup/frozen > /dev/null 2>&1
    mkdir /sys/fs/cgroup/unfrozen > /dev/null 2>&1
    echo 1 > /sys/fs/cgroup/frozen/cgroup.freeze > /dev/null 2>&1
}

    
#chmod a+x $MODDIR/mb/*.sh
chmod 777 -R /data/adb/modules/mubei

mkdir_boot

if [ ! -f "$sd"];then
mkdir "$sd"  
fi
echo "开机启动，已删除旧日志！" > "$sd"  

/bin/magisk su -c 'sh /data/adb/modules/mubei/mb/墓碑kill启动.sh' > /dev/null 2>&1 &
#sh /data/adb/modules/mubei/mb/墓碑v2启动.sh > /dev/null 2>&1 &
sleep 3

mb_id="$(pgrep -f 'mb.sh' )"
mb_id1="$(pgrep -f 'mb1.sh' )"
mb_id2="$(pgrep -f 'mb2.sh' )"

if [ "$mb_id" != "" ]; then
    echo "$(date '+%T') ️当前模式：Kill墓碑运行成功！" >>$sd
elif [ "$mb_id1" != "" ]; then
    echo "$(date '+%T') ️当前模式：Freeze v1墓碑运行成功！" >>$sd    
elif [ "$mb_id2" != "" ]; then
    echo "$(date '+%T') ️当前模式：Freeze v2墓碑运行成功！" >>$sd
else
    echo "$(date '+%T') ️开机启动：失败……！" >>$sd    
fi
#set +x    # 关闭调试模式