### Sıkça Sorulan Sorular

- _BusyBox gerekli mi?_

> **Hayır.** Uygulamanın kendi yerleşik uygulaması vardır. Ancak ek bir BusyBox
> uygulamasına/modülüne sahip olmak herhangi bir çakışmaya neden olmaz.

- _Bazı ayarlar neden etkin değil (değiştirilemez)?_

> FDE.AI, cihazınızın listelenen ayarlardan herhangi birini destekleyip desteklemediğini kontrol
> eder. Bir ayar desteklenmiyorsa, devre dışı bırakılacaktır. Bu aynı zamanda seçilen Yapay Zeka
> moduna ve gerçek zamanlı sistemin olup olmadığına da bağlı olabilir. optimizasyonun
> etkinleştirilip veya etkinleştirilmediğidurumlarda.

- _Ben güç tasarrufuna ayarlarken Yapay Zeka neden cihazımı performans moduna alıyor?_

> Yapay Zeka, cihaz şarj oluyorsa performans için Sanal Belleği ayarlar. Cihazınızı şarjdan
> çıkardıktan sonra Yapay önceki moda geri döner. Bu seçenek güvenlidir ve cihaz yalnızca
> Sanal Bellek parametrelerini ayarladığı için aşırı ısınma (frekans/termal değişiklik olmaz).

- _Uygulama iyi çalıştı, ancak günlük uzun süredir güncellenmiyor. Bu iyi mi?_

> **Evet**, çünkü FDE.AI yalnızca gerçekten gerekliyse çeşitli arka plan etkinlikleri
> gerçekleştirir. cihazınızın kullanım senaryosunda. Ancak, uygulamanın gerçekten takıldığını
> düşünüyorsanız, yeniden başlatmayı deneyin. Ayarlar sayfasından FDE.AI'yi veya cihazınızı
> yeniden başlatın.

- _FDE.AI, Herhangi bir tweaker uygulamasıyla çalışır mı?_

> Muhtemelen evet, ancak kesinlikle **ÖNERİLMEZ**. Beklenmeyen sorunlar/çakışmalar meydana
> gelebilir. Ancak, ne yaptığınızı biliyorsanız ve bir ayarın çakışıp çakışmayacağını biliyorsanız,
> olabilir FDE.AI ile birlikte diğer tweaker'ları kullanabilirsiniz. Ancak, daha önce belirtildiği
> gibi, bu TAVSİYE EDİLMEZ ve RİSK KENDİNİZE AİTTİR.

- _CPU ve/veya GPU Turbo neden desteklenmiyor?

> Kullandığınız İşlemci, FDE.AI'nin kullanması için gerekli bir bilgi düğümü sağlamadığından Dolayı.
> Ancak, ayrıca cihazınızın yonga seti/sürücüsü onu desteklemiyor olabilir. Ek olarak, bazı
> İşlemciler de desteklemez çalışmak için gerekli ayarları sağlar
> 'ondemand'/'interactive'/'schedutil' veya bunlara dayalı olarak yöneticiler CPU Turbo tarafından
> desteklenmelidir. Her neyse, deneyebileceğiniz şey İşlemci Yöneticisini değiştirmektir,
> çekirdek yönetim uygulamasını kaldırın veya rastgele bir aksaklık olmadığından emin olmak için
> uygulamaların verilerini temizleyin. Bunlara ek olarak, aksi halde desteklemeyen belirli Mali ve
> Vivante GPU'lar için eski GPU Turbo desteği vardır özellik. Sürekli oyun hızlandırma seçeneğinin
> etkin olmasını gerektirir ve desteklenen oyunlarla çalışır otomatik olarak veya AI modu
> performans olarak ayarlandıysa her zaman etkinleştirilebilir.

- _CPU/GPU yöneticimi nasıl değiştiririm?_

> Bir çekirdek yöneticisi indirin (SmartPack'i öneririz, ancak kelimenin tam anlamıyla tüm
> uygulamala iyidir) ve değiştirin orada.

- _Uygulamayı son kullanılanlardan kaydırarak güvenli bir şekilde kapatabilir miyim?_

> Evet. Tüm süreçleri yöneten bir arka plan hizmeti var. Uygulama, bir sarmalayıcı gibi davranır ve
> her zaman çalışır bu arka plan hizmetidir

- _Bir arka plan hizmetinden bahsettiğinizde, bu, uygulamanın pilimi bitireceği anlamına mı
  geliyor?_

> **Hayır**. Sadece hayır.

- _FDE.AI nasıl doğru şekilde kaldırılır?_

> Uygulamayı her zamanki gibi kaldırın ve cihazınızı yeniden başlatın. Uygulanan tüm ayarlar eski
> haline döner. varsayılanlar. Ancak lütfen kaldırma nedenlerinizi destek grubunda bildirmeyi
> düşünün. Özellikle de hatalar yüzündense veya uygulama beklediğiniz gibi çalışmıyorsa.

- _Uygulama tarafından hangi kök yöntemleri desteklenir?_

> Kelimenin tam anlamıyla herhangi biri, ancak Magisk önerilir.

- _Uygulama ana sayfasındaki yapay zeka yaşam süresi sayacı nedir?_

> Yapay zekanın ne kadar süredir aktif olduğunu gösteren basit bir göstergedir.
> için "FDE.AI'yi Yeniden Başlat" düğmesine basarsanız veya cihazınız yeniden başladığında
> sıfırlayın.

- _Yapay zeka neden bazen modunu yanlış bildirir?_

> Yanlış raporlama yapmıyor, sadece yavaş yavaş (gerçek zamanlı değil) durumunu güncelliyor.
> ~40 saniye gerektirir.

- _Bilgi sayfasındaki "PC Optimizer" düğmesi nedir ve neden oradadır?_

> Bu, Windows işletim sistemi için ortaklık (ücretsiz yazılım) iyileştirici uygulamasına bir
> bağlantıdır. Uygulama geliştirildi ve farklı geliştiriciler tarafından korunur
> (FDE.AI ekibi değil).

- _Sistemim, FDE.AI yürütüldükten sonra gecikmeye başlıyor. Neden?_

> Bu olmamalı. Ancak **all** build.prop ayarlarını devre dışı bırakmayı deneyebilir, yeniden
> başlatabilirsiniz cihaz ve bakın.

- _Bu SSS'nin kapsamadığı bir sorum var. Bir yanıtı nerede bulabilirim?_

> "AI bölümü hakkında bilgi"yi kontrol edin. Ayrıca katılmaktan çekinmeyin
> [Telegram destek grubumuz](https://t.me/feralab_eng) - yardımcı olmaktan memnuniyet duyarız :)

- _Bir hata buldum/önerilerim var, bunları nereye bildirebilirim?_

> Yukarıdakiyle aynı - Telegram destek grubumuzda.