alias DV="2>/dev/null"
Manjusaka_find() {
	i=0
	for Manjusaka in $(DV find -L /system -iname "*thermal*" -type f | grep -v 'hardware' | grep -v '@' | grep -v '.so'); do
		{
			MJK=$(echo "${Manjusaka##*/}")
			[ "${MJK##*.}" = "xml" ] || [ "${MJK##*.}" = "conf" ] || [ "${MJK##*.}" = "rc" ] && {

				[ $(wc -c "$Manjusaka" | awk '{print $1}') -ne 0 ] && {
					wc -c "$Manjusaka"
					printf "\033[31m - 未移除 \033[0m\n"
				} || {
					wc -c "$Manjusaka"
					let i++
					printf "\033[32m - 第${i}个温控已移除 \033[0m\n"
				}

			}
		}
	done
}
Manjusaka_find
exit 0
