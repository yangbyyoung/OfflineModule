ShellVersion="1.0"

# 创建日志文件及限制文件大小
function limitlog(){
	local logfile=$1
	local maxsize=$((1024*10))
	filesize=`ls -l $logfile | awk '{ print $5 }'`
	if test "$filesize" -gt "$maxsize" ;then
		echo " " > $logfile
	fi
}
mkdir -p /storage/emulated/0/Android/OptLog
txt="/storage/emulated/0/Android/OptLog/Opt.log"
if [ ! -f "$txt" ];then
  touch $txt
fi
limitlog "$txt"
sleep 0.2

# 清理垃圾文件夹目录
#开启方法：去掉下面各行前面的#及空格
# rm -rf /storage/emulated/0/.tbs
# rm -rf /storage/emulated/0/.turing.dat
# rm -rf /storage/emulated/0/.protected_image
# rm -rf /storage/emulated/0/.turingdebug
# rm -rf /storage/emulated/0/.UTSystemConfig
# rm -rf /storage/emulated/0/.xlDownload
# rm -rf /storage/emulated/0/Audiobooks
# rm -rf /storage/emulated/0/Movies
# rm -rf /storage/emulated/0/Notifications
# rm -rf /storage/emulated/0/QQBrowser
# rm -rf /storage/emulated/0/Recordings
# rm -rf /storage/emulated/0/Fonts
# rm -rf /storage/emulated/0/.SystemConfig
# rm -rf /storage/emulated/0/Ringtones
# rm -rf /storage/emulated/0/Subtitles
# rm -rf /storage/emulated/0/.gs_fs6
# rm -rf /storage/emulated/0/.oukdtft
# rm -rf /storage/emulated/0/.7934039a
# rm -rf /storage/emulated/0/.gs_fs0
# rm -rf /storage/emulated/0/Backups/.SystemConfig
# rm -rf /storage/emulated/0/.wps_preloaded_2.txt
# rm -rf /storage/emulated/0/.DataStorage
# rm -rf /storage/emulated/0/5A968A4B377F25ED0A1FD3C67B0CEE31
echo "-完成清理垃圾-"