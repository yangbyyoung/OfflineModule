# Variables
skuid=`getprop ro.cda.skuid.id_final`
sku=${skuid:3:2}
brand=`getprop ro.product.brand`
device=`getprop ro.product.device`
platform=`getprop ro.board.platform`
treble=`getprop ro.treble.enabled`
cpuarch=`getprop ro.product.cpu.abi`
# $1:error_message
_abort()
{
    ui_print "$1"
    ui_print "! LKT installation failed."
    exit 1
}

_get_nr_core()
{
    echo "$(cat /proc/stat | grep cpu[0-9] | wc -l)"
}

_is_aarch64()
{
    if [ "$(getprop ro.product.cpu.abi)" == "arm64-v8a" ]; then
        echo "true"
    else
        echo "false"
    fi
}

_is_eas()
{
    if [ "$(grep sched /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors)" != "" ]; then
        echo "true"
    else
        echo "false"
    fi
}

# $1:cpuid
_get_maxfreq()
{
    local fpath="/sys/devices/system/cpu/cpu$1/cpufreq/scaling_available_frequencies"
    local maxfreq="0"

    if [ ! -f "$fpath" ]; then
        echo ""
        return
    fi

    for f in $(cat $fpath); do
        [ "$f" -gt "$maxfreq" ] && maxfreq="$f"
    done
    echo "$maxfreq"
}

_get_socid()
{
    if [ -f /sys/devices/soc0/soc_id ]; then
        echo "$(cat /sys/devices/soc0/soc_id)"
    else
        echo "$(cat /sys/devices/system/soc/soc0/id)"
    fi
}

_get_sm6150_type()
{
    [ -f /sys/devices/soc0/soc_id ] && SOC_ID="$(cat /sys/devices/soc0/soc_id)"
    [ -f /sys/devices/system/soc/soc0/id ] && SOC_ID="$(cat /sys/devices/system/soc/soc0/id)"
    case "$SOC_ID" in
    365 | 366) echo "sdm730" ;;
    355 | 369) echo "sdm675" ;;
    esac
}

_get_sdm865_type()
{
    local ddr_type4="07"
	local ddr_type5="08"
    local ddr_type
    ddr_type="$(od -An -tx /proc/device-tree/memory/ddr_device_type)"
    if [ ${ddr_type:4:2} == $ddr_type5 ]; then
        echo "sdm865_lp5"
    elif [ ${ddr_type:4:2} == $ddr_type4 ]; then
        echo "sdm865_lp4x"
    else
        echo "sdm865_lp5"
    fi
}

_get_sdm76x_type()
{
    if [ "$(cat /sys/devices/soc0/revision)" == "2.0" ]; then
        echo "sdm768"
    else
        echo "sdm765"
    fi
}

_get_msm8916_type()
{
    case "$(_get_socid)" in
    "206"|"247"|"248"|"249"|"250") echo "msm8916" ;;
    "233"|"240"|"242") echo "sdm610" ;;
    "239"|"241"|"263"|"268"|"269"|"270"|"271") echo "sdm616" ;;
    *) echo "msm8916" ;;
    esac
}

_get_msm8952_type()
{
    case "$(_get_socid)" in
    "264"|"289")
        echo "msm8952"
    ;;
    *)
        if [ "$(_get_nr_core)" == "8" ]; then
            echo "sdm652"
        else
            echo "sdm650"
        fi
    ;;
    esac
}

_get_sdm636_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm636_eas"
    else
        echo "sdm636_hmp"
    fi
}

_get_sdm660_type()
{
    local b_max
    b_max="$(_get_maxfreq 4)"
    # sdm660 & sdm636 may share the same platform name
    if [ "$b_max" -gt 2000000 ]; then
        if [ "$(_is_eas)" == "true" ]; then
            echo "sdm660_eas"
        else
            echo "sdm660_hmp"
        fi
    else
        echo "$(_get_sdm636_type)"
    fi

}

_get_sdm626_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm626_eas"
    else
        echo "sdm626_hmp"
    fi
}

_get_sdm625_type()
{
    local b_max
    b_max="$(_get_maxfreq 4)"
    # sd625 / 626 /630 may share the same platform name
    if [ "$b_max" -lt 2100000 ]; then
        if [ "$(_is_eas)" == "true" ]; then
            echo "sdm625_eas"
        else
            echo "sdm625_hmp"
        fi
    else
        echo "$(_get_sdm626_type)"
    fi
}

_get_sdm835_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm835_eas"
    else
        echo "sdm835_hmp"
    fi
}

_get_sdm82x_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "sdm82x_eas"
        return
    fi
    
    local l_max
    local b_max
    l_max="$(_get_maxfreq 0)"
    b_max="$(_get_maxfreq 2)"

    # sdm820 OC 1728/2150
    if [ "$l_max" -lt 1800000 ]; then
        if [ "$b_max" -gt 2100000 ]; then
            # 1593/2150
            echo "sdm820_hmp"
        elif [ "$b_max" -gt 1900000 ]; then
            # 1593/1996
            echo "sdm821_v1_hmp"
        else
            # 1363/1824
            echo "sdm820_hmp"
        fi
    else
        if [ "$b_max" -gt 2300000 ]; then
            # 2188/2342
            echo "sdm821_v3_hmp"
        else
            # 1996/2150
            echo "sdm821_v2_hmp"
        fi
    fi
}

_get_e8895_type()
{
    if [ "$(_is_eas)" == "true" ]; then
        echo "e8895_eas"
    else
        echo "e8895_hmp"
    fi
}

# $1:cfg_name
_setup_platform_file()
{
    if [ -f $MODPATH/config/$1.json ]; then
        #mv $MODPATH/config/cfg_uperf.json $MODPATH/config/cfg_uperf.json.bak 2> /dev/null
        #cp $MODPATH/config/$1.json $MODPATH/config/cfg_uperf.json 2> /dev/null
    cp_ch -n $MODPATH/config/$1.json $MODPATH/config/cfg_uperf.json 0755 > /dev/null 2>&1
    else
        _abort "! Config file \"$1.json\" not found."
    fi
}

# $1:board_name
_get_cfgname()
{
    local ret
    case "$1" in
    kona)          ret="$(_get_sdm865_type)" ;;
    msmnile* | sm8150*)       ret="sdm855" ;;
    sdm845* | sda845*)        ret="sdm845" ;;
    "lito")          ret="$(_get_sdm76x_type)" ;;
    "sm6150")        ret="$(_get_sm6150_type)" ;;
    "sdm710")        ret="sdm710" ;;
    "msm8916")       ret="$(_get_msm8916_type)" ;;
    "msm8939")       ret="sdm616" ;;
    "msm8952")       ret="$(_get_msm8952_type)" ;;
    msm8953* | sdm630* | sda630*)       ret="$(_get_sdm625_type)" ;;
    "msm8953pro")    ret="$(_get_sdm626_type)" ;;
    sdm660* | sda660*)        ret="$(_get_sdm660_type)" ;;
    sdm636* | sda636*)        ret="$(_get_sdm636_type)" ;;
    "trinket")       ret="sdm665" ;;
    "msm8976")       ret="sdm652" ;;
    "msm8956")       ret="sdm650" ;;
    msm8998* | apq8098*)       ret="$(_get_sdm835_type)" ;;
    msm8996* | apq8096*)    ret="$(_get_sdm82x_type)" ;;
    "universal9825") ret="e9820";;
    "universal9820") ret="e9820" ;;
    "universal9810") ret="e9810" ;;
    universal8895* | exynos8895*) ret="$(_get_e8895_type)" ;;
    universal8890* | exynos8890*) ret="e8890" ;;
    universal7420* | exynos7420*) ret="e7420" ;;
    *)               ret="unsupported" ;;
    esac
    echo "$ret"
}
ui_print " "
ui_print "  Brand       : $brand"
ui_print "  Codename    : $device"
ui_print "  SoC         : $platform"
ui_print " "
ui_print "- Performing device compatibility check..."

# Checks

    target=$platform
    cfgname="$(_get_cfgname $target)"
    if [ "$cfgname" == "unsupported" ]; then
        target="$(getprop ro.product.board)"
        cfgname="$(_get_cfgname $target)"
    fi

    if [ "$cfgname" != "unsupported" ]; then
        #echo "- The platform name is $target. Use $cfgname.json"
        _setup_platform_file "$cfgname"
        set_perm "$MODPATH/system/vendor/etc/powerhint.json" 0 0 0755 u:object_r:vendor_configs_file:s0
		
		
    if [[ $platform == *"universal9825"* ]] || [[ $platform == *"universal9820"* ]]; then
    ui_print  "- Warning!"
    ui_print  "- LKT may have compatibility issuses on this device"
	else
    ui_print "- Passed! Congrats, this device is compatible"    
    fi

    else
        ui_print  "- Error!"
        _abort "! [$target] not supported."
    fi
	

ui_print "  "
ui_print "  "
ui_print "  ██╗     ██╗  ██╗████████╗"
ui_print "  ██║     ██║ ██╔╝╚══██╔══╝"
ui_print "  ██║     █████╔╝    ██║   "
ui_print "  ██║     ██╔═██╗    ██║   "
 sleep "0.1"
ui_print "  ███████╗██║  ██╗   ██║   "
 sleep "0.5"
ui_print "  ╚══════╝╚═╝  ╚═╝   ╚═╝   "
 sleep "1"
ui_print "  ........................."
ui_print " "          
ui_print "   legendary.kernel.tweaks "
ui_print "  ........................."
ui_print " "
ui_print "   THE #1 KERNEL TWEAKING MOD"
ui_print " "
 
# Choices
ui_print "- Use se the volume keys to select the tweaks mode"
ui_print "  You can still change this later."
ui_print " "
ui_print "- LKT Profiles: "
ui_print " "
ui_print "  1. Powersave"
ui_print "  2. Balanced (Recommended)"
ui_print "  3. Performance"
ui_print "  "
sleep 1
MODE="";
#if [ -z $MODE ]; then
ui_print "  Vol(+) = powersave"
ui_print "  Vol(-) = show more options.."
ui_print " "
    if chooseport; then
MODE="BAT"
ui_print "- powersave profile selected."
ui_print " "
    else
MODE=""
    fi
#else
#MODE=""
#fi

if [ -z $MODE ]; then

ui_print "  Vol(+) = balanced"
ui_print "  Vol(-) = show more options.."
ui_print " "
    if chooseport; then
MODE="BAL"
ui_print "- balanced profile selected."
ui_print " "
    else
MODE=""
    fi
fi

if [ -z $MODE ]; then

ui_print "  Vol(+) = performance"
ui_print " "
    if chooseport; then
MODE="PER"
ui_print "- performance profile selected."
ui_print " "
    else
MODE="BAL"
ui_print "- Incorrect entry."
ui_print "- balanced profile selected by default."
ui_print " "
    fi
fi

if [ $MODE = 'BAT' ]; then
PROFILEMODE=0
elif [ $MODE = 'BAL' ]; then
PROFILEMODE=1
elif [ $MODE = 'PER' ]; then
PROFILEMODE=2
fi


  VER=$(cat ${TMPDIR}/module.prop | grep -oE 'version=v[0-9].[0-9]+' | awk -F= '{ print $2 }' )
  
  #sed -i "s/<VER>/${VER}/g" $TMPDIR/service.sh > /dev/null 2>&1
  #sed -i "s/<PROFILEMODE>/$PROFILEMODE/g" $TMPDIR/service.sh > /dev/null 2>&1
  sed -i "s/<VER>/${VER}/g" ${MODPATH}/service.sh > /dev/null 2>&1
  sed -i "s/<PROFILEMODE>/$PROFILEMODE/g" ${MODPATH}/service.sh > /dev/null 2>&1
  sed -i "s/<MODPATH>/${MODPATH}/g" ${MODPATH}/system/bin/lkt > /dev/null 2>&1
  #awk '{sub(/<MODPATH>/,"$MODPATH")}1' $MODPATH/system/bin/lkt > /dev/null 2>&1

    ui_print "- Extracting module files"

case "$cpuarch" in
  "arm64-v8a")
	mkdir -p $BASEDIR/system/lib64
    cp_ch -n $MODPATH/uperf/arm64-v8a/uperf $MODPATH/bin/uperf 0755 > /dev/null 2>&1
    cp_ch -n $MODPATH/sfanalysis/arm64-v8a/injector $MODPATH/bin/injector  0755 > /dev/null 2>&1
    cp_ch -n $MODPATH/sfanalysis/arm64-v8a/libsfanalysis.so $MODPATH/system/lib64/libsfanalysis.so 0755 > /dev/null 2>&1
  ;;
  "armeabi-v7a")
	mkdir -p $BASEDIR/system/lib
    cp_ch -n $MODPATH/uperf/arm64-v8a/uperf $MODPATH/bin/uperf 0755 > /dev/null 2>&1
    cp_ch -n $MODPATH/sfanalysis/armeabi-v7a/injector $MODPATH/bin/injector 0755 > /dev/null 2>&1
    cp_ch -n $MODPATH/sfanalysis/armeabi-v7a/libsfanalysis.so $BASEDIR/system/lib/libsfanalysis.so 0755 > /dev/null 2>&1
    ;;
esac

  chmod 0755 $MODPATH/bin/*
  
  #create sfanalysis enable flag
  mktouch  $MODPATH/enable_sfanalysis

  #clean installation files
  rm -rf $MODPATH/system/uperf/*
  rm -rf $MODPATH/system/sfanalysis/*
  rm -rf $MODPATH/system/config/*
  rmdir $MODPATH/system/uperf
  rmdir $MODPATH/system/sfanalysis
  #rmdir $MODPATH/system/config
	
ui_print "- For switching profile use the lkt manager app addon"
 sleep "0.3"
ui_print "  Or type lkt in terminal and ollow the instructions"
 sleep "1"
ui_print " "

ui_print "- Official Telegram Group : @LKT_XDA"
 sleep "0.1"
\ui_print "- Telegram Updates Channel : @LKTO"
 sleep "0.3"
ui_print " "
ui_print " "