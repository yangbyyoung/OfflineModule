#!/system/bin/sh
#禁/启用app/服务列表，就不一一说明了
#请和Disable_cloud.sh同步
#com.miui.powerkeeper
clouds="com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver"

#清理列表：MIUI的电量和性能，Analytics和Joyose
clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose"

#云控的域名/ip地址
Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

#启用
for i in ${clouds};
do
  pm enable ${i}
done

#清除应用数据
for i in ${clears};
do
  pm clear ${i}
done

#解除隐藏Analytics
pm unsuspend com.miui.analytics
pm unhide com.miui.analytics
#关闭云控界面
pm disable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity

#解除屏蔽MIUI云控，电量和性能接收云控数据。
for i in ${Cloud_address};
do
  iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done