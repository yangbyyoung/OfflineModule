#!/system/bin/sh

#重新启动mi_thermald，避免重启云温控失败
function restart_mi_thermald(){
killall -15 mi_thermald
for i in $(which -a mi_thermald)
do
	nohup "$i" >/dev/null 2>&1 &
done
}

#运行
function running_main(){
#等待两分钟后启动
sleep 2m
#定义变量
a=0
while :;do
if test -d "/data/vendor/thermal/config" ;then
	restart_mi_thermald
	break
fi
	sleep 20s
a=$(( $a + 1 ))
#80秒后退出
test "$a" = "4" && break
done
}

#运行脚本
( running_main & )





