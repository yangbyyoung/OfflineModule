
SKIPUNZIP=0
DEBUG=false

IDerror() {
ui_print " >>>:"
ui_print " 删除所有涉及振动的模块-重启."
ui_print " 查看vendor(odm)/firmware目录:"
ui_print " 检查上述文件是否缺失/重复."
ui_print " 把文件补全或删除重复,再安装模块."
ui_print " -"
ui_print " 若是其他品牌刷的MIUI移植包,由于底包(驱动方案)不同,"
abort " 本模块不兼容.请放弃~."
}

if [ -f /odm/firmware/1_*.bin ] || [ -f /odm/firmware/2_*.bin ]; then
   A="odm"
elif [ -f /vendor/firmware/1_*.bin ] || [ -f /vendor/firmware/2_*.bin ]; then
   A="vendor"
else
   ui_print "! ID文件(1_*.bin、2_*.bin)异常"
   IDerror
fi
M="$MODPATH"
F="$M/File"
C="/$A/firmware"
SC="system$C"
D="$M/$SC"
aw="aw8697_haptic.bin"
P="`grep_prop ro.product.odm.device /odm/etc/build.prop`"
U="`grep_prop ro.soc.model /vendor/build.prop`"
V="`grep_prop ro.odm.build.version.incremental /odm/etc/build.prop`"
ui_print "- 设备:$P($U)"
ui_print "- $V(SDK:$API)"
if [ "$API" -lt 30 ]; then
   abort " 安卓版本低于11.0"
fi
ui_print "　　　　　 !风险提示!"
ui_print "-个别机型可能有(功耗/振动异常/无振动等)玄学问题."
ui_print "-建议搜索专版模块,或单独MiuiExtra映射震动."
ui_print "-模块非万能,玄学问题概不负责.是否继续?"
ui_print "　　 音量↑:安装　音量↓:取消"
key_click=""
while [ "$key_click" = "" ]; do
   key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
   sleep 0.2
done
case "$key_click" in
   "KEY_VOLUMEUP")
   ui_print "　　　 ✓✓"
   if [ -f $C/67_NotificationXy*.bin ]; then
     fname=$C/67_NotificationXy*.bin
     fsize1=`ls -l $fname | awk '{ print $5 }'`
     maxze1=$((9892))
     if [ $fsize1 -ne $maxze1 ]; then
        ui_print "-马达型号不符!仅适配官方MIUI-0809马达机型."
        ui_print "-其他马达破音/振动异常请勿反馈!"
        ui_print "-若要安装,请降低强度,减少破音/异常概率."
        sleep 0.6
     fi
   else
     ui_print "! ID文件(67_NotificationXy*.bin)异常!"
     IDerror
   fi
   ;;
   *)
   abort "　　　　　　　　　　 ✓✓"
esac
. $F/main.sh
rm -rf $MODPATH/File
rm -rf $MODPATH/$SC/*\**
ui_print ""
ui_print ""
ui_print ""
ui_print ""