SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

SKIPUNZIP=0
ASH_STANDALONE=1

print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 - MIUI版本: $MIUI  $Version
 - 状态检测，白名单，阈值设置文件在：/data/adb/modules/ram

    23年8月19内容：
 - 与@火柴 联合开发，功耗降低30%。
 - @火柴重构代码，模块原有逻辑不变。
 - 模块独立运行与其它模块都不冲突。

 
   23年8月06内容：
 - 去除inotifywait改用标准c库，代码更健壮。
 - 解决与墓碑模块冲突问题，兼容性大幅度提升。

 
  23年4月22内容：
 - 增加“白名单.conf”避免杀掉重要APP。
 - 运存不足时，避免当前APP被杀掉，出现闪存现象。
 
 23年3月25内容：
 - 修复ram.sh的cpu占用高于0%的情况。
 ****************************
 "
}


set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0777  0777
}