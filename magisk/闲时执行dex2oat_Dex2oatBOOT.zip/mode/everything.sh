if [ $dex2oat_select = "系统应用" -o $dex2oat_select = "三方应用" -o $dex2oat_select = "全部应用" ]; then
	if [ $dex2oat_select = "系统应用" ]; then
		Package=$(pm list packages -s | grep "^package:" | cut -f2 -d ':')
		for i in $Package
		do
			cmd package compile -m everything $i
		done
	elif [ $dex2oat_select = "三方应用" ]; then
		Package=$(pm list packages -3 | grep "^package:" | cut -f2 -d ':')
		for i in $Package
		do
			cmd package compile -m everything $i
		done
	elif [ $dex2oat_select = "全部应用" ]; then
		cmd package compile -m speed -a
	elif [ $dex2oat_select != "全部应用" ] && [ $optional_app = "是" ]; then
		Optionalapp=$(cat $OPTIONALAPP_CONFIG | grep -v '^#')
		for a in $Optionalapp
		do
			cmd package compile -m everything $a
		done
		fi
	fi
	else
		echo "✘未选择应用" >> $DEX2OAT_LOG
	fi
else
	echo "✘无效的输入" >> $DEX2OAT_LOG
fi
