sleep 10s
echo "微信保活开始运行~~" | tee file.txt
while true
do
su -c am start-foreground-service com.tencent.mm/com.tencent.mm.booter.CoreService
su -c am start-foreground-service com.tencent.mm/com.tencent.mm.service.ProcessService$MMProcessService
echo $(date "+%Y-%m-%d %H:%M:%S") | tee file.txt
sleep 30s
#30秒唤醒微信
done