#!/system/bin/sh
sleep 30
am 
start-foreground-service -n com.jwg.searchEVO/.Service.ForegroundService
settings put secure enabled_accessibility_services com.jwg.searchEVO/com.jwg.searchEVO.Accessibility.MyAccessibilityService 