#调用update-binary进行安装 作者：时雨🌌星空
unzip -oj "$ZIPFILE" "META-INF/com/google/android/update-binary" -d "$TMPDIR";sh "$TMPDIR/update-binary" "$@";rm -rf "$TMPDIR";exit