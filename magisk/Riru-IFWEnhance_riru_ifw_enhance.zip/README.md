# Riru - IFWEnhance

A module of [Riru](https://github.com/RikkaApps/Riru). Enhance Intent Firewall.

[中文说明](https://github.com/Magisk-Modules-Repo/riru_ifw_enhance/blob/master/README_zh.md)

## Requirements

* [Riru](https://github.com/RikkaApps/Riru) > 22.0 installed.
* Android 8.0+



## Feature

Enhance Intent Firewall

* Apply Intent Firewall for **Implicit intents** (`PackageManager.queryIntentActivities`)



## Feedback

Telegram Group [Kr328 Riru Modules](https://t.me/kr328_riru_modules)
