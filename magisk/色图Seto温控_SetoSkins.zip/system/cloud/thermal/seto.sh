while true; do
	sleep 3
cp -f /sdcard/Android/备份温控（请勿删除）/* /data/vendor/thermal/config/
	cp -f /data/media/0/Android/备份温控（请勿删除）/* /data/vendor/thermal/config/
done
