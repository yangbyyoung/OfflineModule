#Copyright Chenzyadb@Coolapk All Rights Reserved.

REPLACE="
"

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  set_perm  $MODPATH/system/bin/thermal-engine 0 0 0755
  set_perm  $MODPATH/system/bin/thermald 0 0 0755
  set_perm  $MODPATH/vendor/bin/thermal-engine 0 0 0755
  set_perm  $MODPATH/vendor/bin/thermalserviced 0 0 0755
}


  #Replace Main 
  ui_print "- Thermal File Removing."
  mkdir -p ${MODPATH}/system/etc
  mkdir -p ${MODPATH}/system/vendor/etc
  mkdir -p ${MODPATH}/system/vendor/lib
  mkdir -p ${MODPATH}/system/vendor/lib64
  mkdir -p ${MODPATH}/system/bin
  mkdir -p ${MODPATH}/system/vendor/bin
  mkdir -p ${MODPATH}/system/vendor/lib64/hw
  mkdir -p ${MODPATH}/system/vendor/lib/hw
  mkdir -p ${MODPATH}/system/lib64
  #hisilicon Thermal_file
  if [ -e /system/etc/thermald.xml ] ; then
  touch $MODPATH/system/etc/thermald.xml
  touch $MODPATH/system/etc/thermald_performance.xml
  touch $MODPATH/system/etc/thermald_performance_qcoff.xml
  touch $MODPATH/system/etc/thermald_qcoff.xml
  fi
  #qualcomm_thermal_lib
  if [ -e /system/bin/thermal-engine ] ; then
  touch $MODPATH/system/bin/thermal-engine
  touch $MODPATH/system/vendor/bin/thermal-engine
  fi
  if [ -e /system/bin/thermald ] ; then
  touch $MODPATH/system/bin/thermald
  touch $MODPATH/system/vendor/bin/thermald
  fi
  if [ -e /system/bin/thermalserviced ] ; then
  touch $MODPATH/system/bin/thermalserviced
  touch $MODPATH/system/vendor/bin/thermalserviced
  fi
  if [ -e /system/vendor/lib/libthermalioctl.so ] ; then
  touch $MODPATH/system/vendor/lib/libthermalioctl.so
  touch $MODPATH/system/vendor/lib/libthermalclient.so
  touch $MODPATH/system/vendor/lib64/libthermalioctl.so
  touch $MODPATH/system/vendor/lib64/libthermalclient.so
  fi
  for tso in $(ls /system/vendor/lib/hw/thermal.*.so /system/vendor/lib64/hw/thermal.*.so)
  do
    touch ${MODPATH}${tso}
  done
  for tconf in $(ls /system/etc/thermal-engine*.conf /system/vendor/etc/thermal-engine*.conf)
  do
    touch ${MODPATH}${tconf}
  done
  for tdconf in $(ls /system/etc/thermald-*.conf /system/vendor/etc/thermald-*.conf)
  do
    touch ${MODPATH}${tdconf}
  done
  #hisilicon_EMUI5.0+ Thermal_file
  if [ -d /product/etc/hwpg/ ] ; then
  mkdir -p ${MODPATH}/product/etc/hwpg/
  touch $MODPATH/product/etc/hwpg/thermald.xml
  touch $MODPATH/product/etc/hwpg/thermald_performence.xml
  touch $MODPATH/product/etc/hwpg/normal_cpu_policy.xml
  touch $MODPATH/product/etc/hwpg/super_cpu_policy.xml
  touch $MODPATH/product/etc/hwpg/thermald.xml
  touch $MODPATH/product/etc/hwpg/thermald_performance.xml
  touch $MODPATH/product/etc/hwpg/thermald_performance_qcoff.xml
  touch $MODPATH/product/etc/hwpg/thermald_qcoff.xml
  fi
  #MediaTek Thermal_file (For Redmi & Xiaomi)
  if [ -d /system/etc/.tp/ ] ; then        
  mktouch $MODPATH/system/etc/.tp/.replace
  fi
  if [ -d /system/vendor/etc/.tp/ ] ; then
  mktouch $MODPATH/system/vendor/etc/.tp/.replace
  fi
  if [ -d /system/etc/.tp0/ ] ; then
  mkdir -p $MODPATH/system/etc/.tp0/
  for mtt in $(ls /system/etc/.tp0/thermal.*.xml)
  do
    touch ${MODPATH}${mtt}
  done
  fi
  if [ -e /system/lib64/libthermalcallback.so ] ; then
  touch $MODPATH/system/lib64/libthermalcallback.so
  touch $MODPATH/system/lib64/libthermalservice.so
  fi
  if [ -e /system/bin/thermalserviced ] ; then
  mkdir -p ${MODPATH}/system/bin
  touch $MODPATH/system/bin/thermalserviced
  fi
  #Huawei PowerEngine&PowerMonitor
  if [ -e /system/app/HwPowerGenieEngine3/HwPowerGenieEngine3.apk ] ; then
  mkdir -p ${MODPATH}/system/app/HwPowerGenieEngine3/
  touch $MODPATH/system/app/HwPowerGenieEngine3/HwPowerGenieEngine3.apk
  fi
  if [ -e /system/app/HwPowerMonitor/HwPowerMonitor.apk ] ; then
  mkdir -p ${MODPATH}/system/app/HwPowerMonitor/
  touch $MODPATH/system/app/HwPowerMonitor/HwPowerMonitor.apk
  fi
  ui_print "- Thermal Removed."

