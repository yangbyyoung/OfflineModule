# 安装时显示的模块名称
mod_name="[cpu负载均衡优化]"
# 模块介绍
mod_install_desc="通过对sched_relax_domain_level值的修改，扩大cpu负载均衡时查找的范围，防止因为某个范围内的核心因为负载过大而降低性能"
# 安装时显示的提示
mod_install_info="是否安装$mod_name？"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="安装$mod_name"
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"
# 按下[音量-]后加入module.prop的内容
mod_select_no_desc=""


mod_install_yes()
{
add_service_sh $MOD_FILES_DIR/service.sh
		return 0
}

mod_install_no()
{
		return 0
}
