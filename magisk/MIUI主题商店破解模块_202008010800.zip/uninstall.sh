#!/system/bin/sh

remove_cache() {

  rm -rf /data/system/package_cache

}

remove_cache