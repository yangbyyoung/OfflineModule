#!/system/bin/sh
MODDIR=${0%/*}
mb=/data/user/0/com.mubei.android/files/墓碑名单.conf
hmd=/data/adb/modules/mubei/mb/墓碑黑名单.conf
sd=/data/media/0/Android/墓碑日志.log
appsl=''
hmds=$(sed '/^\s*\(#\|$\)/d' "$hmd")
SYSAPP=$(pm list package -s | awk -F ":" '{print $NF}')
pose="com.tencent.mm:sandbox* com.tencent.mm:exdevice* com.tencent.mm:hotpot* com.tencent.mm:TMAssistantDownloadSDKService* com.tencent.mm:tools*"
inotifywait -m /dev/cpuset/top-app/ |
while read path action file; do
if [ "$action" = "MODIFY" ]; then
        lru=$(dumpsys activity lru)
        apps=$(am stack list | awk '/taskId/&&!/unknown/{print $2}' | awk 'NR==1 || NR==2' | awk -F '/' '{print $1}')
        abbs=$(echo "$lru" | grep -E 'FGS|TOP|PER' | grep 'act' | awk -F ':' '{print $3}' | awk -F '/' '{print $1}')

                pgrep -f $apps |while read pid;do echo $pid > /dev/freezer/thaw/cgroup.procs;done     
        if [[ "$appsl" != "$apps" ]];then
                . /data/user/0/com.mubei.android/files/墓碑名单.conf
                echo -e "$appsl" | tr ' ' '\n' | tr -d '[ \t]' | while read app; do
                BMDS=$(echo -e  "$HMD" | grep -v '^#' | grep -v '^$')
                have=$(echo -e "$apps" | grep  "$app" -c -m 1)
                bmd=$(echo -e "$BMDS" | grep -o "$app" -c -m 1)
                ser=$(echo -e "$abbs" | grep "$app" -c -m 1)
                sysapp=$(echo -e "$SYSAPP" | grep -o "$app" -c -m 1)
                hmdapp=$(echo -e "$hmds" | grep -o "$app" -c -m 1)
                if [[ $have -eq 0 ]]; then
                    if [[ $bmd -eq 0 ]]; then
                        if [[ $ser -eq 0 ]] ;then
                            if [[ $sysapp -eq 0 ]]; then
                                if [[ $app == "com.tencent.mm" ]]; then
                                    (sleep 300
                                    dq=$(dumpsys window displays | grep "mFocusedApp" | grep -v "AppWindowToken" | awk '{print $(NF-1)}' | awk -F "/" '{print $1}')
                                    if [[ "$dq" == "com.tencent.mm" ]]; then
                                        echo "$(date '+%T') 微信${app} 取消操作" >> $sd 
                                    else
                                        echo "$(date '+%T') 微信${app} 只留推送" >> $sd 
                                        echo -e "$pose" | tr ' ' '\n' | tr -d '[ \t]' | xargs pkill -9 -f
                                    fi) &
                                else
                                    echo "$(date '+%T') 离开$app 送入墓碑" >> $sd 
                                    pgrep -f $app |while read pid;do echo $pid > /dev/freezer/frozen/cgroup.procs;done
                                    appops set $app WAKE_LOCK ignore
                                fi
                            fi
                        fi
                    fi
                fi 

                if [[ $have -eq 0 ]] ;then
                if [[ "$app" != "android" ]]; then
                    if [[ $hmdapp -eq 1 ]];then
                        echo "$(date '+%T') 离开$app 进黑墓碑" >> $sd 
                        pgrep -f $app |while read pid;do echo $pid > /dev/freezer/frozen/cgroup.procs;done
                        appops set $app WAKE_LOCK ignore
                    fi
                fi
                fi
            done
        fi
        appsl=$apps
fi
done