SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=false
modename() {
 ui_print "已把原生framework-res.apk备份到/sdcard，部分机型不支持改方法，如变砖请进rec还原"
}
install() {
cp /system/framework/framework-res.apk /sdcard/
 unzip -o "$ZIPFILE" 'system/framework/framework-res.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/app/bromite/org.bromite.webview.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/app/bromite/lib/arm64/libwebviewchromium.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/app/bromite/lib/arm64/libcrashpad_handler_trampoline.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/app/bromite/lib/arm/libwebviewchromium.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/product/app/bromite/lib/arm/libcrashpad_handler_trampoline.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/bromite/org.bromite.webview.apk' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/bromite/lib/arm64/libwebviewchromium.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/bromite/lib/arm64/libcrashpad_handler_trampoline.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/bromite/lib/arm/libwebviewchromium.so' -d $MODPATH >&2
 unzip -o "$ZIPFILE" 'system/app/bromite/lib/arm/libcrashpad_handler_trampoline.so' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}