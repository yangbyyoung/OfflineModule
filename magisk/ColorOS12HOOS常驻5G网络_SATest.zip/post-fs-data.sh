# 开机之前执行
#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容 即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

# 这个脚本将以 post-fs-data 模式执行
# 更多信息请访问 Magisk 主题
#HOOS
#5G状态
settings put system system 5g_nr_working 1
#不要问,这是关联5G命令行
setprop persist.radio.testmode ture
setprop persist.vendor.radio.optelopt_debug false
setprop persist.vendor.radio.default_smart_sa_enabled false
setprop persist.radio.ischinatelecom false
setprop persist.radio.ischinamobile false
setprop persist.vendor.radio.pingpong.duration false
setprop persist.vendor.radio.smart_sa_screen_off_min false
setprop persist.vendor.radio.smart_sa_dereg_timer_min false
setprop persist.vendor.radio.smart_sa_enable_timeout_min false
setprop persist.vendor.radio.smart_sa_keep_disable_min false
setprop persist.vendor.radio.pingpong.count false
#不要问,这是打开5G开关
setprop persist.vendor.radio.sa_enabled ture
# 这个开关 1.2.3.4
setprop persist.vendor.radio.arfcn_test_mode 4
#不要问,这是智能5G开关
setprop smart_fiveg false
settings put system system smart_fiveg false
#不要问,这是智能5G开关
setprop persist.radio.usersetting.smart5g false
setprop persist.radio.userchange.smart5g false
#不要问,这是智能SA/NSA开关
setprop persist.vendor.radio.default_sa_enabled ture
setprop persist.vendor.radio.default_smart_sa_enabled false


#COS
#智能5G
settings put system system oplus_show_fiveg_status 1
settings put system system oplus_support_fiveg_status 1
settings put system system oplus.radio.smart5g_switch 0
settings put system system oplus.radio.smart5g_switch1 0
settings put system system oplus.radio.smart5g_switch2 0
settings put system system oplus.radio.smart5g_switch3 0
settings put system system oplus.radio.smart5g_switch4 0
settings put system system oplus.radio.smart5g_switch5 0
settings put system system oplus.radio.light_smart5g_switch=0
#SA城市白名单
settings put system system oplus.radio.loc_control_switch 0
#NSA+SA
settings put system system user_auto_mode 0
settings put system system user_nr_mode 3
settings put system system user_nr_mode_sub 3
settings put system system user_operator_nr_mode 1
settings put system system user_rotation 0
#///////////////////////////////////////////////
#SA测试
settings put system oplus.network.nr_mode_test sa_only
setprop persist.oplus.network.nr_mode_test sa_only
#SA城市白名单
settings put system oplus.radio.loc_control_switch false
setprop persist.oplus.radio.loc_control_switch false
setprop persist.sys.oplus.radio.loc_control_switch false
#SA回落未返回
settings put system oplus.software.radio.sa_rat_control ture
setprop persist.oplus.software.radio.sa_rat_control ture
setprop persist.sys.oplus.software.radio.sa_rat_control ture
#TAC变化尝试恢复SA
settings put system oplus.software.radio.sa_tac_control ture
setprop persist.oplus.software.radio.sa_tac_control ture
setprop persist.sys.oplus.software.radio.sa_tac_control ture
#灭屏回退SA
settings put system oplus.software.radio.screen_off_disable_sa_enabled false
setprop persist.oplus.software.radio.screen_off_disable_sa_enabled false
setprop persist.sys.oplus.software.radio.screen_off_disable_sa_enabled false
#SA注册失败回退SA
settings put system oplus.software.radio.sa_reg_timeout_enabled false
setprop persist.oplus.software.radio.sa_reg_timeout_enabled false
setprop persist.sys.oplus.software.radio.sa_reg_timeout_enabled false
#查询SA状态失败回退SA
settings put system oplus.software.radio.backoff_sa_cause_network_reject false
setprop persist.oplus.software.radio.backoff_sa_cause_network_reject false
setprop persist.sys.oplus.software.radio.backoff_sa_cause_network_reject false
#PING SA/PING失败回退SA
settings put system oplus.software.radio.sa_pingpong_control_disabled false
setprop persist.oplus.software.radio.sa_pingpong_control_disabled false
setprop persist.sys.oplus.software.radio.sa_pingpong_control_disabled false
#SA数据拨号失败回退SA
settings put system oplus.software.radio.data_call_control_disabled ture
setprop persist.oplus.software.radio.data_call_control_disabled ture
setprop persist.sys.oplus.software.radio.data_call_control_disabled ture
#关闭5G DUMP测试
settings put system oplus.software.radio.disable_5g_nr_5gdump false
setprop persist.oplus.software.radio.disable_5g_nr_5gdump false
setprop persist.sys.oplus.software.radio.disable_5g_nr_5gdump false
#IMS通信注册异常回退SA
settings put system oplus.software.radio.sa_ims_control_disabled false
setprop persist.oplus.software.radio.sa_ims_control_disabled false
setprop persist.sys.oplus.software.radio.sa_ims_control_disabled false
#禁用SA信号弱退回4G
settings put system oplus.radio.enable_weak_signal_backoff 0
setprop persist.oplus.radio.enable_weak_signal_backoff 0
setprop persist.sys.oplus.radio.enable_weak_signal_backoff 0
#WIFI通话回退SA
settings put system oplus.software.radio.wfc_disable_nrsa false
setprop persist.oplus.software.radio.wfc_disable_nrsa false
setprop persist.sys.oplus.software.radio.wfc_disable_nrsa false
#DND异常回退SA
settings put system oplus.software.radio.smart5g_rtt_check_sa false
setprop persist.oplus.software.radio.smart5g_rtt_check_sa false
setprop persist.sys.oplus.software.radio.smart5g_rtt_check_sa false
#屏蔽SA最小值
settings put system oplus.network.sa_screen_off_min 0
setprop persist.oplus.network.sa_screen_off_min 0
settings put system oplus.network.sa_nw_rej_sec 0
settings put system oplus.network.sa_nw_rej_sec 0
setprop persist.oplus.network.sa_nw_rej_sec 0
settings put system oplus.network.sa_pingpong_duration 0
setprop persist.oplus.network.sa_pingpong_duration 0
settings put system oplus.network.sa_reg_timeout_min 0
setprop persist.oplus.network.sa_reg_timeout_min 0
settings put system oplus.network.sa_tac_change_min 0
setprop persist.oplus.network.sa_tac_change_min 0

setprop persist.sys.assert.panic false
setprop persist.sys.oplus.radio.backoff_sa_cause_weak_signal false
setprop persist.sys.oplus.radio.backoff_sa_cause_weak_signal.config false
setprop persist.sys.oplus.radio.weak_sa.backoff false
setprop persist.sys.oplus.radio.weak_sa.backoff_daily_count 0
setprop persist.sys.oplus.radio.weak_sa.dot_daily_count 0

setprop ro.oplus.radio.disable_sa_dump_times 0
setprop ro.oplus.radio.tac_changed_timer 0
setprop ro.oplus.radio.sa_backoff_recover_time 3

setprop persist.sys.oplus.operator.opta=0
setprop persist.vendor.radio.lte_con_stat_delay_timer=0
setprop persist.vendor.radio.scg_con_stat_delay_timer=0

settings put system oplus.radio.light_smart5g_cfg=ver_num=0;screenoff_speed=0;lowbat_speed=0;lowbat_thres=0;dis_endc_timer=0
settings put system oplus.radio.smart5g_ext_basic=ver_num=1;update_time=1
settings put system oplus.radio.smart5g_sa_cfg=ver_num=1;nr_prio_ctrl=1;lte_pref_prohibit_t=900;sa_pref_prohibit_t0=120;sa_pref_prohibit_stage_num=5;irat_pingpong_restrain=false
settings put system oplus.radio.smart5g_thermal_cfg=ver_num=1;enable=1;sa_deprio_enable=1;prohibitinterval=0


