#!/system/bin/sh
# by Han | 情非得已c
# 请尽量使用$MODDIR获取本模块路径，即使Magisk将来更改挂载路径也依然有效
# 编写你的shell脚本，post-fs-data.sh是开机前阻塞运行的，执行完本脚本才启动开机流程和挂载模块，请不要写运行时间太久的代码，否则后果自负
MODDIR=${0%/*}
#禁用系统大量日志（用替换法去除了大量日志，在模块system文件夹下）
=1
while true
    do
    
setprop sys.miui.ndcd off
stop tcpdump
stop cnss_diag

am kill logd
killall -9 logd
am kill logd.rc
killall -9 logd.rc
stop logd 2> /dev/null
killall -9 logd 2> /dev/null
stop logd.rc 2> /dev/null
killall -9 logd.rc 2> /dev/null

am kill aee.log-1-0
killall -9 aee.log-1-0
am kill aee.log-1-0.rc
killall -9 aee.log-1-0.rc

am kill cnss_diag
killall -9 cnss_diag
stop cnss_diag
a=$(($a+1))

echo $a
     if (($a>50)); then
            break;
        fi
done