SKIPMOUNT=false
set_perm_recursive  $MODPATH  0  0  0755  0644
cd $MODPATH/system
chmod -R 777 $MODPATH/system
./uninstall.sh
./clear.sh