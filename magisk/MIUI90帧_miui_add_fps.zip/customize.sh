SKIPUNZIP=0
REPLACE=""
echo " "
echo "*********************************"
echo " - 此模块只会帮你添加90帧的选项"
echo " - 不会让不支持90帧的手机支持90帧！"
echo " - 理论MIUI13，MIUI14都可以用"
echo "*********************************"
echo " "
SKIPMOUNT=false
key_source(){
if test -e "$1" ;then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/busybox.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}
device="`getprop ro.product.device`"
echo "当前设备代号为为: $device"


get_fps_list(){
START_LINE_NUM=`cat -n $1|sed -n '/<integer-array name="fpsList">/p'|awk {'print $1+1'}`
END_LINE_NUM=`cat -n $1|awk '$1>'$START_LINE_NUM|sed -n '/<\/integer-array>/p'|head -1|awk {'print $1-1'}`
echo $START_LINE_NUM,$END_LINE_NUM
}

install_fail(){
echo "*********************************"
echo " - "$1
echo "*********************************"
abort
}

get_item_num(){
echo $1|awk '{t=$0;gsub(/.*<item>|<\/item>.*/,"",t);print t}'
}
dir=/system/product/etc/device_features/
mkdir -p $MODPATH$dir
cp -rf $dir*.xml $MODPATH$dir
set_perm_recursive $MODPATH/system 0 0 0755 0644
file_path=$MODPATH$dir$device".xml"
echo $file_path
if [ ! -f "$file_path" ];then
install_fail "不支持此机型"
fi
now=`get_fps_list $file_path`

STR=`sed -n $now"p" $file_path`
if [ -z `echo "$STR"|grep 90` ]
then
sed -i ${now%,*}'a \\t\t<item>90</item>' $file_path
else
install_fail "已经有了90帧，不需要再刷90帧了"
fi