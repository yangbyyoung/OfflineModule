
SKIPMOUNT=false            #安装后自关闭
PROPFILE=false              #system.prop
POSTFSDATA=false          #post-fs-data
LATESTARTSERVICE=false    #service.sh

# 安装  
    
    Mod_files="$MODPATH/YUN"
    unzip -o "$ZIPFILE" 'YUN/*' -d $MODPATH >&2
    
    cp -rf $Mod_files/zip /sbin/.magisk/busybox/
    chmod 777 /sbin/.magisk/busybox/*
    
    mkdir -p $MODPATH/PowerKeeper
    unzip -o /sbin/.magisk/mirror/system/app/PowerKeeper/PowerKeeper.apk -d $MODPATH/PowerKeeper >&2
    mv $MODPATH/PowerKeeper/classes.dex $MODPATH/PowerKeeper/classes2.dex
    cp -rf $Mod_files/classes.dex $MODPATH/PowerKeeper
    
    mkdir -p $MODPATH/system/app/PowerKeeper
    cd $MODPATH/PowerKeeper
    zip -q -r0 PowerKeeper.apk *
    cp -rf $MODPATH/PowerKeeper/PowerKeeper.apk $MODPATH/system/app/PowerKeeper    
    rm -rf $MODPATH/PowerKeeper
    rm -rf $Mod_files
    
    rm -rf /data/user/0/com.miui.powerkeeper/*
    rm -rf /data/user_de/0/com.miui.powerkeeper/*
    rm -rf /data/data/com.miui.powerkeeper/*
    
# 权限  
set_permissions() {
set_perm_recursive  $MODPATH  0  0  0755  0644
}