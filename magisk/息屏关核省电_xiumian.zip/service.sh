#感谢：部分代码来自酷安@hwwwww。注意：由于脚本采用的是while循环扫描的方式，扫描时间为3s，所以在开启屏幕时会有1秒到3秒的卡顿。

#关闭屏幕时会启用省电调度powersave和关闭6个cpu核心，开启屏幕时会恢复，达到待机省电的效果。

#开始执行...

sleep 2s

chmod 777 /data/adb/modules/xiumian/powersave.sh
chmod 777 /data/adb/modules/xiumian/service.sh

#执行息屏关核命令
while :
do
sh /data/adb/modules/xiumian/powersave.sh
sleep 3s
done