#!/system/bin/sh
rm -rf /data/vendor/thermal/config
echo '600' > /sys/class/power_supply/bms/temp_hot 2>/dev/null & sleep 0.2
echo '0' > /sys/class/power_supply/battery/sw_jeita_enabled 2>/dev/null &
echo '600' > /sys/class/power_supply/bms/temp_warm 2>/dev/null &
echo '0' > /sys/class/power_supply/bms/temp_cool 2>/dev/null &
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
#boot detection
until [ $(getprop init.svc.bootanim) = "stopped" ]
do
sleep 2
done
#Other
chmod 0755/sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
chmod 0755/sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
# configure governor settings for little cluster小核心调度
echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo 1804800 > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/rate_limit_us
echo 1804800 > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo 1804800 > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/pl
echo 1804800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
# configure governor settings for big cluster大核心调度
echo "performance" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo "2419200" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
echo "2419200" > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
echo "2419200" > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/rate_limit_us
echo "2419200" > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo "performance" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo "2841600" > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq
echo "2841600" > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq
echo "0:1766400 1:1766400 2:1766400 3:1766400 4:2803200 5:2803200 6:2803200 7:2803200" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "10000"> /sys/module/cpu_boost/parameters/input_boost_ms
# cpuset parameters任务分配机制
#后台任务
echo 0-7 > /dev/cpuset/background/cpus
#系统级后台任务
echo 0-7 > /dev/cpuset/system-background/cpus
#前台任务加速核心
echo 0-7 > /dev/cpuset/foreground/boost/cpus
#前台任务
echo 0-7 > /dev/cpuset/foreground/cpus
#当前界面任务
echo 0-7 > /dev/cpuset/top-app/cpus
#相机任务
echo 0-7 > /dev/cpuset/camera-daemon/cpus
echo 0-7 > /dev/cpuset/foreground/boost/cpus
#后台任务
echo    "100" > /dev/stune/background/schedtune.boost
#请求低延迟
echo    "1" > /dev/stune/background/schedtune.prefer_idle
#前台任务
echo    "100" > /dev/stune/foreground/schedtune.boost
#请求低延迟
echo    "1" > /dev/stune/foreground/schedtune.prefer_idle
#当前界面的任务
echo    "100" > /dev/stune/top-app/schedtune.boost
#请求低延迟
echo    "1" > /dev/stune/top-app/schedtune.prefer_idle
#rt任务激进延迟
echo    "100" > /dev/stune/rt/schedtune.boost
#请求低延迟
echo    "1" > /dev/stune/rt/schedtune.prefer_idle
#Io
echo    "deadline" >  /sys/block/sda/queue/scheduler
echo    "2048" >  /sys/block/sda/queue/read_ahead_kb
echo    "1024" >  /sys/block/sda/queue/nr_requests
#GPU
echo    "performance" >  /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo    "875000000" >  /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
echo    "875000000" >  /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
echo    "0" >  /sys/class/kgsl/kgsl-3d0/min_pwrlevel
echo    "0" >  /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo    "0" >  /sys/class/kgsl/kgsl-3d0/default_pwrlevel
#性能模式