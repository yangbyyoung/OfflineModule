
# 如果您不希望Magisk挂载，则设置为true
#为您提供任何文件。大多数模块都不想要
#将此标志设置为true
SKIPMOUNT=false
# 如果需要加载system.prop，则设置为true
PROPFILE=false
# 如果需要后fs-data脚本，则设置为true
POSTFSDATA=false

# 如果需要late_start服务脚本，则设置为true
LATESTARTSERVICE=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"


# Construct your own list here
REPLACE="
"
#_______________________________________________
print_modname() {
   ui_print "△冲冲冲！！！＼＼\\٩( 'ω' )و //／／冲冲冲！！！▼"
   ui_print "**************广告位置*****************"
   ui_print "欢迎使用YouGod框架模块"
   ui_print "官宣粉丝交流群938499734"
   ui_print "芥子空间：官宣ღ"
   ui_print "酷安：官宣吖"
   ui_print "**************广告位置*****************"
   ui_print "by guanxuan"
   end_time=$(date "+%Y-%m-%d %H:%M:%S")
   sc=$(date --date="${start_time}" +%s)    
   ec=$(date --date="${end_time}" +%s)
   echo "- 刷入耗时：$((ec-sc))秒"
   time=$(date "+%Y-%m-%d %H:%M:%S")
   echo "- 当前时间: $time"
   echo "- 注意：刷入后第一次开机会清理gpu缓存。"
   echo "- 注意：开机会稍久，一般两三分钟，请耐心等待！"
   echo "模块刷入时间：$time" >> $T
}


# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code

