#!/system/bin/sh
# 等待彻底开机完成
until [ "$(getprop init.svc.bootanim)" = "stopped" ]; do
	sleep 5
done
while [ ! -d "/sdcard/Android" ]; do
	sleep 5
done

# 测试网络
while :; do
	p=$(ping -c 1 -w 5 www.baidu.com | grep -c 'ms')
	[ $p != 0 ] && break
done
setprop service.adb.tcp.port 5555
stop adbd
start adbd
