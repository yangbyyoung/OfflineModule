 ui_print "*******************************"
  ui_print "MIUI终极优化模块（爱玩机特供兼容留云精简版）刷入中"
  ui_print "MIUI终极优化模块（爱玩机特供兼容留云精简版）刷入完成"
  ui_print "作者:爽歪歪"
  

  
  
  set_perm_recursive  $MODPATH  0  0  0755  0644


AUTOMOUNT=true

MOD_Version="`grep_prop version $TMPDIR/module.prop`"
MOD_Author="`grep_prop author $TMPDIR/module.prop`"
MOD_Description="`grep_prop description $TMPDIR/module.prop`"
MarketName="`getprop ro.product.marketname`"
Device="`getprop ro.product.device`"
Model="`getprop ro.product.model`"
MIUI="`getprop ro.miui.ui.version.name`"
Version="`getprop ro.build.version.incremental`"
Android="`getprop ro.build.version.release`"
za=$MODPATH/YuK/7za #$za a -tzip -mx=7 -mmt

