SKIPMOUNT=false
LATESTARTSERVICE=true
POSTFSDATA=true
PROPFILE=true
print_modname() {
  ui_print "*******************************"
  ui_print "   Magisk Module:          "
  ui_print "   MiUI14小白条沉浸         "
  ui_print "   By Casun咔咔            "
  ui_print "   酷安@Casun2022         "
  ui_print "   B站@韦兰Waylan         "
  ui_print "   玩机企鹅群:1023942204   "
  ui_print "*******************************"
}
on_install() {
 ui_print "- 正在释放文件"
 unzip -o "$ZIPFILE" 'system/product/overlay/SystemUi.apk' -d $MODPATH >&2
}
set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
}