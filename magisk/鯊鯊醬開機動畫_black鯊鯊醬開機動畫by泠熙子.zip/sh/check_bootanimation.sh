if [[ "$bootanimation_check" = "1" ]];then
for i in $MODPATH$bootpath;do
rm -rf $MODPATH/*.zip
[[ ! -e $i ]] && abort "並未檢測到有效的開機動畫，請確保模塊安裝包的“根目錄”里含有有效的開機動畫“zip”文件（其他壓縮格式的文件會導致無法使用）"
done
fi

if [[ "$bootanimation_check" = "2" ]];then
for i in $MODPATH$bootpath_dark;do
rm -rf $MODPATH/*.zip
[[ ! -e $i ]] && abort "並未檢測到有效的開機動畫，請確保模塊安裝包的“根目錄”里含有有效的開機動畫“zip”文件（其他壓縮格式的文件會導致無法使用）"
done
fi

[[  -e $MODPATH/*.zip ]] && abort "並未檢測到對應文件" 