echo "*******************************"
echo "     Module author: 嘟嘟ski（soulize二改）    "
echo "*******************************"
echo
echo
echo " 此模块用于小米MIX4机型，国行MIUI恢复95°C温度墙 "
echo " 温度墙本身与模块无关 "
echo " 如果你从不更新系统，可以在安装脚本执行完成后删除模块 "
echo
echo


soc=$(cat /sys/devices/soc0/machine | tr 'A-Z' 'a-z')
if [[ "$soc" != "lahaina" ]]; then
  echo
  echo
  echo "此模块仅适用于骁龙888平台"
  echo
  echo

  exit 2
fi

sku=$(getprop ro.boot.hardware.sku | tr 'A-Z' 'a-z')
if [[ "$sku" == "odin"  ]]; then
  echo
else
  echo "此模块仅适用于小米MIX4机型"
  exit 2
fi


# 以下内容同 service.sh


slot=$(getprop ro.boot.slot_suffix)
echo '当前系统插槽：' $slot

img=''
case "$sku" in
odin)
  img='V12.5.2.0_devcfg.mbn'
;;
*)
  echo '无可用镜像文件'
  exit 2
;;
esac

if [[ -f $MODPATH/$img && -e /dev/block/by-name/devcfg$slot ]]; then
  dd if=$MODPATH/$img of=/dev/block/by-name/devcfg$slot
  echo '安装完成，现在可以重启手机'
  echo '此操作具有一定风险，如果你还没有备份重要数据，建议先备份再重启！'
else
  echo '必要文件路径无法访问，安装失败！'
  exit 2
fi
