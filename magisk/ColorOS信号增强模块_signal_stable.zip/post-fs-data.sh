#!/system/bin/sh
MODDIR=${0%/*}
mount --bind $MODDIR/files/BlackListApp.apk /product/priv-app/BlackListApp/BlackListApp.apk