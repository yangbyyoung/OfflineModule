#!/system/bin/sh
MODDIR=${0%/*}
setenforce 1