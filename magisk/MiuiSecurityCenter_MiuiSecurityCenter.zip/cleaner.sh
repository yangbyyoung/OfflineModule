PKG="com.miui.securitycenter
     com.xiaomi.micloud.sdk
     com.miui.cleanmaster
     com.miui.securityadd
     com.lbe.security.miui
     com.miui.powerkeeper
     com.miui.guardprovider"
for PKGS in $PKG; do
  rm -rf /data/user/*/$PKGS/cache
done


