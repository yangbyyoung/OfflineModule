selinux_1(){
se1=`find /data/adb/modules -iname "*.sh" -type f`
for i in $se1;do grep -l -w "setenforce 0" $i|cut -d / -f 5;done
}

selinux_2(){
se1=`find /data/adb/modules -iname "*.sh" -type f`
for i in $se1;do grep -l "/sys/fs/selinux" $i|cut -d / -f 5;done
}