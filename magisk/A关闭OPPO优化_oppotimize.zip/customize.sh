SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************
 "
 ui_print "*******************************"
 ui_print "     	Magisk Module        "
 ui_print "Make By ❤️酷安：官宣吖❤️"
 ui_print "*******************************"
set_perm_recursive $MODPATH 0 0 0755 0777

#官宣粉丝交流群：938499734，搞机！外挂！文案！