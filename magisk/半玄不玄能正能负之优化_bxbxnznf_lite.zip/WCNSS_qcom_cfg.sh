
function correctpath(){
	case `echo "$1"` in
	/system_ext* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	/vendor* )
		echo "/system"$1""
	;;
	/product* )
		echo "/system"$1""
	;;
	esac
}


find /system/ /system_ext /vendor /product -iname 'WCNSS_qcom_cfg.ini' -type f 2> /dev/null | while read file ;do
file=$(correctpath $file)
mkdir -p $MODPATH$(dirname $file)
cp -rf $file $MODPATH$(dirname $file)
sed 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
sed -i 's/gEnablefwlog=.*/gEnablefwlog=0/g' $MODPATH$file
done

logdir=/data/vendor/wlan_logs
test -e $logdir && rm -rf "$logdir/*"


