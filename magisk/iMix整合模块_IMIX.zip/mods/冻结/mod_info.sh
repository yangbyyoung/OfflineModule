# 安装时显示的模块名称
mod_name="MIUI12.5精简：水宝cb（冻结部分）"
# 模块介绍
mod_install_desc="精简系统常驻软件与无用软件，减少后台占用，提高流畅度（垃圾清理，小米画报，stk等）"
# 安装时显示的提示
mod_install_info="是否冻结[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="冻结$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc="[$mod_select_yes_text]"
# 按下[音量-]选择的功能提示
mod_select_no_text="保留$mod_name"
# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{

pm disable com.miui.cleanmaster

pm disable com.android.stk

pm disable com.miui.analytics

pm disable com.mfashiongallery.emag

pm disable com.duokan.reader

    return 0
}

mod_install_no()
{
    return 0
}