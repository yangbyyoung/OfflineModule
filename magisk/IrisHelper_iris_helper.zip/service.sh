#!/system/bin/sh
MODDIR=${0%/*}

$MODDIR/busybox nohup sh $MODDIR/iris_helper.sh >/dev/null 2>&1 &