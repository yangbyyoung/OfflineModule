# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
MODDIR=${0%/*}
killall -9 tts-server-go >/dev/null 2>&1
rm -rf "$MODDIR/tts-server-go"
