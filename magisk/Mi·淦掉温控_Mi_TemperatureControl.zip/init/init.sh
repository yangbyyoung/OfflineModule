sleep 60
for i in /data/adb/modules/Mi_TemperatureControl/sh/*.sh ;do
  chmod 777 $i
  /system/bin/sh $i
done

for i in /data/adb/modules/Mi_TemperatureControl/sh/* ;do
  chmod 777 $i
  /system/bin/sh $i
done