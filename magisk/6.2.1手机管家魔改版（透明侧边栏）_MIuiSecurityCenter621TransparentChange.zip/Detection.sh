function dalvik_cache() {
 getName=$(basename "$(GetApkPath $1 apk)" .apk)
 dda=/data/dalvik-cache/arm
 [[ -d ${dda}64 ]] && dda=${dda}64
 for i in $getName; do
  rm -rf $dda/system@*@${i}*
 done
}

function GetApkPath() {
 file_path=$(pm path "$1" | sed 's/package://g')
 if [[ $(echo "$2" | grep "apk") == "apk" ]]; then
  echo "${file_path}"
 elif [[ $(echo "$2" | grep "path") == "path" ]]; then
  echo "${file_path%/*}"
 elif [[ $(echo "$2" | grep "name") == "name" ]]; then
  echo "${file_path##*/}"
 fi
}

#模块激活检测
barrage=$(getprop ro.barrage.macrotest)
if [[ "$barrage" == "1" ]]; then
 rm -rf /data/system/package_cache/*
 settings put secure gb_bullet_chat 1
 settings put secure gb_boosting 1
else
 settings put secure gb_boosting 0
 settings put secure gb_bullet_chat 0
 rm -rf /data/system/package_cache/*
fi
