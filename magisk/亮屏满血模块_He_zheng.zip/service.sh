#!/system/bin/sh
/sbin/magisk su -c 'sh /data/adb/modules/He_zheng/data1.sh'
/sbin/magisk su -c 'sh /data/adb/modules/He_zheng/data2.sh'
/sbin/magisk su -c 'sh /data/adb/modules/He_zheng/data3.sh'