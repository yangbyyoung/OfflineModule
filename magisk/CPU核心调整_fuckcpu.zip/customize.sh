#创建文件夹
mkdir /sdcard/Android/MW_CPUTurbo
#写入开关CPU核心代码
echo "echo 已调整为省电模式
echo "省电" > /data/adb/modules/fuckcpu/config.txt
chmod 777 /data/adb/modules/fuckcpu/CPUTurbo.sh
su -c /data/adb/modules/fuckcpu/CPUTurbo.sh" > /sdcard/Android/MW_CPUTurbo/省电模式.sh
echo "echo 已调整为性能模式 
echo "性能" > /data/adb/modules/fuckcpu/config.txt
chmod 777 /data/adb/modules/fuckcpu/CPUTurbo.sh
su -c /data/adb/modules/fuckcpu/CPUTurbo.sh" > /sdcard/Android/MW_CPUTurbo/性能模式.sh
#安装脚本
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
module_version="`grep_prop version $TMPDIR/module.prop`"
module_name="`grep_prop name $TMPDIR/module.prop`"
module_id="`grep_prop id $TMPDIR/module.prop`"
  ui_print "-------------------------------------"
  ui_print "- $module_name "
  ui_print "- 作者: 魔威"
  ui_print "- 版本: $module_version"
  ui_print "-------------------------------------"
  ui_print "- 机型: $var_device"
  ui_print "- 安卓版本: $var_version"
  ui_print "安装脚本马上开始"
  sleep 3
  ui_print "安装完成请重启"
  