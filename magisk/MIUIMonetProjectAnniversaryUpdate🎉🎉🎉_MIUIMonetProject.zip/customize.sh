#!/bin/sh
chmod 775 "$MODPATH/install"
$MODPATH/install