#######################
#  哔哩哔哩 @请叫我副台长     #
#######################
#!/system/bin/sh
MODDIR=${0%/*}

echo 1 > /sys/fs/f2fs/sda17/gc_booster
echo 200 > /sys/fs/f2fs/sda17/cp_interval
