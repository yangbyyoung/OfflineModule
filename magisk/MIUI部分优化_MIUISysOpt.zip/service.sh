#!/system/bin/sh
MODDIR=${0%/*}
busybox=/data/adb/magisk/busybox
#关闭hw叠加层
service call SurfaceFlinger 1008 i32 1
#开启极致模式的开关
settings put Secure speed_mode_enable 1
#开启自动转屏按钮
settings put secure show_rotation_suggestions 1
#cgroup和millet
if [ `getprop sys.boot_completed` == "1" ];then
	umount /sys/fs/cgroup/freezer
	umount /sys/fs/cgroup
	mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup/
	mkdir /sys/fs/cgroup/frozen/
	chown system:system /sys/fs/cgroup/frozen/cgroup.procs
	chown system:system /sys/fs/cgroup/frozen/cgroup.freeze
	echo 1 > /sys/fs/cgroup/frozen/cgroup.freeze
	mkdir /sys/fs/cgroup/unfrozen/
	chown system:system /sys/fs/cgroup/unfrozen/cgroup.procs
	chown system:system /sys/fs/cgroup/unfrozen/cgroup.freeze
	break
fi
#fstrim
touch $MODDIR/fstrim.log
chmod +rwx $MODDIR/fstrim
sh $MODDIR/fstrim >>$MODDIR/fstrim.log
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c $MODDIR/cron.d
