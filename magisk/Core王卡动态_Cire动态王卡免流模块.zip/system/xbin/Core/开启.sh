"${0%/*}"/Core/Chen start
auto_daemon() {
    sleep 5000
sh ../动态/开启.sh
}
auto_daemon &
setprop auto_pid $!