SKIPMOUNT=false
#安装后开关
PROPFILE=true
#system.prop文件
POSTFSDATA=false
#post-fs-data脚本
LATESTARTSERVICE=false
#service.sh中脚本
print_modname() {
  ui_print "MIUI14音质振动优化"
  ui_print "请在安装前安装防砖模块，以免出现意外"
  ui_print "应该适用于MIUI14全机型"
}
on_install() {
ui_print "- 5s后开始安装本模块，请确定已安装防砖模块"
sleep 5s
if [ -d /storage/emulated/0/.音效固件打包专用  ];then
        echo 检测到残留
          rm -rf /storage/emulated/0/.音效固件打包专用
else
        echo 开始生成
fi
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/firmware
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib64
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/etc
mkdir -p /storage/emulated/0/.音效固件打包专用/system/app
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib
sleep 2s
cp -r /system/vendor/lib/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib/
cp -r /system/vendor/etc/audio /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/app/MiSound /storage/emulated/0/.音效固件打包专用/system/app/
cp -r /system/vendor/etc/acdbdata /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/vendor/lib64/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib64/
cp -r /system/vendor/firmware/aw8697_rtp_1.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/
cp -r /system/vendor/firmware/aw8697_haptic.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/
sleep2s
tar -cvzf 音效固件打包.tar.gz /storage/emulated/0/.音效固件打包专用/ 
cp -r ./音效固件打包.tar.gz /storage/emulated/0/
rm -rf ./音效固件打包.tar.gz
rm -rf /storage/emulated/0/.音效固件打包专用
sleep 2s
rename /storage/emulated/0/音效固件打包.tar.gz /storage/emulated/0/音效固件打包.zip
  ui_print "- 生成完毕，保存在根目录，正在安装"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 安装完毕，开始清理碎片"
    /dev/*/.magisk/busybox/fstrim -v /cache 
    rm -rf /data/system/package_cache/*
  ui_print "-安装完成"
}

set_permissions() {
 set_perm_recursive $MODPATH 0 0 0755 0644
 set_perm  $MODPATH/system/app/MiSound/MiSound.apk  0  0  0644
 #set_perm  $MODPATH/system/priv-app/MusicFX/MusicFX.apk  0  0  0644
#设置权限，基本不要去动
  ui_print "正在设置权限，请稍等"
}