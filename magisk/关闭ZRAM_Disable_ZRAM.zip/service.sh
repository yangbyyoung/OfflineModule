#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done
MODDIR=${0%/*}
nohup ${MODDIR}/disable_zram.sh > /dev/null 2>&1 &