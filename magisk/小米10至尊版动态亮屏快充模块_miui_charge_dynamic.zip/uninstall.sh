#!/system/bin/sh
rm -rf /data/adb/modules/miui_charge_dynamic/
exit 0