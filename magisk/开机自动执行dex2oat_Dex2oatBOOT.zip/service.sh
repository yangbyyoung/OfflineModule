#!/system/bin/sh
MODDIR=${0%/*}
#相关路径
dex2oat_config="/data/dex2oat.prop"
dex2oat_log="/cache/dex2oat.log"
optionalapp_config="/data/optionalapp.prop"
#相关配置
Dex2oat=`cat $dex2oat_config | grep -v '^#' | grep "^dex2oat=" | cut -f2 -d '='`
Select=`cat $dex2oat_config | grep -v '^#' | grep "^select=" | cut -f2 -d '='`
Optionalapp=`cat $dex2oat_config | grep -v '^#' | grep "^optionalapp=" | cut -f2 -d '='`
#写个日志
touch $dex2oat_log
echo "开始执行dex2oat" > $dex2oat_log
echo "当前配置：$Dex2oat；当前选择：$Select；自选应用：$Optionalapp" >> $dex2oat_log
#等30秒压压惊
sleep 30
#判断并运行dex2oat
if [ $Dex2oat = "speed-profile" ]; then
	. $MODDIR/dex2oat/speed-profile 2>&1 | tee -a $dex2oat_log
else
	if [ $Dex2oat = "speed" ]; then
		. $MODDIR/dex2oat/speed 2>&1 | tee -a $dex2oat_log
	else
		if [ $Dex2oat = "everything" ]; then
			. $MODDIR/dex2oat/everything 2>&1 | tee -a $dex2oat_log
		else
			echo "✘配置读取错误" >> $dex2oat_log
		fi
	fi
fi
echo "运行完毕" >> $dex2oat_log
