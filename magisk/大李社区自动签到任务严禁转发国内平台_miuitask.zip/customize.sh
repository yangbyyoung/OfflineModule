#!/system/bin/sh


ui_print "- 开始设置环境权限."
set_perm_recursive ${MODPATH} 0 0 0755 0755
set_perm  ${MODPATH}/miuitask 0 0 0755
ui_print "严禁转发到国内平台 QQ 微信 酷安等 不要那么弱智!!!"
ui_print "严禁转发到国内平台 QQ 微信 酷安等 不要那么弱智!!!"
ui_print "严禁转发到国内平台 QQ 微信 酷安等 不要那么弱智!!!"
ui_print ""
ui_print "在小米社区提起此脚本/模块的你妈死了 你这辈子就是小米性奴 舔你那米爹"
ui_print "在小米社区提起此脚本/模块的你妈死了 你这辈子就是小米性奴 舔你那米爹"
ui_print ""
ui_print "************************************************"
ui_print "配置教程见 https://github.com/heinu123/miui-auto-tasks"
ui_print "未配置情况下不会执行签到任务 自己看readme去"
ui_print ""
ui_print ""
ui_print "telegram频道: @wtdnwbzda"
ui_print "博客: https://www.heinu.cc"
ui_print ""
ui_print "！！！为了让你阅读以上消息，安装进度暂停3秒！！！"
ui_print "无需重启 立即生效"
sleep 3