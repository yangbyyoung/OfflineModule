# Modify_the_Zram


### 描述：
利用安卓设备自身init.qcom.post_boot.sh文件实现Zram的大小设置与关闭开启。
### 功能：
支持开启2GZram
支持开启4GZram
支持关闭Zram或者自定义开启的Zram大小
### 修复：
优化提示文本。

