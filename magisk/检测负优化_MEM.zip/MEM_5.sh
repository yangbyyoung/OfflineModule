echo "
————————————————————🍂🍃🍂🍃
"
. $MODPATH/prop.sh
echo "
●————————⑥老旧/危险代码检测(prop)————————●
"
echo "－请你自行考虑是否要移除或者禁用模块。"
cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
for i in $(hw2);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块包含了老旧的代码，即和GPU有关的HW代码。"
echo "－例如：hw3d.force=1 hw2d.force=2"
echo "－这类代码在当今(安卓8.0以上)起到的作用已经可以忽略的了。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
for i in $(hw3);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块包含了老旧的代码，即和GPU有关的HW代码。"
echo "－例如：hw3d.force=1 hw2d.force=2"
echo "－这类代码在当今(安卓8.0以上)起到的作用已经可以忽略的了。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
for i in $(sqlite);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块可能包含了危险代码。"
echo "－例如：debug.sqlite.syncmode=OFF debug.sqlite.wal.syncmode=OFF"
echo "－这类代码如果全部设置为OFF，很可能会导致数据丢失。"
echo "－问题频繁出现在通话记录/联系人/部分设置……丢失"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
for i in $(sqlite_wal);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块可能包含了危险代码。"
echo "－例如：debug.sqlite.syncmode=OFF debug.sqlite.wal.syncmode=OFF"
echo "－这类代码如果全部设置为OFF，很可能会导致数据丢失。"
echo "－问题频繁出现在通话记录/联系人/部分设置……丢失"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
if [[ -e $module_id/system/lib/libsqlite.so ]] || [[ -e $module_id/system/lib64/libsqlite.so ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－检测到此模块可能包含了危险代码。"
echo "－如果继续使用，很可能会出现问题导致数据丢失。"
echo "－问题频繁出现在通话记录/联系人/部分设置……丢失"
echo "－模块虽然是用的替换/添加sqlite 驱动"
echo "－但其实和debug.sqlite.syncmode=OFF debug.sqlite.wal.syncmode=OFF这类代码毫无区别"
echo "－其结果都是关闭了fsync"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
for i in $(net);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－有这个代码的模块要多注意了"
echo "－示例：ro.config.hw_power_saving=true"
echo "－true 则表示可以在手机空闲(待机)时，进行断网，false 则代表禁用。"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
for i in $(picture);do
if [[ "$module_id" = "$i" ]];then
echo " "
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
echo "－名称：${name:5}"
echo "－作者：${author:7}"
echo "－简介：${description:12}"
echo " "
echo "－大小：$size"
echo " "
echo "－有这玩意的模块，多半是玄学"
echo "－⏩■■■■■■■■■■■■■■■■■■■■■■■■■■⏪"
echo " "
fi
done
done
echo "
————————————————————🍂🍃🍂🍃
"
echo ""
echo ""