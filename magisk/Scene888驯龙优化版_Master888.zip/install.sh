SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
#语法定义
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
#(弃用)模块说明显示
D="`grep_prop description $TMPDIR/module.prop`"
BUSYBOX="/data/adb/magisk/busybox"
ui_print "- $C    "
ui_print "- 设备: $var_device"
ui_print "- 系统: $var_version"
ui_print "- 作者：$B"
#查找并删除旧模块
ui_print "- 查找并删除旧模块"
rm -rf /data/adb/modules/Master888
rm -f /data/powercfg.sh
rm -f /data/powercfg.json
ui_print "- 提取文件"
#解压文件至模块目录
unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
ui_print "- 执行文件配置"
#Copy&权限定义
cp $MODPATH/config/powercfg.sh /data
cp $MODPATH/config/powercfg.json /data
chmod 0644 /data/powercfg.sh
chmod 0644 /data/powercfg.json
ui_print ""
ui_print " 请搭配Scene使用，刷入后自动识别                             "
ui_print "                  "
ui_print "请停用其它调度和与本模块功能重复的模块，防止冲突及意外发生。"
ui_print "                   "
ui_print "游戏掉帧可选搭配asoul游戏优化模块或开启游戏稳帧会增加发热和耗电                                     "
ui_print "                   "
ui_print " 请使用配套的gpu降压文件，以免影响调度                    "
ui_print "https://wwt.lanzouj.com/b01jp7atc密码:d4ia 下载gpu降压文件        "
ui_print "                   "
ui_print "                   "
ui_print "可选‘再Scene附加设置，运行性能中关闭boost                     "
ui_print "                   "
ui_print "    安装完成      "
ui_print "    重启生效      "
set_perm_recursive  $MODPATH  0  0  0755  0644