function sponsor() {
echo "#################################
 - 按音量键＋: 赞助作者
 - 按音量键－: 下次一定
#################################"
	while :;do choose="$(getevent -qlc 1 | awk '{ print $3 }')";case "${choose}" in KEY_VOLUMEUP)echo "感谢支持"; am start -a android.intent.action.VIEW -d  https://afdian.net/a/HCha1 >/dev/null &;;KEY_VOLUMEDOWN);;*)continue;esac;break;done
}
#########main##########
if [ -f "/data/adb/modules/Hc_memory/module.prop" ]; then
  versionCode=$(grep "versionCode=" /data/adb/modules/Hc_memory/module.prop | cut -d "=" -f 2)
  if [  $versionCode < 210 ]; then
    echo "内存管理非最新版，不兼容冰箱v3，退出模块"
    exit 1
  fi
fi
freezer="/data/media/0/Android/Hc_tombstone"
mkdir -p $freezer
if [[ ! -f $freezer/.sponsor ]];then
    sponsor
    echo 'no' > $freezer/.sponsor
fi
[[ ! -f $freezer/白名单.conf ]] && cp $MODPATH/白名单.conf $freezer/白名单.conf
[[ ! -f $freezer/强制黑名单.conf ]] && cp $MODPATH/强制黑名单.conf $freezer/强制黑名单.conf
home=$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')
srf=$(ime list －s |grep 'packageName' |awk -F '=' '{print $NF}' |awk 'NR==1')
confb=$freezer/白名单.conf
if [[ -z $(cat $confb | grep $srf) ]]; then
	sed -i "1i\#输入法，切勿删除\n$srf" $confb
fi
if [[ -z $(cat $confb | grep $home) ]]; then
	sed -i "1i\#默认桌面，切勿删除\n$home" $confb
fi
root='[ "$(id -u)" = 0 ]||{ echo "- 正在获取root权限";exec su -c "sh \"$0\" \"$@\"";}
'
[[ -d /data/adb/modules/HcCacheFridge ]] && echo "检测到旧墓碑模块，已自动关闭旧墓碑" && touch /data/adb/modules/HcCacheFridge/disable
if [[ $(grep '已加入白名单' $freezer/白名单.conf) != '' ]];then
echo '无需添加'
else
echo "
#系统进程已加入白名单，上限一千行，误删
" >> $freezer/白名单.conf
pm list packages -s |awk -F : '{print$NF}' >> $freezer/白名单.conf
echo '添加成功'
fi
awk '!a[$0]++' $freezer/白名单.conf > $freezer/白名单.conf.bak
mv $freezer/白名单.conf.bak $freezer/白名单.conf
echo /data/adb/modules/Hc_tombstone/gx.sh >$freezer/更新配置.sh
chmod -R 777 $freezer
find /sdcard/Android/Hc_tombstone/ -type f ! -name "白名单.conf*" ! -name '强制黑名单.conf' ! -name '.sponsor' ! -name "更新配置.sh" -delete
echo "  配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer
配置文件：$freezer"
set_perm_recursive $MODPATH 0 0 0755 0777
rm -rf "$MODPATH/*.conf"