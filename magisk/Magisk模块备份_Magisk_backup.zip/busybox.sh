busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
test -e "$magiskbusybox" && {
mkdir -p "$busyboxdir"
chmod -R 777 "$busyboxdir"
chmod 777 "$magiskbusybox"
$magiskbusybox --install -s $busyboxdir
} || abort "－ 您的magisk busybox 怎么不见了？"

