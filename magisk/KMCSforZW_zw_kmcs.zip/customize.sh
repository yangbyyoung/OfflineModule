##########################################################################################
#
# Magisk模块安装脚本
#
##########################################################################################
# 如果您需要更多的自定义，并且希望自己做所有事情
# 请在custom.sh中标注SKIPUNZIP=1
# 以跳过提取操作并应用默认权限/上下文上下文步骤。
# 请注意，这样做后，您的custom.sh将负责自行安装所有内容。
SKIPUNZIP=1
# 如果您需要调用Magisk内部的busybox，请在custom.sh中标注ASH_STANDALONE=1
ASH_STANDALONE=0
# 脚本当前路径
MODDIR=${0%/*}
# 模块应该被安装到的路径 MODPATH；可以临时存储文件的路径 TMPDIR；模块的安装包(zip)的路径 ZIPFILE

####################################
# 安装
####################################
ui_print "

    #######################################
                  KMCS for ZW
                    乐阿兰那
    #######################################
       检测手机是否已经破解卡米的模块。如安装过程中
    断、如安装结果与实际情况不符，请截屏安装过程，并
    写明哪里有问题，同时附手机services.jar文件给我。
    我QQ邮箱157947621@qq.com
    检测过程需要2~4分钟。
          **************************
   【提醒】模块安装过程中将检测手机是否已经进行了破
    解卡米操作，需要耗时2~4分钟！
    #######################################

"

# 将 $ZIPFILE 提取到 $MODPATH
ui_print "-   开始解压模块文件"
unzip -qo "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
# 检测是否已破解卡米
ui_print "-   which dexdump：$(which dexdump)"
test -z "$(which dexdump)" &&  { ui_print "-   没有dexdump命令，无法解包classes*.dex文件";sleep 3s;abort "-   模块安装程序终止";}
services_path=$(find /system -type f -iname "services.jar" 2>/dev/null)
ui_print "-   services_path：$services_path"
test -z "$services_path" && { ui_print "-   没有services.jar文件，无法检测是否已经破解卡米";sleep 3s;abort "-   模块安装程序终止";}
services_size=$(/system/bin/ls -l /system/framework/services.jar | cut -f5 -d ' ')
ui_print "-   services_size：$services_size"
test "$services_size" -le "4000000" && { ui_print "-   services.jar小于4MB，未合并odex";sleep 3s;abort "-   模块安装程序终止";}
unzip "$services_path" classes.dex classes2.dex -d $TMPDIR
jckm_0=$(dexdump -d $TMPDIR/classes*.dex | grep -f $MODPATH/jckm.txt)
ui_print "-   jckm_0列表：$jckm_0"
jckm_1=$(dexdump -d $TMPDIR/classes*.dex | grep -f $MODPATH/jckm.txt | wc -l)
test "$jckm_1" -ge "1" &&  { ui_print "-   没有事先破解卡米，模块不适用！！！";sleep 3s;abort "-   模块安装程序终止";} ||
ui_print "-   恭喜！！已实现破解卡米，模块适用！"
ui_print "-   测试成功结束，请清屏并发给作者！"
sleep 3s
abort "-   本模块会自动清除，对手机无任何修改、残留"
#################################
# 权限设置
#################################
# 对于目录(包括文件):
# set_perm_recursive  <目录>    <所有者> <用户组> <目录权限> <文件权限>
# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644
# 对于文件(不包括文件所在目录)

#################################
# 删除多余文件
#################################
rm -rf $MODPATH/customize.sh $MODPATH/*.md $MODPATH/jckm.txt 2>/dev/null