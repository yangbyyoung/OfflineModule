#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 10
chmod 777 /sys/class/power_supply/battery/step_charging_enabled
while true; do
echo '0' > /sys/class/power_supply/battery/step_charging_enabled
sleep 1
done