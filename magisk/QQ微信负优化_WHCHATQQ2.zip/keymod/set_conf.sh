#/system/bin/sh

Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")

MODPATH="/data/adb/$Magisk_mod/WHCHATQQ2"

export PATH=/system/bin:$MODPATH/busybox:$PATH

crond_file=$MODPATH/keymod/task/root

function show_value() {
	local value=$1
	local file=/data/media/0/Android/QQ微信负优化/QQ微信负优化.conf
	cat "$file" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

controlsifwd() {
	local ifw=/data/system/ifw
	local file="$MODPATH/keymod/ifw"
	test ! -e "$ifw" && mkdir -p $ifw
	if test -e $file; then
		cp -rf $file/* $ifw
		chmod -R 0700 $ifw
		chown -R system:system $ifw
	else
		echo "错误，ifw配置文件不存在"
	fi
}

controlsifwe() {
	local file="
	/data/system/ifw/com.tencent.mm$.xml
	/data/system/ifw/com.coolapk.market$.xml
	/data/system/ifw/com.tencent.mobileqq$.xml
	/data/system/ifw/com.tencent.tim$.xml
	"
	for i in $file; do
		test -e "$i" && {
			rm -rf "$i" 2>/dev/null
		}
	done
}

set_pm_QQ() {
local QQ='
com.tencent.mobileqq/com.tencent.aelight.camera.aebase.PeakService
com.tencent.mobileqq/com.tencent.gamecenter.wadl.api.impl.WadlProxyService
com.tencent.mobileqq/com.tencent.mobileqq.colornote.smallscreen.ColorNoteSmallScreenService
com.tencent.mobileqq/com.tencent.mobileqq.microapp.app.AppBrandTaskPreloadReceiver
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver1
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver2
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver3
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver4
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver5
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver6
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.AppBrandTaskPreloadReceiver7
com.tencent.mobileqq/com.tencent.mobileqq.mini.app.InternalAppBrandTaskPreloadReceiver
com.tencent.mobileqq/com.tencent.mobileqq.music.QQPlayerService
com.tencent.mobileqq/com.tencent.mobileqq.nearby.NearbyReceiver
com.tencent.mobileqq/com.tencent.mobileqq.servlet.ClearPushReceiver
com.tencent.mobileqq/com.tencent.mobileqq.statistics.UECReceiver
com.tencent.mobileqq/com.tencent.mobileqq.uniformdownload.core.UniformDownloadNfnReceiver
com.tencent.mobileqq/com.tencent.mobileqq.winkpublish.service.WinkPublishService
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.AppBrandMainReceiver1
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.AppBrandMainReceiver2
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.AppBrandMainReceiver3
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.AppBrandMainReceiver4
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.AppBrandMainReceiver5
com.tencent.mobileqq/com.tencent.qqmini.sdk.receiver.InternalAppBrandMainReceiver
com.tencent.mobileqq/com.tencent.sc.appwidget.QCenterWidgetProvider
com.tencent.mobileqq/com.tencent.tmdownloader.TMAssistantDownloadService
com.tencent.mobileqq/cooperation.troop.NearbyVideoProxyBroadcastReceiver
com.tencent.mobileqq/cooperation.weiyun.WeiyunBroadcastReceiver
com.tencent.mobileqq/cooperation.weiyun.WeiyunProxyBroadcastReceiver
com.tencent.mobileqq/kcsdk.shell.KcShellService
'
	for i in $QQ; do
		pm $sate $i >/dev/null 2>&1
	done
}

set_pm_MM() {
local MM='
com.tencent.mm/.plugin.appbrand.ad.ui.AppBrandAdUI1
com.tencent.mm/.plugin.appbrand.ad.ui.AppBrandAdUI2
com.tencent.mm/.plugin.appbrand.ad.ui.AppBrandAdUI3
com.tencent.mm/.plugin.appbrand.ad.ui.AppBrandAdUI4
com.tencent.mm/.plugin.hp.tinker.TinkerPatchResultService
com.tencent.mm/com.facebook.CurrentAccessTokenExpirationBroadcastReceiver
com.tencent.mm/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
com.tencent.mm/com.google.android.gms.measurement.AppMeasurementReceiver 
com.tencent.mm/com.google.firebase.iid.FirebaseInstanceIdReceiver 
com.tencent.mm/com.tencent.mars.comm.Alarm
com.tencent.mm/com.tencent.mm.booter.BluetoothReceiver
com.tencent.mm/com.tencent.mm.booter.BluetoothStateReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$AlarmReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$ConnectionReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$ExdeviceProcessReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$SandBoxProcessReceiver
com.tencent.mm/com.tencent.mm.booter.MMReceivers$SandBoxProcessReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$ToolsMpProcessReceiver 
com.tencent.mm/com.tencent.mm.booter.MMReceivers$ToolsProcessReceiver 
com.tencent.mm/com.tencent.mm.crash.FirstCrashUploadBroadcastReceiver 
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver 
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver1
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver1 
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver2
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver2 
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver3
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver3 
com.tencent.mm/com.tencent.mm.plugin.appbrand.task.AppBrandTaskPreloadReceiver4
com.tencent.mm/com.tencent.mm.plugin.lite.LiteAppTaskPreloadReceiver 
com.tencent.mm/com.tencent.mm.plugin.performance.elf.ElfCallUpReceiver 
com.tencent.mm/com.tencent.mm.sandbox.monitor.CrashUploadAlarmReceiver 
com.tencent.mm/com.tencent.mm.sandbox.updater.AppInstallerUI
com.tencent.mm/com.tencent.mm.sandbox.updater.AppUpdaterUI
com.tencent.mm/com.tencent.tinker.lib.service.TinkerPatchForeService
com.tencent.mm/com.tencent.tinker.lib.service.TinkerPatchService$InnerService
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_00
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_00_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_01
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_01_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_02
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_02_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_03
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_04
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_05
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_06
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_07
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_08
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTKStub_09
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_00
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_00_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_01
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_02
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_02_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_03
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_04
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_05
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_06
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_07
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_08
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SGTStub_09
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_00
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_00_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_01
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_01_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_02
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_02_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_03
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_04
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_05
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_06
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$SIStub_07
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_00
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_00_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_01
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_01_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_02
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_02_T
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_03
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_04
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_05
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_06
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_07
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_08
com.tencent.mm/com.tencent.tinker.loader.hotplug.ActivityStubs$STDStub_09
com.tencent.mm/com.tencent.tmdownloader.TMAssistantDownloadService
'
	for i in $MM; do
		pm $sate $i >/dev/null 2>&1
	done
}

#亮屏任务
if test $(show_value "亮屏清理任务") == 开启; then
	sed -i "s/.*QQWEA.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "*/"$(show_value "亮屏任务时间")" * * * * ${crond_file%/*}/QQWEA.sh" >>$crond_file
elif test $(show_value "亮屏清理任务") == 关闭; then
	sed -i "s/.*QQWEA.sh//g;/^[[:space:]]*$/d" $crond_file
fi

#息屏任务
if test $(show_value "息屏清理任务") == 开启; then
	sed -i "s/.*QQWEB.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "*/"$(show_value "息屏任务时间")" * * * * ${crond_file%/*}/QQWEB.sh" >>$crond_file
elif test $(show_value "息屏清理任务") == 关闭; then
	sed -i "s/.*QQWEB.sh//g;/^[[:space:]]*$/d" $crond_file
fi

#垃圾清理任务
if test $(show_value "QQ微信垃圾清理") == 开启; then
	sed -i "s/.*QQMM.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "0 "$(show_value "QQ微信垃圾清理时间")" * * * ${crond_file%/*}/QQMM.sh" >>$crond_file
elif test $(show_value "QQ微信垃圾清理") == 关闭; then
	sed -i "s/.*QQMM.sh//g;/^[[:space:]]*$/d" $crond_file
fi

#内存回收任务
if test $(show_value "内存回收") == 开启; then
	sed -i "s/.*mem_control.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "*/"$(show_value "内存回收任务时间")" * * * * ${crond_file%/*}/mem_control.sh" >>$crond_file
elif test $(show_value "内存回收") == 关闭; then
	sed -i "s/.*mem_control.sh//g;/^[[:space:]]*$/d" $crond_file
fi

#QQ微信保活任务
if test $(show_value "QQ微信保活") == 开启; then
	sed -i "s/.*keepalive.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "*/"$(show_value "QQ微信保活任务时间")" * * * * ${crond_file%/*}/keepalive.sh" >>$crond_file
elif test $(show_value "QQ微信保活") == 关闭; then
	sed -i "s/.*keepalive.sh//g;/^[[:space:]]*$/d" $crond_file
fi

#QQ，微信休眠任务
if test $(show_value "QQ，微信休眠") == 开启; then
	sed -i "s/.*sleep.sh//g;s/.*wakeup.sh//g;/^[[:space:]]*$/d" $crond_file
	echo "0 "$(show_value "QQ，微信假死时间")" * * * ${crond_file%/*}/sleep.sh" >>$crond_file
	echo "0 "$(show_value "QQ，微信唤醒时间")" * * * ${crond_file%/*}/wakeup.sh" >>$crond_file
elif test $(show_value "QQ，微信休眠") == 关闭; then
	sed -i "s/.*sleep.sh//g;s/.*wakeup.sh//g;/^[[:space:]]*$/d" $crond_file
fi

if test $(show_value "IFW") == 启用; then
	controlsifwd
elif test $(show_value "IFW") == 恢复; then
	controlsifwe
fi

if test $(show_value "微信PM") == 启用; then
	sate=disable
	set_pm_MM && unset sate
elif test $(show_value "微信PM") == 恢复; then
	sate=enable
	set_pm_MM && unset sate
fi

if test $(show_value "QQPM") == 启用; then
	sate=disable
	set_pm_QQ && unset sate
elif test $(show_value "QQPM") == 恢复; then
	sate=enable
	set_pm_QQ && unset sate
fi

if test $(show_value "speed编译") == 启用; then
	cmd package compile -m speed com.tencent.mobileqq 2>/dev/null
	cmd package compile -m speed com.tencent.mm 2>/dev/null
fi
