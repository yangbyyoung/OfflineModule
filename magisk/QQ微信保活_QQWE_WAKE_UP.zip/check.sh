
mod='
WE_WAKE_UP
QQ_WAKE_UP
QQWE_WAKE_UP
'
until_function=/data/adb/magisk/util_functions.sh
MOD=/data/adb/modules
MOD2=/data/adb/lite_modules

function get_magisk_lite(){
grep -q lite_modules $until_function && echo "true" || echo "false"
}

test "$(get_magisk_lite)" = "true" && MOD=$MOD2

cd $MOD
for i in $(ls);do
	for o in $mod;do
		name=$(cat $i/module.prop | grep 'name'| cut -d = -f2 )
		author=$(cat $i/module.prop | grep 'author'| cut -d = -f2 )
		description=$(cat $i/module.prop | grep 'description'| cut -d = -f2 )
		size=` du -sh $i |awk '{print $1}'`
		if test "$i" = "$o" -a "$i" != "$id" ;then
			echo " "
			echo "∞————————————————————————∞"
			echo ""
			echo "－名称：$name"
			echo "－作者：$author"
			echo "－简介：$description"
			echo " "
			echo "－大小：$size"
			echo " "
			echo "－ 模块功能冲突，已经停用该模块！"
			echo "∞————————————————————————∞"
			echo " "
			touch "$i/disable"
		fi
	done
done


