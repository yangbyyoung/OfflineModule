export PATH=/data/adb/magisk/busybox:$PATH

	if [[ $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) != "true" ]]; then
	
noDozes="
+com.tencent.mm
+com.netease.cloudmusic
+com.tencent.mobileqq
"
noDozes=`pm list packages -e | sed "s/package:/-/g"`$noDozes
dumpsys deviceidle whitelist $noDozes

echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory

fi