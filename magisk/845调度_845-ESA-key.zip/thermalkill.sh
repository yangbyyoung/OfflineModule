#!/system/bin/sh

export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH
function correctpath(){
case `echo "$1"` in
	/system_ext* | /vendor* | /product* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
esac
}


find /system/ /system_ext /vendor /product -iname '*thermal*' -type f  2> /dev/null | sed -e '/.*android.*/d' -e '/.*libthermalclient.*/d' -e '/.*thermal-engine.*/d' | while read file ;do
file=$(correctpath $file  )
test -n $file && {
mkdir -p $MODPATH${file%/*}
touch $MODPATH$file && echo "成功替换: $file"
}
done



