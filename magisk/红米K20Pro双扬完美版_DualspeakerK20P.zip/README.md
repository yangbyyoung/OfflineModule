Changelog:

Version 5:
- Initial Release
- Remove sth
- Fix some bugs
