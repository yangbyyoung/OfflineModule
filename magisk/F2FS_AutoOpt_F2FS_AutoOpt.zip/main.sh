#F2FS文件系统优化(Trim+GC)
MODDIR=${0%/*}
if [ `dumpsys deviceidle | grep mScreenOn` == "mScreenOn=true" ] ; then
	#init
	function start(){			  
		rundata=`date "+%Y-%m-%d %H:%M:%S"`
	}
	
	function get_userdata(){
		userdata=`cat "$MODDIR/userdata_num"`
	}

	function enforce_se(){
		setenforce 1
	}

	function permissive_se(){
		setenforce 0
	}

	function check_selinux(){
		restore_se=""
		if [ `getenforce` == "Permissive" ] ; then
			restore_se="permissive_se"
		else
			restore_se="enforce_se"
		fi
	}

	function infoend(){
  		count_trim=`cat "$MODDIR/count_trim"`
  		count_gc=`cat "$MODDIR/count_gc"`
  		if [ "$trimed" == "1" ] ; then
  			echo " # " >>$MODDIR/TRIM_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_TRIM.log >$MODDIR/TRIM_tmpO.log
			cat $MODDIR/TRIM_tmpN.log $MODDIR/TRIM_tmpO.log >/sdcard/Android/fsopt/FSopt_TRIM.log
			sed -i '100,120d' /sdcard/Android/fsopt/FSopt_TRIM.log
			count_trim=$(($count_trim + 1 ))
		fi
		if [ "$gced" == "1" ] ; then
			echo " # " >>$MODDIR/GC_tmpN.log
			cat /sdcard/Android/fsopt/FSopt_GC.log >$MODDIR/GC_tmpO.log
			cat $MODDIR/GC_tmpN.log $MODDIR/GC_tmpO.log >/sdcard/Android/fsopt/FSopt_GC.log
			sed -i '100,120d' /sdcard/Android/fsopt/FSopt_GC.log
			count_gc=$(($count_gc + 1 ))
		fi
		echo "$count_trim" >$MODDIR/count_trim
		echo "$count_gc" >$MODDIR/count_gc
		sed -i "s/\[.*\]/\[ 已TRIM $count_trim 次，已GC $count_gc 次 \]/g" "$MODDIR/module.prop"
	}
	
	function cpud(){
		out=$(echo "scale=$4; $1*$2/$3" | bc)
		echo $out
		return $?
	}

	function fstrimd(){
		busybox=$MODDIR/busybox
		busybox fstrim -v $1 >$MODDIR/trim_inf
		trim=`cat "$MODDIR/trim_inf" | tr -cd "[0-9]"`
		if [ "$trim" == "0" -o "$trim" == "" -o "$trim" == "NULL" ] ; then
			echo " --- $1: 无需TRIM " >>$MODDIR/TRIM_tmpN.log
		else
			trimed=1
			tf_trim $1 "B trimmed" $trim 1000000 1000000000 1 1000000 1000000000 1000
		fi
		echo "NULL" >$MODDIR/trim_inf
	}
	
	function tf_trim(){				
		if [ "$3" -ge "$4" ] ; then
			out=$(cpud $3 $6 $7 2)
			if [ "$3" -ge "$5" ] ; then
				out=$(cpud $3 $6 $8 2)
				echo " --- $1: $out G$2 " >>$MODDIR/TRIM_tmpN.log
			else
				echo " --- $1: $out M$2 " >>$MODDIR/TRIM_tmpN.log
			fi
		else
			out=$(cpud $3 $6 $9 2)
			echo " --- $1: $out K$2 " >>$MODDIR/TRIM_tmpN.log
		fi
	}

	function tf_gc(){				
		if [ "$3" -ge "$4" ] ; then
			out=$(cpud $3 $6 $7 2)
			if [ "$3" -ge "$5" ] ; then
				out=$(cpud $3 $6 $8 2)
				echo " --- $1: $out G$2 " >>$MODDIR/GC_tmpN.log
			else
				echo " --- $1: $out M$2 " >>$MODDIR/GC_tmpN.log
			fi
		else
			out=$(cpud $3 $6 $9 2)
			echo " --- $1: $out K$2 " >>$MODDIR/GC_tmpN.log
		fi
	}
	
	function get_info(){
		initunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
	}
	
	function gc_main(){
		echo lock_me >/sys/power/wake_lock
		runcycle=0
		counts=0
		until [ `cat "/sys/fs/f2fs/$userdata/unusable"` == "0" ] ; do
			echo "50" > /sys/fs/f2fs/$userdata/gc_urgent_sleep_time
			echo "3" > /sys/fs/f2fs/$userdata/gc_urgent
			cpuload
			runcycle=$(($runcycle + 1 ))
			if	[ "$usage" -ge "50" ] ;then
				counts=$(($counts + 1 ))
				if	[ "$counts" -ge "5" ] ;then
					break 1
				fi
			else
				if	[ "$counts" -ge "1" ] ;then
					counts=$(($counts - 1 ))
				fi
			fi
		done
		echo "0" >/sys/fs/f2fs/$userdata/gc_urgent
		echo lock_me >/sys/power/wake_unlock
	}

	function gc_rtime(){
		if [ "$runcycle" -ge 60 ] ; then
			runtime_m=$(cpud $runcycle 1 60 0)
			runtime_s=$(echo "scale=0; $runcycle - $runtime_m*60" | bc)
			echo " --- GC_Runtime: $runtime_m Min $runtime_s Sec " >>$MODDIR/GC_tmpN.log
		else
			echo " --- GC_Runtime: $runcycle Sec " >>$MODDIR/GC_tmpN.log
		fi
	}

	function gc_edinfo(){
		freeseg=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		endunuse=`cat "/sys/fs/f2fs/$userdata/unusable"`
		unusegc=$(($initunuse - $endunuse))
		if [ "$unusegc" -le "0" ] ; then
			unusegc=0
		fi
	}
	
	function lock_d(){
		if [ "$1" "$2" "$3" ] ; then
			echo "Lock" >$MODDIR/SleepLocker
		fi
	}
	
	function gc_scale(){
		free_space=`cat "/sys/fs/f2fs/$userdata/free_segments"`
		unuse_block=`cat "/sys/fs/f2fs/$userdata/unusable"`
		free_space=$(cpud $free_space 512 1 0)
		total_free=$(($free_space + $unuse_block))
		scale_gc=$(cpud $total_free 7 100 0)
	}

	function cpuload(){
		info_old=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
		total_old=$(echo $info_old | awk '{print $1+$2+$3+$4+$5+$6+$7}')
		usage_old=$(echo $info_old | awk '{print $1+$2+$3}')
		sleep 1
		info_new=$(cat /proc/stat | grep -w cpu | awk '{print $2,$3,$4,$5,$6,$7,$8}')
		total_new=$(echo $info_new | awk '{print $1+$2+$3+$4+$5+$6+$7}')
		usage_new=$(echo $info_new | awk '{print $1+$2+$3}')
		busy=$(($usage_new - $usage_old))
		cputime=$(($total_new - $total_old))
		usage=$(echo "scale=0; $busy*100/$cputime" | bc)
	}
	
	function trim_only(){
		start
		echo " # " >$MODDIR/TRIM_tmpN.log
		echo " --- $rundata " >>$MODDIR/TRIM_tmpN.log
		fstrimd "/cache"
		fstrimd "/data"
	}


	#Main
	check_selinux
	permissive_se
	get_userdata
	trimed=0
	gced=0
	gc_scale
	if [ `cat "/sys/fs/f2fs/$userdata/unusable"` -ge "$scale_gc" ] ;then
		if [ `cat "/sys/class/power_supply/battery/status"` = "Charging" -o `cat "/sys/class/power_supply/battery/capacity"` -ge "50" ] ;then
			trim_only
			start
			echo " # " >$MODDIR/GC_tmpN.log
			echo " --- $rundata " >>$MODDIR/GC_tmpN.log
			get_info
			gc_main
			gc_edinfo
			gc_rtime
			tf_gc "GC_已回收" "B" $unusegc 245 244141 4096  1000000 1000000000 1000
			tf_gc "GC_剩余待回收" "B" $endunuse 245 244141 4096 1000000 1000000000 1000
			tf_gc "DATA_F2FS空闲" "B" $freeseg 0 478 2097152 1000000 1000000000 1
			gced=1
			infoend
			trimed=0
			lock_d "$endunuse" "-le" "5000"
		else
			trim_only
			infoend
		fi
	else
		trim_only
		infoend
	fi
	$restore_se
fi
if [ "$trimed" == "1" ] ; then
	sleep 1800
fi
