#更新hosts
curl -o /data/adb/modules/AD_lite/ADhosts https://dev.iw233.cn/Lucky/Sbhosts.php
dd if=/data/adb/modules/AD_lite/ADhosts of=/system/etc/hosts 
setprop net.dns1 223.5.5.5
setprop net.dns2 223.6.6.6