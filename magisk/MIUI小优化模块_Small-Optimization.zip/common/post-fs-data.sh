#!/system/bin/sh
MODDIR=${0%/*}
Permission_setting() {
  rm -rf $1
  touch $1
  chmod 000 $1
}
mktouch() {
  mkdir -p ${1%/*} 2>/dev/null
  [ -z $2 ] && touch $1 || echo $2 > $1
  chmod 644 $1
}

if [[ ! -e /system/bin/awk ]]; then
	if [[ ! -e $MODDIR/system/bin/awk ]]; then
	mkdir -p $MODDIR/system/bin/
	cp -a $MODDIR/MATERIAL/awk $MODDIR/system/bin/
	fi
else
	if [[ -e $MODDIR/system/bin/awk ]]; then
	rm -rf $MODDIR/system/bin/awk
	fi
fi

# mdnsd
if [[ -d /data/adb/modules/MIUI12ABajiangXiaoJingJian/ ]]; then
	[[ -e $MODDIR/system/bin/mdnsd ]] && rm -rf $MODDIR/system/bin/mdnsd
	[[ -e $MODDIR/system/etc/init/mdnsd.rc ]] && rm -rf $MODDIR/system/etc/init/mdnsd.rc
elif [[ -d /data/adb/modules/MIUIABajiangYCmdnsdFW/ ]]; then
	[[ -e $MODDIR/system/bin/mdnsd ]] && rm -rf $MODDIR/system/bin/mdnsd
	[[ -e $MODDIR/system/etc/init/mdnsd.rc ]] && rm -rf $MODDIR/system/etc/init/mdnsd.rc
else
	if [[ -e /system/bin/mdnsd ]]; then
		[[ ! -e $MODDIR/system/bin/mdnsd ]] && mktouch $MODDIR/system/bin/mdnsd
	fi
	if [[ -e /system/etc/init/mdnsd.rc ]]; then
		[[ ! -e $MODDIR/system/etc/init/mdnsd.rc ]] && mktouch $MODDIR/system/etc/init/mdnsd.rc
	fi
fi

# 移除系统跟踪
if [[ -d /data/adb/modules/MIUI12ABajiangXiaoJingJian/ ]]; then
	[[ -e $MODDIR/system/app/Traceur/.replace ]] && rm -rf $MODDIR/system/app/Traceur/.replace
else
	[[ ! -e $MODDIR/system/app/Traceur/.replace ]] && mktouch $MODDIR/system/app/Traceur/.replace
fi

# 删除桌面日志并禁止写入（来自雄氏老方）
if [[ -e /data/user_de/0/com.miui.home/cache/debug_log ]]; then
	Permission_setting /data/user_de/0/com.miui.home/cache/debug_log
fi

# 删除不必要的网络日志（来自水龙）
if [[ -e /data/vendor/wlan_logs ]]; then
	Permission_setting /data/vendor/wlan_logs
fi

# 禁止mi-rcs 写日志（来自旧梦）
if [[ -e /data/media/0/JuphoonService ]]; then
	Permission_setting /data/media/0/JuphoonService
fi