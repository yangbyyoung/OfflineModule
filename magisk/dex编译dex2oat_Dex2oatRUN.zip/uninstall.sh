rm -rf /data/adb/Dex2oatRUN
