# Check Enable
SKIPMOUNT=true
# system.prop
PROPFILE=false
# post-fs-data script
POSTFSDATA=false
# service script
LATESTARTSERVICE=true
# ==============================
echo "*****************************"
echo "挂载分区"
mount -o remount,rw /
echo "*****************************"
cat $MODPATH/system/vendor/bin/cnss_diag 2> /dev/null
# 设置变量
cleanzdy=1
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.*version.incremental`"
# ==============================
# 判断是否为官方内核
if cat '/proc/version' | grep "perf" > /dev/null
then
echo "*****************************"
echo "当前内核为:官方内核"
else
echo "*****************************"
echo "当前内核为:第三方内核"
fi
echo "*****************************"
echo "系统版本：$var_version"
echo "设备版本：$var_release"
echo "*****************************"
echo "主要邮箱: OLX_Team@88.com"
echo "请务必给予Rulong_Boost (Root权限)"
echo "*****************************"
echo "22.1.21"
echo "新增:如龙数据网络加速"
echo "移除部分GPU相关更改"
echo "*****************************"
echo "22.1.18"
echo "新增自定义:列表动画"
echo "优化Android 12 功耗"
echo "*****************************"
echo "22.1.17"
echo "修复长时间开机导致如龙网络加速重置问题"
echo "完全启用如龙内存域压缩"
echo "*****************************"
echo "22.1.13"
echo "新增自定义: 小核最低频率 (仅限865 Soc)"
echo "升级新增: 自动备份如龙自定义至/sdcard/如龙自定义备份.conf"
echo "*****************************"
echo "22.1.12"
echo "修复Miui 21.12.30后版本卡死问题"
echo "(雷军！金凡！！！)"
echo "默认去除均衡模式"
echo "完整865调度.自行使用如龙自动化调度"
echo "修改详细cpuset负载均衡"
echo "适配如龙自动化判断"
echo "*****************************"
echo "22.1.10"
echo "判断机制完善:新旧机型进行多重判断"
echo "触控刷新率的bug修复"
echo "22.1.9"
echo "机型分级: 865系列Soc 开放均衡调度"
echo "优化屏幕触控采样率为当前设定的刷新率"
echo "*****************************"
echo "22.1.8"
echo "机型分级: 红米k30s新增均衡调度"
echo "日志和自定义输出位置改为: /cache/Rulong"
echo "*****************************"
echo "22.1.6"
echo "新增自定义: Doze开关"
echo "*****************************"
echo "22.1.5"
echo "在Android12: 暂时去除HWUI调整并关闭用户层Vulkan"
echo "修复: Misans字体自定义重复创建问题"
echo "删除阿里类UC Webview"
echo "*****************************"
echo "22.1.4"
echo "伪装小米账户和国家地址为俄罗斯"
echo "去除: 隐藏小白条自定义"
echo "*****************************"
echo "22.1.2"
echo "修正部分机型: 无信号问题"
echo "*****************************"
echo "22.1.1"
echo "Wlan Boost优化"
echo "如龙代码精简"
echo "新增自定义: 隐藏小白条"
# ==============================
# 释放文件，普通shell命令
on_install() {
echo "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/xbin/busybox  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.boot  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.init  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.d  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.set  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.fstrim  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.vfs  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.version  0  2000  0777
  set_perm_recursive $MODPATH/system/xbin/Rulong/olx.wlan  0  2000  0777
}
# ==============================
if [ -e /system/app/olx/olx.apk ] 
then
echo "*****************************"
echo "检测到MiuiCx_Rom"
rm -rf $MODPATH/system/vendor/app/Rulong.version.olx
else
echo
fi
# ==============================
rm -rf /data/system/ifw/com.miui.securitycenter.xml
rm -rf /data/adb/modules/Rulong
rm -rf /data/adb/modules/Rulong_ZhuQue
rm -rf /data/adb/modules/Rulong_QingLong
rm -rf /system/app/Rulong_Boost
echo "*****************************"
# ==============================
if [[ "$cleanzdy" = 1 ]] ; then 2> /dev/null
echo "本次更新将会清除如龙的自定义修改"
echo "已备份如龙自定义至/内置储存/如龙自定义备份.conf"
cp -r /cache/Rulong/RulongPro/RulongPro.conf /sdcard/如龙自定义备份.conf
rm -rf /sdcard/Rulong/*
rm -rf /cache/Rulong/*
else
echo "本次更新不会清除如龙的自定义修改"
fi
# ==============================
echo "*****************************"
echo "清除缓存"
rm -rf /data/system/package_cache/*
# ==============================
exit 0