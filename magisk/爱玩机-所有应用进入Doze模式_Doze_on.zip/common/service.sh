#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

#sleep 25
newShell=$MODDIR/whitelist.sh
while true; do
pm list packages --user 0 | sed 's/package:/ dumpsys deviceidle whitelist -/' | sed 's/$//' > $newShell
sh $newShell
rm -rf $newShell
sleep 60
done



#dumpsys deviceidle whitelist +com.tencent.mobileqq
#如果需要忽略腾讯QQ打盹，请删除上一行#
#dumpsys deviceidle whitelist +com.tencent.mm
#如果需要忽略微信打盹，请删除上一行#

