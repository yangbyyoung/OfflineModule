#!/system/bin/sh

function show_value() {
	local value=$1
	local file=$MODPATH/模块配置.conf
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g;s/，/,/g;s/——/-/g;s/：/:/g;s/[[:space:]]//g'
}

if test $(show_value "华为机型") == HUAWEINova8Pro; then
	echo '
#HUAWEI Nova 8 Pro
ro.product.manufacturer=HUAWEI
ro.product.brand=HUAWEI
ro.product.model=BRQ-AN00
#END
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMate40; then
	echo '
#HUAWEI Mate 40 
ro.product.manufacturer=HUAWEI
ro.product.brand=HUAWEI
ro.product.model=NOP-AN00-PD
#END 
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMateX5G; then
	echo '
#HUAWEI Mate X 5G
ro.product.brand=HUAWEI
ro.product.manufacturer=HUAWEI
ro.product.model=TAH-AN00
#END
' >$MODPATH/system.prop
elif test $(show_value "华为机型") == HUAWEIMate40Pro; then
	echo '
#HUAWEI Mate40 Pro
ro.product.brand=HUAWEI
ro.product.manufacturer=HUAWEI
ro.product.model=NOP-AN00
#END
' >$MODPATH/system.prop
fi

if test $(show_value "修改为华为机型") == 否; then
	rm -rf $MODPATH/system.prop
fi

function set_crond_hms() {
	CROND_FILE=$MODPATH/crond/root
		script_file1=${CROND_FILE%/*}/keepalivetask.sh
		Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
		echo "*/"$(show_value "HMS保活定时任务时间")" * * * * /data/adb/$Magisk_mod/$id/crond/keepalivetask.sh" >>$CROND_FILE
		sed -i "2i MODPATH=/data/adb/$Magisk_mod/$id" $script_file1
		sed -i "2i export PATH=/data/adb/$Magisk_mod/$id/busybox:/system/bin:\$PATH" $script_file1
		chmod -R 777 $MODPATH/crond
}

function set_crond_QQ() {
	CROND_FILE=$MODPATH/crond/root
		script_file2=${CROND_FILE%/*}/killhms.sh
		Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
		echo "*/"$(show_value "定时杀死唤醒后台时间")" * * * * /data/adb/$Magisk_mod/$id/crond/killhms.sh" >>$CROND_FILE
		sed -i "2i MODPATH=/data/adb/$Magisk_mod/$id" $script_file2
		sed -i "2i export PATH=/data/adb/$Magisk_mod/$id/busybox:/system/bin:\$PATH" $script_file2
		sed -i "2i cleartime="$(show_value "杀死唤醒后台延时")"" $script_file2
		chmod -R 777 $MODPATH/crond
}

if test $(show_value "HMS保活定时任务") == 开启; then
	set_crond_hms
elif test $(show_value "HMS保活定时任务") == 关闭; then
	rm -rf $MODPATH/crond/keepalivetask.sh
fi

if test $(show_value "定时杀死唤醒后台") == 开启; then
	set_crond_QQ
elif test $(show_value "定时杀死唤醒后台") == 关闭; then
	rm -rf $MODPATH/crond/killhms.sh
fi

if test $(show_value "定时杀死QQ后台") == 关闭 -a $(show_value "HMS保活定时任务") == 关闭; then
	rm -rf $MODPATH/crond
fi

