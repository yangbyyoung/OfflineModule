rm -f /system/etc/security/cacerts/87bc3517.0
