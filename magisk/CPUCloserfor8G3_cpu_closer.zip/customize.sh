if [ `getprop ro.soc.model` != "SM8650" ]; then
    echo; echo "- 本程序仅支持骁龙8G3！"
    echo "- This program is for Snapdragon 8G3 only!"
    echo; exit 1
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/cpu_closer 0 0 0755
