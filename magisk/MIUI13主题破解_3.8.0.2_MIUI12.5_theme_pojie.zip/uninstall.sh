tmp_list="ThemeManager"
dda=/data/dalvik-cache/arm
[ -d $dda"64" ] && dda=$dda"64"
for i in $tmp_list; do
	rm -f $dda/system@*@"$i"*
done
rm -rf /data/system/package_cache/*
chattr -i /data/system/theme/rights
chmod 775 /data/system/theme
rm -rf /data/system/theme/rights
rm -rf /data/app/*/com.android.thememanager*
rm -rf /data/app/com.android.thememanager*
