rm -rf /data/thermal
rm -rf /data/vendor/thermal
touch /data/thermal
touch /data/vendor/thermal
/data/adb/magisk/busybox chattr +i  /data/thermal
/data/adb/magisk/busybox chattr +i  /data/vendor/thermal