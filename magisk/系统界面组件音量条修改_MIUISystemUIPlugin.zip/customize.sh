SKIPUNZIP=0
ASH_STANDALONE=1

#ui_print '================================================='
#ui_print '  模块说明：'
#ui_print '    将MIUI新版安装包管理组件替换为2.1.2旧版。'
#ui_print '================================================='
# 旧版系统：MiuiPackageInstaller
# 新版系统：MIUIPackageInstaller（安卓12）
dest=/system/app/MIUISystemUIPlugin
[ ! -d $dest ] && dest=${dest/MIUI/Miui}
apk=$(ls $dest/M*.apk)
mkdir -p $MODPATH$dest
mv $MODPATH/MIUISystemUIPluginMod.apk $MODPATH$apk
rm -f /data/system/package_cache/*/M???SystemUIPlugin-16
ui_print '    安装完成，重启后生效！'

REPLACE="
$dest
"
# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644

