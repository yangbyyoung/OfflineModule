bootpath=$(find /system /my_product -type f -iname "*bootanimation*.zip" 2>/dev/null | sed 's/\/product/\/system\/product/g' | sed 's/\/system\/system/\/system/g' )
for i in $bootpath;do
mkdir -p $MODPATH/$(dirname $i)
cp -rf $MODPATH/*.zip $MODPATH/$i
done

bootpath_dark=$(find /system /product -type f -iname "*bootanimation-dark*.zip" 2>/dev/null | sed 's/\/product/\/system/product/g' | sed 's/\/system\/system/\/system/g' )
for d in $bootpath_dark;do
mkdir -p $MODPATH/$(dirname $d)
cp -rf $MODPATH/*.zip $MODPATH/$d
done


if [ -d "$MODPATH/system/" ];then
    rm -rf $MODPATH/post-fs-data.sh
    else
    ui_print "模塊應衹作用于COS11/12系統，其他版本使用可能失敗，請確保救磚模塊能夠正常工作"
fi



cd /data/adb/modules
for module_id in $(ls);do
name=$(cat $module_id/module.prop | grep 'name')
author=$(cat $module_id/module.prop | grep 'author')
description=$(cat $module_id/module.prop | grep 'description')
size=` du -sh $module_id|awk '{print $1}'`
for o in $bootpath;do
if [[ -e "$module_id/$o" ]] && [[ "$module_id" != "$id" ]] && [[ ! -e "$module_id/remove" ]] && [[ ! -e "$module_id/disable" ]];then
ui_print "模塊來源于酷安作者“灼热的红豆”，“泠熙子”衹是在模塊中添加了開機動畫并修改了部分顯示文字"
ui_print "正在刷入模塊"
ui_print " "
ui_print "似乎手機上已經存在了其他開機動畫模塊"
ui_print "下面為其他模塊的信息，本模塊會自動關閉，如果需要再次啟用請確保本模塊已經關閉以免衝突"
ui_print "模塊名稱：${name:5}"
ui_print "模塊作者：${author:7}"
ui_print "模塊簡介：${description:12}"
ui_print "模塊大小：$size"
ui_print " "
touch $module_id/disable
fi
done

for i in $bootpath_dark;do
if [[ -e "$module_id/$i" ]] && [[ "$module_id" != "$id" ]] && [[ ! -e "$module_id/remove" ]] && [[ ! -e "$module_id/disable" ]];then
ui_print "模塊來源于酷安作者“灼热的红豆”，“泠熙子”衹是在模塊中添加了開機動畫并修改了部分顯示文字"
ui_print "正在刷入模塊"
ui_print " "
ui_print "似乎手機上已經存在了其他開機動畫模塊"
ui_print "下面為其他模塊的信息，本模塊會自動關閉，如果需要再次啟用請確保本模塊已經關閉以免衝突"
ui_print "模塊名稱：${name:5}"
ui_print "模塊作者：${author:7}"
ui_print "模塊簡介：${description:12}"
ui_print "模塊大小：$size"
ui_print " "
touch $module_id/disable
fi
done
done

