#!/system/bin/sh
MODDIR=${0%/*}
    chmod -h 0200 /sys/devices/msm_sdcc.1/polling
    chmod -h 0200 /sys/devices/msm_sdcc.2/polling
    chmod -h 0200 /sys/devices/msm_sdcc.3/polling
    chmod -h 0200 /sys/devices/msm_sdcc.4/polling

    chown -h system.system /sys/devices/msm_sdcc.1/polling
    chown -h system.system /sys/devices/msm_sdcc.2/polling
    chown -h system.system /sys/devices/msm_sdcc.3/polling
    chown -h system.system /sys/devices/msm_sdcc.4/polling
su -c $MODDIR/xuan.sh -v /cache
sleep 30