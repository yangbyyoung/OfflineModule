# 链接字体
ln -s /system/fonts/font.ttf $MODPATH/system/fonts/MiLanProVF.ttf
ln -s /system/fonts/font.ttf $MODPATH/system/fonts/MiSansVF.ttf
