#!/system/bin/sh
if [ "$(id -u)" != "0" ]; then
	echo "不给root执行什么？"
	exit 1
fi
HC_hsgarb='/sdcard/Android/HChai/HC_hsgarb'

function app_3() {
    if [[ $(grep '#已添加第三方应用' $HC_hsgarb/应用.conf) != '' ]];then
        echo '无需添加'
    else
        echo "
#已添加第三方应用
#哪个应用出问题移除那个应用，如果移除了还有问题那就不是此模块问题。
" >> $HC_hsgarb/应用.conf
        pm list packages -3 |awk -F : '{print$NF}' >> $HC_hsgarb/应用.conf
        echo '添加成功'
    fi
    caidan
}

function app_s() {
    if [[ $(grep '#已添加系统应用' $HC_hsgarb/应用.conf) != '' ]];then
        echo '无需添加'
    else
        echo "
#已添加系统应用
#哪个应用出问题移除那个应用，如果移除了还有问题那就不是此模块问题。
" >> $HC_hsgarb/应用.conf
        pm list packages -s |awk -F : '{print$NF}' >> $HC_hsgarb/应用.conf
        echo '添加成功'
    fi
    caidan
}

function no_repeat() {
    awk '!a[$0]++' $HC_hsgarb/应用.conf > $HC_hsgarb/应用.conf.bak
    mv $HC_hsgarb/应用.conf.bak $HC_hsgarb/应用.conf
    awk '!a[$0]++' $HC_hsgarb/阻止创建路径.conf > $HC_hsgarb/阻止创建路径.conf.bak
    mv $HC_hsgarb/阻止创建路径.conf.bak $HC_hsgarb/阻止创建路径.conf
    echo "去重成功"
    sleep 1
    caidan
}

function auto_app() {
    echo "


#自动添加，可以反复到终端配置添加，如遇到问题可以删除自动添加配置。
#自动添加的配置不一定好用，我的建议是可以手动整理一下。
#有些文件/文件夹现在是空的并不代表以后都是空的
#不要把自己的配置添加到后面。
" >> $HC_hsgarb/阻止创建路径.conf
    echo "请耐心等待"
    find /sdcard/ -type d -empty -not -path "/sdcard/Android/*" -not -path "/sdcard/共享目录/*" -o -type f -empty -not -name "*.nomedia" -not -path "/sdcard/Android/*" -not -path "/sdcard/共享目录/*" | awk '{print "<\"" $0 "\">"}' >>$HC_hsgarb/阻止创建路径.conf
    no_repeat
    echo "添加成功"
    sleep 1
    caidan
}

function caidan() {
	clear
	echo "Loading……"
	sleep 0.5
	clear
	echo "————————————————"
	echo "1：添加所有第三方软件到应用.conf"
	echo "2：添加所有系统软件到应用.conf(一键变砖)"
	echo "3：配置去重复行"
	echo "4：添加空文件/文件夹到阻止创建路径.conf"
	echo "5：退出"
	echo "————————————————"
	echo "键盘输入以上数字选择，请按右下角lm呼出键盘。
修改配置后重启手机生效。后期加入inotify就不用重启了"
	echo -n "输入:" && read setting
	case $setting in
	"1")
		app_3
		;;
	"2")
		app_s
		;;
	"3")
		no_repeat
		;;
	"4")
		auto_app
		;;
	"5")
		exit
		;;
	*)
		echo "输入错误"
		caidan
		;;
	esac
}

caidan
