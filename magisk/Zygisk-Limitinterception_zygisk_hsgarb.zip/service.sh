#!/system/bin/sh
#————————————————————————#
MODDIR="$(dirname "$0")"
#————————————————————————#
while [ -z "$boot" ]; do
	sleep 10
	boot=$(getprop ro.boot.bootreason)
done
ac=null
until [ $ac = "false" ]; do
	#rosan检测
	ac=$(/system/bin/app_process -Djava.class.path=$MODDIR/compilations.dex /system/bin com.rosan.shell.ActiviteJava)
	sleep 10
done
sleep 5

while IFS= read -r line
do
    if [[ $line == "<"* ]]; then
        content=$(echo "$line" | sed -e 's/^<//' -e 's/>$//' -e 's/^"//' -e 's/"$//')
        rm -rf "$content"
    fi
done < "/data/adb/modules/zygisk_hsgarb/HC_hsgarb/阻止创建路径.conf"