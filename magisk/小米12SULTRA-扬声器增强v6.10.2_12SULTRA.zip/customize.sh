SKIPUNZIP=0
MODDIR=${0%/*}
alias sh='/system/bin/sh'
a=$(getprop ro.system.build.version.release)

print_modname() {
  ui_print "***********************"
  ui_print "MiSoundBOOST!!!!"
  ui_print "Design By Huber_HaYu 以及团队的支持"
  ui_print "SetoSkins bug_casc 灵聚、神生 mly墨临渊 ChatGPT（本模块协助成员）"
  ui_print "感谢各位的支持和帮助"
  ui_print "***********************"
}


boot_first_load(){
    update_path="/data/adb/modules_update/12SULTRA"
    conf="/data/data/com.miui.misound/shared_prefs/mi_sound_preference.xml"
    pm disable com.miui.misound
    #pm clear com.miui.misound
    mkdir -p /data/data/com.miui.misound/shared_prefs
    cp -f $update_path/config/normal.xml $conf
    pm enable com.miui.misound
    am start --windowingMode 5 -n com.miui.misound/com.miui.misound.dolby.DolbyEqActivity
    sleep 2.5s
    am force-stop com.miui.misound
    am force-stop com.android.settings
    cp -f $update_path/system/app/MiSound/MiSound.apk $update_path/system/product/app/MiSound/MiSound.apk
}


set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
    chmod a+x "$MODPATH/Mly"
}

nfc_fix() {
    ui_print " - 您是否安装/升级了最新的Magisk 26.0版本？"
    ui_print " - 不清楚的一定要退出一下去查看自己的Magisk版本！"
    ui_print "这至关重要！错误的选择可能会导致卡米或NFC/Joyose丢失！"
    ui_print "   "
    sleep 0.6
    ui_print "- 如果不是Magisk 26.0，请按音量上键"
    ui_print "  "
    sleep 1s
    ui_print "- 如果是Magisk 26.0，请务必按音量下键！"
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
            sleep 0.8
            if [ $a == "13" ]; then
                ui_print "Android Version:$a"
                sleep 0.5s
                ui_print "Fixing.."
                sleep 1s
                mkdir -p $MODPATH/system/product/
                cp -r /product/pangu/system/* $MODPATH/system/product/
            fi    
            if [ $a == "12" ]; then
                ui_print "无需修复 已跳过"
            fi
        ;;
        *)
            echo "Magisk 26.0设备，模块准备完毕"
    esac
}

# 【本模块纯参数调音，如需引用调音文件请注明作者】
sleep 0.4s
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
sleep 1.5s
ui_print " ————————————————————————————————————————————————————"
ui_print " 本模块内的扬声器振幅、Virtual Bass，压限参数来自"
ui_print "       ---------人工智能ChatGPT---------"
ui_print " ————————————————————————————————————————————————————"
sleep 1s
ui_print "请稍后..."
sleep 8s
ui_print "------------------------------"
ui_print "【团队感谢：SetoSkins(代码) shadow3(代码) 灵聚、神生(代码)"
ui_print "mly墨临渊(调音、调试) 中二的番茄（辅助调音） big_chair(辅助调音) bug_casc(辅助调音)】"
ui_print "AI参数调整：ChatGPT"
ui_print "------------------------------"

print_modname
boot_first_load
set_permissions
nfc_fix