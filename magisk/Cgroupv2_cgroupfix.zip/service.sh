#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
while true
do
if [ `getprop sys.boot_completed` == "1" ];then
    sleep 1
    umount /sys/fs/cgroup/freezer
    umount /sys/fs/cgroup
    mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup/
    # MIUI millet
    mkdir /sys/fs/cgroup/frozen/
    chown system:system /sys/fs/cgroup/frozen/cgroup.procs
    chown system:system /sys/fs/cgroup/frozen/cgroup.freeze
    echo 1 > /sys/fs/cgroup/frozen/cgroup.freeze
    mkdir /sys/fs/cgroup/unfrozen/
    chown system:system /sys/fs/cgroup/unfrozen/cgroup.procs
    chown system:system /sys/fs/cgroup/unfrozen/cgroup.freeze
    break
fi
sleep 1
done
