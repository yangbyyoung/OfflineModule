#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}
modulesParent=$(dirname $MODDIR)
# 该脚本将在设备开机后作为延迟服务启动
sleep 1
if [ "$modulesParent" = "" ]; then
  modulesParent=/data/adb/modules
fi
keyCheckPath=${MODDIR}/keycheck
checkEnableApps=${MODDIR}/.enable_apps
chmod 7777 $keyCheckPath
#ModulesParent=/data/adb/modules

sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ✓模块已载入 ] /g' "$MODDIR/module.prop"
rm -rf "${MODDIR}"/start.log
echo "响应音量键00：$(getprop init.svc.bootanim)：，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/start.log
$keyCheckPath
echo "响应音量键01：$(getprop init.svc.bootanim)：，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/start.log
$keyCheckPath
echo "响应音量键02：$(getprop init.svc.bootanim)：，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/start.log
$keyCheckPath
if [[ $? = 1 ]]; then
 msg=$($keyCheckPath 2>&1)
 echo "响应音量键手势异常，异常信息$msg：，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/Log.txt
 exit
fi

if [[ $(getprop init.svc.bootanim) == "stopped" ]]; then
  echo "正常开机，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>${MODDIR}/Log.txt
  if [ -f $checkEnableApps ]; then
    rm -rf "$checkEnableApps"
  fi
else
  touch "/cache/.disable_magisk"
  if [ -f $checkEnableApps ]; then
    rm -rf "$checkEnableApps"
    #解冻恢复软件
    rm -rf /data/system/users/0/package-restrictions.xml
    #禁用无障碍功能
    settings delete secure enabled_accessibility_services
  else
    touch "$checkEnableApps"
  fi
  for path in $(ls $modulesParent); do
    if [ "$path" != "RescueBrick" ]; then
      touch "$modulesParent/$path/disable"
    fi
  done

  echo "开机失败，发生时间：$(date "+%Y年%m月%d日%H:%M:%S")" >>"${MODDIR}"/Log.txt
  reboot

fi
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ✓音量监听结束 ] /g' "$MODDIR/module.prop"
