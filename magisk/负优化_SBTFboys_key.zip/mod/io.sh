set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2"
        chmod +x "$2"
        echo "$1" > "$2" && chmod 0644 "$2" || echo "修改"$2"失败！"
    fi
}


for i in $(find /sys/block/*/queue/iostats  /sys/block/*/queue/nomerges);do
set_value 0 "$i"
done