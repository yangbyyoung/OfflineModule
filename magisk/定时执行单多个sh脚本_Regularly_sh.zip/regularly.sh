MODDIR=${0%/*}

while true
do
[ ! -d /storage/emulated/0/Android ] && mkdir /storage/emulated/0/Android
[ ! -e /storage/emulated/0/Android/timing.ini ] && cp -f ${MODDIR}/timing.ini /storage/emulated/0/Android/
source /storage/emulated/0/Android/timing.ini
[ "${run_mode}" == "" ] && cp -f ${MODDIR}/timing.ini /storage/emulated/0/Android/
while [ "${on_off}" == "0" ]
do
sleep 40s
source /storage/emulated/0/Android/timing.ini
done
execute_day_s=$(($execute_day*86400))
timing_md5=`"${MODDIR}/busybox" md5sum "/storage/emulated/0/Android/timing.ini"|"${MODDIR}/busybox" cut -d ' ' -f1`
timing_md5_old=`"${MODDIR}/busybox" cat ${0%/*}/md5.txt`
[ "${timing_md5}" != "${timing_md5_old}" ] && echo -n "${timing_md5}" > "${0%/*}/md5.txt" && timing_md5_old=${timing_md5} && current_date=`"${MODDIR}/busybox" date "+%Y-%m-%d"` && execute_time_all="${execute_time}"':00' && execute_time_1=`"${MODDIR}/busybox" date -d "${current_date} ${execute_time_all}" +%s` && execute_time_2=$((${execute_time_1}+${execute_day_s})) && echo -n "${execute_time_2}" > "${0%/*}/time2.txt"
current_time=`"${MODDIR}/busybox" date +%s`
[ "${current_time}" -lt "${execute_time_1}" ] && sleep 40s && current_time=`"${MODDIR}/busybox" date +%s`
[ "${current_time}" -gt $((${execute_time_1}+60)) ] && current_time=`"${MODDIR}/busybox" date +%s` && execute_time_1=`"${MODDIR}/busybox" cat "${0%/*}/time2.txt"` && execute_time_2=$((${execute_time_2}+${execute_day_s})) && echo -n "${execute_time_2}" > "${0%/*}/time2.txt"
if [ "${current_time}" -ge "${execute_time_1}" ] && [ "${current_time}" -le $((${execute_time_1}+60)) ];then
for execute_sh_i in ${execute_sh}
do
[ "${run_mode}" == "1" ] && [ "${sequential_concurrent}" == "1" ] && sh ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt 
[ "${run_mode}" == "1" ] && [ "${sequential_concurrent}" == "2" ] && sh ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt &
[ "${run_mode}" == "2" ] && [ "${sequential_concurrent}" == "1" ] && source ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt 
[ "${run_mode}" == "2" ] && [ "${sequential_concurrent}" == "2" ] && source ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt &
[ "${run_mode}" == "3" ] && [ "${execute_sh_i:0:17}" == "/storage/emulated" ] && execute_sh_i=${execute_sh_i/'storage'/'data'} && execute_sh_i=${execute_sh_i/'emulated'/'media'} && chmod 0777 ${execute_sh_i} && [ "${sequential_concurrent}" == "1" ] && ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt 
[ "${run_mode}" == "3" ] && [ "${execute_sh_i:0:17}" == "/storage/emulated" ] && execute_sh_i=${execute_sh_i/'storage'/'data'} && execute_sh_i=${execute_sh_i/'emulated'/'media'} && chmod 0777 ${execute_sh_i} && [ "${sequential_concurrent}" == "2" ] && ${execute_sh_i} > ${execute_sh_i%"/"*}/${execute_sh_i##*"/"}_log.txt &
execute_sh_i=""
done
current_time=`"${MODDIR}/busybox" date +%s`
execute_time_1=`"${MODDIR}/busybox" cat "${0%/*}/time2.txt"`
execute_time_2=$((${execute_time_2}+${execute_day_s}))
echo -n "${execute_time_2}" > "${0%/*}/time2.txt"
sleep 60s
fi
done