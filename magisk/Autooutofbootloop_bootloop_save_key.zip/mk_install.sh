#!/system/bin/sh

echo "$(getprop ro.system.build.version.incremental)" > "$MODPATH/version"
chmod -R 0755 "$MODPATH"

abi=$(getprop ro.product.cpu.abi)
test "$abi" = "" && abi="$ARCH"

case $abi in
arm*) 
	mv -f "$MODPATH/tools/arm/keycheck" "$MODPATH/tools/keycheck"
	rm -rf $MODPATH/tools/arm $MODPATH/tools/x86
;;
x86*) 
	mv -f "$MODPATH/tools/x86/keycheck" "$MODPATH/tools/keycheck"
	rm -rf $MODPATH/tools/arm $MODPATH/tools/x86
;;
mips*)
	abort "- 目前不支持该处理器！"
;;
*) 
	abort "- 未知处理器！" 
;;
esac