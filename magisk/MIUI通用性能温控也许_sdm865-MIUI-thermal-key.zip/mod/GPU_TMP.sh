#!/system/bin/sh

function install_magisk_busybox() {
mkdir -p /data/adb/busybox
/data/adb/magisk/busybox --install -s /data/adb/busybox
chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}

#添加busybox，避免参数无用。
install_magisk_busybox

#模块目录
dir="${0%/*}"
MODPATH="${dir%/*}"
#读取配置
function show_value() {
	local value=$1
	local file="${MODPATH}/配置.prop"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function mod_gpu_tmp(){
local target_number="${1}"
test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='125000'
for i in $(ls -d /sys/class/thermal/thermal_zone*/*point*temp)
do
name=`cat "${i%/*}/type" | grep -Ei 'gpu|gpuss'`
value=`cat "${i}"`
if test "${name}" != "" ;then
	chmod -R 0755 "${i%/*}"
		chmod -R 0777 "${i}"
		echo "${target_number}" > "${i}"
	chmod 0555 "${i}"
	test "$(cat "${i}")" != "${target_number}" && echo "修改 ${i} 失败，值为$(cat ${i})"
fi
done
}


temperature_number="$(show_value 'GPU温度')"

if test "$(echo "$temperature_number" | grep -w '^[[:digit:]]*$')" != "" ;then
	mod_gpu_tmp "${temperature_number}"
fi


