hw2(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "hw2d.force" $i|cut -d / -f 5 ;done
}
hw3(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "hw3d.force" $i|cut -d / -f 5 ;done
}
sqlite(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "debug.sqlite.syncmode" $i|cut -d / -f 5 ;done
}
sqlite_wal(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "debug.sqlite.wal.syncmode" $i|cut -d / -f 5 ;done
}
net(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "ro.config.hw_power_saving" $i|cut -d / -f 5 ;done
}
picture(){
for i in $(find /data/adb -iname "*.prop" -type f);do grep -l "ro.media.enc" $i|cut -d / -f 5 ;done
}