# by Han | 情非得已c
# 当SKIPUNZIP=1时跳过默认的解压程序和设置权限过程
SKIPUNZIP=0

# 当REPLACE里设置了路径变量，会删除此目录，路径中不能有空格和特殊符号
# 例如这将删除/system/app/ceshi目录
REPLACE="
/system/app/ceshi
"

# 请尽量使用ui_print代替echo，因为echo的信息不会在TWRP恢复下显示
ui_print "by Han | 情非得已c"
# 开始自由编写shell代码



# 模块安装后请设置好权限
# 设置权限函数演示，具体请查看：README.md文件
set_perm "$MODPATH/rirud.apk" 0 0 0600

set_perm_recursive "$MODPATH" 0 0 0755 0644
