#!system/bin/sh

# ALL CODE DESIGNED BY HUBER_HAYU IN KU'AN
chmod +x Huber_EQFile_Ready.sh

# Make Folder and Copy Files
mkdir -p /storage/emulated/0/AA_Switch_EQ
mkdir -p /storage/emulated/0/AA_Switch_EQ/GameMode
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/bass.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/balance.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/old.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/Hi-Res.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/MidNight.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/outdoor.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/进入QQ音乐音频Debug.sh /storage/emulated/0/AA_Switch_EQ
sleep 0.2
cp -f /data/adb/modules/K50G/config/all_eq/Switch_File/进入AppleMusic.Debug模式.sh /storage/emulated/0/AA_Switch_EQ

# Game Audio
sleep 0.5
sh "/data/adb/modules/K50G/AI_Huber/AutoAudio.sh"
#sh "/data/adb/modules/K50G/config/harman.sh"