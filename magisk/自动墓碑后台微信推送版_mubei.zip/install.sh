# Most mods would like it to be enable
SKIPMOUNT=false
#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用

# Set to true if you need to load system.prop
PROPFILE=true
#是否使用common/system.prop文件

# Set to true if you need post-fs-data script
POSTFSDATA=true
#是否使用post-fs-data脚本执行文件

# Set to true if you need late_start service script
LATESTARTSERVICE=true
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
	ui_print "*******************************"
	ui_print "     自动墓碑后台APP模块    "
	ui_print "    作者：奋斗的小青年       "
	ui_print "   公众号：有效玩机  首发~！   "
	ui_print "*******************************
	23.08.10号更新内容：

	- 修复分享，快捷登录等卡系统界面。
	- 小黑猫不识别等问题，QQ，皮皮虾需要墓碑的请自行加黑名单。
	
	  基本介绍:
	- 切换模式后需要手动清理上一模式被冻结的APP。
	- 微信后台只留推送组件延迟5分钟执行。
	- 新增开机自动删除旧日志功能。
	- 增加微信识别，后台时只留必要的推送功能。
	- “墓碑黑名单.conf”可让顽固APP和系统APP进墓碑。
	- 统一日志到真实Android路径下。
	- 适配软件客户端软件来自大佬@离音。
	- 兼容Android10、到Android13+。
	- 独立运行不依赖系统组件。
	- APP离开前台后立即进入墓碑模式。不耗电，不占用CPU，只占运存。
	";
	ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"


##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
	ui_print "- 正在释放文件"
	unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'mb/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
	name=$(pm list packages | grep -w package:com.mubei.android)
	mubeiapp="package:com.mubei.android"
	if [[ $name == $mubeiapp ]]
	then
		ui_print "- 墓碑软件端已安装"
	

	else
		ui_print "- 墓碑软件端未安装"
		unzip -o "$ZIPFILE" 'mb.apk' -d /data/local/tmp/ >&2
		#以下安装APK代码来由搞机助手
		export File='/data/local/tmp/mb.apk'
		export Delete_APK='1'
		abort() {
			ui_print "$@" 1>&2
		}
		IFS=$'\n'
		suffix=${File##*.}
		name=`basename "$File"`
		[[ $1 = -s ]] && installer=" -i $installer " || installer=" "
		ui_print "- 正在安装墓碑软件端"
		if [[ ! -f $File ]]; then
			abort "- 文件不存在"
		else
			unzip -l "$File" &>/dev/null
			[[ $? -ne 0 ]] && abort "- $name 不是压缩文件"
		fi
		if [[ $suffix = apk ]]; then
			size=`ls -l "$File" | awk '{print $5}'`
			a="cat \""$File"\" | pm install -r -d -S "$size""$installer" 1> /dev/null"
			eval $a
			result=$?
			if [[ $result = 0 ]]; then
				ui_print "- 墓碑软件端 安装成功"
				[[ $Delete_APK = 1 ]] && rm -f "$File"

			else
				abort -e "- 墓碑软件端 安装失败"
			fi
		fi
	fi
	ui_print "- 已经删除临时文件"


}

set_permissions() {

	# The following is default permissions, DO NOT remove
	set_perm_recursive  $MODPATH  0  0  0777  0777

	#设置权限，基本不要去动
}

