#!/system/bin/bash

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 3
done

#全局高刷
if [[ `getprop ro.product.vendor.model` == "LE2110" ]]
then
service call SurfaceFlinger 1035 i32 1
else
[[ `wm size` == *'1080'* ]] && service call SurfaceFlinger 1035 i32 6
[[ `wm size` == *'1440'* ]] && service call SurfaceFlinger 1035 i32 13
fi

#温控
setprop sys.hans.enable false
setprop persist.vendor.enable.hans false

#调度
echo '1' > /proc/sys/kernel/sched_boost
echo '0' > /sys/devices/system/cpu/cpu4/core_ctl/enable
echo '0' > /sys/devices/system/cpu/cpu7/core_ctl/enable
echo '1190400' > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq

#LMK
setprop sys.lmk.minfree_levels "4096:0,5120:100,8192:200,32768:250,65536:900,96000:950"

#KTM
mkdir -p /dev/crond
echo -e \
'for thermal in $(ls /sys/class/thermal/thermal_zone{39..99}/mode)
do
echo disabled > $thermal
done' > /dev/thermaloff
echo '*/3 * * * * /system/bin/bash /dev/thermaloff' >/dev/crond/root
/data/adb/magisk/busybox crond -c /dev/crond
