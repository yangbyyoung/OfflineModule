#!/system/bin/sh
MODDIR=${0%/*}
name=$MODDIR/system/vendor/overlay/BsCharge
function get()
{
   echo  $MODDIR/Operate/$1/$2/*.xz
}

function Unzip()
{
   nohup $MODDIR/xz -d $1 -f
   touch $MODDIR/Operate/$2
   rm $MODDIR/Operate/$3
   sed -i "/^description=/c description=充电动画%$4" "$MODDIR/module.prop"
}

function before()
{
   cd $name
   cp $1 $(pwd)
   Unzip $name/*.xz $2 $3
}

[[ ! -d /storage/emulated/0/Android/ ]] && sm set-sdcardfs on

for x in $MODDIR/Operate/* ; do
   case "${x##*/}" in
   Tianxuan_First)
      before $(get TianXuan 1) Tianxuan_Second Tianxuan_First TianXuanJi
      break;
   ;;
   Tianxuan_Second)
      before $(get TianXuan 2) Tianxuan_Third Tianxuan_Second TianXuanJi   
      break;   
   ;;
   Tianxuan_Third)
      before $(get TianXuan 3) BlackShark Tianxuan_Third TianXuanJi   
      break;   
   ;;
   BlackShark)
      before $(get Shark 1) XueJi BlackShark BlackSharkJi
      break;   
   ;;
   XueJi)
      before $(get ChuiXueJi 1) RoJi XueJi ChuiXueJi   
      break;
   ;;
   RoJi)
      before $(get RoeJi 1) Tianxuan_First RoJi RoeJi   
      break;
   ;;
   esac
done