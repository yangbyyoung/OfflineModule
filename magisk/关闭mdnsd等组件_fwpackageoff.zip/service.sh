#!system/bin/sh
MODDIR=${0%/*}
stop cnss_diag
stop vendor.ipacm-diag
stop tcpdump
stop statsd
stop dpmd
stop dpmd.rc
stop mdnsd
stop mdnsd.rc
am kill cnss_diag
am kill vendor.ipacm-diag
am kill tcpdump
am kill statsd
am kill dpmd
am kill dpmd.rc
am kill mdnsd
am kill mdnsd.rc
killall -9 cnss_diag
killall -9 vendor.ipacm-diag
killall -9 tcpdump
killall -9 statsd
killall -9 dpmd
killall -9 dpmd.rc
killall -9 mdnsd
killall -9 mdnsd.rc