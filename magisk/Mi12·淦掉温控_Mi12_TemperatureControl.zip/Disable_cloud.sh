#!/system/bin/sh
#禁/启用app/服务列表，就不一一说明了
#如果游戏还是不能稳帧，请将以下去掉注释加到下列列表中，注意Enable_the_cloud.sh同步
#com.miui.powerkeeper
clouds="com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver"

#清理列表：MIUI的电量和性能，Analytics和Joyose
clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose"

#云控的域名/ip地址
Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

#禁用
for i in ${clouds};
do
  pm disable ${i}
done

#清除应用数据
for i in ${clears};
do
  pm clear ${i}
done

#Analytics，禁用服务和隐藏应用
pm suspend com.miui.analytics
pm hide com.miui.analytics
#打开云控界面，避免异常，下同
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
#打开Joyose智能服务
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity

#屏蔽MIUI云控，防止电量和性能接收云控数据。
for i in ${Cloud_address};
do
  iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -A INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done