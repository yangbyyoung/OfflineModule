if [[ ! -f /sys/class/qcom-battery/fg1_rsoc ]]; then
  echo '此模块不适用于您的设备'
  exit 1
fi