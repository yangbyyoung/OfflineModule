
SKIPUNZIP=1

ui_print "- 正在提取文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

ui_print "- 正在设置权限"
set_perm_recursive $MODPATH 0 0 0755 0644

ab=1
. $MODPATH/service.sh

ui_print "- 已完成挂载"

ui_print "- 完成权限设置"
ui_print " "
ui_print "------------------------------"
ui_print "- 注意事项："
ui_print "- 清除相关软件数据"
ui_print "- 对应挂载路径文件会丢失"
ui_print "------------------------------"
ui_print "- （需要的文件请注意备份）"
ui_print "------------------------------"
ui_print "- 清楚数据会导致挂载失效"
ui_print "- 重启后恢复"
ui_print "------------------------------"
ui_print "- 安装模块后再安装软件"
ui_print "- 不会挂载目录"
ui_print "- 重启后恢复"
ui_print "------------------------------"