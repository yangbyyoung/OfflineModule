#!/bin/sh
rm -rf /cache/dalvik-cache
mkdir -p /cache/dalvik-cache
rm -rf /data/system/package_cache/*
rm -rf /data/dalvik-cache/arm/*
rm -rf /data/dalvik-cache/arm64/*
rm -rf /data/system/fonts/theme_webview/*
#rm -rf $b/*.bak
rm -rf /data/system/theme_magic/*
rm -rf /data/system/shutdown-checkpoints/*
#rm -rf /data/system/battery-history/*
#rm -rf /data/system/sync/*
#rm -rf /data/system/users/0/*
rm -rf /data/system/theme_magic/*
rm -rf /data/resource-cache/*
rm -rf /storage/emulated/0/Android/Hubert/AutoTap
conf="/data/data/com.miui.misound/shared_prefs/mi_sound_preference.xml"
rm $conf