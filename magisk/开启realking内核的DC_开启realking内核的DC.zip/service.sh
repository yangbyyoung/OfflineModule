MODDIR=${0%/*}
echo "1">/sys/devices/platform/soc/soc:qcom,dsi-display-primary/msm_fb_ea_enable