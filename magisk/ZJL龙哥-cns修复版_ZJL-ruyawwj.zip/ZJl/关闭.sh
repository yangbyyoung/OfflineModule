zjlPath="${0%/*}/*/ZJL"
${zjlPath} -c -d