SKIPMOUNT=false
function key_source(){
if test -e "$1" ;then
	source "$1"
	rm -rf "$1"
fi
}

key_source $MODPATH/key.sh
key_source $MODPATH/check.sh
key_source $MODPATH/busybox.sh
key_source $MODPATH/setupcrond.sh
key_source $MODPATH/update.sh
key_source $MODPATH/package_extra.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}

