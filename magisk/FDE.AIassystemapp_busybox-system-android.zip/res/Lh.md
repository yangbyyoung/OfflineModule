### Informações da IA: Inteligência Artificial

FDE possui uma implementação de IA: Inteligência Artificial que funciona em qualquer dispositivo,
assim como a própria FDE. Seu objetivo é verificar o cenário de uso atual e adaptar alguns
parâmetros do sistema em tempo real para proporcionar a melhor experiência em cada cenário de uso.
Todos os aumento de desempenho/turbos são desativados automaticamente quando a tela está desligada.
Todas as ações da IA: Inteligência Artificial são registradas. A melhor parte é que isso NÃO consome
bateria.

---

#### O que é ativado automaticamente quando possível:

**Turbo da GPU**:\
A IA: Inteligência Artificial detectará automaticamente se a sua GPU pode executar a implementação
Turbo GPU da FDE e informará no log. O Turbo GPU mede a carga da GPU e, se mantiver alta (sob carga
pesada), a IA: Inteligência Artificial aumentará as frequências da GPU ao máximo por cerca de 30
segundos até a próxima verificação de carga ocorrer. Quando a carga da GPU diminuir, as frequências
padrão serão restauradas. Isso não fará seus jogos rodarem mais rápido, mas deve torná-los mais
estáveis, pois o governador não pulará de uma frequência para outra sob carga pesada. Isso não
depende do nome do pacote - monitora diretamente as cargas da GPU por qualquer motivo (jogo,
benchmark, etc). Tornando isso universal. Também depende da temperatura - os valores limite são
dinâmicos e não aumentarão as coisas se o dispositivo estiver superaquecido. Ativo apenas quando a
tela está LIGADA. Suportado na maioria das GPUs Adreno e Mali. Não entrará em conflito com a
implementação do Turbo GPU da Huawei.

**Turbo GPU Legado**:\
Este modo Turbo será selecionado se o driver da GPU do kernel não fornecer informações de carga em
tempo real. A diferença em relação ao Turbo GPU regular é que o Legado aumentará apenas em qualquer
processo/jogo da lista de aplicativos pesados em execução sem depender da carga da GPU em tempo
real. Você também pode habilitar o Turbo GPU Legado constante alterando manualmente o modo IA:
Inteligência Artificial para desempenho. Ative a opção de aumento de desempenho para jogos pesados
nas configurações para fazer este modo funcionar automaticamente. Ativo apenas quando a tela está
LIGADA. Suportado em algumas GPUs Mali e Vivante.

**Aumento do Framebuffer**:\
A IA: Inteligência Artificial detectará se o seu SoC pode executar a implementação de aumento de
desempenho do Framebuffer da FDE e informará no log. A IA: Inteligência Artificial aumenta
automaticamente as frequências do framebuffer quando a tela está LIGADA e a carga da GPU é maior que
30%. Isso resultará em uma taxa de quadros mais estável durante a renderização da tela. Ativo apenas
quando a tela está LIGADA. Suportado em alguns SoCs Qualcomm.

**Turbo CPU**:\
A IA: Inteligência Artificialdetectará se a sua CPU pode executar a implementação do Turbo CPU da
FDE e informará no log. O Turbo CPU mede a carga da CPU e, se mantiver alta (sob carga
pesada/estresse), a IA: Inteligência Artificial tornará o governador da CPU mais responsivo e fará
com que ele mantenha a frequência da CPU acima da "alta velocidade freq." (cerca de metade da
frequência máxima disponível) por cerca de 30 segundos até a próxima verificação de carga ocorrer.
Isso não depende do nome do pacote - monitora diretamente a carga da CPU por qualquer motivo (jogo,
benchmark, etc.), tornando isso universal. Isso depende da temperatura - os valores limite são
dinâmicos e não aumentarão as coisas se o dispositivo estiver superaquecido. Ativo apenas quando a
tela está LIGADA. Compatível com os governadores interativos, ondemand, schedutil e outros baseados
nestes.

**Aprendizado de máquina**:\
O aprendizado de máquina (Machine learning) é usado se o seu dispositivo suportar o Turbo CPU e/ou
GPU. O ML aprenderá como você usa seu dispositivo e adaptará alguns parâmetros do sistema em tempo
real. Se você joga muito, a IA: Inteligência Artificial aumentará o desempenho para você. Se você
apenas conversa e assiste a vídeos, a IA: Inteligência Artificial aumentará a economia de energia.
Se você estiver jogando e conversando, a IA: Inteligência Artificial decidirá o que fazer por si
mesma - é para isso que serve o aprendizado de máquina. No aplicativo FDE.AI, o comportamento da
escolha feita pelo ML pode ser configurado para sempre preferir economia de energia ou otimização de
desempenho.

**Ajustador dinâmico de VM**:\
Verifica o uso da RAM a cada 30 segundos aproximadamente e ajusta alguns parâmetros da VM com base
nesta verificação. Isso resultará em um gerenciamento de cache de RAM melhorado. Ele também
informará se o sistema estiver com pouca RAM livre. Ativo apenas quando a tela está LIGADA.

**Controlador térmico**:\
A IA: Inteligência Artificial verifica a temperatura do dispositivo e informa no log se o
dispositivo estiver superaquecendo. Os limites do Turbo CPU/GPU são calculados com base no valor
lido do controlador térmico, de modo que, se o dispositivo aquecer, o Turbo CPU/GPU interromperá o
aumento de desempenho no dispositivo e/ou fará isso mais raramente. Se a temperatura do dispositivo
ficar muito alta, ele substituirá quaisquer configurações de estrangulamento e ativará até que a
temperatura baixe um pouco, depois disso, restaurará os parâmetros de estrangulamento anteriores.

**Detector de estado de carregamento**:\
A Inteligência Artificial verifica se o dispositivo está sendo carregado ou não. Se estiver
carregando, a IA: Inteligência Artificial configura a VM (Virtual Memory/Memória Virtual) ( para
desempenho ideal. Quando você desconectar o dispositivo, o perfil anterior da VM será restaurado de
acordo com o perfil aprendido pela IA: Inteligência Artificial. O modo Forçar Doze (se habilitado)
também depende disso, evitando que seja executado enquanto o dispositivo estiver carregando. Este
recurso não aumenta as frequências, apenas ajusta as configurações da VM, então não é perigoso e não
fará o dispositivo superaquecer. Se o controle de desempenho (throttling) foi desativado pelo
usuário ou pela IA: Inteligência Artificial (para aplicativos/jogos pesados) - será reativado
durante o carregamento. Além disso, enquanto a IA: Inteligência Artificial está no modo avançado, o
estado de economia de energia do Android OS é monitorado - se ativado, a IA: Inteligência Artificial
será configurada automaticamente para o modo de economia de energia e não ativará o modo de
desempenho.
