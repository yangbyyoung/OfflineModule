# Hi-Res Audio Enabler Magisk Module

## Descriptions
- Enables high resolution 24 or 32 bit width audio output if device is supported.
- Causes no sound or low sound issue in unsupported device
- Not for Bluetooth audio
- Adds path name hph-highquality-mode to mixer path if not available yet

## Screenshots
- https://t.me/androidryukimodsdiscussions/6546
- https://t.me/androidryukimodsdiscussions/6539
- https://t.me/androidryukimodsdiscussions/1532

## Requirements
- Magisk or KernelSU installed

## Installation Guide & Download Link
- Install this module https://www.pling.com/p/1532198/ via Magisk app or KernelSU app or Recovery if Magisk installed
- This is also an audio mod so, you need to install AML Magisk Module https://t.me/androidryukimodsdiscussions/29836 if using any other audio mod module
- Reboot
- For checking is it applied or not, read Troubleshootings bellow!

## Optionals & Troubleshootings
- https://t.me/androidryukimodsdiscussions/60861
- https://t.me/androidryukimodsdiscussions/29836
- https://t.me/androidryukimodsdiscussions/58223

## Support & Bug Report
- https://t.me/androidryukimodsdiscussions/2618 (Z folder is enough, no need logs)
- If you don't do above, issues will be closed immediately

## Tested on
- Android 10 CrDroid ROM
- Android 11 DotOS ROM
- Android 12 AncientOS ROM
- Android 12.1 Nusantara ROM
- Android 13 Nusantara ROM, AOSP ROM, & CrDroid ROM

## Credits and contributors
- https://t.me/viperatmos
- https://t.me/androidryukimodsdiscussions
- You can contribute ideas about this Magisk Module here: https://t.me/androidappsportdevelopment

## Thanks for Donations
This Magisk Module is always will be free but you can however show us that you are care by making a donations:
- https://ko-fi.com/reiryuki
- https://www.paypal.me/reiryuki
- https://t.me/androidryukimodsdiscussions/2619


