SKIPMOUNT=false#刷入自动开启
PROPFILE=false#system.prop
POSTFSDATA=true#post-fs-data
LATESTARTSERVICE=true@#service.sh
print_modname() {
  ui_print ""
  ui_print "  🔻 小米 11 出厂音频驱动（含旧版音效音质）"
  ui_print "    💠 模块原版为酷安 @枫落流昔 制作。"
  ui_print "    💠 由 @Asstiff 改编为小米 11 出厂驱动"
  ui_print "    💠 安装核心破解效果更佳，否则可能无法打开“音效音质”"

  ui_print ""
}

#！！！！！！！！！！！！！！！！！！
on_install() {  
  sleep 0.3s
  ui_print "  💬 基于 12.0.12.0 vendor 内驱动"
  ui_print "     内置出厂“音效音质”应用，但由于降级，可能导致其卡退。"
  ui_print "     如果需要，请自行重新安装一遍它"
  ui_print "     不确定本模块是不是真的有用，不确定会不会导致 bug"
  ui_print ""
  ui_print ""
  sleep 0.5s
  ui_print "            ⚠️完全实验性⚠️            "
  ui_print ""
  sleep 0.5s
  ui_print ""
  ui_print "  💬 哦对了，光替换为出厂版本“音效音质”"
  ui_print "     就说音质有变化的，纯属智商检测"  
  ui_print "     实测，恢复出厂版本“音效音质”完全没用"
  ui_print "     不信？你试试 root 后卸载掉音效音质，音效也不会有任何变化"
  sleep 0.4s
  ui_print ""
  ui_print "  🔇（虽然我这个模块可能也没有任何用）"
  ui_print ""
  ui_print ""
  sleep 0.5s
  ui_print "             🕐正在安装🕐"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d $MODPATH >&2
  ui_print ""
  ui_print ""
  sleep 2s
  ui_print "  🟢 安装完毕，请重启。"
  ui_print ""
  ui_print "  ⚠️ 默认情况打不开“音效音质”，正常情况，不影响效果"
  ui_print "     本模块支持在安装核心破解的情况下开机自动安装旧版“音效音质”"
  ui_print ""  
  sleep 0.7s
  ui_print "  🔇（其实可以秒装完）"
  ui_print "    （但秒装完显得好假）"
  ui_print ""
  

}
set_permissions() {
  set_perm_recursiven  $MODPATH  0  0  0755  0644
  set_perm $MODPATH/service.sh 0 0 0755 0644
  set_perm $MODPATH/post-fs-data.sh 0 0 0755 0644
}