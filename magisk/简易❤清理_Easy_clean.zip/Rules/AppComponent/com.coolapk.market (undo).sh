#【酷安】【版本 13.2.1(2306161)】
exec >/dev/null 2>&1 #重定向输出，不显示
#onekit 服务
pm enable com.coolapk.market/com.volcengine.onekit.component.ComponentDiscoveryService
#onekit 内容提供者
pm enable com.coolapk.market/com.volcengine.onekit.OneKitInitProvider
#未知
pm enable com.coolapk.market/com.coolapk.market.view.ad.interstitial.InterstitialAdActivity
#开屏遮罩
pm enable com.coolapk.market/com.coolapk.market.view.splash.FullScreenAdActivity
pm enable com.coolapk.market/com.coolapk.market.view.ad.dpsdk.DrawVideoFullScreenActivity
#杯子？
pm enable com.coolapk.market/com.beizi.ad.AdActivity
#杯子？服务
pm enable com.coolapk.market/com.beizi.ad.DownloadService
#腾讯广告SDK
pm enable com.coolapk.market/com.qq.e.ads.ADActivity
pm enable com.coolapk.market/com.qq.e.ads.DialogActivity
pm enable com.coolapk.market/com.qq.e.ads.LandscapeADActivity
pm enable com.coolapk.market/com.qq.e.ads.PortraitADActivity
pm enable com.coolapk.market/com.qq.e.ads.RewardvideoLandscapeADActivity
pm enable com.coolapk.market/com.qq.e.ads.RewardvideoPortraitADActivity
#log
pm enable com.coolapk.market/com.tencent.qcloud.logutils.LogActivity
pm enable com.coolapk.market/com.apm.applog.migrate.MigrateDetectorActivity

#腾讯广告SDK 内容提供器
pm enable com.coolapk.market/com.qq.e.comm.GDTFileProvider
#腾讯广告SDK 服务
pm enable com.coolapk.market/com.qq.e.comm.DownloadService
#天目
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuAdDetailActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuAppPermissionsActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuFullScreenVodActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuLandscapeFullScreenVodActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuLoadingPageActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuRewardVodActivity
pm enable com.coolapk.market/com.tianmu.ad.activity.TianmuWebViewActivity
#天目 内容提供者
pm enable com.coolapk.market/com.tianmu.provider.TianmuAdFileProvider
#穿山甲
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPAuthor2Activity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPBrowserActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPDramaDetailActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPDrawPlayActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPHomePageActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPNewsDetailActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.core.privacy.DPPrivacySettingActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPReportActivity
pm enable com.coolapk.market/com.bytedance.sdk.dp.host.act.DPSearchActivity
pm enable com.coolapk.market/com.bytedance.sdk.open.douyin.ui.DouYinWebAuthorizeActivity
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.DouyinAuthorizeActivityProxy
pm enable com.coolapk.market/com.bytedance.ies.xbridge.system.activity.GetPermissionActivity
pm enable com.coolapk.market/com.bytedance.ug.sdk.luckycat.impl.stubproxy.LuckyCatBrowserExposeStubProxy
pm enable com.coolapk.market/com.bytedance.applog.migrate.MigrateDetectorActivity
pm enable com.coolapk.market/com.bytedance.novel.view.NovelReaderActivity
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$Activity
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$Activity_Behind
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$Activity_Portrait
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$Activity_T_SingleTask1
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$AppCompat
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$AppCompat_Portrait
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$AppCompat_SingleTask2
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$AppCompat_T_SingleTop1
pm enable com.coolapk.market/com.bytedance.pangrowth.reward.StubActivity\$Activity_main_standard
pm enable com.coolapk.market/com.bytedance.pangrowth.reward.StubActivity\$AppCompat_main_singleTop1
pm enable com.coolapk.market/com.bytedance.pangrowth.reward.StubActivity\$AppCompat_main_standard
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity_T
pm enable com.coolapk.market/com.bytedance.novel.channel.NovelWebActivity
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$Activity_T
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.StubActivity\$AppCompat_T
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Activity
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity1
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity2
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity3
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity4
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity5
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity6
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity7
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_SingleTop_Portrait_AppCompatActivity_DramaDetail
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity_T
pm enable com.coolapk.market/com.bytedance.android.openliveplugin.stub.activity.Stub_Standard_Activity_DouyinWebAuthorizeActivity
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Landscape_Activity
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity
pm enable com.coolapk.market/com.bytedance.sdk.dp.stub.activity.Stub_Standard_Portrait_AppCompatActivity_T
pm enable com.coolapk.market/com.bytedance.pangrowth.reward.activity.WXConfigAlertDialogActivity
pm enable com.coolapk.market/com.bytedance.ug.sdk.luckycat.impl.wxauth.WXEntryActivity
pm enable com.coolapk.market/com.ss.android.downloadlib.activity.JumpKllkActivity
pm enable com.coolapk.market/com.ss.android.downloadlib.activity.TTDelegateActivity
pm enable com.coolapk.market/com.ss.android.downloadlib.addownload.compliance.AppDetailInfoActivity
pm enable com.coolapk.market/com.ss.android.downloadlib.addownload.compliance.AppPrivacyPolicyActivity
pm enable com.coolapk.market/com.ss.android.socialbase.appdownloader.view.DownloadTaskDeleteActivity
pm enable com.coolapk.market/com.ss.android.socialbase.appdownloader.view.JumpUnknownSourceActivity
#穿山甲SDK 内容提供器
pm enable com.coolapk.market/com.bytedance.sdk.dp.act.DPProvider
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.server.DownloaderServerManager
pm enable com.coolapk.market/com.bytedance.pangle.FileProvider
pm enable com.coolapk.market/com.bytedance.pangle.provider.MainProcessProviderProxy
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.stub.server.MainServerManager
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.TTFileProvider
pm enable com.coolapk.market/com.bytedance.sdk.openadsdk.multipro.TTMultiProvider
#穿山甲SDK 广播接收器
pm enable com.coolapk.market/com.bytedance.applog.collector.Collector
pm enable com.coolapk.market/com.ss.android.downloadlib.core.download.DownloadReceiver
#穿山甲SDK 服务
pm enable com.coolapk.market/com.ss.android.socialbase.appdownloader.DownloadHandlerService
pm enable com.coolapk.market/com.ss.android.socialbase.appdownloader.RetryJobSchedulerService
pm enable com.coolapk.market/com.ss.android.socialbase.downloader.downloader.DownloadService
pm enable com.coolapk.market/com.ss.android.socialbase.downloader.downloader.IndependentProcessDownloadService
pm enable com.coolapk.market/com.ss.android.socialbase.downloader.downloader.SqlDownloadCacheService
pm enable com.coolapk.market/com.ss.android.socialbase.downloader.impls.DownloadHandleService
pm enable com.coolapk.market/com.ss.android.socialbase.downloader.notification.DownloadNotificationService
#ADmobile ADSuyi
pm enable com.coolapk.market/admsdk.library.activity.AdDetailActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileAppPermissionsActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileDownloadApkConfirmDialogActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileFullScreenVodActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileLandscapeFullScreenVodActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileLandscapeRewardVodActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileRewardVodActivity
pm enable com.coolapk.market/admsdk.library.activity.AdmobileWebViewActivity
pm enable com.coolapk.market/cn.admobiletop.adsuyi.adapter.gdt.widget.DownloadApkConfirmDialogActivity
#ADmobile ADSuyi 内容提供者
pm enable com.coolapk.market/admsdk.library.provider.AdmAdFileProvider
#xunmeng SDK 讯盟
pm enable com.coolapk.market/com.xunmeng.amiibo.rewardvideo.RewardVideoAdActivity
pm enable com.coolapk.market/com.xunmeng.amiibo.view.ULinkLandActivity
#xunmeng 服务
pm enable com.coolapk.market/com.xunmeng.pinduoduo.apm4sdk.crash.service.CrashReportIntentService
#快手广告SDK
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.AdWebViewActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$ChannelDetailActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$DeveloperConfigActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$EpisodeDetailActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity1
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity2
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity3
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity4
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity5
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity6
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity7
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity8
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity9
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivity10
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivitySingleInstance1
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivitySingleInstance2
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivitySingleTop1
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$FragmentActivitySingleTop2
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$GoodsPlayBackActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$KsTrendsActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$ProfileHomeActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$ProfileVideoDetailActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$TubeDetailActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity\$TubeProfileActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.FeedDownloadActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.KSRewardLandScapeVideoActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.KsFullScreenLandScapeVideoActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.KsFullScreenVideoActivity
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.KsRewardVideoActivity
#快手广告SDK 内容提供者
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.AdSdkFileProvider
#快手广告SDK 广播接收器
pm enable com.coolapk.market/com.kuaishou.weapon.p0.receiver.WeaponRECE
#快手广告SDK 服务
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.DownloadService
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.FileDownloadService\$SeparateProcessService
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.FileDownloadService\$SharedMainProcessService
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.app.ServiceProxyRemote
pm enable com.coolapk.market/com.kwad.sdk.api.proxy.VideoWallpaperService
#小米广告SDK
pm enable com.coolapk.market/com.miui.zeus.landingpage.sdk.activity.WebViewActivity
pm enable com.coolapk.market/com.miui.zeus.mimo.sdk.ad.reward.RewardVideoAdActivity
pm enable com.coolapk.market/com.miui.zeus.mimo.sdk.view.WebViewActivity
pm enable com.coolapk.market/com.miui.zeus.mimo.sdk.ad.reward.RewardVideoAdActivityNew


