#!/bin/bash
MODDIR=${0%/*}

cd $MODDIR/
#Run script program
awk 'BEGIN {
    i=0;
    do {
		system("'$PWD/Gameswitchs.sh' ")
    }
    while (i)
exit;
}'