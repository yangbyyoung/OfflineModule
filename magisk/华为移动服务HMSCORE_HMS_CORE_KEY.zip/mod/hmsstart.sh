#!/system/bin/sh
#am start -n com.huawei.appmarket/.MainActivity 2>/dev/null
#input keyevent HOME
am start -n com.huawei.hwid/com.huawei.hms.core.activity.JumpActivity 2>/dev/null