#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# LMK
chmod 777 /sys/module/lowmemorykiller/parameters/minfree
chown 777 /sys/module/lowmemorykiller/parameters/minfree
echo '10240,16384,18432,20480,30720,33280' > /sys/module/lowmemorykiller/parameters/minfree
echo '56250' > /sys/module/lowmemorykiller/parameters/vmpressure_file_min
adjZeroMinFree=14746
echo '262144' > /proc/sys/vm/extra_free_kbytes
# Kill无用线程
killall -9 com.xiaomi.market
killall -9 com.miui.screenrecorder
killall -9 com.miui.bugreport
#优化
  if ${memopt} ; then
    busybox=/data/adb/magisk/busybox
      $busybox fstrim /data 2>/dev/null
      sleep 10
    echo all > /sys/block/zram0/idle
    sleep 10
    echo idle > /sys/block/zram0/writeback
  fi
}
  if ${affinity} ; then
    fuck_you(){
      local ps_ret="$(ps -Ao pid,args)"
      for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
          taskset -p "$2" "$temp_tid"
          renice "$3" -p "$temp_tid"
        done
      done
    }
    fuck_you "kswapd" "e0" "-2"
    fuck_you "oom_reaper" "4" "-3"
    echo 8 > /sys/block/zram0/max_comp_streams
    echo 0 > /proc/sys/vm/page-cluster
    echo 0 > /proc/sys/vm/compact_unevictable_allowed
    echo 650 > /proc/sys/vm/extfrag_threshold
  fi
}
zram_efficient
optimize_mem
sleep 10
sync
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory