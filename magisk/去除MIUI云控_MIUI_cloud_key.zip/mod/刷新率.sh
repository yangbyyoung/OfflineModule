#!/system/bin/sh

test "$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit

#定义分隔符
local IFS=$'\n'

#输出文件
folder="${0%/*}/刷新率"
test -d "$folder" && rm -rf "$folder"
mkdir -p "$folder"

#输出刷新率命令
for i in $(dumpsys display | grep 'DisplayModeRecord' )
do
level_id="$(echo $i | grep -wo 'id=[0-9].*[0-9],' | sed 's|id=||g;s|,.*||g' )"
cmd_id="$(($level_id - 1))"
fps_level="$(echo $i | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' )"
width="$(echo $i | grep -wo 'width=[0-9].*[0-9],' | sed 's|width=||g;s|,.*||g;s|height=[0-9].*[0-9]||g' )"
height="$(echo $i | grep -wo 'height=[0-9].*[0-9],' | sed 's|height=||g;s|,.*||g;s|width=[0-9].*[0-9]||g' )"
cat << key >> "$folder/"$fps_level"_"$width"X"$height".sh" && echo -e "\n生成 [ 刷新率: "$fps_level" 分辨率: "$width"X"$height" ] 脚本！"
#!/system/bin/sh
#@coolapk 10007
#service方法
#dumpsys display | grep 'DisplayModeRecord'
#可以看到 "档数=(id - 1)"
#利用service call SurfaceFlinger 1035 i32 档数 实现刷新率自定义。
#刷新率: $fps_level ($level_id) 
#档位: $cmd_id
#屏幕分辨率: $width X $height
#但是启用智能刷新率后无法用"service code"和 "settings 刷新率" 来修改刷新率
#以及会和dfps会冲突(因为dfps用的就是这两个反复写入。)
#命令:
test "\$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit

service call SurfaceFlinger 1035 i32 $cmd_id
settings put secure support_highfps 1
settings put system peak_refresh_rate $fps_level
settings put system user_refresh_rate $fps_level
settings put system miui_refresh_rate $fps_level
settings put system min_refresh_rate $fps_level
settings put system default_refresh_rate $fps_level
settings put system refresh_default_rate $fps_level
resetprop persist.vendor.dfps.level $fps_level
#启动MIUI刷新率检测
#su -c cmd activity startservice -n com.miui.powerkeeper/.ui.framerate.FrameRateService >/dev/null 2>&1
key
done

cat << key > "$folder/恢复.sh" && echo -e "\n已生成恢复脚本！"
#!/system/bin/sh
#@coolapk 10007
#service方法
#dumpsys display | grep 'DisplayModeRecord'
#可以看到 "档数=(id - 1)"
#利用service call SurfaceFlinger 1035 i32 档数 实现刷新率自定义。
#刷新率: $fps_level ($level_id)
#命令:
test "\$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit
service call SurfaceFlinger 1035 i32 -1
settings delete secure support_highfps
settings delete system peak_refresh_rate
settings delete system user_refresh_rate
settings delete system miui_refresh_rate
settings delete system min_refresh_rate
settings delete system default_refresh_rate
settings delete system refresh_default_rate
resetprop ro.vendor.smart_dfps.enable true
resetprop --delete persist.vendor.dfps.level
if test "$(getprop ro.miui.ui.version.name)" != "" ;then
	am force-stop com.miui.powerkeeper >/dev/null 2>&1
	su -c cmd activity startservice -n com.miui.powerkeeper/.ui.framerate.FrameRateService >/dev/null 2>&1
fi
key


echo -e "\n已生成文件夹 "$folder" \n\n请到文件夹里用root执行脚本，修改刷新率\n"



