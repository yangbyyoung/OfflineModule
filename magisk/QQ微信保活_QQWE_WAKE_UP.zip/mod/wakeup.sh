processa=`ps -ef |grep -w 'com.tencent.mobileqq' | grep -v grep | wc -l`
processb=`ps -ef |grep -w 'com.tencent.mm' | grep -v grep | wc -l`
processmainq=`ps -ef |grep -w 'com.tencent.mobileqq:MSF' | grep -v grep | wc -l`
processmainw=`ps -ef |grep -w 'com.tencent.mm:push' | grep -v grep | wc -l`

MOD='/data/adb/modules/QQWE_WAKE_UP/module.prop'
MOD2='/data/adb/lite_modules/QQWE_WAKE_UP/module.prop'
test -e $MOD2 && MOD=$MOD2

function wake_up_process(){
	QQservice="
	com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService
	com.tencent.mobileqq/com.tencent.mobileqq.app.CoreService
	"
	MMservice="
	com.tencent.mm/com.tencent.mm.booter.CoreService
	"
	for i in $QQservice $MMservice;do
		am startservice -n $i
	done
	for i in com.tencent.mm com.tencent.mobileqq;do
		dumpsys deviceidle whitelist +$i
	done
}

if test "$processa" -lt "2" -o "$processb" -lt "2" -o "$processmainq" -lt "1" -o "$processmainw" -lt "1" ;then
	test "$processa" -lt "2" -o "$processmainq" -lt "1" && {
		sed -i "/^description=/c description="$(date +%H:%M)"，QQ被杀死，已经为您保活。" $MOD
	}
	test "$processb" -lt "2" -o "$processmainw" -lt "1" && {
		sed -i "/^description=/c description="$(date +%H:%M)"，微信被杀死，已经为您保活。" $MOD
	}
wake_up_process 2> /dev/null
fi

