功能列表:

[Magisk_该模块缓存] 清理 
[Magisk日志] 清理 
[MIUI桌面日志] 清理 
[MIUI系统日志] 清理 
[Wlan_Logs日志] 清理 

X5_UC_内核禁用:
[高德地图] 垃圾文件清理
[哔哩哔哩] 日志文件清理
[铁路12306] 启动广告禁用
[腾讯QQ] 日志文件清理
[QQ] X5内核备份和日志清理
[腾讯网盘] X5内核禁用
[腾讯地图] X5内核禁用
[腾讯QQ] X5内核禁用
[QQ邮箱] X5内核禁用
[腾讯微信] X5内核禁用
[企业微信] X5内核禁用
[京喜] X5内核禁用
[京东] X5内核禁用
[京东极速版] X5内核禁用
[歌词适配] X5内核禁用
[哔哩哔哩] X5内核禁用
[朴朴超市] X5内核禁用
[叮咚买菜] X5内核禁用
[和彩云网盘] X5内核禁用
[铁路12306] UC内核禁用

SD Maid清理:
[应用程序无响应] 事件日志 清理 
[Android系统临时文件] 清理 
[Android系统日志文件] 清理 
[Logcat日志] 清理 
[应用使用分析统计信息] 清理 
[应用崩溃日志] 清理 
[SD Maid] 清理 

微信清理:
[微信垃圾日志_缓存] 清理开始 
[日志文件] 清理 
[主缓存] 清理 
[插件] 清理 
[视频缓存] 清理 
[升级缓存] 清理 
[广告缓存] 清理 
[WebView缓存] 清理 
[TBS插件 X5内核] 清理 
[直播] 清理 
[公共目录垃圾日志_缓存] 清理 
[微信垃圾日志_缓存] 清理 

Doze省电休眠策略:
[Doze省电休眠策略] 参数调整已完成，请配合Doze激进模式使用 

MIUI耗电进程优化:
mdnsd优化
mdnsd.rc优化
logd优化
logd.rc优化
dumpstate优化
dumpstate.rc优化
dpmd优化
dpmd.rc优化
qseelogd优化
qseelogd.rc优化
tcpdump优化
cnss_diag优化
charge_logger优化

MIUI12 水龙优化 @水龙:
禁用binder调试 
禁用内核调试 
禁用用户空间向dmesg写入日志 
禁用sched_autogroup 
禁用f2fs I/O数据收集统计 
禁用调度统计 
禁用I/O统计 
禁用(存储I/O)调试帮助 
禁用I/O调试，UFS 和EMMC皆可用 
禁用不必要的转储 RAMDUMP 
禁用调试驱动 

Google Doze优化
