#清除模块卸载残留
rm -rf /data/adb/Dex2oatBOOT
