#!/bin/sh

cd /data/user/0/cn.gov.pbc.dcep/

chattr -i envc.push

echo "r=0" > envc.push

chattr +i envc.push

ui_print "正在安装模块..."    

ui_print "by 忆雨"

ui_print "无聊瞎写的()"

ui_print "安装成功！！"

ui_print "重启APP生效"

ui_print "正在前往作者首页"

sleep 1

am start -d 'coolmarket://u/13562649' >/dev/null 2>&1