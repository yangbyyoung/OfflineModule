# Changelog

## All changelogs are now here:

https://www.androidacy.com/blog/
