# 安装时显示的模块名称
mod_name="MIUI补全优化"
# 模块介绍
mod_install_desc="✨是否MIUI补全优化"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"
# 按下[音量+]选择的功能提示
mod_select_yes_text="安装$mod_name"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_desc=" "
# 按下[音量-]选择的功能提示
mod_select_no_text="不安装$mod_name"

# 按下[音量+]时执行的函数
# 如果不需要，请保留函数结构和return 0
mod_install_yes()
{
/sbin/.magisk/busybox/chattr -i -a -A /cache/magisk.log
chmod 777 /cache/magisk.log
/sbin/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.solohsu.android.edxp.manager/log
chmod 777 /data/user_de/0/com.solohsu.android.edxp.manager/log
/sbin/.magisk/busybox/chattr -i -a -A /data/user_de/0/org.meowcat.edxposed.manager/log
chmod 777 /data/user_de/0/org.meowcat.edxposed.manager/log
/sbin/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.miui.home/cache/debug_log
chmod 777 /data/user_de/0/com.miui.home/cache/debug_log
/dev/*/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.miui.home/cache/debug_log
/dev/*/.magisk/busybox/chattr -i -a -A /data/user_de/0/org.meowcat.edxposed.manager/log
/dev/*/.magisk/busybox/chattr -i -a -A /data/user_de/0/com.solohsu.android.edxp.manager/log
/dev/*/.magisk/busybox/chattr -i -a -A /cache/magisk.log

return 0
}

mod_install_no()
{

rm -rf $TMPDIR
exit 1
    return 0
}
