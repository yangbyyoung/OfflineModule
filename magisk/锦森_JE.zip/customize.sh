  ui_print "*******************************"
  ui_print "刷入中"
  ui_print "你下一个云控何必是云控"
  ui_print "刷入成功后请你重启手机"
  ui_print "*******************************"
  
  
  pm uninstall -k --user 0 com.miui.analytics
  pm install-existing --user 0 com.miui.daemon