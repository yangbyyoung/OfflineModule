# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0


if [[ $(getprop ro.miui.ui.version.name) = V125 ]]; then
    print "您的系统是MIUI12.5"
   else
   print "您的系统是MIUI13"
   
fi


Print "  ※ 模块信息 ※"
Print "- 模块名称: $MODNAME"
Print "- 模块版本: $MODVERSION"
Print "- 模块代号: $MODID"
Print "- 模块制作: $MODAUTH"
Print "_______________"
Print "  ※ 系统详情 ※"
Print "¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
Print "- 设备代号: $(getprop ro.product.device)"
Print "- 芯片型号: $Hardware $(($(cat /sys/devices/system/cpu/kernel_max) + 1))核"
Print "- 芯片架构: $(getprop ro.product.cpu.abi)"
Print "- 安卓版本: Android $(getprop ro.build.version.release)"
Print "- 系统版本: $(getprop ro.build.version.incremental)"
Print "- 基线版本: $(getprop ro.build.display.id)"
Print "- 内存大小: $(cat /proc/meminfo | head -n 1 | awk '{print $2/1000}')MB"
Print "- 闪存颗粒: $UFS_MODEL $Particles"
Print "- 内核版本: $(uname -r)"
Print "_______________"
Print "  ※ 附加信息 ※"
Print "¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
Print "悍匪制作"
Print "- 刷入时间: $Start_Time"
End_Time=$(date "+%Y-%m-%d %H:%M:%S")
Print "- 刷入耗时: $(Print $((Sleep_Time + $(date +%s -d "${End_Time}") - $(date +%s -d "${Start_Time}"))) | awk '{t=split("60 秒 60 分 24 时 999 天",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}')"
Print "_______________"
Print "  ※ 刷入成功 ※"
Print "¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
Print "- 请重启设备."
