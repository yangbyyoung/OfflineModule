#!/system/bin/sh
/sbin/magisk su -c 'sh /data/adb/modules/miui_charge_mi10/data1.sh'
/sbin/magisk su -c 'sh /data/adb/modules/miui_charge_mi10/data2.sh'
/sbin/magisk su -c 'sh /data/adb/modules/miui_charge_mi10/data3.sh'
