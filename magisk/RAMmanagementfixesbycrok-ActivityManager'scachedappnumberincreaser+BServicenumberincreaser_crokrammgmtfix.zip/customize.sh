ui_print ""
ui_print "################################"
ui_print "#                              #"
ui_print "# crok's RAM management tweaks #"
ui_print "#                              #"
ui_print "################################"
ui_print ""

