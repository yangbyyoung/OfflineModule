SKIPMOUNT=false
#安装模块后禁用模块
PROPFILE=false
#调用system.prop
POSTFSDATA=false
#使用post-fs-data脚本
LATESTARTSERVICE=false
#开机时执行common/service.sh中脚本
print_modname() {
  ui_print "*******************************"
  ui_print "  Magisk Module:         "
  ui_print "  By 穗穗"
  ui_print "*******************************"
  ui_print "原创模块            禁止转载"
  
}
REPLACE="
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
#不要尝试去更改这个，你会后悔的
REPLACE="

"
#同上，这个和应用精简有关
on_install() {
  ui_print "- 正在执行..."
  ui_print "重要的事情说3遍"
  ui_print "使用方法;长按桌面，选择壁纸，点动态壁纸就可以啦"
  ui_print "使用方法;长按桌面，选择壁纸，点动态壁纸就可以啦"
  ui_print "使用方法;长按桌面，选择壁纸，点动态壁纸就可以啦"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
#权限<owner> <group> <dirpermission> <filepermission>
}
#权限<owner> <group> <dirpermission> <filepermission>
