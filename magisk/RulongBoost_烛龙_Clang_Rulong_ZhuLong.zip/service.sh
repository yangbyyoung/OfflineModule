# 挂载分区
mount -o remount,rw /
#
if [ -e /system/app/olx/olx.apk ] 
then
echo "检测到MiuiCx_Rom"
rm -rf /system/xbin/olx
rm -rf /system/xbin/olx.boot
rm -rf /system/xbin/olx.init
rm -rf /system/xbin/olx.d
rm -rf /system/xbin/olx.set
rm -rf /system/xbin/olx.fstrim
rm -rf /system/xbin/olx.vfs
rm -rf /system/xbin/olx.version
rm -rf /system/xbin/olx.wlan
#
else
echo
fi
#
chmod 0777 /system/xbin/busybox
chmod 0777 /system/xbin/Rulong/olx
chmod 0777 /system/xbin/Rulong/olx.boot
chmod 0777 /system/xbin/Rulong/olx.init
chmod 0777 /system/xbin/Rulong/olx.d
chmod 0777 /system/xbin/Rulong/olx.set
chmod 0777 /system/xbin/Rulong/olx.fstrim
chmod 0777 /system/xbin/Rulong/olx.vfs
chmod 0777 /system/xbin/Rulong/olx.version
chmod 0777 /system/xbin/Rulong/olx.wlan