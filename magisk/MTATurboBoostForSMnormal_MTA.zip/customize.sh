SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
D="`grep_prop description $TMPDIR/module.prop`"
ui_print "- *******************************"
ui_print "- $C    "
ui_print "- 作者：$B"
ui_print "- $D    "
ui_print "- *******************************"

sleep 2
cp -rf /system/lib64/android.frameworks.displayservice@1.0.so $MODPATH/system/lib64/android.frameworks.displayservice@1.0.so
sleep 2

set_perm_recursive  $MODPATH  0  0  0755  0777





