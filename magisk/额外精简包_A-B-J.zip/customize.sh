SKIPUNZIP=0

i=0

if [[ -d /data/adb/modules_update/MIUI12ABajiangXiaoJingJian ]]; then
  Streamline=/data/adb/modules_update/MIUI12ABajiangXiaoJingJian
else
  Streamline=/data/adb/modules/MIUI12ABajiangXiaoJingJian
fi

mkt() {
  [[ ! -d ${2} ]] && return 0
  i=$(expr ${i} + 1)
  echo "- 替换目标: $i $1 $2"
  mkdir -p ${Streamline}/${2} 2>/dev/null
  touch ${Streamline}/${2}/.replace
  chmod 644 ${Streamline}/${2}/.replace
}

[[ ! -d ${Streamline} ]] && abort "- ！没有安装小精简，无法进行安装额外精简"
[[ $(grep_prop version ${Streamline}/module.prop) != "v4.1" ]] && abort "- ！请先安装新版本小精简模块"

echo " "
echo "#########################"
echo "- 模块: $(grep_prop name $TMPDIR/module.prop)"
echo "- 模块ID: $(grep_prop id $TMPDIR/module.prop)"
echo "- 作者: $(grep_prop author $TMPDIR/module.prop)"
echo "- 介绍: $(grep_prop description $TMPDIR/module.prop)"
echo "#########################"
echo "- 设备相关信息↓"
echo "- SDK: $(getprop ro.build.version.sdk)"
echo "- 设备: $(getprop ro.fota.oem)"
echo "- 设备代号: $(getprop ro.product.device)"
echo "- 安卓版本: Android $(getprop ro.build.version.release)"
echo "- MIUI版本: $(getprop ro.miui.ui.version.name)  $(getprop ro.build.version.incremental)"
echo "#########################"
echo " "

# 请先阅读：默认大部分开启，自己需要保留哪些，删除对应行，右上角保存刷入即可。
# 刷入后不会生成模块，而是加入在小精简模块当中。

mkt "小米音乐" /system/priv-app/Music
mkt "小米音乐(new)" /system/app/Music

mkt "维修模式(new)" /system/app/MaintenanceMode

mkt "服务与反馈(new)" /system/priv-app/MIService

mkt "打印处理服务" /system/app/PrintSpooler
mkt "打印处理服务(new)" /system/app/MiuiPrintSpoolerBeta

mkt "MIUI12系统打印服务" /system/app/BuiltInPrintService
mkt "MIUI12.5系统打印服务(new)" /system/priv-app/BuiltInPrintService

mkt "小米互传" /system/priv-app/MiShare #貌似这个精简后，截图发送底部的发送后删除截图功能也被移除。

mkt "悬浮球" /system/app/TouchAssistant
mkt "悬浮球(new)" /system/app/MIUITouchAssistant

#mkt "搜索" /system/priv-app/QuickSearchBox

#mkt "生活黄页" /system/priv-app/YellowPage #与号码标识相关

mkt "投屏(new)" /system/app/MiLink
mkt "投屏服务1" /system/app/MiPlayClient
mkt "投屏服务2" /system/app/MiLinkService2
mkt "投屏服务3" /system/priv-app/WfdService

mkt "NFC" /system/app/NQNfcNci
mkt "小米智能卡" /system/app/TSMClient #和NFC相关

mkt "万象息屏" /system/priv-app/MiuiAod #和息屏指纹相关
mkt "万象息屏(new)" /system/priv-app/MIUIAod #和息屏指纹相关

#mkt "智能助理(负一屏)" /system/priv-app/PersonalAssistant
#mkt "智能助理(负一屏new)" /system/priv-app/MIUIPersonalAssistant

#mkt "小米浏览器" /system/priv-app/Browser MIUI12.5精简没问题，MIUI12会卡米！

mkt "MIUI+" /system/priv-app/Mirror #MIUI12版本名为 跨屏协作
mkt "小米互联通信服务" /system/app/mi_connect_service #推送服务，MIUI12没任何影响，在12.5版本中与MIUI＋关联。

#mkt "钱包" /system/app/Mipay

#mkt "小米支付" /system/app/NextPay

#mkt "米币支付" /system/app/PaymentService

#mkt "小米闻声" /system/app/MiuiAccessibility

mkt "传送门" /system/priv-app/ContentExtension

#mkt "小米视频" /system/priv-app/MiuiVideo

#注意：小爱同学在MIUI12.5被精简，恢复后存在闪退无法继续使用，大概率需要线刷才能解决，请慎重考虑。
#mkt "小爱同学" /system/app/VoiceAssist
#mkt "语音唤醒" /system/app/VoiceTrigger
#mkt "AI虚拟助手(MIUI12)" /system/app/AiAsstVision
#mkt "AI虚拟助手(MIUI12.5)" /system/product/app/aiasst_service

#完成
[[ $i == 0 ]] && abort "error: 连个屁都没精简" || echo "- 刷入成功，重启生效！"
sed -i "/^description=/c description=①解决mdnsd耗电严重问题。②通过精简可以有效提升续航、流畅度、减少内存占用，如果你需要用到的某个程序被精简，请自行拆包删除相应内容再打包重刷即可（有详细注释），更新支持MIUI12.5。更新安装时间：$(date "+%Y-%m-%d %H:%M") 【已安装额外精简v2.1】" "$Streamline/module.prop"