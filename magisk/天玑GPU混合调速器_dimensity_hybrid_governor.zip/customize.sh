freq_table=/data/gpu_freq_table.conf
soc=$(getprop ro.hardware)
if [[ "$soc" == "mt6895" ]]; then
  if [[ $(getprop ro.soc.model | grep 6896) != '' ]]; then
    soc="mt6896"
  fi
fi

if [[ -f $freq_table && $(grep '45000' $freq_table) == '' ]] && [[ "$soc" == "mt6895" ]]; then
  echo '你的配置文件对于该版本的调速器来说有些过旧了'
  echo '你需要背负频率/电压表，并删除'$freq_table
  echo '才能继续更新到新版模块！'
  exit 1
fi

echo
echo " 频率/电压表位于 $freq_table 可自行修改 "
echo " 修改频率表后，需重启手机或通过SCENE开关调速器使其生效 "
echo " 该模块将在开机60秒后生效 "
echo " 如遇死机问题，可在重启后及时禁用模块 "
echo
echo
echo " 此模块用于改善天玑8000/9000 GPU的高频功耗 "
echo " 你所玩的游戏GPU性能需求越大收益越明显 "
echo " 如果你不玩游戏，此模块的作用将不太明显 "
echo
echo

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/gpu-scheduler 0 0 0755 0755

if [[ "$soc" != "mt6983" ]] && [[ "$soc" != "mt6895" ]] && [[ "$soc" != "mt6896" ]]; then
  echo
  echo
  echo "此模块仅适用于天玑8100/8200/9000"
  echo
  echo

  exit 2
fi

volt_list=$(cat /proc/gpufreqv2/stack_working_opp_table | awk '{print $5}')
volt_list=$(echo $volt_list)

# 一般用不上的电压 67500 67500 66875 66875 66250 66250 65625 65625 65000 65000 64375 64375 63750 63125 63125
if [[ "$soc" == "mt6983" ]]; then
volt_list="62500 61875 61875 61250 60625 60000 59375 58750 58125 57500 56875 56250 55625 55000 54375 53750 53125 52500 51875 51250 50625 50000"
else 
volt_list="62500 61875 61875 61250 60625 60000 59375 58750 58125 57500 56875 56250 55625 55000 54375 53750 53125 52500 51875 51250 50625 50000 49375 48750 48125 47500 46875 46250 45625 45000 44375 43750 43125 42500 41875"
fi

freq_list=$(cat /proc/gpufreqv2/stack_working_opp_table | awk '{print $3}')
freq_list=$(echo $freq_list)

# default_margin="7"
# if [[ "$soc" == "mt6983" ]]; then
#   default_margin="7"
# elif [[ "$soc" == "mt6895" ]]; then
#   default_margin="10"
# fi

default_margin="45MHz"
if [[ "$soc" == "mt6983" ]]; then
  default_margin="10MHz"
elif [[ "$soc" == "mt6895" ]]; then
  default_margin="10MHz"
elif [[ "$soc" == "mt6896" ]]; then
  default_margin="10MHz"
fi

if [[ "$soc" == "mt6983" ]]; then
ddr_notes="# 0 : Vcore(0) 750000μv DDR(0) ≥ 6400MHz
# 1 : Vcore(0) 750000μv  DDR(1) 6400MHz
# 2 : Vcore(0) 750000μv  DDR(2) 5500MHz
# 3 : Vcore(1) 650000μv  DDR(2) 5500MHz
# 4 : Vcore(1) 650000μv  DDR(3) 4266MHz
# 5 : Vcore(2) 612500μv  DDR(4) 3200MHz
# 6 : Vcore(3) 550000μv  DDR(5) 2667MHz
# 7 : Vcore(3) 550000μv  DDR(6) 2133MHz
# 8 : Vcore(4) 531250μv  DDR(7) 1866MHz"
else
ddr_notes="# 0 : Vcore(0) 787500μv DDR(0) ≥ 6400MHz
# 1 : Vcore(0) 787500μv  DDR(1) 6400MHz
# 2 : Vcore(0) 787500μv  DDR(2) 5500MHz
# 3 : Vcore(1) 725000μv  DDR(2) 5500MHz
# 4 : Vcore(1) 725000μv  DDR(3) 4266MHz
# 5 : Vcore(2) 625000μv  DDR(4) 3200MHz
# 6 : Vcore(3) 575000μv  DDR(5) 2667MHz
# 7 : Vcore(3) 575000μv  DDR(6) 2133MHz
# 8 : Vcore(4) 550000μv  DDR(7) 1866MHz"
fi


notes="# DDR_OPP 控制内存频率，常用值：
# 999 : 默认/自动
$ddr_notes


# Volt(GPU电压) 每625为一档，常用值：
# $volt_list
# 注: 相同电压下不同频率能效相同，但最大功耗不同
# 例: 在3DMark Wild Life中，349MHz约3.5W, 484MHz约4.1W
# 特殊值 0 代表默认电压，天玑9000不支持设置电压为50000以下数值，因此低频电压需配置为0


# Freq(GPU频率) 必须是以下值之一
# $freq_list


# 配置项：余量(%) 或 余量(MHz)
# 可配置为 0~100 代表GPU空闲比例，数值越大升频越激进
# 或配置为0MHz~800MHz 代表以MHz为单位的固定性能余量
margin=$default_margin


# 为确保你配置的电压不会比默认值还高，请先查看/proc/gpufreqv2/stack_working_opp_table中各频率的电压
# 以下为频率/电压表配置内容
# 请务必将频率/电压值以从低到高的顺序配置
"
preset_9000="# Freq Volt DDR_OPP
214000 0 999
290000 50000 999
366000 50000 999
417000 50000 999
484000 50000 3
552000 53125 3
612000 55000 3
665000 56250 3
717000 56875 3
803000 57500 3
848000 58750 3"

preset_8100="# Freq Volt DDR_OPP
219000 43750 999
280000 46875 999
351000 48750 999
402000 50000 999
487000 52500 3
555000 55625 3
642000 57500 3
721000 58125 3
800000 59375 3
852000 60000 0"

preset_8200="# Freq Volt DDR_OPP
219000 43125 999
268000 44375 999
304000 45625 999
351000 46875 999
402000 48125 999
453000 49375 3
504000 50000 3
555000 51250 3
590000 51875 3
642000 53125 3
695000 55000 3
747000 56250 3
800000 57500 3
852000 58750 0
950000 61250 0"

v(){
  echo $1 $2 > /proc/gpufreqv2/fix_custom_freq_volt
}

if [[ -f $freq_table ]]; then
 cp -f $freq_table $freq_table.bakup
 preset=$(cat $freq_table | grep -E '#.*Freq.*Volt' -A 99)
else
  if [[ "$soc" == "mt6983" ]]; then
    preset="$preset_9000"
  elif [[ "$soc" == "mt6895" ]]; then
    preset="$preset_8100"
  elif [[ "$soc" == "mt6896" ]]; then
    preset="$preset_8200"
  else
    echo "无可用预设，模块不适用于此手机"
    exit 2
  fi
fi

echo "$notes" > $freq_table
echo "$preset" >> $freq_table

echo "如果你在测试过程中遇到了"
echo "不生效、死机、闪屏、突发卡顿"
echo "可能是频率/电压配置有误"
echo ""

echo '查找安装的游戏，并配置games.conf'
echo '* 当/data/games.conf存在时，调速器只对添加的游戏生效'

echo '>> 添加预设游戏&基准测试程序'
preset_games='xyz.aethersx2.android
org.ppsspp.ppsspp
org.ppsspp.ppssppgold
skyline.emu
com.xiaoji.gamesirnsemulator
com.futuremark.dmandroid.application
com.glbenchmark.glbenchmark27
com.antutu.benchmark.full
com.ioncannon.cpuburn.gpugflops

com.tencent.tmgp.cod
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.pubgmhdce
com.tencent.ig
com.tencent.tmgp.sgame
com.tencent.tmgp.sgamece
com.tencent.tmgp.speedmobile
com.tencent.mf.uam
com.tencent.tmgp.cf
com.tencent.af
com.tencent.lolm
com.tencent.jkchess

com.miHoYo.Yuanshen
com.miHoYo.ys.mi
com.miHoYo.ys.bilibili
com.miHoYo.GenshinImpact
com.miHoYo.hkrpg
com.miHoYo.hkrpg.bilibili
com.HoYoverse.hkrpgoversea
com.mihoyo.bh3
com.mihoyo.bh3.mi
com.mihoyo.bh3.uc
com.miHoYo.bh3.wdj
com.miHoYo.bh3.bilibili
com.mojang.minecraftpe

com.tgc.sky.android
com.kiloo.subwaysurf
com.taptap

com.netease.sky
com.netease.moba.aligames
com.netease.party
com.netease.jddsaef
com.netease.g93na
com.netease.g93natw
com.netease.g93nagb

com.netease.mrzhna
com.netease.mrzh.nearme.gamecenter

com.dw.h5yvzr.yt
com.pwrd.hotta.laohu
com.hottagames.hotta.bilibili
com.hottagames.hotta.mi
com.hottagames.hotta.vivo'
echo "$preset_games" > /data/games.conf

echo '>> 查找并添加基于Unity&UE4引擎的游戏'
pm list packages -3 | grep -v 'mobileqq' | cut -f2 -d ':' | while read package
do
  path=$(pm path $package | cut -f2 -d ':')
  dir=${path%/*}
  libs="$dir/lib/arm64"
  if [[ -d $libs ]]; then
    game_libs=$(ls $libs | grep -E '(libunity.so|libUE3.so|libUE4.so)')
    if [[ "$game_libs" != '' ]] && [[ $(echo "$preset_games" | grep $package) == '' ]]; then
      echo " + $package"
      echo $package >> /data/games.conf
    fi
  fi
done

scene_games=/data/data/com.omarea.vtools/shared_prefs/games.xml
if [[ -f $scene_games ]]; then
  echo '>> 添加SCENE识别的游戏'
  grep '="true"' /data/data/com.omarea.vtools/shared_prefs/games.xml | cut -f2 -d '"' | while read package
  do
    r=$(grep $package /data/games.conf)
    if [[ "$r" == '' ]]; then
      echo " + $package"
      echo $package >> /data/games.conf
    fi
  done
fi
