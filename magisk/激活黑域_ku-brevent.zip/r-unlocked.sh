#!/system/bin/sh
MODDIR=${0%/*}

sh /data/data/me.piebridge.brevent/brevent.sh
